
package co.com.ath.pgw.client.ach;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;

import co.com.ath.pgw.client.ach.dto.BankListOut;


/**
 * <p>Clase Java para anonymous complex type.
 * 
 * <p>El siguiente fragmento de esquema especifica el contenido que se espera que haya en esta clase.
 * 
 * <pre>
 * &lt;complexType>
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="bankListOut" type="{http://com/ath/service/payments/pseservices}BankListOut"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "", propOrder = {
    "bankListOut"
})
@XmlRootElement(name = "getBankListResponse")
public class GetBankListResponse {

    @XmlElement(required = true, nillable = true)
    protected BankListOut bankListOut;

    /**
     * Obtiene el valor de la propiedad bankListOut.
     * 
     * @return
     *     possible object is
     *     {@link BankListOut }
     *     
     */
    public BankListOut getBankListOut() {
        return bankListOut;
    }

    /**
     * Define el valor de la propiedad bankListOut.
     * 
     * @param value
     *     allowed object is
     *     {@link BankListOut }
     *     
     */
    public void setBankListOut(BankListOut value) {
        this.bankListOut = value;
    }

}
