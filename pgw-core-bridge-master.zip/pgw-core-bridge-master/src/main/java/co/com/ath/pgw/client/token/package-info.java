@javax.xml.bind.annotation.XmlSchema(namespace = "urn://ath.com.co/xsd/common/", elementFormDefault = javax.xml.bind.annotation.XmlNsForm.QUALIFIED)
package co.com.ath.pgw.client.token;
