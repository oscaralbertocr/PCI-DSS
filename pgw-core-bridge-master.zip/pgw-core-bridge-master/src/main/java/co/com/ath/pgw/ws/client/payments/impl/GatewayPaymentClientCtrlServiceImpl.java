/*
 * GatewayPaymentClientCtrlServiceImpl
 *  
 * GSI - Integración
 * Creado el: 9/10/2014
 *
 * Copyright (c) A Toda Hora S.A. Todos los derechos reservados
 * 
 * Este software es confidencial y es propietario de ATH, queda prohibido
 * su uso, reproducción y copia de manera parcial o permanente salvo autorización
 * expresa de A Toda Hora S.A o de quién represente sus derechos.
 */
package co.com.ath.pgw.ws.client.payments.impl;

import java.math.BigDecimal;
import java.math.BigInteger;
import java.net.MalformedURLException;
import java.net.URL;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import co.com.ath.pgw.bsn.dto.in.AddRBMPaymentInDTO;
import co.com.ath.pgw.bsn.dto.out.AddRBMPaymentOutDTO;
import co.com.ath.pgw.client.rbm.GatewayPayment;
import co.com.ath.pgw.client.rbm.RBMBridgeImplClient;
import co.com.ath.pgw.client.rbm.comercio.compra.CompraElectronicaHTTPService;
import co.com.ath.pgw.client.rbm.dto.TipoRespuesta;
import co.com.ath.pgw.client.rbm.dto.TipoSolicitudCompra;
import co.com.ath.pgw.client.rbm.handler.HeaderHandlerResolver;
import co.com.ath.pgw.client.rbm.model.TipoCabeceraSolicitud;
import co.com.ath.pgw.client.rbm.model.TipoCapacidadPIN;
import co.com.ath.pgw.client.rbm.model.TipoInfoCompraResp;
import co.com.ath.pgw.client.rbm.model.TipoInfoPuntoInteraccion;
import co.com.ath.pgw.client.rbm.model.TipoInfoRespuesta;
import co.com.ath.pgw.client.rbm.model.TipoInfoTerminal;
import co.com.ath.pgw.client.rbm.model.TipoInfoUbicacion;
import co.com.ath.pgw.client.rbm.model.TipoModoCapturaPAN;
import co.com.ath.pgw.client.rbm.common.AgreementInfoType;
import co.com.ath.pgw.client.rbm.common.CardLogicalDataType;
import co.com.ath.pgw.client.rbm.common.CustNameType;
import co.com.ath.pgw.client.rbm.common.FeeType;
import co.com.ath.pgw.client.rbm.common.OrderInfoType;
import co.com.ath.pgw.client.rbm.common.PersonalDataType;
import co.com.ath.pgw.client.rbm.v1.RBMPaymentAddRqType;
import co.com.ath.pgw.client.rbm.v1.RBMPaymentAddRsType;
import co.com.ath.pgw.client.rbm.common.ReferenceType;
import co.com.ath.pgw.client.rbm.common.TaxFeeType;
import co.com.ath.pgw.client.rbm.common.UserIdType;
import co.com.ath.pgw.util.constants.CoreConstants;
import co.com.ath.pgw.util.converter.DateUtil;
import co.com.ath.pgw.util.converter.PaymentsObjectsConverter;
import co.com.ath.pgw.util.converter.Util;
import co.com.ath.pgw.ws.client.payments.GatewayPaymentClientCtrlService;

/**
 * Implementación por defecto para el consumo de los servicios de pago.
 *
 * @author Andrés Méndez Juanias <proveedor_mamendez@ath.com.co> 
 * @version 1.0 9/10/2014
 * @since 1.0
 * 
 * @PCI-DSS
 * <strong>Autor</strong>Efren Lopez </br>
 * <strong>Descripcion</strong>Actualización de campos </br>
 * <strong>Numero de Cambios</strong>1</br>
 * <strong>Identificador corto</strong>C01</br>
 * 
 * @PCI-DSS
 * <strong>Autor</strong>Efren Lopez </br>
 * <strong>Descripcion</strong>Implementación de WSEE Security</br>
 * <strong>Numero de Cambios</strong>1</br>
 * <strong>Identificador corto</strong>C02</br>
 * 
 * @PCI-DSS
 * <strong>Autor</strong>Jesus Avendaño</br>
 * <strong>Descripcion</strong>Implementacion de cambio, consumo a Core-Bus-RBm y desimplementacion de consumo Core-RBM</br>
 * <strong>Numero de Cambios</strong>3</br>
 * <strong>Identificador corto</strong>C03</br>
 * <strong>Fecha</strong>17/06/2020</br>
 * 
 */
@Service
public class GatewayPaymentClientCtrlServiceImpl implements GatewayPaymentClientCtrlService {
	
	static Logger LOGGER = LoggerFactory.getLogger(GatewayPaymentClientCtrlServiceImpl.class);
	
	@Value("${pasarela.ws.rbm.wsdl}")
	private String urlEndpoint;
	
	@Value("${pasarela.ws.rbmCD.wsdl}")
	private String urlEndpointCD;
	
	@Value("${pasarela.ws.rbm.tipoTerminal}")
	private String tipoTerminal;
	
	private CompraElectronicaHTTPService compraElectronicaHTTPService;
	
	public GatewayPaymentClientCtrlServiceImpl(){
		super();
	}

	@Override
	public AddRBMPaymentOutDTO addRBMPayment(AddRBMPaymentInDTO inDTO) {
		TipoSolicitudCompra inDTOClient = null;
		TipoRespuesta outDTOClient = null;
		try {
			/**
			 * INI-C03
			 */
			RBMBridgeImplClient rbmBridgeImplClient = new RBMBridgeImplClient(urlEndpointCD);
						
//			compraElectronicaHTTPService = new CompraElectronicaHTTPService(new URL(urlEndpoint));
//			HeaderHandlerResolver headerHandlerResolver = new HeaderHandlerResolver(athUsername,ath); 
//			compraElectronicaHTTPService.setHandlerResolver(headerHandlerResolver);

			
			inDTOClient = PaymentsObjectsConverter.convertAddRBMPaymentInDTOToRBMPaymentAddRqType(inDTO);
			TipoCabeceraSolicitud tipoCabeceraSolicitud = new TipoCabeceraSolicitud();
			TipoInfoPuntoInteraccion tipoInfoPuntoInteraccion = new TipoInfoPuntoInteraccion();
			tipoInfoPuntoInteraccion.setTipoTerminal(tipoTerminal);
			tipoInfoPuntoInteraccion.setIdAdquiriente(inDTO.getTransactionBO().getReference1());
			tipoInfoPuntoInteraccion.setIdTerminal(inDTO.getTransactionBO().getReference2());
			tipoInfoPuntoInteraccion.setIdTransaccionTerminal(Long.parseLong(Util.cortaDerechaTexto(inDTO.getTransactionBO().getPmtId(), CoreConstants.PMTID_LIMIT)));
			/**
			 * INI-C01
			 */
			tipoInfoPuntoInteraccion.setModoCapturaPAN(TipoModoCapturaPAN.MANUAL);
			tipoInfoPuntoInteraccion.setCapacidadPIN(TipoCapacidadPIN.VIRTUAL);
			/**
//			 * FIN-C01
//			 */
			tipoCabeceraSolicitud.setInfoPuntoInteraccion(tipoInfoPuntoInteraccion);
			inDTOClient.setCabeceraSolicitud(tipoCabeceraSolicitud);
			
			RBMPaymentAddRqType rbmPaymentAddRqType = convertTipoSolicitudCompraToRBMPaymentAddRqType(inDTO);
//			LOGGER.info("Iniciando transaccion cliente RBM: \n{}", inDTOClient);
//			outDTOClient = compraElectronicaHTTPService.getCompraElectronicaHTTPPort().compraProcesar(inDTOClient);
			LOGGER.info("Iniciando transaccion cliente RBM: \n{}", rbmPaymentAddRqType);
			RBMPaymentAddRsType rbmPaymentAddRsType = rbmBridgeImplClient.getClient().addRBMPayment(rbmPaymentAddRqType);
			outDTOClient = convertRBMPaymentAddRsTypeToTipoRespuesta(rbmPaymentAddRsType,tipoCabeceraSolicitud);
			LOGGER.info("Respuesta transaccion cliente RBM: \n{}", outDTOClient);
//			LOGGER.info("Respuesta transaccion cliente RBM: \n{}", outDTOClient);
			PaymentsObjectsConverter.mapHomologationCodeRBM(outDTOClient);
			LOGGER.info("Homologación de respuestas cliente RBM: \n{}", outDTOClient);
			
			/**
			 * FIN-C03
			 */
		} catch (MalformedURLException e) {
			LOGGER.error("Can not initialize wsdl", urlEndpoint);
			e.printStackTrace();
	    } catch (Exception e) {
	    	e.printStackTrace();
		}
		
		return PaymentsObjectsConverter.convertRBMPaymentAddRsTypeToAddRBMPaymentOutDTO(outDTOClient);
	}
	
	/**
	 * INI-C03
	 */
	private RBMPaymentAddRqType convertTipoSolicitudCompraToRBMPaymentAddRqType(AddRBMPaymentInDTO inDTO) {
		TipoSolicitudCompra inDTOClient = null;
		RBMPaymentAddRqType rbmPaymentAddRqType = new RBMPaymentAddRqType();
		inDTOClient = PaymentsObjectsConverter.convertAddRBMPaymentInDTOToRBMPaymentAddRqType(inDTO);
		TipoCabeceraSolicitud tipoCabeceraSolicitud = new TipoCabeceraSolicitud();
		TipoInfoPuntoInteraccion tipoInfoPuntoInteraccion = new TipoInfoPuntoInteraccion();
		tipoInfoPuntoInteraccion.setTipoTerminal(tipoTerminal);
		tipoInfoPuntoInteraccion.setIdAdquiriente(inDTO.getTransactionBO().getReference1());
		tipoInfoPuntoInteraccion.setIdTerminal(inDTO.getTransactionBO().getReference2());
		tipoInfoPuntoInteraccion.setIdTransaccionTerminal(Long.parseLong(Util.cortaDerechaTexto(inDTO.getTransactionBO().getPmtId(), CoreConstants.PMTID_LIMIT)));
		tipoInfoPuntoInteraccion.setModoCapturaPAN(TipoModoCapturaPAN.MANUAL);
		tipoInfoPuntoInteraccion.setCapacidadPIN(TipoCapacidadPIN.VIRTUAL);
		tipoCabeceraSolicitud.setInfoPuntoInteraccion(tipoInfoPuntoInteraccion);
		inDTOClient.setCabeceraSolicitud(tipoCabeceraSolicitud);
		rbmPaymentAddRqType.setRqUID(inDTO.getRqUID());
		rbmPaymentAddRqType.setChannel(inDTO.getTransactionBO().getSource().getId());
		rbmPaymentAddRqType.setClientDt(DateUtil.toXMLGregorianCalendar(inDTO.getClientDt()));
		rbmPaymentAddRqType.setIPAddr(inDTO.getIpAddr());
		UserIdType userId = new UserIdType();
		userId.setCustIdType(inDTO.getTransactionBO().getCustomerDocType());
		userId.setCustIdNum(inDTO.getTransactionBO().getCustomerDocId());
		rbmPaymentAddRqType.setUserId(userId);
		rbmPaymentAddRqType.setPmtId(inDTO.getTransactionBO().getPmtId());
		PersonalDataType personalDataType = new PersonalDataType();
		CustNameType custname = new CustNameType();
		custname.setFirstName(inDTO.getTransactionBO().getCustomerName());
		custname.setMiddleName(inDTO.getTransactionBO().getMiddleNameBuyer());
		custname.setLastName(inDTO.getTransactionBO().getLastNameBuyer());
		personalDataType.setCustName(custname);
		personalDataType.setEmailAddr(inDTO.getTransactionBO().getCustomerEmail());
		personalDataType.setPhone(inDTO.getTransactionBO().getCustomerMobileNumber());
		List<PersonalDataType> personalData = new ArrayList<PersonalDataType>();
		personalData.add(personalDataType);
		rbmPaymentAddRqType.setPersonalData(personalData);
		AgreementInfoType agreementInfoType = new AgreementInfoType();
		agreementInfoType.setAgreementId(String.valueOf(inDTO.getTransactionBO().getCommerce().getNuraCode()));
		agreementInfoType.setName(inDTO.getTransactionBO().getCommerce().getSubscription().getCompanyName());
		agreementInfoType.setNIT(inDTO.getTransactionBO().getCommerce().getNit());
		rbmPaymentAddRqType.setAgreementInfo(agreementInfoType);
		CardLogicalDataType cardLogicalDataType = new CardLogicalDataType();
		cardLogicalDataType.setCardEmbossNum(inDTO.getTransactionBO().getCreditCard().getNumber());
		cardLogicalDataType.setBrand(inDTO.getTransactionBO().getCreditCard().getBrand().getName());
		cardLogicalDataType.setExpDt(DateUtil.toXMLGregorianCalendar(inDTO.getExpDate()));
		cardLogicalDataType.setCardVrfyData(inDTO.getTransactionBO().getCreditCard().getSecurityCode());
		rbmPaymentAddRqType.setCardLogicalData(cardLogicalDataType);
		rbmPaymentAddRqType.setInstalamentsNum(inDTO.getInstalamentsNum());
		OrderInfoType orderInfoType = new OrderInfoType();
		orderInfoType.setOrderId(Long.parseLong(inDTO.getTransactionBO().getOrderNumber()));
		orderInfoType.setDesc(inDTO.getTransactionBO().getDescription());
		rbmPaymentAddRqType.setOrderInfo(orderInfoType);
		FeeType feeType = new FeeType();
		feeType.setAmt(inDTO.getTransactionBO().getTotalValue());
		feeType.setCurCode(inDTO.getTransactionBO().getCurrency());
		rbmPaymentAddRqType.setFee(feeType);
		TaxFeeType taxFeeType = new TaxFeeType();
		taxFeeType.setAmt(inDTO.getTransactionBO().getTaxValue());
		taxFeeType.setCurCode(inDTO.getTransactionBO().getCurrency());
		rbmPaymentAddRqType.setTaxFee(taxFeeType);
		ReferenceType referenceType = new ReferenceType();
		ReferenceType r2 = new ReferenceType();
		referenceType.setRefId("");
		referenceType.setRefType("");
		r2.setRefId("");
		r2.setRefType("");
		List<ReferenceType> reference =  new ArrayList<ReferenceType>();
		reference.add(referenceType);	
		reference.add(r2);					
		rbmPaymentAddRqType.setReference(reference);
		return rbmPaymentAddRqType;
	}
	/**
	 * FIN-C03
	 */
	
	/**
	 * INI-C03
	 */
	private TipoRespuesta convertRBMPaymentAddRsTypeToTipoRespuesta(RBMPaymentAddRsType rbmPaymentAddRsType, TipoCabeceraSolicitud tipoCabeceraSolicitud) {
		TipoRespuesta tipoRespuesta = new TipoRespuesta();
		TipoInfoPuntoInteraccion tipoInfoPuntoInteraccion = new TipoInfoPuntoInteraccion();
		tipoInfoPuntoInteraccion.setTipoTerminal(tipoCabeceraSolicitud.getInfoPuntoInteraccion().getTipoTerminal());
		tipoInfoPuntoInteraccion.setIdTerminal(tipoCabeceraSolicitud.getInfoPuntoInteraccion().getIdTerminal());
		tipoInfoPuntoInteraccion.setIdAdquiriente(tipoCabeceraSolicitud.getInfoPuntoInteraccion().getIdAdquiriente());
		tipoInfoPuntoInteraccion.setTipoTerminal(tipoCabeceraSolicitud.getInfoPuntoInteraccion().getTipoTerminal());
		tipoInfoPuntoInteraccion.setModoCapturaPAN(tipoCabeceraSolicitud.getInfoPuntoInteraccion().getModoCapturaPAN());
		tipoInfoPuntoInteraccion.setCapacidadPIN(tipoCabeceraSolicitud.getInfoPuntoInteraccion().getCapacidadPIN());
		tipoCabeceraSolicitud.setInfoPuntoInteraccion(tipoInfoPuntoInteraccion);
		tipoRespuesta.setCabeceraRespuesta(tipoCabeceraSolicitud);
		
		TipoInfoRespuesta tipoInfoRespuesta = new TipoInfoRespuesta();
		tipoInfoRespuesta.setCodRespuesta(String.valueOf(rbmPaymentAddRsType.getTransactionStatus().getTrnServerStatusCode()));
		tipoInfoRespuesta.setDescRespuesta(rbmPaymentAddRsType.getTransactionStatus().getTrnServerStatusDesc());
		tipoInfoRespuesta.setEstado(rbmPaymentAddRsType.getTransactionStatus().getTrnServerStatusDesc());
		tipoRespuesta.setInfoRespuesta(tipoInfoRespuesta);
		
		TipoInfoCompraResp tipoInfoCompraResp = new TipoInfoCompraResp();
		tipoInfoCompraResp.setFechaPosteo(rbmPaymentAddRsType.getTransactionStatus().getCompensationDt());
		tipoInfoCompraResp.setFechaTransaccion(rbmPaymentAddRsType.getTransactionStatus().getEffDt());
		tipoInfoCompraResp.setNumAprobacion(rbmPaymentAddRsType.getTransactionStatus().getApprovalId());
		tipoRespuesta.setInfoCompraResp(tipoInfoCompraResp);
		
		tipoRespuesta.setIdTransaccionAutorizador(tipoCabeceraSolicitud.getInfoPuntoInteraccion().getIdTransaccionTerminal());
		
		TipoInfoTerminal tipoInfoTerminal = new TipoInfoTerminal();
		
		tipoInfoTerminal.setNombreAdquiriente("");
		TipoInfoUbicacion tipoInfoUbicacion = new TipoInfoUbicacion();
		tipoInfoUbicacion.setCiudad("");
		tipoInfoUbicacion.setDepartamento("");
		tipoInfoUbicacion.setPais("");
		tipoInfoTerminal.setInfoUbicacion(tipoInfoUbicacion);
		
		tipoRespuesta.setInfoTerminal(tipoInfoTerminal);
		return tipoRespuesta;
	}
	/**
	 * FIN-C03
	 */

}
