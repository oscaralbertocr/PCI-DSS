package co.com.ath.pgw.ws.client.payments.impl;

import java.net.InetAddress;
import java.net.MalformedURLException;
import java.net.UnknownHostException;
import java.security.SecureRandom;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.TimeZone;

import javax.annotation.PostConstruct;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import co.com.ath.pgw.bsn.model.bo.TransactionBO;
import co.com.ath.pgw.client.bank.info.GetBankInfoRequest;
import co.com.ath.pgw.client.bank.info.GetBankInfoResponse;
import co.com.ath.pgw.client.bank.info.MsgRqHdrType;
import co.com.ath.pgw.client.bank.info.xsd.ifx.BankInfoInqRqType;
import co.com.ath.pgw.client.bank.info.xsd.ifx.BankInfoType;
import co.com.ath.pgw.client.bank.info.xsd.ifx.BillPmtInfoType;
import co.com.ath.pgw.client.bank.info.xsd.ifx.DepAcctIdFromType;
import co.com.ath.pgw.util.constants.TransactionChannels;
import co.com.ath.pgw.util.converter.DateUtil;
import co.com.ath.pgw.ws.client.bankinfoinquiry.BankInfoInquiryImplClient;
import co.com.ath.pgw.ws.client.payments.BankInquiryService;

/**
 * 
 *  @RQ27199
 *  <strong>Autor</strong>Camilo Bustamante</br>
 *  <strong>Descripcion</strong>Ajuste a consulta banco recaudador</br>
 *  <strong>Numero de Cambios</strong>1</br>
 *  <strong>Identificador corto</strong>C01</br>
 *
 */
@Service
public class BankInquiryServiceImpl implements BankInquiryService {
	
	static Logger LOGGER = LoggerFactory.getLogger(BankInquiryServiceImpl.class);

	BankInfoInquiryImplClient bankInfoInquiryImplClient;
	
	@Value("${pasarela.ws.bankinfoinquiry.wsdl}")
	private String urlEndPoint;
		
	@PostConstruct
	public void init(){
		try {
			bankInfoInquiryImplClient = new BankInfoInquiryImplClient(urlEndPoint);			
		} catch (MalformedURLException e) {
			LOGGER.error("Existe un error con la URL ({}) del servicio @Bankinfo, {}", 
					urlEndPoint, e.getMessage());
		} catch (Exception e) {
			LOGGER.error("No fue posible inicializar el servicio @Bankinfo, {}", 
					e.getMessage());
		}
	}
	
	public GetBankInfoResponse getBankInfo(TransactionBO txBo) {
		
		GetBankInfoRequest getBankInfoRequest = new GetBankInfoRequest();
		BankInfoInqRqType bankInfoInqRq = new BankInfoInqRqType();
		
		//Generacion rqid
		SecureRandom codGen = new SecureRandom();
		Long temporalRqid = codGen.nextLong();
		if (temporalRqid <= 0) {
			temporalRqid = temporalRqid * (-1);
		}
		
		bankInfoInqRq.setRqUID(temporalRqid);
		
		//Obligatorio por wsdl
		BillPmtInfoType billPmtInfoType = new BillPmtInfoType();
				
		//Obligatorio por wsdl
		DepAcctIdFromType depAcctIdFrom = new DepAcctIdFromType();
				
		BankInfoType bankInfo = new BankInfoType();
		bankInfo.setBankId(txBo.getBank().getAchCode().toString());
		
		depAcctIdFrom.setBankInfo(bankInfo);
		billPmtInfoType.setDepAcctIdFrom(depAcctIdFrom);
		billPmtInfoType.setPmtCodServ(txBo.getCommerce().getNuraCode());
		billPmtInfoType.setInvoiceNum(txBo.getOrderNumber());
		billPmtInfoType.setTrxDt(getTxDate(txBo.getTransactionDate()));
		billPmtInfoType.setApprovalId(txBo.getPmtId().toString());
		billPmtInfoType.setApprovalId(txBo.getPmtId().toString());

		bankInfoInqRq.getBillPmtInfo().add(billPmtInfoType);
		getBankInfoRequest.setBankInfoInqRq(bankInfoInqRq);
			
		GetBankInfoResponse bankInfoResponse = null;
		try {
			LOGGER.info("@Bankinfo input pmtid: {}\n{}", txBo.getPmtId(), getBankInfoRequest);
			bankInfoResponse = bankInfoInquiryImplClient.getClient().getBankInfo(getBankInfoRequest);
			LOGGER.info("@Bankinfo output pmtid: {}\n{}", txBo.getPmtId(), bankInfoResponse);
			
			return bankInfoResponse;
		} catch (Exception e) {
			LOGGER.error("@Bankinfo No fue posible consultar el banco de recuador para el pmtid: {}\n{}", 
					txBo.getPmtId(), e.getLocalizedMessage());
			return null;
		}
		
	}
	
	
	/**
	 * Retorna el formato de fecha del documento del servicio.
	 * 
	 * Formato [-]CCYY-MM-DDThh:mm:ss[Z|(+|-)hh:mm]
	 * 
	 * @param transactionDate
	 * @return
	 */
	private String getTxDate(Date transactionDate) {
		
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss'Z'");
		sdf.setTimeZone(TimeZone.getTimeZone("GMT"));
		return sdf.format(transactionDate);

	}
	/**FIN-C01**/
}