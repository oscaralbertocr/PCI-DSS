
package co.com.ath.pgw.client.ach;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;

import co.com.ath.pgw.client.ach.dto.BankListInp;


/**
 * <p>Clase Java para anonymous complex type.
 * 
 * <p>El siguiente fragmento de esquema especifica el contenido que se espera que haya en esta clase.
 * 
 * <pre>
 * &lt;complexType>
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="bankListInp" type="{http://com/ath/service/payments/pseservices}BankListInp"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "", propOrder = {
    "bankListInp"
})
@XmlRootElement(name = "getBankList")
public class GetBankList {

    @XmlElement(required = true, nillable = true)
    protected BankListInp bankListInp;

    /**
     * Obtiene el valor de la propiedad bankListInp.
     * 
     * @return
     *     possible object is
     *     {@link BankListInp }
     *     
     */
    public BankListInp getBankListInp() {
        return bankListInp;
    }

    /**
     * Define el valor de la propiedad bankListInp.
     * 
     * @param value
     *     allowed object is
     *     {@link BankListInp }
     *     
     */
    public void setBankListInp(BankListInp value) {
        this.bankListInp = value;
    }

}
