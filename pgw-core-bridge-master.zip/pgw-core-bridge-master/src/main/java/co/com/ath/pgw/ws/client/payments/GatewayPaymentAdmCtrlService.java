/*
 * GatewayPaymentAdmCtrlService
 *  
 * GSI - Integración
 * Creado el: 16/10/2014
 *
 * Copyright (c) A Toda Hora S.A. Todos los derechos reservados
 * 
 * Este software es confidencial y es propietario de ATH, queda prohibido
 * su uso, reproducción y copia de manera parcial o permanente salvo autorización
 * expresa de A Toda Hora S.A o de quién represente sus derechos.
 */
package co.com.ath.pgw.ws.client.payments;

import co.com.ath.pgw.bsn.dto.in.ModRevRBMPaymentInDTO;
import co.com.ath.pgw.bsn.dto.out.ModRevRBMPaymentOutDTO;

/**
 * Interfaz que define los metodos disponibles para consumir los servicios de
 * GatewayPaymentAdm. 
 *
 * @author Andrés Méndez Juanias <proveedor_mamendez@ath.com.co> 
 * @version 1.0 16/10/2014
 * @since 1.0
 */
public interface GatewayPaymentAdmCtrlService {

	public ModRevRBMPaymentOutDTO modRevRBMPayment(ModRevRBMPaymentInDTO inDTO, String username, String pass);
	
}
