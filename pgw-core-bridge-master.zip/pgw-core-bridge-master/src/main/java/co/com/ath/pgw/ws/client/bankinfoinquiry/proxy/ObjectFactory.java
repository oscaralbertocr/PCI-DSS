
package co.com.ath.pgw.ws.client.bankinfoinquiry.proxy;

import javax.xml.bind.JAXBElement;
import javax.xml.bind.annotation.XmlElementDecl;
import javax.xml.bind.annotation.XmlRegistry;
import javax.xml.namespace.QName;

import co.com.ath.pgw.client.bank.info.GetBankInfoRequest;
import co.com.ath.pgw.client.bank.info.GetBankInfoResponse;
import co.com.ath.pgw.client.bank.info.xsd.ifx.BankInfoInqRqType;
import co.com.ath.pgw.client.bank.info.xsd.ifx.BankInfoInqRsType;


/**
 * This object contains factory methods for each 
 * Java content interface and Java element interface 
 * generated in the cliente package. 
 * <p>An ObjectFactory allows you to programatically 
 * construct new instances of the Java representation 
 * for XML content. The Java representation of XML 
 * content can consist of schema derived interfaces 
 * and classes representing the binding of schema 
 * type definitions, element declarations and model 
 * groups.  Factory methods for each of these are 
 * provided in this class.
 * 
 */
@XmlRegistry
public class ObjectFactory {

    private final static QName _BankInfoInqRs_QNAME = new QName("urn://grupoaval.com/inquiry/v1/", "BankInfoInqRs");
    private final static QName _BankInfoInqRq_QNAME = new QName("urn://grupoaval.com/inquiry/v1/", "BankInfoInqRq");

    /**
     * Create a new ObjectFactory that can be used to create new instances of schema derived classes for package: cliente
     * 
     */
    public ObjectFactory() {
    }

    /**
     * Create an instance of {@link BankInfoInqRqType }
     * 
     */
    public BankInfoInqRqType createBankInfoInqRqType() {
        return new BankInfoInqRqType();
    }

    /**
     * Create an instance of {@link GetBankInfoResponse }
     * 
     */
    public GetBankInfoResponse createGetBankInfoResponse() {
        return new GetBankInfoResponse();
    }

    /**
     * Create an instance of {@link BankInfoInqRsType }
     * 
     */
    public BankInfoInqRsType createBankInfoInqRsType() {
        return new BankInfoInqRsType();
    }

    /**
     * Create an instance of {@link GetBankInfoRequest }
     * 
     */
    public GetBankInfoRequest createGetBankInfoRequest() {
        return new GetBankInfoRequest();
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link BankInfoInqRsType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "urn://grupoaval.com/inquiry/v1/", name = "BankInfoInqRs")
    public JAXBElement<BankInfoInqRsType> createBankInfoInqRs(BankInfoInqRsType value) {
        return new JAXBElement<BankInfoInqRsType>(_BankInfoInqRs_QNAME, BankInfoInqRsType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link BankInfoInqRqType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "urn://grupoaval.com/inquiry/v1/", name = "BankInfoInqRq")
    public JAXBElement<BankInfoInqRqType> createBankInfoInqRq(BankInfoInqRqType value) {
        return new JAXBElement<BankInfoInqRqType>(_BankInfoInqRq_QNAME, BankInfoInqRqType.class, null, value);
    }

}
