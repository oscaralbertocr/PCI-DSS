package co.com.ath.pgw.ws.client.bankinfoinquiry;

import java.net.MalformedURLException;
import java.net.URL;

import javax.net.ssl.HostnameVerifier;
import javax.net.ssl.HttpsURLConnection;
import javax.net.ssl.SSLSession;
import javax.xml.ws.BindingProvider;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import co.com.ath.pgw.util.client.WebServiceClientUtil;
import co.com.ath.pgw.util.client.XTrustProvider;
import co.com.ath.pgw.ws.client.bankinfoinquiry.proxy.BankInquiry;
import co.com.ath.pgw.ws.client.bankinfoinquiry.proxy.BankInquirySvc;

/**
 * Implementación del cliente del servicio BankInfoInquiry
 * @author 
 * @version 1.0
 * @since 1.0
 */
public class BankInfoInquiryImplClient {
	
	static Logger LOGGER = LoggerFactory.getLogger(BankInfoInquiryImplClient.class);

	/** Verifica e indica que el nombre del host es valido */
	static {
	    HttpsURLConnection.setDefaultHostnameVerifier(new HostnameVerifier(){
			@Override
			public boolean verify(String hostname, SSLSession arg1) {
				/*
                if (hostname.equals("localhost")){
                	return true;
                }
                return false;
                */
				return true;
			}
        });
	}
	
	/** EndPoint donde se encuentra el servicio */
	private String urlEndPoint;
	
	/** Objeto que consume el servicio */
	private BankInquiry client;
	
	/** Constructor que recibe la url del EndPoint a consumir */
	public BankInfoInquiryImplClient(String urlEndPoint) throws MalformedURLException {
		LOGGER.info("Iniciando cliente para EndPoint-> {}", urlEndPoint);
		this.urlEndPoint = urlEndPoint;
		try {
			init();
		} catch (MalformedURLException e) {
			LOGGER.error("No se pudo inicializar el EndPoint", e);
		} catch (Exception e) {
			LOGGER.error("No se pudo inicializar el EndPoint", e);
		}
	}
   
   /**
    * Inicia el contexto del cliente
    */
	private void init() throws MalformedURLException {
		XTrustProvider.install();
		BankInquirySvc service = new BankInquirySvc(new URL(this.urlEndPoint));
		this.client = service.getBankInquiryPort();
		WebServiceClientUtil.attachEndPointToClient((BindingProvider) this.client, this.urlEndPoint);
        LOGGER.info("Cliente iniciado... ");
	}
	
	/**
	 * @return the urlEndPoint
	 */
	public String getUrlEndPoint() {
		return urlEndPoint;
	}
	
	/**
	 * @return the client
	 */
	public BankInquiry getClient() {
		return client;
	}
	
	
}
