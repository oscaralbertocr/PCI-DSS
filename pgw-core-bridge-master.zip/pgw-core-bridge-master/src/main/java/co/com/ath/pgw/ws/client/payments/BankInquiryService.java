package co.com.ath.pgw.ws.client.payments;

import co.com.ath.pgw.bsn.model.bo.TransactionBO;
import co.com.ath.pgw.client.bank.info.GetBankInfoResponse;

public interface BankInquiryService {

	/**
	 * Servicio que realiza la consulta de la información del banco de una transacción.
	 * 
	 * @param transacciones
	 *            DTO con la información de entrada.
	 * @return DTO con el resultado.
	 */

	public GetBankInfoResponse getBankInfo(TransactionBO txBo);
	
}
