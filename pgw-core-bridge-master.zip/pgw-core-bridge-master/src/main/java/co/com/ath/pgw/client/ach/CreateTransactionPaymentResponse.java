
package co.com.ath.pgw.client.ach;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;

import co.com.ath.pgw.client.ach.dto.TransactionPaymentOut;


/**
 * <p>Clase Java para anonymous complex type.
 * 
 * <p>El siguiente fragmento de esquema especifica el contenido que se espera que haya en esta clase.
 * 
 * <pre>
 * &lt;complexType>
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="transactionPaymentOut" type="{http://com/ath/service/payments/pseservices}TransactionPaymentOut"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "", propOrder = {
    "transactionPaymentOut"
})
@XmlRootElement(name = "createTransactionPaymentResponse")
public class CreateTransactionPaymentResponse {

    @XmlElement(required = true)
    protected TransactionPaymentOut transactionPaymentOut;

    /**
     * Obtiene el valor de la propiedad transactionPaymentOut.
     * 
     * @return
     *     possible object is
     *     {@link TransactionPaymentOut }
     *     
     */
    public TransactionPaymentOut getTransactionPaymentOut() {
        return transactionPaymentOut;
    }

    /**
     * Define el valor de la propiedad transactionPaymentOut.
     * 
     * @param value
     *     allowed object is
     *     {@link TransactionPaymentOut }
     *     
     */
    public void setTransactionPaymentOut(TransactionPaymentOut value) {
        this.transactionPaymentOut = value;
    }

}
