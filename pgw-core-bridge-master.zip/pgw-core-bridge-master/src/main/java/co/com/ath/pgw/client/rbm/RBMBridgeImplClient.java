package co.com.ath.pgw.client.rbm;

import java.net.MalformedURLException;
import java.net.URL;

import javax.net.ssl.HostnameVerifier;
import javax.net.ssl.HttpsURLConnection;
import javax.net.ssl.SSLSession;
import javax.xml.ws.BindingProvider;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import co.com.ath.pgw.client.rbm.GatewayPayment;
import co.com.ath.pgw.client.rbm.GatewayPaymentService;
import co.com.ath.pgw.client.rbm.WebServiceClientUtil;
import co.com.ath.pgw.client.rbm.XTrustProvider;


/**
 * Implementación del cliente del servicio GatewayPayment
 * @author proveedor_cjmurillo
 * @version 1.0
 * @since 1.0
 */
public class RBMBridgeImplClient{
	
	static Logger LOGGER = LoggerFactory.getLogger(RBMBridgeImplClient.class);
	
	/** Verifica e indica que el nombre del host es valido */
	static {
	    HttpsURLConnection.setDefaultHostnameVerifier(new HostnameVerifier(){
			@Override
			public boolean verify(String hostname, SSLSession arg1) {
				/*
                if (hostname.equals("localhost")){
                	return true;
                }
                return false;
                */
				return true;
			}
        });
	}
	
	
	/** EndPoint donde se encuentra el servicio */
    private String urlEndPoint;
    
    /** Objeto que consume el servicio */
    private GatewayPayment client;
    
    /** Constructor que recibe la url del EndPoint a consumir 
     * @throws MalformedURLException */
    public RBMBridgeImplClient(String urlEndPoint) throws MalformedURLException {
    	LOGGER.info("Iniciando cliente para EndPoint-> {}", urlEndPoint);
    	this.urlEndPoint = urlEndPoint;
        try {
			init();
		} catch (MalformedURLException e) {
			LOGGER.error("No se pudo inicializar el EndPoint \n{}", e);
		} catch (RuntimeException runtimeException) {
			LOGGER.error("Error inicializando cliente GatewayPaymentImplClient: \n{}", runtimeException);
			throw runtimeException;
		}
    
    }

    
    /**
     * Inicia el contexto del cliente
     * @throws MalformedURLException 
     */
    private void init() throws MalformedURLException {
    	XTrustProvider.install();
    	GatewayPaymentService service = new GatewayPaymentService(new URL(this.urlEndPoint));
		this.client = service.getGatewayPaymentPort();
        WebServiceClientUtil.attachEndPointToClient((BindingProvider) this.client, this.urlEndPoint);
        LOGGER.info("Cliente iniciado... ");
    }

    
	/**
	 * @return the urlEndPoint
	 */
	public String getUrlEndPoint() {
		return urlEndPoint;
	}

	/**
	 * @return the client
	 */
	public GatewayPayment getClient() {
		return client;
	}

}
