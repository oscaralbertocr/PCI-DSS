/*
 * GatewayPaymentAdmCtrlServiceImpl
 *  
 * GSI - Integración
 * Creado el: 16/10/2014
 *
 * Copyright (c) A Toda Hora S.A. Todos los derechos reservados
 * 
 * Este software es confidencial y es propietario de ATH, queda prohibido
 * su uso, reproducción y copia de manera parcial o permanente salvo autorización
 * expresa de A Toda Hora S.A o de quién represente sus derechos.
 */
package co.com.ath.pgw.ws.client.payments.impl;

import java.net.MalformedURLException;
import java.net.URL;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import co.com.ath.pgw.bsn.dto.in.ModRevRBMPaymentInDTO;
import co.com.ath.pgw.bsn.dto.out.ModRevRBMPaymentOutDTO;
import co.com.ath.pgw.client.rbm.comercio.compra.CompraElectronicaHTTPService;
import co.com.ath.pgw.client.rbm.dto.TipoRespuesta;
import co.com.ath.pgw.client.rbm.dto.TipoSolicitudCompra;
import co.com.ath.pgw.client.rbm.handler.HeaderHandlerResolver;
import co.com.ath.pgw.client.rbm.model.TipoCabeceraSolicitud;
import co.com.ath.pgw.client.rbm.model.TipoCapacidadPIN;
import co.com.ath.pgw.client.rbm.model.TipoInfoPuntoInteraccion;
import co.com.ath.pgw.client.rbm.model.TipoModoCapturaPAN;
import co.com.ath.pgw.util.constants.CoreConstants;
import co.com.ath.pgw.util.converter.PaymentsObjectsConverter;
import co.com.ath.pgw.util.converter.Util;
import co.com.ath.pgw.ws.client.payments.GatewayPaymentAdmCtrlService;

/**
 * Class description goes here...
 *
 * @author Andrés Méndez Juanias <proveedor_mamendez@ath.com.co> 
 * @version 1.0 16/10/2014
 * @since 1.0
 */
@Service
public class GatewayPaymentAdmCtrlServiceImpl implements GatewayPaymentAdmCtrlService {
    
    static Logger LOGGER = LoggerFactory.getLogger(GatewayPaymentAdmCtrlServiceImpl.class);
    
    @Value("${pasarela.ws.rbm.wsdl}")
	private String urlEndpoint;
	
	@Value("${pasarela.ws.rbm.tipoTerminal}")
	private String tipoTerminal;
    
    private CompraElectronicaHTTPService compraElectronicaHTTPService;
    
	@Override
	public ModRevRBMPaymentOutDTO modRevRBMPayment(ModRevRBMPaymentInDTO inDTO, String username, String pass) {
		TipoSolicitudCompra inDTOClient = null;
		TipoRespuesta outDTOClient = null;
		try {
			compraElectronicaHTTPService = new CompraElectronicaHTTPService(new URL(urlEndpoint));
				HeaderHandlerResolver headerHandlerResolver = new HeaderHandlerResolver(username,pass); 
			compraElectronicaHTTPService.setHandlerResolver(headerHandlerResolver);
			
			inDTOClient = PaymentsObjectsConverter.convertModRevRBMPaymentInDTOToRevRBMPaymentModRqType(inDTO);
			TipoCabeceraSolicitud tipoCabeceraSolicitud = new TipoCabeceraSolicitud();
			TipoInfoPuntoInteraccion tipoInfoPuntoInteraccion = new TipoInfoPuntoInteraccion();
			tipoInfoPuntoInteraccion.setTipoTerminal(tipoTerminal);
			tipoInfoPuntoInteraccion.setIdAdquiriente(inDTO.getReferenceList().get(0));
			tipoInfoPuntoInteraccion.setIdTerminal(inDTO.getReferenceList().get(1));
			tipoInfoPuntoInteraccion.setIdTransaccionTerminal(Long.parseLong(Util.cortaDerechaTexto(inDTO.getPmtId(), CoreConstants.PMTID_LIMIT)));
			
			tipoInfoPuntoInteraccion.setModoCapturaPAN(TipoModoCapturaPAN.MANUAL);
			tipoInfoPuntoInteraccion.setCapacidadPIN(TipoCapacidadPIN.VIRTUAL);
			
			tipoCabeceraSolicitud.setInfoPuntoInteraccion(tipoInfoPuntoInteraccion);
			inDTOClient.setCabeceraSolicitud(tipoCabeceraSolicitud);
			LOGGER.info("Iniciando reverso cliente RBM: \n{}", inDTOClient);
			outDTOClient = compraElectronicaHTTPService.getCompraElectronicaHTTPPort().compraReversar(inDTOClient);
			LOGGER.info("Resultado reverso cliente RBM: \n{}", outDTOClient);
			PaymentsObjectsConverter.mapHomologationCodeRBM(outDTOClient);
			LOGGER.info("Homologación de respuestas cliente RBM: \n{}", outDTOClient);
			
		} catch (MalformedURLException e) {
			LOGGER.error("Can not initialize wsdl", urlEndpoint);
	    }
		return PaymentsObjectsConverter.convertRevRBMPaymentModRsTypeToModRevRBMPaymentOutDTO(outDTOClient);
	}

}
