
package co.com.ath.pgw.client.ach;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;

import co.com.ath.pgw.client.ach.dto.TransactionPaymentInp;


/**
 * <p>Clase Java para anonymous complex type.
 * 
 * <p>El siguiente fragmento de esquema especifica el contenido que se espera que haya en esta clase.
 * 
 * <pre>
 * &lt;complexType>
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="transactionPaymentInp" type="{http://com/ath/service/payments/pseservices}TransactionPaymentInp"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "", propOrder = {
    "transactionPaymentInp"
})
@XmlRootElement(name = "createTransactionPayment")
public class CreateTransactionPayment {

    @XmlElement(required = true)
    protected TransactionPaymentInp transactionPaymentInp;

    /**
     * Obtiene el valor de la propiedad transactionPaymentInp.
     * 
     * @return
     *     possible object is
     *     {@link TransactionPaymentInp }
     *     
     */
    public TransactionPaymentInp getTransactionPaymentInp() {
        return transactionPaymentInp;
    }

    /**
     * Define el valor de la propiedad transactionPaymentInp.
     * 
     * @param value
     *     allowed object is
     *     {@link TransactionPaymentInp }
     *     
     */
    public void setTransactionPaymentInp(TransactionPaymentInp value) {
        this.transactionPaymentInp = value;
    }

}
