package co.com.ath.pgw.client.ach;

import java.net.MalformedURLException;
import java.net.URL;
import java.util.Map;

import javax.net.ssl.HostnameVerifier;
import javax.net.ssl.HttpsURLConnection;
import javax.net.ssl.SSLSession;
import javax.xml.ws.BindingProvider;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import co.com.ath.pgw.util.client.WebServiceClientUtil;
import co.com.ath.pgw.util.client.XTrustProvider;

/**
 * Implementación del cliente del servicio ACHBridgeService
 * @author proveedor_cjmurillo
 * @version 1.0
 * @since 1.0
 */
public class ACHBridgeImplClient {

	static Logger LOGGER = LoggerFactory.getLogger(ACHBridgeImplClient.class);
	
	/** Verifica e indica que el nombre del host es valido */
	static {
	    HttpsURLConnection.setDefaultHostnameVerifier(new HostnameVerifier(){
			@Override
			public boolean verify(String hostname, SSLSession arg1) {
				/*
                if (hostname.equals("localhost")){
                	return true;
                }
                return false;
                */
				return true;
			}
        });
	}
	
	/** EndPoint donde se encuentra el servicio */
    private String urlEndPoint;
    
    /** Objeto que consume el servicio */
    private Bridge client;
    
    /** Objeto que consume el servicio */
    private BridgePci clientPci;
    
    /** Constructor que recibe la url del EndPoint a consumir */
    public ACHBridgeImplClient(String urlEndPoint, int timeOut) {
    	LOGGER.info("Iniciando cliente para EndPoint-> {}", urlEndPoint);
    	this.urlEndPoint = urlEndPoint;
        try {
			init(timeOut,false);
		} catch (MalformedURLException e) {
			LOGGER.error("No se pudo inicializar el EndPoint \n{}", e);
		} catch (RuntimeException runtimeException) {
			LOGGER.error("Error inicializando cliente ACHBridgeImplClient \n{}", runtimeException);
			throw runtimeException;
		}
    }
    
    /** Constructor que recibe la url del EndPoint a consumir */
    public ACHBridgeImplClient(String urlEndPoint, int timeOut, boolean opt) {
    	LOGGER.info("Iniciando cliente para EndPoint-> {}", urlEndPoint);
    	this.urlEndPoint = urlEndPoint;
        try {
			init(timeOut, opt);
		} catch (MalformedURLException e) {
			LOGGER.error("No se pudo inicializar el EndPoint \n{}", e);
		} catch (RuntimeException runtimeException) {
			LOGGER.error("Error inicializando cliente ACHBridgeImplClient \n{}", runtimeException);
			throw runtimeException;
		}
    }

    /**
     * Inicia el contexto del cliente
     */
    private void init(int timeOut, boolean opt) throws MalformedURLException {
    	
    	XTrustProvider.install();
    	ACHBridgeService service = new ACHBridgeService(new URL(this.urlEndPoint));
    	
    	/*Prueba TimeOut*/
   	
    	int connectionTimeOutInMs = timeOut;
    	if(!opt) {
    		this.client = service.getACHBridgePport();
    		Map<String, Object> context = ((BindingProvider)this.client).getRequestContext();
    		context.put("com.sun.xml.internal.ws.connect.timeout", connectionTimeOutInMs);
    		context.put("com.sun.xml.internal.ws.request.timeout", connectionTimeOutInMs);
    		context.put("com.sun.xml.ws.request.timeout", connectionTimeOutInMs);
    		context.put("com.sun.xml.ws.connect.timeout", connectionTimeOutInMs);
    		WebServiceClientUtil.attachEndPointToClient((BindingProvider) this.client, this.urlEndPoint);
    	}else {
    		this.clientPci = service.getACHBridgePportPci();
    		Map<String, Object> context = ((BindingProvider)this.clientPci).getRequestContext();
    		context.put("com.sun.xml.internal.ws.connect.timeout", connectionTimeOutInMs);
    		context.put("com.sun.xml.internal.ws.request.timeout", connectionTimeOutInMs);
    		context.put("com.sun.xml.ws.request.timeout", connectionTimeOutInMs);
    		context.put("com.sun.xml.ws.connect.timeout", connectionTimeOutInMs);
    		WebServiceClientUtil.attachEndPointToClient((BindingProvider) this.clientPci, this.urlEndPoint);
    	}
        
        LOGGER.info("Cliente iniciado... ");
    }
    
	/**
	 * @return the urlEndPoint
	 */
	public String getUrlEndPoint() {
		return urlEndPoint;
	}

	/**
	 * @return the client
	 */
	public Bridge getClient() {
		return client;
	}
	
	/**
	 * @return the client
	 */
	public BridgePci getClientPCI() {
		return clientPci;
	}

}
