package co.com.ath.pgw.client.rbm;
import java.io.IOException;
import java.net.InetAddress;
import java.net.NetworkInterface;
import java.net.SocketException;
import java.net.UnknownHostException;
import java.util.Collections;
import java.util.Iterator;
import java.util.Set;
import javax.xml.namespace.QName;
import javax.xml.soap.SOAPBody;
import javax.xml.soap.SOAPConstants;
import javax.xml.soap.SOAPElement;
import javax.xml.soap.SOAPEnvelope;
import javax.xml.soap.SOAPException;
import javax.xml.soap.SOAPHeader;
import javax.xml.soap.SOAPHeaderElement;
import javax.xml.soap.SOAPMessage;
import javax.xml.ws.handler.MessageContext;
import javax.xml.ws.handler.soap.SOAPHandler;
import javax.xml.ws.handler.soap.SOAPMessageContext;


/**
 * 
 * @author Jesus Octavio Avendaño <jesus.avendano@sophossolutions.com> 
 * @version 1.0 17/06/2020
 * @since 1.0 * 
 *
 */

public class HandlerChain implements SOAPHandler<SOAPMessageContext>{
    @Override
    public void close(MessageContext context) { 
    }

    @Override
    public boolean handleMessage(SOAPMessageContext context) {
        //Don't intercept outbound messages (SOAP Requests)
        if ((Boolean)context.get(MessageContext.MESSAGE_OUTBOUND_PROPERTY)) {return true;}

        SOAPMessage message = context.getMessage();
        try {
            SOAPBody body = message.getSOAPBody();
            Iterator<SOAPElement> bodyIterator = body.getChildElements();
            SOAPElement responseElement = bodyIterator.next();
            responseElement.setElementQName(new QName("http://www.theserver.com/cmdb_rel_ci", "cmdb"));
        } catch (Exception e) {e.printStackTrace();}
        return true;
    }

    @Override
    public boolean handleFault(SOAPMessageContext context) {
        return false;
    }

    @Override
    public Set<QName> getHeaders() {
        return Collections.emptySet();
    }}