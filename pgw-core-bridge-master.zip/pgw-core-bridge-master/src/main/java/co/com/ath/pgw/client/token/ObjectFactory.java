
package co.com.ath.pgw.client.token;

import javax.xml.bind.JAXBElement;
import javax.xml.bind.annotation.XmlElementDecl;
import javax.xml.bind.annotation.XmlRegistry;
import javax.xml.datatype.XMLGregorianCalendar;
import javax.xml.namespace.QName;

import co.com.ath.pgw.client.tokenize.dto.TokenizedDataRqType;
import co.com.ath.pgw.client.tokenize.dto.TokenizedDataRsType;
import co.com.ath.pgw.client.tokenize.model.AdditionalStatusType;
import co.com.ath.pgw.client.tokenize.model.AuthExtType;
import co.com.ath.pgw.client.tokenize.model.AuthType;
import co.com.ath.pgw.client.tokenize.model.BankInfoType;
import co.com.ath.pgw.client.tokenize.model.CustIdType;
import co.com.ath.pgw.client.tokenize.model.ProtectExtType;
import co.com.ath.pgw.client.tokenize.model.ProtectType;
import co.com.ath.pgw.client.tokenize.model.SeverityType;
import co.com.ath.pgw.client.tokenize.model.StatusType;
import co.com.ath.pgw.client.tokenize.model.SvcRqType;
import co.com.ath.pgw.client.tokenize.model.SvcRsType;
import co.com.ath.pgw.client.tokenize.model.TokenizedDataInfoRqType;
import co.com.ath.pgw.client.tokenize.model.TokenizedDataInfoRsType;
import co.com.ath.pgw.client.tokenize.model.TokenizedDtInfoRqType;
import co.com.ath.pgw.client.tokenize.model.TokenizedDtInfoRsType;
import co.com.ath.pgw.client.tokenize.model.UserIdType;


/**
 * This object contains factory methods for each 
 * Java content interface and Java element interface 
 * generated in the co.com.ath.pgw.client.token package. 
 * <p>An ObjectFactory allows you to programatically 
 * construct new instances of the Java representation 
 * for XML content. The Java representation of XML 
 * content can consist of schema derived interfaces 
 * and classes representing the binding of schema 
 * type definitions, element declarations and model 
 * groups.  Factory methods for each of these are 
 * provided in this class.
 * 
 */
@XmlRegistry
public class ObjectFactory {

    private final static QName _GetTokenizedData_QNAME = new QName("urn://ath.com.co/support/v1/", "getTokenizedData");
    private final static QName _AddTokenizedData_QNAME = new QName("urn://ath.com.co/support/v1/", "addTokenizedData");
    private final static QName _GetTokenizedDataResponse_QNAME = new QName("urn://ath.com.co/support/v1/", "getTokenizedDataResponse");
    private final static QName _AddTokenizedDataResponse_QNAME = new QName("urn://ath.com.co/support/v1/", "addTokenizedDataResponse");
    private final static QName _Channel_QNAME = new QName("urn://ath.com.co/xsd/common/", "Channel");
    private final static QName _ClientDt_QNAME = new QName("urn://ath.com.co/xsd/common/", "ClientDt");
    private final static QName _CustIdNum_QNAME = new QName("urn://ath.com.co/xsd/common/", "CustIdNum");
    private final static QName _CustIdType_QNAME = new QName("urn://ath.com.co/xsd/common/", "CustIdType");
    private final static QName _CustLoginId_QNAME = new QName("urn://ath.com.co/xsd/common/", "CustLoginId");
    private final static QName _BankId_QNAME = new QName("urn://ath.com.co/xsd/common/", "BankId");
    private final static QName _BranchId_QNAME = new QName("urn://ath.com.co/xsd/common/", "BranchId");
    private final static QName _IdSecKey_QNAME = new QName("urn://ath.com.co/xsd/common/", "IdSecKey");
    private final static QName _Data_QNAME = new QName("urn://ath.com.co/xsd/common/", "Data");
    private final static QName _Format_QNAME = new QName("urn://ath.com.co/xsd/common/", "Format");
    private final static QName _StrRefine_QNAME = new QName("urn://ath.com.co/xsd/common/", "StrRefine");
    private final static QName _Method_QNAME = new QName("urn://ath.com.co/xsd/common/", "Method");
    private final static QName _Info_QNAME = new QName("urn://ath.com.co/xsd/common/", "Info");
    private final static QName _IPAddr_QNAME = new QName("urn://ath.com.co/xsd/common/", "IPAddr");
    private final static QName _Name_QNAME = new QName("urn://ath.com.co/xsd/common/", "Name");
    private final static QName _RqUID_QNAME = new QName("urn://ath.com.co/xsd/common/", "RqUID");
    private final static QName _ApprovalId_QNAME = new QName("urn://ath.com.co/xsd/common/", "ApprovalId");
    private final static QName _UserId_QNAME = new QName("urn://ath.com.co/xsd/common/", "UserId");
    private final static QName _BankInfo_QNAME = new QName("urn://ath.com.co/xsd/common/", "BankInfo");
    private final static QName _TokenizedDataInfoRq_QNAME = new QName("urn://ath.com.co/xsd/common/", "TokenizedDataInfoRq");
    private final static QName _Protect_QNAME = new QName("urn://ath.com.co/xsd/common/", "Protect");
    private final static QName _Auth_QNAME = new QName("urn://ath.com.co/xsd/common/", "Auth");
    private final static QName _SvcRs_QNAME = new QName("urn://ath.com.co/xsd/common/", "SvcRs");
    private final static QName _Status_QNAME = new QName("urn://ath.com.co/xsd/common/", "Status");
    private final static QName _StatusCode_QNAME = new QName("urn://ath.com.co/xsd/common/", "StatusCode");
    private final static QName _ServerStatusCode_QNAME = new QName("urn://ath.com.co/xsd/common/", "ServerStatusCode");
    private final static QName _Severity_QNAME = new QName("urn://ath.com.co/xsd/common/", "Severity");
    private final static QName _StatusDesc_QNAME = new QName("urn://ath.com.co/xsd/common/", "StatusDesc");
    private final static QName _ServerStatusDesc_QNAME = new QName("urn://ath.com.co/xsd/common/", "ServerStatusDesc");
    private final static QName _AdditionalStatus_QNAME = new QName("urn://ath.com.co/xsd/common/", "AdditionalStatus");
    private final static QName _TokenizedDataInfoRs_QNAME = new QName("urn://ath.com.co/xsd/common/", "TokenizedDataInfoRs");

    /**
     * Create a new ObjectFactory that can be used to create new instances of schema derived classes for package: co.com.ath.pgw.client.token
     * 
     */
    public ObjectFactory() {
    }

    /**
     * Create an instance of {@link TokenizedDataRqType }
     * 
     */
    public TokenizedDataRqType createTokenizedDataRqType() {
        return new TokenizedDataRqType();
    }

    /**
     * Create an instance of {@link TokenizedDataRsType }
     * 
     */
    public TokenizedDataRsType createTokenizedDataRsType() {
        return new TokenizedDataRsType();
    }

    /**
     * Create an instance of {@link UserIdType }
     * 
     */
    public UserIdType createUserIdType() {
        return new UserIdType();
    }

    /**
     * Create an instance of {@link BankInfoType }
     * 
     */
    public BankInfoType createBankInfoType() {
        return new BankInfoType();
    }

    /**
     * Create an instance of {@link TokenizedDataInfoRqType }
     * 
     */
    public TokenizedDataInfoRqType createTokenizedDataInfoRqType() {
        return new TokenizedDataInfoRqType();
    }

    /**
     * Create an instance of {@link ProtectType }
     * 
     */
    public ProtectType createProtectType() {
        return new ProtectType();
    }

    /**
     * Create an instance of {@link AuthType }
     * 
     */
    public AuthType createAuthType() {
        return new AuthType();
    }

    /**
     * Create an instance of {@link SvcRsType }
     * 
     */
    public SvcRsType createSvcRsType() {
        return new SvcRsType();
    }

    /**
     * Create an instance of {@link StatusType }
     * 
     */
    public StatusType createStatusType() {
        return new StatusType();
    }

    /**
     * Create an instance of {@link AdditionalStatusType }
     * 
     */
    public AdditionalStatusType createAdditionalStatusType() {
        return new AdditionalStatusType();
    }

    /**
     * Create an instance of {@link TokenizedDataInfoRsType }
     * 
     */
    public TokenizedDataInfoRsType createTokenizedDataInfoRsType() {
        return new TokenizedDataInfoRsType();
    }

    /**
     * Create an instance of {@link SvcRqType }
     * 
     */
    public SvcRqType createSvcRqType() {
        return new SvcRqType();
    }

    /**
     * Create an instance of {@link CustIdType }
     * 
     */
    public CustIdType createCustIdType() {
        return new CustIdType();
    }

    /**
     * Create an instance of {@link TokenizedDtInfoRqType }
     * 
     */
    public TokenizedDtInfoRqType createTokenizedDtInfoRqType() {
        return new TokenizedDtInfoRqType();
    }

    /**
     * Create an instance of {@link ProtectExtType }
     * 
     */
    public ProtectExtType createProtectExtType() {
        return new ProtectExtType();
    }

    /**
     * Create an instance of {@link AuthExtType }
     * 
     */
    public AuthExtType createAuthExtType() {
        return new AuthExtType();
    }

    /**
     * Create an instance of {@link TokenizedDtInfoRsType }
     * 
     */
    public TokenizedDtInfoRsType createTokenizedDtInfoRsType() {
        return new TokenizedDtInfoRsType();
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link TokenizedDataRqType }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link TokenizedDataRqType }{@code >}
     */
    @XmlElementDecl(namespace = "urn://ath.com.co/support/v1/", name = "getTokenizedData")
    public JAXBElement<TokenizedDataRqType> createGetTokenizedData(TokenizedDataRqType value) {
        return new JAXBElement<TokenizedDataRqType>(_GetTokenizedData_QNAME, TokenizedDataRqType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link TokenizedDataRqType }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link TokenizedDataRqType }{@code >}
     */
    @XmlElementDecl(namespace = "urn://ath.com.co/support/v1/", name = "addTokenizedData")
    public JAXBElement<TokenizedDataRqType> createAddTokenizedData(TokenizedDataRqType value) {
        return new JAXBElement<TokenizedDataRqType>(_AddTokenizedData_QNAME, TokenizedDataRqType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link TokenizedDataRsType }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link TokenizedDataRsType }{@code >}
     */
    @XmlElementDecl(namespace = "urn://ath.com.co/support/v1/", name = "getTokenizedDataResponse")
    public JAXBElement<TokenizedDataRsType> createGetTokenizedDataResponse(TokenizedDataRsType value) {
        return new JAXBElement<TokenizedDataRsType>(_GetTokenizedDataResponse_QNAME, TokenizedDataRsType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link TokenizedDataRsType }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link TokenizedDataRsType }{@code >}
     */
    @XmlElementDecl(namespace = "urn://ath.com.co/support/v1/", name = "addTokenizedDataResponse")
    public JAXBElement<TokenizedDataRsType> createAddTokenizedDataResponse(TokenizedDataRsType value) {
        return new JAXBElement<TokenizedDataRsType>(_AddTokenizedDataResponse_QNAME, TokenizedDataRsType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link String }{@code >}
     */
    @XmlElementDecl(namespace = "urn://ath.com.co/xsd/common/", name = "Channel")
    public JAXBElement<String> createChannel(String value) {
        return new JAXBElement<String>(_Channel_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link XMLGregorianCalendar }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link XMLGregorianCalendar }{@code >}
     */
    @XmlElementDecl(namespace = "urn://ath.com.co/xsd/common/", name = "ClientDt")
    public JAXBElement<XMLGregorianCalendar> createClientDt(XMLGregorianCalendar value) {
        return new JAXBElement<XMLGregorianCalendar>(_ClientDt_QNAME, XMLGregorianCalendar.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link String }{@code >}
     */
    @XmlElementDecl(namespace = "urn://ath.com.co/xsd/common/", name = "CustIdNum")
    public JAXBElement<String> createCustIdNum(String value) {
        return new JAXBElement<String>(_CustIdNum_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link String }{@code >}
     */
    @XmlElementDecl(namespace = "urn://ath.com.co/xsd/common/", name = "CustIdType")
    public JAXBElement<String> createCustIdType(String value) {
        return new JAXBElement<String>(_CustIdType_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link String }{@code >}
     */
    @XmlElementDecl(namespace = "urn://ath.com.co/xsd/common/", name = "CustLoginId")
    public JAXBElement<String> createCustLoginId(String value) {
        return new JAXBElement<String>(_CustLoginId_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link String }{@code >}
     */
    @XmlElementDecl(namespace = "urn://ath.com.co/xsd/common/", name = "BankId")
    public JAXBElement<String> createBankId(String value) {
        return new JAXBElement<String>(_BankId_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link String }{@code >}
     */
    @XmlElementDecl(namespace = "urn://ath.com.co/xsd/common/", name = "BranchId")
    public JAXBElement<String> createBranchId(String value) {
        return new JAXBElement<String>(_BranchId_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link String }{@code >}
     */
    @XmlElementDecl(namespace = "urn://ath.com.co/xsd/common/", name = "IdSecKey")
    public JAXBElement<String> createIdSecKey(String value) {
        return new JAXBElement<String>(_IdSecKey_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link String }{@code >}
     */
    @XmlElementDecl(namespace = "urn://ath.com.co/xsd/common/", name = "Data")
    public JAXBElement<String> createData(String value) {
        return new JAXBElement<String>(_Data_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link String }{@code >}
     */
    @XmlElementDecl(namespace = "urn://ath.com.co/xsd/common/", name = "Format")
    public JAXBElement<String> createFormat(String value) {
        return new JAXBElement<String>(_Format_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link String }{@code >}
     */
    @XmlElementDecl(namespace = "urn://ath.com.co/xsd/common/", name = "StrRefine")
    public JAXBElement<String> createStrRefine(String value) {
        return new JAXBElement<String>(_StrRefine_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link String }{@code >}
     */
    @XmlElementDecl(namespace = "urn://ath.com.co/xsd/common/", name = "Method")
    public JAXBElement<String> createMethod(String value) {
        return new JAXBElement<String>(_Method_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link String }{@code >}
     */
    @XmlElementDecl(namespace = "urn://ath.com.co/xsd/common/", name = "Info")
    public JAXBElement<String> createInfo(String value) {
        return new JAXBElement<String>(_Info_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link String }{@code >}
     */
    @XmlElementDecl(namespace = "urn://ath.com.co/xsd/common/", name = "IPAddr")
    public JAXBElement<String> createIPAddr(String value) {
        return new JAXBElement<String>(_IPAddr_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link String }{@code >}
     */
    @XmlElementDecl(namespace = "urn://ath.com.co/xsd/common/", name = "Name")
    public JAXBElement<String> createName(String value) {
        return new JAXBElement<String>(_Name_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Long }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link Long }{@code >}
     */
    @XmlElementDecl(namespace = "urn://ath.com.co/xsd/common/", name = "RqUID")
    public JAXBElement<Long> createRqUID(Long value) {
        return new JAXBElement<Long>(_RqUID_QNAME, Long.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link String }{@code >}
     */
    @XmlElementDecl(namespace = "urn://ath.com.co/xsd/common/", name = "ApprovalId")
    public JAXBElement<String> createApprovalId(String value) {
        return new JAXBElement<String>(_ApprovalId_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link UserIdType }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link UserIdType }{@code >}
     */
    @XmlElementDecl(namespace = "urn://ath.com.co/xsd/common/", name = "UserId")
    public JAXBElement<UserIdType> createUserId(UserIdType value) {
        return new JAXBElement<UserIdType>(_UserId_QNAME, UserIdType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link BankInfoType }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link BankInfoType }{@code >}
     */
    @XmlElementDecl(namespace = "urn://ath.com.co/xsd/common/", name = "BankInfo")
    public JAXBElement<BankInfoType> createBankInfo(BankInfoType value) {
        return new JAXBElement<BankInfoType>(_BankInfo_QNAME, BankInfoType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link TokenizedDataInfoRqType }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link TokenizedDataInfoRqType }{@code >}
     */
    @XmlElementDecl(namespace = "urn://ath.com.co/xsd/common/", name = "TokenizedDataInfoRq")
    public JAXBElement<TokenizedDataInfoRqType> createTokenizedDataInfoRq(TokenizedDataInfoRqType value) {
        return new JAXBElement<TokenizedDataInfoRqType>(_TokenizedDataInfoRq_QNAME, TokenizedDataInfoRqType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link ProtectType }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link ProtectType }{@code >}
     */
    @XmlElementDecl(namespace = "urn://ath.com.co/xsd/common/", name = "Protect")
    public JAXBElement<ProtectType> createProtect(ProtectType value) {
        return new JAXBElement<ProtectType>(_Protect_QNAME, ProtectType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link AuthType }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link AuthType }{@code >}
     */
    @XmlElementDecl(namespace = "urn://ath.com.co/xsd/common/", name = "Auth")
    public JAXBElement<AuthType> createAuth(AuthType value) {
        return new JAXBElement<AuthType>(_Auth_QNAME, AuthType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link SvcRsType }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link SvcRsType }{@code >}
     */
    @XmlElementDecl(namespace = "urn://ath.com.co/xsd/common/", name = "SvcRs")
    public JAXBElement<SvcRsType> createSvcRs(SvcRsType value) {
        return new JAXBElement<SvcRsType>(_SvcRs_QNAME, SvcRsType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link StatusType }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link StatusType }{@code >}
     */
    @XmlElementDecl(namespace = "urn://ath.com.co/xsd/common/", name = "Status")
    public JAXBElement<StatusType> createStatus(StatusType value) {
        return new JAXBElement<StatusType>(_Status_QNAME, StatusType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Long }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link Long }{@code >}
     */
    @XmlElementDecl(namespace = "urn://ath.com.co/xsd/common/", name = "StatusCode")
    public JAXBElement<Long> createStatusCode(Long value) {
        return new JAXBElement<Long>(_StatusCode_QNAME, Long.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link String }{@code >}
     */
    @XmlElementDecl(namespace = "urn://ath.com.co/xsd/common/", name = "ServerStatusCode")
    public JAXBElement<String> createServerStatusCode(String value) {
        return new JAXBElement<String>(_ServerStatusCode_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link SeverityType }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link SeverityType }{@code >}
     */
    @XmlElementDecl(namespace = "urn://ath.com.co/xsd/common/", name = "Severity")
    public JAXBElement<SeverityType> createSeverity(SeverityType value) {
        return new JAXBElement<SeverityType>(_Severity_QNAME, SeverityType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link String }{@code >}
     */
    @XmlElementDecl(namespace = "urn://ath.com.co/xsd/common/", name = "StatusDesc")
    public JAXBElement<String> createStatusDesc(String value) {
        return new JAXBElement<String>(_StatusDesc_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link String }{@code >}
     */
    @XmlElementDecl(namespace = "urn://ath.com.co/xsd/common/", name = "ServerStatusDesc")
    public JAXBElement<String> createServerStatusDesc(String value) {
        return new JAXBElement<String>(_ServerStatusDesc_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link AdditionalStatusType }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link AdditionalStatusType }{@code >}
     */
    @XmlElementDecl(namespace = "urn://ath.com.co/xsd/common/", name = "AdditionalStatus")
    public JAXBElement<AdditionalStatusType> createAdditionalStatus(AdditionalStatusType value) {
        return new JAXBElement<AdditionalStatusType>(_AdditionalStatus_QNAME, AdditionalStatusType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link TokenizedDataInfoRsType }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link TokenizedDataInfoRsType }{@code >}
     */
    @XmlElementDecl(namespace = "urn://ath.com.co/xsd/common/", name = "TokenizedDataInfoRs")
    public JAXBElement<TokenizedDataInfoRsType> createTokenizedDataInfoRs(TokenizedDataInfoRsType value) {
        return new JAXBElement<TokenizedDataInfoRsType>(_TokenizedDataInfoRs_QNAME, TokenizedDataInfoRsType.class, null, value);
    }

}
