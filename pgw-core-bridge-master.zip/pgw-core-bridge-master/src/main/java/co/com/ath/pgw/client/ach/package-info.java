@javax.xml.bind.annotation.XmlSchema(namespace = "http://com/ath/service/payments/pseservices")
package co.com.ath.pgw.client.ach;
