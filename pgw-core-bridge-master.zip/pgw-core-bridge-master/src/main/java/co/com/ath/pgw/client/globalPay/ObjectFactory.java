
package co.com.ath.pgw.client.globalPay;

import javax.xml.bind.annotation.XmlRegistry;

import co.com.ath.pgw.client.globalPay.dto.ConsultarEstadoDePagoRespuestaResponse;
import co.com.ath.pgw.client.globalPay.dto.ConsultarEstadoDePagoSolicitudRequest;
import co.com.ath.pgw.client.globalPay.dto.ConsultarEstadoMultiCompraRespuestaResponse;
import co.com.ath.pgw.client.globalPay.dto.ConsultarEstadoMultiCompraSolicitudRequest;
import co.com.ath.pgw.client.globalPay.dto.IniciarTransaccionDeCompraRespuestaResponse;
import co.com.ath.pgw.client.globalPay.dto.IniciarTransaccionDeCompraSolicitudRequest;
import co.com.ath.pgw.client.globalPay.dto.IniciarTransaccionMultiCompraRepuestaResponse;
import co.com.ath.pgw.client.globalPay.dto.IniciarTransaccionMultiCompraSolicitudRequest;


/**
 * This object contains factory methods for each 
 * Java content interface and Java element interface 
 * generated in the co.com.rbm.esb.globalpay package. 
 * <p>An ObjectFactory allows you to programatically 
 * construct new instances of the Java representation 
 * for XML content. The Java representation of XML 
 * content can consist of schema derived interfaces 
 * and classes representing the binding of schema 
 * type definitions, element declarations and model 
 * groups.  Factory methods for each of these are 
 * provided in this class.
 * 
 */
@XmlRegistry
public class ObjectFactory {


    /**
     * Create a new ObjectFactory that can be used to create new instances of schema derived classes for package: co.com.rbm.esb.globalpay
     * 
     */
    public ObjectFactory() {
    }

    /**
     * Create an instance of {@link ConsultarEstadoDePagoRespuestaResponse }
     * 
     */
    public ConsultarEstadoDePagoRespuestaResponse createConsultarEstadoDePagoRespuesta() {
        return new ConsultarEstadoDePagoRespuestaResponse();
    }

    /**
     * Create an instance of {@link ConsultarEstadoDePagoSolicitudRequest }
     * 
     */
    public ConsultarEstadoDePagoSolicitudRequest createConsultarEstadoDePagoSolicitud() {
        return new ConsultarEstadoDePagoSolicitudRequest();
    }

    /**
     * Create an instance of {@link IniciarTransaccionDeCompraRespuestaResponse }
     * 
     */
    public IniciarTransaccionDeCompraRespuestaResponse createIniciarTransaccionDeCompraRespuesta() {
        return new IniciarTransaccionDeCompraRespuestaResponse();
    }

    /**
     * Create an instance of {@link IniciarTransaccionDeCompraSolicitudRequest }
     * 
     */
    public IniciarTransaccionDeCompraSolicitudRequest createIniciarTransaccionDeCompraSolicitud() {
        return new IniciarTransaccionDeCompraSolicitudRequest();
    }

    /**
     * Create an instance of {@link IniciarTransaccionMultiCompraRepuestaResponse }
     * 
     */
    public IniciarTransaccionMultiCompraRepuestaResponse createIniciarTransaccionMultiCompraRepuesta() {
        return new IniciarTransaccionMultiCompraRepuestaResponse();
    }

    /**
     * Create an instance of {@link IniciarTransaccionMultiCompraSolicitudRequest }
     * 
     */
    public IniciarTransaccionMultiCompraSolicitudRequest createIniciarTransaccionMultiCompraSolicitud() {
        return new IniciarTransaccionMultiCompraSolicitudRequest();
    }

    /**
     * Create an instance of {@link ConsultarEstadoMultiCompraSolicitudRequest }
     * 
     */
    public ConsultarEstadoMultiCompraSolicitudRequest createConsultarEstadoMultiCompraSolicitud() {
        return new ConsultarEstadoMultiCompraSolicitudRequest();
    }

    /**
     * Create an instance of {@link ConsultarEstadoMultiCompraRespuestaResponse }
     * 
     */
    public ConsultarEstadoMultiCompraRespuestaResponse createConsultarEstadoMultiCompraRespuesta() {
        return new ConsultarEstadoMultiCompraRespuestaResponse();
    }

}
