
package co.com.ath.pgw.client.ach;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;

import co.com.ath.pgw.client.ach.dto.TransactionInformationOut;


/**
 * <p>Clase Java para anonymous complex type.
 * 
 * <p>El siguiente fragmento de esquema especifica el contenido que se espera que haya en esta clase.
 * 
 * <pre>
 * &lt;complexType>
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="transactionInformationOut" type="{http://com/ath/service/payments/pseservices}TransactionInformationOut"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "", propOrder = {
    "transactionInformationOut"
})
@XmlRootElement(name = "getTransactionInformationResponse")
public class GetTransactionInformationResponse {

    @XmlElement(required = true)
    protected TransactionInformationOut transactionInformationOut;

    /**
     * Obtiene el valor de la propiedad transactionInformationOut.
     * 
     * @return
     *     possible object is
     *     {@link TransactionInformationOut }
     *     
     */
    public TransactionInformationOut getTransactionInformationOut() {
        return transactionInformationOut;
    }

    /**
     * Define el valor de la propiedad transactionInformationOut.
     * 
     * @param value
     *     allowed object is
     *     {@link TransactionInformationOut }
     *     
     */
    public void setTransactionInformationOut(TransactionInformationOut value) {
        this.transactionInformationOut = value;
    }

}
