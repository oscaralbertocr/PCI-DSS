
package co.com.ath.pgw.client.ach;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;

import co.com.ath.pgw.client.ach.dto.TransactionInformationInp;


/**
 * <p>Clase Java para anonymous complex type.
 * 
 * <p>El siguiente fragmento de esquema especifica el contenido que se espera que haya en esta clase.
 * 
 * <pre>
 * &lt;complexType>
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="transactionInformationInp" type="{http://com/ath/service/payments/pseservices}TransactionInformationInp"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "", propOrder = {
    "transactionInformationInp"
})
@XmlRootElement(name = "getTransactionInformation")
public class GetTransactionInformation {

    @XmlElement(required = true)
    protected TransactionInformationInp transactionInformationInp;

    /**
     * Obtiene el valor de la propiedad transactionInformationInp.
     * 
     * @return
     *     possible object is
     *     {@link TransactionInformationInp }
     *     
     */
    public TransactionInformationInp getTransactionInformationInp() {
        return transactionInformationInp;
    }

    /**
     * Define el valor de la propiedad transactionInformationInp.
     * 
     * @param value
     *     allowed object is
     *     {@link TransactionInformationInp }
     *     
     */
    public void setTransactionInformationInp(TransactionInformationInp value) {
        this.transactionInformationInp = value;
    }

}
