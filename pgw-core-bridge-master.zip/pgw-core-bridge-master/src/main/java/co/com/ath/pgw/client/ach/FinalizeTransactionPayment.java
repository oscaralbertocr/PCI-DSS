
package co.com.ath.pgw.client.ach;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;

import co.com.ath.pgw.client.ach.dto.FinalizeTransactionPaymentInp;


/**
 * <p>Clase Java para anonymous complex type.
 * 
 * <p>El siguiente fragmento de esquema especifica el contenido que se espera que haya en esta clase.
 * 
 * <pre>
 * &lt;complexType>
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="finalizeTransactionPaymentInp" type="{http://com/ath/service/payments/pseservices}FinalizeTransactionPaymentInp"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "", propOrder = {
    "finalizeTransactionPaymentInp"
})
@XmlRootElement(name = "finalizeTransactionPayment")
public class FinalizeTransactionPayment {

    @XmlElement(required = true)
    protected FinalizeTransactionPaymentInp finalizeTransactionPaymentInp;

    /**
     * Obtiene el valor de la propiedad finalizeTransactionPaymentInp.
     * 
     * @return
     *     possible object is
     *     {@link FinalizeTransactionPaymentInp }
     *     
     */
    public FinalizeTransactionPaymentInp getFinalizeTransactionPaymentInp() {
        return finalizeTransactionPaymentInp;
    }

    /**
     * Define el valor de la propiedad finalizeTransactionPaymentInp.
     * 
     * @param value
     *     allowed object is
     *     {@link FinalizeTransactionPaymentInp }
     *     
     */
    public void setFinalizeTransactionPaymentInp(FinalizeTransactionPaymentInp value) {
        this.finalizeTransactionPaymentInp = value;
    }

}
