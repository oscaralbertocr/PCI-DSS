
package co.com.ath.pgw.client.ach;

import javax.xml.bind.annotation.XmlRegistry;

import co.com.ath.pgw.client.ach.dto.BankListInp;
import co.com.ath.pgw.client.ach.dto.BankListOut;
import co.com.ath.pgw.client.ach.dto.FinalizeTransactionPaymentInp;
import co.com.ath.pgw.client.ach.dto.FinalizeTransactionPaymentOut;
import co.com.ath.pgw.client.ach.dto.TransactionInformationInp;
import co.com.ath.pgw.client.ach.dto.TransactionInformationOut;
import co.com.ath.pgw.client.ach.dto.TransactionPaymentInp;
import co.com.ath.pgw.client.ach.dto.TransactionPaymentOut;
import co.com.ath.pgw.client.ach.model.BankACHData;


/**
 * This object contains factory methods for each 
 * Java content interface and Java element interface 
 * generated in the pse.core.ws.client.gen package. 
 * <p>An ObjectFactory allows you to programatically 
 * construct new instances of the Java representation 
 * for XML content. The Java representation of XML 
 * content can consist of schema derived interfaces 
 * and classes representing the binding of schema 
 * type definitions, element declarations and model 
 * groups.  Factory methods for each of these are 
 * provided in this class.
 * 
 */
@XmlRegistry
public class ObjectFactory {


    /**
     * Create a new ObjectFactory that can be used to create new instances of schema derived classes for package: pse.core.ws.client.gen
     * 
     */
    public ObjectFactory() {
    }

    /**
     * Create an instance of {@link FinalizeTransactionPayment }
     * 
     */
    public FinalizeTransactionPayment createFinalizeTransactionPayment() {
        return new FinalizeTransactionPayment();
    }

    /**
     * Create an instance of {@link FinalizeTransactionPaymentInp }
     * 
     */
    public FinalizeTransactionPaymentInp createFinalizeTransactionPaymentInp() {
        return new FinalizeTransactionPaymentInp();
    }

    /**
     * Create an instance of {@link CreateTransactionPaymentResponse }
     * 
     */
    public CreateTransactionPaymentResponse createCreateTransactionPaymentResponse() {
        return new CreateTransactionPaymentResponse();
    }

    /**
     * Create an instance of {@link TransactionPaymentOut }
     * 
     */
    public TransactionPaymentOut createTransactionPaymentOut() {
        return new TransactionPaymentOut();
    }

    /**
     * Create an instance of {@link FinalizeTransactionPaymentResponse }
     * 
     */
    public FinalizeTransactionPaymentResponse createFinalizeTransactionPaymentResponse() {
        return new FinalizeTransactionPaymentResponse();
    }

    /**
     * Create an instance of {@link FinalizeTransactionPaymentOut }
     * 
     */
    public FinalizeTransactionPaymentOut createFinalizeTransactionPaymentOut() {
        return new FinalizeTransactionPaymentOut();
    }

    /**
     * Create an instance of {@link GetTransactionInformation }
     * 
     */
    public GetTransactionInformation createGetTransactionInformation() {
        return new GetTransactionInformation();
    }

    /**
     * Create an instance of {@link TransactionInformationInp }
     * 
     */
    public TransactionInformationInp createTransactionInformationInp() {
        return new TransactionInformationInp();
    }

    /**
     * Create an instance of {@link GetBankList }
     * 
     */
    public GetBankList createGetBankList() {
        return new GetBankList();
    }

    /**
     * Create an instance of {@link BankListInp }
     * 
     */
    public BankListInp createBankListInp() {
        return new BankListInp();
    }

    /**
     * Create an instance of {@link GetBankListResponse }
     * 
     */
    public GetBankListResponse createGetBankListResponse() {
        return new GetBankListResponse();
    }

    /**
     * Create an instance of {@link BankListOut }
     * 
     */
    public BankListOut createBankListOut() {
        return new BankListOut();
    }

    /**
     * Create an instance of {@link GetTransactionInformationResponse }
     * 
     */
    public GetTransactionInformationResponse createGetTransactionInformationResponse() {
        return new GetTransactionInformationResponse();
    }

    /**
     * Create an instance of {@link TransactionInformationOut }
     * 
     */
    public TransactionInformationOut createTransactionInformationOut() {
        return new TransactionInformationOut();
    }

    /**
     * Create an instance of {@link CreateTransactionPayment }
     * 
     */
    public CreateTransactionPayment createCreateTransactionPayment() {
        return new CreateTransactionPayment();
    }

    /**
     * Create an instance of {@link TransactionPaymentInp }
     * 
     */
    public TransactionPaymentInp createTransactionPaymentInp() {
        return new TransactionPaymentInp();
    }

    /**
     * Create an instance of {@link BankACHData }
     * 
     */
    public BankACHData createBankACHData() {
        return new BankACHData();
    }

}
