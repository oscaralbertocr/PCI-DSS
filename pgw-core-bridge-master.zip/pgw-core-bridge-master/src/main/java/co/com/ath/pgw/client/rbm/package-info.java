@javax.xml.bind.annotation.XmlSchema(namespace = "http://www.rbm.com.co/esb/", elementFormDefault = javax.xml.bind.annotation.XmlNsForm.QUALIFIED)
package co.com.ath.pgw.client.rbm;
