/*
 * GatewayPaymentClientCtrlService
 *  
 * GSI - Integración
 * Creado el: 9/10/2014
 *
 * Copyright (c) A Toda Hora S.A. Todos los derechos reservados
 * 
 * Este software es confidencial y es propietario de ATH, queda prohibido
 * su uso, reproducción y copia de manera parcial o permanente salvo autorización
 * expresa de A Toda Hora S.A o de quién represente sus derechos.
 */
package co.com.ath.pgw.ws.client.payments;

import co.com.ath.pgw.bsn.dto.in.AddRBMPaymentInDTO;
import co.com.ath.pgw.bsn.dto.out.AddRBMPaymentOutDTO;

/**
 * Interfaz que define el los metodos disponibles para consumir los pagos de 
 * pasarela.
 *
 * @author Andrés Méndez Juanias <proveedor_mamendez@ath.com.co> 
 * @version 1.0 9/10/2014
 * @since 1.0
 */
public interface GatewayPaymentClientCtrlService {
	
	public AddRBMPaymentOutDTO addRBMPayment(AddRBMPaymentInDTO inDTO);

}
