@javax.xml.bind.annotation.XmlSchema(namespace = "urn://grupoaval.com/inquiry/v1/", elementFormDefault = javax.xml.bind.annotation.XmlNsForm.QUALIFIED)
package co.com.ath.pgw.ws.client.bankinfoinquiry.proxy;
