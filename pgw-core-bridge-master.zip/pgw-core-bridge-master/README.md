# pgw-core-bridge
# Ejecucion Release [Core Bridge] - prv_jmrodriguez:CB_1
# Ejecucion Release [Core Bridge] - prv_jmrodriguez:CB_1.1
# Ejecucion Release [Core Bridge] - prv_jmrodriguez:CB_1.2
# Ejecucion Release [Core Bridge] - prv_jmrodriguez:CB_1.3
# Ejecucion Release [Core Bridge] - prv_jmrodriguez:CB_1.4


