# pgw-generateReport
Componente para creación de reportes
