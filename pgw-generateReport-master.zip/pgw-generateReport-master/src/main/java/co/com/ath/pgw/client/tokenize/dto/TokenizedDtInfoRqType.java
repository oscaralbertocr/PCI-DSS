
package co.com.ath.pgw.client.tokenize.dto;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlSeeAlso;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Clase Java para TokenizedDtInfoRq_Type complex type.
 * 
 * <p>El siguiente fragmento de esquema especifica el contenido que se espera que haya en esta clase.
 * 
 * <pre>
 * &lt;complexType name="TokenizedDtInfoRq_Type"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element ref="{urn://ath.com.co/xsd/common/}IdSecKey"/&gt;
 *         &lt;element ref="{urn://ath.com.co/xsd/common/}Protect"/&gt;
 *         &lt;element ref="{urn://ath.com.co/xsd/common/}Auth"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "TokenizedDtInfoRq_Type", propOrder = {
    "idSecKey",
    "protect",
    "auth"
})
@XmlSeeAlso({
    TokenizedDataInfoRqType.class
})
public class TokenizedDtInfoRqType {

    @XmlElement(name = "IdSecKey", required = true, namespace = "urn://ath.com.co/xsd/common/")
    protected String idSecKey;
    @XmlElement(name = "Protect", required = true, namespace = "urn://ath.com.co/xsd/common/")
    protected ProtectType protect;
    @XmlElement(name = "Auth", required = true, namespace = "urn://ath.com.co/xsd/common/")
    protected AuthType auth;

    /**
     * Obtiene el valor de la propiedad idSecKey.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getIdSecKey() {
        return idSecKey;
    }

    /**
     * Define el valor de la propiedad idSecKey.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setIdSecKey(String value) {
        this.idSecKey = value;
    }

    /**
     * Obtiene el valor de la propiedad protect.
     * 
     * @return
     *     possible object is
     *     {@link ProtectType }
     *     
     */
    public ProtectType getProtect() {
        return protect;
    }

    /**
     * Define el valor de la propiedad protect.
     * 
     * @param value
     *     allowed object is
     *     {@link ProtectType }
     *     
     */
    public void setProtect(ProtectType value) {
        this.protect = value;
    }

    /**
     * Obtiene el valor de la propiedad auth.
     * 
     * @return
     *     possible object is
     *     {@link AuthType }
     *     
     */
    public AuthType getAuth() {
        return auth;
    }

    /**
     * Define el valor de la propiedad auth.
     * 
     * @param value
     *     allowed object is
     *     {@link AuthType }
     *     
     */
    public void setAuth(AuthType value) {
        this.auth = value;
    }

}
