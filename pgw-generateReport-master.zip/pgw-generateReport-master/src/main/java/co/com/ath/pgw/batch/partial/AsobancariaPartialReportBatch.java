
/**
 * 
 */
package co.com.ath.pgw.batch.partial;




import java.util.Date;
import java.util.StringTokenizer;

import javax.annotation.PostConstruct;
import javax.annotation.Resource;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.batch.core.Job;
import org.springframework.batch.core.JobExecution;
import org.springframework.batch.core.JobParametersBuilder;
import org.springframework.batch.core.Step;
import org.springframework.batch.core.configuration.annotation.JobBuilderFactory;
import org.springframework.batch.core.configuration.annotation.StepBuilderFactory;
import org.springframework.batch.core.launch.JobLauncher;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.scheduling.concurrent.ThreadPoolTaskScheduler;
import org.springframework.scheduling.support.CronTrigger;
import org.springframework.stereotype.Service;

import co.com.ath.pgw.batch.EncriptPGPTasklet;
import co.com.ath.pgw.batch.GenerateReportTasklet;


/**
 * @author dario.hernandez
 *
 */
@Service
public class AsobancariaPartialReportBatch {
	private static final Logger logger = LoggerFactory.getLogger(AsobancariaPartialReportBatch.class);
	
	/**
	 * constructor del job
	 */
	@Resource
	private JobBuilderFactory jobBuilderFactory;
	/**
	 * constructor del Step
	 */
	@Resource
	private StepBuilderFactory stepBuilderFactory;
	/**
	 * job Launcher
	 */
	@Resource
	private JobLauncher jobLauncher;
	/**
	 * nombre del Job
	 */
	private static final String JOB_NAME = "COMISION_PARTIAL_REPORT_JOB";
	/**
	 * nombre del Step
	 */
	private static final String STEP_NAME = "GENERATE_PARTIAL_REPORT_STEP";
	/**
	 * Variable para el cifrado del reporte
	 */
	private static final String TASKLET_NAME = "ENCRIPT_PGP"; 
	
	
	
	@Value("${report.mediosPagosVAR}")
	private String mediosPagosVAR;

	@Value("${report.obligacionesParcialesVAR}")
	private String obligacionesVAR;
	
	@Value("${report.obligacionParcialNura}")
	private String obligacionNura;
	
	@Value(value = "${pathPartialDownload}")
	private String pathDownload;
	
	@Value(value = "${report.parcialName}")
	private String reportName;	
	
	@Value(value = "${report.ConsolidadoName}")
	private String reportNameConsolidado;	
	
	@Autowired(required=true)
	private EncriptPGPTasklet encriptPGPTasklet;
	
	@Autowired(required=true)
	private GenerateReportTasklet generateReportTasklet;
	/**
	 * ruta local del archivo
	 */
	@Value(value = "${pathLiquidacion}")
	private String pathLiquidacion;
	/**
	 * Ruta local de la contingencia
	 */
	@Value(value = "${pathLiquidacion.contingencia}")
	private String pathContingencia;
	
	/**
	 * Propiedad que indica si el archivo se genera para banco o para unifier
	 * */
	@Value(value = "${report.unifier}")
	private String unifier;
	
	@Value(value = "${pasarela.batch.scheduled.asobancaria.partial.cronArray}")
	private String cronArray;
	
	String horaInicio = "00:00:00.000000000";
	String horaFin = "23:59:59.999999999";	
	
	
	
	/**
	 * Se crean las tareas de ejecucion (CronTrigger) en tiempo de ejecucion,
	 * de acuerdo al numero de parciales configurado en la propiedad
	 * pasarela.batch.scheduled.asobancaria.partial.cronArray
	 */
	@PostConstruct
	public void init() {
		
		Integer i = 0;
		
		cronArray = cronArray.replace("[", "");
		StringTokenizer st = new StringTokenizer(cronArray, "]");
		
		// Se crea la cantidad de tareas configuradas en la propiedad
		while (st.hasMoreElements()) {
			
			i++;
			
			final String parcial = "parcial"+i;
			
			final String jobName;
				jobName = JOB_NAME + i;
			
			// La tarea crea el job que construye el reporte
			Runnable runnable = new Runnable() {
				@Override
				public void run() {
					logger.info("Se inicia ejecucion del job {} ", jobName);
					Job job = createJob(jobName);
					runJob(job, parcial);
				}
			};
			
			String cronValue = st.nextToken();
			logger.info("Se configura job {} asi: {}", jobName, cronValue);
			
			/* Se crea la tarea y se asigna al scheduler */
			CronTrigger cron = new CronTrigger( cronValue );
			ThreadPoolTaskScheduler s = new ThreadPoolTaskScheduler();
	        s.initialize();
	        s.schedule(runnable, cron);
	        s.setThreadNamePrefix(JOB_NAME);

		}
	
		

	}


	public void runJob(Job job, String parcial) {
		
		
		logger.info("Se inicia ejecucion del job :::>> {} ",parcial);
		JobParametersBuilder jobParametersBuilder = this.partialGenerateParameters(job.getName());
		this.executeJob(job, jobParametersBuilder);	
		}
	
	
	/**
	 * Job que se encarga de generar cada uno de los reportes parciales.
	 * @return
	 */
	private Job createJob(String jobName) {
		return jobBuilderFactory.get(jobName)
				.flow(generateReportStep())
				.next(this.encriptPGP())
				.end()
				.build();
	}

	private Step generateReportStep() {
		return stepBuilderFactory.get(STEP_NAME)
				.tasklet(this.generateReportTasklet)
				.build();
	}
	
	private Step encriptPGP() {
		return stepBuilderFactory.get(TASKLET_NAME)
				.tasklet(this.encriptPGPTasklet)
				.build();
	}

/**
 * Ejecuta el Job del batch.
 * @return 
 * 		JobExecution
 **/

private JobExecution executeJob( Job job, JobParametersBuilder jobParams) {

	logger.info("::: executeJob empezando Job para generacion de archivos parciales  :::");
	JobExecution jobExecution;
	try {
		
		jobExecution = this.jobLauncher.run(job, jobParams.toJobParameters());
		
		
	} catch (Exception e) {
		jobExecution = null;
		logger.error("Error ejecutando el job: {}",e);
	}
	return jobExecution;
}


private JobParametersBuilder partialGenerateParameters(String parcial) {
	parcial=parcial.replace(JOB_NAME, "");
	logger.info("::: Generando parametros para reporte parcial ::: Numero ::: {}",parcial);
	JobParametersBuilder jobParametersBuilder = new JobParametersBuilder();
	jobParametersBuilder.addString("filePath", this.pathDownload);
	jobParametersBuilder.addString("fileType", "2");
	jobParametersBuilder.addString("fileId", "3");
	jobParametersBuilder.addString("contingencia", "");
	jobParametersBuilder.addString("unifier", this.unifier);
	jobParametersBuilder.addString("fecha", "");
	jobParametersBuilder.addString("fileDesc", this.obligacionNura);
	jobParametersBuilder.addString("mediosPagosVAR",  this.mediosPagosVAR);
	jobParametersBuilder.addString("obligacionesVAR", this.obligacionesVAR);
	jobParametersBuilder.addString("obligacionNura",  this.obligacionNura);
	jobParametersBuilder.addString("cronArray", this.cronArray);
	jobParametersBuilder.addString("nombreReporte",  this.reportName);
	jobParametersBuilder.addString("nombreReporteConsolidado",  this.reportNameConsolidado);
	jobParametersBuilder.addString("joname",  STEP_NAME);
	jobParametersBuilder.addString("nJob",  parcial);
	jobParametersBuilder.addString("tipoAsobancaria",  "2011");	
	jobParametersBuilder.addDate("date", new Date());
	logger.info("::: Termina Generacion de parametros para reporte parcial ::: Numero ::: {}",parcial);
	return jobParametersBuilder;
}

}