package co.com.ath.pgw.batch;

import java.util.Date;

import javax.annotation.PostConstruct;
import javax.annotation.Resource;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.batch.core.Job;
import org.springframework.batch.core.JobExecution;
import org.springframework.batch.core.JobParametersBuilder;
import org.springframework.batch.core.Step;
import org.springframework.batch.core.configuration.annotation.JobBuilderFactory;
import org.springframework.batch.core.configuration.annotation.StepBuilderFactory;
import org.springframework.batch.core.launch.JobLauncher;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;


@Service
public class ContingenciaAsobancaria {

	private static final Logger logger = LoggerFactory.getLogger(ContingenciaAsobancaria.class);

	/**
	 * constructor del job
	 */
	@Resource
	private JobBuilderFactory jobBuilderFactory;
	/**
	 * constructor del Step
	 */
	@Resource
	private StepBuilderFactory stepBuilderFactory;
	/**
	 * job Launcher
	 */
	@Resource
	private JobLauncher jobLauncher;
	/**
	 * nombre del Job
	 */
	private static final String JOB_NAME = "CONTINGENCIA_ASOBANCARIA_REPORT_JOB";
	/**
	 * nombre del Step
	 */
	private static final String STEP_NAME = "GENERATE_CONTINGENCIA_ASOBANCARIA_REPORT_STEP";
	/**
	 * Variable para el cifrado del reporte
	 */
	private static final String TASKLET_NAME = "ENCRIPT_PGP"; 
	
	
	
	@Value("${report.mediosPagosVAR}")
	private String mediosPagosVAR;

	@Value(value = "${pathAsobancaria.Contingencia}")
	private String pathContingenciaAsobancaria;
	
	@Value("${report.obligacionNura}")
	private String obligacionNura;
	
	@Value("${report.obligacionesVAR}")
	private String obligacionesVAR;
	
	@Value(value = "${report.name}")
	private String reportName;	
	
	@Autowired(required=true)
	private EncriptPGPTasklet encriptPGPTasklet;
	
	@Autowired(required=true)
	private GenerateReportTasklet generateReportTasklet;
	
	String horaInicio = "00:00:00.000000000";
	String horaFin = "23:59:59.999999999";	
		
	/**
	 * instanciamiento del Job
	 */
	private Job jobInstance;
	
	private static final String RECAUDO ="Recaudoobligacion.";
	
	@PostConstruct
	public void init() {
		jobInstance = createJob();
	}
	
	private Job createJob() {
		return jobBuilderFactory.get(JOB_NAME)
				.flow(generateReportStep())
				.next(this.encriptPGP())
				.end()
				.build();
	}

	private Step generateReportStep() {
		return stepBuilderFactory.get(STEP_NAME)
				.tasklet(this.generateReportTasklet)
				.build();
	}
	
	@Transactional(propagation = Propagation.NOT_SUPPORTED)
	public void automaticRun(String fileType , String fileName, String fileDesc) {
		String[] obligaciones = null;
		String[] obligacionesNura = null;
		String[] name = null;
		String nameReport ="";
		String fecha ="";
		String nura = "";
		String comercio= "";
		int positionNura = 0;
		
		try {
			obligaciones = obligacionNura.split(",");
			obligacionesNura = obligacionesVAR.split(",");
			name = reportName.split(",");
			
			for (int j = 0; j < obligaciones.length; j++) {	
				if (obligaciones[j].equals(fileType)) {
					nura = fileType;
					positionNura = j;					
					break;
				}					
			}
			
			comercio = obligacionesNura[positionNura];
			nameReport = name[positionNura];
			fecha=fileName;
			
			logger.info("Reporte de recaudos de contingencia {}", comercio);
			executeJobContingencia(nameReport,fecha,nura,comercio);

			
		} catch (Exception e) {
			logger.error("Error no esperado iniciando la generacion del reporte de recaudos parciales: \n{}", e);
		}	
	}

	private JobExecution executeJobContingencia(String fileType, String fecha, String fileDesc, String spnName) {
		JobExecution jobExecution;
		try {
			logger.info("::: Generando parametros para reporte Asobancaria Contingencia ::: Nura ::: {}",fileDesc);
			JobParametersBuilder jobParametersBuilder = new JobParametersBuilder();
			jobParametersBuilder.addString("filePath", this.pathContingenciaAsobancaria);
			jobParametersBuilder.addString("fileId", "2");
			jobParametersBuilder.addString("contingencia", "1");
			jobParametersBuilder.addString("fecha", fecha);
			jobParametersBuilder.addString("mediosPagosVAR",  this.mediosPagosVAR);
			jobParametersBuilder.addString("obligacionesVAR", spnName);
			jobParametersBuilder.addString("obligacionNura",  fileDesc);
			jobParametersBuilder.addString("nombreReporte",  fileType);
			jobParametersBuilder.addString("fileNameIn", RECAUDO+fecha.replace("/", "")+".TXT");
			jobParametersBuilder.addString("unifier", "1");
			jobParametersBuilder.addString("joname",  STEP_NAME);
			jobParametersBuilder.addDate("date", new Date());
			logger.info("::: Termina Generacion de parametros para Asobancaria Contingencia ::: Nura ::: {}",fileDesc);

			jobExecution = jobLauncher.run(jobInstance, jobParametersBuilder.toJobParameters());
			
		} catch (Exception ex) {
			jobExecution = null;
			logger.error("Error ejecutando :\n{}", ex);
		}
		return jobExecution;
	}
	
	/**
	 * Genera el reporte cifrado.
	 * 
	 * @return 
	 * 		Step
	 **/
	private Step encriptPGP() {
		return stepBuilderFactory.get(TASKLET_NAME)
				.tasklet(this.encriptPGPTasklet)
				.build();
	}
	

}
