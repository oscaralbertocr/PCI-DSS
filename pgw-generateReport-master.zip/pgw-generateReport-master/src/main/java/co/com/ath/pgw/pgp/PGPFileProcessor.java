package co.com.ath.pgw.pgp;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;

import org.bouncycastle.openpgp.PGPPublicKey;
import org.bouncycastle.openpgp.PGPSecretKey;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import co.com.ath.pgw.util.Constants;
import co.com.ath.pgw.util.PGPUtils;
 
/**
 * Encripta o desencripta un archivo en formato PGP. 
 *
 *
 * @author Jesus Octavio Avendaño Sierra <jesus.avendano@sophossolutions.com> 
 * @version 1.0 16/15/2019
 * 
 * @sophosSolutions
 * <strong>Autor: </strong>Jesus Octavio Avendaño Sierra</br>
 * <strong>Numero de Cambios: </strong>0</br>
 * 	
*/ 
public class PGPFileProcessor {
 
    private static final Logger logger = LoggerFactory.getLogger(PGPFileProcessor.class);
	
    private String passphrase;
    private String publicKeyFileName;
    private String secretKeyFileName;
    private String inputFileName;
    private String outputFileName;
    private boolean asciiArmored = false;
    private boolean integrityCheck = true;
 
    /**
	 * Encrypta el archivo. Retorna true si el encriptado es correcto, false en otro caso 
	 * @return boolean
	*/
    public boolean encrypt() throws IOException {
    	try {

    		logger.info(Constants.LOG_HEADER);
    		logger.info("	LEYENDO EL ARCHIVO: {}", this.inputFileName);
    		logger.info("	USANDO LLAVE PUBLICA: {}", this.publicKeyFileName);
    		FileInputStream keyIn = new FileInputStream(this.publicKeyFileName);
    		logger.info("	GENERANDO ARCHIVO ENCRIPTADO: {}", this.outputFileName);
            FileOutputStream out = new FileOutputStream(this.outputFileName);
            PGPUtils.encryptFile(out, this.inputFileName, PGPUtils.readPublicKey(keyIn), this.asciiArmored, this.integrityCheck);
            logger.info("	TERMINANDO PROCESO DE ENCRIPTADO");
            out.close();
            keyIn.close();
            logger.info(Constants.LOG_HEADER);
            return true;
		} catch (Exception e) {
			logger.info("	ERROR EN EL PROCESO DE ENCRIPTADO");
			logger.info("	TERMINANDO PROCESO");
			logger.error("  ERROR: {}",e);
			logger.info(Constants.LOG_HEADER);			
			return false;
		}
    }
 
    public boolean signEncrypt() throws Exception {
        FileOutputStream out = new FileOutputStream(this.outputFileName);
        FileInputStream publicKeyIn = new FileInputStream(this.publicKeyFileName);
        FileInputStream secretKeyIn = new FileInputStream(this.secretKeyFileName);
 
        PGPPublicKey publicKey = PGPUtils.readPublicKey(publicKeyIn);
        PGPSecretKey secretKey = PGPUtils.readSecretKey(secretKeyIn);
 
        PGPUtils.signEncryptFile(
                out,
                this.getInputFileName(),
                publicKey,
                secretKey,
                this.getPassphrase(),
                this.isAsciiArmored(),
                this.isIntegrityCheck() );
 
        out.close();
        publicKeyIn.close();
        secretKeyIn.close();
 
        return true;
    }
 
    
    /**
	 * Desencrita el archivo. Retorna true si el desencriptado es correcto, false en otro caso 
	 * @return boolean
	*/
    public boolean decrypt() throws Exception {
    	try {    		
    		logger.info(Constants.LOG_HEADER);
    		logger.info("	LEYENDO EL ARCHIVO: {}", this.inputFileName);
    		logger.info("	USANDO LLAVE SECRETA: {}", this.secretKeyFileName);
            FileInputStream in = new FileInputStream(this.inputFileName);
            logger.info("	GENERANDO ARCHIVO DESENCRIPTADO: {}", this.outputFileName);
            FileInputStream keyIn = new FileInputStream(this.secretKeyFileName);
            FileOutputStream out = new FileOutputStream(this.outputFileName);
            PGPUtils.decryptFile(in, out, keyIn, this.passphrase.toCharArray());
            logger.info("	TERMINANDO PROCESO DE ENCRIPTADO");
            in.close();
            out.close();
            keyIn.close();
            logger.info(Constants.LOG_HEADER);
            return true;
		} catch (Exception e) {
			logger.info("	ERROR EN EL PROCESO DE DESENCRIPTADO");
			logger.info("	TERMINANDO PROCESO");
			logger.info("*******************************************************************");
			return false;
		}
    }
 
    public boolean isAsciiArmored() {
            return this.asciiArmored;
    }
 
    public void setAsciiArmored(boolean asciiArmored) {
            this.asciiArmored = asciiArmored;
    }
 
    public boolean isIntegrityCheck() {
            return this.integrityCheck;
    }
 
    public void setIntegrityCheck(boolean integrityCheck) {
            this.integrityCheck = integrityCheck;
    }
 
    public String getPassphrase() {
            return this.passphrase;
    }
 
    public void setPassphrase(String passphrase) {
            this.passphrase = passphrase;
    }
 
    public String getPublicKeyFileName() {
            return this.publicKeyFileName;
    }
 
    public void setPublicKeyFileName(String publicKeyFileName) {
            this.publicKeyFileName = publicKeyFileName;
    }
 
    public String getSecretKeyFileName() {
            return this.secretKeyFileName;
    }
 
    public void setSecretKeyFileName(String secretKeyFileName) {
            this.secretKeyFileName = secretKeyFileName;
    }
 
    public String getInputFileName() {
            return this.inputFileName;
    }
 
    public void setInputFileName(String inputFileName) {
            this.inputFileName = inputFileName;
    }
 
    public String getOutputFileName() {
            return this.outputFileName;
    }
 
    public void setOutputFileName(String outputFileName) {
            this.outputFileName = outputFileName;
    }
 
}