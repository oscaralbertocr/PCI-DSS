/**
 * TokenizeDataService
 *  
 * GSI - Core Pasarela
 * Creado el: 09/08/2017
 *
 * Copyright (c) A Toda Hora S.A. Todos los derechos reservados
 * 
 * Este software es confidencial y es propiedad de ATH, queda prohibido
 * su uso, reproducción y copia de manera parcial o permanente salvo autorización
 * expresa de A Toda Hora S.A o de quién represente sus derechos.
 */
package co.com.ath.pgw.client.tokenize.impl;

import co.com.ath.pgw.dto.TokenizeInDTO;
import co.com.ath.pgw.dto.TokenizeOutDTO;

/**
 * 
 * @author proveedor_lbonilla
 * @version 1.0
 * 
 */
public interface TokenizeDataService {
	
	/**
	 * Metodo que recibe un dato tokenizado u ofuscado, para retornar el dato en claro original
	 * 
	 * @param tokenizeInDTO
	 * @return
	 * @since 1.0
	 */
	TokenizeOutDTO getTokenize(TokenizeInDTO tokenizeInDTO) throws Exception;

}
