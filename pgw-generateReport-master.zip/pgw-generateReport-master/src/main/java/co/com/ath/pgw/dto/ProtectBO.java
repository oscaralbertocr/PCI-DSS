package co.com.ath.pgw.dto;

/**
 * 
 * @author proveedor_lbonilla
 * @version 1.0
 */
public class ProtectBO {
	
	/**
	 * 
	 */
	private String data;
	
	/**
	 * 
	 */
	private String format;
	
	/**
	 * 
	 */
	private String strRefine;
	
	
	public String getData() {
		return data;
	}
	public void setData(String data) {
		this.data = data;
	}
	public String getFormat() {
		return format;
	}
	public void setFormat(String format) {
		this.format = format;
	}
	public String getStrRefine() {
		return strRefine;
	}
	public void setStrRefine(String strRefine) {
		this.strRefine = strRefine;
	}

}
