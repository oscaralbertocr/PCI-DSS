package co.com.ath.pgw.dto;

/**
 * DTO Fileline
 *
 * @author Jesus Octavio Avendaño Sierra <jesus.avendano@sophossolutions.com> 
 * @version 1.0 16/15/2019
 * 
 * @sophosSolutions
 * <strong>Autor: </strong>Jesus Octavio Avendaño Sierra</br>
 * <strong>Numero de Cambios: </strong>0</br>
 * 	
*/

public class FileLine {
	
	private String firstChar;
	
    private String beforeToken;
    
    private String token;
    
    private String afterToken;
    

    public FileLine() {
    }

    public FileLine(String firstChar, String beforeToken, 
    					String token, String afterToken) {
    	this.firstChar = firstChar;
        this.beforeToken = beforeToken;
        this.token = token;
        this.afterToken = afterToken;
    }
    
    
    /**
    *
    *@return String que representa el primer caracter de la linea
    */
    public String getFirstChar() {
    	return firstChar;
    }
    
    /**
    *	@param firstChar
    *				Establese el primer caracter de la linea
    *
    */
    public void setFirstChar(String firstChar) {
    	this.firstChar = firstChar;
    }
    
    /**
    *
    *@return String que representa el texto encontrado antes del token
    */
    public String getBeforeToken() {
    	return beforeToken;
    }

    /**
     *	@param beforeToken
     *				Establese el texto antes del token 
     *
     */
    public void setBeforeToken(String beforeToken) {
        this.beforeToken = beforeToken;
    }
    /**
    *
    *@return String que representa el token
    */
    public String gettoken() {
    	return token;
    }

    /**
     *	@param token
     *				Establese el token
     *
     */
    public void setToken(String token) {
        this.token = token;
    }
    /**
    *
    *@return String que representa el texto encontrado despues del token
    */
    public String getAfterToken() {
    	return afterToken;
    }

    /**
     *	@param afterToken
     *				Establese el texto despues del token
     *
     */
    public void setAfterToken(String afterToken) {
        this.afterToken = afterToken;
    }

    @Override
    public String toString() {
        return "Primer caracter: " + this.firstChar + ", Token: " + this.token;
    }
}
