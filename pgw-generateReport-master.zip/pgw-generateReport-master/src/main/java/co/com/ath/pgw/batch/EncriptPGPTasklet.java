package co.com.ath.pgw.batch;

import java.io.File;
import java.util.HashMap;

import javax.annotation.Resource;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.batch.core.StepContribution;
import org.springframework.batch.core.configuration.annotation.StepScope;
import org.springframework.batch.core.scope.context.ChunkContext;
import org.springframework.batch.core.step.tasklet.Tasklet;
import org.springframework.batch.repeat.RepeatStatus;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import co.com.ath.pgw.pgp.PGPFileProcessor;
import co.com.ath.pgw.util.AesCifer;
import co.com.ath.pgw.util.ConectionFTP;
import co.com.ath.pgw.util.Parametro;
import co.com.ath.pgw.util.Utils;

/**
 * Tasklet para realizar el PGP
 * @author SophosSolutions
 * @version 1.0
 */
@Service
@StepScope
public class EncriptPGPTasklet implements Tasklet {
	
	private static final Logger logger = LoggerFactory.getLogger(EncriptPGPTasklet.class);

//	@Value(value = "${pathCreateDetokenizateFile}")
	private String pathCreateDetokenizateFile;

//	@Value(value = "${pathOutCommissionPgp}")
	private String pathOutCommissionPgp;

//	@Value(value = "${pathOutCollectionPgp}")
	private String pathOutCollectionPgp;
	
	@Value("#{jobParameters[obligacionNura]}")
	private String obligacionNura;
	
	@Value(value = "${pathKeyPublicPgp}")
	private String pathKeyPublicPgp;
	
	@Value(value = "${pathKeyPublicPgpAsobancaria}")
	private String pathKeyPublicPgpAsobancaria;
	
	@Value(value = "${pathKeyPublicPgpAsobancariaparcial}")
	private String pathKeyPublicPgpAsobancariaparcial;

	@Value(value = "${pathKeyPublicPgpBIPXC}")
	private String pathKeyPublicPgpBIPXC;
	
	
	@Value(value = "${pathCommissionFTP}")
	private String pathCommissionFTP;
	
	@Value(value = "${pathCollectionFTP}")
	private String pathCollectionFTP;
	
	@Value(value = "${pathPArcialesFTP}")
	private String pathPArcialesFTP;

	@Value(value = "${pathCollectionBIPXC_FTP}")
	private String pathCollectionBIPXC_FTP;
	
	@Value("#{jobParameters[fileNameIn]}")
	private String fileNameIn;

	@Value("#{jobParameters[fileNameOut]}")
	private String fileNameOut;

	@Value("#{jobParameters[fileType]}")
	private String fileType;

	@Value("#{jobParameters[fileId]}")
	private String fileId;
	
	@Value("#{jobParameters[filePath]}")
	private String filePath;

	@Value("#{jobParameters[fileDesc]}")
	private String fileDesc;

	@Value(value = "${stringCompareCommission}")
	private String stringCompareCommission;

	@Value(value = "${stringComparecollection}")
	private String stringComparecollection;

	@Value(value = "${pathCreateDetokenizateReportAsobancaria}")
	private String pathCreateDetokenizateReportAsobancaria;
	
	@Value(value = "${pathPartial.contingencia}")
	private String pathCreateCont;
	
	@Value(value = "${pathReportBIPXC}")
	private String pathReportBIPXC;
	
	
	@Value("#{jobParameters[fileNameLiquidacion]}")
	private String nameLiquidacion;
	
	@Value("#{jobParameters[filePathLiquidacion]}")
	private String pathLiquidacion;
	@Resource
	private Parametro parametro;
	@Autowired
	private AesCifer tripleDes;
	/**
	 * Conexion FTP  
	 */
	@Resource
	private ConectionFTP conectionFTP;// C01
	
//	@Value(value = "${report.zip}")
	private String validZip =""; 

//	@Value(value = "${report.zipName}")
	private String zipName ="";	
	
//	@Value(value = "${report.zipParcial}")
	private String zipParcial ="";
	
    @Value("#{jobParameters[nombreReporte]}")
    private String nombreReporte;  
    
    @Value("#{jobParameters[nombreReporteConsolidado]}")
    private String reportNameConsolidado;
    
    @Value("#{jobParameters[reportDate]}")
    private String reportDate; 	
    
    @Value("#{jobParameters[fecha]}")
    private String reportDateCont;
    
    @Value("#{jobParameters[cronArray]}")
    private String cronArray;
    
    @Value("#{jobParameters[nJob]}")
    private String nJob;
    
    @Value("#{jobParameters[contingencia]}")
	private String contingencia;
    
    @Value("#{jobParameters[fecha]}")
	private String fecha;
    
    @Value("#{jobParameters[cifrado]}")
	private String cifrado;
    
	
	@Value("#{jobParameters[tipoAsobancaria]}")
	private String tipoAsobancaria;
	
	@Value(value = "${pathKeyPublicPgpAsobancariaparcialJFK}")
	private String pathKeyPublicPgpAsobancariaparcialJFK;
		
	@Value("#{jobParameters[llaveBogotaTC]}")
	private String llaveBogotaTC;
	
	@Value("#{jobParameters[llaveBogotaOC]}")
	private String llaveBogotaOC;
	
	@Value("#{jobParameters[fullPathTC]}")
	private String fullPathTC;
	
	@Value("#{jobParameters[fullPathOC]}")
	private String fullPathOC;	
	
	@Value(value = "${pasarela.cifradoRecaudosBogota}")
	private String cifradoBogota;	
	
	@Value(value = "${pasarela.ftpName.tarjeta_credito.bogota.bogota}")
	private String ftpNameTC;
	
//	@Value(value = "${pasarela.ftpName.otros_creditos.bogota.bogota}")
	private String ftpNameOC;	
        
    @Autowired(required = true)
    Utils util;    
	
	/**
	 * Ejecuta El Tasklet
	 * 
	 */
	@Override
	public RepeatStatus execute(StepContribution contribution, ChunkContext chunkContext) throws Exception {
		
		String inputFileName = "";
		String outputFileName = "";
		String keyFile = "";
		StringBuilder fileNamePgp;
		String pathSFTP = "";
		boolean validTypeEncrypt = true;
		String[] zipReports = null;
		String[] obligaciones = null;
		HashMap<String, String> archivos = new HashMap<String, String>();
		
		try {
			logger.info("EncriptPGPTasklet vSP");
			if (fileId.equals("2")) {
				zipReports = validZip.split(",");
				
				if (contingencia.equals("1")) {
					
					String obligacionContingenia = obligacionNura;
					String nameReports = nombreReporte;	
					String obligacion="obligacion";
					String fileReport="";	
					
					for (int j = 0; j < zipReports.length; j++) {	
						if (zipReports[j].equals(obligacionContingenia)) {
							validTypeEncrypt = false;
							break;
						}					
					}
					
					fileReport = util.nameReport(reportDateCont,nameReports,this.filePath,obligacionContingenia, "1");
					logger.info(fileReport);		
					logger.info("encriptando: {}", fileReport);
					inputFileName = fileReport;
					outputFileName = getNameToPgp(fileReport).toString();
					keyFile = this.pathKeyPublicPgpAsobancaria;
					
					File file = new File(inputFileName);
					if(file.exists()) {
						boolean[] valores = encryptReport(this.fileNameIn.replaceAll(obligacion, obligacionContingenia), inputFileName, outputFileName, keyFile, validTypeEncrypt,obligacionContingenia,true, reportDateCont);
						validTypeEncrypt = valores[0];
						if(valores[1]) {
							pathSFTP = this.pathCollectionFTP.concat("/"+obligacionContingenia);
							conectionFTP.conectar(outputFileName, pathSFTP);
						}
					}
					
					
				}
				else {
					String[] nameReports = null;
					obligaciones = obligacionNura.split(",");
					nameReports = nombreReporte.split(",");	
					String obligacion="obligacion";
					String fileReport="";	
									
					for(int i=0; i< obligaciones.length; i++) {
						for (int j = 0; j < zipReports.length; j++) {	
							if (obligaciones[i].equals(zipReports[j])) {
								validTypeEncrypt = false;
								break;
							}					
						}
						if(this.fileId.equals("2")) {
							fileReport = util.nameReport(reportDate,nameReports[i],this.pathCreateDetokenizateReportAsobancaria,obligaciones[i], "0");
							logger.info(fileReport);		
							logger.info("encriptando: {}", fileReport);
							inputFileName = fileReport;
							outputFileName = getNameToPgp(fileReport).toString();
							keyFile = this.pathKeyPublicPgpAsobancaria;
						}else {
							inputFileName = this.pathCreateDetokenizateFile.concat("\\" + this.fileNameIn.replace(obligacion, obligaciones[i]));
							if (this.fileType.equals(this.stringCompareCommission)) //Recaudo o Comision
								outputFileName = this.pathOutCommissionPgp.concat("\\" + this.fileNameOut.replace(obligacion, obligaciones[i]));
							else if(this.fileType.equals(this.stringComparecollection))
								outputFileName = this.pathOutCollectionPgp.concat("\\" + this.fileNameOut.replace(obligacion, obligaciones[i]));
							keyFile = this.pathKeyPublicPgp;
						}				
						
						File file = new File(inputFileName);
						if(file.exists()) {
							boolean[] valores = encryptReport(this.fileNameIn.replaceAll(obligacion, obligaciones[i]), inputFileName, outputFileName, keyFile, validTypeEncrypt,obligaciones[i],false,"");
							validTypeEncrypt = valores[0];
							if(valores[1]) {
								pathSFTP = this.pathCollectionFTP.concat("/"+obligaciones[i]);
								//conectionFTP.conectar(outputFileName, pathSFTP);
								if(!archivos.containsKey(outputFileName)) {
									archivos.put(outputFileName, pathSFTP);									
								} 
							}
						}
						
					}
					
										
					conectionFTP.conectar(archivos);
				}
				
			/*
			 * Proceso de encriptado PGP para Parciales Inicio*/
			}else if(fileId.equals("3")){
				String nameReports = null;
				String[] ultimo=null;
				String[] horaorden = null;
				String fechaOrden[] = null;
				String[] initialTime=null;
				obligaciones = obligacionNura.split(",");
				nameReports = nombreReporte;	
				cronArray = "[0 0 0 ? * MON-FRI]"+cronArray;
		        cronArray = cronArray.replace("[", "");
		        cronArray = cronArray.replace("? * MON-FRI", "");
		        ultimo=cronArray.split("]");
		        initialTime=ultimo;
				
				 /**Se obtienen las horas de inicio y fin del reporte -inicio-**/
		        for( int j=0; j< initialTime.length; j++) {
					horaorden=initialTime[j].split(" ");
					for(int f=0; f< horaorden.length; f++) {
						if(horaorden[f].length()==1) {
							horaorden[f]="0"+horaorden[f];	
						}
					 }
					initialTime[j]=horaorden[2]+":"+horaorden[1]+":"+horaorden[0];
		        }
		        /**Se obtienen las horas de inicio y fin del reporte -fin-**/
				
				String nameReportConsolidado = reportNameConsolidado;
				zipReports = zipParcial.split(",");
				String fileReport="";
				int nJobs = ultimo.length;
				Integer pHora= Integer.parseInt(nJob);
								
				for(int i=0; i< obligaciones.length; i++) {
					for (int j = 0; j < zipReports.length; j++) {	
						if (obligaciones[i].equals(zipReports[j])) {
							validTypeEncrypt = false;
							break;
						}					
					}
						
					if(contingencia.contentEquals("1")) {
						
						fechaOrden=fecha.split("/");
	        			String fechaOrdenC=fechaOrden[2]+fechaOrden[1]+fechaOrden[0];
						if(pHora == nJobs-1) {
							
							fileReport = util.nameReporteConsolidado(nameReportConsolidado,this.filePath,obligaciones[i],fechaOrdenC);
							logger.info(fileReport);		
							logger.info("encriptando el consolidado: {}", fileReport);
							inputFileName = fileReport;
							outputFileName = getNameParcialToPgp(fileReport).toString();
							keyFile = tipoAsobancaria.equals("2001") ? this.pathKeyPublicPgpAsobancariaparcialJFK : this.pathKeyPublicPgpAsobancariaparcial;
							
							File file = new File(inputFileName);
							if(file.exists()) {
								boolean[] valores = encryptReport(fileReport, inputFileName, outputFileName, keyFile, validTypeEncrypt,obligaciones[i],false,"");
								validTypeEncrypt = valores[0];
							}
						}else {
							
							fileReport = util.nameReportPartial(nameReports,this.filePath,obligaciones[i],initialTime[pHora],fechaOrdenC);
							logger.info(fileReport);		
							logger.info("encriptando el parcial: {}", fileReport);
							inputFileName = fileReport;
							outputFileName = getNameParcialToPgp(fileReport).toString();
							keyFile = tipoAsobancaria.equals("2001") ? this.pathKeyPublicPgpAsobancariaparcialJFK : this.pathKeyPublicPgpAsobancariaparcial;
							
							File file = new File(inputFileName);
							if(file.exists()) {
								boolean[] valores = encryptReport(fileReport, inputFileName, outputFileName, keyFile, validTypeEncrypt,obligaciones[i],false,"");
								validTypeEncrypt = valores[0];
							}							
						}
						
					}else if(pHora == nJobs-1) {
							
							fileReport = util.nameReporteConsolidado(nameReportConsolidado,this.filePath,obligaciones[i],"");
							logger.info(fileReport);		
							logger.info("encriptando el consolidado: {}", fileReport);
							inputFileName = fileReport;
							outputFileName = getNameParcialToPgp(fileReport).toString();
							keyFile = this.tipoAsobancaria.equals("2001") ? this.pathKeyPublicPgpAsobancariaparcialJFK : this.pathKeyPublicPgpAsobancariaparcial;
							File file = new File(inputFileName);
							if(file.exists()) {
								boolean[] valores = encryptReport(fileReport, inputFileName, outputFileName, keyFile, validTypeEncrypt,obligaciones[i],false,"");
								validTypeEncrypt = valores[0];
								if(valores[1]) {
									pathSFTP = this.pathCollectionFTP.concat("/"+obligaciones[i]);
									conectionFTP.conectar(outputFileName, pathSFTP);
								}
							}
							
						}else {
							
							fileReport = util.nameReportPartial(nameReports,this.filePath,obligaciones[i],initialTime[pHora],"");
							logger.info(fileReport);		
							logger.info("encriptando el parcial: {}", fileReport);
							inputFileName = fileReport;
							outputFileName = getNameParcialToPgp(fileReport).toString();
							keyFile = this.tipoAsobancaria.equals("2001") ? this.pathKeyPublicPgpAsobancariaparcialJFK : this.pathKeyPublicPgpAsobancariaparcial;
							File file = new File(inputFileName);
							if(file.exists()) {
								boolean[] valores = encryptReport(fileReport, inputFileName, outputFileName, keyFile, validTypeEncrypt,obligaciones[i],false,"");
								validTypeEncrypt = valores[0];
								if(valores[1]) {
									pathSFTP = this.pathPArcialesFTP.concat("/"+obligaciones[i]);
									conectionFTP.conectar(outputFileName, pathSFTP);
								}
							}	
							
						}
						
				}
				
			}else if(fileId.equals("5")){
				logger.info("encriptando: {}",fullPathTC);	
				encryptReport(fullPathTC, fullPathTC, fullPathTC+cifradoBogota, llaveBogotaTC, true, "", false, "");
//				logger.info("encriptando: {}",fullPathOC);	
//				encryptReport(fullPathOC, fullPathOC, fullPathOC+cifradoBogota, llaveBogotaOC, true,"");	
				
				pathSFTP = this.pathCollectionFTP.concat("/"+ftpNameTC);
				conectionFTP.conectar(fullPathTC+cifradoBogota, pathSFTP);
				
//				pathSFTP = this.pathCollectionFTP.concat("/"+ftpNameOC);
//				conectionFTP.conectar(fullPathOC+cifradoBogota, pathSFTP);
				
			}
			else {
				fileNamePgp = getNameToPgp(this.nameLiquidacion);
				
				inputFileName = this.pathLiquidacion.concat("\\"+this.nameLiquidacion);
				outputFileName = this.pathLiquidacion.concat("\\"+fileNamePgp);
				keyFile = this.pathKeyPublicPgp;
				File file = new File(inputFileName);
				if(file.exists()) {
					boolean[] valores = encryptReport(fileNamePgp.toString(), inputFileName, outputFileName, keyFile, validTypeEncrypt,"",false,"");
					validTypeEncrypt = valores[0];
					if(valores[1]) {
						pathSFTP = this.pathCommissionFTP;
						conectionFTP.conectar(outputFileName, pathSFTP);
					}
				}	
				
				
			}
		}catch (Exception e) {
			logger.error("Error al tratar de enviar los parametros para cifrar el reporte : {}",  e);
		}finally {
			fileNamePgp = null;
			inputFileName = "";
			outputFileName = "";
			keyFile = "";
		}

		return RepeatStatus.FINISHED;
	}
	
	/**
	 * Metodo que cifra el reporte en pgp
	 * @param nameReport
	 * @param inputFileName
	 * @param outputFileName
	 * @param keyFile
	 * @param validTypeEncrypt 
	 * @param obligacion 
	 */
	private boolean[] encryptReport(String nameReport, String inputFileName, String outputFileName, String keyFile, boolean validTypeEncrypt, String obligacion, boolean contingencia, String fecha) {
		PGPFileProcessor pgpFileProcessor = new PGPFileProcessor();		
		boolean result = true;
		try {
			if (validTypeEncrypt) {
				pgpFileProcessor.setInputFileName(inputFileName);
				pgpFileProcessor.setOutputFileName(outputFileName);
				pgpFileProcessor.setPublicKeyFileName(keyFile);			
				
				if(pgpFileProcessor.encrypt()) {
					logger.info("Se encripto correctamente el archivo : {}", nameReport);
				}else {
					throw new Exception("Encrypt Fail");
				}				
			} else {
				result  = generateZip(zipName,obligacion,inputFileName, contingencia, fecha);
			}

		}catch (Exception e) {
			result = false;
			logger.error("Error al tratar de encriptar el archivo a PGP : {} {} ",outputFileName, e);
		}finally {
			pgpFileProcessor = null;
			validTypeEncrypt = true;
		}
		return new boolean[]{validTypeEncrypt,result};		
	}
	
	/**
	 * Metodo para crear el nombre del reporte cifrado
	 * @param fileName
	 * @return
	 */
	private StringBuilder getNameToPgp(String fileName) {
		StringBuilder result = new StringBuilder(fileName);
		return result.append(".PGP");
	}
	
	/**
	 * /**
	 * Metodo para crear el nombre del reporte parcial cifrado
	 * @param fileName
	 * @return
	 */
	private StringBuilder getNameParcialToPgp(String fileName) {
		StringBuilder result = new StringBuilder(fileName);
		return result.append(tipoAsobancaria.equals("2001") ? cifrado : ".pgp");
	}
	
	/**
	 * Metodo que crea reporte en zip segun convenio
	 * @param zipName
	 * @param obligaciones
	 * @param fileReport 
	 */
	private boolean generateZip(String zipName, String obligaciones, String fileReport, boolean contingencia, String fecha) {
		boolean result = true;
		try {
			util.generaZip(zipName,obligaciones,fileReport, contingencia, fecha);			
		} catch (Exception e) {
			result= false;
			logger.error("Error al tratar crear el reporte zip : {} {}", obligaciones, e);
		}
		return result;
	}

}
