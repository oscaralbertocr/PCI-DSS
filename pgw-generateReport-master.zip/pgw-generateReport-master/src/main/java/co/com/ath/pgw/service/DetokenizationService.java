package co.com.ath.pgw.service;

import co.com.ath.pgw.dto.RequestTransferService;
import co.com.ath.pgw.util.CustomException;

/**
 * interfaz para el servicio de destokenizado. 
 *
 *
 * @author Jesus Octavio Avendaño Sierra <jesus.avendano@sophossolutions.com> 
 * @version 1.0 16/15/2019
 * 
 * @sophosSolutions
 * <strong>Autor: </strong>Jesus Octavio Avendaño Sierra</br>
 * <strong>Numero de Cambios: </strong>0</br>
 * 	
*/ 

public interface DetokenizationService {
	
	/**
	 * Metodo encargado de descargar el archivo por FTP.
	 * 
	 * @param **********
	 *            *******************************

	 * @return 
	 * 
	 **/
	public void dowloadFileFtp() throws CustomException, Exception;
	
	
	/**
	 * Metodo encargado destokenizar los PAN.
	 * 
	 * @param **********
	 *            *******************************

	 * @return 
	 * 
	 **/
	public void detokenization();
	
	/**
	 * Inicia el servicio.
	 * 
	 * @param **********
	 *            *******************************

	 * @return 
	 * 
	 **/
	public void run() throws CustomException, Exception;


	void run(RequestTransferService requestTransferService2) throws CustomException, Exception;


	void detokenization(RequestTransferService requestTransferService2);

}
