
package co.com.ath.pgw.dto;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonProperty;

import co.com.ath.pgw.util.XMLUtil;

public class GenericErrorResponse implements Serializable {

	@JsonProperty("MsgRsHdr")
	private MsgRsHdr msgRsHdr;
	private static final long serialVersionUID = 6294218922180477354L;

	public MsgRsHdr getMsgRsHdr() {
		return msgRsHdr;
	}

	public void setMsgRsHdr(MsgRsHdr msgRsHdr) {
		this.msgRsHdr = msgRsHdr;
	}

	@Override
	public String toString() {
		XMLUtil<GenericErrorResponse> util = new XMLUtil<GenericErrorResponse>();
		return util.convertObjectToJson(this);
	}

}
