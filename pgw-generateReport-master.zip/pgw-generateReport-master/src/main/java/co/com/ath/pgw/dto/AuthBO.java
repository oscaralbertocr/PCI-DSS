package co.com.ath.pgw.dto;

/**
 * 
 * @author proveedor_lbonilla
 *
 */
public class AuthBO {
	
	/**
	 * 
	 */
	private String method;
	
	/**
	 * 
	 */
	private String info;
	
	
	public String getMethod() {
		return method;
	}
	public void setMethod(String method) {
		this.method = method;
	}
	public String getInfo() {
		return info;
	}
	public void setInfo(String info) {
		this.info = info;
	}

}
