package co.com.ath.pgw.storedprocedures.impl;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Types;
import java.text.SimpleDateFormat;
import java.util.Date;

import javax.naming.InitialContext;
import javax.sql.DataSource;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.batch.core.configuration.annotation.StepScope;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import co.com.ath.pgw.storedprocedures.service.ProcedureService;
import co.com.ath.pgw.util.Constants;
import co.com.ath.pgw.util.Utils;

/**
 * @author braejan.arias
 *
 */
@Service
@StepScope
public class ProcedureServiceImpl implements ProcedureService{
    
	private static final Logger logger = LoggerFactory.getLogger(ProcedureServiceImpl.class);
	
    @Autowired(required = true)
    Utils util;
    
	@Value("#{jobParameters[tipoAsobancaria]}")
	private String tipoAsobancaria;

	@Override
	public void generateReportRecaudos(String obligaciones, String name) throws SQLException {
		Connection connection = null;
		CallableStatement callableStatement = null;
		ResultSet resultSet = null;
        InitialContext initialContext = null;
        DataSource dataSource = null;
		try {
	        initialContext = new InitialContext();
	        dataSource = (DataSource) initialContext
	                       .lookup("jdbc/pgwDS");
	        logger.info("::: SE REALIZA LA CONEXION AL DATASOURCE :::");			
			connection = dataSource.getConnection();
			callableStatement = connection.prepareCall(Constants.SP_REPORTE_RECAUDOS);
			callableStatement.setInt(1, Integer.parseInt(obligaciones));
			callableStatement.registerOutParameter(3, Types.VARCHAR);
			callableStatement.registerOutParameter(4, Types.VARCHAR);
			callableStatement.registerOutParameter(2, Constants.CURSOR);
			callableStatement.execute();
			resultSet = (ResultSet) callableStatement.getObject(2);
			
			if (callableStatement.getObject(3).equals("error")) {
				logger.error("Error interno del procedimiento {}", callableStatement.getObject(4));
			} else {
				util.generarArchivo(resultSet, name, "");
			}
						
			resultSet.close();			
			callableStatement.close();
			connection.close();
		}catch(Exception e) {
			logger.error("Error llamando procedimiento {}", e);
			
		} finally {
			if (connection != null) {
				connection.close();
			}
			if (callableStatement != null) {
				callableStatement.close();
			}
			if (resultSet != null) {
				resultSet.close();
			}
		}
		
	}
	/**Ajuste Contingencia recaudos
	 * */
	/**
	 * Implementacion consumo de procedimiento para recaudos contingencia
	 * 
	 * **/
	@Override
	public void  generateReportRecaudosCont(String obligaciones, String name, String horaInicio, String horaFin, int unifier, String fecha) throws SQLException {
		logger.info("::: Entro a crear Contingencia de Recaudos :::");
		Connection connection = null;
		CallableStatement callableStatement = null;
		ResultSet resultSet = null;
        InitialContext initialContext = null;
        DataSource dataSource = null;
        
		try {
	        initialContext = new InitialContext();
	        dataSource = (DataSource) initialContext
	                       .lookup("jdbc/pgwDS");
	        logger.info("::: SE REALIZA LA CONEXION AL DATASOURCE :::");			
			connection = dataSource.getConnection();
			callableStatement = connection.prepareCall(Constants.SP_REPORTE_RECAUDOS_CONTINGENCIA);
			callableStatement.setInt(1, Integer.parseInt(obligaciones));
			callableStatement.registerOutParameter(3, Types.VARCHAR);
			callableStatement.registerOutParameter(4, Types.VARCHAR);
			callableStatement.registerOutParameter(2, Constants.CURSOR);
			callableStatement.setString(5, horaInicio);
			callableStatement.setString(6, horaFin);
			callableStatement.setInt(7, unifier);
			callableStatement.setString(8, fecha);
			callableStatement.execute();
			resultSet = (ResultSet) callableStatement.getObject(2);
			
			if (callableStatement.getObject(3).equals("error")) {
				logger.error("Error interno del procedimiento {}", callableStatement.getObject(4));
			} else {
				util.generarArchivo(resultSet, name, "");
			}
						
			resultSet.close();			
			callableStatement.close();
			connection.close();
		}catch(Exception e) {
			logger.error("Error llamando procedimiento {}", e);
			
		} finally {
			if (connection != null) {
				connection.close();
			}
			if (callableStatement != null) {
				callableStatement.close();
			}
			if (resultSet != null) {
				resultSet.close();
			}
		}
		
	}
	/**
	 * Ajuste contingencia recaudos
	 * */
	
	

	@Override
	public void generateReportLiquidacion(String pathReport, String idBanco, String tipoReporte, String fechaInicial, String fechaFinal)
			throws SQLException {
		Connection connection = null;
		CallableStatement callableStatement = null;
		ResultSet resultSet = null;
		ResultSet resultFooter = null;
        InitialContext initialContext = null;
        DataSource dataSource = null;
        String tempFooter = "";
		try {			
			initialContext = new InitialContext();
			dataSource = (DataSource) initialContext
			                .lookup("jdbc/pgwDS");
			logger.info("::: SE REALIZA LA CONEXION AL DATASOURCE :::");			
			connection = dataSource.getConnection();
			callableStatement = connection.prepareCall(Constants.SP_REPORTE_LIQUIDACION);
			callableStatement.setString(1, idBanco);
			callableStatement.setString(2, tipoReporte);
			callableStatement.setString(3, fechaInicial);
			callableStatement.setString(4, fechaFinal);
			
			callableStatement.registerOutParameter(5, Types.VARCHAR);
			callableStatement.registerOutParameter(6, Types.VARCHAR);
			callableStatement.registerOutParameter(7, Constants.CURSOR);
			callableStatement.registerOutParameter(8, Constants.CURSOR);
			callableStatement.execute();
			resultSet = (ResultSet) callableStatement.getObject(7);
			resultFooter = (ResultSet) callableStatement.getObject(8);
			
			
	         while(resultFooter.next()) {
	        	 if (!resultFooter.getString(1).isEmpty()) {
	        		 tempFooter = resultFooter.getString(1);
	        	 }
	         }
						
			util.generarArchivo(resultSet, pathReport,tempFooter);
						
			resultSet.close();
			resultFooter.close();
			callableStatement.close();
			connection.close();
		}catch(Exception e) {
			logger.error("Error llamando procedimiento {}", e);
			
		} finally {
			if (connection != null) {
				connection.close();
			}
			if (callableStatement != null) {
				callableStatement.close();
			}
			if (resultSet != null) {
				resultSet.close();
			}
			if (resultFooter != null) {
				resultFooter.close();
			}			
			
		}
		
	}

	/**
	 * Implementacion consumo de procedimiento para parciales
	 * 
	 * **/
	@Override
	public void  generateReportRecaudosParcialesCont(String obligaciones, String name, String horaInicio, String horaFin, int unifier, String fecha, boolean intermedio) throws SQLException {
		logger.info("::: Entro a crear un parcial :::");
		Connection connection = null;
		CallableStatement callableStatement = null;
		ResultSet resultSet = null;
        InitialContext initialContext = null;
        DataSource dataSource = null;
        if(unifier!=1) {
        	unifier=0;
        }
		try {
			initialContext = new InitialContext();
	        dataSource = (DataSource) initialContext
	                       .lookup("jdbc/pgwDS");
	        logger.info("::: SE REALIZA LA CONEXION AL DATASOURCE :::");			
			connection = dataSource.getConnection();
			
			if (tipoAsobancaria.equals("2001")) {
				if(intermedio) {
					callableStatement = connection.prepareCall(Constants.SP_REPORTE_RECAUDOS_JFK_INTERMEDIO_CONTINGENCIA);
				}
				else {
					callableStatement = connection.prepareCall(Constants.SP_REPORTE_RECAUDOS_JFK_CONTINGENCIA);
				}
			}else {
				callableStatement = connection.prepareCall(Constants.SP_REPORTE_RECAUDOS_PARCIALES_CONTINGENCIA);
			}
			callableStatement.setInt(1, Integer.parseInt(obligaciones));
			callableStatement.registerOutParameter(3, Types.VARCHAR);
			callableStatement.registerOutParameter(4, Types.VARCHAR);
			callableStatement.registerOutParameter(2, Constants.CURSOR);
			callableStatement.setString(5, horaInicio);
			callableStatement.setString(6, horaFin);
			callableStatement.setInt(7, unifier);
			callableStatement.setString(8, fecha);
			callableStatement.execute();
			resultSet = (ResultSet) callableStatement.getObject(2);
			
			if (callableStatement.getObject(3).equals("error")) {
				logger.error("Error interno del procedimiento {}", callableStatement.getObject(4));
			} else {				
				if (tipoAsobancaria.equals("2001")) {
					util.generarArchivoCRLF(resultSet, name, "");
				}else {
					util.generarArchivo(resultSet, name, "");
				}
			}
						
			resultSet.close();			
			callableStatement.close();
			connection.close();
		}catch(Exception e) {
			logger.error("Error llamando procedimiento {}", e);
			
		} finally {
			if (connection != null) {
				connection.close();
			}
			if (callableStatement != null) {
				callableStatement.close();
			}
			if (resultSet != null) {
				resultSet.close();
			}
		}
		
	}

	
	/**
	 * IMplementacion consumo de procedimiento para parciales
	 * 
	 * **/
	@Override
	public void generateReportRecaudosParciales(String obligaciones, String name, String horaInicio, String horaFin, int unifier,boolean partial234 ) throws SQLException {
		logger.info("::: Entro a crear un parcial :::");
		Connection connection = null;
		CallableStatement callableStatement = null;
		ResultSet resultSet = null;
        InitialContext initialContext = null;
        DataSource dataSource = null;
		try {
	        initialContext = new InitialContext();
	        dataSource = (DataSource) initialContext
	                       .lookup("jdbc/pgwDS");
	        logger.info("::: SE REALIZA LA CONEXION AL DATASOURCE :::");			
			connection = dataSource.getConnection();
			
			if (tipoAsobancaria.equals("2001")) {
				if(partial234) {
					callableStatement = connection.prepareCall(Constants.SP_REPORTE_RECAUDOS_JFK_INTERMEDIO);
				}
				else {
					callableStatement = connection.prepareCall(Constants.SP_REPORTE_RECAUDOS_JFK);
				}
			} else {
				if(partial234) {
					callableStatement = connection.prepareCall(Constants.SP_REPORTE_RECAUDOS_PARCIALES_234);
				}
				else {
				callableStatement = connection.prepareCall(Constants.SP_REPORTE_RECAUDOS_PARCIALES);
				}
			}
			
			callableStatement.setInt(1, Integer.parseInt(obligaciones));
			callableStatement.registerOutParameter(3, Types.VARCHAR);
			callableStatement.registerOutParameter(4, Types.VARCHAR);
			callableStatement.registerOutParameter(2, Constants.CURSOR);
			callableStatement.setString(5, horaInicio);
			callableStatement.setString(6, horaFin);
			callableStatement.setInt(7, unifier);
			callableStatement.execute();
			resultSet = (ResultSet) callableStatement.getObject(2);
			
			if (callableStatement.getObject(3).equals("error")) {
				logger.error("Error interno del procedimiento {}", callableStatement.getObject(4));
			} else {				
				if (tipoAsobancaria.equals("2001")) {
					util.generarArchivoCRLF(resultSet, name, "");
				}else {
					util.generarArchivo(resultSet, name, "");
				}
			}
						
			resultSet.close();			
			callableStatement.close();
			connection.close();
		}catch(Exception e) {
			logger.error("Error llamando procedimiento {}", e);
			
		} finally {
			if (connection != null) {
				connection.close();
			}
			if (callableStatement != null) {
				callableStatement.close();
			}
			if (resultSet != null) {
				resultSet.close();
			}
		}
		
	}
	
	@Override
	public void generateReportBIPXC(String name) throws SQLException {
		Connection connection = null;
		CallableStatement callableStatement = null;
		ResultSet resultSet = null;
        InitialContext initialContext = null;
        DataSource dataSource = null;
		try {
	        initialContext = new InitialContext();
	        dataSource = (DataSource) initialContext
	                       .lookup("jdbc/pgwDS");
	        logger.info("::: SE REALIZA LA CONEXION AL DATASOURCE :::");			
			connection = dataSource.getConnection();
			callableStatement = connection.prepareCall(Constants.SP_REPORTE_BIPXC);
			callableStatement.registerOutParameter(1, Types.VARCHAR);
			callableStatement.registerOutParameter(2, Types.VARCHAR);
			callableStatement.registerOutParameter(3, Constants.CURSOR);
			callableStatement.execute();
			resultSet = (ResultSet) callableStatement.getObject(3);
			
			if (callableStatement.getObject(3).equals("error")) {
				logger.error("Error interno del procedimiento {}", callableStatement.getObject(4));
			} else {
				util.generarArchivoCRLF(resultSet, name, "");
			}
						
			resultSet.close();			
			callableStatement.close();
			connection.close();
		}catch(Exception e) {
			logger.error("Error llamando procedimiento {}", e);
			
		} finally {
			if (connection != null) {
				connection.close();
			}
			if (callableStatement != null) {
				callableStatement.close();
			}
			if (resultSet != null) {
				resultSet.close();
			}
		}
		
	}

	@Override
	public void generateReportRecaudosBogota(String obligaciones, String name, int tokenizar, Date fecha) throws SQLException {
		Connection connection = null;
		CallableStatement callableStatement = null;
		ResultSet resultSet = null;
        InitialContext initialContext = null;
        DataSource dataSource = null;
        SimpleDateFormat format = new SimpleDateFormat("yyyyMMdd");
		try {
	        initialContext = new InitialContext();
	        dataSource = (DataSource) initialContext
	                       .lookup("jdbc/pgwDS");
	        logger.info("::: SE REALIZA LA CONEXION AL DATASOURCE :::");			
			connection = dataSource.getConnection();
			callableStatement = connection.prepareCall(Constants.SP_REPORTE_RECAUDOS_BOGOTA);
			callableStatement.setString(1, obligaciones);
			callableStatement.setString(2, format.format(fecha));
			callableStatement.registerOutParameter(4, Types.VARCHAR);
			callableStatement.registerOutParameter(5, Types.VARCHAR);
			callableStatement.registerOutParameter(3, Constants.CURSOR);
			callableStatement.setInt(6, tokenizar);
			callableStatement.execute();
			resultSet = (ResultSet) callableStatement.getObject(3);
			
			if (callableStatement.getObject(4).equals("error")) {
				logger.error("Error interno del procedimiento {}", callableStatement.getObject(5));
			} else {
				util.generarArchivoCRLF(resultSet, name, "");
			}
						
			resultSet.close();			
			callableStatement.close();
			connection.close();
		}catch(Exception e) {
			logger.error("Error llamando procedimiento {}", e);
			
		} finally {
			if (connection != null) {
				connection.close();
			}
			if (callableStatement != null) {
				callableStatement.close();
			}
			if (resultSet != null) {
				resultSet.close();
			}
		}
		
	}
}
