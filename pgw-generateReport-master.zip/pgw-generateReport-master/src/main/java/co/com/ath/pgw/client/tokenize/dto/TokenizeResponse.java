
package co.com.ath.pgw.client.tokenize.dto;

import java.io.Serializable;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonProperty;

import co.com.ath.pgw.util.XMLUtil;

public class TokenizeResponse implements Serializable {

	@JsonProperty("token")
	private String token;
	@JsonProperty("tokens")
	private List<String> tokens;
	private static final long serialVersionUID = 1L;

	public String getToken() {
		return token;
	}

	public void setToken(String token) {
		this.token = token;
	}

	public List<String> getTokens() {
		return tokens;
	}

	public void setTokens(List<String> tokens) {
		this.tokens = tokens;
	}

	@Override
	public String toString() {
		XMLUtil<TokenizeResponse> util = new XMLUtil<TokenizeResponse>();
		return util.convertObjectToJson(this);
	}

}
