package co.com.ath.pgw.batch;

import javax.annotation.Resource;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.batch.core.configuration.annotation.StepScope;
import org.springframework.batch.item.ItemProcessor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpMethod;
import org.springframework.stereotype.Service;

import co.com.ath.pgw.client.tokenize.impl.TokenizeDataService;
import co.com.ath.pgw.dto.AuthBO;
import co.com.ath.pgw.dto.FileLine;
import co.com.ath.pgw.dto.ProtectBO;
import co.com.ath.pgw.dto.RequestDetokenizationService;
import co.com.ath.pgw.dto.TokenizeDataInfoBO;
import co.com.ath.pgw.dto.TokenizeInDTO;
import co.com.ath.pgw.dto.TokenizeOutDTO;
import co.com.ath.pgw.util.AbstractRestClient;
import co.com.ath.pgw.util.AesCifer;
import co.com.ath.pgw.util.Constants;
import co.com.ath.pgw.util.Parametro;



/**
 * Processor del batch de destokenizacion
 *
 * @author Jesus Octavio Avenda�o Sierra <jesus.avendano@sophossolutions.com> 
 * @version 1.0 16/15/2019
 *
 * @sophosSolutions
 * <strong>Autor: </strong>Jesus Octavio Avenda�o Sierra</br>
 * <strong>Numero de Cambios: </strong>0</br>
 *
*/

@Service
@StepScope
public class FileLineProcessor implements ItemProcessor<FileLine, FileLine> {
	
	private static final Logger logger = LoggerFactory.getLogger(FileLineProcessor.class);

	//@Value(value="${urlDetokenizationService}")
	private String urlDetokenizationService;
	
//	@Value(value="${naeUser}")
	private String naeUser;
	
	
	
	//@Value(value="${format}")
	private String formatGemalto;
	
	
	
	@Value(value="${flagToDestokenization}")
	private String flagToDestokenization;
	
	@Value(value="${flagToNoDestokenization}")
	private String flagToNoDestokenization;
	
	@Value("#{jobParameters[fileType]}")
	private String fileType;
	
	@Value(value = "${stringCompareCommission}")
	private String stringCompareCommission;
	
	@Value(value = "${stringComparecollection}")
	private String stringComparecollection;
	
	@Value(value = "${initialCharTokenCommission}")
	private int initialCharTokenCommission;
	
	@Value(value = "${finalCharTokenCommission}")
	private int finalCharTokenCommission;
	
	@Value(value = "${initialCharTokenCollection}")
	private int initialCharTokenCollection;
	
	@Value(value = "${finalCharTokenCollection}")
	private int finalCharTokenCollection;
	
	//@Value("${pasarela.ws.tokenize.service}")
	private String serviceTokenize;
	
	@Value("#{jobParameters[rqUID]}")
	private String rqUID;
	
	@Value("#{jobParameters[channel]}")
	private String channel;
	
	@Value("#{jobParameters[iPAddr]}")
	private String iPAddr;
	
	//@Value("${pasarela.tc.tokenize.info}")
	private String info;
	
	//@Value("${pasarela.tc.tokenize.method}")
	private String method;
	
	//@Value("${pasarela.tc.tokenize.format}")
	private String formatVoltage;
	
	//@Value("${pasarela.tc.tokenize.strRefine}")
	private String strRefine;
	@Resource
	private Parametro parametro;
	@Autowired 
	private AesCifer tripleDes;
	
	@Resource
	TokenizeDataService tokenizeDataService;
	
	/**
	 * Proceso que se ejecuta para cada linea.
	 * @param fileLine
	 * 			Linea leida.		
	 * @author Jesus Octavio Avenda�o Sierra <jesus.avendano@sophossolutions.com> 
	 * @version 1.0 16/15/2019
	*/
	@Override
	public FileLine process(FileLine fileLine) throws Exception {
		String firstChar = fileLine.getFirstChar();
		final String beforeToken = fileLine.getBeforeToken();
		final String token = fileLine.gettoken();
		String afterToken = fileLine.getAfterToken();
		final FileLine transformedLine;
		String detoken = token;
		try {
			if (fileLine.getFirstChar().equals(this.flagToDestokenization)) {  	//	DesTokenizar
				firstChar = "";
				if (this.fileType.equals(this.stringCompareCommission)) //Recaudo o Comision
					detoken = StringUtils.leftPad(this.detokenization(token.trim()), ((finalCharTokenCommission - initialCharTokenCommission) + 1), "0");
				else if(this.fileType.equals(this.stringComparecollection))
					detoken = StringUtils.leftPad(this.detokenization(token.trim()), ((finalCharTokenCollection - initialCharTokenCollection) + 1), "0");
			} else if(fileLine.getFirstChar().equals(this.flagToNoDestokenization)) {	//	No DesTokenizar
				firstChar = "";
			}
			String spaces = this.generateSpaces(firstChar, beforeToken, detoken, afterToken);
	        transformedLine = new FileLine(firstChar, beforeToken, detoken, afterToken + spaces);
		} catch (Exception e) {
			logger.error("Error FileLine process : {}", e);
			throw new Exception(e.getMessage());
		}
        return transformedLine;
	}
	
	/**
	 * Consume el servicio rest de destokenizacion.
	 *
	 * @param token
	 * 			String que se enviara en la peticion para ser destokenizado
	 * @author Jesus Octavio Avenda�o Sierra <jesus.avendano@sophossolutions.com> 
	 * @version 1.0 16/15/2019
	*/
	private String detokenization(String token) throws Exception {
		String detoken = null;
		try {
			if (serviceTokenize.equals(Constants.SERVICE_TOKENIZE_VOLTAGE)) {
				TokenizeInDTO tokenizeInDTO = new TokenizeInDTO();
				TokenizeDataInfoBO tokenizeDataInfoBO = new TokenizeDataInfoBO();
				
				tokenizeInDTO.setRqUID(Long.parseLong(this.rqUID));
				tokenizeInDTO.setChannel(this.channel);
				tokenizeInDTO.setIpAddr(this.iPAddr);
				
				AuthBO authBO = new AuthBO();
				authBO.setInfo(this.info.trim());
				authBO.setMethod(this.method.trim());
				tokenizeDataInfoBO.setAuth(authBO);
				
				String idSecKey = tripleDes.decrypt(parametro.getParametro("pasarelatctokenizeidSecKey"));
				
				tokenizeDataInfoBO.setIdSecKey(idSecKey.trim());
				
				ProtectBO protectBO = new ProtectBO();
				protectBO.setData(token);
				protectBO.setFormat(this.formatVoltage.trim());
				protectBO.setStrRefine(this.strRefine.trim());
				tokenizeDataInfoBO.setProtect(protectBO);
				
				tokenizeInDTO.setTokenizeDataInfoBO(tokenizeDataInfoBO);
				TokenizeOutDTO tokenizeOutDTO = tokenizeDataService.getTokenize(tokenizeInDTO);
				detoken = tokenizeOutDTO.getTokenizeDataInfoBO().getProtect().getData();
			}

		} catch (Exception e) {
			logger.error("Errordetokenization : {}", e);
			throw new Exception(e.getMessage());
		}
		return detoken;
	}
	
	/**
	 * Genera la cantidad de espacios necesarios para
	 * cumplir con el estandar definido por la documentacion de los reportes.
	 *
	 * @param firstChar
	 * 			caracter de inicio de linea
	 * 
	 * @param beforeToken
	 * 			String que esta antes del token
	 * 
	 * @param token
	 * 			token
	 * 
	 * @param afterToken
	 * 			String que esta despues del token
	 * 
	 * @author Jesus Octavio Avenda�o Sierra <jesus.avendano@sophossolutions.com> 
	 * @version 1.0 16/15/2019
	*/
	private String generateSpaces(String firstChar , String beforeToken , String token , String afterToken) {
		StringBuilder allLine = new StringBuilder( firstChar + beforeToken + token + afterToken );
		StringBuilder spaces = new StringBuilder();
		int count = 220 - allLine.length();
		for (int i = 0; i < count; i++) {
			spaces.append(" ");
		}
		return spaces.toString();
	}
	
}