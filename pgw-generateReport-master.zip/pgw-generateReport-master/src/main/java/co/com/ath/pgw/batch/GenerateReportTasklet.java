package co.com.ath.pgw.batch;

import java.sql.Statement;
import java.text.SimpleDateFormat;
import java.util.Date;

import javax.annotation.Resource;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.batch.core.StepContribution;
import org.springframework.batch.core.configuration.annotation.StepScope;
import org.springframework.batch.core.scope.context.ChunkContext;
import org.springframework.batch.core.step.tasklet.Tasklet;
import org.springframework.batch.repeat.RepeatStatus;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import co.com.ath.pgw.client.tokenize.impl.TokenizeDataService;
import co.com.ath.pgw.storedprocedures.impl.ProcedureServiceImpl;
import co.com.ath.pgw.util.DataSourceConfig;
import co.com.ath.pgw.util.DateUtil;
import co.com.ath.pgw.util.Utils;

/**
 * Processor del batch de destokenizacion
 *
 * @author Jesus Octavio Avenda�o Sierra <jesus.avendano@sophossolutions.com>
 * @version 1.0 16/15/2019
 *
 * @sophosSolutions <strong>Autor: </strong>Jesus Octavio Avenda�o Sierra</br>
 *                  <strong>Numero de Cambios: </strong>0</br>
 *
 */

@Service
@StepScope
public class GenerateReportTasklet implements Tasklet {

	private static final Logger logger = LoggerFactory.getLogger(GenerateReportTasklet.class);

	//@Value(value = "${urlDetokenizationService}")
	private String urlDetokenizationService;

	@Value(value = "${initialCharTokenCollection}")
	private int initialCharTokenCollection;

	@Value(value = "${finalCharTokenCollection}")
	private int finalCharTokenCollection;

	//@Value(value = "${format}")
	private String formatGemalto;

	@Value("#{jobParameters[rqUID]}")
	private String rqUID;

	@Value("#{jobParameters[channel]}")
	private String channel;

	@Value("#{jobParameters[iPAddr]}")
	private String iPAddr;

	@Value("#{jobParameters[contingencia]}")
	private String contingencia;

	//@Value("${pasarela.tc.tokenize.info}")
	private String info;

	//@Value("${pasarela.tc.tokenize.method}")
	private String method;

	//@Value("${pasarela.tc.tokenize.idSecKey}")
	//private String idSecKey;

	//@Value("${pasarela.tc.tokenize.format}")
	private String formatVoltage;

	//@Value("${pasarela.tc.tokenize.strRefine}")
	private String strRefine;

	@Autowired(required = true)
	DataSourceConfig dbConfig;

	@Autowired(required = true)
	Utils util;

	@Autowired(required = true)
	DateUtil utildate;

	@Autowired
	ProcedureServiceImpl service;

	@Resource
	TokenizeDataService tokenizeDataService;
	private Statement stmt = null;

	@Value("#{jobParameters[mediosPagosVAR]}")
	private String mediosPagosVAR;

	@Value("#{jobParameters[obligacionesVAR]}")
	private String obligacionesVAR;
	
	@Value("#{jobParameters[obligacionNura]}")
	private String obligacionNuraCont;
	
	@Value("${report.obligacionNura}")
	private String obligacionNura;

	@Value("#{jobParameters[obligacionNura]}")
	private String obligacionNuraParcial;

	@Value("#{jobParameters[cronArray]}")
	private String cronArray;

	@Value("#{jobParameters[fileName]}")
	private String fileName;

	@Value("#{jobParameters[filePath]}")
	private String filePath;

	@Value("#{jobParameters[fileNameLiquidacion]}")
	private String fileLiquidacion;

	@Value("#{jobParameters[filePathLiquidacion]}")
	private String pathLiquidacion;

	@Value("#{jobParameters[idBancoRepublica]}")
	private String idBancoRepublica;

	@Value("#{jobParameters[numeroTerminal]}")
	private String numeroTerminal;

	@Value("#{jobParameters[reportType]}")
	private String reportType;

	@Value("#{jobParameters[startDate]}")
	private String startDate;

	@Value("#{jobParameters[endDate]}")
	private String endDate;

	@Value("#{jobParameters[fecha]}")
	private String fecha;

	//@Value("${pasarela.ws.tokenize.service}")
	private String serviceTokenize;

	@Value("${MedioPago}")
	private String medioPago;

	@Value("#{jobParameters[fileId]}")
	private String tipoReporte;

	@Value("#{jobParameters[nombreReporte]}")
	private String nombreReporte;

	@Value("#{jobParameters[nombreReporteConsolidado]}")
	private String reportNameConsolidado;

	@Value("#{jobParameters[reportDate]}")
	private String reportDate;

	@Value("#{jobParameters[nJob]}")
	private String nJob;

	@Value("#{jobParameters[unifier]}")
	private String unifiere;
	
	@Value("#{jobParameters[fileNameRecaudosBogotaTC]}")
	private String nameBogotaTC;
	
	@Value("#{jobParameters[fileNameRecaudosBogotaOC]}")
	private String nameBogotaOC;
	
	@Value("#{jobParameters[nuraTC]}")
	private String nuraTC;
	
	@Value("#{jobParameters[nuraOC]}")
	private String nuraOC;
	
	@Value("#{jobParameters[filePathTC]}")
	private String filePathTC;
	
	@Value("#{jobParameters[filePathOC]}")
	private String filePathOC;
	
	@Value("#{jobParameters[contingenciaBogota]}")
	private String contingenciaRecaudosBogota;	

	@Override
	public RepeatStatus execute(StepContribution contribution, ChunkContext chunkContext) throws Exception {
		logger.info("-----------------------------Tasklet iniciado----------------------------");

		if (tipoReporte.equals("2")) {
			generarReporteRecaudos();
			/* Archivos parciales */
		}else if (tipoReporte.equals("3")) {
			generarReporteParcialRecaudos();
		}
		/* Archivos BIPXC */
		else if(tipoReporte.equals("4")){
			generarReporteBIPXC();
		}		
		else if (tipoReporte.equals("5")) {
			generarRecaudosBogota();
		}
		else {
			generarReporteLiquidacion();
		}
		return RepeatStatus.FINISHED;
	}

	private void generarReporteRecaudos() {
		

		try {
			if(contingencia.equals("1")) {
			
				mediosPagosVAR = medioPago;
				String obligaciones = obligacionesVAR;	
				String obligacionesNura = this.obligacionNuraCont;
				String nameReports = nombreReporte;
				String fechaContingencia = this.fecha;
				
				logger.info("Inicio generaci�n del archivo de Contingencia para el convenio {}", obligaciones);
				String name = util.nameReport(fechaContingencia, nameReports, this.filePath, obligacionesNura, "1");
				this.service.generateReportRecaudosCont(obligaciones,name,"00:00:00","23:59:59",0,fechaContingencia);
				logger.info("Fin de la construcci�n del archivo destokenizado para el convenio {}", obligaciones);
			}
			else {
				String obligaciones[] = null;
				String obligacionesNura[] = null;
				String nameReports[] = null;
					
				mediosPagosVAR = medioPago;
				obligaciones = obligacionesVAR.split(",");
				obligacionesNura = obligacionNura.split(",");
				nameReports = nombreReporte.split(",");
	
				for (int i = 0; i < obligaciones.length; i++) {
	
					logger.info("Inicio generaci�n del archivo destokenizado para el convenio {}", obligaciones[i]);
	
					String name = util.nameReport(reportDate, nameReports[i], this.filePath, obligacionesNura[i], "0");
					this.service.generateReportRecaudos(obligaciones[i], name);
	
					logger.info("Fin de la construcci�n del archivo destokenizado para el convenio {}", obligaciones[i]);
				}
			}
		} catch (Exception e) {
			logger.error("problemas en la construccion del archivo {}", e);
		}
	}

	/**
	 * Metodo que genera el reporte de liquidacion
	 */
	private void generarReporteLiquidacion() {
		String idBanco = "";
		String reporte = "";
		String fechaInicial = "";
		String fechaFinal = "";

		try {
			idBanco = idBancoRepublica;
			reporte = reportType;
			fechaFinal = endDate;
			fechaInicial = startDate;

			logger.info("Inicio generaci�n del reporte de liquidacion");

			String name = pathLiquidacion + "\\" + fileLiquidacion;
			this.service.generateReportLiquidacion(name, idBanco, reporte, fechaInicial, fechaFinal);

			logger.info("Fin de la construccion del archivo");

		} catch (Exception e) {
			logger.error("problemas en la construccion del archivo de liquidacion  {}", e);
		}
	}

	/**
	 * Metodo que genera el reporte parcial de recaudos
	 */

	private void generarReporteParcialRecaudos() {
		String obligaciones[] = null;
		String obligacionesNura[] = null;
		String nameReports = null;
		String nameReportConsolidado = null;
		String initialTime[] = null;
		String horaorden[] = null;
		String fechaOrden[] = null;
		String horaInicial = "";
		Integer unifier = Integer.parseInt(this.unifiere);
		String horaFinal = "";


		try {	

			mediosPagosVAR = medioPago;
			obligaciones = obligacionesVAR.split(",");
			obligacionesNura = obligacionNuraParcial.split(",");
			nameReports = nombreReporte;
			nameReportConsolidado = reportNameConsolidado;

			/**Se obtienen las horas de inicio y fin del reporte -inicio-**/
			Integer pHora= Integer.parseInt(nJob);
			cronArray = "[0 0 0 ? * MON-FRI]"+cronArray;
			cronArray = cronArray.replace("[", "");
			cronArray = cronArray.replace("? * MON-FRI", "");
			initialTime=cronArray.split("]");

			int ultimo=initialTime.length-1;
			int primero=ultimo-(ultimo-1);
			for( int j=0; j< initialTime.length; j++) {
				horaorden=initialTime[j].split(" ");
				for(int f=0; f< horaorden.length; f++) {
					if(horaorden[f].length()==1) {
						horaorden[f]="0"+horaorden[f];	
					}
				}


				initialTime[j]=horaorden[2]+":"+horaorden[1]+":"+horaorden[0];

			}
			/**Se obtienen las horas de inicio y fin del reporte -fin-**/

			for(int i=0; i< obligaciones.length; i++) {
				logger.info("Job que se ejecutara :::>>{}",pHora);
				logger.info(":::::>>>>>>>>>>>:::::::este es el valor del parametro de la hora inicial {}  posicion del Array {}"
						,initialTime[pHora-1],pHora-1);
				logger.info(":::::>>>>>>>>>>>:::::::este es el valor del parametro de la hora final {} posicion del Array {}"
						,initialTime[pHora],pHora);

				if(contingencia.equals("1")) {
					fechaOrden=fecha.split("/");
					String fechaOrdenC=fechaOrden[2]+fechaOrden[1]+fechaOrden[0];
					if(ultimo == pHora) {

						String name = util.nameReporteConsolidado(nameReportConsolidado,this.filePath,obligacionesNura[i],fechaOrdenC);
						this.service.generateReportRecaudosParcialesCont(obligaciones[i],name,initialTime[0],"23:59:59",unifier,fecha,false);	
						logger.info("Este es el ultimo job por tanto se construira reporte consolidado para el convenio {} "
								+ "schundle ejecutado ::> {}", obligaciones[i],pHora);

					}else {
						horaInicial=initialTime[pHora-1];
						horaFinal=initialTime[pHora];
						String name = util.nameReportPartial(nameReports,this.filePath,obligacionesNura[i],horaFinal,fechaOrdenC);
						if (primero == pHora) {
							this.service.generateReportRecaudosParcialesCont(obligaciones[i],name,initialTime[0],"23:59:59",unifier,fecha,false);
							logger.info("Fin de la construcci�n del archivo destokenizado para el convenio {} se tomaran las transacciones del dia hasta la hora {}", obligaciones[i],horaFinal);	
						}else {
							this.service.generateReportRecaudosParcialesCont(obligaciones[i],name,horaInicial,horaFinal,unifier,fecha,true);
						}

						logger.info("Fin de la construcci�n del archivo destokenizado para el convenio {}", obligaciones[i]);

					}
				}else if(ultimo == pHora ) {

					String name = util.nameReporteConsolidado(nameReportConsolidado,this.filePath,obligacionesNura[i],"");
					this.service.generateReportRecaudosParciales(obligaciones[i],name,initialTime[0],"23:59:59",unifier,false);
					logger.info("Este es el ultimo job por tanto se construira reporte consolidado para el convenio {} "
							+ "schundle ejecutado ::> {}", obligaciones[i],pHora);

				}else {
					horaInicial=initialTime[pHora-1];
					horaFinal=initialTime[pHora];
					String name = util.nameReportPartial(nameReports,this.filePath,obligacionesNura[i],horaFinal,"");
					if (primero == pHora) {
						this.service.generateReportRecaudosParciales(obligaciones[i],name,initialTime[0],"23:59:59",unifier,false);
						logger.info("Fin de la construcci�n del archivo destokenizado para el convenio {} se tomaran las transacciones del dia hasta la hora {}", obligaciones[i],horaFinal);	
					}else{
						this.service.generateReportRecaudosParciales(obligaciones[i],name,horaInicial,horaFinal,unifier,true);
					}

					logger.info("Fin de la construcci�n del archivo destokenizado para el convenio {}", obligaciones[i]);
				}


			}                   
		}catch (Exception e) {
			logger.error("problemas en la construccion del archivo {}", e);
		}
	}
	
	private void generarRecaudosBogota() {

		try {
			logger.info("Inicio generaci�n del archivo recaudos bogota tarjeta de credito");			
			this.service.generateReportRecaudosBogota(nuraTC,filePathTC + "\\" + nameBogotaTC,0,
					contingenciaRecaudosBogota.equals("0") ? new Date() :new SimpleDateFormat("dd/MM/yyyy").parse(fecha));
			logger.info("Fin de la construcci�n del archivo recaudos bogota tarjeta de credito");
			
//			logger.info("Inicio generaci�n del archivo recaudos bogota otros creditos");
//			this.service.generateReportRecaudosBogota(nuraOC,filePathOC + "\\" + nameBogotaOC,1);
//			logger.info("Fin de la construcci�n del archivo recaudos bogota otros creditos");

		} catch (Exception e) {
			logger.error("problemas en la construccion del archivo {}", e);
		}
	}

	private void generarReporteBIPXC() {
		String nameReports = null;

		try {
			nameReports = nombreReporte;

			

				logger.info("Inicio generaci�n del archivo desCifrado para el convenio ");

				String name = util.nameReportBIPXC(nameReports, this.filePath);
				this.service.generateReportBIPXC(name);

				logger.info("Fin de la construcci�n del archivo descifrado para el reporte BIPXC");
			
		} catch (Exception e) {
			logger.error("problemas en la construccion del archivo {}", e);
		}
	}
}
