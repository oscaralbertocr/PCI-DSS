package co.com.ath.pgw.batch;

import java.sql.Timestamp;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

import javax.annotation.PostConstruct;
import javax.annotation.Resource;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.batch.core.Job;
import org.springframework.batch.core.JobExecution;
import org.springframework.batch.core.JobParametersBuilder;
import org.springframework.batch.core.Step;
import org.springframework.batch.core.configuration.annotation.JobBuilderFactory;
import org.springframework.batch.core.configuration.annotation.StepBuilderFactory;
import org.springframework.batch.core.launch.JobLauncher;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import co.com.ath.pgw.util.AVALBankEnum;

/**
 * Configuracion reporte de liquidacion
 * 
 * @author Diego Alejandro Galeano Garzon <diego.galeano@sophossolutions.com>
 * @version 1.0 10/03/2020
 */
@Service
public class ComisionReportBatch {
	
	private static final Logger logger = LoggerFactory.getLogger(ComisionReportBatch.class);

	/**
	 * constructor del job
	 */
	@Resource
	private JobBuilderFactory jobBuilderFactory;
	/**
	 * constructor del Step
	 */
	@Resource
	private StepBuilderFactory stepBuilderFactory;
	/**
	 * job Launcher
	 */
	@Resource
	private JobLauncher jobLauncher;
	/**
	 * instanciamiento del Job
	 */
	private Job jobInstance;
	/**
	 * nombre del Job
	 */
	private static final String JOB_NAME = "COMISION_REPORT_JOB";
	/**
	 * nombre del Step
	 */
	private static final String STEP_NAME = "GENERATE_REPORT_STEP";
	/**
	 * Pattern del archivo
	 */
	private static final String FILE_NAME_PATTERN = "%s_Pagos_PortalDePagos_%s.DAT";
	/**
	 * Variable para el cifrado del reporte
	 */
	private static final String TASKLET_NAME = "ENCRIPT_PGP"; 
	/**
	 * ruta local del archivo
	 */
	@Value(value = "${pathLiquidacion}")
	private String pathLiquidacion;
	/**
	 * Ruta local de la contingencia
	 */
	@Value(value = "${pathLiquidacion.contingencia}")
	private String pathContingencia;
	
	private boolean validateDate = true;
	
	String horaInicio = "00:00:00.000000000";
	String horaFin = "23:59:59.999999999";	
	
	@Autowired(required=true)
	private GenerateReportTasklet generateReportTasklet;
	
	@Autowired(required=true)
	private EncriptPGPTasklet encriptPGPTasklet;
	
	@PostConstruct
	public void init() {
		jobInstance = createJob();
	}
	
	private Job createJob() {
		return jobBuilderFactory.get(JOB_NAME)
				.flow(generateReportStep())
				.next(this.encriptPGP())
				.end()
				.build();
	}

	private Step generateReportStep() {
		return stepBuilderFactory.get(STEP_NAME)
				.tasklet(this.generateReportTasklet)
				.build();
	}
	
	/**
	 * Metodo encargado de ejecutar el reporte diario
	 */
	@Scheduled(cron="${reportLiquidacionCron}")
	public void run() {
		logger.info("::: Activacion de cron :::");
		Calendar calendar = Calendar.getInstance();
		calendar.add(Calendar.DATE, -1);
		Date curDate = calendar.getTime();
		try {
			validateDate = true;
			String compensationDateStart = mergeDate(curDate, horaInicio);
			String compensationDateEnd = mergeDate(curDate, horaFin);
			
			AVALBankEnum[] bancosAval = AVALBankEnum.values();
			for( AVALBankEnum avalBank : bancosAval ){
				logger.info("Reporte de liquidacion diario para el banco {}", avalBank.getInitialBank());
				executeJob(getFileName(avalBank.getInitialBank(),curDate), compensationDateStart, compensationDateEnd, avalBank, "D", pathLiquidacion);
			}
		} catch (Exception ex) {
			logger.error("Error no esperado iniciando la generacion de archivos de Liquidacion Comisiones: \n{}", ex);
		}
	}
	
	/**
	 * Metodo encargado de ejecutar el reporte Mensual
	 */
	@Scheduled(cron="${reportLiquidacionMensualCron}")
	public void runMonthly(){
		try {
			validateDate = false;
			
			Calendar calendar1 = Calendar.getInstance();
			calendar1.add(Calendar.DATE, -1);
			Date curDate = calendar1.getTime();
			
			Calendar calendar = Calendar.getInstance();
			calendar.setTime(new Date());
			calendar.add(Calendar.MONTH, -1);

			// Ultimo d�a del mes anterior
			int diaMaxMes = calendar.getActualMaximum(Calendar.DAY_OF_MONTH);
			int mesAnterior = calendar.get(Calendar.MONTH);
			int year = calendar.get(Calendar.YEAR);

			// set fecha �ltimo d�a
			calendar.set(year, mesAnterior, diaMaxMes);
			Date afterDate = calendar.getTime();

			// Primer d�a del mes anterior
			int diaMinMes = calendar.getActualMinimum(Calendar.DAY_OF_MONTH);

			// set fecha primer d�a
			calendar.set(year, mesAnterior, diaMinMes);
			Date beforeDate = calendar.getTime();
			
			String compensationDateStart = mergeDate(beforeDate, horaInicio);
			String compensationDateEnd = mergeDate(afterDate, horaFin);
			
			
			AVALBankEnum[] bancosAval = AVALBankEnum.values();
			for( AVALBankEnum avalBank : bancosAval ){
				logger.info("Reporte de liquidacion mensual para el banco {}", avalBank.getInitialBank());
				executeJob(getFileName(avalBank.getInitialBank(),curDate), compensationDateStart, compensationDateEnd, avalBank, "M", pathLiquidacion);
			}
			
			
		} catch (Exception e) {
			logger.error("Error no esperado iniciando la generacion de archivos de Liquidacion Comisiones: \n{}", e);
		}		
	} 
	
	/**
	 * Metodo encargado de generar la contingencia
	 * @param fileType
	 * @param fileName
	 */
	@Transactional(propagation = Propagation.NOT_SUPPORTED)
	public void automaticRun(String fileType , String fileName) {
		SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyyMMdd");
		String tipoArchivo = null;
		Date afterDate = null;
		Date beforeDate = null;
		
		try {
			String nombreArchivo = fileName;
			String[] s_nombreArchivo = nombreArchivo.split("_");

			if ((fileType.equals("CD")) && (s_nombreArchivo[3].length() == 8))  {
				// Archivo Diario
				tipoArchivo = "D";
				validateDate = true;
				Calendar calendar = Calendar.getInstance();
				calendar.setTime(simpleDateFormat.parse(s_nombreArchivo[3]));
				beforeDate = calendar.getTime();
				afterDate = calendar.getTime();
			} else if ((fileType.equals("CM")) && (s_nombreArchivo[3].length() == 6)) {
				// Archivo Mensual
				tipoArchivo = "M";
				validateDate = false;
				s_nombreArchivo[3] = s_nombreArchivo[3] + "01";
				Calendar calendar = Calendar.getInstance();
				calendar.setTime(simpleDateFormat.parse(s_nombreArchivo[3]));
				// Ultimo dia del mes anterior
				int diaMaxMes = calendar.getActualMaximum(Calendar.DAY_OF_MONTH);
				int mesAnterior = calendar.get(Calendar.MONTH);
				int year = calendar.get(Calendar.YEAR);
				// set fecha ultimo dia
				calendar.set(year, mesAnterior, diaMaxMes);
				afterDate = calendar.getTime();
				// Primer dia del mes anterior
				int diaMinMes = calendar.getActualMinimum(Calendar.DAY_OF_MONTH);
				// set fecha primer dia
				calendar.set(year, mesAnterior, diaMinMes);
				beforeDate = calendar.getTime();
			}else {
				throw new Exception("El nombre del archivo no concuerda con el el fileType (Tipo de archivo CD:Diario CM:Mensual)");
			}

			String compensationDateStart = mergeDate(beforeDate, horaInicio);
			String compensationDateEnd = mergeDate(afterDate, horaFin);
			
			
			AVALBankEnum[] bancosAval = AVALBankEnum.values();
			for (AVALBankEnum avalBank : bancosAval) {
					if (avalBank.getInitialBank().equals(s_nombreArchivo[0])) {
						logger.info("Reporte de liquidacion de contingencia para el banco {}", s_nombreArchivo[0]);
						executeJob(getFileName(s_nombreArchivo[0], beforeDate), compensationDateStart, compensationDateEnd, avalBank,tipoArchivo,pathContingencia);
					}
			}			
			
		} catch (Exception e) {
			logger.error("Error no esperado iniciando la generacion de la contingencia del archivos de Liquidacion Comisiones: \n{}", e);
		}
		
	}
	
	/**
	 * Metodo encargado de cargar las variables para el reporte
	 * @param fileName
	 * @param DateStart
	 * @param DateEnd
	 * @param avalBank
	 * @return
	 */
	private JobExecution executeJob(String fileName, String dateStart, String dateEnd, AVALBankEnum avalBank, String tipoReporte, String path) {
		JobExecution jobExecution;
		try {
			JobParametersBuilder jobParams = new JobParametersBuilder();
			jobParams.addLong("time", System.currentTimeMillis());
			jobParams.addString("rqUID", "132");
			jobParams.addString("channel", "132");
			jobParams.addString("iPAddr", "132");			
			jobParams.addString("fileType", "2");
			jobParams.addString("fileId", "1");
			jobParams.addString("startDate", dateStart);
			jobParams.addString("endDate", dateEnd);
			jobParams.addLong("bankId", avalBank.getIdBank());
			jobParams.addString("initialBank", avalBank.getInitialBank());
			jobParams.addString("BankRepublica", avalBank.getCentralBankCode());
			jobParams.addString("idBancoRepublica", avalBank.getCentralBankCode());
			jobParams.addString("numeroTerminal", avalBank.getTerminalCodeBank());
			jobParams.addString("reportType", tipoReporte);
			jobParams.addString("fileNameLiquidacion",  fileName);
			jobParams.addString("filePathLiquidacion", path);

			jobExecution = jobLauncher.run(jobInstance, jobParams.toJobParameters());
			
		} catch (Exception ex) {
			jobExecution = null;
			logger.error("Error ejecutando :\n{}", ex);
		}
		return jobExecution;
	}	
	
	/**
	 * Metodo que crea el nombre del reporte
	 * @param initialBank
	 * @param currentDate
	 * @return
	 */
	private String getFileName(String initialBank,Date currentDate) {
		SimpleDateFormat format;
		if (validateDate) {
			format = new SimpleDateFormat("yyyyMMdd");
		} else {
			format = new SimpleDateFormat("yyyyMM");
		}
		return String.format(FILE_NAME_PATTERN,initialBank,format.format(currentDate));
	}
	
	/**
	 * Metodo para dar formato a las fechas
	 * @param date
	 * @param hora
	 * @return
	 * @throws ParseException
	 */
	private String mergeDate(Date date, String hora) throws ParseException {
		DateFormat dateFormat = new SimpleDateFormat("ddMMyyyy HHmmss");
		String fechaSalida = "";
		Date fecha = null;
 	   try {	
			Calendar calendar = Calendar.getInstance();
			StringBuilder dateBuilder = new StringBuilder();
			calendar.setTime(date);
			dateBuilder.append(calendar.get(Calendar.YEAR));
	        dateBuilder.append("-");
			dateBuilder.append(calendar.get(Calendar.MONTH)+1);
	        dateBuilder.append("-");
			dateBuilder.append(calendar.get(Calendar.DAY_OF_MONTH));
			dateBuilder.append(" ");
			dateBuilder.append(hora);
			
			fecha = Timestamp.valueOf(dateBuilder.toString());
		
			fechaSalida= dateFormat.format(fecha); 
		
 	  } catch (Exception e) {
 		 logger.error("error al dar formato a la fecha {}", e);
		} 
	return fechaSalida; 
	}
	
	/**
	 * Genera el reporte cifrado.
	 * 
	 * @return 
	 * 		Step
	 **/
	private Step encriptPGP() {
		return stepBuilderFactory.get(TASKLET_NAME)
				.tasklet(this.encriptPGPTasklet)
				.build();
	}
}