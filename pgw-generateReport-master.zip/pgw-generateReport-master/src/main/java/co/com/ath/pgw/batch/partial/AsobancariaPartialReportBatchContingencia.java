package co.com.ath.pgw.batch.partial;

import java.util.Date;

import javax.annotation.PostConstruct;
import javax.annotation.Resource;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.batch.core.Job;
import org.springframework.batch.core.JobExecution;
import org.springframework.batch.core.JobParametersBuilder;
import org.springframework.batch.core.Step;
import org.springframework.batch.core.configuration.annotation.JobBuilderFactory;
import org.springframework.batch.core.configuration.annotation.StepBuilderFactory;
import org.springframework.batch.core.launch.JobLauncher;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import co.com.ath.pgw.batch.EncriptPGPTasklet;
import co.com.ath.pgw.batch.GenerateReportTasklet;

@Service
public class AsobancariaPartialReportBatchContingencia {
	
	private static final Logger logger = LoggerFactory.getLogger(AsobancariaPartialReportBatchContingencia.class);

	/**
	 * constructor del job
	 */
	@Resource
	private JobBuilderFactory jobBuilderFactory;
	/**
	 * constructor del Step
	 */
	@Resource
	private StepBuilderFactory stepBuilderFactory;
	/**
	 * job Launcher
	 */
	@Resource
	private JobLauncher jobLauncher;
	/**
	 * nombre del Job
	 */
	private static final String JOB_NAME = "COMISION_PARTIAL_REPORT_JOB";
	/**
	 * nombre del Step
	 */
	private static final String STEP_NAME = "GENERATE_PARTIAL_REPORT_STEP";
	/**
	 * Variable para el cifrado del reporte
	 */
	private static final String TASKLET_NAME = "ENCRIPT_PGP"; 
	
	
	
	@Value("${report.mediosPagosVAR}")
	private String mediosPagosVAR;

	@Value("${report.obligacionesParcialesVAR}")
	private String obligacionesVAR;
	
	@Value("${report.obligacionParcialNura}")
	private String obligacionNura;
	
	@Value(value = "${pathPartialDownload}")
	private String pathDownload;
	
	@Value(value = "${pathPartial.contingencia}")
	private String pathContingenciaParcial;
	
	@Value(value = "${report.parcialName}")
	private String reportName;	
	
	@Value(value = "${report.ConsolidadoName}")
	private String reportNameConsolidado;	
	
	@Autowired(required=true)
	private EncriptPGPTasklet encriptPGPTasklet;
	
	@Autowired(required=true)
	private GenerateReportTasklet generateReportTasklet;
	/**
	 * Propiedad que indica si el archivo se genera para banco o para unifier
	 * */
	@Value(value = "${report.unifier}")
	private String unifier;
	
	/**
	 * ruta local del archivo
	 */
	@Value(value = "${pathLiquidacion}")
	private String pathLiquidacion;
	/**
	 * Ruta local de la contingencia
	 */
	@Value(value = "${pathLiquidacion.contingencia}")
	private String pathContingencia;
	
	@Value(value = "${pasarela.batch.scheduled.asobancaria.partial.cronArray}")
	private String cronArray;
	
	String horaInicio = "00:00:00.000000000";
	String horaFin = "23:59:59.999999999";	
	
	
	
	/**
	 * instanciamiento del Job
	 */
	private Job jobInstance;
	
	
	@PostConstruct
	public void init() {
		jobInstance = createJob();
	}
	
	private Job createJob() {
		return jobBuilderFactory.get(JOB_NAME)
				.flow(generateReportStep())
				.next(this.encriptPGP())
				.end()
				.build();
	}

	private Step generateReportStep() {
		return stepBuilderFactory.get(STEP_NAME)
				.tasklet(this.generateReportTasklet)
				.build();
	}
	
	@Transactional(propagation = Propagation.NOT_SUPPORTED)
	public void automaticRun(String fileType , String fileName) {
		String jobName ="";
		String fecha ="";
		
		try {			
			jobName=fileType;	
			
			if (fileType.equals("C")) {
				jobName = String.valueOf(cronArray.split("]").length);
			}else {
				jobName=fileType;
			}			
			
			fecha=fileName;
			logger.info("Reporte de recaudos parciales de contingencia");
			executeJobContingencia(jobName,fecha);

			
		} catch (Exception e) {
			logger.error("Error no esperado iniciando la generacion del reporte de recaudos parciales: \n{}", e);
		}	
	}

	private JobExecution executeJobContingencia(String parcial, String fecha) {
		JobExecution jobExecution;
		try {
			logger.info("::: Generando parametros para reporte parcial ::: Numero ::: {}",parcial);
			JobParametersBuilder jobParametersBuilder = new JobParametersBuilder();
			jobParametersBuilder.addString("filePath", this.pathContingenciaParcial);
			jobParametersBuilder.addString("fileType", "2");
			jobParametersBuilder.addString("fileId", "3");
			jobParametersBuilder.addString("contingencia", "1");
			jobParametersBuilder.addString("fecha", fecha);
			jobParametersBuilder.addString("fileDesc", this.obligacionNura);
			jobParametersBuilder.addString("mediosPagosVAR",  this.mediosPagosVAR);
			jobParametersBuilder.addString("obligacionesVAR", this.obligacionesVAR);
			jobParametersBuilder.addString("obligacionNura",  this.obligacionNura);
			jobParametersBuilder.addString("cronArray", this.cronArray);
			jobParametersBuilder.addString("nombreReporte",  this.reportName);
			jobParametersBuilder.addString("nombreReporteConsolidado",  this.reportNameConsolidado);
			jobParametersBuilder.addString("unifier", this.unifier);
			jobParametersBuilder.addString("joname",  STEP_NAME);
			jobParametersBuilder.addString("nJob",  parcial);
			jobParametersBuilder.addString("tipoAsobancaria",  "2011");	
			jobParametersBuilder.addDate("date", new Date());
			logger.info("::: Termina Generacion de parametros para reporte parcial ::: Numero ::: {}",parcial);

			jobExecution = jobLauncher.run(jobInstance, jobParametersBuilder.toJobParameters());
			
		} catch (Exception ex) {
			jobExecution = null;
			logger.error("Error ejecutando :\n{}", ex);
		}
		return jobExecution;
	}
	
	/**
	 * Genera el reporte cifrado.
	 * 
	 * @return 
	 * 		Step
	 **/
	private Step encriptPGP() {
		return stepBuilderFactory.get(TASKLET_NAME)
				.tasklet(this.encriptPGPTasklet)
				.build();
	}
	

}
