package co.com.ath.pgw.batch;


import java.io.File;

import javax.annotation.PostConstruct;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.batch.core.configuration.annotation.StepScope;
import org.springframework.batch.item.file.FlatFileItemReader;
import org.springframework.batch.item.file.mapping.BeanWrapperFieldSetMapper;
import org.springframework.batch.item.file.mapping.DefaultLineMapper;
import org.springframework.batch.item.file.transform.FixedLengthTokenizer;
import org.springframework.batch.item.file.transform.Range;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.io.FileSystemResource;
import org.springframework.stereotype.Service;

import co.com.ath.pgw.dto.FileLine;
/**
 * Reader del batch de destokenizacion
 *
 * @author Jesus Octavio Avenda�o Sierra <jesus.avendano@sophossolutions.com> 
 * @version 1.0 16/15/2019
 * 
 * @sophosSolutions
 * <strong>Autor: </strong>Jesus Octavio Avenda�o Sierra</br>
 * <strong>Numero de Cambios: </strong>0</br>
 * 	
*/
@Service
@StepScope
public class FileLineReader extends FlatFileItemReader<FileLine>{
	
	private static final Logger logger = LoggerFactory.getLogger(FileLineReader.class);
	
	@Value("#{jobParameters[filePath]}")
	private String filePath;
		
	@Value("#{jobParameters[fileName]}")
	private String fileName;

	@Value("#{jobParameters[fileType]}")
	private String fileType;

	@Value("#{jobParameters[fileId]}")
	private String fileId;

	@Value("#{jobParameters[fileDesc]}")
	private String fileDesc;
	
	@Value(value = "${initialCharTokenCommission}")
	private int initialCharTokenCommission;
	
	@Value(value = "${finalCharTokenCommission}")
	private int finalCharTokenCommission;
	
	@Value(value = "${initialCharTokenCollection}")
	private int initialCharTokenCollection;
	
	@Value(value = "${finalCharTokenCollection}")
	private int finalCharTokenCollection;

	@Value(value = "${stringCompareCommission}")
	private String stringCompareCommission;
	
	@Value(value = "${stringComparecollection}")
	private String stringComparecollection;
	
	/**
	 * Inicia la lectura por linea.
	 *
	 * @author Jesus Octavio Avenda�o Sierra <jesus.avendano@sophossolutions.com> 
	 * @version 1.0 16/15/2019
	*/
	@PostConstruct
	public void init() { 
		this.setName("FileLineReader");
		this.setResource(new FileSystemResource(new File(this.filePath, this.fileName)));
		this.setEncoding("utf8");
		this.setLineMapper(this.lineMapper());
	}
	
	private DefaultLineMapper<FileLine> lineMapper(){
		DefaultLineMapper<FileLine> defaultLineMapper = new DefaultLineMapper<FileLine>();
		defaultLineMapper.setFieldSetMapper(this.beanWrapperFieldSetMapper());
		if(this.fileType.equals(this.stringComparecollection)) {//Recaudo o Comision
			defaultLineMapper.setLineTokenizer(this.tokenizerCollection());
		}else if(this.fileType.equals(this.stringCompareCommission)){
			defaultLineMapper.setLineTokenizer(this.tokenizerCommission());
		}
		return defaultLineMapper;
	}
	
	private BeanWrapperFieldSetMapper<FileLine> beanWrapperFieldSetMapper() {
		BeanWrapperFieldSetMapper<FileLine> beanWrapperFieldSetMapper = new  BeanWrapperFieldSetMapper<FileLine>();
		beanWrapperFieldSetMapper.setTargetType(FileLine.class);
		return beanWrapperFieldSetMapper;
	}
	
	/**
	 * Tokenizer para recaudos.
	 *
	 * @author Jesus Octavio Avenda�o Sierra <jesus.avendano@sophossolutions.com> 
	 * @version 1.0 16/15/2019
	*/
	private FixedLengthTokenizer tokenizerCollection() {
		FixedLengthTokenizer fixedLengthTokenizer = new FixedLengthTokenizer();
		String[] names = {
				"firstChar",
				"beforeToken",
				"token",
				"afterToken",
		};

		Range[] ranges = {
				new Range(1, 1), 
				new Range(2, (this.initialCharTokenCollection-1)),
				new Range(this.initialCharTokenCollection, this.finalCharTokenCollection),
				new Range(this.finalCharTokenCollection+1)
		};
		
		fixedLengthTokenizer.setNames(names);
		fixedLengthTokenizer.setColumns(ranges);
		return fixedLengthTokenizer;
	}
	
	/**
	 * Tokenizer para comisiones.
	 *
	 * @author Jesus Octavio Avenda�o Sierra <jesus.avendano@sophossolutions.com> 
	 * @version 1.0 16/15/2019
	*/
	private FixedLengthTokenizer tokenizerCommission() {
		FixedLengthTokenizer fixedLengthTokenizer = new FixedLengthTokenizer();
		String[] names = {
				"firstChar",
				"beforeToken",
				"token",
				"afterToken",
		};

		Range[] ranges = {
				new Range(1, 1), 
				new Range(2, (this.initialCharTokenCommission-1)),
				new Range(this.initialCharTokenCommission, this.finalCharTokenCommission),
				new Range(this.finalCharTokenCommission+1)
		};
		
		fixedLengthTokenizer.setNames(names);
		fixedLengthTokenizer.setColumns(ranges);
		return fixedLengthTokenizer;
	}
		
}