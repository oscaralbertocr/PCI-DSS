/*
 * CommonObjectOutDTO
 *  
 * GSI - Integración
 * Creado el: 20/09/2014
 *
 * Copyright (c) A Toda Hora S.A. Todos los derechos reservados
 * 
 * Este software es confidencial y es propietario de ATH, queda prohibido
 * su uso, reproducción y copia de manera parcial o permanente salvo autorización
 * expresa de A Toda Hora S.A o de quién represente sus derechos.
 */
package co.com.ath.pgw.dto;

/**
 * DTO que contiene los objetos comunes pra la información de salida.
 * 
 * @author Andrés Méndez Juanias <proveedor_mamendez@ath.com.co>
 */
public class CommonObjectOutDTO  {
    
    /** Identificador único del mensaje. */
    protected Long rqUID;
    
    /** Código de respuesta. */
    protected Integer statusCode;
    
    /** Mensaje descriptivo. */
    protected String statusDesc;

	/**
	 * Metodo encargado de recuperar el identificador unico del mensaje.
	 * @return El identificador único del mensaje..
	 */
	public Long getRqUID() {
		return rqUID;
	}

	/**
	 * Metodo encargado de actualizar el identificador unico del mensaje.
	 * @param rqUID Nuevo valor para el identificador unico del mensaje.
	 */
	public void setRqUID(Long rqUID) {
		this.rqUID = rqUID;
	}

	/**
	 * Metodo encargado de recuperar el codigo de respuesta.
	 * @return El codigo de respuesta.
	 */
	public Integer getStatusCode() {
		return statusCode;
	}

	/**
	 * Metodo encargado de actualizar el codigo de respuesta.
	 * @param statusCode Nuevo valor para el codigo de respuesta.
	 */
	public void setStatusCode(Integer statusCode) {
		this.statusCode = statusCode;
	}

	/**
	 * Metodo encargado de recuperar el mensaje descriptivo.
	 * @return El mensaje descriptivo.
	 */
	public String getStatusDesc() {
		return statusDesc;
	}

	/**
	 * Metodo encargado de actualizar el mensaje descriptivo.
	 * @param statusDesc Nuevo valor para el mensaje descriptivo.
	 */
	public void setStatusDesc(String statusDesc) {
		this.statusDesc = statusDesc;
	}

}
