package co.com.ath.pgw.batch;

import java.util.Calendar;
import java.util.GregorianCalendar;

import javax.annotation.PostConstruct;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.batch.core.Job;
import org.springframework.batch.core.JobExecution;
import org.springframework.batch.core.JobParametersBuilder;
import org.springframework.batch.core.Step;
import org.springframework.batch.core.configuration.annotation.JobBuilderFactory;
import org.springframework.batch.core.configuration.annotation.StepBuilderFactory;
import org.springframework.batch.core.launch.JobLauncher;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.task.SimpleAsyncTaskExecutor;
import org.springframework.core.task.TaskExecutor;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;

/**
 * Configuración del proceso 
 * 
 * Batch para la destokenizacion de los reportes.
 *
 * @author Jesus Octavio Avendaño Sierra <jesus.avendano@sophossolutions.com> 
 * @version 1.0 16/15/2019
 * 
 * @sophosSolutions
 * <strong>Autor: </strong>Jesus Octavio Avendaño Sierra</br>
 * <strong>Numero de Cambios: </strong>0</br>
 * 
 * * @sophosSolutions
 * <strong>Autor: </strong>Nelly Rocio Linares</br>
 * <strong>Version </strong>1.1</br>
 * 	
 */
@Service
public class BatchConfiguration {

	@Autowired(required=true)
	private JobBuilderFactory jobBuilderFactory;

	@Autowired(required=true)
	private StepBuilderFactory stepBuilderFactory;

	@Autowired(required=true)
	private JobLauncher jobLauncher;

	@Autowired(required=true)
	private FileLineReader fileLineReader;

	@Autowired(required=true)
	private FileLineProcessor fileLineProcessor;

	@Autowired(required=true)
	private FileLineWriter fileLineWriter;

	@Autowired(required=true)
	private EncriptPGPTasklet encriptPGPTasklet;
	
	
	@Autowired(required=true)
	private GenerateReportTasklet generateReportTasklet;

	@Autowired(required = true)
	private FileLines fileLines;

	// Inicio. Version 1.1
	@Autowired(required=true)
	private ProcessFinalFileTasket processFinalFileTasket;
	// Final. Version 1.1
	
	@Value("${report.mediosPagosVAR}")
	private String mediosPagosVAR;

	@Value("${report.obligacionesVAR}")
	private String obligacionesVAR;
	
	@Value("${report.obligacionNura}")
	private String obligacionNura;
	
	@Value(value = "${pathDownload}")
	private String pathDownload;

	@Value(value = "${pathLiquidacion}")
	private String pathLiquidacion;	
	
	@Value(value = "${report.name}")
	private String reportName;	

	private static final Logger logger = LoggerFactory.getLogger(BatchConfiguration.class);

	private Job job;

	private static final String JOB_NAME = "DETOKENIZATION";

	private static final String TASKLET_NAME = "ENCRIPT_PGP"; 
	
	private static final String RECAUDO ="Recaudoobligacion.";

	@PostConstruct
	public void init() {
		this.job = this.createJob();
	}

	/**
	 * Sonda encargada de destokenizar los reportes.
	 * 
	 * @param fileName
	 *            Nombre del archivo.
	 *
	 * @param filePath
	 *            Ruta donde se encuetra el archivo especificado.
	 *
	 * @param fileType
	 *            Tipo de archivo (Recaudo, Comision).
	 * 
	 **/
	@Scheduled(cron="${reportAsobancariaCron}")
	public void run() {
		logger.info("::: Activacion de cron :::");
		JobParametersBuilder jobParametersBuilder = this.generateParameters();
		this.executeJob(jobParametersBuilder);
	}

	/**
	 * Ejecuta el Job del batch.
	 * 
	 * @return 
	 * 		JobExecution
	 **/
	private JobExecution executeJob(JobParametersBuilder jobParams) {

		logger.info("::: executeJob empezando Job :::");
		JobExecution jobExecution;
		try {
			fileLines.inicializar();
			jobExecution = this.jobLauncher.run(this.job, jobParams.toJobParameters());
		} catch (Exception e) {
			jobExecution = null;
			logger.error("Error ejecutando el job: {}",e);
		}
		return jobExecution;
	}

	/**
	 * Genera el job del batch.
	 * 
	 * @return 
	 * 		Job
	 **/
	private Job createJob() {
		return this.jobBuilderFactory.get(JOB_NAME)
				.flow(this.generateReport())
//				.next(this.detokenizationLines())
//				.next(this.processFileFinal())  // Version.1.1
				.next(this.encriptPGP())
				.end()
				.build();
	}

	private Step generateReport() {
		return stepBuilderFactory.get("GENERAR_REPORT_TASKLET")
				.tasklet(this.generateReportTasklet)
				.build();
	}

	/**
	 * Genera el step del job.
	 * 
	 * @return 
	 * 		Step
	 **/
	private Step encriptPGP() {
		return stepBuilderFactory.get(TASKLET_NAME)
				.tasklet(this.encriptPGPTasklet)
				.build();
	}

	// Inicio.Version.1.1
	public TaskExecutor taskExecutor(){
		SimpleAsyncTaskExecutor asyncTaskExecutor=new SimpleAsyncTaskExecutor("spring_batch");
		asyncTaskExecutor.setConcurrencyLimit(4);
		return asyncTaskExecutor;
	}

	// Final.Version.1.1

	/**
	 * Genera el objeto jobParametersBuilder con los parametros requeridos.
	 * 
	 * @param fileName
	 *            Nombre del archivo.
	 *
	 * @param filePath
	 *            Ruta donde se encuetra el archivo especificado.
	 *
	 * @param fileType
	 *            Tipo de archivo (Recaudo, Comision).
	 * 
	 **/
	private JobParametersBuilder generateParameters() {
		Calendar fecha = new GregorianCalendar();
		logger.info("::: Generando parametros :::");
		JobParametersBuilder jobParametersBuilder = new JobParametersBuilder();
		jobParametersBuilder.addLong("time", System.currentTimeMillis());
		jobParametersBuilder.addString("rqUID", "132");
		jobParametersBuilder.addString("channel", "132");
		jobParametersBuilder.addString("iPAddr", "132");
		String mesActual = (((fecha.get(Calendar.MONTH)+1)>9) ? Integer.toString(fecha.get(Calendar.MONTH)+1) : ("0"+(fecha.get(Calendar.MONTH)+1)));
		String diaActual = (((fecha.get(Calendar.DAY_OF_MONTH))>9) ? Integer.toString(fecha.get(Calendar.DAY_OF_MONTH)) : ("0"+fecha.get(Calendar.DAY_OF_MONTH)));
		String fechaActual = diaActual + mesActual + fecha.get(Calendar.YEAR);
		jobParametersBuilder.addString("fileName",  RECAUDO+fechaActual+".TXT");
		jobParametersBuilder.addString("filePath", this.pathDownload);
		jobParametersBuilder.addString("fileNameLiquidacion",  "BOCC_Pagos_PortalDePagos_20190813.DAT");
		jobParametersBuilder.addString("filePathLiquidacion", this.pathLiquidacion);
		jobParametersBuilder.addString("fileType", "2");
		jobParametersBuilder.addString("fileNameIn", RECAUDO+fechaActual+".TXT");
		jobParametersBuilder.addString("fileNameOut", RECAUDO+fechaActual+".TXT.PGP");
		jobParametersBuilder.addString("fileId", "2");
		jobParametersBuilder.addString("fileDesc", this.obligacionNura);
		jobParametersBuilder.addString("mediosPagosVAR",  this.mediosPagosVAR);
		jobParametersBuilder.addString("obligacionesVAR", this.obligacionesVAR);
		jobParametersBuilder.addString("obligacionNura",  this.obligacionNura);
		jobParametersBuilder.addString("nombreReporte",  this.reportName);
		jobParametersBuilder.addString("reportDate",  fechaActual);
		jobParametersBuilder.addString("contingencia", "0");
		logger.info("::: Parametros Generados :::");
		return jobParametersBuilder;
	}


}
