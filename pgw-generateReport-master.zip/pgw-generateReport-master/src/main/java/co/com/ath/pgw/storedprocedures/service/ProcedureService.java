package co.com.ath.pgw.storedprocedures.service;

import java.sql.SQLException;
import java.util.Date;

public interface ProcedureService {
	
	public void generateReportRecaudos(String obligaciones, String name) throws SQLException;
	
	public void generateReportRecaudosCont(String obligaciones, String name, String horaInicio, String horaFin, int unifier, String fecha) throws SQLException;
	
	public void generateReportLiquidacion(String pathReport,String idBanco, String tipoReporte, String fechaInicial, String fechaFinal) throws SQLException;
	
	public void generateReportRecaudosParcialesCont (String obligaciones, String name, String horaInicio, String horaFin, int unifier, String fecha, boolean intermedio) throws SQLException;
	
	public void generateReportRecaudosParciales(String obligaciones, String name, String horaInicio, String horaFin, int unifier, boolean partial234) throws SQLException;
	
	public void generateReportRecaudosBogota(String obligaciones, String name, int tokenizar, Date fecha) throws SQLException; 
	public void generateReportBIPXC(String name)throws SQLException;

}


