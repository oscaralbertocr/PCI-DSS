package co.com.ath.pgw.batch;

import java.io.File;
import java.util.List;

import javax.annotation.PostConstruct;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.batch.core.configuration.annotation.StepScope;
import org.springframework.batch.item.file.FlatFileItemWriter;
import org.springframework.batch.item.file.transform.DelimitedLineAggregator;
import org.springframework.batch.item.file.transform.FieldExtractor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.io.FileSystemResource;
import org.springframework.core.io.Resource;
import org.springframework.stereotype.Service;

import co.com.ath.pgw.dto.FileLine;

/**
 * Writer del batch de destokenizacion
 *
 * @author Jesus Octavio Avenda�o Sierra <jesus.avendano@sophossolutions.com>
 * @version 1.0 16/15/2019
 * 
 * @sophosSolutions <strong>Autor: </strong>Jesus Octavio Avenda�o Sierra</br>
 *                  <strong>Numero de Cambios: </strong>0</br>
 *                  
 * @sophosSolutions <strong>Autor: </strong>Nelly Rocio Linares</br>
 *  <strong>Version </strong>1.1</br>
 * 
 */

@Service
@StepScope
public class FileLineWriter extends FlatFileItemWriter<FileLine> {

	private static final Logger logger = LoggerFactory.getLogger(FileLineWriter.class);

	@Value("#{jobParameters[filePath]}")
	private String filePath;

	@Value("#{jobParameters[fileName]}")
	private String fileName;
	
	@Value("#{jobParameters[fileId]}")
	private String fileId;

	@Value("#{jobParameters[fileDesc]}")
	private String fileDesc;

//	@Value(value = "${pathCreateDetokenizateFile}")
	private String pathCreateDetokenizateFile;
	
	@Value(value = "${pathCreateDetokenizateReportAsobancaria}")
	private String pathCreateDetokenizateReportAsobancaria;

	@Autowired(required = true)
	private FileLines fileLines;

	@PostConstruct
	public void init() {
		Resource resource;
		if(this.fileId == "2") {
			resource = new FileSystemResource(new File(pathCreateDetokenizateReportAsobancaria.concat("\\"+this.fileDesc), 
														this.fileName));
		}else {
			resource = new FileSystemResource(new File(pathCreateDetokenizateFile, this.fileName));			
		}

		this.setResource(resource);
		this.setLineAggregator(this.delimitedLineAggregator());
	}

	DelimitedLineAggregator<FileLine> delimitedLineAggregator() {
		DelimitedLineAggregator<FileLine> delimitedLineAggregator = new DelimitedLineAggregator<FileLine>();
		delimitedLineAggregator.setDelimiter("");
		delimitedLineAggregator.setFieldExtractor(new FieldExtractor<FileLine>() {

			@Override
			public Object[] extract(FileLine item) {
				
				return new Object[] { item.getFirstChar(), item.getBeforeToken(), item.gettoken(),
						item.getAfterToken() };
			}
		});
		return delimitedLineAggregator;
	}

	// Inicio.version 1.1
	@Override
	public void write(List<? extends FileLine> items) throws Exception {
	
		for (FileLine linea : items) {
			fileLines
					.put(linea.getFirstChar() + linea.getBeforeToken() + linea.gettoken() + linea.getAfterToken());
		}
		super.write(items);
	}
	// Final.version 1.1
}