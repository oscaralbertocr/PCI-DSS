package co.com.ath.pgw.batch.ReporteBIPXC;

import java.util.Date;

import javax.annotation.PostConstruct;
import javax.annotation.Resource;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.batch.core.Job;
import org.springframework.batch.core.JobExecution;
import org.springframework.batch.core.JobParametersBuilder;
import org.springframework.batch.core.Step;
import org.springframework.batch.core.configuration.annotation.JobBuilderFactory;
import org.springframework.batch.core.configuration.annotation.StepBuilderFactory;
import org.springframework.batch.core.launch.JobLauncher;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.task.SimpleAsyncTaskExecutor;
import org.springframework.core.task.TaskExecutor;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import co.com.ath.pgw.batch.EncriptPGPTasklet;
import co.com.ath.pgw.batch.GenerateReportTasklet;
import co.com.ath.pgw.util.AesCifer;
import co.com.ath.pgw.util.Parametro;


/**
 * Configuración del proceso 
 * 
 * Batch para generacion de reportes BIPXC.
 *
 * @author Dario Hernandez Rojas <dario.hernandez@sophossolutions.com> 
 * @version 1.0 03/17/2021
 
 */
@Service
public class BIPXCReportBatchContingencia {


	@Autowired(required=true)
	private JobBuilderFactory jobBuilderFactory;

	@Autowired(required=true)
	private StepBuilderFactory stepBuilderFactory;

	@Autowired(required=true)
	private JobLauncher jobLauncher;

	@Autowired(required=true)
	private EncriptPGPTasklet encriptPGPTasklet;
	
	@Autowired(required=true)
	private EncryptTasklet encryptTasklet;
	
	@Autowired(required=true)
	private GenerateReportTasklet generateReportTasklet;
	
	@Autowired
	private AesCifer tripleDes;
	
	@Resource
	private Parametro parametro;
	
	@Value(value = "${report.BIPXC}")
	private String reportName;
	
	@Value(value = "${pathReportContingencyBIPXC}")
	private String pathDownload;

	@Value(value = "${pathKeyPublicPgpBIPXC}")
	private String pathKeyPublicPgpBIPXC;
	
	@Value(value = "${pathKeyPrivatePgpBIPXC}")
	private String pathKeyPrivatePgpBIPXC;
	
	@Value(value = "${pathCollectionContingenciaBIPXCFTP}")
	private String pathCollectionFTP;
	
	private static final Logger logger = LoggerFactory.getLogger(BIPXCReportBatch.class);

	private Job job;

	private static final String JOB_NAME = "BIPXCReportBatch";

	private static final String TASKLET_NAME = "ENCRIPT_PGP"; 
	
	private final String stepEncrypt = "CipherFirmFile";
	
	@PostConstruct
	public void init() {
		this.job = this.createJob();
	}

	

	/**
	 * Genera el job del batch.
	 * 
	 * @return 
	 * 		Job
	 **/
	private Job createJob() {
		return this.jobBuilderFactory.get(JOB_NAME)
				.flow(this.generateReport())
				.next(this.cipherTask())
				.end()
				.build();
	}

	private Step generateReport() {
		return stepBuilderFactory.get("GENERAR_REPORT_TASKLET")
				.tasklet(this.generateReportTasklet)
				.build();
	}

	/**
	 * Genera el step del job.
	 * 
	 * @return 
	 * 		Step
	 **/
	private Step encriptPGP() {
		return stepBuilderFactory.get(TASKLET_NAME)
				.tasklet(this.encriptPGPTasklet)
				.build();
	}

	private Step cipherTask() {
		return this.stepBuilderFactory.get(this.stepEncrypt)
				.tasklet(this.encryptTasklet)
				.build();
	}
	
	
	// Inicio.Version.1.1
	public TaskExecutor taskExecutor(){
		SimpleAsyncTaskExecutor asyncTaskExecutor=new SimpleAsyncTaskExecutor("spring_batch");
		asyncTaskExecutor.setConcurrencyLimit(4);
		return asyncTaskExecutor;
	}

	// Final.Version.1.1

	@Transactional(propagation = Propagation.NOT_SUPPORTED)
	public void automaticRun() {
		
		
		try {			
			
			logger.info("Reporte de BIMediosPagoXConvenio de contingencia");
			executeJobContingencia();

			
		} catch (Exception e) {
			logger.error("Error no esperado iniciando la generacion del reporte de BIMediosPagoXConvenio contingencia: \n{}", e);
		}	
	}
	/**
	 * Genera el objeto jobParametersBuilder con los parametros requeridos.
	 * 
	 * @param fileName
	 *            Nombre del archivo.
	 *
	 * @param filePath
	 *            Ruta donde se encuetra el archivo especificado.
	 *
	 * @param fileType
	 *            Tipo de archivo (Recaudo, Comision, JFK, BIPXC).
	 * 
	 **/

	private JobExecution executeJobContingencia() {
		JobExecution jobExecution;
		try {
		logger.info("::: Generando parametros para reporte BIMediosPagoXConvenio ::: ");
		JobParametersBuilder jobParametersBuilder = new JobParametersBuilder();
		jobParametersBuilder.addString("filePath", this.pathDownload);
		jobParametersBuilder.addString("fileType", "2");
		jobParametersBuilder.addString("pathCollectionFTP", this.pathCollectionFTP);
		jobParametersBuilder.addString("keyPublicPGP", this.pathKeyPublicPgpBIPXC);
		jobParametersBuilder.addString("secretKeyFile", this.pathKeyPrivatePgpBIPXC);
		jobParametersBuilder.addString("frassSecretKey", obtenerParametro("frassSecretKeyBIPXC"));
		jobParametersBuilder.addString("fileId", "4");
		jobParametersBuilder.addString("contingencia", "1");
		jobParametersBuilder.addString("fecha", "");
		jobParametersBuilder.addString("nombreReporte",  this.reportName);
		jobParametersBuilder.addString("joname",  JOB_NAME);
		jobParametersBuilder.addDate("date", new Date());
		logger.info("::: Termina Generacion de parametros para reporte BIMediosPagoXConvenio :::");
		jobExecution = jobLauncher.run(job, jobParametersBuilder.toJobParameters());
		
		} catch (Exception ex) {
			jobExecution = null;
			logger.error("Error ejecutando :\n{}", ex);
		}
		return jobExecution;
		}
	
	/**
	 * Metodo que consulta parametros de la BD
	 * @param nombreParametro
	 * @return
	 */
	public String obtenerParametro(String nombreParametro) {
		String result = "";
		try {
			result = tripleDes.decrypt(parametro.getParametro(nombreParametro));
			
		} catch (Exception e) {
			logger.error("Error consultando parametro. {}",e);
		}
		return result;
	}

}
