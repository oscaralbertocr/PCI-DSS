package co.com.ath.pgw.srv;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.batch.core.configuration.annotation.EnableBatchProcessing;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.scheduling.annotation.EnableScheduling;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import co.com.ath.pgw.dto.GenericErrorResponse;
import co.com.ath.pgw.dto.RequestTransferService;
import co.com.ath.pgw.mapper.MapperResponseTransferService;
import co.com.ath.pgw.service.impl.DetokenizationServiceImplementation;
import co.com.ath.pgw.util.CustomException;

/**
 * Facade del servicio. 
 *
 *
 * @author Jesus Octavio Avendaño Sierra <jesus.avendano@sophossolutions.com> 
 * @version 1.0 16/15/2019
 * 
 * @sophosSolutions
 * <strong>Autor: </strong>Jesus Octavio Avendaño Sierra</br>
 * <strong>Numero de Cambios: </strong>0</br>
 * 	
*/

@EnableBatchProcessing
@EnableScheduling
@RestController
@RequestMapping(value ="/transferManagement")
public class TransferManagementFacade {
	
	@Autowired
	private DetokenizationServiceImplementation detokenizationServiceImplementation;

	private static final Logger logger = LoggerFactory.getLogger(TransferManagementFacade.class);
	
	@RequestMapping(value = "/initTransfer" , method = RequestMethod.POST)
	public ResponseEntity<Object> initTransfer(
			@RequestHeader("X-RqUID") Long rqUID,
    		@RequestHeader("X-Channel") String channel,
    		@RequestHeader("X-IPAddr") String iPAddr,
			@RequestBody RequestTransferService requestTransferService) {
		logger.info("@initTransfer input \n {}", requestTransferService);
		
		ResponseEntity<Object> response;
		GenericErrorResponse genericErrorResponse;
		try {
			detokenizationServiceImplementation.run(requestTransferService);
			response = new MapperResponseTransferService().responseTransferService(HttpStatus.NO_CONTENT, null);
		} catch(CustomException e) {
			genericErrorResponse = MapperResponseTransferService.mapperResponseErrorCore(e);
			response = new MapperResponseTransferService().responseTransferService(HttpStatus.PARTIAL_CONTENT, genericErrorResponse);
			logger.info("@initTransfer error output \n{}", genericErrorResponse);
		} catch (Exception e) {
			genericErrorResponse = MapperResponseTransferService.mapperResponseErrorCore(e);
			response = new MapperResponseTransferService().responseTransferService(HttpStatus.INTERNAL_SERVER_ERROR, genericErrorResponse);
			logger.info("@initTransfer error output \n{}", genericErrorResponse);
		}
		return response;
	}
}
