
package co.com.ath.pgw.client.tokenize.dto;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlSeeAlso;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Clase Java para ProtectExt_Type complex type.
 * 
 * <p>El siguiente fragmento de esquema especifica el contenido que se espera que haya en esta clase.
 * 
 * <pre>
 * &lt;complexType name="ProtectExt_Type"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element ref="{urn://ath.com.co/xsd/common/}Data"/&gt;
 *         &lt;element ref="{urn://ath.com.co/xsd/common/}Format" minOccurs="0"/&gt;
 *         &lt;element ref="{urn://ath.com.co/xsd/common/}StrRefine" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "ProtectExt_Type", propOrder = {
    "data",
    "format",
    "strRefine"
})
@XmlSeeAlso({
    ProtectType.class
})
public class ProtectExtType {

    @XmlElement(name = "Data", required = true, namespace = "urn://ath.com.co/xsd/common/")
    protected String data;
    @XmlElement(name = "Format", namespace = "urn://ath.com.co/xsd/common/")
    protected String format;
    @XmlElement(name = "StrRefine", namespace = "urn://ath.com.co/xsd/common/")
    protected String strRefine;

    /**
     * Obtiene el valor de la propiedad data.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getData() {
        return data;
    }

    /**
     * Define el valor de la propiedad data.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setData(String value) {
        this.data = value;
    }

    /**
     * Obtiene el valor de la propiedad format.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getFormat() {
        return format;
    }

    /**
     * Define el valor de la propiedad format.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setFormat(String value) {
        this.format = value;
    }

    /**
     * Obtiene el valor de la propiedad strRefine.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getStrRefine() {
        return strRefine;
    }

    /**
     * Define el valor de la propiedad strRefine.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setStrRefine(String value) {
        this.strRefine = value;
    }

}
