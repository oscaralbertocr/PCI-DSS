package co.com.ath.pgw.batch;

import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Component;


/**
 * Clase para manejar los registros del archivo
 * @author SophosSolutions . Nelly Linares
 * @version 1.0
 */
@Component
public class FileLines {

	private List<String> list = new ArrayList<String>();
	
	public void put(String valor) {
		list.add(valor);
		
	}
	
	public void inicializar() {
		list.clear();
	}
	
	public List<String> getList(){
		return list;
	}
	
	
	
}
