package co.com.ath.pgw.util;

public interface Constants {

	public static final String TIMEZONE = "America/Bogota";
	
	public static final Integer ERROR_STATUS_CODE_300 = 300;
	
	public static final String ERROR_STATUS_CODE_DESC = "No es posible procesar la transacci�n.";
	
	public static final String SERVICE_TOKENIZE_VOLTAGE = "VOLTAGE";
	public static final String SERVICE_TOKENIZE_GEMALTO = "GEMALTO";
	public static final int CURSOR = -10;
	
	public static final String extFileCipher = ".PGP";
	public static final String HEADER_LOG = "*******************************************************************";
	

	public static final String SP_REPORTE_RECAUDOS = "{ call pkg_reportes.sp_generar_reporte_recaudos(?, ?, ?, ?) }";
	public static final String SP_REPORTE_RECAUDOS_CONTINGENCIA = "{ call pkg_reportes.sp_generar_reporte_recaudos(?, ?, ?, ?, ?, ?, ?, ?) }";
	public static final String SP_REPORTE_RECAUDOS_PARCIALES_CONTINGENCIA = "{ call pkg_reportes.sp_generar_reporte_recaudos(?, ?, ?, ?, ?, ?, ?, ?) }";
	public static final String SP_REPORTE_RECAUDOS_PARCIALES = "{ call pkg_reportes.sp_generar_reporte_recaudos(?, ?, ?, ?, ?, ?, ?) }";
	public static final String SP_REPORTE_RECAUDOS_PARCIALES_234 = "{ call pkg_reportes.sp_generar_reporte234_recaudos(?, ?, ?, ?, ?, ?, ?) }";
	public static final String SP_REPORTE_LIQUIDACION = "{ call pkg_reportes.sp_generar_reporte_liquidacion(?, ?, ?, ?, ?, ?, ?, ?) }";
	public static final String SP_REPORTE_RECAUDOS_JFK = "{ call pkg_reportes.sp_generar_reporte_JFK(?, ?, ?, ?, ?, ?, ?) }";
	public static final String SP_REPORTE_RECAUDOS_JFK_INTERMEDIO = "{ call pkg_reportes.sp_generar_JFK_intermedio(?, ?, ?, ?, ?, ?, ?) }";	
	public static final String SP_REPORTE_RECAUDOS_JFK_CONTINGENCIA = "{ call pkg_reportes.sp_generar_reporte_JFK(?, ?, ?, ?, ?, ?, ?, ?) }";
	public static final String SP_REPORTE_RECAUDOS_JFK_INTERMEDIO_CONTINGENCIA = "{ call pkg_reportes.sp_generar_JFK_intermedio(?, ?, ?, ?, ?, ?, ?, ?) }";	
	public static final String SP_REPORTE_BIPXC = "{ call pkg_reportes.sp_generar_reporte_bipxc(?,?,?) }";
	public static final String SEPARADOR = "\\";
	public static final String LOG_HEADER = "*******************************************************************";
	public static final String SP_REPORTE_RECAUDOS_BOGOTA = "{ call pkg_reportes.sp_generar_recaudos_bogota(?, ?, ?, ?, ?, ?) }";

	public static final String URL_AUTORIZACION_USER = "/pgw-services/usuarios/user/";
	public static final String URL_PARAMETRO = "/pgw-services/rest/parametro/{clave}";
	public static final String URL_LISTA = "/pgw-services/rest/parametro/lista";
	public static final String PAR_SBTM_2020 = "58TM_47H_2020_PR0C3551N6";

}
