package co.com.ath.pgw.batch.recaudos;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.batch.core.StepContribution;
import org.springframework.batch.core.configuration.annotation.StepScope;
import org.springframework.batch.core.scope.context.ChunkContext;
import org.springframework.batch.core.step.tasklet.Tasklet;
import org.springframework.batch.repeat.RepeatStatus;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import co.com.ath.pgw.util.ConectionFTP;
import co.com.ath.pgw.util.PGPFileProcessor;
import co.com.ath.pgw.util.Utils;




@Service
@StepScope
public class EncryptTaskletBogota implements Tasklet{
	
	

	@Value("#{jobParameters[fileNameOutput]}")
	private String fileNameOutput;
	
	@Value("#{jobParameters[keyPublicPGP]}")
	private String keyPublicPGP;
	
	@Value("#{jobParameters[secretKeyFile]}")
	private String secretKeyFile;
	
	@Value("#{jobParameters[frassSecretKey]}")
	private String frassSecretKey;
	
	
	@Value("#{jobParameters[reportDate]}")
	private String reportDate; 
	
		@Value("#{jobParameters[pathCollectionFTP]}")
	private String pathCollectionFTP;
		
	@Value("#{jobParameters[basePath]}")
	private String basePath;
	
	
	@Value("#{jobParameters[filePath]}")
	private String pathReportBIPXC;
	
	@Value("#{jobParameters[fileNameRecaudosBogotaTC]}")
	private String nameBogotaTC;
	
	@Value("#{jobParameters[filePathTC]}")
	private String filePathTC;
	
	@Value("#{jobParameters[fullPathTC]}")
	private String fullPathTC;
	
	@Value("#{jobParameters[cifradoBogota]}")
	private String cifradoBogota;
	
	@Value("#{jobParameters[ftpNameTC]}")
	private String ftpNameTC;
	
	
	@Autowired
	ConectionFTP conectionFTP;
	
	@Autowired(required = true)
	Utils util;  
	 
	static Logger logger = LoggerFactory.getLogger(EncryptTaskletBogota.class);

	@Override
	public RepeatStatus execute(StepContribution contribution, ChunkContext chunkContext) {
		PGPFileProcessor pgpFileProcessor = new PGPFileProcessor();
			try {
				////////////////////////////////////////////////////////////////
				String pathSFTP = "";
				//String nameReport = nombreReporte;	
				String fileReport="";	
				String outputFileName ="";
				
				fileReport = filePathTC + "\\" + nameBogotaTC;
				pgpFileProcessor.setInputFileName( fullPathTC);
				pgpFileProcessor.setOutputFileName(fullPathTC + cifradoBogota);
				pgpFileProcessor.setSecretKeyFileName(this.secretKeyFile);
				pgpFileProcessor.setRing(this.frassSecretKey);
				pgpFileProcessor.setPublicKeyFileName(this.keyPublicPGP);
				
				if (pgpFileProcessor.signEncrypt()) {
					logger.info("Se encripto y firmo correctamente el archivo :{}",	fileReport);
					outputFileName = fileReport + cifradoBogota;
					pathSFTP = this.pathCollectionFTP.concat("/"+ftpNameTC);
					conectionFTP.conectar(fullPathTC+cifradoBogota, pathSFTP);
				}else {
					throw new Exception("Encrypt and signature Fail");
				}
			} catch (Exception e) {
				logger.error(e.getMessage());
				logger.error("Error al tratar de encriptar y cifrar el archivo a PGP o en el FTP: {}", this.fileNameOutput);
				logger.error(e.toString());
			}
		return RepeatStatus.FINISHED;
	}
	
}

