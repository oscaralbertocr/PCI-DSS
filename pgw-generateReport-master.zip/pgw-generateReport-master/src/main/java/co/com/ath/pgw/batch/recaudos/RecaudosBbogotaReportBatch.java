package co.com.ath.pgw.batch.recaudos;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

import javax.annotation.PostConstruct;
import javax.annotation.Resource;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.batch.core.Job;
import org.springframework.batch.core.JobExecution;
import org.springframework.batch.core.JobParametersBuilder;
import org.springframework.batch.core.Step;
import org.springframework.batch.core.configuration.annotation.JobBuilderFactory;
import org.springframework.batch.core.configuration.annotation.StepBuilderFactory;
import org.springframework.batch.core.launch.JobLauncher;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;

import co.com.ath.pgw.batch.GenerateReportTasklet;
import co.com.ath.pgw.util.AesCifer;
import co.com.ath.pgw.util.Parametro;

@Service
public class RecaudosBbogotaReportBatch {
	
	private static final Logger logger = LoggerFactory.getLogger(RecaudosBbogotaReportBatch.class);

	/**
	 * constructor del job
	 */
	@Resource
	private JobBuilderFactory jobBuilderFactory;
	/**
	 * constructor del Step
	 */
	@Resource
	private StepBuilderFactory stepBuilderFactory;
	/**
	 * job Launcher
	 */
	@Resource
	private JobLauncher jobLauncher;
	/**
	 * instanciamiento del Job
	 */
	private Job jobInstance;
	/**
	 * nombre del Job
	 */
	private static final String JOB_NAME = "RECAUDOS_BOGOTA_REPORT_JOB";
	/**
	 * nombre del Step
	 */
	private static final String STEP_NAME = "GENERATE_RECAUDOS_BOGOTA_REPORT_STEP";
	/**
	 * Variable para el cifrado del reporte
	 */
	private static final String TASKLET_NAME = "ENCRIPT_PGP";
	
	@Autowired(required=true)
	private GenerateReportTasklet generateReportTasklet;
	
	@Autowired(required=true)
	private EncryptTaskletBogota encriptPGPTasklet;
	
	@Autowired
	private AesCifer tripleDes;
	
	@Resource
	private Parametro parametro;
	
	@Value(value = "${pasarela.tarjeta_credito.bogota}")
	private String tcBogotaNura;
	
//	@Value(value = "${pasarela.otros_creditos.bogota}")
	private String ocBogotaNura;
	
//	@Value(value = "${pasarela.llavepgp.tarjeta_credito.bogota}")
//	private String llaveTc;
	
//	@Value(value = "${pasarela.llavepgp.otros_creditos.bogota}")
	private String llaveOc;
	
	@Value(value = "${pasarela.ruta.tarjeta_credito.bogota}")
	private String pathTc;
	
//	@Value(value = "${pasarela.ruta.otros_creditos.bogota}")
	private String pathOc;
	
	@Value(value = "${pasarela.name.tarjeta_credito.bogota}")
	private String nameReportTc;
	
//	@Value(value = "${pasarela.name.otros_creditos.bogota}")
	private String nameReportOc;
	
	@Value(value = "${pasarela.cifradoRecaudosBogota}")
	private String cifrado;
	
	@Value(value = "${pasarela.ftpName.tarjeta_credito.bogota.bogota}")
	private String folder;
	
	@Value(value = "${pasarela.llavepgp.tarjeta_credito.bogota}")
	private String pathKeyPublicPgpBBTA;
	
	@Value(value = "${pasarela.llavefirma.tarjeta_credito.bogota}")
	private String pathKeyPrivatePgpBBTA;

	@Value(value = "${pathCollectionFTP.tarjeta_credito.bogota}")
	private String pathCollectionFTP;
	
	String lsNameTC = "";
	String lsNameOC = "";

	@PostConstruct
	public void init() {
		jobInstance = createJob();
	}
	
	private Job createJob() {
		return jobBuilderFactory.get(JOB_NAME)
				.flow(generateReportStep())
				.next(this.encriptPGP())
				.end()
				.build();
	}
	
	private Step generateReportStep() {
		return stepBuilderFactory.get(STEP_NAME)
				.tasklet(this.generateReportTasklet)
				.build();
	}

	private Step encriptPGP() {
		return stepBuilderFactory.get(TASKLET_NAME)
				.tasklet(this.encriptPGPTasklet)
				.build();
	}
	
	/**
	 * Metodo encargado de ejecutar el reporte diario
	 */
	@Scheduled(cron="${pasarela.cron.bogota}")
	public void run() {
		logger.info("::: Activacion de cron :::");
		Calendar calendar = Calendar.getInstance();
		Date curDate = calendar.getTime();
		
		try {
			logger.info("Reporte BBOGOTATC");
		
			lsNameTC = getFileName(nameReportTc.split("%"),curDate);			
			//lsNameOC = getFileName(nameReportOc.split("%"),curDate);

			executeJob();

		} catch (Exception ex) {
			logger.error("Error no esperado iniciando la generacion de archivos de TCBOGOTA: \n{}", ex);
		}
	}
	
	/**
	 * Metodo encargado de cargar las variables para el reporte
	 * @param fileName
	 * @param DateStart
	 * @param DateEnd
	 * @param avalBank
	 * @return
	 */
	private JobExecution executeJob() {
		JobExecution jobExecution;
		try {
			JobParametersBuilder jobParams = new JobParametersBuilder();
			jobParams.addLong("time", System.currentTimeMillis());
			jobParams.addString("rqUID", "132");
			jobParams.addString("channel", "132");
			jobParams.addString("iPAddr", "132");			
			jobParams.addString("fileType", "5");
			jobParams.addString("fileId", "5");
			jobParams.addString("pathCollectionFTP", this.pathCollectionFTP);
			jobParams.addString("keyPublicPGP", this.pathKeyPublicPgpBBTA);
			jobParams.addString("secretKeyFile", this.pathKeyPrivatePgpBBTA);
			jobParams.addString("frassSecretKey", obtenerParametro("frassSecretKeyBBTA"));
			jobParams.addString("cifradoBogota", this.cifrado);
			jobParams.addString("ftpNameTC", this.folder);
			jobParams.addString("fileNameRecaudosBogotaTC", lsNameTC);
			jobParams.addString("fileNameRecaudosBogotaOC", lsNameOC);
			jobParams.addString("nuraTC",  tcBogotaNura);
			jobParams.addString("nuraOC",  ocBogotaNura);
			jobParams.addString("filePathTC", pathTc);
			jobParams.addString("filePathOC", pathOc);
			jobParams.addString("contingenciaBogota", "0");
			jobParams.addString("llaveBogotaOC", llaveOc);
			jobParams.addString("fullPathTC", pathTc+"\\"+lsNameTC);			
			jobParams.addString("fullPathOC", pathOc+"\\"+lsNameOC);
			jobParams.addString("joname",  STEP_NAME);
			jobParams.addDate("date", new Date());

			jobExecution = jobLauncher.run(jobInstance, jobParams.toJobParameters());
			
		} catch (Exception ex) {
			jobExecution = null;
			logger.error("Error ejecutando :\n{}", ex);
		}
		return jobExecution;
	}	
	
	private String getFileName(String[]param,Date currentDate) {
		SimpleDateFormat format;
			format = new SimpleDateFormat(param[1]);
			
		return param[0]+format.format(currentDate)+param[2];
	}
	
	/**
	 * Metodo que consulta parametros de la BD
	 * @param nombreParametro
	 * @return
	 */
	public String obtenerParametro(String nombreParametro) {
		String result = "";
		try {
			result = tripleDes.decrypt(parametro.getParametro(nombreParametro));
			
		} catch (Exception e) {
			logger.error("Error consultando parametro. {}",e);
		}
		return result;
	}
	
}
