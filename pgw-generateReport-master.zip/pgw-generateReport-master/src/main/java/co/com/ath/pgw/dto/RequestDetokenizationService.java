package co.com.ath.pgw.dto;


/**
 * DTO Peticion al servcio de destokenizacion (Proveedor externo)
 *
 *
 * @author Jesus Octavio Avendaño Sierra <jesus.avendano@sophossolutions.com> 
 * @version 1.0 16/15/2019
 * 
 * @sophosSolutions
 * <strong>Autor: </strong>Jesus Octavio Avendaño Sierra</br>
 * <strong>Numero de Cambios: </strong>0</br>
 * 	
*/
public class RequestDetokenizationService {
	
	private String naeUser;
	
	private String naePassword;
	
	private String token;
	
	private String format;
	
	private String keyName;
	
	
	public RequestDetokenizationService() {
	}
	
	public RequestDetokenizationService(String naeUser, String naePassword, String token, String format,
			String keyName) {
		this.naeUser = naeUser;
		this.naePassword = naePassword;
		this.token = token;
		this.format = format;
		this.keyName = keyName;
	}
	
	/**
    *
    *@return el naeUser
    */
	public String getNaeUser() {
		return naeUser;
	}
	/**
    *
    *@param naeUser
    */
	public void setNaeUser(String naeUser) {
		this.naeUser = naeUser;
	}
	/**
    *
    *@return el nae
    */
	public String getNaePassword() {
		return naePassword;
	}
	/**
    *
    *@param nae
    */
	public void setNaePassword(String naePassword) {
		this.naePassword = naePassword;
	}
	/**
    *
    *@return el token
    */
	public String getToken() {
		return token;
	}
	/**
    *
    *@param token
    */
	public void setToken(String token) {
		this.token = token;
	}
	/**
    *
    *@return el formato
    */
	public String getFormat() {
		return format;
	}
	/**
    *
    *@param format
    */
	public void setFormat(String format) {
		this.format = format;
	}
	/**
    *
    *@return el keyName
    */
	public String getKeyName() {
		return keyName;
	}
	/**
    *
    *@param keyName
    */
	public void setKeyName(String keyName) {
		this.keyName = keyName;
	}
	
	
		
}
