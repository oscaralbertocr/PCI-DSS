package co.com.ath.pgw.dto;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonProperty;

import co.com.ath.pgw.util.XMLUtil;




/**
 * DTO Peticion incial. Activa el servicio transfer.
 *
 *
 * @author Jesus Octavio Avendaño Sierra <jesus.avendano@sophossolutions.com> 
 * @version 1.0 16/15/2019
 * 
 * @sophosSolutions
 * <strong>Autor: </strong>Jesus Octavio Avendaño Sierra</br>
 * <strong>Numero de Cambios: </strong>0</br>
 * 	
*/

public class RequestTransferService implements Serializable{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	@JsonProperty("File")
	private File file;
	
	/**
    *
    *@param fileName
    *			Establece el nombre del archivo
    */
	public void setFile(File File) {
		this.file = File;
	}
	
	/**
    *
    *@return el nombre del archivo
    */
	public File getFile() {
		return this.file;
	}
	
	@Override
	public String toString() {
		XMLUtil<RequestTransferService> util = new XMLUtil<RequestTransferService>();
		return util.convertObjectToJson(this);
	}
	
}