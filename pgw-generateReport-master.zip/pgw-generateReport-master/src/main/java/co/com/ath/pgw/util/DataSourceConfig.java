package co.com.ath.pgw.util;

import java.sql.Connection;

import javax.naming.InitialContext;
import javax.sql.DataSource;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

@Service
public class DataSourceConfig {
	
	private static final Logger logger = LoggerFactory.getLogger(DataSourceConfig.class);
	
	   public Connection conexionBD(){
		   
		   Connection connection = null;
           InitialContext initialContext = null;
           DataSource dataSource = null;
           try {
				initialContext = new InitialContext();
				dataSource = (DataSource) initialContext.lookup("jdbc/pgwDS");
				connection = dataSource.getConnection();
				logger.info("::: SE REALIZA LA CONEXION AL DATASOURCE :::");
           } catch (Exception e) {
        	   logger.error("::: SE PRESENTARION PROBLEMAS AL OBTENER EL DATA SOURCE ::: {} ", e);
           }
		return connection;
                    
     }

}
