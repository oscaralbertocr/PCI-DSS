package co.com.ath.pgw.util;

import java.util.Arrays;
import java.util.Collection;
import java.util.HashMap;
import java.util.Iterator;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.client.RestTemplate;

import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;

import co.com.ath.pgw.dto.ResponseDetokenizationService;


public class AbstractRestClient {
	
	private static final Logger logger = LoggerFactory.getLogger(AbstractRestClient.class);
	
	public String consumeRest(String constantPathURL, Object request, HttpMethod method, HashMap<String, String> headersMap) throws Exception {
		String response = "";
		String urlInsertAuditLog = constantPathURL;
		
		RestTemplate restTemplate = new RestTemplate();
		HttpHeaders headers = new HttpHeaders();
		headers.setContentType(MediaType.APPLICATION_JSON);
		headers.setAccept(Arrays.asList(MediaType.APPLICATION_JSON));
		
		if(headersMap != null && !headersMap.isEmpty()) {
			Iterator<String> iterator = headersMap.keySet().iterator();
			while(iterator.hasNext()) {
				String llave = iterator.next();
				String value = headersMap.get(llave);
				headers.set(llave, value);
			}
		}
		
		try {
			HttpEntity<Object> entity = new HttpEntity<Object>(request, headers);
			ResponseEntity<ResponseDetokenizationService> responseEntity = restTemplate.exchange(urlInsertAuditLog, method, entity, ResponseDetokenizationService.class);
			logger.info("StatusCode from Service: {}", responseEntity.getStatusCode());
			if (responseEntity.getStatusCode() == HttpStatus.OK || responseEntity.getStatusCode() == HttpStatus.PARTIAL_CONTENT || responseEntity.getStatusCode() == HttpStatus.INTERNAL_SERVER_ERROR)
				response = responseEntity.getBody().getValue();
		} catch(Exception e) {
			logger.error("Error al tratar de conectar con el cliente de detokenizacion: {}", e);
			throw new Exception(e.getMessage());
		}
		
		return response;
	}

	/**
	 * Valida si un objeto dado esta vacio o nulo
	 * @param object Objeto a ser validado
	 * @return true - si el objeto es vacio o nulo, false si el objeto tiene algún valor
	 */
	public static boolean isObjectEmpty(Object object) {
		if(object == null) return true;
		else if(object instanceof String) {
			if (((String)object).trim().length() == 0) {
				return true;
			}
		} else if(object instanceof Collection) {
			return isCollectionEmpty((Collection<?>)object);
		}
		return false;
	}
	
	/**
	 * Valida si un objeto de tipo Collection es vacio o nulo
	 * @param collection objeto a ser validad
	 * @return
	 */
	private static boolean isCollectionEmpty(Collection<?> collection) {
		if (collection == null || collection.isEmpty()) {
			return true;
		}
		return false;
	}
	
	public String convertToJson(Object object) {
		String jsonInString = "";
		if (!isObjectEmpty(object)) {
			ObjectMapper mapper = new ObjectMapper();
			// Ignore null field in serialization
			mapper.setSerializationInclusion(Include.NON_NULL);
			try {
				jsonInString = mapper.writeValueAsString(object);
			} catch (JsonProcessingException jsonProcessingException) {
				jsonInString = "";
			}
		}
		jsonInString = jsonInString.replace('"', ' ');

		return jsonInString;

	}
	
	
}
