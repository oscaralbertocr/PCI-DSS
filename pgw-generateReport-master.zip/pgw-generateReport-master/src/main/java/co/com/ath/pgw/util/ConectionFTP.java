package co.com.ath.pgw.util;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.util.HashMap;

import javax.annotation.Resource;

import org.apache.commons.net.ftp.FTPSClient;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import com.jcraft.jsch.Channel;
import com.jcraft.jsch.ChannelSftp;
import com.jcraft.jsch.JSch;
import com.jcraft.jsch.JSchException;
import com.jcraft.jsch.Session;
import com.jcraft.jsch.SftpATTRS;
import com.jcraft.jsch.SftpException;




/**
 * 
 * Clase para enviar un archivo por SFTP.
 *
 * @author Jesus Octavio Avendaño Sierra <jesus.avendano@sophossolutions.com>
 * @version 1.0 08/05/2019
 * 
 * 
 * @PCI 
 * <strong>Autor: </strong>Jesus Octavio Avendaño Sierra</br>
 * <strong>Fecha: </strong>23/07/2019</br>
 * <strong>Descripcion: </strong>Se agrega el envio del archivo por FTP</br>
 * <strong>Numero de Cambios: </strong>3</br>
 * <strong>Identificador corto: </strong>C01</br>
 * 
 **/

@Service
public class ConectionFTP {

	@Value(value = "${pasarela.ftp.host}")
	private String host;

	private String user;

	private String password;

	@Value(value = "${pasarela.ftp.basePath}")
	private String basePath;
	
	@Value(value = "${pasarela.ftp.port}")
	private int port;
	@Resource
	private Parametro parametro;
	@Autowired
	private AesCifer tripleDes;
	
	private static final Logger logger = LoggerFactory.getLogger(ConectionFTP.class);
	
	public ConectionFTP() {		

	}
	
	/**	
	 * 	
	 * Constructor de la conexion	
	 * 	
	 * @param host el servidor al que se conectara	
	 * @param user	el usuario con el se realizara la conexion	
	 * @param basePath ruta origen del servidor	
	 * @param contrase�a del usuario	
	 */
	public ConectionFTP(String host, String user, String basePath, String password) {	
	this.host = host;	
	this.user = user;	
	this.basePath = basePath;	
	this.password = password;	
}

	/**
	 * 
	 * Metodo encargado de conectar al SSH (SFTP) y enviar el reporte de baloto.
	 * @author Nelly Rocio Linares
	 * @param fileName
	 * @param directorio
	 * @throws Exception 
	 */
	public void conectar(String fileName, String directorio) throws Exception  {
		Session session = null;
		Channel channel = null;
		ChannelSftp channelSftp = null;
		String pathFinal = basePath + directorio;
		JSch jsch = new JSch();
		try {
			logger.info("ConectionFTP vSP");
			logger.info("Iniciando conexion FTP, se tratara de enviar el archivo: {}", fileName);
			logger.info("Ruta: {}", directorio);
			user = tripleDes.decrypt(parametro.getParametro("pasarelaftpuser"));
			password = tripleDes.decrypt(parametro.getParametro("pasarelaftppassword"));
			session = jsch.getSession(user, host, port);//C01
			session.setPassword(password);

			java.util.Properties config = new java.util.Properties();
			config.put("StrictHostKeyChecking", "no");
			session.setConfig(config);

			session.connect();

			channel = session.openChannel("sftp");
			channel.connect();

			logger.info("Conectado al FTP ");
			channelSftp = (ChannelSftp) channel;

			SftpATTRS attrs = null;
			
				attrs = channelSftp.stat(pathFinal);
			
			if (attrs != null) {
				logger.info("Directory exists IsDir= {}", attrs.isDir());
			} else {
				logger.info("Creating dir {}", basePath);
				channelSftp.mkdir(pathFinal);
			}

			channelSftp.cd(pathFinal);

			File f = new File(fileName);
			channelSftp.put(new FileInputStream(f), f.getName());

		} catch (SftpException e) {
			logger.error("Error para conectarse al ftp SftpException {}", e.getMessage());

		} catch (FileNotFoundException e) {
			logger.error("El archivo no se encuentra en la ruta {}", e.getMessage());
		} catch (JSchException e) {
			logger.error("Error para conectarse al ftp JSchException {}", e.getMessage());
		} catch (Exception e) {
			logger.error("Excepcion {} ", e.getMessage());
			
		} finally {
			if (channelSftp != null) {
				channelSftp.exit();
			}
			if(channel != null) {
				channel.disconnect();
			}
			if(session != null) {
				session.disconnect();
			}
			logger.info("Host Session disconnected.");
		}

	}
	
	//C01
	/**
	 * Metodo encargado de conectar al FTP y enviar el reporte de baloto.
	 * @author Jesus Octavio Avendaño
	 * @Idmodificación C01
	 * @return Step
	 */
	public void uploadReportFTP(String fileName, String directorio) {
		FTPSClient ftp = new FTPSClient("TLS");
		File file = new File(fileName);
		String pathFinal = basePath + directorio;
		try {
			ftp.connect(host,port);
			String user = tripleDes.decrypt(parametro.getParametro("pasarelaftpuser"));
			String password = tripleDes.decrypt(parametro.getParametro("pasarelaftppassword"));
			if(ftp.login(user, password)) {
				logger.info("Conexion con el FTP Correcta");
				ftp.enterLocalPassiveMode();
				ftp.changeWorkingDirectory(pathFinal);
				ftp.storeFile(file.getName(), new FileInputStream(file));
				ftp.disconnect();
			}else{
				logger.info("Conexion Fallida");
			}
		} catch (Exception e) {
			logger.error("Error para conectarse al ftp {}", e);
		}finally {
			file = null;
			ftp = null;
		}
	}
	
	public String getHost() {
		return host;
	}

	public void setHost(String host) {
		this.host = host;
	}

	public String getUser() {
		return user;
	}

	public void setUser(String user) {
		this.user = user;
	}

	public String getBasePath() {
		return basePath;
	}

	public void setBasePath(String basePath) {
		this.basePath = basePath;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}
	
	
	/**
	 * 
	 * Metodo encargado de conectar al SSH (SFTP) y enviar el reporte de baloto.
	 * @author Nelly Rocio Linares
	 * @param fileName
	 * @param directorio
	 * @throws Exception 
	 */
	public void conectar(HashMap<String, String> archivos) throws Exception  {
		Session session = null;
		Channel channel = null;
		ChannelSftp channelSftp = null;
		JSch jsch = new JSch();
		try {
			
			logger.info("Iniciando conexion FTP");			
			user = tripleDes.decrypt(parametro.getParametro("pasarelaftpuser"));
			password = tripleDes.decrypt(parametro.getParametro("pasarelaftppassword"));
			session = jsch.getSession(user, host, port);//C01
			session.setPassword(password);

			java.util.Properties config = new java.util.Properties();
			config.put("StrictHostKeyChecking", "no");
			session.setConfig(config);

			session.connect();

			channel = session.openChannel("sftp");
			channel.connect();

			logger.info("Conectado al FTP ");
			channelSftp = (ChannelSftp) channel;
			
			
			for (HashMap.Entry<String, String> entry : archivos.entrySet()) {
				try {			    
			    logger.info("Iniciando conexion FTP, se tratara de enviar el archivo: {}", entry.getKey());
			    logger.info("Ruta: {}", entry.getValue());
			    
			    String pathFinal = null;
			    pathFinal = basePath + entry.getValue();
			    
			    SftpATTRS attrs = null;
				
				attrs = channelSftp.stat(pathFinal);
				
				
				if (attrs != null) {
					logger.info("Directory exists IsDir= {}", attrs.isDir());
				} else {
					logger.info("Creating dir {}", basePath);
					channelSftp.mkdir(pathFinal);
				}
				
				
				channelSftp.cd(pathFinal);

				File f = null;
				f =	new File(entry.getKey());
				channelSftp.put(new FileInputStream(f), f.getName());
			    
				} catch (FileNotFoundException e) {
					logger.error("El archivo no se encuentra en la ruta {}", e.getMessage());
				} catch (Exception e) {
					logger.error("Excepcion for envio de archivo al ftp {}", e.getMessage());
				}
			    
			}			

		} catch (SftpException e) {
			logger.error("Error para conectarse al ftp SftpException {}", e.getMessage());

		} catch (FileNotFoundException e) {
			logger.error("El archivo no se encuentra en la ruta {}", e.getMessage());
		} catch (JSchException e) {
			logger.error("Error para conectarse al ftp JSchException {}", e.getMessage());
		} catch (Exception e) {
			logger.error("Excepcion {} ", e.getMessage());
			
		} finally {
			if (channelSftp != null) {
				channelSftp.exit();
			}
			if(channel != null) {
				channel.disconnect();
			}
			if(session != null) {
				session.disconnect();
			}
			logger.info("Host Session disconnected.");
		}

	}

}
