package co.com.ath.pgw.dto;

import co.com.ath.pgw.util.XMLUtil;
import com.fasterxml.jackson.annotation.JsonProperty;


/**
 * DTO Repsuesta a la llamada del servicion transfer.
 *
 *
 * @author Jesus Octavio Avendaño Sierra <jesus.avendano@sophossolutions.com> 
 * @version 1.0 16/15/2019
 * 
 * @sophosSolutions
 * <strong>Autor: </strong>Jesus Octavio Avendaño Sierra</br>
 * <strong>Numero de Cambios: </strong>0</br>
 * 	
*/
public class ResponseTransferService {

	@JsonProperty("Result")
	private String result;
	
	/**
    *
    *@param result
    *			resultado de la transaccion
    */
	public void setResult(String result){
		this.result = result;
	}
	
	/**
    *
    *@return el resultado de la peticion.
    */
	public String getResult() {
		return this.result;
	}
	
	public ResponseTransferService() {}
	
	public ResponseTransferService(String result) {
		this.setResult(result);
	}
	
	@Override
	public String toString() {
		XMLUtil<ResponseTransferService> util = new XMLUtil<ResponseTransferService>();
		return util.convertObjectToJson(this);
	}
	
}
