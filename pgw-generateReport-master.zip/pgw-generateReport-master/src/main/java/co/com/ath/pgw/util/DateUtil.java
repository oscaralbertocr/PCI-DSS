package co.com.ath.pgw.util;

import java.sql.Timestamp;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;

import javax.xml.datatype.DatatypeConfigurationException;
import javax.xml.datatype.DatatypeFactory;
import javax.xml.datatype.XMLGregorianCalendar;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

/**
 * Utilidades de conversión para fechas
 * @author proveedor_cjmurillo
 * @version 1.0
 * @since 1.0
 */
@Service
public class DateUtil {

	private static final Logger logger = LoggerFactory.getLogger(DateUtil.class);
	
	/**
	 * Convierte de Date a XMLGregorianCalendar
	 * @param inn
	 * @return
	 */
    public static XMLGregorianCalendar toXMLGregorianCalendar(Date inn){
    	if(inn == null) { return null; }
        GregorianCalendar gCalendar = new GregorianCalendar();
        gCalendar.setTime(inn);
        XMLGregorianCalendar xmlCalendar = null;
        try {
            xmlCalendar = DatatypeFactory.newInstance().newXMLGregorianCalendar(gCalendar);
        } catch (DatatypeConfigurationException ex) {
            logger.error("Error conviertiendo valores. {}" ,ex);
        }
        return xmlCalendar;
    }
  
   
    /**
     * Convierte de XMLGregorianCalendar a Date
     * @param inn
     * @return
     */
    public static Date toDate(XMLGregorianCalendar inn){
        if(inn == null) { return null; }
        return inn.toGregorianCalendar().getTime();
    }
    
	/**
	 * Retorna la fecha en el formato dado.
	 * 
	 * @param date
	 * @param format
	 * @return
	 */
	public static String parseDate(Date date, String format) {
		
		String returnDate;
		try {
			SimpleDateFormat simpleDateFormat = new SimpleDateFormat(format);
			returnDate = simpleDateFormat.format(date);
		} catch (Exception e) {
			logger.error("No fue posible formatear la fecha:{} formato: {}", date, format);
			return null;
		}

		return returnDate;
	}
	
	public static Date parseString(String date, String format) {
		Date returnDate;
		try {
			SimpleDateFormat simpleDateFormat = new SimpleDateFormat(format);
			returnDate = simpleDateFormat.parse(date);
		} catch (Exception e) {
			logger.error("No fue posible formatear la fecha:{} formato: {}", date, format);
			return null;
		}
		return returnDate;
	}
	
	/*
	 * Metodo que devuelve la hora en formato 24H con milisegundos
	 * 
	 * 
	 * 
	 * */
	public String TimeFull24() {
		return Hora() + ":" + Minuto() + ":" + Segundo() + "." + Milisegundo() ;
		}
	public static  String Hora() {
		Calendar calendario = new GregorianCalendar();
		if (String.valueOf(calendario.get(Calendar.HOUR_OF_DAY)).length() == 2) {
			
		return String.valueOf(calendario.get(Calendar.HOUR_OF_DAY));
		} else {
		return "0" + String.valueOf(calendario.get(Calendar.HOUR_OF_DAY));
		}
		}
	public String Minuto() {
		Calendar calendario = new GregorianCalendar();
		if (String.valueOf(calendario.get(Calendar.MINUTE)).length() == 2) {
		return String.valueOf(calendario.get(Calendar.MINUTE));
		} else {
		return "0" + String.valueOf(calendario.get(Calendar.MINUTE));
		}
		}
	public String Segundo() {
		Calendar calendario = new GregorianCalendar();
		if (String.valueOf(calendario.get(Calendar.SECOND)).length() == 2) {
		return String.valueOf(calendario.get(Calendar.SECOND));
		} else {
		return "0" + String.valueOf(calendario.get(Calendar.SECOND));
		}
		}
	public String Milisegundo() {
		Calendar calendario = new GregorianCalendar();
		return String.valueOf(calendario.get(Calendar.MILLISECOND));
	}
	
	/**
	 * M�todo encargado de combinar la fecha y la hora.
	 * @param date
	 * @return
	 * @throws ParseException
	 */
	public Timestamp mergeDate(Date date, String hora) throws ParseException {

        Calendar cal = Calendar.getInstance();
		StringBuilder sb = new StringBuilder();
		cal.setTime(date);
		sb.append(cal.get(Calendar.YEAR));
        sb.append("-");
		sb.append(cal.get(Calendar.MONTH)+1);
        sb.append("-");
		sb.append(cal.get(Calendar.DAY_OF_MONTH));
		sb.append(" ");
		sb.append(hora);
		
		return Timestamp.valueOf(sb.toString());
		
	}
	
}

