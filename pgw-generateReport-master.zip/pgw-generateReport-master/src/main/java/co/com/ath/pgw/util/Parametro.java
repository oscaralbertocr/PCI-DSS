package co.com.ath.pgw.util;



import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.json.JSONException;
import org.json.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestClientException;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;

import co.com.ath.pgw.dto.ParametroDTO;



@Service
public class Parametro {
	private static final Logger LOGGER = LoggerFactory.getLogger(Parametro.class);
	/**
	 * pathAutorizacion
	 */
	@Value(value = "${pasarela.batch.autorizacion}")
	private  String autorizacion;
	/**
	 * pathParametro
	 */
	@Value(value = "${pasarela.batch.parametro}")
	private  String parametro;
	
	/**
	 * @param clave
	 * @return
	 */
	public  String getParametro(String clave) throws Exception{
		try {
			
			String uriPermiso = this.autorizacion;
			String uriParametro = this.parametro;

			HttpHeaders headers = new HttpHeaders();
			headers.setContentType(MediaType.APPLICATION_JSON);
			headers.set("Authorization", getToken(uriPermiso));

			HttpEntity request = new HttpEntity(headers);
			RestTemplate plantilla = new RestTemplate();
			ResponseEntity<ParametroDTO> response = plantilla.exchange(uriParametro, HttpMethod.GET, request,
					ParametroDTO.class, clave);

			if (response.getStatusCode() == HttpStatus.OK) {
				ParametroDTO parametro = response.getBody();
				return parametro.getValor();
			}
		} catch (Exception e) {
			throw new Exception("Error al tratar de obtener el parametro identificado con la clave: " + clave);
		}
		return null;
	}

	/**
	 * @param clave
	 * @return
	 */
	public static List<ParametroDTO> getParametros(String[] parametrosArray)throws Exception {
		
		try {
			String path = getPathContext();
			String uriPermiso = path + Constants.URL_AUTORIZACION_USER;
			String uriParametro = path + Constants.URL_LISTA;

			HttpHeaders headers = new HttpHeaders();
			headers.setContentType(MediaType.APPLICATION_JSON);
			headers.set("Authorization", getToken(uriPermiso));
			
			HttpEntity<Object> request = new HttpEntity<Object>(parametrosArray, headers);

			RestTemplate plantilla = new RestTemplate();
			
			ResponseEntity<List<ParametroDTO>> response = plantilla.exchange(uriParametro, HttpMethod.POST, request,new ParameterizedTypeReference<List<ParametroDTO>>() {});
			if (response.getStatusCode() == HttpStatus.OK) {
				List<ParametroDTO> parametros = response.getBody();
				return parametros;
			}
		} catch (Exception e) {
			
			throw new Exception("Error al tratar de obtener la lista de parametros ");
		}
		return null;
	}

	/**
	 * @return
	 */
	private static String getToken(String uri)throws Exception {
		String token;
		try {
			token = "";

			JSONObject usuario = new JSONObject();
			usuario.put("User", "AuthParametros");

			HttpHeaders headers = new HttpHeaders();
			headers.setContentType(MediaType.APPLICATION_JSON);

			HttpEntity<String> request = new HttpEntity<String>(usuario.toString(), headers);

			RestTemplate plantilla = new RestTemplate();
			token = plantilla.postForObject(uri, request, String.class);
		} catch (Exception e) {
		
			throw new Exception("Se presentaron problemas para obtener el Token");
		}
		return token;
	}

	/**
	 * @return
	 */
	public static String getPathContext()throws Exception {
		try {
			String ip = "";
			HttpServletRequest request = ((ServletRequestAttributes) RequestContextHolder.currentRequestAttributes())
					.getRequest();
			if (request.getProtocol().contains("HTTP")) {
				ip="HTTP://" +request.getLocalAddr()+":"+request.getLocalPort();
			} else {
			       ip ="HTTPS://" +request.getLocalAddr()+":"+request.getLocalPort();
			}
			return ip;
		} catch (Exception e) {
			throw new Exception("Se presentaron problemas para obtener el contexto de la Api");
		}

	}

}
