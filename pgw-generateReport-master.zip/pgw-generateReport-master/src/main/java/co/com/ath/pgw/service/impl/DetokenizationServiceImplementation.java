package co.com.ath.pgw.service.impl;


import java.io.File;

import javax.annotation.Resource;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import co.com.ath.pgw.batch.ComisionReportBatch;
import co.com.ath.pgw.batch.ReporteBIPXC.BIPXCReportBatchContingencia;
import co.com.ath.pgw.batch.partial.AsobancariaPartialReportBatch;
import co.com.ath.pgw.batch.ContingenciaAsobancaria;
import co.com.ath.pgw.batch.partial.AsobancariaPartialReportBatchContingencia;
import co.com.ath.pgw.batch.partial.jfk.JfkPartialReportBatchContingencia;
import co.com.ath.pgw.batch.recaudos.RecaudosBbogotaReportBatchContingencia;
import co.com.ath.pgw.dto.RequestTransferService;
import co.com.ath.pgw.service.DetokenizationService;
import co.com.ath.pgw.util.AesCifer;
import co.com.ath.pgw.util.CustomException;
import co.com.ath.pgw.util.FTPconnection;
import co.com.ath.pgw.util.Parametro;

/**
 * Servicio de destokenización. Ejecuta los procesos para descargar
 * destokenizar, y encriptar el archivo especificado por la peticion
 * entrante. 
 *
 *
 * @author Jesus Octavio Avendaño Sierra <jesus.avendano@sophossolutions.com> 
 * @version 1.0 16/15/2019
 * 
 * @sophosSolutions
 * <strong>Autor: </strong>Jesus Octavio Avendaño Sierra</br>
 * <strong>Numero de Cambios: </strong>0</br>
 * 	
*/ 
@Service
public class DetokenizationServiceImplementation implements DetokenizationService{
	@Resource
	private Parametro parametro;
	@Autowired
	private ComisionReportBatch batchLiquidacion;
	
	@Autowired
	private BIPXCReportBatchContingencia batchBIPXC;
	
	@Autowired
	private AsobancariaPartialReportBatchContingencia batchParcial;
	
	@Autowired
	private JfkPartialReportBatchContingencia batchJfkParcial;

	@Autowired
	private ContingenciaAsobancaria batchAsobancaria;
	
	
	@Autowired
	private AesCifer tripleDes;
	
	@Autowired
	private RecaudosBbogotaReportBatchContingencia recaudosBogota;
	
	public String getFileNameIn() {
		return this.fileNameIn;
	}
	
//	@Value(value = "${portFTP}")
	private String port;
	
//	@Value(value = "${hostFTP}")
	private String host;
	
	
	
	@Value(value = "${pathCommissionFTP}")
	private String pathCommissionFTP;
	
	@Value(value = "${pathCollectionFTP}")
	private String pathCollectionFTP;
	
	@Value(value = "${modeConnectionFtp}")
	private int modeConnectionFtp;

	@Value(value = "${pathDownload}")
	private String pathDownload;
	
	@Value(value = "${stringCompareCommission}")
	private String stringCompareCommission;
	
	@Value(value = "${stringComparecollection}")
	private String stringComparecollection;
	
	private static final Logger logger = LoggerFactory.getLogger(DetokenizationServiceImplementation.class);
	
	private RequestTransferService requestTransferService = null;
	private String fileNameIn = null;
	private String fileType = null;
	
	/**
	 *  Cosntructor
	 *  
	 *  @param requestTransferService 
	 *  			Cuerpo de la peticion. 
	 *  
	 */ 

	
	/**
	 *  Inicia el proceso de destokenizacion.
	 * @param requestTransferService2 
	 *  
	 */ 
	@Override
	public void run(RequestTransferService requestTransferService) throws CustomException, Exception {
			this.detokenization(requestTransferService);
	}
	
	/**
	 *  Descarga el archivo especificado en la peticiom, por FTP.
	 *  
	 */
	@Override
	public void dowloadFileFtp() throws CustomException, Exception {
		FTPconnection ftpconnection = null;
		try {
			String pathFTP = this.fileType.equals(this.stringCompareCommission) ? this.pathCommissionFTP : this.pathCollectionFTP;
			String user = tripleDes.decrypt(parametro.getParametro("pasarelaftpuser"));
			String password = tripleDes.decrypt(parametro.getParametro("pasarelaftppassword"));
			ftpconnection = new FTPconnection(this.host, user, password, pathFTP, this.port, this.modeConnectionFtp);
			if (ftpconnection.existsFile(this.fileNameIn)) {
				ftpconnection.downloadFile(this.pathDownload, this.fileNameIn);
				logger.info("::: Archivo descargado correctamente desde el FTP :::");
			} else {
				logger.info("::: El archivo no se encuentra disponible :::");
				throw new CustomException("El archivo no se encuentra disponible");
			}
		} catch (CustomException e) {
			throw new CustomException(e.getMessage());
		} catch (Exception e) {
			throw new Exception(e.getMessage());
		} finally {
			if(ftpconnection != null) {
				ftpconnection.close();
				ftpconnection = null;
			}
		}
	}
	
	/**
	 * Verifica si existe el archivo en la carpeta local
	*/
	public void existsFile() throws CustomException, Exception{
		try {
			File file = new File(this.pathDownload + "/" + this.fileNameIn);
			if (file.exists()) {
				logger.info("::: Archivo cargado correctamente desde la carpeta local :::");
			} else {
				logger.error("::: Archivo no encontrado en la carpeta local :::");
				throw new CustomException("Archivo no encontrado en la carpeta local");
			}
		} catch (CustomException e) {
			logger.error("::: Archivo no no existe en la carpeta local :::");
			throw new CustomException(e.getMessage());
			
		} catch (Exception e) {
			throw new Exception(e.getMessage());
		}
	}

	/**
	 *  Inicia el proceso de batch que se 
	 *  encarga de la lectura, destokenizacion, y 
	 *  escritura del archivo descargado.
	 * @param requestTransferService2 
	 *  
	 */
	@Override
	public void detokenization(RequestTransferService request) {

		logger.info("Iniciando servicio de batch");
		
		// 1 = liquidacion, 2 = recaudos 3=recaudos parciales
		if (request.getFile().getFileId().equals("1")) {
			batchLiquidacion.automaticRun(request.getFile().getFileType(), request.getFile().getFileName());
		} else if(request.getFile().getFileId().equals("2")){
			batchAsobancaria.automaticRun(request.getFile().getFileType(),request.getFile().getFileName(), request.getFile().getFileDesc());
		}else if (request.getFile().getFileId().equals("3")) {
			if (request.getFile().getFileDesc().equals("9506")) {
				batchParcial.automaticRun(request.getFile().getFileType(),request.getFile().getFileName());
			}else if (request.getFile().getFileDesc().equals("3878")) {
				batchJfkParcial.automaticRun(request.getFile().getFileType(),request.getFile().getFileName());
			}
		}else if (request.getFile().getFileId().equals("4")) {
			batchBIPXC.automaticRun();
		}else if (request.getFile().getFileId().equals("5")) {
			recaudosBogota.run(request.getFile().getFileName());
		}
		
		logger.info("Terminando servicio de batch");
	}

	public RequestTransferService getRequestTransferService() {
		return this.requestTransferService;
	}

	public void setRequestTransferService(RequestTransferService requestTransferService) {
		this.requestTransferService = requestTransferService;
	}

	@Override
	public void detokenization() {
		// Auto-generated method stub
		
	}

	@Override
	public void run() throws CustomException, Exception {
		// Auto-generated method stub
		
	}
	
}
