
package co.com.ath.pgw.dto;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonProperty;

public class AdditionalStatus implements Serializable {

	@JsonProperty("StatusCode")
	private String statusCode;
	@JsonProperty("StatusDesc")
	private String statusDesc;
	@JsonProperty("Severity")
	private String severity;
	private static final long serialVersionUID = -8949993428231959780L;

	public String getStatusCode() {
		return statusCode;
	}

	public void setStatusCode(String statusCode) {
		this.statusCode = statusCode;
	}
	
	public String getStatusDesc() {
		return statusDesc;
	}

	public void setStatusDesc(String statusDesc) {
		this.statusDesc = statusDesc;
	}

	public String getSeverity() {
		return severity;
	}

	public void setSeverity(String severity) {
		this.severity = severity;
	}

}
