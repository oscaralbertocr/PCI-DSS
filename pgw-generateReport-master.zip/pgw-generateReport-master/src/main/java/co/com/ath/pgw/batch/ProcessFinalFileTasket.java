package co.com.ath.pgw.batch;

import java.io.BufferedWriter;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.Collections;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.batch.core.StepContribution;
import org.springframework.batch.core.configuration.annotation.StepScope;
import org.springframework.batch.core.scope.context.ChunkContext;
import org.springframework.batch.core.step.tasklet.Tasklet;
import org.springframework.batch.repeat.RepeatStatus;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;


/**
 * Tasklet para realizar escribir el archivo destokenizado
 * @author SophosSolutions. Nelly Linares
 * @version 1.0
 */

@Service
@StepScope
public class ProcessFinalFileTasket implements Tasklet {

	@Autowired(required = true)
	private FileLines fileLines;

	@Value("#{jobParameters[fileNameIn]}")
	private String fileNameIn;

//	@Value(value = "${pathCreateDetokenizateFile}")
	private String pathCreateDetokenizateFile;

	private static final Logger logger = LoggerFactory.getLogger(ProcessFinalFileTasket.class);

	@Override
	public RepeatStatus execute(StepContribution contribution, ChunkContext chunkContext) throws Exception {

		
		String pathFinal = pathCreateDetokenizateFile + "\\" + fileNameIn;
		Path path = Paths.get(pathFinal);

		try {
			BufferedWriter fileWriter = Files.newBufferedWriter(path);

			List<String> listado = fileLines.getList();
			
			Collections.sort(listado);

			for (String pd : listado) {
				
				fileWriter.write(pd);
				fileWriter.newLine();

			}
			fileWriter.close();

		} catch (Exception e) {
			logger.error("Error al tratar de escribir el archivo: {} {}", this.fileNameIn, e);
		}
		return RepeatStatus.FINISHED;
	}

}
