package co.com.ath.pgw.mapper;

import java.util.Calendar;

import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import co.com.ath.pgw.dto.AdditionalStatus;
import co.com.ath.pgw.dto.GenericErrorResponse;
import co.com.ath.pgw.dto.MsgRsHdr;
import co.com.ath.pgw.dto.Status;
import co.com.ath.pgw.util.Constants;

/**
 * Mapper de la respuesta del servicio Transfer.
 *
 *
 * @author Jesus Octavio Avendaño Sierra <jesus.avendano@sophossolutions.com> 
 * @version 1.0 16/15/2019
 * 
 * @sophosSolutions
 * <strong>Autor: </strong>Jesus Octavio Avendaño Sierra</br>
 * <strong>Numero de Cambios: </strong>0</br>
 * 	
*/
public class MapperResponseTransferService {
	
	/**
	 * Retorna la respuesta a la peticion del servicio.
	 * @param requestInitTransfer
	 * 			Cuerpo de la petición del servicio.		
	 * @return ResponseTransferService
	*/
	public ResponseEntity<Object> responseTransferService(HttpStatus status, GenericErrorResponse genericErrorResponse) {
		HttpHeaders headers = new HttpHeaders();
		//headers.add("Status", String.valueOf("Error"));
		if(genericErrorResponse != null)
			return new ResponseEntity<Object>(genericErrorResponse, headers, status);
		else
			return new ResponseEntity<Object>(headers, status);
	}
	
	/**
	 * Metodo que mapea la respuesta no exitosa del core
	 * @param Exception
	 * @return GenericErrorResponse
	 */
	public static GenericErrorResponse mapperResponseErrorCore(Exception exception) {
		GenericErrorResponse genericErrorResponse = new GenericErrorResponse();
		
		Status status = new Status();
		status.setStatusCode(String.valueOf(Constants.ERROR_STATUS_CODE_300));
		status.setStatusDesc(Constants.ERROR_STATUS_CODE_DESC);
		status.setEndDt(Calendar.getInstance().getTime());
		
		AdditionalStatus additionalStatus = new AdditionalStatus();
		additionalStatus.setStatusCode(String.valueOf(Constants.ERROR_STATUS_CODE_300));
		additionalStatus.setStatusDesc(exception.getMessage());
		status.setAdditionalStatus(additionalStatus);
		
		MsgRsHdr msgRsHdr = new MsgRsHdr();
		msgRsHdr.setStatus(status);
		msgRsHdr.setEndDt(Calendar.getInstance().getTime());
		genericErrorResponse.setMsgRsHdr(msgRsHdr);
		
		return genericErrorResponse;
	}
	
}