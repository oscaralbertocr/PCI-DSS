package co.com.ath.pgw.util;

import java.io.StringWriter;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Marshaller;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.fasterxml.jackson.core.JsonGenerator;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;

/**
 * Convertidor entre objeto y xml
 * @author proveedor_cjmurillo
 * @version 1.0
 * @since 1.0
 */
public class XMLUtil<T> {
	
	private static final Logger logger = LoggerFactory.getLogger(XMLUtil.class);
	
	
	/**
	 * Convierte un objeto a XML
	 * @param type objeto a convertir
	 * @return cadena en formato xml del objeto
	 */
	public String convertObjectToXml(T type) {
		try {
			StringWriter stringWriter = new StringWriter();
			JAXBContext jaxbContext = JAXBContext.newInstance(type.getClass());
			Marshaller marshaller = jaxbContext.createMarshaller();
			marshaller.setProperty(Marshaller.JAXB_FORMATTED_OUTPUT, Boolean.TRUE); //Formatear el XML o mostrarlo en una sola linea
			marshaller.setProperty(Marshaller.JAXB_FRAGMENT, true);
			marshaller.marshal(type, stringWriter);
			return stringWriter.toString();
		} catch (JAXBException jaxbException) {
			logger.warn("Error al convertir objeto a xml: ["+type.getClass().getName()+"]", jaxbException);
			return null;
		}
	}
	
	/**
	 * Convierte un objeto a JSON
	 * @param type objeto a convertir
	 * @return cadena en formato json del objeto
	 */
	public String convertObjectToJson(T type) {
		try {
			ObjectMapper objectMapper = new ObjectMapper();
			objectMapper.configure(JsonGenerator.Feature.QUOTE_FIELD_NAMES, false);
			return objectMapper.writerWithDefaultPrettyPrinter().writeValueAsString(type);
		} catch (JsonProcessingException jsonProcessingException) {
			logger.warn("Error al convertir objeto a json: ["+type.getClass().getName()+"]", jsonProcessingException);
			return null;
		}
	}
	
}
