
package co.com.ath.pgw.client.tokenize.dto;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlSeeAlso;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Clase Java para CustId_Type complex type.
 * 
 * <p>El siguiente fragmento de esquema especifica el contenido que se espera que haya en esta clase.
 * 
 * <pre>
 * &lt;complexType name="CustId_Type"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element ref="{urn://ath.com.co/xsd/common/}CustIdType"/&gt;
 *         &lt;element ref="{urn://ath.com.co/xsd/common/}CustIdNum"/&gt;
 *         &lt;element ref="{urn://ath.com.co/xsd/common/}CustLoginId" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "CustId_Type", propOrder = {
    "custIdType",
    "custIdNum",
    "custLoginId"
})
@XmlSeeAlso({
    UserIdType.class
})
public class CustIdType {

    @XmlElement(name = "CustIdType", required = true, namespace = "urn://ath.com.co/xsd/common/")
    protected String custIdType;
    @XmlElement(name = "CustIdNum", required = true, namespace = "urn://ath.com.co/xsd/common/")
    protected String custIdNum;
    @XmlElement(name = "CustLoginId", namespace = "urn://ath.com.co/xsd/common/")
    protected String custLoginId;

    /**
     * Obtiene el valor de la propiedad custIdType.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCustIdType() {
        return custIdType;
    }

    /**
     * Define el valor de la propiedad custIdType.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCustIdType(String value) {
        this.custIdType = value;
    }

    /**
     * Obtiene el valor de la propiedad custIdNum.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCustIdNum() {
        return custIdNum;
    }

    /**
     * Define el valor de la propiedad custIdNum.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCustIdNum(String value) {
        this.custIdNum = value;
    }

    /**
     * Obtiene el valor de la propiedad custLoginId.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCustLoginId() {
        return custLoginId;
    }

    /**
     * Define el valor de la propiedad custLoginId.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCustLoginId(String value) {
        this.custLoginId = value;
    }

}
