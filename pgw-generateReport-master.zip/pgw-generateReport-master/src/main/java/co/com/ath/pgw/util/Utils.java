package co.com.ath.pgw.util;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.sql.ResultSet;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.zip.ZipEntry;
import java.util.zip.ZipOutputStream;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

@Service
public class Utils {
	
	private static final Logger logger = LoggerFactory.getLogger(Utils.class);
    
    /**
     * Metodo que construye el nombre del reporte
     * @param reportDate
     * @param nameReports
     * @param filePath
     * @param obligacionesNura
     * @return
     */
    public String nameReport(String reportDate, String nameReports, String filePath, String obligacionesNura,String contingencia) {
    	String result = "";
    	Date localDate = null;
    	String[] nameReplace = null;
    	SimpleDateFormat formatter = null;
    	String fecha = "";
    	
    	try {
            nameReplace = nameReports.split("%");
            if (contingencia.equals("1")) {
            	reportDate=reportDate.replace("/","");
            }	
        	localDate = new SimpleDateFormat("ddMMyyyy").parse(reportDate);  
            
            formatter = new SimpleDateFormat(nameReplace[1]);
            fecha = formatter.format(localDate);
            result = filePath+"\\"+obligacionesNura+"\\"+nameReplace[0]+fecha+nameReplace[2];
           } catch (Exception e) {
            logger.error("::: SE PRESENTARION PROBLEMAS AL GENERAR EL NOMBRE DEL REPORTE ::: {}", e);
		}
    	
		return result;	
    }
    
    /**
     * Metodo que crea el archivo
     * @param resultSet
     * @param fileName
     * @param resultFooter 
     * @throws IOException
     */
    public void generarArchivo (ResultSet resultSet, String fileName, String resultFooter) throws IOException {
	         BufferedWriter bw = null;	                
	         FileWriter file = null;
	         try {
	        	 file = new FileWriter(fileName);
	        	 
	        	 bw = new BufferedWriter(file);
		         
	        	 while(resultSet.next()) {
		        	 if (!resultSet.getString(1).isEmpty()) {
		        		bw.append(resultSet.getString(1)+"\n");
		        	 }
		         }
		         
		         if (!resultFooter.isEmpty()) {
		        	 bw.append(resultFooter+"\n");
				}
		         
		         bw.flush();
		         bw.close();
			} catch (Exception e) {
				logger.error("Error creando reporte {}", e);
			}finally {
				if (bw != null) {
					bw.close();
				}
				if (file != null) {
					file.close();
				}				
			}	
	   }
  
    
    /**
     * Metodo que crea el archivo con formato CRLF
     * @param resultSet
     * @param fileName
     * @param resultFooter 
     * @throws IOException
     */
    public void generarArchivoCRLF (ResultSet resultSet, String fileName, String resultFooter) throws IOException {
	         BufferedWriter bw = null;	                
	         FileWriter file = null;
	         try {
	        	 file = new FileWriter(fileName);	
	        	 bw = new BufferedWriter(file);
		         
	        	 while(resultSet.next()) {
		        	 if (!resultSet.getString(1).isEmpty()) {
		        		 bw.append(resultSet.getString(1));
		              
		                bw.write("\r\n");
		        	 }
		         }
		         
		         if (!resultFooter.isEmpty()) {
		        	 bw.append(resultFooter);
		        	 bw.write("\r\n");
				}
		         
		         bw.flush();
		         bw.close();
			} catch (Exception e) {
				logger.error("Error creando reporte {}", e);
			}finally {
				if (bw != null) {
					bw.close();
				}
				if (file != null) {
					file.close();
				}				
			}	
	   }
    
  	/**
	 * Se encarga de comprimir un archivo a ZIP
	 * 
	 * @param archivoOrigen		Nombre del archivo que se desea comprimir
	 * @param urlOrigen			Url del archivoOrigen 
	 * @param archivoDestino	Nombre del archivo ZIP que se desea generar
	 * @param urlDestino		Url del archivoDestino
	 * 
	 * @return	Indica si el archivo se genero
	 *  
	 */
	public boolean generaZip(String razonSocial, String obligaciones,String pathOrigen, boolean contingencia, String reportDateCont){		

		logger.info("Comprimiendo archivo: {}", pathOrigen);

		String separador = Constants.SEPARADOR;
		
		byte[]buffer = new byte[1024];
		ZipOutputStream zipOutputStream = null;
		FileInputStream fileInputStream = null;
		
		String[] urlOrigen = null;
		urlOrigen = pathOrigen.split("\\\\");
		
		String nameZip = "";
		String tempOutput = "";
		
		try {
			nameZip = generaNombreZip(razonSocial, obligaciones, contingencia, reportDateCont);
			
			if (contingencia) {
				tempOutput = urlOrigen[0]+ separador+urlOrigen[1]+ separador+urlOrigen[2] + separador +urlOrigen[3] + separador + nameZip;
			} else {
				tempOutput = urlOrigen[0]+ separador+urlOrigen[1]+ separador+urlOrigen[2] + separador + nameZip;
			}
			
			zipOutputStream = new ZipOutputStream(new FileOutputStream(tempOutput));
			zipOutputStream.putNextEntry(new ZipEntry(urlOrigen[3]));
			zipOutputStream.setMethod(ZipOutputStream.DEFLATED);
			zipOutputStream.setLevel(5);

			fileInputStream = new FileInputStream(new File(pathOrigen));

			int len = 0;
			while ((len = fileInputStream.read(buffer)) > 0)
				zipOutputStream.write(buffer, 0, len);

			logger.info("Archivo generado: {}", nameZip);
			
			return true;
			
		} catch (Exception e) {
			logger.error("Error en la compresion de archivo ZIP {}", e);
			return false;
		} finally{
			
			if(null!=fileInputStream)
				safeClose(fileInputStream);
			
			if(null!=zipOutputStream)
				safeCloseZip(zipOutputStream);
		}
	}
	
	/**
	 * Ejecuta de manera segura el cierre del objeto FileInputStream de entrada.
	 * 
	 * @param foo
	 */
	public void safeClose(FileInputStream foo) {
		if (foo != null) {
			try {
				foo.close();
			} catch (IOException ex) {
				logger.error("No fue posible cerrar el FileInputStream. {}", ex);
			}
		}
	}

	/**
	 * Ejecuta de manera segura el cierre del objeto ZipOutputStream de entrada.
	 * 
	 * @param foo
	 */
	public void safeCloseZip(ZipOutputStream foo) {
		if (foo != null) {
			try {
				foo.closeEntry();
				foo.close();
			} catch (IOException ex) {
				logger.error("No fue posible cerrar el ZipOutputStream. {}", ex);
			}
		}
	}
	
	
	/**
	 * Retorna el nombre del archivo ZIP a generar.
	 * @return
	 * @throws ParseException 
	 */
	private String generaNombreZip(String razonSocial,String codigoNura, boolean contingencia, String fecha) throws ParseException {
		
		SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyyMMdd");
		SimpleDateFormat simpleHourFormat = new SimpleDateFormat("kkmmss");
		Date currentDate = new Date();
		
		
		if (contingencia) {
			Date localDate = null;
			localDate = new SimpleDateFormat("ddMMyyyy").parse(fecha.replace("/", "")); 
			return codigoNura + codigoNura + razonSocial + "_" + simpleDateFormat.format(localDate) + "_"
					+ simpleHourFormat.format(currentDate) + "_ASO11.zip";
			
		} else {			
			return codigoNura + codigoNura + razonSocial + "_" + simpleDateFormat.format(currentDate) + "_"
					+ simpleHourFormat.format(currentDate) + "_ASO11.zip";
		}
		

	}  
	
	/**
	 * Retorna el nombre del archivo de recaudo parcial a generar.
	 * @return
	 */
	public String nameReportPartial( String nameReports, String filePath, String obligacionesNura,String horaJob, String fecha) {
		
			String result = "";
	    	String[] nameReplace = null;
	    	horaJob= horaJob.replace(":", "");
	    	horaJob= "."+horaJob;
	    	
		
    	try {
            nameReplace = nameReports.split("%"); 
            
           if(fecha.equals("")) {
        	 
        	   SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyyMMdd");
       		Date currentDate = new Date();
       		
       		result = filePath+"\\"+obligacionesNura+"\\"+nameReplace[0]+simpleDateFormat.format(currentDate)
       				+ horaJob+nameReplace[2];
           }else 
           result = filePath+"\\"+obligacionesNura+"\\"+nameReplace[0]+fecha+horaJob
   				+nameReplace[2];
		
	}  catch (Exception e) {
        logger.error("::: SE PRESENTARION PROBLEMAS AL GENERAR EL NOMBRE DEL REPORTE ::: {}", e);
	}  
    	return result;
}
	/**
	 * Retorna el nombre del archivo de recaudo consolidado a generar.
	 * @return
	 */
	public String nameReporteConsolidado( String nameReportConsolidado, String filePath, String obligacionesNura, String fecha) {
		
			String result = "";
	    	String[] nameReplace = null;
	    	
		
    	try {
    		nameReplace = nameReportConsolidado.split("%"); 
    		if(fecha.equals("")) {
    			SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyyMMdd");
    			
    			Date currentDate = new Date();
    			result = filePath+"\\"+obligacionesNura+"\\"+nameReplace[0]+simpleDateFormat.format(currentDate)
				+nameReplace[2];
    		}else
		
		
		result = filePath+"\\"+obligacionesNura+"\\"+nameReplace[0]+fecha
				+nameReplace[2];
		
	}  catch (Exception e) {
        logger.error("::: SE PRESENTARION PROBLEMAS AL GENERAR EL NOMBRE DEL REPORTE ::: {}", e);
	}  
    	return result;
}
	
	 /**
     * Metodo que construye el nombre del reporte BIPXC
     * @param reportDate
     * @param nameReports = PAGOXCOMERCIO_%yyyyMMddkkmmss%.TXT
     * @param filePath = D:\\bi-reportes\\PSP\\ PAra contingencia =
     * @return
     */
    public String nameReportBIPXC(String nameReports, String filePath) {
    	String result = "";
    	String[] nameReplace = null;
    	
    	try {
            nameReplace = nameReports.split("%");            
            
			 SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyyMMdd");
				
			Date currentDate = new Date();
			result = filePath+nameReplace[0]+simpleDateFormat.format(currentDate)
			+nameReplace[2];
            
           
    		
		} catch (Exception e) {
            logger.error("::: SE PRESENTARION PROBLEMAS AL GENERAR EL NOMBRE DEL REPORTE ::: {}", e);
		}
    	
		return result;	
    }
    
}