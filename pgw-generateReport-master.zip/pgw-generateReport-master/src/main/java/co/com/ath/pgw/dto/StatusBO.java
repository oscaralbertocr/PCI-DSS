/*
 * TransactionStatusVO
 *  
 * GSI - Integración
 * Creado el: 29/08/2014
 *
 * Copyright (c) A Toda Hora S.A. Todos los derechos reservados
 * 
 * Este software es confidencial y es propietario de ATH, queda prohibido
 * su uso, reproducción y copia de manera parcial o permanente salvo autorización
 * expresa de A Toda Hora S.A o de quién represente sus derechos.
 */
package co.com.ath.pgw.dto;


/**
 * Estado de una transacción.
 * 
 * @author proveedor_lbonilla
 * @version 1.0 12/08/2017
 * @since 1.0
 */
public class StatusBO {
	
	/**
	 * 
	 */
	private long statusCode;
	
	/**
	 * 
	 */
	private String ServerStatusCode;
	
	/**
	 * 
	 */
	private String Severity;
	
	/**
	 * 
	 */
	private String statusDesc;
	
	/**
	 * 
	 */
	private String serverStatusDesc;
	

	public long getStatusCode() {
		return statusCode;
	}

	public void setStatusCode(long statusCode) {
		this.statusCode = statusCode;
	}

	public String getServerStatusCode() {
		return ServerStatusCode;
	}

	public void setServerStatusCode(String serverStatusCode) {
		ServerStatusCode = serverStatusCode;
	}

	public String getSeverity() {
		return Severity;
	}

	public void setSeverity(String severity) {
		Severity = severity;
	}

	public String getStatusDesc() {
		return statusDesc;
	}

	public void setStatusDesc(String statusDesc) {
		this.statusDesc = statusDesc;
	}

	public String getServerStatusDesc() {
		return serverStatusDesc;
	}

	public void setServerStatusDesc(String serverStatusDesc) {
		this.serverStatusDesc = serverStatusDesc;
	}

	

	
	@Override
	public String toString() {
		return "StatusBO [statusCode=" + statusCode + ", ServerStatusCode=" + ServerStatusCode + ", Severity="
				+ Severity + ", statusDesc=" + statusDesc + ", serverStatusDesc=" + serverStatusDesc + "]";
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((ServerStatusCode == null) ? 0 : ServerStatusCode.hashCode());
		result = prime * result + ((Severity == null) ? 0 : Severity.hashCode());
		result = prime * result + ((serverStatusDesc == null) ? 0 : serverStatusDesc.hashCode());
		result = prime * result + (int) (statusCode ^ (statusCode >>> 32));
		result = prime * result + ((statusDesc == null) ? 0 : statusDesc.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		StatusBO other = (StatusBO) obj;
		if (ServerStatusCode == null) {
			if (other.ServerStatusCode != null)
				return false;
		} else if (!ServerStatusCode.equals(other.ServerStatusCode))
			return false;
		if (Severity == null) {
			if (other.Severity != null)
				return false;
		} else if (!Severity.equals(other.Severity))
			return false;
		if (serverStatusDesc == null) {
			if (other.serverStatusDesc != null)
				return false;
		} else if (!serverStatusDesc.equals(other.serverStatusDesc))
			return false;
		if (statusCode != other.statusCode)
			return false;
		if (statusDesc == null) {
			if (other.statusDesc != null)
				return false;
		} else if (!statusDesc.equals(other.statusDesc))
			return false;
		return true;
	}
	
	
	
}