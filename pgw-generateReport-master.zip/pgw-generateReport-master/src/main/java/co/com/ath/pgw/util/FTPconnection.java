package co.com.ath.pgw.util;

import java.io.BufferedOutputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.Properties;
import java.util.Vector;

import org.apache.commons.net.ftp.FTP;
import org.apache.commons.net.ftp.FTPFile;
import org.apache.commons.net.ftp.FTPSClient;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;

import com.jcraft.jsch.Channel;
import com.jcraft.jsch.ChannelSftp;
import com.jcraft.jsch.ChannelSftp.LsEntry;
import com.jcraft.jsch.JSch;
import com.jcraft.jsch.Session;
import com.jcraft.jsch.SftpATTRS;
/**
 * Permite la conexion a un recurso FTP, SSH,
 *
 *
 * @author Jesus Octavio Avendaño Sierra <jesus.avendano@sophossolutions.com> 
 * @version 1.0 16/15/2019
 * 
 * @sophosSolutions
 * <strong>Autor: </strong>Jesus Octavio Avendaño Sierra</br>
 * <strong>Numero de Cambios: </strong>0</br>
 * 	
*/ 
public class FTPconnection {
	
	@Autowired
	Environment env;

	private static final Logger logger = LoggerFactory.getLogger(FTPconnection.class);

	private FTPSClient  connFTP = null;
	private ChannelSftp connSSH = null;
	@SuppressWarnings("unused")
	private String directory = null;
	private boolean connecOnSSH = false;
	private Integer port = (Integer) null;

	private String server;

	private String userName;

	private String password;

	
	/**
	 * inicializa los parametros para la conexion al recurso.
	 * @param server
	 * 			Servidor al que se desea conectar
	 * @param username
	 * 			usuario registrado para la conexion
	 * @param conexion
	 * 			contraseña para establecer la conexion
	 * @param directory
	 * 			ruta dentro del servidor FTP desde donde se desea descargar los archivos
	 * @param port
	 * 			puerto requerido para establecer la conexion
	 * @param mode
	 * 			tipo de conexion a establecer, 0: SFTP, FTP; 1: SSH
	*/
	public FTPconnection(String server,String username,String password,String directory,String port, int modeConnectionFtp) throws Exception {
		this.server = server;
		this.userName = username;
		this.password = password;
		this.directory = directory;
		this.port = Integer.parseInt(port);
		try {
			switch (modeConnectionFtp) {
				case 0:
					this.connecOnSSH = false;
					this.connFTP = this.connectOnFTP();				
					break;
				case 1:
					this.connecOnSSH = true;
					this.connSSH = this.connectOnSSH();
					break;
				default:
					break;
			}
		} catch (Exception e) {
			throw new Exception(e.getMessage());
		}
	}

	
	/**
	 * Realiza la conexión a un recurso FTP.
	*/
	private FTPSClient connectOnFTP() throws Exception {
		try {
			FTPSClient ftp = new FTPSClient("TLS");
			logger.info("Iniciando la conexion con el servidor FTP");
			ftp.connect(this.server,this.port);
			if(ftp.login(this.userName, this.password)) {
				logger.info("Conexion Correcta");
				ftp.enterLocalPassiveMode();
				ftp.changeWorkingDirectory(this.directory);
			}else{
				logger.info("Conexion Fallida");
				throw new Exception("Usuario o contrasena del FTP incorrectos");
			}
			return ftp;
		} catch (Exception e) {
			logger.error("Error al tratar de conectar con el FTP: {}", e);
			throw new Exception("Error al tratar de conectar con el FTP: "+ e.getMessage());
		}
	}
	
	/**
	 * Realiza la conexión a un recurso SSH.
	*/
	private ChannelSftp connectOnSSH() throws Exception {
		try {
			JSch jsch = new JSch();
			Session session = jsch.getSession( this.userName, this.server, this.port );
			session.setConfig( "PreferredAuthentications", "password" );
			session.setPassword( this.password );
			Properties config = new Properties();
			config.put("StrictHostKeyChecking", "no");
			session.setConfig(config);
			logger.info("Iniciando la conexion con el servidor SSH");
			session.connect();
			Channel channel = session.openChannel( "sftp" );
			ChannelSftp ssh = ( ChannelSftp ) channel;
			ssh.connect();
			logger.info("Conectado al SSH: {}", this.server);
			ssh.cd(directory);
			return ssh;
		} catch (Exception e) {
			logger.error("Error al tratar de conectar con el servidor SSH: {}", e);
			throw new Exception("Error al tratar de conectar con el servidor SSH: "+ e.getMessage());
		}
	}

	/**
	 * Lista los archivos destro de la carpeta actual del FTP.
	*/
	public void listFiles(){
		try {
			if(!this.connecOnSSH) {
				FTPFile[] ftpFiles = this.connFTP.listFiles();  
				if (ftpFiles != null && ftpFiles.length > 0) {
					//loop thru files
					for (FTPFile file : ftpFiles) {
						if (file.isFile()) {
							logger.info("File is {}", file.getName());
						} else if (file.isDirectory()){
							logger.info("Directory is {}", file.getName());
						}
					}
				}
			}else {
				logger.info("Directory is {}", this.connSSH.pwd());
				Vector<?> filelist = this.connSSH.ls(".");
				for(int i=0; i<filelist.size();i++){
					LsEntry entry = (LsEntry) filelist.get(i);					
				}
			}
		} catch (Exception e) {
			logger.error(e.toString());
		}
		
	}
	
	/**
	 * Descarga un archivo de la conexion actual.
	 * 
	 * @param
	 * 		fileToDownload
	 * 				Nombre del archivo que se debe descargar
	*/
	public void downloadFile(String fileToDownload){
		this.downloadFile("C:\\Users\\jesus.avendano\\Desktop\\" ,fileToDownload);
	}
	/**
	 * Descarga un archivo de la conexion actual, y lo ubica en una ruta especifica.
	 * 
	 * @param
	 * 		destination
	 * 				carpeta de destino donde se colocara el archivo descargado
	 * 		fileToDownload
	 * 				Nombre del archivo que se debe descargar
	*/
	public void downloadFile(String destination, String fileToDownload){
		try {
			String outDest = destination + "\\" + fileToDownload; 
			BufferedOutputStream outStream = new BufferedOutputStream(new FileOutputStream(outDest));
			if(!this.connecOnSSH) {
				logger.info("Se descargara desde la carpeta: {}", this.connFTP.printWorkingDirectory());
				logger.info("El archivo: {}", fileToDownload);
				try {
					this.connFTP.setFileType(FTP.BINARY_FILE_TYPE);
					if(this.connFTP.retrieveFile(fileToDownload, outStream)) {
						logger.info("Descarga correcta");	    	
					} else {
						logger.info("Error Descarga");
					}
				} catch (Exception e) {
					logger.info(e.toString());
				}
			}else {
				logger.info("Se descargara desde la carpeta: {}", this.connSSH.pwd());
				logger.info("El archivo: {}", fileToDownload);
				this.connSSH.get(fileToDownload , outStream);
				logger.info("Descarga correcta");
			}
			outStream.close();
		} catch (Exception e) {
			logger.info("Error Descarga");
			logger.error(e.toString());
		}
	}

	/**
	 * Cierra la conexion.
	*/
	public void close() {
		try {
			if(!connecOnSSH)
				this.connFTP.disconnect();
			else
				this.connSSH.disconnect();
		} catch (IOException e) {
			logger.error("Error en close()", e);
		}
	}
	
	/**
	 * Verifica si existe un archivo en el servidor
	*/
	public boolean existsFile(String fileToDownload) {
		boolean existe = false;
		try {
			if(!this.connecOnSSH) {
				FTPFile[] ftpFiles = this.connFTP.listFiles(fileToDownload);  
				if (ftpFiles != null && ftpFiles.length > 0) {
					existe = true;
				}
			} else {
				SftpATTRS fileList = this.connSSH.stat(fileToDownload);
				if (fileList != null) {
					existe = true;
				}
			}
			return existe;
		} catch (Exception e) {
			logger.error("Error en existsFile()", e);
			return false;
		}
	}

}