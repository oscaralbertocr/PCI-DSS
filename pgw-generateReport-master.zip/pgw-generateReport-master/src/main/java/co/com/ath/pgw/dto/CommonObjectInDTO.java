/*
 * CommonObjectInDTO
 *  
 * GSI - Integración
 * Creado el: 20/09/2014
 *
 * Copyright (c) A Toda Hora S.A. Todos los derechos reservados
 * 
 * Este software es confidencial y es propietario de ATH, queda prohibido
 * su uso, reproducción y copia de manera parcial o permanente salvo autorización
 * expresa de A Toda Hora S.A o de quién represente sus derechos.
 */
package co.com.ath.pgw.dto;

import java.util.Date;

import co.com.ath.pgw.util.XMLUtil;

/**
 * DTO que contiene los objetos comunes pra la información de entrada.
 * 
 * @author Andrés Méndez Juanias <proveedor_mamendez@ath.com.co>
 */
public class CommonObjectInDTO {

	/** Identificador único del mensaje. */
	protected Long rqUID;

	/** Fecha y hora de solicitud */
	protected Date clientDt;

	/** Dirección IP desde donde se hace la petición. */
	protected String ipAddr;


	/**
	 * Metodo encargado de recuperar el identificador unico del mensaje.
	 * 
	 * @return El identificador unico del mensaje.
	 */
	public Long getRqUID() {
		return rqUID;
	}

	/**
	 * Metodo encargado de actualizar identificador unico del mensaje.
	 * 
	 * @param rqUID
	 *            Nuevo valor para el identificador unico del mensaje.
	 */
	public void setRqUID(Long rqUID) {
		this.rqUID = rqUID;
	}

	/**
	 * Metodo encargado de recuperar la fecha y hora de solicitud.
	 * 
	 * @return la fecha y hora de solicitud
	 */
	public Date getClientDt() {
		return clientDt;
	}

	/**
	 * Metodo encargado de actualizar la fecha y hora de solicitud.
	 * 
	 * @param clientDt
	 *            Nuevo valor para la fecha y hora de solicitud.
	 */
	public void setClientDt(Date clientDt) {
		this.clientDt = clientDt;
	}

	/**
	 * Metodo encargado de recuperar la direccion IP de la peticion.
	 * 
	 * @return La dirección IP de la petición.
	 */
	public String getIpAddr() {
		return ipAddr;
	}

	/**
	 * Metodo encargado de actualizar la direccion IP de la peticion.
	 * 
	 * @param ipAddr
	 *            Nuevo valor para la direccion IP de la peticion.
	 */
	public void setIpAddr(String ipAddr) {
		this.ipAddr = ipAddr;
	}
	
	@Override
	public String toString() {
		XMLUtil<CommonObjectInDTO> requestParser = new XMLUtil<CommonObjectInDTO>();
		return requestParser.convertObjectToXml(this);
	}

}
