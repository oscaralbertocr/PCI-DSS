package co.com.ath.pgw;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PgwFileCreatorApplicationTests {

	@Test
	void contextLoads() {
	}

}
