package co.com.ath.pgw.file.tasklet.impl;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.stream.IntStream;
import java.util.stream.Stream;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.batch.core.StepContribution;
import org.springframework.batch.core.configuration.annotation.StepScope;
import org.springframework.batch.core.scope.context.ChunkContext;
import org.springframework.batch.repeat.RepeatStatus;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import co.com.ath.pgw.file.mail.MailDto;
import co.com.ath.pgw.file.mail.MailService;
import co.com.ath.pgw.file.tasklet.CommissionFileCreatorTasklet;
import co.com.ath.pgw.util.Constants;
import co.com.ath.pgw.util.Util;

/**
 * Processor for creation of Monthly Commission Files
 * 
 * @author Javier Esteban Flórez Rincón <javier.florez@sophossolutions.com>
 * @version 1.0 03/08/2020
 * 
 * @sophosSolutions <strong>Autor: </strong>Javier Esteban Flórez Rincon</br>
 *                  <strong>Número de Cambios: </strong>0</br>
 *
 */
@Service
@StepScope
public class CommissionFileCreatorTaskletImpl implements CommissionFileCreatorTasklet {

	private static final Logger logger = LoggerFactory.getLogger(CommissionFileCreatorTaskletImpl.class);

	@Value(value = "#{jobParameters[workspace]}")
	private String workspace;

	@Value(value = "#{jobParameters[filePathLiquidacion]}")
	private String pathLiquidacion;

	@Value(value = "#{jobParameters[fileName]}")
	private String fileName;

	@Value(value = "#{jobParameters[bankCode]}")
	private String bankCode;

	@Value(value = "${pasarela.mail.to}")
	private String mailTo;

	/**
	 * Suma todos los montos aprobados en el archivo para crear el footer
	 */
	private double totalApprovedMount;

	/**
	 * Suma todos los montos no aprobados en el archivo para crear el footer
	 */
	private double totalRejectedMount;

	/**
	 * Lleva la cuenta del total de registros a escribir en el archivo
	 */
	private int totalLines;

	/**
	 * Nombre base de los archivos, recibe primero el nombre hasta el indicativo del
	 * mes y el segundo parametro para la expresión regular
	 */
	private static final String BASE_NAME = "%s%s.DAT";

	private static final String REGEX_EXPRESSION = "[0-9]{2}";

	@Autowired
	private MailService mailService;

	@Override
	public RepeatStatus execute(StepContribution contribution, ChunkContext chunkContext) throws Exception {
		logger.info("-----------------------------Tasklet iniciado----------------------------");

		processor();

		return RepeatStatus.FINISHED;
	}

	/**
	 * Handle the file creation process
	 */
	public void processor() {
		try {
			if (moveFiles(pathLiquidacion, workspace) == 1) { // Continua si los archivos se movieron sin problemas
				logger.info("Archivos copiados con éxito en workspace: {}", workspace);
				File filesPath = new File(workspace);
				File[] files = filesPath.listFiles();
				
				if (files != null && files.length > 0) { // Si en la carpeta temporal existen archivos o la carpeta
					logger.info("Encontrados archivos: Creando archivo mensual");
					String monthlyFileName = pathLiquidacion + File.separator + 
							String.format(BASE_NAME, fileName, ""); // Creo el nombre del archivo
					
					Files.createFile(Paths.get(monthlyFileName)); //Creo el archivo mensual para escribir sobre este

					logger.info("Escribiendo Header");
					writeCommissionFile(monthlyFileName, createHeader());
					logger.info("Header escrito con éxito");
					for (File file : files) {
						StringBuilder data = readDailyFiles(file);
						if (data != null) {
							logger.info("Escribiendo {} en archivo mensual", file.getName());
							writeCommissionFile(monthlyFileName, data.toString());
							logger.info("Finalizada escritura en archivo mensual");
						}
					}
					logger.info("Escribiendo footer en archivo");
					writeCommissionFile(monthlyFileName, createFooter());
					logger.info("Footer Escrito con éxito escrito con éxito");
				} else {
					logger.info("No se han encontrado archivos o el directorio de trabajo");
				}
			}
			deleteFiles(this.workspace); // Borra carpeta temporal al finalizar el proceso
		} catch (Exception e) {
			logger.error("Ha ocurrido un error: {}", e.getMessage(), e);
		}
	}

	@Override
	public StringBuilder readDailyFiles(File file) {
		try {
			final StringBuilder data = new StringBuilder();

			logger.info("Iniciando lectura de archivo {} ", file.getName());
			String[] lines = Util.readFile(file.getAbsolutePath());
			IntStream.range(1, lines.length - 1) // Configure the range, beginning since the position 1, because 0 is
												// the header
			.forEach(i -> { 					// and the last is the footer
				data.append(lines[i]);
				data.append(System.getProperty(Constants.SEPARATOR_NAME));
				sumTotals(lines[i]);
			});
			logger.info("Finalizada lectura de {} ", file.getName());
			return data;
		} catch (Exception e) {
			logger.error("Error ejecutando lectura de archivo: {}", file.getName(), e);
			sendMail(e.getMessage(), file.getName());
		}
		return null;
	}

	public void sendMail(String message, String fileName) {
		try {
			logger.info("---------- Inicio envío email --------------");
			StringBuilder sb = new StringBuilder("Se ha obtenido un error al generar el archivo "
					+ "de liquidación mensual debido a lo siguiente: \n");
			sb.append(message);
			sb.append(System.getProperty(Constants.SEPARATOR_NAME));
			sb.append(String.format("El error se presenta realizando la lectura del archivo diario: %s", fileName));
			sb.append(" por tanto este archivo no ha sido escrito en el archivo mensual");
			MailDto inDTO = new MailDto();
			inDTO.setTo(mailTo);
			inDTO.setSubject(String.format("Archivo de liquidación mensual generado con error %s", this.fileName));
			inDTO.setText(sb.toString());
			mailService.sendNotification(inDTO);
			logger.info("Email informativo enviado");
		} catch (Exception e) {
			logger.error("Error realizando envío de email: {}", e.getMessage(), e);
		}
	}

	@Override
	public void writeCommissionFile(String path, String body) {
		logger.info("Iniciando escritura en archivo {}", path);
		Util.writeFile(path, body);
		logger.info("Finalizada escritura en archivo {}", path);
	}

	/**
	 * Process the line to take the mounts and sum the total approved and total
	 * rejected
	 * 
	 * @param line
	 */
	public void sumTotals(String line) {
		final float mount = Float.parseFloat(line.substring(172, 187));
		if (Integer.parseInt(line.substring(205, 206)) == Constants.APPROVED_TX_CODE) { // 4 is the code for approved
																						// transaction
			this.totalApprovedMount = this.totalApprovedMount + mount;
		} else {
			this.totalRejectedMount = this.totalRejectedMount + mount;
		}
		totalLines++;
	}

	/**
	 * Creates footer line with all the collected information
	 * 
	 * @return Footer line created
	 */
	/**
	 * @return
	 */
	public String createFooter() {
		logger.info("Creando footer con los siguientes montos: {},{}", totalApprovedMount, totalRejectedMount);
		StringBuilder footer = new StringBuilder("03"); // Indicativo del tipo texto 01 = header - 02 = body - 03 =
														// footer
		footer.append(String.format("%010d", totalLines));
		footer.append(String.format("%020.2f", totalApprovedMount).replace(",", ".")); // Reemplazamos la coma decimal
																						// por un punto
		footer.append(String.format("%020.2f", totalRejectedMount).replace(",", "."));
		footer.append(System.getProperty(Constants.SEPARATOR_NAME));
		return footer.toString();
	}

	/**
	 * Creates header line with all the collected information
	 * 
	 * @return Header line created
	 */
	public String createHeader() {
		logger.info("Creando encabezado archivo mensual para código banco: {}", this.bankCode);
		SimpleDateFormat format;
		format = new SimpleDateFormat("yyyyMMdd");

		Calendar firstDate = Calendar.getInstance();
		firstDate.add(Calendar.MONTH, -1); // Ubicamos la fecha en el mes anterior
		firstDate.set(Calendar.DAY_OF_MONTH, 1); // Ubicamos la fecha en el primer día del mes

		Calendar lastDate = Calendar.getInstance();
		lastDate.add(Calendar.DATE, -1); // Como el archivo se genera el primer día del mes siguiente, ubicamos la fecha
											// en el día anterior

		Calendar currentDate = Calendar.getInstance();

		StringBuilder header = new StringBuilder("01");// Indicativo del tipo texto 01 = header - 02 = body - 03 =
														// footer
		header.append(String.format("%4s", bankCode).replace(" ", "0")); // Se reemplazan los espacios para rellenar con
																			// 0
		header.append("M"); // Indicativo del tipo de reporte M = Mensual D = Diario
		header.append(format.format(firstDate.getTime()));
		header.append(format.format(lastDate.getTime()));
		header.append(format.format(currentDate.getTime()));
		header.append(System.getProperty(Constants.SEPARATOR_NAME));
		return header.toString();
	}

	/**
	 * Move files to workspace
	 * 
	 * @param pathFrom Source directory where the files exists
	 * @param pathTo   Detiny directory to work
	 * @return 1 if the operation completes or 0 if an error appears
	 */
	public int moveFiles(String pathFrom, String pathTo) {
		try {
			logger.info("Iniciando copia de archivos en workspace para archivo mensual: {}", fileName);
			final Path source = Paths.get(pathFrom);
			final Path destiny = Paths.get(pathTo);

			return moveFiles(source, destiny);
		} catch (Exception e) {
			logger.error("Error ubicando los directorios de trabajo: {}", e.getMessage(), e);
		}
		return 0;
	}

	private int moveFiles(Path source, Path pathTo) {
		String patterName = String.format(BASE_NAME, fileName, REGEX_EXPRESSION); // Se reemplazan los parámetros del
																					// BASE_NAME
		Pattern pattern = Pattern.compile(patterName, Pattern.CASE_INSENSITIVE);// Se crea un patrón para comparar la
																				// expresión regular

		try (Stream<Path> pathStream = Files.list(source)) {
			if (!Files.exists(pathTo)) { // Si es la primera iteración con un banco, se debe crear el directorio de
											// trabajo
				logger.info("Se crea el espacio de trabajo en {}", pathTo);
				Files.createDirectory(pathTo);
			}
			pathStream.forEach(file -> {
				Matcher matcher = pattern.matcher(file.getFileName().toString()); // Comparamos nombres y la expressión
																					// regular
				if (matcher.find()) { // Copiamos en caso de éxito
					logger.info("Copiando el siguiente archivo: {}", file.getFileName());
					final Path destiny = Paths.get(pathTo.toString() + File.separator + file.getFileName().toString());
					Util.copyFiles(file.toAbsolutePath(), destiny);
					logger.info("Copia de archivo finalizada");
				}
			});
			return 1;
		} catch (IOException ex) {
			logger.error("Error leyendo archivos en directorio: {}", ex.getMessage(), ex);
			return 0;
		}
	}

	/**
	 * Deletes the files in workspace
	 * 
	 * @param path
	 * @return 1 if the operation is completed 0 if some error appears
	 */
	public int deleteFiles(String path) {
		try {
			logger.info("Borrando espacio de trabajo: {}", path);
			final Path pathToBeDeleted = Paths.get(path);
			if (Files.exists(pathToBeDeleted)) { // Si la carpeta no fue creada no se puede borrar
				Util.deleteFiles(pathToBeDeleted);
				return 1;
			}
			logger.info("La ruta {} no existe", path);
		} catch (Exception ex) {
			logger.error("Error borrando el directorio de trabajo: {}", ex.getMessage(), ex);
		}
		return 0;
	}

}
