package co.com.ath.pgw.util;

public enum AVALBankEnum {
	
	AV_VILLAS("52","00010524","052","Banco AV Villas",1L,"BAVV","8333"),
	BOGOTA("01","00010016","001","Banco de BogotÃ¡",2L,"BBOG","8332"),
	POPULAR("02","00010029","002","Banco Popular",3L,"BPOP","8334"),
	OCCIDENTE("23","00010236","023","Banco de Occidente",4L,"BOCC","8331");
	
	/**
	 * Codigo asignado por el Banco de la Republica.
	 */
	private String centralBankCode;
	
	/**
	 * Codigo AVAL de la institucion financiera.
	 */
	private String avalCode;
	
	/**
	 * Codigo de compensacion
	 */
	private String compensationCode;
	
	/**
	 * Nombre de la institucion financiera.
	 */
	private String bankName;
	
	/**
	 * Identificador en Base de Datos
	 */
	private Long idBank;
	
	/**
	 * Identificador Banco Sigla
	 */
	private String initialBank;

	/**
	 * Identificador Banco Sigla
	 */
	private String terminalCodeBank;
	
	/**
	 * Constructor de la enumeracion.
	 * @param centralBankCode Codigo en Banco de la Republica.
	 * @param avalCode Codigo AVAL de la institucion financiera.
	 * @param compensationCode Codigo de compensacion.
	 * @param bankName Nombre de la institucion financiera.
	 */
	private AVALBankEnum(String centralBankCode, String avalCode,
			String compensationCode, String bankName,Long idBank,
			String initialBank,String terminalCodeBank) {
		this.centralBankCode = centralBankCode;
		this.avalCode = avalCode;
		this.compensationCode = compensationCode;
		this.bankName = bankName;
		this.idBank=idBank;
		this.initialBank=initialBank;
		this.terminalCodeBank = terminalCodeBank;
	}

	/**
	 * @return the centralBankCode
	 */
	public String getCentralBankCode() {
		return centralBankCode;
	}

	/**
	 * @return the avalCode
	 */
	public String getAvalCode() {
		return avalCode;
	}

	/**
	 * @return the compensationCode
	 */
	public String getCompensationCode() {
		return compensationCode;
	}

	/**
	 * @return the bankName
	 */
	public String getBankName() {
		return bankName;
	}

	/**
	 * @return the idbank
	 */
	public Long getIdBank() {
		return idBank;
	}

	/**
	 * @return the idInitialBank
	 */
	public String getInitialBank() {
		return initialBank;
	}
	
	/**
	 * @return the terminalCodeBank
	 */
	public String getTerminalCodeBank() {
		return terminalCodeBank;
	}
}
