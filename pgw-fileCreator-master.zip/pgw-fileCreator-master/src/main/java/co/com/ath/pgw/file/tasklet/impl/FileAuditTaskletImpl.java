package co.com.ath.pgw.file.tasklet.impl;

import java.util.stream.IntStream;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.batch.core.StepContribution;
import org.springframework.batch.core.configuration.annotation.StepScope;
import org.springframework.batch.core.scope.context.ChunkContext;
import org.springframework.batch.repeat.RepeatStatus;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import co.com.ath.pgw.file.mail.MailDto;
import co.com.ath.pgw.file.mail.MailService;
import co.com.ath.pgw.file.tasklet.FileAuditTasklet;
import co.com.ath.pgw.util.Constants;
import co.com.ath.pgw.util.Util;

/**
 * Processor for Monthly Commission Files audit
 * 
 * @author Javier Esteban Flórez Rincón <javier.florez@sophossolutions.com>
 * @version 1.0 03/08/2020
 * 
 * @sophosSolutions <strong>Autor: </strong>Javier Esteban Flórez Rincon</br>
 *                  <strong>Numero de Cambios: </strong>0</br>
 *
 */
@Service
@StepScope
public class FileAuditTaskletImpl implements FileAuditTasklet{
	
	private static final Logger logger = LoggerFactory.getLogger(FileAuditTaskletImpl.class);
	
	@Value("#{jobParameters[filePathLiquidacion]}")
	private String pathFileLiquidacion;
	
	@Value(value = "${pasarela.mail.to}")
	private String mailTo;
	
	private double totalApprovedMount;
	
	private double totalRejectedMount;
	
	private int totalLines;
	
	@Autowired
	private MailService mailService;
	
	@Override
	public RepeatStatus execute(StepContribution contribution, ChunkContext chunkContext) throws Exception {
		logger.info("-----------------------------Tasklet iniciado----------------------------");

		auditDailyFile();
		
		return RepeatStatus.FINISHED;
	}	
	
	@Override
	public void auditDailyFile() {
		try {
			logger.info("Iniciando lectura de archivo {} ", pathFileLiquidacion);
			String[] lines = Util.readFile(pathFileLiquidacion);
			
			IntStream.range(1, lines.length -1) //Configure the range, beginning since the position 1, because 0 is the header
			.forEach(i -> sumTotals(lines[i])); // and the last is the footer
			logger.info("---------Finalizada lectura de archivo----------------------------");
			String footer = lines[lines.length - 1];
			String footerCalculated = createFooter();
			logger.info("Comparando footer calculado: {} - vs footer existente: {}", footerCalculated, footer);
			validateFile(footer, footerCalculated);
		} catch (Exception e) {
			logger.error("Error ejecutando lectura de archivos: {}", e.getMessage() ,e);
		}
	}
	
	@Override
	public void validateFile(String footer, String footerCalculated) {
		try {
			logger.info("Validando archivo {}", this.pathFileLiquidacion);
			if (!footer.equals(footerCalculated)) {
				logger.info("Archivo con inconsistencias, se envía email");
				StringBuilder sb = new StringBuilder("Se han encontrado inconsistencias en el archivo al comparar los montos obtenidos: \n");
				sb.append(String.format("Monto total transacciones aprobadas calculado: %.2f %n", this.totalApprovedMount));
				sb.append(String.format("Monto total transacciones rechazadas calculado: %.2f %n", this.totalRejectedMount));
				sb.append(String.format("Footer actual: %s %n", footer));
				sb.append(String.format("Footer correcto: %s %n", footerCalculated));
				MailDto inDTO = new MailDto();
				inDTO.setTo(mailTo);
				inDTO.setSubject("Inconsistencias archivo de liquidación de comisiones diario");
				inDTO.setText(sb.toString());
				mailService.sendNotification(inDTO);
				logger.info("Email informativo enviado");
				return;
			}
			logger.info("No se han identificado inconsistencias en archivo {}", this.pathFileLiquidacion);
		} catch (Exception e) {
			logger.error("Error realizando envío de email: {}", e.getMessage() ,e);
		}
	}

	/**
	 * Process the line to take the mounts and sum the total approved and total rejected
	 * @param line
	 */
	public void sumTotals(String line) {
		final double mount = Double.parseDouble(line.substring(172, 187));
        if(Integer.parseInt(line.substring(205, 206)) == Constants.APPROVED_TX_CODE) { //4 is the code for approved transaction
        	this.totalApprovedMount = this.totalApprovedMount + mount; 
        } else {
        	this.totalRejectedMount = this.totalRejectedMount + mount;
        }
        totalLines++;		
	}
	
	/**
	 * Creates footer line with all the collected information
	 * @return Footer line created
	 */
	public String createFooter() {
		logger.info("Procesando totales para crear footer y realizar comparación");
		StringBuilder footer = new StringBuilder("03"); //Indicativo del tipo texto 01 = header - 02 = body - 03 = footer
		footer.append(String.format("%010d", totalLines));
		footer.append(String.format("%020.2f", totalApprovedMount).replace(",", ".")); //Reemplazamos la coma decimal por un punto
		footer.append(String.format("%020.2f", totalRejectedMount).replace(",", "."));
		return footer.toString();
	}

}
