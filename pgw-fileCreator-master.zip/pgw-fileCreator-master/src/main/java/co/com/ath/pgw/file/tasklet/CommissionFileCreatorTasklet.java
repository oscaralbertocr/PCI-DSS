package co.com.ath.pgw.file.tasklet;

import java.io.File;

import org.springframework.batch.core.step.tasklet.Tasklet;

/**
 * Interface processor for creation of Monthly Commission Files 
 * 
 * @author Javier Esteban Flórez Rincón <javier.florez@sophossolutions.com>
 * @version 1.0 03/08/2020
 * 
 * @sophosSolutions <strong>Autor: </strong>Javier Esteban Flórez Rincon</br>
 *                  <strong>Numero de Cambios: </strong>0</br>
 *
 */
public interface CommissionFileCreatorTasklet extends Tasklet{

	/**
	 * Method that get the daily files and read them
	 */
	public StringBuilder readDailyFiles(File file);
	
	/**
	 * Writes in monthly commission file
	 * 
	 * @param body represents the body text in the daily file to add in the
	 *             commission file
	 */
	public void writeCommissionFile(String path, String body);
	
}
