package co.com.ath.pgw.file.tasklet;

import org.springframework.batch.core.step.tasklet.Tasklet;

/**
 * Interface processor for encryption of Monthly Commission Files 
 * 
 * @author Javier Esteban Flórez Rincón <javier.florez@sophossolutions.com>
 * @version 1.0 03/08/2020
 * 
 * @sophosSolutions <strong>Autor: </strong>Javier Esteban Flórez Rincon</br>
 *                  <strong>Numero de Cambios: </strong>0</br>
 *
 */
public interface EncryptPGPTasklet extends Tasklet{
	
	/**
	 * Metodo que cifra el reporte en pgp
	 */
	public boolean encryptReport(String nameReport, String inputFileName, String outputFileName, String keyFile, String obligacion);
	
}
