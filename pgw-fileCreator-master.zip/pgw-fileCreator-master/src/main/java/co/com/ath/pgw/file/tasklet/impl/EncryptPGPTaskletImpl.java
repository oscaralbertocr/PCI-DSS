package co.com.ath.pgw.file.tasklet.impl;

import java.io.File;

import javax.annotation.Resource;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.batch.core.StepContribution;
import org.springframework.batch.core.configuration.annotation.StepScope;
import org.springframework.batch.core.scope.context.ChunkContext;
import org.springframework.batch.repeat.RepeatStatus;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import co.com.ath.pgw.encrypt.EncrypterService;
import co.com.ath.pgw.exceptions.EncryptionException;
import co.com.ath.pgw.file.tasklet.EncryptPGPTasklet;
import co.com.ath.pgw.util.ConnectionFTP;

@Service
@StepScope
public class EncryptPGPTaskletImpl implements EncryptPGPTasklet {
	
	@Value("#{jobParameters[fileName]}")
	private String nameLiquidacion;
	
	@Value("#{jobParameters[filePathLiquidacion]}")
	private String pathLiquidacion;
	
	@Value(value = "${pathKeyPublicPgp}")
	private String pathKeyPublicPgp;
	
	@Value(value = "${pathCommissionFTP}")
	private String pathCommissionFTP;
	
	/**
	 * Conexion FTP  
	 */
	@Resource
	private ConnectionFTP conectionFTP;
	
	@Resource
	private EncrypterService encrypter;

	private static final Logger logger = LoggerFactory.getLogger(EncryptPGPTaskletImpl.class);
	
	@Override
	public RepeatStatus execute(StepContribution contribution, ChunkContext chunkContext) throws Exception {
		logger.info("------------- Tasklet encriptación iniciado -------------------");
		String inputFileName = "";
		String outputFileName = "";
		String keyFile = "";
		StringBuilder fileNamePgp;
		String pathSFTP = "";
		try {
			fileNamePgp = getNameToPgp(this.nameLiquidacion);
			
			inputFileName = this.pathLiquidacion.concat(File.separator).concat(this.nameLiquidacion).concat(".DAT");
			outputFileName = this.pathLiquidacion.concat(File.separator + fileNamePgp);
			keyFile = this.pathKeyPublicPgp;
			encryptReport(fileNamePgp.toString(), inputFileName, outputFileName, keyFile,"");
			logger.info("Encriptación realizada");
			pathSFTP = this.pathCommissionFTP;
			logger.info("Iniciando envío Ftp");
			//conectionFTP.connect(outputFileName, pathSFTP);
		
		}catch (Exception e) {
			logger.error("Error al tratar de enviar los parametros para cifrar el reporte : {}", e.getMessage(),  e);
		}
		
		return RepeatStatus.FINISHED;
	}
	
	/**
	 * Metodo para crear el nombre del reporte cifrado
	 * @param fileName
	 * @return
	 */
	private StringBuilder getNameToPgp(String fileName) {
		StringBuilder result = new StringBuilder(fileName);
		return result.append(".PGP");
	}

	@Override
	public boolean encryptReport(String nameReport, String inputFileName, String outputFileName, String keyFile, String obligacion) {
		logger.info("--------- Iniciando encriptación -----------------");
		try {
			encrypter.setInputFileName(inputFileName);
			encrypter.setOutputFileName(outputFileName);
			encrypter.setPublicKeyFileName(keyFile);			
			
			if(encrypter.encrypt()) {
				logger.info("Se encripto correctamente el archivo : {}", nameReport);
			} else {
				throw new EncryptionException("Encrypt Fail");
			}		
			return true;
		} catch (Exception e) {
			logger.error("Error al tratar de encriptar el archivo a PGP : {} {} ",outputFileName, e);
		} finally {
			encrypter = null;
		}
		return false;		
	}

}
