package co.com.ath.pgw.util;

public class Constants {
	
	private Constants() {}
	
	public static final int APPROVED_TX_CODE = 4;
	
	public static final String SEPARATOR_NAME = "line.separator";
	
	public static final String USERNAME_KEY = "pasarela.mail.username";
	
	public static final String PROPERTY_NAME_KEY = "pasarela.mail.password";
	
	public static final String AUTH_KEY = "mail.smtp.auth";
	
	public static final String PROTOCOL_KEY = "mail.transport.protocol";
	
	public static final String TLS_KEY = "mail.smtp.starttls.enable";
	
	public static final String SSL_KEY = "mail.smtp.ssl.trust";
	
	public static final String DEBUG_KEY = "mail.debug";
}
