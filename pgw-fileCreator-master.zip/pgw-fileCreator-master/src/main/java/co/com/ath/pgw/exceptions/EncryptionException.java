package co.com.ath.pgw.exceptions;

public class EncryptionException extends Exception{

	/**
	 * 
	 */
	private static final long serialVersionUID = -6811683571599100791L;
	
	public EncryptionException(String message) {
		super(message);
	}

}
