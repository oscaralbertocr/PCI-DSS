package co.com.ath.pgw.file.mail;

import javax.mail.MessagingException;

public interface MailService {
	public void sendNotification(MailDto inDTO) throws MessagingException;
}
