package co.com.ath.pgw.file.mail;

import java.util.Map;
import java.util.Properties;
import java.util.Set;
import java.util.regex.Matcher;

import javax.annotation.PostConstruct;
import javax.annotation.Resource;
import javax.mail.MessagingException;
import javax.mail.internet.MimeMessage;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.env.Environment;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.mail.javamail.JavaMailSenderImpl;
import org.springframework.mail.javamail.MimeMessageHelper;
import org.springframework.stereotype.Service;

import co.com.ath.pgw.util.Constants;


/**
 * Default implementation for email send
 * 
 * @author Javier Esteban Flórez Rincón <javier.florez@sophossolutions.com>
 * @version 1.0 03/08/2020
 * 
 * @sophosSolutions <strong>Autor: </strong>Javier Esteban Flórez Rincon</br>
 *                  <strong>Numero de Cambios: </strong>0</br>
 *
 */
@Service
public class MailServiceImpl implements MailService{
	
	private static Logger logger = LoggerFactory.getLogger(MailServiceImpl.class);
	
	@Value("${pasarela.mail.from}")
	private String from;
	
	@Value("${pasarela.mail.encoding:UTF-8}")
    private String encoding;
	
	@Resource
	private Environment environment;
	
	private JavaMailSender javaMailSender;
	
	/**
	 * Constructor por defecto del servicio de mail.
	 */
	public MailServiceImpl() {
		super();
	}
	
	/**
	 * Método que inicializa la configuración del servicio de email.
	 */
	@PostConstruct
	public void init() {
		logger.info("-----------Creando de servicio de correo ------------");
		JavaMailSenderImpl mailSenderImpl = new JavaMailSenderImpl();
		mailSenderImpl.setHost(environment.getProperty("pasarela.mail.host"));
		mailSenderImpl.setPort(environment.getProperty("pasarela.mail.port", Integer.class));
		if(environment.containsProperty(Constants.USERNAME_KEY) && !environment.getProperty(Constants.USERNAME_KEY).isEmpty()){
			mailSenderImpl.setUsername(environment.getProperty(Constants.USERNAME_KEY));
		}
		if(environment.containsProperty(Constants.PROPERTY_NAME_KEY) && !environment.getProperty(Constants.PROPERTY_NAME_KEY).isEmpty()){
			mailSenderImpl.setPassword(environment.getProperty(Constants.PROPERTY_NAME_KEY));
		}
		mailSenderImpl.setJavaMailProperties(getMailProperties());
		javaMailSender = mailSenderImpl;
	}
	
	/**
	 * Obtiene las propiedades adicionales para el servicio de email. 
	 * @return Propiedades adicionales para la conexion de email.
	 */	
	private Properties getMailProperties() {
		Properties mailProperties = new Properties();
		if(environment.containsProperty(Constants.AUTH_KEY)){
			mailProperties.put(Constants.AUTH_KEY, environment.getProperty(Constants.AUTH_KEY));
		}
		if(environment.containsProperty(Constants.PROTOCOL_KEY)){
			mailProperties.put(Constants.PROTOCOL_KEY, environment.getProperty(Constants.PROTOCOL_KEY));
		}
		if(environment.containsProperty(Constants.TLS_KEY)){
			mailProperties.put(Constants.TLS_KEY, environment.getProperty(Constants.TLS_KEY));
		}
		if(environment.containsProperty(Constants.SSL_KEY)){
			mailProperties.put(Constants.SSL_KEY, environment.getProperty(Constants.SSL_KEY));
		}
		if(environment.containsProperty(Constants.DEBUG_KEY)){
			mailProperties.put(Constants.DEBUG_KEY, environment.getProperty(Constants.DEBUG_KEY));
		}
        return mailProperties;
	}
	
	/**
	 * Método encargado de reemplazar los argumentos en una cadena de texto dada.
	 * @param text Cadena de texto.
	 * @param args Argumentos a remplazar.
	 * @return Cadena de texto procesada.
	 */
	private String replaceArgs(String text, Map<String, String> args) {
		if (args != null && text != null) {
			Set<String> keySet = args.keySet();
			for (String key : keySet) {
				String value = args.get(key) != null ? args.get(key): "";
				text = text.replaceAll("\\{\\{[ ]*" + key + "[ ]*\\}\\}",
						Matcher.quoteReplacement(value));
			}
		}
		if (text == null) {
			text = "";
		}
		return text;
	}
	
	public void sendNotification(MailDto inDTO) throws MessagingException {
		logger.info("Iniciando envío de correo");
		MimeMessage message = javaMailSender.createMimeMessage();
		MimeMessageHelper helper = new MimeMessageHelper(message, true, encoding);
		helper.setFrom((inDTO.getFrom() != null)? inDTO.getFrom(): from);
		helper.setTo(inDTO.getTo());
		helper.setSubject(replaceArgs(inDTO.getSubject(), inDTO.getArgs()));
		helper.setText(inDTO.getText());
		javaMailSender.send(message);
		logger.info("Finalizado proceso de envío de correo");
	}

}
