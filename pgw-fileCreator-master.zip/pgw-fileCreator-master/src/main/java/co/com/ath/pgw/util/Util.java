package co.com.ath.pgw.util;

import java.io.BufferedWriter;
import java.io.File;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;
import java.nio.file.StandardOpenOption;
import java.util.Comparator;
import java.util.stream.Stream;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * This class contains global method to be used in any other class
 * 
 * @author Javier Esteban Flórez Rincón <javier.florez@sophossolutions.com>
 * @version 1.0 03/08/2020
 * 
 * @sophosSolutions <strong>Autor: </strong>Javier Esteban Flórez Rincon</br>
 *                  <strong>Número de Cambios: </strong>0</br>
 *
 */
public class Util {
	
	private static final Logger logger = LoggerFactory.getLogger(Util.class);
	
	private Util() {}
	
	/**
	 * Read a specific file
	 * @param path Path to the file to read
	 * @return The lines of the file in a String array or null if an error ocurrs
	 */
	public static String[] readFile(String path) {
		try {
			Path file = Paths.get(path);
			try (Stream<String> linesStream = Files.lines(file, StandardCharsets.ISO_8859_1)) {
				return linesStream.toArray(String[]:: new);
			}
		} catch (Exception e) {
			logger.error("Se ha presentado ejecutando la lectura de archivo: {}", e.getMessage(), e);
		}
		return null;
	}
	
	/**
	 * Write the text in a specific file
	 * @param path Path to the file to write
	 * @param body The text to write in the file
	 */
	public static void writeFile(String path, String body) {
		try {
			Path file = Paths.get(path);

			Files.write(file, body.getBytes(), StandardOpenOption.APPEND);
		} catch (Exception e) {
			logger.error("Error ejecutando escritura en el archivo: {}", e.getMessage(), e);
		}
	}
	
	/**
	 * This method makes the copy in the new path
	 * @param source
	 * @param destiny
	 */
	public static void copyFiles(Path source, Path destiny) {
		try{
			Files.copy(source, destiny, StandardCopyOption.REPLACE_EXISTING);
		} catch (IOException ex) {
			logger.error("Error copiando archivos en directorio: {}", ex.getMessage(), ex);
		}
	}
	
	/**
	 * This method deletes the files in a specific path
	 * @param pathToBeDeleted The path to be deleted
	 * @return 1 if the operation is completed 0 if some error appears
	 */
	public static int deleteFiles(Path pathToBeDeleted) {
		try (Stream<Path> path = Files.walk(pathToBeDeleted)){
			path.sorted(Comparator.reverseOrder())
		    .map(Path::toFile)
		    .forEach(File::delete);
			return 1;
		} catch ( Exception ex) {
			logger.error("Error borrando archivos de directorio: {}", ex.getMessage(), ex);
		}
		return 0;
	}
	
}
