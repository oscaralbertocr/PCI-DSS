package co.com.ath.pgw.util;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import com.jcraft.jsch.Channel;
import com.jcraft.jsch.ChannelSftp;
import com.jcraft.jsch.JSch;
import com.jcraft.jsch.JSchException;
import com.jcraft.jsch.Session;
import com.jcraft.jsch.SftpATTRS;
import com.jcraft.jsch.SftpException;

/**
 * 
 * Clase para enviar un archivo por SFTP.
 *
 * @author Javier Esteban Florez Rincon <javier.florez@sophossolutions.com>
 * @version 1.0 08/08/2020
 * 
 **/

@Service
public class ConnectionFTP {

	@Value(value = "${pasarela.ftp.host}")
	private String host;

	@Value(value = "${pasarela.ftp.user}")
	private String user;

	@Value(value = "${pasarela.ftp.password}")
	private String password;

	@Value(value = "${pasarela.ftp.basePath}")
	private String basePath;
	
	@Value(value = "${pasarela.ftp.port}") 
	private int port;

	private static final Logger logger = LoggerFactory.getLogger(ConnectionFTP.class);

	public ConnectionFTP() {

	}

	/**
	 * 
	 * Constructor de la conexion
	 * 
	 * @param host el servidor al que se conectara
	 * @param user	el usuario con el se realizara la conexion
	 * @param basePath ruta origen del servidor
	 * @param contraseÃ±a del usuario
	 */
	
	public ConnectionFTP(String host, String user, String basePath, String password) {
		this.host = host;
		this.user = user;
		this.basePath = basePath;
		this.password = password;
	}

	/**
	 * 
	 * Metodo encargado de conectar al SSH (SFTP) y enviar el reporte.
	 * @param fileName
	 * @param directorio
	 */
	public void connect(String fileName, String directorio) {
		Session session = null;
		Channel channel = null;
		ChannelSftp channelSftp = null;
		String pathFinal = basePath + directorio;
		JSch jsch = new JSch();
		try {
			
			logger.info("Iniciando conexion FTP, se tratara de enviar el archivo: {}", fileName);
			logger.info("Ruta: {}", directorio);
			session = jsch.getSession(user, host, port);//C01
			session.setPassword(password);

			java.util.Properties config = new java.util.Properties();
			config.put("StrictHostKeyChecking", "no");
			session.setConfig(config);

			session.connect();

			channel = session.openChannel("sftp");
			channel.connect();

			logger.info("Conectado al FTP ");
			channelSftp = (ChannelSftp) channel;

			SftpATTRS attrs = null;
			attrs = channelSftp.stat(pathFinal);
			
			if (attrs != null) {
				logger.info("Directory exists IsDir= {}", attrs.isDir());
			} else {
				logger.info("Creating dir {}", basePath);
				channelSftp.mkdir(pathFinal);
			}

			channelSftp.cd(pathFinal);

			File f = new File(fileName);
			channelSftp.put(new FileInputStream(f), f.getName());

		} catch (SftpException e) {
			logger.error("Error para conectarse al ftp {}", e.getMessage(), e);

		} catch (FileNotFoundException e) {
			logger.error("El archivo no se encuentra en la ruta");
		} catch (JSchException e) {
			logger.error("Error para conectarse al ftp");
		} finally {
			if (channelSftp != null) {
				channelSftp.exit();
			}
			if (channel != null) {
				channel.disconnect();
			}
			if (session != null ) {
				session.disconnect();
			}
			logger.info("Host Session disconnected.");
		}

	}
	
	public String getHost() {
		return host;
	}

	public void setHost(String host) {
		this.host = host;
	}

	public String getUser() {
		return user;
	}

	public void setUser(String user) {
		this.user = user;
	}

	public String getBasePath() {
		return basePath;
	}

	public void setBasePath(String basePath) {
		this.basePath = basePath;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

}
