package co.com.ath.pgw.batch;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

import javax.annotation.PostConstruct;
import javax.annotation.Resource;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.batch.core.Job;
import org.springframework.batch.core.JobExecution;
import org.springframework.batch.core.JobParametersBuilder;
import org.springframework.batch.core.Step;
import org.springframework.batch.core.configuration.annotation.JobBuilderFactory;
import org.springframework.batch.core.configuration.annotation.StepBuilderFactory;
import org.springframework.batch.core.launch.JobLauncher;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;

import co.com.ath.pgw.file.tasklet.CommissionFileCreatorTasklet;
import co.com.ath.pgw.file.tasklet.EncryptPGPTasklet;
import co.com.ath.pgw.util.AVALBankEnum;

@Service
public class CommissionFileCreatorBatch {

	private static final Logger logger = LoggerFactory.getLogger(CommissionFileCreatorBatch.class);

	/**
	 * constructor del job
	 */
	@Resource
	private JobBuilderFactory jobBuilderFactory;
	
	/**
	 * constructor del Step
	 */
	@Resource
	private StepBuilderFactory stepBuilderFactory;
	
	/**
	 * job Launcher
	 */
	@Resource
	private JobLauncher jobLauncher;
	
	/**
	 * instanciamiento del Job
	 */
	private Job jobInstance;
	
	/**
	 * ruta local de los archivos
	 */
	@Value(value = "${pathLiquidacion}")
	private String pathLiquidacion;
	
	@Value(value = "${workspace}")
	private String workspace;	
	
	/**
	 * Pattern del archivo
	 */
	private static final String FILE_NAME_PATTERN = "%s_Pagos_PortalDePagos_%s";
	
	/**
	 * nombre del Job
	 */
	private static final String JOB_NAME = "COMISION_REPORT_JOB";
	
	/**
	 * nombre del Step
	 */
	private static final String STEP_NAME = "CREATE_COMMISSION_REPORT_STEP";
	
	/**
	 * nombre del Step de encriptación
	 */
	private static final String STEP_ENCRYPT_NAME = "CREATE_ENCRYPTION_REPORT_STEP";
	
	@Autowired(required=true)
	private CommissionFileCreatorTasklet commissionFileCreator;
	
	@Autowired(required=true)
	private EncryptPGPTasklet encryptPGP;
	
	@PostConstruct
	public void init() {
		jobInstance = createJob();
	}
	
	private Job createJob() {
		return jobBuilderFactory.get(JOB_NAME)
				.flow(generateReportStep())
				.next(generateEncryptTasklet())
				.end()
				.build();
	}

	private Step generateReportStep() {
		return stepBuilderFactory.get(STEP_NAME)
				.tasklet(this.commissionFileCreator)
				.build();
	}
	
	private Step generateEncryptTasklet() {
		return stepBuilderFactory.get(STEP_ENCRYPT_NAME)
				.tasklet(encryptPGP)
				.build();
	}
	
	
	/**
	 * Metodo encargado de ejecutar el reporte diario
	 */
	@Scheduled(cron="${createMonthlyReportCron}")
	public void run() {
		logger.info("::: Activacion de cron :::");
		Calendar calendar = Calendar.getInstance();
		calendar.add(Calendar.DATE, -1);
		Date curDate = calendar.getTime();
		try {
			AVALBankEnum[] bancosAval = AVALBankEnum.values();
			for( AVALBankEnum avalBank : bancosAval ){
				logger.info("Reporte de liquidacion diario para el banco {}", avalBank.getInitialBank());
				executeJob(getFileName(avalBank.getInitialBank(), curDate), avalBank.getCompensationCode());
			}
		} catch (Exception ex) {
			logger.error("Error no esperado iniciando la generacion de archivos de Liquidacion Comisiones Mensual: {}", ex.getMessage(),  ex);
		}
	}
	
	/**
	 * Metodo que crea el nombre del reporte
	 * @param initialBank
	 * @param currentDate
	 * @return
	 */
	private String getFileName(String initialBank,Date currentDate) {
		SimpleDateFormat format;
		format = new SimpleDateFormat("yyyyMM");
		
		return String.format(FILE_NAME_PATTERN,initialBank,format.format(currentDate));
	}
	
	/**
	 * Metodo encargado de cargar las variables para el reporte
	 * @param fileName
	 * @param DateStart
	 * @param DateEnd
	 * @param avalBank
	 * @return
	 */
	private JobExecution executeJob(String fileName, String bankCode) {
		JobExecution jobExecution;
		try {
			JobParametersBuilder jobParams = new JobParametersBuilder();
			jobParams.addString("workspace", workspace);
			jobParams.addString("filePathLiquidacion", pathLiquidacion);
			jobParams.addString("fileName", fileName);
			jobParams.addString("bankCode", bankCode);
			
			jobExecution = jobLauncher.run(jobInstance, jobParams.toJobParameters());
		} catch (Exception ex) {
			jobExecution = null;
			logger.error("Error ejecutando job: {}", ex.getMessage(), ex);
		}
		return jobExecution;
	}	
	
}
