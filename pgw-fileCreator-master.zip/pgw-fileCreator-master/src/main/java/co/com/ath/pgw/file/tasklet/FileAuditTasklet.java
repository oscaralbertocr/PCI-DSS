package co.com.ath.pgw.file.tasklet;

import org.springframework.batch.core.step.tasklet.Tasklet;

public interface FileAuditTasklet extends Tasklet{
	
	/**
	 * Method that get the daily files and read them
	 */
	public void auditDailyFile();
	
	/**
	 * Validate the footer line in a file comparating with the calculated footer
	 */
	public void validateFile(String footer, String footerCalculated);
	
}
