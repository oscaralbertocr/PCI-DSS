package co.com.ath.pgw.encrypt;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import co.com.ath.pgw.util.PGPUtils;

@Service
public class EncrypterService {
	
private static final Logger logger = LoggerFactory.getLogger(EncrypterService.class);
	
    private String passphrase;
    private String publicKeyFileName;
    private String secretKeyFileName;
    private String inputFileName;
    private String outputFileName;
    private boolean asciiArmored = false;
    private boolean integrityCheck = true;
    
    /**
	 * Encrypta el archivo. Retorna true si el encriptado es correcto, false en otro caso 
	 * @return boolean
	*/
    public boolean encrypt() throws IOException {
    	logger.info("----------- Iniciando encriptación archivo --------------");
		logger.info("LEYENDO EL ARCHIVO: {}", this.inputFileName);
		logger.info("USANDO LLAVE PUBLICA: {}", this.publicKeyFileName);
    	try (FileInputStream keyIn = new FileInputStream(this.publicKeyFileName);
    			FileOutputStream out =  new FileOutputStream(this.outputFileName)){
    		logger.info("GENERANDO ARCHIVO ENCRIPTADO: {}", this.outputFileName);
            PGPUtils.encryptFile(out, this.inputFileName, PGPUtils.readPublicKey(keyIn), this.asciiArmored, this.integrityCheck);
            logger.info("TERMINANDO PROCESO DE ENCRIPTADO");
            logger.info("------------Finalizada encriptación archivo --------------");
            return true;
		} catch (Exception e) {
			logger.info("ERROR EN EL PROCESO DE ENCRIPTADO");
			logger.info("TERMINANDO PROCESO");
			logger.info("-------------Finalizado proceso ----------------");
			return false;
		}
    }
 
    public boolean isAsciiArmored() {
            return this.asciiArmored;
    }
 
    public void setAsciiArmored(boolean asciiArmored) {
            this.asciiArmored = asciiArmored;
    }
 
    public boolean isIntegrityCheck() {
            return this.integrityCheck;
    }
 
    public void setIntegrityCheck(boolean integrityCheck) {
            this.integrityCheck = integrityCheck;
    }
 
    public String getPassphrase() {
            return this.passphrase;
    }
 
    public void setPassphrase(String passphrase) {
            this.passphrase = passphrase;
    }
 
    public String getPublicKeyFileName() {
            return this.publicKeyFileName;
    }
 
    public void setPublicKeyFileName(String publicKeyFileName) {
            this.publicKeyFileName = publicKeyFileName;
    }
 
    public String getSecretKeyFileName() {
            return this.secretKeyFileName;
    }
 
    public void setSecretKeyFileName(String secretKeyFileName) {
            this.secretKeyFileName = secretKeyFileName;
    }
 
    public String getInputFileName() {
            return this.inputFileName;
    }
 
    public void setInputFileName(String inputFileName) {
            this.inputFileName = inputFileName;
    }
 
    public String getOutputFileName() {
            return this.outputFileName;
    }
 
    public void setOutputFileName(String outputFileName) {
            this.outputFileName = outputFileName;
    }
}
