package co.com.ath.pgw.batch;

import java.io.File;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

import javax.annotation.PostConstruct;
import javax.annotation.Resource;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.batch.core.Job;
import org.springframework.batch.core.JobExecution;
import org.springframework.batch.core.JobParametersBuilder;
import org.springframework.batch.core.Step;
import org.springframework.batch.core.configuration.annotation.JobBuilderFactory;
import org.springframework.batch.core.configuration.annotation.StepBuilderFactory;
import org.springframework.batch.core.launch.JobLauncher;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;

import co.com.ath.pgw.file.tasklet.FileAuditTasklet;
import co.com.ath.pgw.util.AVALBankEnum;

@Service
public class FileAuditBatch {

	private static final Logger logger = LoggerFactory.getLogger(FileAuditBatch.class);

	/**
	 * constructor del job
	 */
	@Resource
	private JobBuilderFactory jobBuilderFactory;
	
	/**
	 * constructor del Step
	 */
	@Resource
	private StepBuilderFactory stepBuilderFactory;
	
	/**
	 * job Launcher
	 */
	@Resource
	private JobLauncher jobLauncher;
	
	/**
	 * instanciamiento del Job
	 */
	private Job jobInstance;
	
	/**
	 * ruta local de los archivos
	 */
	@Value(value = "${pathLiquidacion}")
	private String pathLiquidacion;
	
	/**
	 * Pattern del archivo
	 */
	private static final String FILE_NAME_PATTERN = "%s_Pagos_PortalDePagos_%s.DAT";
	
	/**
	 * nombre del Job
	 */
	private static final String JOB_NAME = "AUDIT_REPORT_JOB";
	/**
	 * nombre del Step
	 */
	private static final String STEP_NAME = "AUDIT_REPORT_STEP";
	
	@Autowired(required=true)
	private FileAuditTasklet fileAuditTasklet;
	
	@PostConstruct
	public void init() {
		jobInstance = createJob();
	}
	
	private Job createJob() {
		return jobBuilderFactory.get(JOB_NAME)
				.flow(generateReportStep())
				.end()
				.build();
	}

	private Step generateReportStep() {
		return stepBuilderFactory.get(STEP_NAME)
				.tasklet(this.fileAuditTasklet)
				.build();
	}
	
	
	/**
	 * Metodo encargado de ejecutar el reporte diario
	 */
	@Scheduled(cron="${auditReportCron}")
	public void run() {
		logger.info("::: Activacion de cron :::");
		Calendar calendar = Calendar.getInstance();
		calendar.add(Calendar.DATE, -1);
		Date curDate = calendar.getTime();
		try {
			AVALBankEnum[] bancosAval = AVALBankEnum.values();
			for( AVALBankEnum avalBank : bancosAval ){
				logger.info("Reporte de liquidacion diario para el banco {}", avalBank.getInitialBank());
				executeJob(getFileName(avalBank.getInitialBank(), curDate));
			}
		} catch (Exception ex) {
			logger.error("Error no esperado iniciando la generacion de archivos de Liquidacion Comisiones Mensual: {}", ex.getMessage(),  ex);
		}
	}
	
	/**
	 * Metodo que crea el nombre del reporte
	 * @param initialBank
	 * @param currentDate
	 * @return
	 */
	private String getFileName(String initialBank,Date currentDate) {
		SimpleDateFormat format;
		format = new SimpleDateFormat("yyyyMMdd");
		
		return String.format(FILE_NAME_PATTERN,initialBank,format.format(currentDate));
	}
	
	/**
	 * Metodo encargado de cargar las variables para el reporte
	 * @param fileName
	 * @param DateStart
	 * @param DateEnd
	 * @param avalBank
	 * @return
	 */
	private JobExecution executeJob(String fileName) {
		JobExecution jobExecution;
		try {
			String pathFile = pathLiquidacion + File.separator + fileName;
			JobParametersBuilder jobParams = new JobParametersBuilder();
			jobParams.addString("filePathLiquidacion", pathFile);
			
			jobExecution = jobLauncher.run(jobInstance, jobParams.toJobParameters());
		} catch (Exception ex) {
			jobExecution = null;
			logger.error("Error ejecutando job: {}", ex.getMessage(), ex);
		}
		return jobExecution;
	}	
	
}
