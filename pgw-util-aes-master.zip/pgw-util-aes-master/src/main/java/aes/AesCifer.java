package aes;

import java.nio.charset.StandardCharsets;
import java.security.InvalidKeyException;
import java.security.SecureRandom;
import java.util.Arrays;
import java.util.Base64;

import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.spec.GCMParameterSpec;
import javax.crypto.spec.SecretKeySpec;

public class AesCifer{
	private final static int GCM_IV_LENGTH = 12;
	private final static int GCM_TAG_LENGTH = 16;
	static SecretKey skey;
	static SecretKeySpec key;
	static byte[] arrayBytes;
	

	private static String encrypt(String privateString) throws Exception {
		try {
			byte[] iv = new byte[GCM_IV_LENGTH];
			(new SecureRandom()).nextBytes(iv);

			Cipher cipher = Cipher.getInstance("AES/GCM/NoPadding");
			GCMParameterSpec ivSpec = new GCMParameterSpec(GCM_TAG_LENGTH * Byte.SIZE, iv);

			key = new SecretKeySpec(arrayBytes,"AES");
			cipher.init(Cipher.ENCRYPT_MODE, key, ivSpec);

			byte[] ciphertext = cipher.doFinal(privateString.getBytes("UTF8"));
			byte[] encrypted = new byte[iv.length + ciphertext.length];
			System.arraycopy(iv, 0, encrypted, 0, iv.length);
			System.arraycopy(ciphertext, 0, encrypted, iv.length, ciphertext.length);

			String encoded = Base64.getEncoder().encodeToString(encrypted);
			return encoded;
		} catch (Exception e) {
			System.out.println("Error");
		}
		return null;
	}



	private static String decrypt(String encrypted) throws Exception {
		try {
			byte[] decoded = Base64.getDecoder().decode(encrypted);

			byte[] iv = Arrays.copyOfRange(decoded, 0, GCM_IV_LENGTH);

			Cipher cipher = Cipher.getInstance("AES/GCM/NoPadding");
			GCMParameterSpec ivSpec = new GCMParameterSpec(GCM_TAG_LENGTH * Byte.SIZE, iv);
			key = new SecretKeySpec(arrayBytes,"AES");
			cipher.init(Cipher.DECRYPT_MODE, key, ivSpec);
			byte[] ciphertext = cipher.doFinal(decoded, GCM_IV_LENGTH, decoded.length - GCM_IV_LENGTH);
			String result = new String(ciphertext, "UTF8");
			return result;
		} catch (InvalidKeyException e) {
			e.printStackTrace();
		}
		return null;
	}

	public static void main(String[] args) {
		try { 
			arrayBytes = "58TM_47H_2020_PR0C3551N6".getBytes(StandardCharsets.UTF_8);
			String opcion =  args[0];
			String r = "";
			switch(opcion) {
			case "encrypt": 
				r = encrypt(args[1]);
				break;
			case "decrypt":
				r = decrypt(args[1]);
				break;
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	
}



