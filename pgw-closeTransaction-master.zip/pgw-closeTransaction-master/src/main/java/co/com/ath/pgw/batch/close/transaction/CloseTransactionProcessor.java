package co.com.ath.pgw.batch.close.transaction;

import javax.annotation.PostConstruct;
import javax.annotation.Resource;

import org.springframework.batch.item.ItemProcessor;
import org.springframework.stereotype.Service;

import co.com.ath.pgw.persistence.dao.PaymentWayDAO;
import co.com.ath.pgw.persistence.dao.ResponseCodeDAO;
import co.com.ath.pgw.persistence.dao.ResponseCodeForPaymentWayDAO;
import co.com.ath.pgw.persistence.dao.TransactionStatusDAO;
import co.com.ath.pgw.persistence.model.Transaction;
import co.com.ath.pgw.persistence.model.TransactionStatus;
import co.com.ath.pgw.util.enums.TransactionStatusEnum;

@Service
public class CloseTransactionProcessor implements
ItemProcessor<Transaction, Transaction> {

	@Resource
	private TransactionStatusDAO transactionStatusDAO;
	
	@Resource
	private ResponseCodeForPaymentWayDAO responseCodeForPaymentWayDAO;

	@Resource
	private ResponseCodeDAO responseCodeDAO;

	@Resource
	private PaymentWayDAO paymentWayDAO;

	private TransactionStatus transactionStatusFailed;
	
	@PostConstruct
	public void init(){
		transactionStatusFailed = transactionStatusDAO.read(TransactionStatusEnum.FAILED.getCode());
	}

	@Override
	public Transaction process(Transaction item){
		TransactionStatusEnum transactionStatusDesc = item.getStatus().getDescription();
		if ((TransactionStatusEnum.PROCESSING.getCode().equals(transactionStatusDesc.getCode()) ||
				TransactionStatusEnum.REGISTERED.getCode().equals(transactionStatusDesc.getCode()) ||
				TransactionStatusEnum.LOGGED_IN.getCode().equals(transactionStatusDesc.getCode())) 
				) {
			item.setStatus(transactionStatusFailed);
		}
		return item;
	}
	
}
