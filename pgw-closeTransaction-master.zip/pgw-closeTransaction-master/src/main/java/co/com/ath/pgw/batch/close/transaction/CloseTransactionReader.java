package co.com.ath.pgw.batch.close.transaction;

import java.sql.Timestamp;
import java.util.HashMap;
import java.util.Map;

import javax.annotation.PostConstruct;
import javax.annotation.Resource;
import javax.persistence.EntityManagerFactory;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.batch.core.configuration.annotation.StepScope;
import org.springframework.batch.item.database.JpaPagingItemReader;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import co.com.ath.pgw.persistence.model.Transaction;
import co.com.ath.pgw.util.enums.TransactionStatusEnum;

@Service
@StepScope
public class CloseTransactionReader extends JpaPagingItemReader<Transaction> {
	
	private static final Logger LOGGER = LoggerFactory.getLogger(CloseTransactionReader.class);
	
	@Resource
	private EntityManagerFactory entityManagerFactory;

	@Value("#{jobParameters[transactionDate]}")
	private Timestamp transactionTimeoutPending;
	
	@Value("#{jobExecutionContext.jobId}")
	private Long jobId;

	@PostConstruct
	public void init() {
		this.setEntityManagerFactory(entityManagerFactory);
		this.setQueryString(queryString());
		this.setParameterValues(parameterValues());
	}
	
	/**
	 * Método encargado de obtener el query que consulta las transacciones pendientes
	 * cuyo tiempo de respuesta ya haya caducado
	 * @return JPQA de la consulta.
	 */
	private String queryString() {
		StringBuilder jpql = new StringBuilder("SELECT t FROM Transaction t ");
		jpql.append("WHERE t.status.code IN (:transactionStatusPro, :transactionStatusReg, :transactionStatusLogIn) ");
		jpql.append(" AND t.jobLockId = :jobId ");
		return jpql.toString();
	}

	/**
	 * Método encargado de retornar los parametros que se envían a la consulta JPA.
	 * @return Mapa con los parametros de la consulta.
	 */
	private Map<String, Object> parameterValues() {
		Map<String, Object> parameterValues = new HashMap<>();
		parameterValues.put("transactionStatusPro", TransactionStatusEnum.PROCESSING.getCode());
		parameterValues.put("transactionStatusReg", TransactionStatusEnum.REGISTERED.getCode());
		parameterValues.put("transactionStatusLogIn", TransactionStatusEnum.LOGGED_IN.getCode());
		parameterValues.put("jobId", jobId);
		
		LOGGER.info("reader date : "+transactionTimeoutPending + "jobID: "+jobId);
		return parameterValues;
	}

}
