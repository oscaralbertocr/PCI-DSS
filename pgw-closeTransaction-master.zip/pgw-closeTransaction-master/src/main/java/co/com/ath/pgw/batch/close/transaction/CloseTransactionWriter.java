package co.com.ath.pgw.batch.close.transaction;

import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

import javax.annotation.Resource;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.batch.item.ItemWriter;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import co.com.ath.pgw.bsn.service.rs.NotificationPayments;
import co.com.ath.pgw.persistence.dao.BrandDAO;
import co.com.ath.pgw.persistence.dao.TransactionDAO;
import co.com.ath.pgw.persistence.dao.TransactionStatusDAO;
import co.com.ath.pgw.persistence.model.Brand;
import co.com.ath.pgw.persistence.model.Transaction;
import co.com.ath.pgw.persistence.model.TransactionStatus;
import co.com.ath.pgw.util.constants.CoreConstants;
import co.com.ath.pgw.util.constants.PaymentWayCodes;
import co.com.ath.pgw.util.enums.AVALBankEnum;
import co.com.ath.pgw.util.enums.TransactionStatusEnum;
import co.com.ath.pgw.util.mailservice.impl.MailServiceImpl;
import co.com.ath.pgw.util.mask.MaskData;
import co.com.ath.ws.rs.objects.BankInfo;
import co.com.ath.ws.rs.objects.TransactionNotification;

@Service
public class CloseTransactionWriter implements ItemWriter<Transaction> {
	
	private static final Logger LOGGER = LoggerFactory.getLogger(CloseTransactionWriter.class);

	@Resource
	private TransactionDAO transactionDAO;
	
	@Resource
	private MailServiceImpl mailService;

	@Resource
	private MaskData maskData;

	@Value("${pasarela.mail.subject.payment.confirmation}")
	private String subject;

	@Value("${pasarela.pse.url}")
	private String paymentURL;

	@Value("${pasarela.mail.template.images.url}")
	private String imageRepoURL;

	@Value("${pasarela.mail.template.default.header.url}")
	private String defaultHeader;

	private Locale locale = Locale.getDefault();

	@Value("${pasarela.pse.nitagregador}")
	private String nitAgregator;

	@Value("${pasarela.pse.nitagregador.avVillas}")
	private String nitAgregatorAvVillas;

	@Value("${pasarela.mail.template.path}")
	private String tempFiles;

	@Resource
	private NotificationPayments notificationPayments;

	@Value("${notification.batch}")
	private Integer batchTimeNotification;	

	@Resource
	private BrandDAO brandDAO;

	@Resource
	private TransactionStatusDAO transactionStatusDAO;

	@Override
	public void write(List<? extends Transaction> items){
		
		for (Transaction transaction : items) {

			transactionDAO.update(transaction);
			LOGGER.info("Transaccion pmtid {} se almacena con estado {}", 
					transaction.getPmtId(), transaction.getStatus().getDescription());			

			Transaction tx = transactionDAO.read(transaction.getId());
				if (transaction.getNotificacionPPagos() == null || transaction.getNotificacionPPagos()==0) {
					if (updatePSEInformation(tx)) {
						transaction.setNotificacionPPagos(1);
						transactionDAO.update(transaction);	
						LOGGER.info("Se actualizo el estado de notificacion a portal de pagos: {}",transaction.getPmtId());
					}
				}			
		}		
	}


	/**
	 * Se informa al Portal de Pagos el estado de la transaccion
	 */
	private boolean updatePSEInformation(Transaction transaction) {
		boolean result= true;
		try {
			TransactionNotification transactionNotification =new TransactionNotification();

			transactionNotification.setBusinessCode(transaction.getStatus().getBusinessCode().getCode());
			transactionNotification.setBusinessCodeDesc(transaction.getStatus().getBusinessCode().getDescription().name());
			transactionNotification.setCommerceNuraCode(transaction.getCommerce().getNuraCode());
			transactionNotification.setPmtId(transaction.getPmtId());
			transactionNotification.setRquId(transaction.getRquId());
			transactionNotification.setTrnChannel(transaction.getTrnChannel());
			transactionNotification.setIpAddress(transaction.getIpAddress());
			transactionNotification.setCustomerDocId(transaction.getCustomerDocId());
			transactionNotification.setCustomerDocType(transaction.getCustomerDocType());
			transactionNotification.setAmt(transaction.getTotalValue());
			transactionNotification.setCurCode(transaction.getCurrency());				
			transactionNotification.setAgreementId(getAgrementId(transaction));
			transactionNotification.setName(transaction.getCommerce().getSubscription().getCompanyName());
			transactionNotification.setNit(transactionDAO.getAggregatorNit(transaction, nitAgregator, nitAgregatorAvVillas));
			transactionNotification.setPhone(transaction.getCommerce().getSubscription().getPhone());								
			transactionNotification.setFirstName(transaction.getCustomerName() != null ? transaction.getCustomerName() : "");
			transactionNotification.setMiddleName(transaction.getMiddleNameBuyer() != null ? transaction.getMiddleNameBuyer() : "");
			transactionNotification.setLastName(transaction.getLastNameBuyer() != null ? transaction.getLastNameBuyer() : "");
			transactionNotification.setSecondLastName(transaction.getSecondLastNameBuyer() != null ? transaction.getSecondLastNameBuyer() : "");				
			transactionNotification.setCustIdType(transaction.getPayerDocType() != null ? transaction.getPayerDocType() : "");
			transactionNotification.setCustIdNum(transaction.getPayerDocId() != null ? transaction.getPayerDocId() : "");
			transactionNotification.setAddress(transaction.getPayerAddress());
			transactionNotification.setEmailAddr(transaction.getPayerMail() != null ? transaction.getPayerMail() : "");
			transactionNotification.setPhone(transaction.getPayerPhone() != null ? transaction.getPayerPhone() : "");				
			transactionNotification.setRquId(transaction.getRquId());
			transactionNotification.setPmtId(transaction.getPmtId());
			transactionNotification.setTrnChannel(transaction.getTrnChannel());				
			transactionNotification.setStatusCode(transaction.getStatus().getCode());
			transactionNotification.setStatusDesc(transaction.getStatus().getDescription().toString());
			transactionNotification.setOrderId(transaction.getOrderNumber()); 
			transactionNotification.setOrderDesc(transaction.getDescription());				
			transactionNotification.setPmtWayId(String.valueOf(transaction.getPaymentWay().getId()));
			transactionNotification.setPmtWayType(transaction.getPaymentWay().getName());

			BankInfo bankInfo = new BankInfo();
			bankInfo.setBankId(transaction.getBank() == null ? null : transaction.getBank().getAvalCode());	
			transactionNotification.setBankInfo(bankInfo);
			transactionNotification.setEffDt(getDate(transaction));
			transactionNotification.setCompensationDate(transaction.getCompensationDate());
			transactionNotification.setApprovalId(PaymentWayCodes.PSE.equals(transaction.getPaymentWay().getId()) ? transaction.getTrazabilityCode()
					: transaction.getApprovalNumber());
			transactionNotification.setReferenceMap(getReferenceMap(transaction, true));
			transactionNotification.setIdOrigenTransaccion(transaction.getSource().getId().toString());
			String codNie = "";

			LOGGER.info("Validacion de tipo de pago PSE y pago de tarjeta de credito. tipo de pago: {}, token: {}", transaction.getPaymentWay().getId(), transaction.getTokenized());

			if(PaymentWayCodes.PSE.equals(transaction.getPaymentWay().getId()) && transaction.getTokenized()!=null ) {
				LOGGER.info("Validacion de tipo de pago PSE y pago de tarjeta de credito se encontro");
				codNie = transaction.getTokenized();
			}else {
				LOGGER.info("Validacion de tipo de pago PSE y pago de tarjeta de credito No se encontro");
			}
			transactionNotification.setCodNIE(codNie);			

			result=notificationPayments.notification(transactionNotification);	
		} catch (Exception e) {
			result = false;
			LOGGER.error("No fue posible consumir el servicio @NotificationPayments {}",
					e.getLocalizedMessage());
		}
		return result;
	}

	private String getAgrementId(Transaction transaction) {
		String nuraCode = transaction.getCommerce().getNuraCode();
		final boolean needHomologate = transaction.getBank() != null
				&& AVALBankEnum.AV_VILLAS.getAvalCode().equals(transaction.getBank().getAvalCode())
				&& transaction.getCommerce().getHomologationBAVVCode() != null;
		if (needHomologate) {
			return transaction.getCommerce().getHomologationBAVVCode();
		}

		if (nuraCode.startsWith("CPV")) {
			nuraCode = nuraCode.substring(3, nuraCode.length());
		}

		return nuraCode;
	}

	private Date getDate(Transaction transaction) {
		if (transaction.getRowLastUpdate() != null) {
			return transaction.getRowLastUpdate();
		}
		return transaction.getTransactionDate();
	}

	/**
	 * Obtiene las referencias de la transaccion y las retorna en una lista de
	 * string.
	 * 
	 * @param tx
	 *            Transaccion a procesar
	 * @return Lista con las referencias encontradas o lista vacia si no hay
	 *         ninguna.
	 */
	private Map<String, String> getReferenceMap(Transaction transaction, boolean fillPaymetWay) {
		Map<String, String> refMap = new HashMap<>();
		if (transaction == null) {
			return refMap;
		}
		if (fillPaymetWay) {
			// Validar el medio de pago para incluir informacion adicional
			if (transaction.getPaymentWay() != null) {
				if ((PaymentWayCodes.PAGOS_AVAL.equals(transaction.getPaymentWay().getId())
						|| PaymentWayCodes.PSE.equals(transaction.getPaymentWay().getId())) && transaction.getBank() != null) {
					refMap.put("BankId", transaction.getBank().getAvalCode());
					refMap.put("BankName", transaction.getBank().getName());
				}

				if ( PaymentWayCodes.TC.equals(transaction.getPaymentWay().getId()) 
						&& transaction.getIdBrand() != null) {

					Brand brand = brandDAO.read(Long.valueOf(transaction.getIdBrand().toString()));
					refMap.put("Brand", brand.getName());

					if ( transaction.isGlobalPay() != null && transaction.isGlobalPay() ) {
						refMap.put("CardEmbossNum", transaction.getCreditCardNumber());
					}

				}		

				TransactionStatus transactionStatus = transactionStatusDAO.findById(TransactionStatusEnum.REFUSED.getCode());
				if (PaymentWayCodes.PSE.equals(transaction.getPaymentWay().getId()) && transaction.getStatus()!=transactionStatus) {
					refMap.put("TrnCycle", transaction.getTrnCycle());
					refMap.put("AchBankCode", transaction.getBank().getAchCode());
				}
			}
		}

		if (transaction.getReference1() != null && !transaction.getReference1().trim().isEmpty()) {
			refMap.put("Reference1", transaction.getReference1());
		}
		if (transaction.getReference2() != null && !transaction.getReference2().trim().isEmpty()) {
			refMap.put("Reference2", transaction.getReference2());
		}
		if (transaction.getReference3() != null && !transaction.getReference3().trim().isEmpty()) {
			refMap.put("Reference3", transaction.getReference3());
		}

		// Ventanilla de Pagos
		if (transaction.getPlantilla() == CoreConstants.TAQUILLA_ON) {
			refMap.put("Template", CoreConstants.TAQUILLA_ON.toString());
			refMap.put("Theme", transaction.getTaquilla().getIdTaquilla().toString());
			refMap.put("LogoURL", new String(transaction.getUrlLogo()));
		} else if (transaction.getPlantilla() == CoreConstants.TAQUILLA_OFF) {
			refMap.put("Template", CoreConstants.TAQUILLA_OFF.toString());
		}

		return refMap;
	}
}