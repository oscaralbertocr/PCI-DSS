package co.com.ath.pgw.batch.config;

import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;


@Configuration
@ComponentScan(basePackages = { 
		"co.com.ath.pgw.persistence.dao",
		"co.com.ath.pgw.persistence.model",
		"co.com.ath.pgw.persistence.service",
		"co.com.ath.pgw.batch.persistence",
		"co.com.ath.pgw.util",
		"co.com.ath.pgw.controller.out.ach",
		"co.com.ath.pgw.ws.client.payments",
		"co.com.ath.pgw.controller.out.rbm.globalPay",
		"co.com.ath.pgw.bsn.service.rs",
		"co.com.ath.pgw.audit"
		})
public class PersistenceConfig {


}
