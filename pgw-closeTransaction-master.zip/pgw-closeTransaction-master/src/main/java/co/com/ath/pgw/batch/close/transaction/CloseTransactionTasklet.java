package co.com.ath.pgw.batch.close.transaction;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.annotation.Resource;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.batch.core.JobExecution;
import org.springframework.batch.core.StepContribution;
import org.springframework.batch.core.scope.context.ChunkContext;
import org.springframework.batch.core.step.tasklet.Tasklet;
import org.springframework.batch.repeat.RepeatStatus;
import org.springframework.stereotype.Service;

import co.com.ath.pgw.persistence.dao.TransactionDAO;
import co.com.ath.pgw.util.enums.TransactionStatusEnum;

@Service
public class CloseTransactionTasklet implements Tasklet {
	
	private static final Logger LOGGER = LoggerFactory.getLogger(CloseTransactionTasklet.class);

	@Resource
	private TransactionDAO transactionDAO;

	@Override
	public RepeatStatus execute(StepContribution contribution,
			ChunkContext chunkContext) {

		List<TransactionStatusEnum> statusList = new ArrayList<>();

		statusList.add(TransactionStatusEnum.REGISTERED);
		statusList.add(TransactionStatusEnum.LOGGED_IN);
		statusList.add(TransactionStatusEnum.PROCESSING);

		JobExecution jobExecution = chunkContext.getStepContext().getStepExecution().getJobExecution();

		jobExecution.getExecutionContext().putLong("jobId", jobExecution.getId());

		Date transactionDate = jobExecution.getJobParameters().getDate("transactionDate");
		LOGGER.info("tasklet fecha: "+transactionDate);
		transactionDAO.lockTransaction(jobExecution.getId(), transactionDate, statusList);

		return RepeatStatus.FINISHED;

	}
}
