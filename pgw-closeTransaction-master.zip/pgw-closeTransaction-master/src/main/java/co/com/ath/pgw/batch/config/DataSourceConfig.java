package co.com.ath.pgw.batch.config;

import java.util.HashMap;

import javax.naming.NamingException;
import javax.sql.DataSource;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.batch.core.configuration.annotation.BatchConfigurer;
import org.springframework.batch.core.explore.JobExplorer;
import org.springframework.batch.core.explore.support.JobExplorerFactoryBean;
import org.springframework.batch.core.launch.JobLauncher;
import org.springframework.batch.core.launch.support.SimpleJobLauncher;
import org.springframework.batch.core.repository.JobRepository;
import org.springframework.batch.core.repository.support.JobRepositoryFactoryBean;
import org.springframework.batch.support.DatabaseType;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.PropertySource;
import org.springframework.core.env.Environment;
import org.springframework.core.task.SimpleAsyncTaskExecutor;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;
import org.springframework.jndi.JndiTemplate;
import org.springframework.orm.jpa.JpaTransactionManager;
import org.springframework.orm.jpa.LocalContainerEntityManagerFactoryBean;
import org.springframework.orm.jpa.vendor.HibernateJpaVendorAdapter;
import org.springframework.transaction.PlatformTransactionManager;

@Configuration
@PropertySource({ "file:D:/pgw-core-config/pgw-config.properties" })
@EnableJpaRepositories(basePackages = "co.com.ath.pgw.persistence", 
	entityManagerFactoryRef = "prvEntityManager", 
	transactionManagerRef = "prvTransactionManager")
public class DataSourceConfig implements BatchConfigurer {

	private static final Logger LOGGER = LoggerFactory.getLogger(DataSourceConfig.class);
	@Autowired
	private Environment environment;

	@Bean
	public LocalContainerEntityManagerFactoryBean prvEntityManager() {
		LocalContainerEntityManagerFactoryBean localContainerEntityManagerFactoryBean = new LocalContainerEntityManagerFactoryBean();
		try {
			DataSource datasource = prvDataSource();
			localContainerEntityManagerFactoryBean.setDataSource(datasource);
		} catch (NamingException e) {
			LOGGER.error("@LocalContainerEntityManagerFactoryBean error: {}: ", e.getMessage() );
		}
		
		localContainerEntityManagerFactoryBean.setPackagesToScan(new String[] { "co.com.ath.pgw.persistence.model" });

		HibernateJpaVendorAdapter vendorAdapter = new HibernateJpaVendorAdapter();
		localContainerEntityManagerFactoryBean.setJpaVendorAdapter(vendorAdapter);
		HashMap<String, Object> properties = new HashMap<>();
		
		properties.put("spring.datasource.tomcat.initial-size", 1);
		properties.put("spring.datasource.tomcat.max-wait", 2000);
		properties.put("spring.datasource.tomcat.max-active", 50);
		properties.put("spring.datasource.tomcat.min-idle", 1);
		properties.put("spring.datasource.tomcat.default-auto-commit", true);
		properties.put("spring.datasource.tomcat.max-idle", 1);
		properties.put("hibernate.hbm2ddl.auto", environment.getProperty("hibernate.hbm2ddl.auto"));
		properties.put("hibernate.dialect", environment.getProperty("hibernate.dialect"));
		
		localContainerEntityManagerFactoryBean.setJpaPropertyMap(properties);

		return localContainerEntityManagerFactoryBean;
	}

	@Bean (destroyMethod = "")
	public DataSource prvDataSource() throws NamingException {
		return (DataSource) new JndiTemplate().lookup(environment.getProperty("jdbc.url.batch"));

	}


	@Override
	public JobExplorer getJobExplorer() throws Exception {
		JobExplorerFactoryBean factory = new JobExplorerFactoryBean();
		factory.setDataSource(prvDataSource());
		factory.afterPropertiesSet();
		return factory.getObject();
	}

	@Override
	public JobLauncher getJobLauncher() throws Exception {
		SimpleJobLauncher jobLauncher = new SimpleJobLauncher();
		jobLauncher.setJobRepository(getJobRepository());
		jobLauncher.setTaskExecutor(new SimpleAsyncTaskExecutor());
		jobLauncher.afterPropertiesSet();
		return jobLauncher;
	}

	@Override
	public JobRepository getJobRepository() throws Exception {
		JobRepositoryFactoryBean factory = new JobRepositoryFactoryBean();
		factory.setDataSource(prvDataSource());
		factory.setIsolationLevelForCreate("ISOLATION_DEFAULT");
		factory.setTransactionManager(getTransactionManager());
		factory.setDatabaseType(DatabaseType.ORACLE.toString());
		factory.setTablePrefix("BATCH_");
		factory.afterPropertiesSet();
		return factory.getObject();
	}

	@Override
	public PlatformTransactionManager getTransactionManager() throws Exception {
		JpaTransactionManager transactionManager = new JpaTransactionManager();
		transactionManager.setEntityManagerFactory(prvEntityManager().getObject());
		return transactionManager;
	}

	
}
