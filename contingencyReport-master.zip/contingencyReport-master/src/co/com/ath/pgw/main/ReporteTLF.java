package co.com.ath.pgw.main;

import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.text.SimpleDateFormat;
import java.util.Date;

import javax.swing.GroupLayout;
import javax.swing.GroupLayout.Alignment;
import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.LayoutStyle.ComponentPlacement;

import org.apache.log4j.Logger;

import com.toedter.calendar.JDateChooser;

import co.com.ath.pgw.util.Util;

public class ReporteTLF extends JDialog {

	private static final long serialVersionUID = 1L;
	
	static Logger log =Logger.getLogger(ReporteTLF.class.getName());

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		try {
			ReporteTLF dialog = new ReporteTLF();
			dialog.setDefaultCloseOperation(JDialog.DISPOSE_ON_CLOSE);
			dialog.setVisible(true);
		} catch (Exception e) {
			log.error("Error Reporte TLF: "+ e);
		}
	}

	/**
	 * Create the dialog.
	 */
	public ReporteTLF() {
		setModalityType(ModalityType.APPLICATION_MODAL);
		setDefaultCloseOperation(JDialog.DISPOSE_ON_CLOSE);
		setTitle("Reporte TLF");
		setBounds(100, 100, 450, 300);
		
		JLabel lbTitulo = new JLabel("Contingencia Reporte TLF");
		lbTitulo.setFont(new Font("Tahoma", Font.PLAIN, 14));
		
		final JDateChooser fecha = new JDateChooser();
		
		JButton btnGenerar = new JButton("Generar");
		btnGenerar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Util consumo = new Util();
				String tipoReporte="5";
				SimpleDateFormat format = new SimpleDateFormat("yyyyMMdd");
				
				if (fecha.getDate() != null) {
					Date fechaGeneracion = fecha.getDate();	
					if (consumo.consumoServicio(tipoReporte,"",format.format(fechaGeneracion),"","",false)) {
						JOptionPane.showMessageDialog(null, 
								"Generaci�n terminada", "Informaci�n", JOptionPane.INFORMATION_MESSAGE);
					}
				} else {
					JOptionPane.showMessageDialog(null, 
							"Debe seleccionar una fecha", "Informaci�n", JOptionPane.INFORMATION_MESSAGE);
				}	
			}
		});
		
		JLabel lblSeleccioneFechaDe = new JLabel("Seleccione fecha de generaci\u00F3n");
		GroupLayout groupLayout = new GroupLayout(getContentPane());
		groupLayout.setHorizontalGroup(
			groupLayout.createParallelGroup(Alignment.LEADING)
				.addGroup(groupLayout.createSequentialGroup()
					.addGroup(groupLayout.createParallelGroup(Alignment.LEADING)
						.addGroup(groupLayout.createSequentialGroup()
							.addGap(138)
							.addComponent(lbTitulo))
						.addGroup(groupLayout.createSequentialGroup()
							.addGap(182)
							.addComponent(btnGenerar)))
					.addContainerGap(138, Short.MAX_VALUE))
				.addGroup(Alignment.TRAILING, groupLayout.createSequentialGroup()
					.addGap(36)
					.addComponent(lblSeleccioneFechaDe)
					.addPreferredGap(ComponentPlacement.RELATED, 76, Short.MAX_VALUE)
					.addComponent(fecha, GroupLayout.PREFERRED_SIZE, 114, GroupLayout.PREFERRED_SIZE)
					.addGap(57))
		);
		groupLayout.setVerticalGroup(
			groupLayout.createParallelGroup(Alignment.LEADING)
				.addGroup(groupLayout.createSequentialGroup()
					.addGap(55)
					.addComponent(lbTitulo)
					.addGap(32)
					.addGroup(groupLayout.createParallelGroup(Alignment.TRAILING)
						.addComponent(fecha, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
						.addComponent(lblSeleccioneFechaDe))
					.addGap(59)
					.addComponent(btnGenerar)
					.addContainerGap(55, Short.MAX_VALUE))
		);
		getContentPane().setLayout(groupLayout);
	}
}
