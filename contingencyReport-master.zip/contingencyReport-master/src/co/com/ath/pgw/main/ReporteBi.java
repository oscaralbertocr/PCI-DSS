package co.com.ath.pgw.main;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.beans.PropertyChangeEvent;
import java.beans.PropertyChangeListener;
import java.text.SimpleDateFormat;
import java.util.Date;

import javax.swing.GroupLayout;
import javax.swing.GroupLayout.Alignment;
import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.LayoutStyle.ComponentPlacement;

import org.apache.log4j.Logger;

import com.toedter.calendar.JDateChooser;

import co.com.ath.pgw.util.Util;

public class ReporteBi extends JDialog {

	private static final long serialVersionUID = 1L;
	
	static Logger log =Logger.getLogger(ReporteBi.class.getName()); 

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		try {
			ReporteBi dialog = new ReporteBi();
			dialog.setDefaultCloseOperation(JDialog.DISPOSE_ON_CLOSE);
			dialog.setVisible(true);
		} catch (Exception e) {
			log.error("Error ReporteBi: "+ e);
		}
	}

	/**
	 * Create the dialog.
	 */
	public ReporteBi() {
		setTitle("Reporte BI");
		setResizable(false);
		setBounds(100, 100, 450, 300);
		setModalityType(ModalityType.APPLICATION_MODAL);
		setDefaultCloseOperation(JDialog.DISPOSE_ON_CLOSE);
		
		JLabel lbTituloBi = new JLabel("Contingencia Reporte BI");
		lbTituloBi.setFont(new Font("Tahoma", Font.PLAIN, 14));
		lbTituloBi.addPropertyChangeListener(new PropertyChangeListener() {
			public void propertyChange(PropertyChangeEvent evt) {
			}
		});
		
		JLabel lblSeleccioneFechaDe = new JLabel("Seleccione fecha de generaci�n");
	
		final JDateChooser fecha = new JDateChooser();
		
		JButton btnGenerar = new JButton("Generar");
		btnGenerar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Util consumo = new Util();
				String tipoReporte="6";
				SimpleDateFormat format = new SimpleDateFormat("yyyyMMdd");
				
				if (fecha.getDate() != null) {
					Date fechaGeneracion = fecha.getDate();				
					if (consumo.consumoServicio(tipoReporte,"",format.format(fechaGeneracion),"","",false)) {	
					JOptionPane.showMessageDialog(null, 
							"Generaci�n terminada", "Informaci�n", JOptionPane.INFORMATION_MESSAGE);
					}
				} else {
					JOptionPane.showMessageDialog(null, 
							"Debe seleccionar una fecha", "Informaci�n", JOptionPane.INFORMATION_MESSAGE);
				}			
			}
		});
		
		GroupLayout groupLayout = new GroupLayout(getContentPane());
		groupLayout.setHorizontalGroup(
			groupLayout.createParallelGroup(Alignment.LEADING)
				.addGroup(groupLayout.createSequentialGroup()
					.addGap(145)
					.addComponent(lbTituloBi, GroupLayout.DEFAULT_SIZE, 156, Short.MAX_VALUE)
					.addGap(143))
				.addGroup(groupLayout.createSequentialGroup()
					.addGap(49)
					.addComponent(lblSeleccioneFechaDe)
					.addPreferredGap(ComponentPlacement.RELATED, 45, Short.MAX_VALUE)
					.addComponent(fecha, GroupLayout.PREFERRED_SIZE, 108, GroupLayout.PREFERRED_SIZE)
					.addGap(91))
				.addGroup(groupLayout.createSequentialGroup()
					.addGap(186)
					.addComponent(btnGenerar, GroupLayout.DEFAULT_SIZE, 81, Short.MAX_VALUE)
					.addGap(177))
		);
		groupLayout.setVerticalGroup(
			groupLayout.createParallelGroup(Alignment.LEADING)
				.addGroup(groupLayout.createSequentialGroup()
					.addGap(37)
					.addComponent(lbTituloBi)
					.addGap(37)
					.addGroup(groupLayout.createParallelGroup(Alignment.TRAILING, false)
						.addComponent(lblSeleccioneFechaDe, GroupLayout.DEFAULT_SIZE, GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
						.addComponent(fecha, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE))
					.addGap(51)
					.addComponent(btnGenerar)
					.addContainerGap(86, Short.MAX_VALUE))
		);
		getContentPane().setLayout(groupLayout);
	}
}
