package co.com.ath.pgw.main;

import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.text.SimpleDateFormat;
import java.util.Date;

import javax.swing.GroupLayout;
import javax.swing.GroupLayout.Alignment;
import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import org.apache.log4j.Logger;

import com.toedter.calendar.JDateChooser;

import co.com.ath.pgw.util.Util;

public class ReporteBaloto extends JDialog {

	private static final long serialVersionUID = 1L;
	
	static Logger log =Logger.getLogger(ReporteBaloto.class.getName()); 

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		try {
			ReporteBaloto dialog = new ReporteBaloto();
			dialog.setDefaultCloseOperation(JDialog.DISPOSE_ON_CLOSE);
			dialog.setVisible(true);
		} catch (Exception e) {
			log.error("Error ReporteBaloto: "+ e);
		}
	}

	/**
	 * Create the dialog.
	 */
	public ReporteBaloto() {
		setTitle("Reporte Baloto");
		setBounds(100, 100, 450, 300);
		setModalityType(ModalityType.APPLICATION_MODAL);
		setDefaultCloseOperation(JDialog.DISPOSE_ON_CLOSE);
		
		JLabel lbTitulo = new JLabel("Contingencia Reporte Baloto");
		lbTitulo.setFont(new Font("Tahoma", Font.PLAIN, 14));
		
		JLabel lbFecha = new JLabel("Seleccione fecha de generaci\u00F3n");
		
		final JDateChooser fecha = new JDateChooser();
		
		JButton btnGenerar = new JButton("Generar");
		btnGenerar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Util consumo = new Util();
				String tipoReporte="2";
				SimpleDateFormat format = new SimpleDateFormat("yyyyMMdd");
				
				if (fecha.getDate() != null) {
					Date fechaGeneracion = fecha.getDate();	
					if (consumo.consumoServicio(tipoReporte,"",format.format(fechaGeneracion),"","",false)) {
						JOptionPane.showMessageDialog(null, 
								"Generaci�n terminada", "Informaci�n", JOptionPane.INFORMATION_MESSAGE);
					}
				} else {
					JOptionPane.showMessageDialog(null, 
							"Debe seleccionar una fecha", "Informaci�n", JOptionPane.INFORMATION_MESSAGE);
				}				
			}
		});
				
		GroupLayout groupLayout = new GroupLayout(getContentPane());
		groupLayout.setHorizontalGroup(
			groupLayout.createParallelGroup(Alignment.LEADING)
				.addGroup(groupLayout.createSequentialGroup()
					.addGap(138)
					.addComponent(lbTitulo, GroupLayout.DEFAULT_SIZE, GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
					.addGap(122))
				.addGroup(groupLayout.createSequentialGroup()
					.addGap(62)
					.addComponent(lbFecha)
					.addGap(38)
					.addComponent(fecha, GroupLayout.PREFERRED_SIZE, 114, GroupLayout.PREFERRED_SIZE)
					.addContainerGap(69, Short.MAX_VALUE))
				.addGroup(groupLayout.createSequentialGroup()
					.addGap(184)
					.addComponent(btnGenerar, GroupLayout.DEFAULT_SIZE, 89, Short.MAX_VALUE)
					.addGap(161))
		);
		groupLayout.setVerticalGroup(
			groupLayout.createParallelGroup(Alignment.LEADING)
				.addGroup(groupLayout.createSequentialGroup()
					.addGap(48)
					.addComponent(lbTitulo)
					.addGap(33)
					.addGroup(groupLayout.createParallelGroup(Alignment.LEADING, false)
						.addComponent(fecha, Alignment.TRAILING, GroupLayout.DEFAULT_SIZE, GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
						.addComponent(lbFecha, Alignment.TRAILING, GroupLayout.DEFAULT_SIZE, GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
					.addGap(51)
					.addComponent(btnGenerar)
					.addGap(83))
		);
		getContentPane().setLayout(groupLayout);
	}
}
