package co.com.ath.pgw.main;

import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.swing.GroupLayout;
import javax.swing.GroupLayout.Alignment;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JDialog;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.LayoutStyle.ComponentPlacement;

import org.apache.log4j.Logger;

import com.toedter.calendar.JDateChooser;

import co.com.ath.pgw.util.Constants;
import co.com.ath.pgw.util.Util;

public class ReporteRecaudos extends JDialog {

	private static final long serialVersionUID = -4549376159109600590L;
	
	static Logger log =Logger.getLogger(ReporteRecaudos.class.getName());
	
	Util consumo = new Util();

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		try {
			ReporteRecaudos dialog = new ReporteRecaudos();
			dialog.setDefaultCloseOperation(JDialog.DISPOSE_ON_CLOSE);
			dialog.setVisible(true);
		} catch (Exception e) {
			log.error("Error Reporte Recaudos: "+ e);
		}
	}

	/**
	 * Create the dialog.
	 */
	public ReporteRecaudos() {
		setTitle("Reporte Recaudos");
		setBounds(100, 100, 450, 300);
		setModalityType(ModalityType.APPLICATION_MODAL);
		setDefaultCloseOperation(JDialog.DISPOSE_ON_CLOSE);
		
		JLabel lbTitulo = new JLabel("Contingencia Reporte de Recaudos");
		lbTitulo.setFont(new Font("Tahoma", Font.PLAIN, 14));
		
		JLabel lbConvenio = new JLabel("Convenio:");
		
		JLabel lbFecha = new JLabel("Seleccione fecha:");		
		
		final JLabel lbParcial = new JLabel("Seleccione Parcial:");
		lbParcial.setVisible(false);
		
		final JDateChooser fecha = new JDateChooser();
		fecha.getCalendarButton().addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
			}
		});
		
		final JComboBox cbParcial = new JComboBox();
		cbParcial.setVisible(false);
		
		List<String> listConvenio =cargaConvenios();
		List<String> listParciales =cargaParciales();
				
		final JComboBox cbConvenio = new JComboBox();
		cbConvenio.addActionListener(new ActionListener() {			
			@Override
			public void actionPerformed(ActionEvent e) {
				String convenioSeleccionado = (String) cbConvenio.getSelectedItem();
				if (convenioSeleccionado.equals("00009506")) {
					cbParcial.setVisible(true);
					lbParcial.setVisible(true);	
				} else {
					cbParcial.setVisible(false);
					lbParcial.setVisible(false);
				}
				
			}
		});
		
		for (int i = 0; i < listConvenio.size(); i++) {
			cbConvenio.addItem(listConvenio.get(i));		
		}	
		
		for (int i = 0; i < listParciales.size(); i++) {
			cbParcial.addItem(listParciales.get(i));		
		}	
		
		JButton btnGenerar = new JButton("Generar");
		btnGenerar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String convenioSeleccionado = (String) cbConvenio.getSelectedItem();
				String parcialSeleccionado = (String) cbParcial.getSelectedItem();
				boolean result = true;
				
				String tipoReporte = "";
				SimpleDateFormat format = new SimpleDateFormat("dd/MM/yyyy");
				
				if (fecha.getDate() != null) {
					Date fechaGeneracion = fecha.getDate();	
					
					if (convenioSeleccionado.equals("00009506")) {
						tipoReporte = "3";
						result = consumo.consumoServicio(tipoReporte,parcialSeleccionado.equals("Completo")? "C" :parcialSeleccionado,format.format(fechaGeneracion),"9506","",true);	
					} else {  
						tipoReporte = "2";
						result = consumo.consumoServicio(tipoReporte,convenioSeleccionado,format.format(fechaGeneracion),"","",true);
					}
					
					if (result) {
						JOptionPane.showMessageDialog(null, 
								"Generaci�n terminada", "Informaci�n", JOptionPane.INFORMATION_MESSAGE);
					}
				} else {
					JOptionPane.showMessageDialog(null, 
							"Debe seleccionar una fecha", "Informaci�n", JOptionPane.INFORMATION_MESSAGE);
				}
				
			}
		});
		
		GroupLayout groupLayout = new GroupLayout(getContentPane());
		groupLayout.setHorizontalGroup(
			groupLayout.createParallelGroup(Alignment.LEADING)
				.addGroup(groupLayout.createSequentialGroup()
					.addGroup(groupLayout.createParallelGroup(Alignment.TRAILING)
						.addGroup(groupLayout.createSequentialGroup()
							.addGap(67)
							.addGroup(groupLayout.createParallelGroup(Alignment.LEADING)
								.addComponent(lbFecha)
								.addComponent(lbConvenio)
								.addComponent(lbParcial))
							.addGap(57)
							.addGroup(groupLayout.createParallelGroup(Alignment.LEADING)
								.addComponent(cbParcial, 0, 116, Short.MAX_VALUE)
								.addComponent(fecha, GroupLayout.DEFAULT_SIZE, 116, Short.MAX_VALUE)
								.addComponent(cbConvenio, 0, 116, Short.MAX_VALUE)))
						.addGroup(groupLayout.createSequentialGroup()
							.addGap(113)
							.addComponent(lbTitulo, GroupLayout.DEFAULT_SIZE, GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
					.addGap(106))
				.addGroup(groupLayout.createSequentialGroup()
					.addGap(182)
					.addComponent(btnGenerar, GroupLayout.DEFAULT_SIZE, GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
					.addGap(181))
		);
		groupLayout.setVerticalGroup(
			groupLayout.createParallelGroup(Alignment.LEADING)
				.addGroup(groupLayout.createSequentialGroup()
					.addGap(30)
					.addComponent(lbTitulo)
					.addGap(28)
					.addGroup(groupLayout.createParallelGroup(Alignment.TRAILING)
						.addGroup(groupLayout.createSequentialGroup()
							.addComponent(lbConvenio)
							.addPreferredGap(ComponentPlacement.UNRELATED)
							.addComponent(lbFecha))
						.addGroup(groupLayout.createSequentialGroup()
							.addComponent(cbConvenio, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
							.addPreferredGap(ComponentPlacement.UNRELATED)
							.addComponent(fecha, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)))
					.addPreferredGap(ComponentPlacement.UNRELATED)
					.addGroup(groupLayout.createParallelGroup(Alignment.BASELINE)
						.addComponent(lbParcial)
						.addComponent(cbParcial, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE))
					.addPreferredGap(ComponentPlacement.RELATED, 58, Short.MAX_VALUE)
					.addComponent(btnGenerar)
					.addGap(23))
		);
		getContentPane().setLayout(groupLayout);
	}
	
	/**
	 * Metodo que carga los convenios 
	 * @return
	 */
	public List<String> cargaConvenios(){
		List<String> listConvenio = new ArrayList<String>();
		String[] nura = null;
		String parcial = "";
		
		try {
			nura = consumo.parametros(Constants.CONVENIOS_RECAUDO, false).split(",");
			
			for (int i = 0; i < nura.length; i++) {
				listConvenio.add(nura[i]); 			 			
			}
			
			parcial = consumo.parametros(Constants.CONVENIOS_RECAUDO_PARCIAL, false);
			listConvenio.add(parcial); 	
			
		} catch (Exception e) {
			log.error("Error cargando los convenios para recaudos. "+e);
		}

		
		return listConvenio;
	}
	
	/**
	 * Metodo que carga la cantidad de reportes parciales 
	 * @return
	 */
	public List<String> cargaParciales(){
		List<String> listParciales = new ArrayList<String>();
		String[] cantidadParciales = null;
		int valor = 0;
		
		try {
			cantidadParciales = consumo.parametros(Constants.PARCIALES_RECAUDO, false).split("]");
			
			for (int i = 0; i < cantidadParciales.length; i++) {
				valor =  i+1;
				if (valor != cantidadParciales.length) {
					listParciales.add(String.valueOf(valor)); 
				}			 			
			}

			listParciales.add("Completo"); 	
			
		} catch (Exception e) {
			log.error("Error cargando los parciales para recaudos. "+e);
		}
		
		return listParciales;		
	}
}
