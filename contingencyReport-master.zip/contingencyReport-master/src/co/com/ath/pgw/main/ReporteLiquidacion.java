package co.com.ath.pgw.main;

import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.swing.GroupLayout;
import javax.swing.GroupLayout.Alignment;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JDialog;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.LayoutStyle.ComponentPlacement;

import org.apache.log4j.Logger;

import com.toedter.calendar.JDateChooser;

import co.com.ath.pgw.dto.Banco;
import co.com.ath.pgw.dto.TipoLiquidacion;
import co.com.ath.pgw.util.Constants;
import co.com.ath.pgw.util.Util;

public class ReporteLiquidacion extends JDialog {

	private static final long serialVersionUID = 1L;
	
	static Logger log =Logger.getLogger(ReporteLiquidacion.class.getName());

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		try {
			ReporteLiquidacion dialog = new ReporteLiquidacion();
			dialog.setDefaultCloseOperation(JDialog.DISPOSE_ON_CLOSE);
			dialog.setVisible(true);
		} catch (Exception e) {
			log.error("Error Reporte Liquidacion: "+ e);
		}
	}

	/**
	 * Create the dialog.
	 */
	public ReporteLiquidacion() {
		setTitle("Reporte Liquidaci\u00F3n de Comisiones");
		setBounds(100, 100, 450, 310);
		setModalityType(ModalityType.APPLICATION_MODAL);
		setDefaultCloseOperation(JDialog.DISPOSE_ON_CLOSE);
		
		final JDateChooser fecha = new JDateChooser();
		final JComboBox cbTipo = new JComboBox();		
		final JComboBox cbBanco = new JComboBox();
		
		JLabel lblTipo = new JLabel("Tipo de Reporte:");
		
		JLabel lbTitulo = new JLabel("Contingencia Reporte Liquidaci\u00F3n de Comisiones ");
		lbTitulo.setFont(new Font("Tahoma", Font.PLAIN, 14));
		
		JLabel lblBanco = new JLabel("Banco:");
		
		JLabel lblSeleccioneFecha = new JLabel("Seleccione fecha:");
		
		List<TipoLiquidacion> listLiquidacion = cargaLiquidacion();
		List<Banco> listBanco = cargaBanco();
		
		for (int i = 0; i < listLiquidacion.size(); i++) {
			cbTipo.addItem(listLiquidacion.get(i));
		}
		
		for (int i = 0; i < listBanco.size(); i++) {
			cbBanco.addItem(listBanco.get(i));
		}
		
		JButton btnGenerar = new JButton("Generar");
		btnGenerar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Banco bancoSeleccionado = (Banco) cbBanco.getSelectedItem();
				TipoLiquidacion reporteSeleccionado = (TipoLiquidacion) cbTipo.getSelectedItem();
				
				Util consumo = new Util();
				String tipoReporte = "1";
				String name = "";
				
				if (fecha.getDate() != null) {
					Date fechaGeneracion = fecha.getDate();	
					
					name = nombreReporte(bancoSeleccionado.getId(), fechaGeneracion, 
							reporteSeleccionado.getId().equals("CD") ? true : false );
					
					if (consumo.consumoServicio(tipoReporte,reporteSeleccionado.getId(),name,"","",true)) {
						JOptionPane.showMessageDialog(null, 
								"Generaci�n terminada", "Informaci�n", JOptionPane.INFORMATION_MESSAGE);
					}
				} else {
					JOptionPane.showMessageDialog(null, 
							"Debe seleccionar una fecha", "Informaci�n", JOptionPane.INFORMATION_MESSAGE);
				}
				
			}
		});
		
		GroupLayout groupLayout = new GroupLayout(getContentPane());
		groupLayout.setHorizontalGroup(
			groupLayout.createParallelGroup(Alignment.LEADING)
				.addGroup(groupLayout.createSequentialGroup()
					.addGap(69)
					.addGroup(groupLayout.createParallelGroup(Alignment.LEADING)
						.addGroup(groupLayout.createSequentialGroup()
							.addComponent(lbTitulo, GroupLayout.PREFERRED_SIZE, 306, Short.MAX_VALUE)
							.addGap(59))
						.addGroup(groupLayout.createSequentialGroup()
							.addGroup(groupLayout.createParallelGroup(Alignment.LEADING)
								.addComponent(lblTipo, GroupLayout.PREFERRED_SIZE, 97, GroupLayout.PREFERRED_SIZE)
								.addComponent(lblBanco)
								.addComponent(lblSeleccioneFecha))
							.addGap(53)
							.addGroup(groupLayout.createParallelGroup(Alignment.LEADING, false)
								.addComponent(fecha, GroupLayout.DEFAULT_SIZE, GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
								.addComponent(cbBanco, 0, GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
								.addComponent(cbTipo, 0, 93, Short.MAX_VALUE))
							.addGap(122))))
				.addGroup(groupLayout.createSequentialGroup()
					.addGap(183)
					.addComponent(btnGenerar, GroupLayout.DEFAULT_SIZE, GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
					.addGap(180))
		);
		groupLayout.setVerticalGroup(
			groupLayout.createParallelGroup(Alignment.LEADING)
				.addGroup(groupLayout.createSequentialGroup()
					.addGap(41)
					.addComponent(lbTitulo)
					.addGap(30)
					.addGroup(groupLayout.createParallelGroup(Alignment.BASELINE)
						.addComponent(lblTipo)
						.addComponent(cbTipo, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE))
					.addGap(18)
					.addGroup(groupLayout.createParallelGroup(Alignment.BASELINE)
						.addComponent(lblBanco)
						.addComponent(cbBanco, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE))
					.addGap(12)
					.addGroup(groupLayout.createParallelGroup(Alignment.TRAILING)
						.addComponent(lblSeleccioneFecha)
						.addComponent(fecha, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE))
					.addPreferredGap(ComponentPlacement.RELATED, 59, Short.MAX_VALUE)
					.addComponent(btnGenerar)
					.addContainerGap())
		);
		getContentPane().setLayout(groupLayout);
	}
	
	/**
	 * Metodo que construye el nombre del reporte
	 * @param banco
	 * @param fecha
	 * @param validateDate
	 * @return
	 */
	public String nombreReporte(String banco, Date fecha, boolean validateDate) {
		SimpleDateFormat format;
		String result="";
		try {
			if (validateDate) {
				format = new SimpleDateFormat("yyyyMMdd");
			} else {
				format = new SimpleDateFormat("yyyyMM");
			}
			 result = String.format(Constants.NAME_LIQUIDACION,banco,format.format(fecha));
			
		} catch (Exception e) {
			log.error("Error generando nombre Reporte Liquidacion para el banco : "+banco+" "+ e);
		}
		return result;
	}
	
	/**
	 * Metodo que carga el tipo de reporte 
	 * @return
	 */
	public List<TipoLiquidacion> cargaLiquidacion(){
		 
		List<TipoLiquidacion> tipoReporte = new ArrayList<TipoLiquidacion>();
		
		TipoLiquidacion reporteDiario = new TipoLiquidacion();
		reporteDiario.setId("CD");
		reporteDiario.setTipoReporte("Reporte Diario");
		
		TipoLiquidacion reporteMensual = new TipoLiquidacion();
		reporteMensual.setId("CM");
		reporteMensual.setTipoReporte("Reporte Mensual");
		
		tipoReporte.add(reporteDiario);
		tipoReporte.add(reporteMensual);
		
		return tipoReporte;		
	}
	
	/**
	 * Metodo que carga los bancos
	 * @return
	 */
	public List<Banco> cargaBanco(){
		 
		List<Banco> banco = new ArrayList<Banco>();
		
		Banco bogota = new Banco();
		bogota.setId("BBOG");
		bogota.setNombre("Banco de Bogot�");
		
		Banco villas = new Banco();
		villas.setId("BAVV");
		villas.setNombre("Banco AV Villas");
		
		Banco occidente = new Banco();
		occidente.setId("BOCC");
		occidente.setNombre("Banco de Occidente");
		
		Banco popular = new Banco();
		popular.setId("BPOP");
		popular.setNombre("Banco Popular");
		
		banco.add(bogota);
		banco.add(villas);
		banco.add(occidente);
		banco.add(popular);
		
		return banco;		
	}
}
