package co.com.ath.pgw.main;
import java.awt.EventQueue;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.beans.PropertyChangeEvent;
import java.beans.PropertyChangeListener;

import javax.swing.GroupLayout;
import javax.swing.GroupLayout.Alignment;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;

import org.apache.log4j.Logger;
import javax.swing.LayoutStyle.ComponentPlacement;

public class Menu {

	private JFrame frmGeneracinDeContingencias;
	
	static Logger log =Logger.getLogger(Menu.class.getName()); 

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Menu window = new Menu();
					window.frmGeneracinDeContingencias.setVisible(true);
				} catch (Exception e) {
					log.error("Error menu: "+ e);
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public Menu() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frmGeneracinDeContingencias = new JFrame();
		frmGeneracinDeContingencias.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frmGeneracinDeContingencias.setResizable(false);
		frmGeneracinDeContingencias.setTitle("Generaci\u00F3n de Contingencias");
		frmGeneracinDeContingencias.setBounds(100, 100, 450, 336);
		
		JLabel lbTitulo = new JLabel("Generaci\u00F3n Reportes Por Contingencia");
		lbTitulo.addPropertyChangeListener(new PropertyChangeListener() {
			public void propertyChange(PropertyChangeEvent arg0) {
			}
		});
		
		JButton btnBi = new JButton("Reporte BI");
		btnBi.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				ReporteBi reporBi= new ReporteBi();
				reporBi.setVisible(true);
				log.info("Inicio contingencia Reporte BI");
			}
		});
		
		JButton btnBaloto = new JButton("Reporte Baloto");
		btnBaloto.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				ReporteBaloto reporBaloto = new ReporteBaloto();
				reporBaloto.setVisible(true);
				log.info("Inicio contingencia Reporte Baloto");
			}
		});
		
		JButton btnComisiones = new JButton("Reporte Liquidaci�n de Comisiones");
		btnComisiones.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				ReporteLiquidacion reporLiquidacion = new ReporteLiquidacion();
				reporLiquidacion.setVisible(true);	
				log.info("Inicio contingencia Reporte Liquidacion de Comisiones");
			}
		});
		
		JButton btnRecaudos = new JButton("Reporte de Recaudos");
		btnRecaudos.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				ReporteRecaudos reporRecaudos = new ReporteRecaudos();
				reporRecaudos.setVisible(true);
				log.info("Inicio contingencia Reporte de Recaudos");
			}
		});
		
		JButton btnTLF = new JButton("Reporte TLF");
		btnTLF.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				ReporteTLF reporteTLF = new ReporteTLF();
				reporteTLF.setVisible(true);
				log.info("Inicio contingencia Reporte TLF");
			}
		});
		
		
		GroupLayout groupLayout = new GroupLayout(frmGeneracinDeContingencias.getContentPane());
		groupLayout.setHorizontalGroup(
			groupLayout.createParallelGroup(Alignment.LEADING)
				.addGroup(groupLayout.createSequentialGroup()
					.addGap(125)
					.addComponent(lbTitulo, GroupLayout.DEFAULT_SIZE, 195, Short.MAX_VALUE)
					.addGap(124))
				.addGroup(groupLayout.createSequentialGroup()
					.addGap(124)
					.addGroup(groupLayout.createParallelGroup(Alignment.TRAILING, false)
						.addComponent(btnTLF, Alignment.LEADING, GroupLayout.DEFAULT_SIZE, GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
						.addComponent(btnRecaudos, Alignment.LEADING, GroupLayout.DEFAULT_SIZE, GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
						.addComponent(btnBi, Alignment.LEADING, GroupLayout.DEFAULT_SIZE, GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
						.addComponent(btnBaloto, Alignment.LEADING, GroupLayout.DEFAULT_SIZE, GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
						.addComponent(btnComisiones, Alignment.LEADING, GroupLayout.DEFAULT_SIZE, GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
					.addContainerGap(123, Short.MAX_VALUE))
		);
		groupLayout.setVerticalGroup(
			groupLayout.createParallelGroup(Alignment.LEADING)
				.addGroup(groupLayout.createSequentialGroup()
					.addGap(33)
					.addComponent(lbTitulo)
					.addGap(39)
					.addComponent(btnBi)
					.addGap(18)
					.addComponent(btnBaloto)
					.addGap(18)
					.addComponent(btnComisiones)
					.addGap(18)
					.addComponent(btnRecaudos)
					.addGap(18)
					.addComponent(btnTLF)
					.addContainerGap(26, Short.MAX_VALUE))
		);
		frmGeneracinDeContingencias.getContentPane().setLayout(groupLayout);
	}
}
