package co.com.ath.pgw.main;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import org.apache.log4j.Logger;

import co.com.ath.pgw.util.Util;

import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.io.Console;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.awt.event.ActionEvent;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.GridBagLayout;
import java.awt.GridBagConstraints;
import java.awt.Insets;
import java.awt.Font;



public class ReporteBIPXC extends JFrame {

	private static final long serialVersionUID = -3094043092730119404L;

	static Logger log =Logger.getLogger(ReporteBIPXC.class.getName());

	Util consumo = new Util();
	private JPanel contentPane;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					ReporteBIPXC frame = new ReporteBIPXC();
					frame.setVisible(true);
				} catch (Exception e) {
					log.error("Error Reporte ReporteBIPXC: "+ e);
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public ReporteBIPXC() {
		setTitle("Contingencia BI Medios de Pago por Comercio");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 300);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		contentPane.setLayout(new BorderLayout(0, 0));
		setContentPane(contentPane);
		
		JPanel panel = new JPanel();
		contentPane.add(panel, BorderLayout.CENTER);
		GridBagLayout gbl_panel = new GridBagLayout();
		gbl_panel.columnWidths = new int[]{79, 288, 0};
		gbl_panel.rowHeights = new int[]{55, 18, 52, 25, 0};
		gbl_panel.columnWeights = new double[]{0.0, 0.0, Double.MIN_VALUE};
		gbl_panel.rowWeights = new double[]{0.0, 0.0, 0.0, 0.0, Double.MIN_VALUE};
		panel.setLayout(gbl_panel);
		
		JButton btnGenerar = new JButton("Generar");
		btnGenerar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				log.info("Inicio contingencia Reporte BI");
				
				
				boolean result = true;
				String tipoReporte = "";
						tipoReporte = "4";
						result = consumo.consumoServicio(tipoReporte,"","","","",true);
					
					if (result) {
						JOptionPane.showMessageDialog(null, 
								"Generaci�n terminada", "Informaci�n", JOptionPane.INFORMATION_MESSAGE);
					}
				
				
			}
		});
		
		JLabel lblNewLabel = new JLabel("Contingencia BI Medios de Pago por Comercio");
		lblNewLabel.setFont(new Font("Tahoma", Font.PLAIN, 14));
		GridBagConstraints gbc_lblNewLabel = new GridBagConstraints();
		gbc_lblNewLabel.fill = GridBagConstraints.BOTH;
		gbc_lblNewLabel.insets = new Insets(0, 0, 5, 0);
		gbc_lblNewLabel.gridx = 1;
		gbc_lblNewLabel.gridy = 1;
		panel.add(lblNewLabel, gbc_lblNewLabel);
		GridBagConstraints gbc_btnNewButton = new GridBagConstraints();
		gbc_btnNewButton.fill = GridBagConstraints.VERTICAL;
		gbc_btnNewButton.gridx = 1;
		gbc_btnNewButton.gridy = 3;
		panel.add(btnGenerar, gbc_btnNewButton);
	}

}
