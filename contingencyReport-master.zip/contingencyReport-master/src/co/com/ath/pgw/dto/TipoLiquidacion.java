package co.com.ath.pgw.dto;

import java.io.Serializable;

public class TipoLiquidacion implements Serializable{

	private static final long serialVersionUID = 369203687418000717L;
	
	private String id;
	private String tipoReporte;
	
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getTipoReporte() {
		return tipoReporte;
	}
	public void setTipoReporte(String tipoReporte) {
		this.tipoReporte = tipoReporte;
	}
	@Override
	public String toString() {
		return tipoReporte;
	}
	
	

}
