package co.com.ath.pgw.dto;

import java.io.Serializable;

public class FileDTO implements Serializable{
	
	private static final long serialVersionUID = 6285845014865471015L;
	private String FileId;
	private String FileType;
	private String FileName;
	private String FileDesc;
	private String SPName;
	private String FileStatus;
	private String FileRqDt;
	
	public String getFileId() {
		return FileId;
	}
	public void setFileId(String fileId) {
		FileId = fileId;
	}
	public String getFileType() {
		return FileType;
	}
	public void setFileType(String fileType) {
		FileType = fileType;
	}
	public String getFileName() {
		return FileName;
	}
	public void setFileName(String fileName) {
		FileName = fileName;
	}
	public String getFileDesc() {
		return FileDesc;
	}
	public void setFileDesc(String fileDesc) {
		FileDesc = fileDesc;
	}
	public String getSPName() {
		return SPName;
	}
	public void setSPName(String sPName) {
		SPName = sPName;
	}
	public String getFileStatus() {
		return FileStatus;
	}
	public void setFileStatus(String fileStatus) {
		FileStatus = fileStatus;
	}
	public String getFileRqDt() {
		return FileRqDt;
	}
	public void setFileRqDt(String fileRqDt) {
		FileRqDt = fileRqDt;
	}
	public static long getSerialversionuid() {
		return serialVersionUID;
	}
	
	@Override
	public String toString() {
		return "{\r\n" + 
				"    \"File\": {\r\n" + 
				"        \"FileId\":\"" + this.FileId + "\",\r\n" + 
				"        \"FileType\":\"" + this.FileType + "\",\r\n" + 
				"        \"FileName\":\"" + this.FileName + "\",\r\n" + 
				"        \"FileDesc\":\"" + this.FileDesc + "\",\r\n" + 
				"        \"SPName\":\"" + this.SPName + "\",\r\n" + 
				"        \"FileStatus\":\"" + this.FileStatus + "\",\r\n" + 
				"        \"FileRqDt\": \"2019-05-10T15:26:00.741Z\"\r\n" + 
				"    }\r\n" + 
				"}";
	}
	
}
