package co.com.ath.pgw.util;

import java.io.DataOutputStream;
import java.io.File;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.Hashtable;
import java.util.Properties;

import javax.swing.JOptionPane;

import org.apache.commons.configuration2.Configuration;
import org.apache.commons.configuration2.ConfigurationConverter;
import org.apache.commons.configuration2.builder.fluent.Configurations;
import org.apache.commons.configuration2.ex.ConfigurationException;
import org.apache.log4j.Logger;

import co.com.ath.pgw.dto.FileDTO;

public class Util {

	static Logger log = Logger.getLogger(Util.class.getName());

	public boolean consumoServicio(String id, String type, String name, String desc, String spName,
			boolean generateReport) {

		boolean sw = true;
		
		FileDTO file=new FileDTO();
		String ruta = generateReport ? Constants.URL_REPORT : Constants.URL_BATCH;
		String ip = parametros(Constants.PROPERTY_CONTINGENCIA, true);

		if (ip == null || ip.isEmpty()) {
			sw = false;
			log.error("No se encontr� direcci�n IP");
			JOptionPane.showMessageDialog(null,
					"No se puede ejecutar el reporte \n Error de configuraci�n: No se encontr� direccion IP", "Error",
					JOptionPane.ERROR_MESSAGE);
		} else {

			String endpoint = ip + ruta;

			try {
				// parametros
				file.setFileId(id);
				file.setFileType(type);
				file.setFileName(name);
				file.setFileDesc(desc);
				file.setSPName(spName);
				file.setFileStatus("0");
				file.setFileRqDt(name);

				log.info("Inicio peticion " + endpoint + "\n" + file.toString());

				// Header
				URL url = new URL(endpoint);
				HttpURLConnection conn = (HttpURLConnection) url.openConnection();
				conn.setRequestMethod(Constants.METHOD);
				conn.setDoOutput(true);
				conn.setRequestProperty("Content-Type", Constants.HEADER_CONTENT);
				conn.setRequestProperty("X-RqUID", Constants.HEADER_RQ);
				conn.setRequestProperty("X-Channel", Constants.HEADER_CHANNEL);
				if (!generateReport) {
					conn.setRequestProperty("X-CompanyId", Constants.HEADER_COMPANY);
				}
				conn.setRequestProperty("X-IPAddr", Constants.HEADER_IP);
				conn.setRequestProperty("charset", Constants.HEADER_CODIFICACION);

				DataOutputStream outputStream = new DataOutputStream(conn.getOutputStream());
				outputStream.writeBytes(file.toString());
				outputStream.flush();
				outputStream.close();

				if (conn.getResponseCode() == 204) {
					log.info(Constants.RESPUESTA + conn.getResponseCode());
				} else if (conn.getResponseCode() == 200) {
					log.info(Constants.RESPUESTA + conn.getResponseCode());
					log.info("Success");
				} else {
					sw = false;
					JOptionPane.showMessageDialog(null,
							"No se pudo ejecutar el reporte \n Error en el consumo del servicio", "Error",
							JOptionPane.ERROR_MESSAGE);
					log.info(Constants.RESPUESTA + conn.getResponseCode());
					log.info("Error");
				}
				conn.disconnect();

			} catch (Exception ex) {
				sw = false;
				log.error("Exception: " + ex);
				JOptionPane.showMessageDialog(null, "No se pudo ejecutar el reporte \n Error interno de la aplicaci�n",
						"Error", JOptionPane.ERROR_MESSAGE);
			} finally {
				log.info("TRABAJO FINALIZADO");
			}
		}
		return sw;
	}

	/**
	 * Metodo que consulta propiedades
	 * 
	 * @param parametro
	 * @return
	 */
	public String parametros(String parametro, boolean ipBase) {
		String result = "";
		
		Configurations configs = new Configurations();
		
		try {
			Configuration config = configs.properties(new File(ipBase ? Constants.URL_CONTINGENCIA : Constants.PARAMETER_REPORT));
			
			Properties properties = ConfigurationConverter.getProperties(config);

			result = properties.getProperty(parametro);
			
		} catch (ConfigurationException e) {
	        log.error("No fue posible encontrar el archivo. " + e.getMessage());
	    }
		
		return result;
	}

}
