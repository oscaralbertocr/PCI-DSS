package co.com.ath.pgw.util;

public interface Constants {

	public static final String METHOD = "POST";
	public static final String HEADER_CONTENT = "application/json";
	public static final String HEADER_RQ = "123";
	public static final String HEADER_CHANNEL = "1";
	public static final String HEADER_COMPANY = "123";
	public static final String HEADER_IP = "1.1.1.1";
	public static final String HEADER_CODIFICACION = "utf-8";
	public static final String PARAMETER_REPORT = "D:\\pgw-core-config\\pgw-reportGenerator.properties";
	public static final String URL_CONTINGENCIA = "D:\\pgw-core-config\\pgw-config.properties";
	public static final String PROPERTY_CONTINGENCIA = "pasarela.app.parametros";	
	public static final String RESPUESTA = "Response Code: ";	
	public static final String NAME_LIQUIDACION = "%s_Pagos_PortalDePagos_%s";
	public static final String CONVENIOS_RECAUDO = "report.obligacionNura";
	public static final String CONVENIOS_RECAUDO_PARCIAL = "report.obligacionParcialNura";
	public static final String PARCIALES_RECAUDO = "pasarela.batch.scheduled.asobancaria.partial.cronArray";
	
	public static final String URL_BATCH = "/pgw-core-batch/paymentsManagement/v1/Payments_File/File";
	public static final String URL_REPORT = "/pgw-generateReport/transferManagement/initTransfer";
	

}
