# contingencyReport
Componente para creación de la contingencia de reportes
 
