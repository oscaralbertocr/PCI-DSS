package com.trxFlow;

import javax.servlet.GenericServlet;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;

public class SMain extends GenericServlet{
	private static final long serialVersionUID = 1L;

	@Override
	public void init() {}
	
	@Override
	public void service(ServletRequest r , ServletResponse sr) throws ServletException{
		
	}	
}