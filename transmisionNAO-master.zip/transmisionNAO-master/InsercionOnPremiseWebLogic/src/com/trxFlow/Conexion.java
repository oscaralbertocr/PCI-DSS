package com.trxFlow;

import java.io.FileInputStream;
import java.io.InputStream;
import java.sql.Connection;
import java.sql.DriverManager;
import java.util.Properties;

import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.sql.DataSource;
//import exceptions.ConnectionException;

public class Conexion {

	private static Connection con;

    private static String url;
	private static String username;
	private static String password;
	//private static Logger log = Logger.getLogger(ConnectionDAO.class);

	private static DataSource dataSource;
    static Connection getConexion() {
    	Encripter en = new Encripter();
            try {
                   
                    Properties prop = new Properties();
                    InputStream iStream = null;
                    //prop.load(new FileInputStream("/ConexionProperties.properties"));
                    //getClass().getResource("filename.properties"));
                    //InputStream is = getClass().getResourceAsStream("/packagename/your.properties");
                   // iStream = new FileInputStream("ConexionProperties.properties");
                    iStream = new FileInputStream("D:\\ActualizacionOnPremise\\ConexionProperties.properties");
                    prop.load(iStream);
                    System.out.println("Inicio Conexion");
                    Class.forName(prop.getProperty("driver"));
                    String host = prop.getProperty("host");
                    String port = prop.getProperty("port");
                    String database = prop.getProperty("database");
                    url = "jdbc:oracle:thin:@" + host + ":" + port + ":" + database;
                    username = prop.getProperty("username");
                    //password =en.Encriptar(prop.getProperty("password"));
                    password=prop.getProperty("password");
                    if (con == null || con.isClosed())
                       con = DriverManager.getConnection(url, username, password);
                    System.out.println("Conexion Exitosa");
                    
            }
            catch (Exception e) {
            	e.printStackTrace();
                    System.out.println("Parametros de conexion incorrectos.");
            }
			return con;
    }
    private void Connection() {
		InitialContext initialContext = null;
		try {
			initialContext = new InitialContext();
			try {
				dataSource = (DataSource) initialContext
						.lookup("jdbc/PortalPagosDS");
			} catch (NamingException e) {
				System.out.println("::: SE PRESENTARION PROBLEMAS AL OBTENER EL DATA SOURCE :::"+e);
			}
		} catch (NamingException e) {
			System.out.println(
					"::: SE PRESENTARION PROBLEMAS AL OBTENER EL INITIAL CONTEXT :::"+e);
		}
	}
    
//    private void open() {
//		InitialContext initialContext = null;
//		try {
//			initialContext = new InitialContext();
//			try {
//				con.
//			} catch (NamingException e) {
//				System.out.println("::: SE PRESENTARION PROBLEMAS AL OBTENER EL DATA SOURCE :::"+e);
//			}
//		} catch (NamingException e) {
//			System.out.println(
//					"::: SE PRESENTARION PROBLEMAS AL OBTENER EL INITIAL CONTEXT :::"+e);
//		}
//	}
//    

	/**
	 * Metodo encargado de retornar una conexion a la base de datos.
	 * 
	 * @return Connection Objeto con la conexion a la base de datos.
	 */
	public static Connection createConnection() throws Exception {
		try {
			return dataSource.getConnection();
		} catch (Exception eException) {
			System.out.println(
					"::: SE PRESENTARION PROBLEMAS AL OBTENER LA CONEXION CON LA BASE DE DATOS :::"+
					eException);
			throw eException;
		}
	}

	 }

	 /* Esta es la clase DataSource que es la que te devuelve un objeto connection y luego dentro de proyecto te puedes hacer un fichero datasource.properties con los parametros que contenga algo asi */




