package com.trxFlow;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Properties;
import java.util.logging.Logger;

import org.quartz.Job;
import org.quartz.JobDataMap;
import org.quartz.JobExecutionContext;
import org.quartz.JobExecutionException;

public class Batch implements Job{
	private Statement stmt = null;
	private final Logger LOGGER = Logger.getLogger( Batch.class.getName() );

	@Override
	public void execute(JobExecutionContext context) throws JobExecutionException {
		JobDataMap dataMap = context.getJobDetail().getJobDataMap();
		int queryNumber = dataMap.getInt("queryNumber");
		try {
			if(queryNumber == 1) {
				this.setInfo("CORE_PASARELA", 1);
			}else if(queryNumber == 2){
				this.setInfo("CORE_PASARELA", 2);
			}
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	public void setInfo(String esquema, int queryNumber) throws IOException {
		ArrayList<String> pmtIds = new ArrayList<>();
		Date date = new Date();
		String rutaLog="D:\\ActualizacionOnPremise\\";
		FileWriter bw = null;
		int cont=0;
		try {
			//Connection con =Conexion.createConnection(); 
			Connection con =Conexion.getConexion(); 
			con.setAutoCommit(false); 			
			//			String cadena;
			//			 FileReader f = new FileReader("C:\\users/mmacias/Documents/archivo.txt");
			//		      BufferedReader b = new BufferedReader(f);
			//			
			int rows=0;
			File archivo = null;
			FileReader fr = null;
			BufferedReader br = null;	
			PreparedStatement  stmt = null;
			//String sql="INSERT INTO "+esquema+".TRANSACCIONES (ID, IDCOMERCIO, IDESTADO, IDTIPOTRANSACCION, IDORIGENTRANSACCION, IDMEDIOPAGO, IDTIPOPRODUCTO, IDTARJETACREDITO, IDTRANSACCIONRED, IDBANCO, IDTIPOPERSONA, IPTRANSACCION, CODIGORESPUESTA, FECHATRANSACCION, NUMEROORDEN, VALORTOTAL, VALORIMPUESTO, MONEDA, DESCRIPCION, NUMEROAPROBACION, FECHAPAGO, FECHACOMPENSACION, TIPODOCUMENTOCOMPRADOR, NUMERODOCUMENTOCOMPRADOR, NOMBRECOMPRADOR, CORREOCOMPRADOR, NROCELULARCOMPRADOR, REFERENCIA1, REFERENCIA2, REFERENCIA3, REGFECHACREACION, REGFECHAMODIFICACION, REGELIMINADO, IDBLOQUEOJOB, PMTID, COMPANIAPAGADOR, NOMBREPAGADOR, ALIASPAGADOR, TIPODOCUMENTOPAGADOR, NUMERODOCUMENTOPAGADOR, GENEROPAGADOR, FECHANACIMIENTOPAGADOR, CIUDADPAGADOR, DEPARTAMENTOPAGADOR, PAISPAGADOR, DIRECCIONPAGADOR, CORREOPAGADOR, TELEFONOPAGADOR, NUMEROTARJETACREDITO, IDBRAND, URLRESPUESTA, INTENCIONPAGO, MONEDATRM, REFERENCIAPAGO2, REFERENCIAPAGO3, REFERENCIAPAGO4, TIPOPAGO, TRM, CANAL, CICLOTRANSACCION, TIPOTRANSACCION, RQUID, PRIMERAPELLIDOCOMPRADOR, PRIMERAPELLIDOPAGADOR, SEGUNDONOMBRECOMPRADOR, SEGUNDONOMBREPAGADOR, SEGUNDOAPELLIDOCOMPRADOR, SEGUNDOAPELLIDOPAGADOR, FLAGCORREO, IDTYPEDOC, NUMDOC, PLANTILLA, IDTAQUILLAS, URLLOGO, TOKENIZADO, IDBANCORECAUDADOR, CUENTADERECAUDO,  GLOBALPAY, ASOBANCARIA) VALUES (?,?,?,?,?,?,?,?,?,?,?,'?',?,'?',?,?,?,'?','?',?,?,?,?,?,?,?,?,?,?,?,'?','?',?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,'?',?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)";
			String sql="";
			//System.out.println(sql);
			Properties prop = new Properties();
			InputStream iStream = null;
			iStream = new FileInputStream("D:\\ActualizacionOnPremise\\ConexionProperties.properties");
			prop.load(iStream);
			//SimpleDateFormat formatter = new SimpleDateFormat("dd-MM-YYYY HH:mm:S");
			String arc = prop.getProperty("url");
			String log = prop.getProperty("log");
			//Calendar c1 = GregorianCalendar.getInstance();
			Date objDate = new Date();
			SimpleDateFormat objSDF = new SimpleDateFormat("ddMMYYYY"); // La cadena de formato de fecha se pasa como un argumento al objeto 
			//de formato de fecha  System.out.println(objSDF.format(objDate));
			// System.out.println("Fecha actua);
			//stmt.close();
			fr = new FileReader (arc);
			br = new BufferedReader(fr);
			rutaLog=rutaLog+log +" - "+objSDF.format(objDate)+".txt";
			bw = new FileWriter(rutaLog,true);
			String linea;
			String[] cadena;
			String sql1="SELECT ID FROM "+esquema+".COMERCIO WHERE CODIGONURA='";
			System.out.println(date.toString());
			bw.write(date.toString()+"................Inicia proceso se insercion de resgistros....................\n");
			bw.flush();
			while((linea=br.readLine())!=null) {
				sql="INSERT INTO "+esquema+".TRANSACCIONES (ID, IDCOMERCIO, IDESTADO, IDTIPOTRANSACCION, IDORIGENTRANSACCION, IDMEDIOPAGO, IDTIPOPRODUCTO, IDTARJETACREDITO, IDTRANSACCIONRED, IDBANCO, IDTIPOPERSONA, IPTRANSACCION, CODIGORESPUESTA, FECHATRANSACCION, NUMEROORDEN, VALORTOTAL, VALORIMPUESTO, MONEDA, DESCRIPCION, NUMEROAPROBACION, FECHAPAGO, FECHACOMPENSACION, TIPODOCUMENTOCOMPRADOR, NUMERODOCUMENTOCOMPRADOR, NOMBRECOMPRADOR, CORREOCOMPRADOR, NROCELULARCOMPRADOR, REFERENCIA1, REFERENCIA2, REFERENCIA3, REGFECHACREACION, REGFECHAMODIFICACION, REGELIMINADO, IDBLOQUEOJOB, PMTID, COMPANIAPAGADOR, NOMBREPAGADOR, ALIASPAGADOR, TIPODOCUMENTOPAGADOR, NUMERODOCUMENTOPAGADOR, GENEROPAGADOR, FECHANACIMIENTOPAGADOR, CIUDADPAGADOR, DEPARTAMENTOPAGADOR, PAISPAGADOR, DIRECCIONPAGADOR, CORREOPAGADOR, TELEFONOPAGADOR, NUMEROTARJETACREDITO, IDBRAND, URLRESPUESTA, INTENCIONPAGO, MONEDATRM, REFERENCIAPAGO2, REFERENCIAPAGO3, REFERENCIAPAGO4, TIPOPAGO, TRM, CANAL, CICLOTRANSACCION, TIPOTRANSACCION, RQUID, PRIMERAPELLIDOCOMPRADOR, PRIMERAPELLIDOPAGADOR, SEGUNDONOMBRECOMPRADOR, SEGUNDONOMBREPAGADOR, SEGUNDOAPELLIDOCOMPRADOR, SEGUNDOAPELLIDOPAGADOR, FLAGCORREO, IDTYPEDOC, NUMDOC, PLANTILLA, IDTAQUILLAS, URLLOGO, TOKENIZADO, IDBANCORECAUDADOR, CUENTADERECAUDO,  GLOBALPAY, ASOBANCARIA) VALUES (998";
				//System.out.println(linea); 

				cadena = linea.split("\\|");
				for (int i=0; i< cadena.length-1; i++) {
					if(!cadena[i].equals("null")) {
						if(!isNumeric(cadena[i])) 
							sql =sql + "'"+cadena[i]+"',";
						else 
							sql =sql + cadena[i]+",";
					}
					else
						sql =sql + "null,";

				}
				sql = sql + cadena[cadena.length-1]+")";
				System.out.println(sql);	
				stmt = con.prepareStatement(sql);
				
				try {
					stmt.addBatch();
					stmt.executeBatch();					
					con.commit();
					cont=cont++;	
				}
				catch (SQLException e) {
					System.out.println(date.toString());
					System.out.println("Error Inserci�n transaccion id: "+" Error: "+e);
					System.out.println("Error Inserci�n transaccion id "+" Error: "+e +" ErrorCode: "+e.getErrorCode()+ " Message: "+e.getMessage());
					bw.write("Error Inserci�n transaccion id "+" Error: "+e +" ErrorCode: "+e.getErrorCode()+ " Message: "+e.getMessage()+"\n");
					bw.flush();
					stmt.close();
				}catch (Exception e) {
					System.out.println(date.toString());
					System.out.println("Error Inserci�n transaccion id: "+" Error: "+e);
					System.out.println("Error Inserci�n transaccion id "+" Error: "+e +" ErrorCode: "+e+ " Message: "+e.getMessage());
					bw.write("Error Inserci�n transaccion id "+" Error: "+e +" ErrorCode: "+e+ " Message: "+e.getMessage()+"\n");
					bw.flush();
					stmt.close();
				}finally {
//					stmt.clearBatch();
					stmt.close();
					bw.flush();
				}

			}

		} catch ( Exception e ) {
			System.out.println(date.toString());
			//JDBCTutorialUtilities.printSQLException(e);
			e.printStackTrace();
			System.out.println("Proceso lectura: "+" Error: "+e);
		} finally {
			bw.write(date.toString()+"Finaliza proceso batch\n");					
			bw.close();
			if (stmt != null) { try {
				stmt.close();
			} catch (SQLException e) {
				e.printStackTrace();
			} }
		}
		//return pmtIds;
	}

	private boolean isNumeric(String cadena){
		try {
			Integer.parseInt(cadena);
			return true;
		} catch (NumberFormatException nfe){
			return false;
		}
	}

}