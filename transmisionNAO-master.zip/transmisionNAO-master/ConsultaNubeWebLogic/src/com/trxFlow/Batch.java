package com.trxFlow;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.SimpleDateFormat;
import java.util.Properties;

import org.quartz.Job;
import org.quartz.JobDataMap;
import org.quartz.JobExecutionContext;
import org.quartz.JobExecutionException;

import com.jcraft.jsch.ChannelSftp;
import com.jcraft.jsch.JSch;
import com.jcraft.jsch.JSchException;
import com.jcraft.jsch.Session;
import com.jcraft.jsch.SftpException;

public class Batch implements Job{
	
	Statement stmt = null;
	private String fileName;	
	private String KeyPublicPGP;

	@Override
	public void execute(JobExecutionContext context) throws JobExecutionException {
		JobDataMap dataMap = context.getJobDetail().getJobDataMap();
		int queryNumber = dataMap.getInt("queryNumber");
		if(queryNumber == 1) {
			this.setInfo(1);
		}else if(queryNumber == 2){
			this.setInfo(2);
		}
	}


	public void setInfo(int queryNumber) {
//		ArrayList<String> pmtIds = new ArrayList<>();
		try {
			//Connection con =Conexion.createConnection(); 
			Connection con = Conexion.getConexion(); 
			//			String cadena;

			//		      BufferedReader b = new BufferedReader(f);
			//			
			Properties prop = new Properties();
			InputStream iStream = null;
			if(queryNumber == 1) {
				iStream = new FileInputStream("D:\\pgw-core-config\\ConsultaNubeTLF\\ConexionProperties.properties");
			}else if(queryNumber == 2){
				iStream = new FileInputStream("D:\\pgw-core-config\\ConsultaNubeOtros\\ConexionProperties.properties");
			}
			prop.load(iStream);
			String archivo = prop.getProperty("url");
			String sql = prop.getProperty("sql");
//			int rows=0;
			FileWriter f = new FileWriter(archivo);
			BufferedWriter b = new BufferedWriter(f);
			//File archivo = null;
			//		      FileReader fr = null;
			//		      PrintWriter pw = null;
			//		      BufferedReader br = null;	
			Statement stmt = con.createStatement();
			System.out.println(sql);
			ResultSet rs = stmt.executeQuery(sql);
			String fecha14, fecha21, fecha22, fecha31, fecha32, fecha42; 
//			int numero78,numero79=0;
			while (rs.next()) {
				if(rs.getDate(14)==null) {
					fecha14 = null;
				}else {
					fecha14 = new SimpleDateFormat("dd/MM/yyyy hh:mm:ss,SSS a").format(rs.getDate(14));
				}
				if(rs.getDate(21)==null) {
					fecha21 = null;
				}else {
					fecha21 = new SimpleDateFormat("dd/MM/yyyy hh:mm:ss,SSS a").format(rs.getDate(21));
				}
				if(rs.getDate(22)==null) {
					fecha22 = null;

				}else {
					fecha22 = new SimpleDateFormat("dd/MM/yyyy hh:mm:ss,SSS a").format(rs.getDate(22));
				}
				if(rs.getDate(31)==null) {
					fecha31 = null;
				}else {
					fecha31 = new SimpleDateFormat("dd/MM/yyyy hh:mm:ss,SSS a").format(rs.getDate(31));
				}
				if(rs.getDate(32)==null) {
					fecha32 = null;
				}else {
					fecha32 = new SimpleDateFormat("dd/MM/yyyy hh:mm:ss,SSS a").format(rs.getDate(32));
				}
				if(rs.getDate(42)==null) {
					fecha42 = null;
				}else {
					fecha42 = new SimpleDateFormat("dd/MM/yyyy hh:mm:ss,SSS a").format(rs.getDate(42));
				}

				String cadena = rs.getInt(1)+"|"+
						rs.getInt(2)+"|"+
						rs.getInt(3)+"|"+
						rs.getInt(4)+"|"+
						rs.getInt(5)+"|"+
						rs.getInt(6)+"|"+
						rs.getString(7)+"|"+
						rs.getString(8)+"|"+
						rs.getString(9)+"|"+
						rs.getString(10)+"|"+
						rs.getString(11)+"|"+
						rs.getString(12)+"|"+
						rs.getString(13)+"|"+
						fecha14 +"|"+
						rs.getString(15)+"|"+
						rs.getString(16)+"|"+
						rs.getString(17)+"|"+
						rs.getString(18)+"|"+
						rs.getString(19)+"|"+
						rs.getString(20)+"|"+
						fecha21 +"|"+
						fecha22 +"|"+
						rs.getString(23)+"|"+
						rs.getString(24)+"|"+
						rs.getString(25)+"|"+
						rs.getString(26)+"|"+
						rs.getString(27)+"|"+
						rs.getString(28)+"|"+
						rs.getString(29)+"|"+
						rs.getString(30)+"|"+
						fecha31 +"|"+
						fecha32+"|"+
						rs.getString(33)+"|"+
						rs.getString(34)+"|"+
						rs.getString(35)+"|"+
						rs.getString(36)+"|"+
						rs.getString(37)+"|"+
						rs.getString(38)+"|"+
						rs.getString(39)+"|"+
						rs.getString(40)+"|"+
						rs.getString(41)+"|"+
						fecha42 +"|"+
						rs.getString(43)+"|"+
						rs.getString(44)+"|"+
						rs.getString(45)+"|"+
						rs.getString(46)+"|"+
						rs.getString(47)+"|"+
						rs.getString(48)+"|"+
						rs.getString(49)+"|"+
						rs.getString(50)+"|"+
						rs.getString(51)+"|"+
						rs.getString(52)+"|"+
						rs.getString(53)+"|"+
						rs.getString(54)+"|"+
						rs.getString(55)+"|"+
						rs.getString(56)+"|"+
						rs.getString(57)+"|"+
						rs.getString(58)+"|"+
						rs.getString(59)+"|"+
						rs.getString(60)+"|"+
						rs.getString(61)+"|"+
						rs.getString(62)+"|"+
						rs.getString(63)+"|"+
						rs.getString(64)+"|"+
						rs.getString(65)+"|"+
						rs.getString(66)+"|"+
						rs.getString(67)+"|"+
						rs.getString(68)+"|"+
						rs.getString(69)+"|"+
						rs.getString(70)+"|"+
						rs.getString(71)+"|"+
						rs.getString(72)+"|"+
						rs.getInt(73)+"|"+
						"null|"+
						rs.getString(75)+"|"+
						rs.getString(76)+"|"+
						rs.getString(77)+"|"+
						"0|"+
						"0|";
				cadena=cadena +"\n";
				b.append(cadena);
				//b.println(cadena);
			}
			b.close();
			envioSftp(archivo);
		} catch ( Exception e ) {
			//JDBCTutorialUtilities.printSQLException(e);
			e.printStackTrace();
		} finally {
			if (stmt != null) { try {
				stmt.close();
			} catch (SQLException e) {
				e.printStackTrace();
			} }
		}
		//return pmtIds;
	}

	public void envioSftp (String rutaArchivo) {

		JSch jsch = new JSch();
		try {
			Properties prop = new Properties();
			InputStream iStream = null;
			iStream = new FileInputStream("D:\\pgw-core-config\\pgw-config.properties");

			prop.load(iStream);
			String host = prop.getProperty("pasarela.ftp.host");
			String user = prop.getProperty("pasarela.ftp.user");
			String password = prop.getProperty("pasarela.ftp.password");
			this.fileName = rutaArchivo;
			this.KeyPublicPGP = prop.getProperty("pasarela.batch.baloto.summary.path.KeyPublicPGPGoAnyWhere");
			Session session = jsch.getSession(user,host,22);
			//session.setConfig("PreferredAuthentications", password);
			session.setConfig("StrictHostKeyChecking", "no");
			session.setPassword(password);
			session.connect();
			com.jcraft.jsch.Channel channel = session.openChannel("sftp");
			ChannelSftp sftp = (ChannelSftp) channel;
			sftp.connect();
			sftp.cd("reportes");
			File file = new File(cifrarPGP());
			InputStream inputStream = new FileInputStream(file);
			sftp.put(inputStream,file.getName());
			inputStream.close();
		} catch (JSchException e) {
			System.out.println("No se pudo realizar la conexi�n");
		}		
		catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		} catch (SftpException e) {
			e.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public String cifrarPGP() throws Exception {
		String nameOut = this.fileName + ".PGP";
		PGPManagement PGPManagement = new PGPManagement();
		try {
			PGPManagement.setPublicKeyFileName(this.KeyPublicPGP);
			PGPManagement.setInputFileName(this.fileName);
			PGPManagement.setOutputFileName(nameOut);
			if (PGPManagement.encrypt()) {
				System.out.println("Se encripto correctamente el archivo :".concat(this.fileName));
			} else {
				throw new Exception("Encrypt Fail");
			}
		} catch (Exception e) {
			System.out.println("Error al tratar de encriptar el archivo a PGP : ".concat(this.fileName));
			System.out.println(e.toString());
		} finally {
			PGPManagement = null;
		}
		return nameOut;
	}
	
}
