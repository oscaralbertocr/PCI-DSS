package com.trxFlow;

import static org.quartz.TriggerBuilder.newTrigger;

import java.io.FileInputStream;
import java.util.Properties;

import javax.servlet.ServletContext;
import javax.servlet.ServletContextEvent;

import org.quartz.CronScheduleBuilder;
import org.quartz.CronTrigger;
import org.quartz.JobBuilder;
import org.quartz.JobDetail;
import org.quartz.Scheduler;
import org.quartz.ee.servlet.QuartzInitializerListener;
import org.quartz.impl.StdSchedulerFactory;


public class SListener extends QuartzInitializerListener {
	
    public void contextInitialized(ServletContextEvent sce)  { 
    	super.contextInitialized(sce);
    	ServletContext ctx = sce.getServletContext();
    	StdSchedulerFactory factory = (StdSchedulerFactory) ctx.getAttribute(QUARTZ_FACTORY_KEY);
    	
    	try {
			Properties firstProp = new Properties(); 
			firstProp.load(new FileInputStream("D:\\pgw-core-config\\pgw-config.properties"));
			String firtsCron = firstProp.getProperty(  "pasarela.flujoTransacciones.1.cron");
						
			Properties secondProp = new Properties(); 
			secondProp.load(new FileInputStream("D:\\pgw-core-config\\pgw-config.properties"));
			String secondCron = secondProp.getProperty("pasarela.flujoTransacciones.2.cron");
			
//			Scheduler scheduler = StdSchedulerFactory.getDefaultScheduler();
			Scheduler scheduler = factory.getScheduler();
			JobDetail firtsJob = JobBuilder.newJob(Batch.class)
			        .withIdentity("jobFirst", "DEFAULT_GROUP")
			        .build();
			firtsJob.getJobDataMap().put("queryNumber", 1);
			
			JobDetail secondJob = JobBuilder.newJob(Batch.class)
			        .withIdentity("jobSecond", "DEFAULT_GROUP")
			        .build();
			secondJob.getJobDataMap().put("queryNumber", 2);
			
			CronTrigger cronTriggerFirst = newTrigger()
					.withIdentity("triggerDetailFirst", "DEFAULT_TRIGGER")
				    .withSchedule(createSchedule(firtsCron)).startNow().build(); 
			
			CronTrigger cronTriggerSecond = newTrigger()
					.withIdentity("triggerDetailSecond", "DEFAULT_TRIGGER")
				    .withSchedule(createSchedule(secondCron)).startNow().build(); 

			scheduler.scheduleJob(firtsJob,  cronTriggerFirst);
			scheduler.scheduleJob(secondJob, cronTriggerSecond);
			
			System.out.println("Iniciando Scheduler...");
			scheduler.start();			 
//			Thread.sleep(10000);
//			scheduler.shutdown();
		} catch(Exception e) {
			System.out.println("Ocurri� una excepci�n");
			System.out.println(e);
        }
    }
    
	private CronScheduleBuilder createSchedule(String cronExpression){
		CronScheduleBuilder builder = CronScheduleBuilder.cronSchedule(cronExpression);
		return builder;
	}
    
    public void contextDestroyed(ServletContextEvent sce)  { 
        super.contextDestroyed(sce);
    }	
}
