package com.trxFlow;
import java.io.FileInputStream;
import java.io.FileOutputStream;

import org.bouncycastle.openpgp.PGPPublicKey;
import org.bouncycastle.openpgp.PGPSecretKey;
 
/**
 * Encripta o desencripta un archivo en formato PGP. 
 *
 *
 * @author Jesus Octavio Avenda�o Sierra <jesus.avendano@sophossolutions.com> 
 * @version 1.0 16/15/2019
 * 
 * @sophosSolutions
 * <strong>Autor: </strong>Jesus Octavio Avenda�o Sierra</br>
 * <strong>Numero de Cambios: </strong>0</br>
 * 	
*/ 
public class PGPManagement {
 
	
    private String passphrase;
    private String publicKeyFileName;
    private String secretKeyFileName;
    private String inputFileName;
    private String outputFileName;
    private boolean asciiArmored = false;
    private boolean integrityCheck = true;
 
    /**
	 * Encrypta el archivo. Retorna true si el encriptado es correcto, false en otro caso 
	 * @return boolean
	*/
    public boolean encrypt() {
    	FileInputStream keyIn;
    	FileOutputStream out;
    	try {
    		System.out.println("*******************************************************************");
    		System.out.println("	LEYENDO EL ARCHIVO: " + this.inputFileName);
    		System.out.println("	USANDO LLAVE PUBLICA: " + this.publicKeyFileName);
    		keyIn = new FileInputStream(this.publicKeyFileName);
    		System.out.println("	GENERANDO ARCHIVO ENCRIPTADO: " + this.outputFileName);
            out = new FileOutputStream(this.outputFileName);
            PGPUtils.encryptFile(out, this.inputFileName, PGPUtils.readPublicKey(keyIn), this.asciiArmored, this.integrityCheck);
            System.out.println("	TERMINANDO PROCESO DE ENCRIPTADO");
            out.close();
            keyIn.close();
            System.out.println("*******************************************************************");
            return true;
		} catch (Exception e) {
			System.out.println("	ERROR EN EL PROCESO DE ENCRIPTADO");
			System.out.println("	TERMINANDO PROCESO");
			System.out.println(e);
			System.out.println("*******************************************************************");
			return false;
		}finally {
			out = null;
			keyIn = null;
		}
    }
    /**
     * encripta el archivo
     * @return boolean
     * @throws Exception
     */
    public boolean signEncrypt() throws Exception {
        FileOutputStream out = new FileOutputStream(this.outputFileName);
        FileInputStream publicKeyIn = new FileInputStream(this.publicKeyFileName);
        FileInputStream secretKeyIn = new FileInputStream(this.secretKeyFileName);
 
        PGPPublicKey publicKey = PGPUtils.readPublicKey(publicKeyIn);
        PGPSecretKey secretKey = PGPUtils.readSecretKey(secretKeyIn);
 
        PGPUtils.signEncryptFile(
                out,
                this.getInputFileName(),
                publicKey,
                secretKey,
                this.getPassphrase(),
                this.isAsciiArmored(),
                this.isIntegrityCheck() );
 
        out.close();
        publicKeyIn.close();
        secretKeyIn.close();
 
        return true;
    }
 
    /**
	 * Desencrita el archivo. Retorna true si el desencriptado es correcto, false en otro caso 
	 * @return boolean
	*/
    public boolean decrypt() throws Exception {
    	try {
    		System.out.println("*******************************************************************");
    		System.out.println("	LEYENDO EL ARCHIVO: " + this.inputFileName);
    		System.out.println("	USANDO LLAVE SECRETA: " + this.secretKeyFileName);
            FileInputStream in = new FileInputStream(this.inputFileName);
            System.out.println("	GENERANDO ARCHIVO DESENCRIPTADO: " + this.outputFileName);
            FileInputStream keyIn = new FileInputStream(this.secretKeyFileName);
            FileOutputStream out = new FileOutputStream(this.outputFileName);
            PGPUtils.decryptFile(in, out, keyIn, this.passphrase.toCharArray());
            System.out.println("	TERMINANDO PROCESO DE ENCRIPTADO");
            in.close();
            out.close();
            keyIn.close();
            System.out.println("*******************************************************************");
            return true;
		} catch (Exception e) {
			System.out.println("	ERROR EN EL PROCESO DE DESENCRIPTADO");
			System.out.println("	TERMINANDO PROCESO");
			System.out.println("*******************************************************************");
			return false;
		}
    }
 
    public boolean isAsciiArmored() {
            return this.asciiArmored;
    }
 
    public void setAsciiArmored(boolean asciiArmored) {
            this.asciiArmored = asciiArmored;
    }
 
    public boolean isIntegrityCheck() {
            return this.integrityCheck;
    }
 
    public void setIntegrityCheck(boolean integrityCheck) {
            this.integrityCheck = integrityCheck;
    }
 
    public String getPassphrase() {
            return this.passphrase;
    }
 
    public void setPassphrase(String passphrase) {
            this.passphrase = passphrase;
    }
 
    public String getPublicKeyFileName() {
            return this.publicKeyFileName;
    }
 
    public void setPublicKeyFileName(String publicKeyFileName) {
            this.publicKeyFileName = publicKeyFileName;
    }
 
    public String getSecretKeyFileName() {
            return this.secretKeyFileName;
    }
 
    public void setSecretKeyFileName(String secretKeyFileName) {
            this.secretKeyFileName = secretKeyFileName;
    }
 
    public String getInputFileName() {
            return this.inputFileName;
    }
 
    public void setInputFileName(String inputFileName) {
            this.inputFileName = inputFileName;
    }
 
    public String getOutputFileName() {
            return this.outputFileName;
    }
 
    public void setOutputFileName(String outputFileName) {
            this.outputFileName = outputFileName;
    }
 
}