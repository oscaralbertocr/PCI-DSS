package co.com.ath.pgw.srv;

import java.text.DateFormat;
import java.text.SimpleDateFormat;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import co.com.ath.pgw.bsn.service.PGWAuditService;
import co.com.ath.pgw.dto.AuditRequest;

/**
 * Servicios expuestos para la gestion de pagos
 * @author SophosSolutions
 * @version 1.0
 */
@CrossOrigin("*")
@RestController
@RequestMapping(path = "/auditManagement/v1")
public class AuditServiceFacade {
	
static Logger LOGGER = LoggerFactory.getLogger(AuditServiceFacade.class);		
	
	@Autowired
	private PGWAuditService pgwAuditService;
		
	/**
	 * Servicio encargado persistir la auditoria del front
	 * @param AuditRequest
	 * @return ResponseEntity
	 */
	@PostMapping("/Gateway_Front/Audit")
    public ResponseEntity<?> persistAudit(@RequestBody(required = true) AuditRequest auditRequest) throws Exception {
		DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		LOGGER.info("@persistAudit");
		try {
			pgwAuditService.persistAudit(auditRequest);
			return new ResponseEntity<>(HttpStatus.OK);
		} catch(Exception e) {
			LOGGER.error(auditRequest.getComponent() + "[" + auditRequest.getOperation() + "]" + " [" + dateFormat.format(auditRequest.getPrcDt()) + "] -> {}", e.getMessage());
			return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
		}
    }
	
}
