package co.com.ath.pgw.util;

public interface DTOConstants {

	public static final String TIMEZONE = "America/Bogota";

}