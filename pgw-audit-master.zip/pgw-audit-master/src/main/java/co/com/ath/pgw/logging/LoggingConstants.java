package co.com.ath.pgw.logging;

/**
 * Constantes para logging
 * @author SophosSolutions
 * @version 1.0
 */
public interface LoggingConstants {

	public static final String CORE = "CORE";
	
}