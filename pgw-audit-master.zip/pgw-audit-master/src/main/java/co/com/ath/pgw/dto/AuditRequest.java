package co.com.ath.pgw.dto;

import java.io.Serializable;
import java.util.Date;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonProperty;

import co.com.ath.pgw.util.DTOConstants;

public class AuditRequest implements Serializable {

	@JsonFormat(pattern="yyyy-MM-dd HH:mm:ss", timezone = DTOConstants.TIMEZONE)
	@JsonProperty("PrcDt")
	private Date prcDt;
	@JsonProperty("Trace")
	private String trace;
	@JsonProperty("Component")
	private String component;
	@JsonProperty("Operation")
	private String operation;
	@JsonProperty("Message")
	private String message;
	@JsonProperty("Content")
	private String content;
	private static final long serialVersionUID = -6856909768254250986L;

	public Date getPrcDt() {
		return prcDt;
	}

	public void setPrcDt(Date prcDt) {
		this.prcDt = prcDt;
	}

	public String getTrace() {
		return trace;
	}

	public void setTrace(String trace) {
		this.trace = trace;
	}

	public String getComponent() {
		return component;
	}

	public void setComponent(String component) {
		this.component = component;
	}

	public String getOperation() {
		return operation;
	}

	public void setOperation(String operation) {
		this.operation = operation;
	}

	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}

	public String getContent() {
		return content;
	}

	public void setContent(String content) {
		this.content = content;
	}

}