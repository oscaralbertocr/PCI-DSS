package co.com.ath.pgw.bsn.service;

import co.com.ath.pgw.dto.AuditRequest;

/**
 * Servicio con las operaciones para persistir la auditoria del front
 * @author SophosSolutions
 * @version 1.0
 */
public interface PGWAuditService {
	
	/**
	 * Servicio encargado persistir la auditoria del front
	 * @param AuditRequest
	 */
	public void persistAudit(AuditRequest auditRequest) throws Exception;

}
