package co.com.ath.pgw.bsn.service.impl;

import java.text.DateFormat;
import java.text.SimpleDateFormat;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import co.com.ath.pgw.bsn.service.PGWAuditService;
import co.com.ath.pgw.dto.AuditRequest;

/**
 * Servicio con las operaciones para persistir la auditoria del front
 * @author SophosSolutions
 * @version 1.0
 */
@Service
public class PGWAuditServiceImpl implements PGWAuditService{

	static Logger LOGGER = LoggerFactory.getLogger(PGWAuditServiceImpl.class);

	@Override
	public void persistAudit(AuditRequest auditRequest) throws Exception {
		DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		try {
			switch (auditRequest.getTrace()) {
				case "ERROR":
					if(auditRequest.getContent() != null && !auditRequest.getContent().isEmpty())
						LOGGER.error(auditRequest.getComponent() + "[" + auditRequest.getOperation() + "]" + " [" + dateFormat.format(auditRequest.getPrcDt()) + "] -> {}", auditRequest.getMessage() + "\n" + auditRequest.getContent());
					else
						LOGGER.error(auditRequest.getComponent() + "[" + auditRequest.getOperation() + "]" + " [" + dateFormat.format(auditRequest.getPrcDt()) + "] -> {}", auditRequest.getMessage());
				break;
				
				case "WARN":
					if(auditRequest.getContent() != null && !auditRequest.getContent().isEmpty())
						LOGGER.warn(auditRequest.getComponent() + "[" + auditRequest.getOperation() + "]" + " [" + dateFormat.format(auditRequest.getPrcDt()) + "] -> {}", auditRequest.getMessage() + "\n" + auditRequest.getContent());
					else
						LOGGER.warn(auditRequest.getComponent() + "[" + auditRequest.getOperation() + "]" + " [" + dateFormat.format(auditRequest.getPrcDt()) + "] -> {}", auditRequest.getMessage());
				break;
				
				case "DEBUG":
					if(auditRequest.getContent() != null && !auditRequest.getContent().isEmpty())
						LOGGER.debug(auditRequest.getComponent() + "[" + auditRequest.getOperation() + "]" + " [" + dateFormat.format(auditRequest.getPrcDt()) + "] -> {}", auditRequest.getMessage() + "\n" + auditRequest.getContent());
					else
						LOGGER.debug(auditRequest.getComponent() + "[" + auditRequest.getOperation() + "]" + " [" + dateFormat.format(auditRequest.getPrcDt()) + "] -> {}", auditRequest.getMessage());
				break;
				
				default:
					if(auditRequest.getContent() != null && !auditRequest.getContent().isEmpty())
						LOGGER.info(auditRequest.getComponent() + "[" + auditRequest.getOperation() + "]" + " [" + dateFormat.format(auditRequest.getPrcDt()) + "] -> {}", auditRequest.getMessage() + "\n" + auditRequest.getContent());
					else
						LOGGER.info(auditRequest.getComponent() + "[" + auditRequest.getOperation() + "]" + " [" + dateFormat.format(auditRequest.getPrcDt()) + "] -> {}", auditRequest.getMessage());
			}
		} catch(Exception e) {
			throw new Exception(e);
		}
	}
	
}
