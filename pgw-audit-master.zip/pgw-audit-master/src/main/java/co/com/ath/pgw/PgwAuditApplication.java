package co.com.ath.pgw;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PgwAuditApplication {

	public static void main(String[] args) {
		SpringApplication.run(PgwAuditApplication.class, args);
	}

}
