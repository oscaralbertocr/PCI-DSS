package co.com.ath.pgw.logging;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.slf4j.Marker;

import ch.qos.logback.classic.Level;
import ch.qos.logback.classic.turbo.TurboFilter;
import ch.qos.logback.core.spi.FilterReply;

/**
 * 
 * @author roger.leguizamon
 *
 */
public class LogginSensitiveDataFilter extends TurboFilter {
	
	private static final String MASK = "$2$4$6$8****$10";
	
	/**
	 * REGEX JSON
	 */
	private static final String REGEX_TAG_JSON = "\"InvoiceNum\": \"|\"NIE\": \\[|\"data\": \"|\"AcctId\": \"[0-9]{15}|\"CardVrfyData\": \"";
	private static final String REGEX_NUM_JSON = "((\"InvoiceNum\": \")([0-9]{4,})|(\"CardVrfyData\": \")([0-9]{3,})|(\"NIE\": \\[\")([0-9]{3,}+)|(\"AcctId\": \"[0-9]{6})([0-9]{6})([0-9]{4,}))";
	private static Pattern patternTagJson = Pattern.compile(REGEX_TAG_JSON);
	private static Pattern patternCardJson = Pattern.compile(REGEX_NUM_JSON);
	
	public LogginSensitiveDataFilter() {
		super();
	}

	@Override
	public FilterReply decide(Marker marker, ch.qos.logback.classic.Logger logger, Level level, String format,
			Object[] params, Throwable t) {
		try {

			if (params != null && params.length > 0) {
				for (Object param : params) {
					if(param != null) {
						Matcher matcherTagJson = patternTagJson.matcher(param.toString());
						Matcher matcherCar = null;
						if (matcherTagJson.find()) matcherCar = patternCardJson.matcher(param.toString());
						if(matcherCar != null) {
							StringBuilder result = new StringBuilder();
							if (format.contains("@") && format.contains("{}"));
							result.append(format.replaceAll("\\{\\}", ""));
							if (matcherCar.find()) {
								result.append(matcherCar.replaceAll(MASK));
								logger.info(result.toString());
								return FilterReply.DENY;
							}
						}
					}
				}
			}

		} catch (Exception e) {
			e.printStackTrace();
		}
		return FilterReply.NEUTRAL;
	}

}
