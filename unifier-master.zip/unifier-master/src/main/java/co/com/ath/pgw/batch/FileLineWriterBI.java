package co.com.ath.pgw.batch;

import java.io.File;

import javax.annotation.PostConstruct;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.batch.core.configuration.annotation.StepScope;
import org.springframework.batch.item.file.FlatFileItemWriter;
import org.springframework.batch.item.file.transform.DelimitedLineAggregator;
import org.springframework.batch.item.file.transform.FieldExtractor;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.io.FileSystemResource;
import org.springframework.core.io.Resource;
import org.springframework.stereotype.Service;

import co.com.ath.pgw.dto.FileLineBI;

/**
 * Writer del batch de destokenizacion
 *
 * @author Jesus Octavio Avenda�o Sierra <jesus.avendano@sophossolutions.com>
 * @version 1.0 16/15/2019
 * 
 * @sophosSolutions <strong>Autor: </strong>Jesus Octavio Avenda�o Sierra</br>
 *                  <strong>Numero de Cambios: </strong>0</br>
 *                  
 * @sophosSolutions <strong>Autor: </strong>Nelly Rocio Linares</br>
 *  <strong>Version </strong>1.1</br>
 * 
 */

@Service
@StepScope
public class FileLineWriterBI extends FlatFileItemWriter<FileLineBI>{

	static Logger LOGGER = LoggerFactory.getLogger(FileLineWriterBI.class);

	@Value("#{jobParameters[destinyBI]}")
	private String destiny;

	@Value("#{jobParameters[fileName]}")
	private String fileName;
	
	@PostConstruct
	public void init() {
		Resource resource = new FileSystemResource(new File(destiny, this.fileName));
		this.setResource(resource);
		this.setLineAggregator(this.delimitedLineAggregator());
	}

	DelimitedLineAggregator<FileLineBI> delimitedLineAggregator() {
		DelimitedLineAggregator<FileLineBI> delimitedLineAggregator = new DelimitedLineAggregator<FileLineBI>();
		delimitedLineAggregator.setDelimiter("");
		delimitedLineAggregator.setFieldExtractor(new FieldExtractor<FileLineBI>() {

			@Override
			public Object[] extract(FileLineBI item) {
				
				return new Object[] { item.getLine()};
			}
		});
		return delimitedLineAggregator;
	}

	
}