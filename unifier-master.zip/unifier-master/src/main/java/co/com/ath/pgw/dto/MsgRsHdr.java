package co.com.ath.pgw.dto;

import java.io.Serializable;
import java.util.Date;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonProperty;

import co.com.ath.pgw.util.Constants;

public class MsgRsHdr implements Serializable {

	@JsonProperty("Status")
	private Status status;
	@JsonFormat(pattern="yyyy-MM-dd HH:mm:ss", timezone = Constants.TIMEZONE)
	@JsonProperty("EndDt")
	private Date endDt;
	private static final long serialVersionUID = -5941293430268074204L;

	public Status getStatus() {
		return status;
	}

	public void setStatus(Status status) {
		this.status = status;
	}

	public Date getEndDt() {
		return endDt;
	}

	public void setEndDt(Date endDt) {
		this.endDt = endDt;
	}

}