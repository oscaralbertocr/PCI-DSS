package co.com.ath.pgw.batch;

import java.io.File;

import javax.annotation.PostConstruct;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.batch.core.configuration.annotation.StepScope;
import org.springframework.batch.item.file.FlatFileItemReader;
import org.springframework.batch.item.file.mapping.BeanWrapperFieldSetMapper;
import org.springframework.batch.item.file.mapping.DefaultLineMapper;
import org.springframework.batch.item.file.transform.FixedLengthTokenizer;
import org.springframework.batch.item.file.transform.Range;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.io.FileSystemResource;
import org.springframework.stereotype.Service;

import co.com.ath.pgw.dto.FileLineRecaudo;

/**
 * 
 * custom Exception.
 *
 * @author Jesus Octavio Avendaño Sierra <jesus.avendano@sophossolutions.com> 
 * @version 1.0 16/15/2019
 * 
 * @sophosSolutions
 * <strong>Autor: </strong>Jesus Octavio Avendaño Sierra</br>
 * <strong>Numero de Cambios: </strong>0</br>
 * 
 * 	
*/

@Service
@StepScope
public class FileMultiReaderRecaudo extends FlatFileItemReader<FileLineRecaudo>{
	

	static Logger LOGGER = LoggerFactory.getLogger(FileMultiReaderRecaudo.class);
	
	@Value("#{jobParameters[fileName]}")
	private String fileName;

	@Value("#{jobParameters[fileType]}")
	private String fileType;
	
	@Value("#{jobParameters[unifierFlag]}")
	private String unifierFlag;
	
	@Value("#{jobParameters[pathDownloadRecaudo1]}")
	private String pathDownload1;

	@Value("#{jobParameters[pathDownloadRecaudo2]}")
	private String pathDownload2;
	
	@Value("#{jobParameters[pathDownloadBBTAClaro]}")
	private String pathDownloadBBTAClaro;
	
	@Value("#{jobParameters[sPName]}")
	private String sPName;	
	
	
	@PostConstruct
	public void init() { 
		
		
		if(this.sPName.equals("BBOGTC")) {
			LOGGER.info(pathDownloadBBTAClaro + "/" + fileName);
			setResource(new FileSystemResource(new File(this.pathDownloadBBTAClaro, this.fileName)));
		}else {
			LOGGER.info(pathDownload1 + "/" + fileName);
			setResource(new FileSystemResource(new File(this.pathDownload1, this.fileName)));
		}
		
		this.setEncoding("utf8");
		this.setLineMapper(this.lineMapper());
	}

	private DefaultLineMapper<FileLineRecaudo> lineMapper(){
		DefaultLineMapper<FileLineRecaudo> defaultLineMapper = new DefaultLineMapper<FileLineRecaudo>();
		defaultLineMapper.setFieldSetMapper(this.beanWrapperFieldSetMapper());
		LOGGER.info("Configurando orden de columnas en la linea");
		defaultLineMapper.setLineTokenizer(this.tokenizerRecaudos());
		LOGGER.info("Configuracion de orden de columnas en la linea Terminada");
		return defaultLineMapper;
	}

	private BeanWrapperFieldSetMapper<FileLineRecaudo> beanWrapperFieldSetMapper() {
		BeanWrapperFieldSetMapper<FileLineRecaudo> beanWrapperFieldSetMapper = new  BeanWrapperFieldSetMapper<FileLineRecaudo>();
		beanWrapperFieldSetMapper.setTargetType(FileLineRecaudo.class);
		return beanWrapperFieldSetMapper;
	}

	/**
	 * Tokenizer para recaudos.
	 *
	 * @author Jesus Octavio Avenda�o Sierra <jesus.avendano@sophossolutions.com> 
	 * @version 1.0 16/15/2019
	 */
	private FixedLengthTokenizer tokenizerRecaudos() {
		LOGGER.info("Tokenizando linea para Recaudos");
		FixedLengthTokenizer fixedLengthTokenizer = new FixedLengthTokenizer();
		String[] names = {
				"flag",
				"next",
		};

		Range[] ranges = {
				new Range(1,2),
				new Range(3)
		};

		fixedLengthTokenizer.setNames(names);
		fixedLengthTokenizer.setColumns(ranges);
		return fixedLengthTokenizer;
	}
	
}