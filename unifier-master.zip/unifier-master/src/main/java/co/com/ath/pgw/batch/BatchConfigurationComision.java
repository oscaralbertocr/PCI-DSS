package co.com.ath.pgw.batch;

import java.util.HashMap;

import javax.annotation.PostConstruct;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.batch.core.Job;
import org.springframework.batch.core.JobExecution;
import org.springframework.batch.core.JobParametersBuilder;
import org.springframework.batch.core.Step;
import org.springframework.batch.core.configuration.annotation.JobBuilderFactory;
import org.springframework.batch.core.configuration.annotation.StepBuilderFactory;
import org.springframework.batch.core.launch.JobLauncher;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import co.com.ath.pgw.dto.FileLineComision;
import co.com.ath.pgw.util.XMLUtil;

/**
 * Configuración del proceso 
 * 
 * Batch para la destokenizacion de los reportes.
 *
 * @author Jesus Octavio Avendaño Sierra <jesus.avendano@sophossolutions.com> 
 * @version 1.0 16/15/2019
 * 
 * @sophosSolutions
 * <strong>Autor: </strong>Jesus Octavio Avendaño Sierra</br>
 * <strong>Numero de Cambios: </strong>0</br>
 * 
 * * @sophosSolutions
 * <strong>Autor: </strong>Nelly Rocio Linares</br>
 * <strong>Version </strong>1.1</br>
 * 	
*/
@Service
public class BatchConfigurationComision {

	static Logger LOGGER = LoggerFactory.getLogger(XMLUtil.class);
	
	@Autowired(required=true)
	private JobBuilderFactory jobBuilderFactory;

	@Autowired(required=true)
	private StepBuilderFactory stepBuilderFactory;

	@Autowired(required=true)
	private JobLauncher jobLauncher;

	@Autowired(required=true)
	private FileMultiReaderComision fileMultiReaderComision;
	
	@Autowired(required=true)
	private FileLineProcessorComision fileLineProcessorComision;
	
	@Autowired(required=true)
	private FileLineWriterComision fileLineWriterComision;
	
	@Autowired(required=true)
	private DecryptTasklet decryptTasklet;
	
	@Autowired(required=true)
	private EncryptTasklet encryptTasklet;

	private Job job;
	
	private final String JOB_NAME = "MERGE";

	private String TASKLET_DECRYPT = "DECRYPT_STEP";
	
	private final String STEP_NAME = "MERGE_LINES";
	
	private String TASKLET_ENCRYPT = "ENCRYPT_STEP";
	
	@PostConstruct
	public void init() {
		this.job = this.createJob();
	}
	
	/**
	 * Sonda encargada de destokenizar los reportes.
	 * 
	 * @param fileName
	 *            Nombre del archivo.
	 *
	 * @param filePath
	 *            Ruta donde se encuetra el archivo especificado.
	 *
	 * @param fileType
	 *            Tipo de archivo (Recaudo, Comision).
	 * 
	 **/
	public void run(HashMap<String, String> parameters) {
		JobParametersBuilder jobParametersBuilder = this.generateParameters(parameters);
		this.executeJob(jobParametersBuilder);		
	}
	
	/**
	 * Ejecuta el Job del batch.
	 * 
	 * @return 
	 * 		JobExecution
	 **/
	private JobExecution executeJob(JobParametersBuilder jobParams) {
		JobExecution jobExecution;
		try {
			jobExecution = this.jobLauncher.run(this.job, jobParams.toJobParameters());
		} catch (Exception e) {
			jobExecution = null;
			e.printStackTrace();
		}
		return jobExecution;
	}
	
	/**
	 * Genera el job del batch.
	 * 
	 * @return 
	 * 		Job
	 **/
	private Job createJob() {
		return this.jobBuilderFactory.get(this.JOB_NAME)
				.flow(this.decryptFile())
				.next(this.mergeFiles())
				.next(this.encryptFile())
				.end()
				.build();
	}
	
	/**
	 * Genera el step de detokenizacion.
	 * 
	 * @return 
	 * 		Step
	 **/
	private Step decryptFile(){
			return this.stepBuilderFactory.get(this.TASKLET_DECRYPT)
					.tasklet(this.decryptTasklet)
					.build();
	}
	
	/**
	 * Genera el step del job.
	 * 
	 * @return 
	 * 		Step
	 **/
	private Step mergeFiles() {
		return this.stepBuilderFactory.get(this.STEP_NAME)
				.<FileLineComision, FileLineComision> chunk(100)
				.reader(this.fileMultiReaderComision)
				.processor(this.fileLineProcessorComision)
				.writer(this.fileLineWriterComision)
				//.faultTolerant()
				//.retryPolicy(new AlwaysRetryPolicy())
				.build();
	}
	
	/**
	 * Genera la encripcion del archivo.
	 * 
	 * @return 
	 * 		Step
	 **/
	private Step encryptFile(){
			return this.stepBuilderFactory.get(this.TASKLET_ENCRYPT)
					.tasklet(this.encryptTasklet)
					.build();
	}

	
	 // Final.Version.1.1
	
	/**
	 * Genera el objeto jobParametersBuilder con los parametros requeridos.
	 * 
	 * @param fileName
	 *            Nombre del archivo.
	 *
	 * @param filePath
	 *            Ruta donde se encuetra el archivo especificado.
	 *
	 * @param fileType
	 *            Tipo de archivo (Recaudo, Comision).
	 * 
	 **/
	private JobParametersBuilder generateParameters(HashMap<String, String> parameters) {
		LOGGER.info("Generando parametros");
		JobParametersBuilder jobParametersBuilder = new JobParametersBuilder();
		jobParametersBuilder.addLong("time", System.currentTimeMillis());
		jobParametersBuilder.addString("fileName", parameters.get("fileName"));
		jobParametersBuilder.addString("unifierFlag", parameters.get("unifierFlag"));
		jobParametersBuilder.addString("sPName", parameters.get("sPName"));
		jobParametersBuilder.addString("pathDownloadComision1", parameters.get("pathDownloadComision1"));
		jobParametersBuilder.addString("pathDownloadComision2", parameters.get("pathDownloadComision2"));
		jobParametersBuilder.addString("destinyComision", parameters.get("destinyComision"));
		jobParametersBuilder.addString("fileType", parameters.get("fileType"));
		jobParametersBuilder.addString("keyPrivateATHPGP", parameters.get("keyPrivateATHPGP"));
		jobParametersBuilder.addString("KeyPublicPGPComisionBOG", parameters.get("KeyPublicPGPComisionBOG"));
		jobParametersBuilder.addString("KeyPublicPGPComisionOCC", parameters.get("KeyPublicPGPComisionOCC"));
		jobParametersBuilder.addString("KeyPublicPGPComisionAVV", parameters.get("KeyPublicPGPComisionAVV"));
		jobParametersBuilder.addString("KeyPublicPGPComisionPOP", parameters.get("KeyPublicPGPComisionPOP"));
		jobParametersBuilder.addString("razonSocial", parameters.get("razonSocial"));
		jobParametersBuilder.addString("pasPrivKey", parameters.get("pasPrivKey"));
		LOGGER.info("Parametros Generados");
		return jobParametersBuilder;
	}

}
