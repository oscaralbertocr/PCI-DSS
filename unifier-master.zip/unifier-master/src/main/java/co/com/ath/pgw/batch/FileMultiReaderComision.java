package co.com.ath.pgw.batch;

import java.io.File;

import javax.annotation.PostConstruct;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.batch.core.configuration.annotation.StepScope;
import org.springframework.batch.item.file.MultiResourceItemReader;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.io.FileSystemResource;
import org.springframework.core.io.Resource;
import org.springframework.stereotype.Service;

import co.com.ath.pgw.dto.FileLineComision;

/**
 * 
 * custom Exception.
 *
 * @author Jesus Octavio Avendaño Sierra <jesus.avendano@sophossolutions.com> 
 * @version 1.0 16/15/2019
 * 
 * @sophosSolutions
 * <strong>Autor: </strong>Jesus Octavio Avendaño Sierra</br>
 * <strong>Numero de Cambios: </strong>0</br>
 * 
 * 	
*/

@Service
@StepScope
public class FileMultiReaderComision extends MultiResourceItemReader<FileLineComision>{
	

	static Logger LOGGER = LoggerFactory.getLogger(FileMultiReaderComision.class);
	
	@Value("#{jobParameters[fileName]}")
	private String fileName;

	@Value("#{jobParameters[fileType]}")
	private String fileType;
	
	@Value("#{jobParameters[unifierFlag]}")
	private String unifierFlag;
	
	@Value("#{jobParameters[pathDownloadComision1]}")
	private String pathDownload1;

	@Value("#{jobParameters[pathDownloadComision2]}")
	private String pathDownload2;
	
	
	
	@Autowired(required=true)
	private FileLineReaderComision fileLineReader;

	@PostConstruct
	public void init() { 
		LOGGER.info(pathDownload1 + "//" + fileName);
		if(this.unifierFlag.equals("0")) {
			setResources(new Resource[] {	new FileSystemResource(new File(this.pathDownload1, this.fileName)),
											new FileSystemResource(new File(this.pathDownload2, this.fileName))});
		}else if(this.unifierFlag.equals("1")){//Dejar de Unificar - solo lee el de Nube LZ
			setResources(new Resource[] {	new FileSystemResource(new File(this.pathDownload1, this.fileName))});
		}
		else if(this.unifierFlag.equals("2")){//Dejar de Unificar - solo lee el de Nube RS
			setResources(new Resource[] {   new FileSystemResource(new File(this.pathDownload2, this.fileName))});
		}
		setDelegate(fileLineReader);
	}

}
