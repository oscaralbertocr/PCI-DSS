package co.com.ath.pgw.util;

public interface Constants {

	public static final String TIMEZONE = "America/Bogota";
	
	public static final Integer ERROR_STATUS_CODE_300 = 300;
	
	public static final String ERROR_STATUS_CODE_DESC = "No es posible procesar la transacci�n.";
	
	public static final String SERVICE_TOKENIZE_VOLTAGE = "VOLTAGE";
	public static final String SERVICE_TOKENIZE_GEMALTO = "GEMALTO";
	public static final String HEADER_LOG = "*******************************************************************";
	
}
