package co.com.ath.pgw.dto;


import com.fasterxml.jackson.annotation.JsonProperty;

/**
 * DTO Repsuesta del consumo al servicio de destokenizacion (Servicio externo).
 *
 *
 * @author Jesus Octavio Avendaño Sierra <jesus.avendano@sophossolutions.com> 
 * @version 1.0 16/15/2019
 * 
 * @sophosSolutions
 * <strong>Autor: </strong>Jesus Octavio Avendaño Sierra</br>
 * <strong>Numero de Cambios: </strong>0</br>
 * 	
*/
public class ResponseDetokenizationService {
	
	@JsonProperty("value")
	private String value;
	
	
	public ResponseDetokenizationService() {
	}
	
	public ResponseDetokenizationService(String value) {
		this.value = value;
	}
	
	/**
    *
    *@return el valor
    */
	public String getValue() {
		return value;
	}
	/**
    *
    *@param value
    *			string que representa al valor destokenizado
    */
	public void setValue(String value) {
		this.value = value;
	}
	
		
}
