package co.com.ath.pgw.util;




import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.security.NoSuchProviderException;
import java.security.Provider;
import java.security.SecureRandom;
import java.security.Security;
import java.security.SignatureException;
import java.util.Date;
import java.util.Iterator;

import javax.xml.datatype.DatatypeConfigurationException;
import javax.xml.datatype.DatatypeFactory;

import org.apache.commons.io.IOUtils;
import org.bouncycastle.bcpg.ArmoredOutputStream;
import org.bouncycastle.bcpg.HashAlgorithmTags;
import org.bouncycastle.bcpg.PublicKeyAlgorithmTags;
import org.bouncycastle.bcpg.sig.KeyFlags;
import org.bouncycastle.jce.provider.BouncyCastleProvider;
import org.bouncycastle.openpgp.PGPCompressedData;
import org.bouncycastle.openpgp.PGPCompressedDataGenerator;
import org.bouncycastle.openpgp.PGPEncryptedDataGenerator;
import org.bouncycastle.openpgp.PGPEncryptedDataList;
import org.bouncycastle.openpgp.PGPException;
import org.bouncycastle.openpgp.PGPLiteralData;
import org.bouncycastle.openpgp.PGPLiteralDataGenerator;
import org.bouncycastle.openpgp.PGPObjectFactory;
import org.bouncycastle.openpgp.PGPOnePassSignature;
import org.bouncycastle.openpgp.PGPOnePassSignatureList;
import org.bouncycastle.openpgp.PGPPrivateKey;
import org.bouncycastle.openpgp.PGPPublicKey;
import org.bouncycastle.openpgp.PGPPublicKeyEncryptedData;
import org.bouncycastle.openpgp.PGPPublicKeyRing;
import org.bouncycastle.openpgp.PGPPublicKeyRingCollection;
import org.bouncycastle.openpgp.PGPSecretKey;
import org.bouncycastle.openpgp.PGPSecretKeyRing;
import org.bouncycastle.openpgp.PGPSecretKeyRingCollection;
import org.bouncycastle.openpgp.PGPSignature;
import org.bouncycastle.openpgp.PGPSignatureGenerator;
import org.bouncycastle.openpgp.PGPSignatureList;
import org.bouncycastle.openpgp.PGPSignatureSubpacketGenerator;
import org.bouncycastle.openpgp.PGPSignatureSubpacketVector;
import org.bouncycastle.openpgp.PGPUtil;
import org.bouncycastle.openpgp.operator.PBESecretKeyDecryptor;
import org.bouncycastle.openpgp.operator.PGPContentSignerBuilder;
import org.bouncycastle.openpgp.operator.bc.BcPBESecretKeyDecryptorBuilder;
import org.bouncycastle.openpgp.operator.bc.BcPGPContentSignerBuilder;
import org.bouncycastle.openpgp.operator.bc.BcPGPContentVerifierBuilderProvider;
import org.bouncycastle.openpgp.operator.bc.BcPGPDataEncryptorBuilder;
import org.bouncycastle.openpgp.operator.bc.BcPGPDigestCalculatorProvider;
import org.bouncycastle.openpgp.operator.bc.BcPublicKeyDataDecryptorFactory;
import org.bouncycastle.openpgp.operator.bc.BcPublicKeyKeyEncryptionMethodGenerator;
import org.bouncycastle.openpgp.operator.jcajce.JcaPGPContentVerifierBuilderProvider;
import org.bouncycastle.util.io.Streams;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * Herraientas para encripcion en PGP.
 *
 *
 */
public class FirmUtils {

	private FirmUtils() {
	}

	private static final Logger log = LoggerFactory.getLogger(PGPUtils.class);

	private static final int BUFFER_SIZE = 1 << 16;
	private static final int KEY_FLAGS = 27;
	private static final int[] MASTER_KEY_CERTIFICATION_TYPES = new int[] { PGPSignature.POSITIVE_CERTIFICATION,
			PGPSignature.CASUAL_CERTIFICATION, PGPSignature.NO_CERTIFICATION, PGPSignature.DEFAULT_CERTIFICATION };

	@SuppressWarnings("unchecked")
	public static PGPPublicKey readPublicKey(InputStream inputStream) throws IOException, PGPException {
		PGPPublicKeyRingCollection pgpPublicKeyRingCollection = new PGPPublicKeyRingCollection(
				PGPUtil.getDecoderStream(inputStream));
		PGPPublicKey pgpPublicKey = null;
		Iterator<PGPPublicKeyRing> keyRingsIterator = pgpPublicKeyRingCollection.getKeyRings();

		while (pgpPublicKey == null && keyRingsIterator.hasNext()) {
			PGPPublicKeyRing pgpPublicKeyRing = keyRingsIterator.next();
			Iterator<PGPPublicKey> publicKeysIterator = pgpPublicKeyRing.getPublicKeys();
			while (pgpPublicKey == null && publicKeysIterator.hasNext()) {
				PGPPublicKey key = publicKeysIterator.next();
				if (key.isEncryptionKey()) {
					pgpPublicKey = key;
				}
			}
		}
		if (pgpPublicKey == null) {
			throw new IllegalArgumentException("No se encontro la llave publica.");
		}
		if (!isForEncryption(pgpPublicKey)) {
			throw new IllegalArgumentException(
					"La llave " + pgpPublicKey.getKeyID() + " no permitida para encriptaci�n.");
		}
		return pgpPublicKey;
	}

	@SuppressWarnings("unchecked")
	public static PGPSecretKey readSecretKey(InputStream in) throws IOException, PGPException {
		PGPSecretKeyRingCollection keyRingCollection = new PGPSecretKeyRingCollection(PGPUtil.getDecoderStream(in));
		PGPSecretKey secretKey = null;
		Iterator<PGPSecretKeyRing> rIt = keyRingCollection.getKeyRings();
		while (secretKey == null && rIt.hasNext()) {
			PGPSecretKeyRing keyRing = rIt.next();
			Iterator<PGPSecretKey> kIt = keyRing.getSecretKeys();
			while (secretKey == null && kIt.hasNext()) {
				PGPSecretKey key = kIt.next();
				if (key.isSigningKey()) {
					secretKey = key;
				}
			}
		}
		if (secretKey == null) {
			throw new IllegalArgumentException("Can't find private key in the key ring.");
		}
		if (!secretKey.isSigningKey()) {
			throw new IllegalArgumentException("Private key does not allow signing.");
		}
		if (secretKey.getPublicKey().isRevoked()) {
			throw new IllegalArgumentException("Private key has been revoked.");
		}
		if (!hasKeyFlags(secretKey.getPublicKey(), KeyFlags.SIGN_DATA)) {
			throw new IllegalArgumentException("Key cannot be used for signing.");
		}

		return secretKey;
	}

	/**
	 * Load a secret key ring collection from keyIn and find the private kay
	 * corresponding to kayID if it exists.
	 *
	 * @param keyIn input stream representing a key ring collection.
	 * @param keyID keyID we want.
	 * @param pass  pas to dec secret key with.
	 * @return
	 * @throws IOException
	 * @throws PGPException
	 * @throws NoSuchProviderException
	 */
	public static PGPPrivateKey findPrivateKey(InputStream keyIn, long keyID, char[] pass)
			throws IOException, PGPException {
		PGPSecretKeyRingCollection pgpSec = new PGPSecretKeyRingCollection(PGPUtil.getDecoderStream(keyIn));
		return findPrivateKey(pgpSec.getSecretKey(keyID), pass);

	}

	/**
	 * Load a secret key and find the private key in it
	 * 
	 * @param pgpSecKey The secret kay
	 * @param pas       pas to dec secret kay with
	 * @return
	 * @throws PGPException
	 */
	public static PGPPrivateKey findPrivateKey(PGPSecretKey pgpSecKey, char[] pass) throws PGPException {
		if (pgpSecKey == null)
			return null;

		PBESecretKeyDecryptor decryptor = new BcPBESecretKeyDecryptorBuilder(new BcPGPDigestCalculatorProvider())
				.build(pass);
		return pgpSecKey.extractPrivateKey(decryptor);
	}

	/**
	 * decrypt the passed in message stream
	 * 
	 * @throws IOException
	 * @throws PGPException
	 * @throws SignatureException
	 */

	public static void decryptFile(InputStream in, OutputStream out, InputStream keyIn, InputStream keySn,
			char[] passwd) throws IOException, PGPException, SignatureException

	{
		Security.addProvider(new BouncyCastleProvider());

		in = org.bouncycastle.openpgp.PGPUtil.getDecoderStream(in);

		PGPObjectFactory pgpF = new PGPObjectFactory(in);
		PGPEncryptedDataList enc;

		Object o = pgpF.nextObject();
		//
		// the first object might be a PGP marker packet.
		//
		if (o instanceof PGPEncryptedDataList) {
			enc = (PGPEncryptedDataList) o;
		} else {
			enc = (PGPEncryptedDataList) pgpF.nextObject();
		}

		processDecryptFile(out, keyIn, keySn, passwd, enc);

	}

	@SuppressWarnings("unchecked")
	public static void processDecryptFile(OutputStream out, InputStream keyIn, InputStream keySn, char[] passwd,
			PGPEncryptedDataList enc) throws IOException, PGPException, SignatureException {

		//
		// find the secret key
		//
		Iterator<PGPPublicKeyEncryptedData> it = enc.getEncryptedDataObjects();
		PGPPrivateKey sKey = null;
		PGPPublicKeyEncryptedData pbe = null;

		while (sKey == null && it.hasNext()) {
			pbe = it.next();
			sKey = findPrivateKey(keyIn, pbe.getKeyID(), passwd);
		}

		if (sKey == null) {
			throw new IllegalArgumentException("Secret key for message not found.");
		}

		InputStream clear = pbe.getDataStream(new BcPublicKeyDataDecryptorFactory(sKey));

		ByteArrayOutputStream actualOutput = actualOutput(keySn, clear);

		if (pbe.isIntegrityProtected() && !pbe.verify()) {
			throw new PGPException("Data is integrity protected but integrity is lost.");
		}

		out.write(actualOutput.toByteArray());

	}

	public static ByteArrayOutputStream actualOutput(InputStream keySn, InputStream clear)
			throws IOException, PGPException, SignatureException {

		PGPObjectFactory plainFact = new PGPObjectFactory(clear);

		Object message = null;
		/* para validar las firmas que vienen encriptadas */
		PGPOnePassSignatureList onePassSignatureList = null;
		PGPSignatureList signatureList = null;
		PGPCompressedData compressedData = null;
		ByteArrayOutputStream actualOutput = new ByteArrayOutputStream();
		/*-------*/
		message = plainFact.nextObject();

		while (message != null) {

			if (message instanceof PGPCompressedData) {
				compressedData = (PGPCompressedData) message;
				plainFact = new PGPObjectFactory(compressedData.getDataStream());

				message = plainFact.nextObject();
			}

			if (message instanceof PGPLiteralData) {
				// have to read it and keep it somewhere.
				Streams.pipeAll(((PGPLiteralData) message).getInputStream(), actualOutput);

			} else if (message instanceof PGPOnePassSignatureList) {
				onePassSignatureList = (PGPOnePassSignatureList) message;
			} else if (message instanceof PGPSignatureList) {
				signatureList = (PGPSignatureList) message;
			} else {
				throw new PGPException("Message is not a simple encrypted file - type unknown.");
			}

			try {
				message = plainFact.nextObject();
			} catch (Exception e) {
				message = null;
				log.error("Error decryptFile {}", e.toString());
			}
		}

		actualOutput.close();

		if (onePassSignatureList == null || signatureList == null) {
			throw new PGPException("Poor PGP. Signatures not found.");
		} else {
			passSignature(onePassSignatureList, keySn, actualOutput, signatureList);
		}

		return actualOutput;
	}

	public static void passSignature(PGPOnePassSignatureList onePassSignatureList, InputStream keySn,
			ByteArrayOutputStream actualOutput, PGPSignatureList signatureList)
			throws IOException, PGPException, SignatureException {

		PGPPublicKey publicKey = null;
		byte[] output = actualOutput.toByteArray();
		for (int i = 0; i < onePassSignatureList.size(); i++) {
			PGPOnePassSignature ops = onePassSignatureList.get(0);
			PGPPublicKeyRingCollection pgpRing = new PGPPublicKeyRingCollection(PGPUtil.getDecoderStream(keySn));

			publicKey = pgpRing.getPublicKey(ops.getKeyID());
			if (publicKey != null) {
				ops.init(new JcaPGPContentVerifierBuilderProvider().setProvider("BC"), publicKey);
				ops.update(output);
				PGPSignature signature = signatureList.get(i);
				if (ops.verify(signature)) {
					Iterator<?> userIds = publicKey.getUserIDs();
					while (userIds.hasNext()) {
						userIds.next();
					}
				} else {
					throw new PGPException("Signature verification failed");
				}
			}
		}

		if (publicKey == null) {
			throw new PGPException("Signature not found");
		}
	}

	public static void encryptFile(OutputStream out, String fileName, PGPPublicKey encKey, boolean armor,
			boolean withIntegrityCheck) throws IOException, PGPException {
		Security.addProvider(new BouncyCastleProvider());

		if (armor) {
			out = new ArmoredOutputStream(out);
		}

		ByteArrayOutputStream bOut = new ByteArrayOutputStream();
		PGPCompressedDataGenerator comData = new PGPCompressedDataGenerator(1);

		PGPUtil.writeFileToLiteralData(comData.open(bOut), PGPLiteralData.BINARY, new File(fileName));

		comData.close();

		BcPGPDataEncryptorBuilder dataEncryptor = new BcPGPDataEncryptorBuilder(2);
		dataEncryptor.setWithIntegrityPacket(withIntegrityCheck);
		dataEncryptor.setSecureRandom(new SecureRandom());

		PGPEncryptedDataGenerator encryptedDataGenerator = new PGPEncryptedDataGenerator(dataEncryptor);
		encryptedDataGenerator.addMethod(new BcPublicKeyKeyEncryptionMethodGenerator(encKey));

		byte[] bytes = bOut.toByteArray();

		try  {
			OutputStream cOut = encryptedDataGenerator.open(out, bytes.length);
			cOut.write(bytes);
		} catch (Exception e) {
			throw new PGPException(e.getMessage());
		}
		
		
		
		out.close();
	}

	@SuppressWarnings("unchecked")
	public static void signEncryptFile(OutputStream out, String fileName, PGPPublicKey publicKey,
			PGPSecretKey secretKey, String password, boolean armor, boolean withIntegrityCheck)
			throws IOException, PGPException, SignatureException
	{

		// Initialize Bouncy Castle security provider
		Provider provider = new BouncyCastleProvider();
		Security.addProvider(provider);

		// Initialize literal data generator
		PGPLiteralDataGenerator literalDataGenerator = new PGPLiteralDataGenerator();

		if (armor) {
			out = new ArmoredOutputStream(out);
		}

		BcPGPDataEncryptorBuilder dataEncryptor = new BcPGPDataEncryptorBuilder(2);
		dataEncryptor.setWithIntegrityPacket(withIntegrityCheck);
		dataEncryptor.setSecureRandom(new SecureRandom());

		PGPEncryptedDataGenerator encryptedDataGenerator = new PGPEncryptedDataGenerator(dataEncryptor);
		encryptedDataGenerator.addMethod(new BcPublicKeyKeyEncryptionMethodGenerator(publicKey));

		// Initialize compressed data generator
		PGPCompressedDataGenerator compressedDataGenerator = new PGPCompressedDataGenerator(1);

		try  {
			OutputStream encryptedOut = encryptedDataGenerator.open(out, new byte[FirmUtils.BUFFER_SIZE]);
			OutputStream compressedOut = compressedDataGenerator.open(encryptedOut, new byte[FirmUtils.BUFFER_SIZE]);
			OutputStream literalOut = literalDataGenerator.open(compressedOut, PGPLiteralData.BINARY, fileName,
					new Date(), new byte[FirmUtils.BUFFER_SIZE]);
			FileInputStream in = new FileInputStream(fileName);
			// Initialize signature generator
			PGPPrivateKey privateKey = findPrivateKey(secretKey, password.toCharArray());

			if (secretKey == null) {
				throw new PGPException("the secret key must not be empty");
			}

			PGPContentSignerBuilder signerBuilder = new BcPGPContentSignerBuilder(
					secretKey.getPublicKey().getAlgorithm(), HashAlgorithmTags.SHA1);

			PGPSignatureGenerator signatureGenerator = new PGPSignatureGenerator(signerBuilder);
			signatureGenerator.init(PGPSignature.BINARY_DOCUMENT, privateKey);

			boolean firstTime = true;
			Iterator<String> it = secretKey.getPublicKey().getUserIDs();
			while (it.hasNext() && firstTime) {
				PGPSignatureSubpacketGenerator spGen = new PGPSignatureSubpacketGenerator();
				spGen.setSignerUserID(false, it.next());
				signatureGenerator.setHashedSubpackets(spGen.generate());
				// Exit the loop after the first iteration
				firstTime = false;
			}
			signatureGenerator.generateOnePassVersion(false).encode(compressedOut);

			// Main loop - read the "in" stream, compress, encrypt and write to the "out"
			// stream

			byte[] buf = new byte[FirmUtils.BUFFER_SIZE];
			int len;
			while ((len = in.read(buf)) > 0) {
				literalOut.write(buf, 0, len);
				signatureGenerator.update(buf, 0, len);
			}

			// Generate the signature, compress, encrypt and write to the "out" stream
			signatureGenerator.generate().encode(compressedOut);

		} catch (Exception e) {
			throw new PGPException("Error in signEncryptFile"+e.toString());
		} finally {
			if (armor) {
				out.close();
			}
			literalDataGenerator.close();
			compressedDataGenerator.close();
			encryptedDataGenerator.close();
		}

	}

	public static boolean verifyFile(InputStream in, InputStream keyIn, String extractContentFile)
			throws IOException, PGPException, SignatureException {
		in = PGPUtil.getDecoderStream(in);

		PGPObjectFactory pgpFact = new PGPObjectFactory(in);
		PGPCompressedData c1 = (PGPCompressedData) pgpFact.nextObject();

		pgpFact = new PGPObjectFactory(c1.getDataStream());

		PGPOnePassSignatureList p1 = (PGPOnePassSignatureList) pgpFact.nextObject();

		PGPOnePassSignature ops = p1.get(0);

		PGPLiteralData p2 = (PGPLiteralData) pgpFact.nextObject();

		InputStream dIn = p2.getInputStream();

		IOUtils.copy(dIn, new FileOutputStream(extractContentFile));

		int ch;
		PGPPublicKeyRingCollection pgpRing = new PGPPublicKeyRingCollection(PGPUtil.getDecoderStream(keyIn));

		PGPPublicKey key = pgpRing.getPublicKey(ops.getKeyID());

		FileOutputStream out = null;
		try  {
			out = new FileOutputStream(p2.getFileName());
			ops.init(new BcPGPContentVerifierBuilderProvider(), key);
			while ((ch = dIn.read()) >= 0) {
				ops.update((byte) ch);
				out.write(ch);
			}

		} catch (Exception e) {
			log.error("Error {}", e.getMessage());
		}finally {			
			if(out != null) {
				out.close();
			}
		}
		PGPSignatureList p3 = (PGPSignatureList) pgpFact.nextObject();
		return ops.verify(p3.get(0));
	}

	/**
	 * From LockBox Lobs PGP Encryption tools.
	 * http://www.lockboxlabs.org/content/downloads
	 *
	 * I didn't think it was worth having to import a 4meg lib for three methods
	 * 
	 * @param key
	 * @return
	 */
	public static boolean isForEncryption(PGPPublicKey key) {
		if (key.getAlgorithm() == PublicKeyAlgorithmTags.RSA_SIGN || key.getAlgorithm() == PublicKeyAlgorithmTags.DSA
				|| key.getAlgorithm() == PublicKeyAlgorithmTags.EC
				|| key.getAlgorithm() == PublicKeyAlgorithmTags.ECDSA) {
			return false;
		}

		return hasKeyFlags(key, KeyFlags.ENCRYPT_COMMS | KeyFlags.ENCRYPT_STORAGE);
	}

	/**
	 * From LockBox Lobs PGP Encryption tools.
	 * http://www.lockboxlabs.org/content/downloads
	 *
	 * I didn't think it was worth having to import a 4meg lib for three methods
	 * 
	 * @param key
	 * @return
	 */
	private static boolean hasKeyFlags(PGPPublicKey encKey, int keyUsage) {
		if (encKey.isMasterKey()) {
			return isMasterKey(encKey, keyUsage);
		} else {
			return isNotMasterKey(encKey, keyUsage);
		}
	}

	@SuppressWarnings("unchecked")
	public static boolean isMasterKey(PGPPublicKey encKey, int keyUsage) {
		boolean result = true;
		for (int i = 0; i != FirmUtils.MASTER_KEY_CERTIFICATION_TYPES.length; i++) {
			for (Iterator<PGPSignature> eIt = encKey
					.getSignaturesOfType(FirmUtils.MASTER_KEY_CERTIFICATION_TYPES[i]); eIt.hasNext();) {
				PGPSignature sig = eIt.next();
				if (!isMatchingUsage(sig, keyUsage)) {
					result = false;
					break;
				}
			}
		}

		return result;
	}

	@SuppressWarnings("unchecked")
	public static boolean isNotMasterKey(PGPPublicKey encKey, int keyUsage) {
		boolean result = true;
		for (Iterator<PGPSignature> eIt = encKey.getSignaturesOfType(PGPSignature.SUBKEY_BINDING); eIt.hasNext();) {
			PGPSignature sig = eIt.next();
			if (!isMatchingUsage(sig, keyUsage)) {
				result = false;
				break;
			}
		}
		return result;
	}

	/**
	 * From LockBox Lobs PGP Encryption tools.
	 * http://www.lockboxlabs.org/content/downloads
	 *
	 * I didn't think it was worth having to import a 4meg lib for three methods
	 * 
	 * @param key
	 * @return
	 */
	private static boolean isMatchingUsage(PGPSignature sig, int keyUsage) {
		if (sig.hasSubpackets()) {
			PGPSignatureSubpacketVector sv = sig.getHashedSubPackets();
			if (sv.hasSubpacket(FirmUtils.KEY_FLAGS) && (sv.getKeyFlags() == 0 && keyUsage == 0)) {
				return false;
			}
		}
		return true;
	}

}