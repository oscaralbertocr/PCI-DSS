package co.com.ath.pgw.batch;


import javax.annotation.PostConstruct;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.batch.core.configuration.annotation.StepScope;
import org.springframework.batch.item.file.FlatFileItemReader;
import org.springframework.batch.item.file.mapping.BeanWrapperFieldSetMapper;
import org.springframework.batch.item.file.mapping.DefaultLineMapper;
import org.springframework.batch.item.file.transform.FixedLengthTokenizer;
import org.springframework.batch.item.file.transform.Range;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import co.com.ath.pgw.dto.FileLineComision;
/**
 * Reader del batch de destokenizacion
 *
 * @author Jesus Octavio Avenda�o Sierra <jesus.avendano@sophossolutions.com> 
 * @version 1.0 16/15/2019
 * 
 * @sophosSolutions
 * <strong>Autor: </strong>Jesus Octavio Avenda�o Sierra</br>
 * <strong>Numero de Cambios: </strong>0</br>
 * 	
 */
@Service
@StepScope
public class FileLineReaderComision extends FlatFileItemReader<FileLineComision>{

	static Logger LOGGER = LoggerFactory.getLogger(FileLineReaderComision.class);

	@Value("#{jobParameters[fileName]}")
	private String fileName;

	@Value("#{jobParameters[fileType]}")
	private String fileType;

	@Value("#{jobParameters[pathDownloadComision1]}")
	private String pathDownload1;

	@Value("#{jobParameters[pathDownloadComision2]}")
	private String pathDownload2;

	/**
	 * Inicia la lectura por linea.
	 *
	 * @author Jesus Octavio Avenda�o Sierra <jesus.avendano@sophossolutions.com> 
	 * @version 1.0 16/15/2019
	 */
	@PostConstruct
	public void init() { 
		this.setName("FileLineReader");
		this.setEncoding("utf8");
		this.setLineMapper(this.lineMapper());
	}

	private DefaultLineMapper<FileLineComision> lineMapper(){
		DefaultLineMapper<FileLineComision> defaultLineMapper = new DefaultLineMapper<FileLineComision>();
		defaultLineMapper.setFieldSetMapper(this.beanWrapperFieldSetMapper());
		LOGGER.info("Configurando orden de columnas en la linea");
		defaultLineMapper.setLineTokenizer(this.tokenizerComisiones());
		LOGGER.info("Configuracion de orden de columnas en la linea Terminada");
		return defaultLineMapper;
	}

	private BeanWrapperFieldSetMapper<FileLineComision> beanWrapperFieldSetMapper() {
		BeanWrapperFieldSetMapper<FileLineComision> beanWrapperFieldSetMapper = new  BeanWrapperFieldSetMapper<FileLineComision>();
		beanWrapperFieldSetMapper.setTargetType(FileLineComision.class);
		return beanWrapperFieldSetMapper;
	}

	/**
	 * Tokenizer para recaudos.
	 *
	 * @author Jesus Octavio Avenda�o Sierra <jesus.avendano@sophossolutions.com> 
	 * @version 1.0 16/15/2019
	 */
	private FixedLengthTokenizer tokenizerComisiones() {
		LOGGER.info("Tokenizando linea para Recaudos");
		FixedLengthTokenizer fixedLengthTokenizer = new FixedLengthTokenizer();
		String[] names = {
				"flag",
				"countTx",
				"aproFailTx"
		};

		Range[] ranges = {
				new Range(1,2),
				new Range(3,12),
				new Range(13)
		};

		fixedLengthTokenizer.setNames(names);
		fixedLengthTokenizer.setColumns(ranges);
		return fixedLengthTokenizer;
	}
	
}