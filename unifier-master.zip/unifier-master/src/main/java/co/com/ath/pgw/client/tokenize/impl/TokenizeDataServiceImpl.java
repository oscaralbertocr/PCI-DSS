/*
 * TokenizeDataService
 *  
 * GSI - Core Pasarela
 * Creado el: 09/08/2017
 *
 * Copyright (c) A Toda Hora S.A. Todos los derechos reservados
 * 
 * Este software es confidencial y es propiedad de ATH, queda prohibido
 * su uso, reproducción y copia de manera parcial o permanente salvo autorización
 * expresa de A Toda Hora S.A o de quién represente sus derechos.
 */
package co.com.ath.pgw.client.tokenize.impl;

import java.net.MalformedURLException;
import java.net.URL;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import co.com.ath.pgw.client.tokenize.dto.TokenizedDataRqType;
import co.com.ath.pgw.client.tokenize.dto.TokenizedDataRsType;
import co.com.ath.pgw.dto.TokenizeInDTO;
import co.com.ath.pgw.dto.TokenizeOutDTO;
import co.com.ath.pgw.util.EncryptUtil;
import co.com.ath.pgw.util.PaymentsObjectsConverter;

/**
 * 
 * @author proveedor_lbonilla
 * @version 1.0
 * 
 * @IM692234 <strong>Autor</strong> Silverio Armando Bonilla Celis</br>
 *       	<strong>Descripcion</strong> Ajuste cifrado tokenización
 *          TC</br>
 *          <strong>Numero de Cambios</strong> 2</br>
 *          <strong>Identificador corto</strong> C01</br>
 */
@Service
public class TokenizeDataServiceImpl implements TokenizeDataService {

	static Logger LOGGER = LoggerFactory.getLogger(TokenizeDataServiceImpl.class);

	@Value("${pasarela.ws.tokenize.wsdl}")
	private String urlEndPoint;

	@Value("${pasarela.ws.tokenize.key}")
	private String key;

	@Value("${pasarela.ws.tokenize.iv}")
	private String iv;

	@Value("${pasarela.ws.tokenize.attempts}")
	private int attempts;

	private TokenizedDataAdmSvc tokenizedDataAdmSvc;

	@Override
	public TokenizeOutDTO getTokenize(TokenizeInDTO tokenizeInDTO) {
		LOGGER.info("Cantidad de intentos configurados: " + attempts);
		int currentAttemp = 0;
		TokenizeOutDTO tokenizeOutDTO= null;
		while(currentAttemp<this.attempts && tokenizeOutDTO==null) {
			currentAttemp=currentAttemp+1;
			LOGGER.info("Intentando detokenizar "+currentAttemp);
			tokenizeOutDTO = detokenize(tokenizeInDTO, currentAttemp);
		}
		return tokenizeOutDTO;
	}

	private TokenizeOutDTO detokenize(TokenizeInDTO tokenizeInDTO, int currentAttemp) {
		TokenizedDataRqType addTokenizedData = null;
		TokenizeOutDTO tokenizeOutDTO = null;
		try {
			tokenizedDataAdmSvc = new TokenizedDataAdmSvc(new URL(urlEndPoint.trim()));
			/** INICIO-C01 **/
			addTokenizedData = PaymentsObjectsConverter.toTokenizedDataRqType(tokenizeInDTO);
			addTokenizedData.getTokenizedDataInfoRq().getAuth().setInfo(EncryptUtil.decrypt(key, iv, addTokenizedData.getTokenizedDataInfoRq().getAuth().getInfo()));
			/** FIN-C01 **/
			//LOGGER.info("Iniciando getTokenize cliente Tokenizacion: \n{}", addTokenizedData);
			TokenizedDataRsType tokenizedDataRsType = tokenizedDataAdmSvc.getTokenizedDataAdmPort().getTokenizedData(addTokenizedData);
			//LOGGER.info("Respuesta getTokenize cliente Tokenizacion: \n{}", tokenizedDataRsType);
			tokenizeOutDTO = PaymentsObjectsConverter.toTokenizeOutDTO(tokenizedDataRsType);
		} catch (MalformedURLException e) {
			LOGGER.error("Can not initialize wsdl " + urlEndPoint);
		} catch (Exception e) {
			if(currentAttemp<attempts){
				tokenizeOutDTO = null;
			}
			LOGGER.error("Error desencriptando el campo info");	
			e.printStackTrace();	
		}
		return tokenizeOutDTO;
	}

}
