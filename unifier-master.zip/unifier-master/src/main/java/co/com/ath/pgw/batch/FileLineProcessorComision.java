package co.com.ath.pgw.batch;

import java.math.BigDecimal;

import javax.annotation.Resource;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.batch.core.ExitStatus;
import org.springframework.batch.core.JobExecution;
import org.springframework.batch.core.StepExecution;
import org.springframework.batch.core.StepExecutionListener;
import org.springframework.batch.core.configuration.annotation.StepScope;
import org.springframework.batch.item.ExecutionContext;
import org.springframework.batch.item.ItemProcessor;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import co.com.ath.pgw.client.tokenize.impl.TokenizeDataService;
import co.com.ath.pgw.dto.AuthBO;
import co.com.ath.pgw.dto.FileLineComision;
import co.com.ath.pgw.dto.ProtectBO;
import co.com.ath.pgw.dto.TokenizeDataInfoBO;
import co.com.ath.pgw.dto.TokenizeInDTO;
import co.com.ath.pgw.dto.TokenizeOutDTO;

/**
 * Processor del batch de destokenizacion
 *
 * @author Jesus Octavio Avendaño Sierra <jesus.avendano@sophossolutions.com> 
 * @version 1.0 16/15/2019
 *
 * @sophosSolutions
 * <strong>Autor: </strong>Jesus Octavio Avendaño Sierra</br>
 * <strong>Numero de Cambios: </strong>0</br>
 *
 */

@Service
@StepScope
public class FileLineProcessorComision implements ItemProcessor<FileLineComision, FileLineComision>, StepExecutionListener {

	@Value("#{jobParameters[fileType]}")
	private String fileType;

	@Value("#{jobParameters[unifierFlag]}")
	private String unifierFlag;

	@Value("#{jobParameters[razonSocial]}")
	private String razonSocial;

	@Value("${tokenize.info}")
	private String info;

	@Value("${tokenize.method}")
	private String method;

	@Value("${tokenize.idSecKey}")
	private String idSecKey;

	@Value("${tokenize.format}")
	private String formatVoltage;

	@Value("${tokenize.strRefine}")
	private String strRefine;

	@Resource
	TokenizeDataService tokenizeDataService;

	private ExecutionContext executionContext;

	static Logger LOGGER = LoggerFactory.getLogger(FileLineProcessorComision.class);

	/**
	 * Proceso que se ejecuta para cada linea.
	 * @param fileLine
	 * 			Linea leida.		
	 * @author Jesus Octavio Avendaño Sierra <jesus.avendano@sophossolutions.com> 
	 * @version 1.0 16/15/2019
	 */
	@Override
	public FileLineComision process(FileLineComision fileLine) throws Exception {
		String token = "";
		String detoken = "";
		if(this.unifierFlag.equals("0")) {
			if(fileLine.getLine().trim().length()==31) {//cabecera
				if(!this.executionContext.containsKey("header")) {
					this.executionContext.put("header", fileLine.getLine());
				}else {
					return null;
				}
			}else if(fileLine.getLine().trim().length()==52) {//footer
				if(!this.executionContext.containsKey("footer")) {
					this.executionContext.put("footer", fileLine.getLine());
					this.executionContext.put("countTx",  Integer.parseInt(fileLine.getCountTx()));
					this.executionContext.put("aproTx",Double.parseDouble(fileLine.getAproFailTx().substring(0, 20)));
					this.executionContext.put("failTx", Double.parseDouble(fileLine.getAproFailTx().substring(20, 40)));
					return null;
				}else {
					double apro = Double.parseDouble(fileLine.getAproFailTx().substring(0, 20));
					double fail = Double.parseDouble(fileLine.getAproFailTx().substring(20, 40));
					BigDecimal aproBD =BigDecimal.valueOf(this.executionContext.getDouble("aproTx") +apro);
					BigDecimal failBD =BigDecimal.valueOf(this.executionContext.getDouble("failTx") +fail);
					aproBD=aproBD.setScale(2);
					failBD=failBD.setScale(2);
					fileLine.setCountTx(generateSpaces(String.valueOf(this.executionContext.getInt("countTx")+Integer.parseInt(fileLine.getCountTx())),10,false));
					fileLine.setAproFailTx(generateSpaces(aproBD.toString(),20,false)
							.concat(generateSpaces(failBD.toString(),20,false)));
				}
			}else if((fileLine.getLine().length()>172) && (fileLine.getLine().startsWith("*") || fileLine.getLine().startsWith("+"))) {
				if(fileLine.getLine().startsWith("*")) {
					token = fileLine.getLine().substring(156, 172);
					detoken = this.detokenization(token.trim().replace("0", ""));
					detoken = StringUtils.leftPad(detoken, 16, "0");
					fileLine.setAproFailTx(fileLine.getAproFailTx().replace(token, detoken));	
				}	
				fileLine.setFlag(fileLine.getFlag().replaceAll("[*+]", ""));
			}
		}else if(((this.unifierFlag.equals("1")||this.unifierFlag.equals("2")) && (fileLine.getLine().length()>172)) && (fileLine.getLine().startsWith("*") || fileLine.getLine().startsWith("+"))) {
			if(fileLine.getLine().startsWith("*")) {
				token = fileLine.getLine().substring(156, 172);	
				detoken = this.detokenization(token.trim().replace("0", ""));
				detoken = StringUtils.leftPad(detoken, 16, "0");
				fileLine.setAproFailTx(fileLine.getAproFailTx().replace(token, detoken));	
			}	
			fileLine.setFlag(fileLine.getFlag().replaceAll("[*+]", ""));
		}
		return fileLine;
	}

	private String detokenization(String token) throws Exception {
		String detoken = null;
		try {
			TokenizeInDTO tokenizeInDTO = new TokenizeInDTO();
			TokenizeDataInfoBO tokenizeDataInfoBO = new TokenizeDataInfoBO();

			tokenizeInDTO.setRqUID(Long.parseLong("1580580339280"));
			tokenizeInDTO.setChannel("5");
			tokenizeInDTO.setIpAddr("1.1.1.1");

			AuthBO authBO = new AuthBO();
			authBO.setInfo(this.info.trim());
			authBO.setMethod(this.method.trim());
			tokenizeDataInfoBO.setAuth(authBO);

			tokenizeDataInfoBO.setIdSecKey(this.idSecKey.trim());

			ProtectBO protectBO = new ProtectBO();
			protectBO.setData(token);
			protectBO.setFormat(this.formatVoltage.trim());
			protectBO.setStrRefine(this.strRefine.trim());
			tokenizeDataInfoBO.setProtect(protectBO);

			tokenizeInDTO.setTokenizeDataInfoBO(tokenizeDataInfoBO);
			TokenizeOutDTO tokenizeOutDTO = tokenizeDataService.getTokenize(tokenizeInDTO);
			detoken = tokenizeOutDTO.getTokenizeDataInfoBO().getProtect().getData();
		} catch (Exception e) {
			throw new Exception(e.getMessage());
		}
		return detoken;
	}

	@Override
	public void beforeStep(StepExecution stepExecution) {
		JobExecution jobExecution = stepExecution.getJobExecution(); 
		this.executionContext = jobExecution.getExecutionContext();
	}

	@Override
	public ExitStatus afterStep(StepExecution stepExecution) {
		return null;
	}


	/**
	 * Genera la cantidad de espacios necesarios para
	 * cumplir con el estandar definido por la documentacion de los reportes.
	 *
	 * @param firstChar
	 * 			caracter de inicio de linea
	 * 
	 * @param beforeToken
	 * 			String que esta antes del token
	 * 
	 * @param token
	 * 			token
	 * 
	 * @param afterToken
	 * 			String que esta despues del token
	 * 
	 * @author Jesus Octavio Avendaño Sierra <jesus.avendano@sophossolutions.com> 
	 * @version 1.0 16/15/2019
	 */
	private String generateSpaces(String value, int size, boolean point) {
		if(point) {
			value = value.concat(".00");			
		}
		StringBuilder allLine = new StringBuilder( value );
		StringBuilder spaces = new StringBuilder();
		int count = size - allLine.length();
		for (int i = 0; i < count; i++) {
			spaces.append("0");
		}
		return spaces.toString().concat(value);
	}

}