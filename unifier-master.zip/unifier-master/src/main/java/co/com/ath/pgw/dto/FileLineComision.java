package co.com.ath.pgw.dto;

/**
 * DTO Fileline
 *
 * @author Jesus Octavio Avendaño Sierra <jesus.avendano@sophossolutions.com> 
 * @version 1.0 16/15/2019
 * 
 * @sophosSolutions
 * <strong>Autor: </strong>Jesus Octavio Avendaño Sierra</br>
 * <strong>Numero de Cambios: </strong>0</br>
 * 	
*/

public class FileLineComision {
	
	private String flag;
	private String countTx;
	private String aproFailTx;
	
	public FileLineComision() {
	}
	
	public String getFlag() {
		return flag;
	}
	public void setFlag(String flag) {
		this.flag = flag;
	}
	public String getCountTx() {
		return countTx;
	}
	public void setCountTx(String countTx) {
		this.countTx = countTx;
	}
	public String getAproFailTx() {
		return aproFailTx;
	}
	public void setAproFailTx(String aproFailTx) {
		this.aproFailTx = aproFailTx;
	}

	public String getLine() {
		return this.getFlag()+ this.getCountTx()+ this.getAproFailTx();
	}
	
	
}
