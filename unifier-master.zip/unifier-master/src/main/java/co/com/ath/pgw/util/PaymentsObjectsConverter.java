package co.com.ath.pgw.util;

import java.util.Calendar;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import co.com.ath.pgw.client.tokenize.dto.TokenizedDataInfoRqType;
import co.com.ath.pgw.client.tokenize.dto.TokenizedDataRqType;
import co.com.ath.pgw.client.tokenize.dto.TokenizedDataRsType;
import co.com.ath.pgw.dto.ProtectBO;
import co.com.ath.pgw.dto.StatusBO;
import co.com.ath.pgw.dto.TokenizeDataInfoBO;
import co.com.ath.pgw.dto.TokenizeInDTO;
import co.com.ath.pgw.dto.TokenizeOutDTO;

public class PaymentsObjectsConverter {
	
	static Logger LOGGER = LoggerFactory.getLogger(PaymentsObjectsConverter.class);
	
	private static final String BANK_PPA = "CorePasarela";
	private static final String BANK_PPA_ID = "901";
	
	/**
	 * 
	 * @param transactionAddRq
	 */
	public static TokenizedDataRqType toTokenizedDataRqType(TokenizeInDTO inDTO) {
		TokenizedDataRqType tokenizedDataRqType = new TokenizedDataRqType();
		tokenizedDataRqType.setChannel(inDTO.getChannel());
		
		tokenizedDataRqType.setClientDt(DateUtil.toXMLGregorianCalendar(Calendar.getInstance().getTime()));
		tokenizedDataRqType.setIPAddr(inDTO.getIpAddr());
		tokenizedDataRqType.setRqUID(inDTO.getRqUID());
		tokenizedDataRqType.setChannel(inDTO.getChannel());
		
		co.com.ath.pgw.client.tokenize.dto.BankInfoType bank = new co.com.ath.pgw.client.tokenize.dto.BankInfoType();
		bank.setName(BANK_PPA);
		bank.setBankId(BANK_PPA_ID);
		
		tokenizedDataRqType.setBankInfo(bank);
		
		TokenizedDataInfoRqType tokenizedDataInfoRqType = new TokenizedDataInfoRqType();
		
		co.com.ath.pgw.client.tokenize.dto.AuthType authType = new co.com.ath.pgw.client.tokenize.dto.AuthType();
		authType.setInfo(inDTO.getTokenizeDataInfoBO().getAuth().getInfo());
		authType.setMethod(inDTO.getTokenizeDataInfoBO().getAuth().getMethod());
		
		tokenizedDataInfoRqType.setAuth(authType);
		tokenizedDataInfoRqType.setIdSecKey(inDTO.getTokenizeDataInfoBO().getIdSecKey());
		
		co.com.ath.pgw.client.tokenize.dto.ProtectType ProtectType = new co.com.ath.pgw.client.tokenize.dto.ProtectType();
		ProtectType.setData(inDTO.getTokenizeDataInfoBO().getProtect().getData());
		ProtectType.setFormat(inDTO.getTokenizeDataInfoBO().getProtect().getFormat());
		
		if(inDTO.getTokenizeDataInfoBO().getProtect().getStrRefine() != null && !inDTO.getTokenizeDataInfoBO().getProtect().getStrRefine().isEmpty())
			ProtectType.setStrRefine(inDTO.getTokenizeDataInfoBO().getProtect().getStrRefine());
		
		tokenizedDataInfoRqType.setProtect(ProtectType);
		tokenizedDataRqType.setTokenizedDataInfoRq(tokenizedDataInfoRqType);
		
		co.com.ath.pgw.client.tokenize.dto.UserIdType userIdType = new co.com.ath.pgw.client.tokenize.dto.UserIdType();
		userIdType.setCustIdNum(inDTO.getUserBO() == null ? "0" : inDTO.getUserBO().getCustIdNum());
		userIdType.setCustIdType(inDTO.getUserBO() == null ? "CC" : inDTO.getUserBO().getCustIdType());
		userIdType.setCustLoginId(inDTO.getUserBO() == null ? "0" : inDTO.getUserBO().getCustLoginId());
		
		tokenizedDataRqType.setUserId(userIdType);
		
		return tokenizedDataRqType;
	}
	
	/**
	 * 
	 * @param tokenizedDataRsType
	 * @return
	 */
	public static TokenizeOutDTO toTokenizeOutDTO(TokenizedDataRsType tokenizedDataRsType) {
		TokenizeOutDTO tokenizeOutDTO = new TokenizeOutDTO();
		
		tokenizeOutDTO.setRqUID(tokenizedDataRsType.getRqUID());
		StatusBO statusBO = new StatusBO();
		statusBO.setServerStatusCode(tokenizedDataRsType.getStatus().getServerStatusCode());
		statusBO.setServerStatusDesc(tokenizedDataRsType.getStatus().getServerStatusDesc());
		statusBO.setSeverity(tokenizedDataRsType.getStatus().getSeverity().toString());
		statusBO.setStatusCode(tokenizedDataRsType.getStatus().getStatusCode());
		statusBO.setStatusDesc(tokenizedDataRsType.getStatus().getStatusDesc());
		
		tokenizeOutDTO.setStatusBO(statusBO);
		
		if(tokenizedDataRsType.getTokenizedDataInfoRs() !=null){
			TokenizeDataInfoBO tokenizeDataInfoBO = new TokenizeDataInfoBO();
			ProtectBO protect = new ProtectBO();
			protect.setData(tokenizedDataRsType.getTokenizedDataInfoRs().getProtect().getData());
			protect.setFormat(tokenizedDataRsType.getTokenizedDataInfoRs().getProtect().getFormat());
			protect.setStrRefine(tokenizedDataRsType.getTokenizedDataInfoRs().getProtect().getStrRefine());
			tokenizeDataInfoBO.setProtect(protect);
			tokenizeOutDTO.setTokenizeDataInfoBO(tokenizeDataInfoBO);
		}
		
		return tokenizeOutDTO;
	}
	
}