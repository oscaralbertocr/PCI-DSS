
package co.com.ath.pgw.client.tokenize.dto;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlType;

import co.com.ath.pgw.util.XMLUtil;


/**
 * <p>Clase Java para TokenizedDataRq_Type complex type.
 * 
 * <p>El siguiente fragmento de esquema especifica el contenido que se espera que haya en esta clase.
 * 
 * <pre>
 * &lt;complexType name="TokenizedDataRq_Type"&gt;
 *   &lt;complexContent&gt;
 *     &lt;extension base="{urn://ath.com.co/xsd/common/}SvcRq_Type"&gt;
 *     &lt;/extension&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "TokenizedDataRq_Type", namespace = "urn://ath.com.co/support/v1/")
public class TokenizedDataRqType
    extends SvcRqType
{

    @Override
	public String toString() {
		XMLUtil<TokenizedDataRqType> requestParser = new XMLUtil<TokenizedDataRqType>();
		return requestParser.convertObjectToXml(this);
	}

}
