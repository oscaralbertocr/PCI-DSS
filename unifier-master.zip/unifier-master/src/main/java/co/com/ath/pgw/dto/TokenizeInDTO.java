/*
 * AddRBMPaymentInDTO
 *  
 * GSI - Integración
 * Creado el: 20/09/2014
 *
 * Copyright (c) A Toda Hora S.A. Todos los derechos reservados
 * 
 * Este software es confidencial y es propietario de ATH, queda prohibido
 * su uso, reproducción y copia de manera parcial o permanente salvo autorización
 * expresa de A Toda Hora S.A o de quién represente sus derechos.
 */
package co.com.ath.pgw.dto;

import co.com.ath.pgw.util.XMLUtil;

/**
 * DTO de entrada con la información para la operación addTokenizeData y getTokenizeData
 *
 * @version 0.0.0 22/09/2014
 * @author Andrés Méndez Juanias <proveedor_mamendez@ath.com.co>
 */

public class TokenizeInDTO extends CommonObjectInDTO {

	
	public TokenizeInDTO(){

	}
	
	/**
	 * 
	 */
	private UserBO userBO;
	
	/**
	 * 
	 */
	private BankBO bankBO;
	
	/**
	 * 
	 */
	private String channel;
	
	
	/**
	 * 
	 */
	private TokenizeDataInfoBO tokenizeDataInfoBO;
	
	
	public String getChannel() {
		return channel;
	}


	public void setChannel(String channel) {
		this.channel = channel;
	}


	public UserBO getUserBO() {
		return userBO;
	}


	public void setUserBO(UserBO userBO) {
		this.userBO = userBO;
	}
	
	@Override
	public String toString() {
		XMLUtil<TokenizeInDTO> requestParser = new XMLUtil<TokenizeInDTO>();
		return requestParser.convertObjectToXml(this);
	}


	public BankBO getBankBO() {
		return bankBO;
	}


	public void setBankBO(BankBO bankBO) {
		this.bankBO = bankBO;
	}


	public TokenizeDataInfoBO getTokenizeDataInfoBO() {
		return tokenizeDataInfoBO;
	}


	public void setTokenizeDataInfoBO(TokenizeDataInfoBO tokenizeDataInfoBO) {
		this.tokenizeDataInfoBO = tokenizeDataInfoBO;
	}

    
}