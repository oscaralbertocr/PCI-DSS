/*
 * AddRBMPaymentOutDTO
 *  
 * GSI - Integración
 * Creado el: 20/09/2014
 *
 * Copyright (c) A Toda Hora S.A. Todos los derechos reservados
 * 
 * Este software es confidencial y es propietario de ATH, queda prohibido
 * su uso, reproducción y copia de manera parcial o permanente salvo autorización
 * expresa de A Toda Hora S.A o de quién represente sus derechos.
 */
package co.com.ath.pgw.dto;

import co.com.ath.pgw.util.XMLUtil;


/**
 * DTO con la información de respuesta de la operación AddRBMPayment.
 *
 * @version 0.0.0 22/09/2014
 * @author Andrés Méndez Juanias <proveedor_mamendez@ath.com.co>
 */

public class TokenizeOutDTO extends CommonObjectOutDTO {

    
    
	public TokenizeOutDTO(){

	}
	
	private StatusBO statusBO;
	
	
	/**
	 * 
	 */
	private TokenizeDataInfoBO tokenizeDataInfoBO;

	@Override
	public String toString() {
		XMLUtil<TokenizeOutDTO> requestParser = new XMLUtil<TokenizeOutDTO>();
		return requestParser.convertObjectToXml(this);
	}

	public TokenizeDataInfoBO getTokenizeDataInfoBO() {
		return tokenizeDataInfoBO;
	}

	public void setTokenizeDataInfoBO(TokenizeDataInfoBO tokenizeDataInfoBO) {
		this.tokenizeDataInfoBO = tokenizeDataInfoBO;
	}

	public StatusBO getStatusBO() {
		return statusBO;
	}

	public void setStatusBO(StatusBO statusBO) {
		this.statusBO = statusBO;
	}

}