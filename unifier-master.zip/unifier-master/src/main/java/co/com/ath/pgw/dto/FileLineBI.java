package co.com.ath.pgw.dto;

/**
 * DTO Fileline
 *
 * @author Jesus Octavio Avendaño Sierra <jesus.avendano@sophossolutions.com> 
 * @version 1.0 16/15/2019
 * 
 * @sophosSolutions
 * <strong>Autor: </strong>Jesus Octavio Avendaño Sierra</br>
 * <strong>Numero de Cambios: </strong>0</br>
 * 	
*/

public class FileLineBI{
	
	private String partA;
	private String partB;
	

	public String getPartA() {
		return partA;
	}


	public void setPartA(String partA) {
		this.partA = partA;
	}


	public String getPartB() {
		return partB;
	}


	public void setPartB(String partB) {
		this.partB = partB;
	}


	public String getLine() {
		return this.getPartA()+ this.getPartB();
	}
	
	
}
