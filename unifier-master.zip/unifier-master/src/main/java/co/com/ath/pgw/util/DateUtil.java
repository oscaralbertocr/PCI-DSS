package co.com.ath.pgw.util;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.GregorianCalendar;

import javax.xml.datatype.DatatypeConfigurationException;
import javax.xml.datatype.DatatypeFactory;
import javax.xml.datatype.XMLGregorianCalendar;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;


/**
 * Utilidades de conversión para fechas
 * @author proveedor_cjmurillo
 * @version 1.0
 * @since 1.0
 */
public class DateUtil {

	static Logger LOGGER = LoggerFactory.getLogger(DateUtil.class);
	
	/**
	 * Convierte de Date a XMLGregorianCalendar
	 * @param inn
	 * @return
	 */
    public static XMLGregorianCalendar toXMLGregorianCalendar(Date inn){
    	if(inn == null) { return null; }
        GregorianCalendar gCalendar = new GregorianCalendar();
        gCalendar.setTime(inn);
        XMLGregorianCalendar xmlCalendar = null;
        try {
            xmlCalendar = DatatypeFactory.newInstance().newXMLGregorianCalendar(gCalendar);
        } catch (DatatypeConfigurationException ex) {
            LOGGER.error("Error conviertiendo valores.",ex);
        }
        return xmlCalendar;
    }
  
   
    /**
     * Convierte de XMLGregorianCalendar a Date
     * @param inn
     * @return
     */
    public static Date toDate(XMLGregorianCalendar inn){
        if(inn == null) { return null; }
        return inn.toGregorianCalendar().getTime();
    }
    
	/**
	 * Retorna la fecha en el formato dado.
	 * 
	 * @param date
	 * @param format
	 * @return
	 */
	public static String parseDate(Date date, String format) {
		
		String returnDate;
		try {
			SimpleDateFormat simpleDateFormat = new SimpleDateFormat(format);
			returnDate = simpleDateFormat.format(date);
		} catch (Exception e) {
			LOGGER.error("No fue posible formatear la fecha: {},  formato:{}", date != null ? date.toString() : "null", format, e);
			return null;
		}

		return returnDate;
	}
	
	public static Date parseString(String date, String format) {
		Date returnDate;
		try {
			SimpleDateFormat simpleDateFormat = new SimpleDateFormat(format);
			returnDate = simpleDateFormat.parse(date);
		} catch (Exception e) {
			LOGGER.error("No fue posible formatear la fecha: {},  formato:{}", date != null ? date.toString() : "null", format, e);
			return null;
		}
		return returnDate;
	}
	
}
