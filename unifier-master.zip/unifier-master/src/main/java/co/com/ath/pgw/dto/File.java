package co.com.ath.pgw.dto;

import java.io.Serializable;

import javax.xml.datatype.XMLGregorianCalendar;

import com.fasterxml.jackson.annotation.JsonProperty;

/**
 * DTO Fileline
 *
 * @author Jesus Octavio Avendaño Sierra <jesus.avendano@sophossolutions.com> 
 * @version 1.0 16/15/2019
 * 
 * @sophosSolutions
 * <strong>Autor: </strong>Jesus Octavio Avendaño Sierra</br>
 * <strong>Numero de Cambios: </strong>0</br>
 * 	
*/
public class File implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	@JsonProperty("FileId")
	private String fileId;
	
	@JsonProperty("FileType")
	private String fileType;
	
	@JsonProperty("FileName")
	private String fileName;
	
	@JsonProperty("FileDesc")
	private String fileDesc;

	@JsonProperty("SPName")
	private String spName;

	@JsonProperty("FileStatus")
	private String fileStatus;

	@JsonProperty("FileRqDt")
	private XMLGregorianCalendar fileRqDt;
	
	/**
    *
    *@return el getFileId
    */
	public String getFileId() {
		return fileId;
	}

	/**
	 *	@param firstChar
	 *				Establese el getFileId
	 *
	 */
	public void setFileId(String fileId) {
		this.fileId = fileId;
	}

	/**
    *
    *@return el FileType
    */
	public String getFileType() {
		return fileType;
	}


	/**
	 *	@param firstChar
	 *				Establese el FileType
	 *
	 */
	public void setFileType(String fileType) {
		this.fileType = fileType;
	}

	/**
    *
    *@return el FileName
    */
	public String getFileName() {
		return fileName;
	}


	/**
	 *	@param firstChar
	 *				Establese el FileName
	 *
	 */
	public void setFileName(String fileName) {
		this.fileName = fileName;
	}

	/**
    *
    *@return el FileDesc
    */
	public String getFileDesc() {
		return fileDesc;
	}


	/**
	 *	@param firstChar
	 *				Establese el FileDesc
	 *
	 */
	public void setFileDesc(String fileDesc) {
		this.fileDesc = fileDesc;
	}

	/**
    *
    *@return el SPName
    */
	public String getSPName() {
		return spName;
	}


	/**
	 *	@param firstChar
	 *				Establese el SPName
	 *
	 */
	public void setSPName(String sPName) {
		spName = sPName;
	}

	/**
    *
    *@return el FileStatus
    */
	public String getFileStatus() {
		return fileStatus;
	}


	/**
	 *	@param firstChar
	 *				Establese el FileStatus
	 *
	 */
	public void setFileStatus(String fileStatus) {
		this.fileStatus = fileStatus;
	}

	/**
    *
    *@return el FileRqDt
    */
	public XMLGregorianCalendar getFileRqDt() {
		return fileRqDt;
	}


	/**
	 *	@param firstChar
	 *				Establese el FileRqDt
	 *
	 */
	public void setFileRqDt(XMLGregorianCalendar fileRqDt) {
		this.fileRqDt = fileRqDt;
	}

}