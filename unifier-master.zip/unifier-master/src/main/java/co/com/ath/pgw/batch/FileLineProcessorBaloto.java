package co.com.ath.pgw.batch;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.batch.core.ExitStatus;
import org.springframework.batch.core.JobExecution;
import org.springframework.batch.core.StepExecution;
import org.springframework.batch.core.StepExecutionListener;
import org.springframework.batch.core.configuration.annotation.StepScope;
import org.springframework.batch.item.ExecutionContext;
import org.springframework.batch.item.ItemProcessor;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import co.com.ath.pgw.dto.FileLineBaloto;

/**
 * Processor del batch de destokenizacion
 *
 * @author Jesus Octavio Avenda�o Sierra <jesus.avendano@sophossolutions.com> 
 * @version 1.0 16/15/2019
 *
 * @sophosSolutions
 * <strong>Autor: </strong>Jesus Octavio Avenda�o Sierra</br>
 * <strong>Numero de Cambios: </strong>0</br>
 *
 */

@Service
@StepScope
public class FileLineProcessorBaloto implements ItemProcessor<FileLineBaloto, FileLineBaloto>, StepExecutionListener {
	
	@Value("#{jobParameters[fileType]}")
	private String fileType;
	
	@Value("#{jobParameters[unifierFlag]}")
	private String unifierFlag;
	
	@Value("#{jobParameters[razonSocial]}")
	private String razonSocial;
	
	private ExecutionContext executionContext;
	
	static Logger LOGGER = LoggerFactory.getLogger(FileLineProcessorBaloto.class);

	/**
	 * Proceso que se ejecuta para cada linea.
	 * @param fileLine
	 * 			Linea leida.		
	 * @author Jesus Octavio Avenda�o Sierra <jesus.avendano@sophossolutions.com> 
	 * @version 1.0 16/15/2019
	 */
	@Override
	public FileLineBaloto process(FileLineBaloto fileLine) throws Exception {
		if(this.unifierFlag.equals("0")) {
			if(fileLine.getLine().trim().startsWith(this.razonSocial)) {//cabecera
				if(!this.executionContext.containsKey("header")) {
					this.executionContext.put("header", fileLine.getLine());
				}else {
					return null;
				}
			}else if(fileLine.getLine().trim().endsWith("||")) {//footer
				if(!this.executionContext.containsKey("footer")) {
					this.executionContext.put("footer", fileLine.getLine());
					this.executionContext.put("partA",  Long.parseLong(fileLine.getLine().split("\\|")[0]));
					this.executionContext.put("partB",  Long.parseLong(fileLine.getLine().split("\\|")[1]));
					return null;
				}else {
					long partA = Long.parseLong(fileLine.getLine().split("\\|")[0]);
					long partB = Long.parseLong(fileLine.getLine().split("\\|")[1]);
					
					fileLine.setPartA(String.valueOf(this.executionContext.getLong("partA") + partA).concat("|"));
					fileLine.setPartB(String.valueOf(this.executionContext.getLong("partB") + partB).concat("||"));
				}
			}
		}
		return fileLine;
	}

	@Override
	public void beforeStep(StepExecution stepExecution) {
		JobExecution jobExecution = stepExecution.getJobExecution(); 
		this.executionContext = jobExecution.getExecutionContext();
				
	}

	@Override
	public ExitStatus afterStep(StepExecution stepExecution) {
		return null;
	}

}