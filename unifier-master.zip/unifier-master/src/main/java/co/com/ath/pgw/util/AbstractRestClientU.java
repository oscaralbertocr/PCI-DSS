package co.com.ath.pgw.util;

import java.util.Arrays;
import java.util.Collection;
import java.util.Iterator;
import java.util.Map;
import java.util.UUID;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.client.HttpStatusCodeException;
import org.springframework.web.client.RestTemplate;

import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;


public class AbstractRestClientU {

	static final Logger LOGGER = LoggerFactory.getLogger(AbstractRestClientU.class);
	public static final String HEADER_RQUID = "X-RqUID";
	public static final String HEADER_CHANNEL = "X-Channel";
	public static final String HEADER_VALUE_CHANNEL = "1";
	public static final String HEADER_IPADDR = "X-IPAddr";
	public static final String HEADER_VALUE_IPADDR = "1.1.1.1";


	public String consumeRest(String constantPathURL, Object request,
			HttpMethod method, Map<String, String> headersMap) 
					 {
		String response = "";
		String urlInsertAuditLog = constantPathURL;

		RestTemplate restTemplate = new RestTemplate();
		HttpHeaders headers = new HttpHeaders();
		headers.setContentType(MediaType.APPLICATION_JSON);
		headers.setAccept(Arrays.asList(MediaType.APPLICATION_JSON));
		headers.set(HEADER_RQUID, String.valueOf(Math.abs(UUID.randomUUID().getMostSignificantBits())));
		headers.set(HEADER_CHANNEL, HEADER_VALUE_CHANNEL);
		headers.set(HEADER_IPADDR, HEADER_VALUE_IPADDR);

		if(headersMap != null && !headersMap.isEmpty()) {
			Iterator<String> iterator = headersMap.keySet().iterator();
			while(iterator.hasNext()) {
				String llave = iterator.next();
				String value = headersMap.get(llave);
				headers.set(llave, value);
			}
		}

		ResponseEntity<String> responseEntity=null;
		try {
			HttpEntity<Object> entity = new HttpEntity<Object>(request, headers);
			responseEntity = restTemplate.exchange(urlInsertAuditLog, method, entity, String.class);
			LOGGER.info("StatusCode from Service: {}", responseEntity.getStatusCode());

			if ( null != responseEntity.getStatusCode() ) {
				LOGGER.info("StatusCode: {}", responseEntity.getStatusCode());
				response = responseEntity.getBody();
			}
		}  catch (HttpStatusCodeException ee) {

			LOGGER.error("Ocurrio una excepcion al intentar consumir el "
					+ "servicio {} ",constantPathURL, ee);
		}  catch (Exception ee) {

			LOGGER.error("Ocurrio una excepcion al intentar consumir el "
					+ "servicio {}", constantPathURL, ee);
		}
		return response;
	}

	/**
	 * Valida si un objeto dado esta vacio o nulo
	 * @param object Objeto a ser validado
	 * @return true - si el objeto es vacio o nulo, false si el objeto tiene algún valor
	 */
	public static boolean isObjectEmpty(Object object) {
		if(object == null) return true;
		else if(object instanceof String) {
			if (((String)object).trim().length() == 0) {
				return true;
			}
		} else if(object instanceof Collection) {
			return isCollectionEmpty((Collection<?>)object);
		}
		return false;
	}

	/**
	 * Valida si un objeto de tipo Collection es vacio o nulo
	 * @param collection objeto a ser validad
	 * @return
	 */
	private static boolean isCollectionEmpty(Collection<?> collection) {
		boolean ret = false;
		if (collection == null || collection.isEmpty()) {
			ret = true;
		}
		return ret;
	}

	public String convertToJson(Object object) {
		String jsonInString = "";
		if (!isObjectEmpty(object)) {
			ObjectMapper mapper = new ObjectMapper();
			// Ignore null field in serialization
			mapper.setSerializationInclusion(Include.NON_NULL);
			try {
				jsonInString = mapper.writeValueAsString(object);

			} catch (JsonProcessingException jsonProcessingException) {
				jsonInString = "";
			}
		}
		jsonInString = jsonInString.replace('"', ' ');

		return jsonInString;

	}


}
