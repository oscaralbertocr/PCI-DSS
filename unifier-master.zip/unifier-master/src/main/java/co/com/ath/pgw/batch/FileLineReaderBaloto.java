package co.com.ath.pgw.batch;


import javax.annotation.PostConstruct;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.batch.core.configuration.annotation.StepScope;
import org.springframework.batch.item.file.FlatFileItemReader;
import org.springframework.batch.item.file.mapping.BeanWrapperFieldSetMapper;
import org.springframework.batch.item.file.mapping.DefaultLineMapper;
import org.springframework.batch.item.file.transform.FixedLengthTokenizer;
import org.springframework.batch.item.file.transform.Range;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import co.com.ath.pgw.dto.FileLineBaloto;
/**
 * Reader del batch de destokenizacion
 *
 * @author Jesus Octavio Avenda�o Sierra <jesus.avendano@sophossolutions.com> 
 * @version 1.0 16/15/2019
 * 
 * @sophosSolutions
 * <strong>Autor: </strong>Jesus Octavio Avenda�o Sierra</br>
 * <strong>Numero de Cambios: </strong>0</br>
 * 	
 */
@Service
@StepScope
public class FileLineReaderBaloto extends FlatFileItemReader<FileLineBaloto>{

	static Logger LOGGER = LoggerFactory.getLogger(FileLineReaderBaloto.class);

	@Value("#{jobParameters[fileName]}")
	private String fileName;
	
	@Value("#{jobParameters[fileType]}")
	private String fileType;

	@Value("#{jobParameters[pathDownloadBaloto1]}")
	private String pathDownload1;

	@Value("#{jobParameters[pathDownloadBaloto2]}")
	private String pathDownload2;

	/**
	 * Inicia la lectura por linea.
	 *
	 * @author Jesus Octavio Avenda�o Sierra <jesus.avendano@sophossolutions.com> 
	 * @version 1.0 16/15/2019
	 */
	@PostConstruct
	public void init() { 
		this.setName("FileLineReader");
		this.setEncoding("utf8");
		this.setLineMapper(this.lineMapper());
	}

	private DefaultLineMapper<FileLineBaloto> lineMapper(){
		DefaultLineMapper<FileLineBaloto> defaultLineMapper = new DefaultLineMapper<FileLineBaloto>();
		defaultLineMapper.setFieldSetMapper(this.beanWrapperFieldSetMapper());
		LOGGER.info("Configurando orden de columnas en la linea");
		defaultLineMapper.setLineTokenizer(this.tokenizerBaloto());
		LOGGER.info("Configuracion de orden de columnas en la linea Terminada");
		return defaultLineMapper;
	}

	private BeanWrapperFieldSetMapper<FileLineBaloto> beanWrapperFieldSetMapper() {
		BeanWrapperFieldSetMapper<FileLineBaloto> beanWrapperFieldSetMapper = new  BeanWrapperFieldSetMapper<FileLineBaloto>();
		beanWrapperFieldSetMapper.setTargetType(FileLineBaloto.class);
		return beanWrapperFieldSetMapper;
	}

	/**
	 * Tokenizer para recaudos.
	 *
	 * @author Jesus Octavio Avenda�o Sierra <jesus.avendano@sophossolutions.com> 
	 * @version 1.0 16/15/2019
	 */
	private FixedLengthTokenizer tokenizerBaloto() {
		LOGGER.info("Tokenizando linea para Recaudos");
		FixedLengthTokenizer fixedLengthTokenizer = new FixedLengthTokenizer();
		String[] names = {
				"partA",
				"partB"
		};

		Range[] ranges = {
				new Range(1,2),
				new Range(3),
				
		};

		fixedLengthTokenizer.setNames(names);
		fixedLengthTokenizer.setColumns(ranges);
		return fixedLengthTokenizer;
	}

}