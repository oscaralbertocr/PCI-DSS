package co.com.ath.pgw.service.impl;


import java.io.File;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.StringTokenizer;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import co.com.ath.pgw.batch.BatchConfigurationBI;
import co.com.ath.pgw.batch.BatchConfigurationBaloto;
import co.com.ath.pgw.batch.BatchConfigurationComision;
import co.com.ath.pgw.batch.BatchConfigurationRecaudo;
import co.com.ath.pgw.batch.BatchConfigurationRecaudosBogota;
import co.com.ath.pgw.dto.RequestTransferService;
import co.com.ath.pgw.service.MergeService;
import co.com.ath.pgw.util.CustomException;

/**
 * Servicio de destokenización. Ejecuta los procesos para descargar
 * destokenizar, y encriptar el archivo especificado por la peticion
 * entrante. 
 *
 *
 * @author Jesus Octavio Avendaño Sierra <jesus.avendano@sophossolutions.com> 
 * @version 1.0 16/15/2019
 * 
 * @sophosSolutions
 * <strong>Autor: </strong>Jesus Octavio Avendaño Sierra</br>
 * <strong>Numero de Cambios: </strong>0</br>
 * 
 * @IM108585
 * <strong>Autor</strong>Camilo Bustamante</br>
 * <strong>Descripcion</strong>Tokenizacion con llave por banco</br>
 * <strong>Numero de Cambios</strong>4</br>
 * <strong>Identificador corto</strong>C01</br>
 * 	
*/ 
@Service
public class MergeServiceImplementation implements MergeService{
	
	@Autowired
	private BatchConfigurationComision batchServiceComision;

	@Autowired
	private BatchConfigurationBaloto batchServiceBaloto;
	
	@Autowired
	private BatchConfigurationRecaudo batchServiceRecaudo;
	@Autowired
	private BatchConfigurationBI batchServiceBI;
	
	@Autowired
	private BatchConfigurationRecaudosBogota batchServiceBogota;
	
	@Value(value = "${originBaloto1}")
	private String originBaloto1;
	
	@Value(value = "${originBaloto2}")
	private String originBaloto2;
	
	@Value(value = "${destinyBaloto}")
	private String destinyBaloto;
	
	@Value(value = "${originComision1}")
	private String originComision1;
	
	@Value(value = "${originComision2}")
	private String originComision2;
	
	@Value(value = "${destinyComision}")
	private String destinyComision;
	
	@Value(value = "${originRecaudo1}")
	private String originRecaudo1;
	
	@Value(value = "${originRecaudo2}")
	private String originRecaudo2;
	
	@Value(value = "${destinyRecaudo}")
	private String destinyRecaudo;
	
	//
	@Value(value = "${originBI1}")
	private String originBI1;
	
	@Value(value = "${originBI2}")
	private String originBI2;
	
	@Value(value = "${destinyBI}")
	private String destinyBI;
	
	@Value(value = "${razonSocial}")
	private String razonSocial;
	
	@Value(value = "${KeyPrivateATHPGP}")
	private String keyPrivateATHPGP;
	
	@Value(value = "${KeyPublicPGPComisionBOG}")
	private String KeyPublicPGPComisionBOG;
	
	@Value(value = "${KeyPublicPGPComisionOCC}")
	private String KeyPublicPGPComisionOCC;
	
	@Value(value = "${KeyPublicPGPComisionAVV}")
	private String KeyPublicPGPComisionAVV;
	
	@Value(value = "${KeyPublicPGPComisionPOP}")
	private String KeyPublicPGPComisionPOP;
	
	
	/*INICIO-C01**/
	@Value(value = "${KeyPublicPGPRecaudo}")
	private String KeyPublicPGPRecaudoDefault;
		
	@Value(value = "${KeyPublicPGPRecaudo}")
	private String KeyPublicPGPRecaudo;
	
	@Value(value = "${pasarela.batch.recaudos.KeyPublicPGP.path.BOCC}")
	private String KeyPublicPGPRecaudoBOCC;
	@Value(value = "${pasarela.batch.recaudos.KeyPublicPGP.path.BAVV}")
	private String KeyPublicPGPRecaudoBAVV;
	@Value(value = "${pasarela.batch.recaudos.KeyPublicPGP.path.BPOP}")
	private String KeyPublicPGPRecaudoBPOP;
	@Value(value = "${pasarela.batch.recaudos.KeyPublicPGP.path.BBOG}")
	private String KeyPublicPGPRecaudoBBOG;
	
	@Value(value = "${pasarela.batch.recaudos.lista.convenios.BOCC}")
	private String listaConvenioBOCC;
	@Value(value = "${pasarela.batch.recaudos.lista.convenios.BAVV}")
	private String listaConvenioBAVV;
	@Value(value = "${pasarela.batch.recaudos.lista.convenios.BPOP}")
	private String listaConvenioBPOP;
	@Value(value = "${pasarela.batch.recaudos.lista.convenios.BBOG}")
	private String listaConvenioBBOG;
	
	private final String SEPARADOR = ",";
	/*FIN-C01**/

	
	@Value(value = "${pasPrivKey}")
	private String pasPrivKey;
	
	@Value(value = "${pasarela.batch.baloto.summary.path.KeyPublicPGP}")
	private String KeyPublicPGPBaloto;
	
	@Value(value = "${originRecaudoBogota}")
	private String originRecaudoBogota;
	
	@Value(value = "${destinyRecaudoBogota}")
	private String destinyRecaudoBogota;
	
	@Value(value = "${pasarela.llavepgp.tarjeta_credito.bogota}")
	private String keyPGPBogota;
	
	@Value(value = "${nameReportBogota}")
	private String nameReportBogota;
			
	@Value(value = "${pasarela.batch.bi.summary.path.KeyPublicPGP}")
	private String KeyPublicPGPBI;
	
	@Value(value = "${unifierFlag}")
	private String unifierFlag;
		
	static Logger LOGGER = LoggerFactory.getLogger(MergeServiceImplementation.class);
	private RequestTransferService requestTransferService = null;
	private String fileName = null;
	private String fileType = null;
	//private String unifierFlag = null;
	private String sPName = null;
	private String fileNameBIRS = null;
	private String fileStatus = null;
	
	/**
	 *  Cosntructor
	 *  
	 *  @param requestTransferService 
	 *  			Cuerpo de la peticion. 
	 *  
	 */ 
	
	public void construct(RequestTransferService requestTransferService) {

		this.setRequestTransferService(requestTransferService);
		this.fileName = (requestTransferService.getFile().getFileName().endsWith(".PGP"))?
						(requestTransferService.getFile().getFileName()).replace(".PGP", ""):
						(requestTransferService.getFile().getFileName());
		this.fileType = requestTransferService.getFile().getFileType();
		//this.unifierFlag = requestTransferService.getFile().getFileDesc();
		
		/*INICIO-C01**/
		this.sPName = requestTransferService.getFile().getSPName();
		this.setKeyPublicPGPRecaudo();
		/*FIN-C01**/
		
		this.sPName="\\" + requestTransferService.getFile().getSPName();
		
		this.fileStatus = requestTransferService.getFile().getFileStatus();
														
	}

	/**
	 *  Inicia el proceso de destokenizacion.
	 *  
	 */ 
	@Override
	public void run() throws CustomException, Exception {
		try {
			this.existsFiles();
			this.merge();
		} catch (CustomException e) {
			throw new CustomException(e.getMessage());
		} catch (Exception e) {
			throw new Exception(e.getMessage());
		}
	}
	
	
	
	/**
	 * Verifica si existe el archivo en la carpeta local
	*/
	public void existsFiles() throws CustomException, Exception{
		try {
			File file1=new File("");
			File file2=new File("");
			String fileNameCloud = this.fileName.concat(".PGP");
			if (fileType.equals("Comision")) {
			LOGGER.info("origin1: "+ originComision1 +", origin2: "+ originComision2 +" , fileName: "+ fileNameCloud);
			 file1 = new File(this.originComision1 + "/" + fileNameCloud);
			 file2 = new File(this.originComision2 + "/" + fileNameCloud);
			}else if(fileType.equals("Baloto")) {
				LOGGER.info("origin1:"+ originBaloto1 +", origin2: "+ originBaloto2 +" , fileName: "+fileNameCloud);
				 file1 = new File(this.originBaloto1 + "/" + fileNameCloud);
				 file2 = new File(this.originBaloto2 + "/" + fileNameCloud);
			}else if(fileType.equals("Recaudo") && sPName.equals(nameReportBogota)) {
				LOGGER.info("origin: {}",  originRecaudoBogota + "\\" +fileNameCloud);
				 file1 = new File(this.originRecaudoBogota + "/" + fileNameCloud);
			}else if(fileType.equals("Recaudo")) {
				LOGGER.info("origin1:"+ originRecaudo1+ this.sPName +", origin2: "+ originRecaudo2 + this.sPName +" , fileName: "+fileNameCloud);
				 file1 = new File(this.originRecaudo1 + this.sPName + "/" + fileNameCloud);
				 file2 = new File(this.originRecaudo2 + this.sPName + "/" + fileNameCloud);
			}
			else if(fileType.equals("BI")) {
				file1 = new File(this.originBI1  + "/" + fileNameCloud);
				LOGGER.info("origin1:"+ originBI1 +" , fileName: "+fileNameCloud);
				        
				if (this.unifierFlag.equals("0")&&this.unifierFlag.equals("2")) {
					String[] fileSplitName = fileName.split("_");
					String fileNamePrefix=fileSplitName[0].concat("_").concat(fileSplitName[1]);
				File[] listFilesRS = new File(originBI2).listFiles();
				for (int i = 0; i < listFilesRS.length; i++) {

				    if (listFilesRS[i].isFile()) {
				        String fileName = listFilesRS[i].getName();
				        if (fileName.startsWith(fileNamePrefix)
				                && fileName.toUpperCase().endsWith(".PGP")) {
				        	 file2 = new File(this.originBI2 + "/" + fileName);
				        	 this.fileNameBIRS= (fileName.endsWith(".PGP"))?
										(fileName).replace(".PGP", ""):
											(fileName);
					LOGGER.info(" origin2: "+ originBI2  +" , fileName: "+fileName);
				            break;
				        }
				    }
				}}
				LOGGER.info("origin1:"+ originBI1 +", origin2: "+ originBI2  +" , fileName: "+file1);
			}
			
			if (this.fileType.equals("Recaudo")) {
			
					if (file1.exists()) {
						LOGGER.info("Archivo AWS Landing Zone cargado correctamente desde la carpeta local");
					} else {
						LOGGER.error("Archivo AWS Landing Zone no encontrado en la carpeta local");
						throw new CustomException("Archivo AWS Landing Zone no encontrado en la carpeta local");
					}
				 

			}else {
				
				if (this.unifierFlag.equals("0")) {
			if (file1.exists()) {
					if(file2.exists()) {
						LOGGER.info("Archivo AWS RS cargado correctamente desde la carpeta local");
					}else {
						LOGGER.error("Archivo AWS RS no encontrado en la carpeta local");
						throw new CustomException("Archivo AWS RS no encontrado en la carpeta local");
					}
			} else {
				LOGGER.error("Archivo Landing Zone no encontrado en la carpeta local");
				throw new CustomException("Archivo Landing Zone no encontrado en la carpeta local");
			}
				}
				else if (this.unifierFlag.equals("1")) {
					if (file1.exists()) {
						LOGGER.info("Archivo AWS Landing Zone cargado correctamente desde la carpeta local");
					} else {
						LOGGER.error("Archivo AWS Landing Zone no encontrado en la carpeta local");
						throw new CustomException("Archivo AWS Landing Zone no encontrado en la carpeta local");
					}
				}
				else if (this.unifierFlag.equals("2")) {
					if(file2.exists()) {
						LOGGER.info("Archivo AWS RS cargado correctamente desde la carpeta local");
					}else {
						LOGGER.error("Archivo AWS RS no encontrado en la carpeta local");
						throw new CustomException("Archivo AWS RS no encontrado en la carpeta local");
					}
				}
				
			}
			
		} catch (CustomException e) {
			throw new CustomException(e.getMessage());
		} catch (Exception e) {
			throw new Exception(e.getMessage());
		}
	}

	/**
	 *  Inicia el proceso de batch que se 
	 *  encarga de la lectura, destokenizacion, y 
	 *  escritura del archivo descargado.
	 *  
	 */
	@Override
	public void merge() {
		LOGGER.info("Iniciando servicio de batch");
		HashMap<String, String> parameters = new HashMap<String, String>();
		parameters.put("fileName", this.fileName);
		parameters.put("fileNameBIRS", this.fileNameBIRS);
		parameters.put("unifierFlag", this.unifierFlag);
		parameters.put("sPName", this.sPName.replace("\\", ""));
		parameters.put("pathDownloadBaloto1", this.originBaloto1);
		parameters.put("pathDownloadBaloto2", this.originBaloto2);
		parameters.put("destinyBaloto", this.destinyBaloto);
		parameters.put("destinyRecaudo", this.destinyRecaudo+ this.sPName);
		parameters.put("pathDownloadComision1", this.originComision1);
		parameters.put("pathDownloadComision2", this.originComision2);
		parameters.put("pathDownloadRecaudo1", this.originRecaudo1+ this.sPName );
		parameters.put("pathDownloadRecaudo2", this.originRecaudo2+ this.sPName );
		parameters.put("destinyComision", this.destinyComision);
		parameters.put("pathDownloadBI1", this.originBI1);
		parameters.put("pathDownloadBI2", this.originBI2);
		parameters.put("destinyBI", this.destinyBI);
		parameters.put("fileType", this.fileType);
		parameters.put("razonSocial", this.razonSocial);
		parameters.put("keyPrivateATHPGP", this.keyPrivateATHPGP);
		parameters.put("KeyPublicPGPComisionBOG", this.KeyPublicPGPComisionBOG);
		parameters.put("KeyPublicPGPComisionOCC", this.KeyPublicPGPComisionOCC);
		parameters.put("KeyPublicPGPComisionAVV", this.KeyPublicPGPComisionAVV);
		parameters.put("KeyPublicPGPComisionPOP", this.KeyPublicPGPComisionPOP);
		parameters.put("KeyPublicPGPRecaudo", this.KeyPublicPGPRecaudo);
		parameters.put("pasPrivKey", this.pasPrivKey);
		parameters.put("KeyPublicPGPBaloto", this.KeyPublicPGPBaloto);
		parameters.put("KeyPublicPGPBI", this.KeyPublicPGPBI);
		parameters.put("destinyRecaudoBogota", this.destinyRecaudoBogota);
		parameters.put("originRecaudoBogota", this.originRecaudoBogota);
		parameters.put("keyPGPBogota", this.keyPGPBogota);
		
		if(this.fileType.equals("Comision")) {
			batchServiceComision.run(parameters);			
		}else if(this.fileType.equals("Baloto")){
			batchServiceBaloto.run(parameters);
		}else if(this.fileType.equals("Recaudo") && sPName.equals(nameReportBogota)) {
			batchServiceBogota.run(parameters);
		}else if(this.fileType.equals("Recaudo")) {
			batchServiceRecaudo.run(parameters);
		}else if(this.fileType.equals("BI")) {
			batchServiceBI.run(parameters);
		}
		

		LOGGER.info("Terminando servicio de batch");
	}
	
	public RequestTransferService getRequestTransferService() {
		return this.requestTransferService;
	}

	public void setRequestTransferService(RequestTransferService requestTransferService) {
		this.requestTransferService = requestTransferService;
	}
	
	/*INICIO-C01**/
	/**
	 * Encargado de definir la llave de cifrado de acuerdo
	 * a las listas de los convenios.
	 */
	private void setKeyPublicPGPRecaudo() {
		
		List<String> conveniosBOCC = new ArrayList<String>();
		List<String> conveniosBBOG = new ArrayList<String>();
		List<String> conveniosBAVV = new ArrayList<String>();
		List<String> conveniosBPOP = new ArrayList<String>();
		
		// Se obtienen las listas de convenios configurados
		StringTokenizer st;
		
		st = new StringTokenizer(listaConvenioBOCC, SEPARADOR);
		while (st.hasMoreElements()) 
			conveniosBOCC.add(st.nextToken());
		
		st = new StringTokenizer(listaConvenioBBOG, SEPARADOR);
		while (st.hasMoreElements()) 
			conveniosBBOG.add(st.nextToken());
		
		st = new StringTokenizer(listaConvenioBAVV, SEPARADOR);
		while (st.hasMoreElements()) 
			conveniosBAVV.add(st.nextToken());
		
		st = new StringTokenizer(listaConvenioBPOP, SEPARADOR);
		while (st.hasMoreElements()) 
			conveniosBPOP.add(st.nextToken());
		
		// Se configura la llave de cifrado
		if( !conveniosBOCC.isEmpty() && conveniosBOCC.contains(this.sPName))
			this.KeyPublicPGPRecaudo = KeyPublicPGPRecaudoBOCC;
		else if( !conveniosBBOG.isEmpty() && conveniosBBOG.contains(this.sPName))
			this.KeyPublicPGPRecaudo = KeyPublicPGPRecaudoBBOG;
		else if( !conveniosBAVV.isEmpty() && conveniosBAVV.contains(this.sPName))
			this.KeyPublicPGPRecaudo = KeyPublicPGPRecaudoBAVV;
		else if( !conveniosBPOP.isEmpty() && conveniosBPOP.contains(this.sPName))
			this.KeyPublicPGPRecaudo = KeyPublicPGPRecaudoBPOP;
		else
			this.KeyPublicPGPRecaudo = KeyPublicPGPRecaudoDefault;
		
		LOGGER.info("Llave de cifrado: {}", this.KeyPublicPGPRecaudo);

	}
	/*FIN-C01**/

}
