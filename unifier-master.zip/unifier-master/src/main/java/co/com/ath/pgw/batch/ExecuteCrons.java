package co.com.ath.pgw.batch;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.scheduling.annotation.EnableScheduling;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;

import co.com.ath.pgw.dto.File;
import co.com.ath.pgw.dto.RequestTransferService;
import co.com.ath.pgw.service.impl.MergeServiceImplementation;
import co.com.ath.pgw.srv.UnifierManagementFacade;

@Service
public class ExecuteCrons {
	private static final Logger LOGGER = LoggerFactory.getLogger(ExecuteCrons.class);
	@Autowired
	private MergeServiceImplementation detokenizationServiceImplementation;

	@Value(value = "${unifierFlag}")
	private String unifierFlag;
		
	@Scheduled(cron="${rackspace.baloto.cron}")
	public void runBalotoRS() {
		LOGGER.info(("@runBalotoRS se ejecuta el cron"));
		if (unifierFlag.equals("2")) {
		Calendar calendar = Calendar.getInstance();
		calendar.add(Calendar.DATE, -1);
		Date curDate = calendar.getTime(); 
		SimpleDateFormat format = new SimpleDateFormat("yyMMdd");
		RequestTransferService requestTransferService=new RequestTransferService();
		File file =new File();
		file.setFileDesc("");
		file.setFileId("");
		file.setFileName("900001_rep_via_"+format.format(curDate)+"DAT");
		file.setFileStatus("");
		file.setFileType("Baloto");
		file.setSPName("");
		requestTransferService.setFile(file);
		try {
			detokenizationServiceImplementation.construct(requestTransferService);
			detokenizationServiceImplementation.run();
		} catch (Exception e) {
			LOGGER.error("@runBalotoRS error output" + "\n" + e.getMessage());
		}
		}
		
	}
	
	
	@Scheduled(cron="${rackspace.comisiones.cron}")
	public void runComisionesRS() {
		LOGGER.info(("@runComisionesRS se ejecuta el cron"));
		if (unifierFlag.equals("2")) {
		Calendar calendar = Calendar.getInstance();
		calendar.add(Calendar.DATE, -1);
		Date curDate = calendar.getTime(); 
		SimpleDateFormat format = new SimpleDateFormat("yyMMdd");
		RequestTransferService requestTransferService=new RequestTransferService();
		File file =new File();
		file.setFileDesc("");
		file.setFileId("");
		file.setFileName("BAVV_Pagos_PortalDePagos_"+format.format(curDate)+"DAT");
		file.setFileStatus("");
		file.setFileType("Comision");
		file.setSPName("");
		requestTransferService.setFile(file);
		
		try {
			detokenizationServiceImplementation.construct(requestTransferService);
			detokenizationServiceImplementation.run();
		} catch (Exception e) {
			LOGGER.error("@runComisionesRS error output" + "\n" + e.getMessage());
		}
		requestTransferService.getFile().setFileName("BPOP_Pagos_PortalDePagos_"+format.format(curDate)+"DAT");
		try {
			detokenizationServiceImplementation.construct(requestTransferService);
			detokenizationServiceImplementation.run();
		} catch (Exception e) {
			LOGGER.error("@runComisionesRS error output" + "\n" + e.getMessage());
		}
		requestTransferService.getFile().setFileName("BOCC_Pagos_PortalDePagos_"+format.format(curDate)+"DAT");
		try {
			detokenizationServiceImplementation.construct(requestTransferService);
			detokenizationServiceImplementation.run();
		} catch (Exception e) {
			LOGGER.error("@runComisionesRS error output" + "\n" + e.getMessage());
		}
		requestTransferService.getFile().setFileName("BBOG_Pagos_PortalDePagos_"+format.format(curDate)+"DAT");
		try {
			detokenizationServiceImplementation.construct(requestTransferService);
			detokenizationServiceImplementation.run();
		} catch (Exception e) {
			LOGGER.error("@runComisionesRS error output" + "\n" + e.getMessage());
		}
		}
	}
	
	@Scheduled(cron="${rackspace.bi.cron}")
	public void runBIRS() {
		LOGGER.info(("@runBIRS se ejecuta el cron"));
		if (unifierFlag.equals("2")) {
		Calendar calendar = Calendar.getInstance();
		calendar.add(Calendar.DATE, -1);
		Date curDate = calendar.getTime(); 
		SimpleDateFormat format = new SimpleDateFormat("yyyyMMdd");
		RequestTransferService requestTransferService=new RequestTransferService();
		File file =new File();
		file.setFileDesc("");
		file.setFileId("");
		file.setFileName("CarguePortalDePagosNube_"+format.format(curDate)+"_000000.txt");
		file.setFileStatus("");
		file.setFileType("BI");
		file.setSPName("");
		requestTransferService.setFile(file);
		try {
			detokenizationServiceImplementation.construct(requestTransferService);
			detokenizationServiceImplementation.run();
		} catch (Exception e) {
			LOGGER.error("@runBIRS error output" + "\n" + e.getMessage());
		}
	
	}
	}	
}
