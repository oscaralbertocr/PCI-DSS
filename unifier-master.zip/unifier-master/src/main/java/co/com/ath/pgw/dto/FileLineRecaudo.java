package co.com.ath.pgw.dto;

/**
 * DTO Fileline
 *
 * @author Jesus Octavio Avendaño Sierra <jesus.avendano@sophossolutions.com> 
 * @version 1.0 16/15/2019
 * 
 * @sophosSolutions
 * <strong>Autor: </strong>Jesus Octavio Avendaño Sierra</br>
 * <strong>Numero de Cambios: </strong>0</br>
 * 	
*/

public class FileLineRecaudo {
	
	private String flag;
	private String next;
	
	public FileLineRecaudo() {
	}
	
	public String getFlag() {
		return flag;
	}
	public void setFlag(String flag) {
		this.flag = flag;
	}
	public String getNext() {
		return next;
	}
	public void setNext(String next) {
		this.next = next;
	}

	public String getLine() {
		return this.getFlag()+ this.getNext();
	}
	
	
}
