package co.com.ath.pgw.batch;

import java.util.HashMap;

import javax.annotation.PostConstruct;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.batch.core.Job;
import org.springframework.batch.core.JobExecution;
import org.springframework.batch.core.JobParametersBuilder;
import org.springframework.batch.core.Step;
import org.springframework.batch.core.configuration.annotation.JobBuilderFactory;
import org.springframework.batch.core.configuration.annotation.StepBuilderFactory;
import org.springframework.batch.core.launch.JobLauncher;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import co.com.ath.pgw.dto.FileLineBI;
import co.com.ath.pgw.dto.FileLineBaloto;

/**
 * Configuración del proceso 
 * 
 * Batch para la destokenizacion de los reportes.
 *
 * @author Jesus Octavio Avendaño Sierra <jesus.avendano@sophossolutions.com> 
 * @version 1.0 16/15/2019
 * 
 * @sophosSolutions
 * <strong>Autor: </strong>Jesus Octavio Avendaño Sierra</br>
 * <strong>Numero de Cambios: </strong>0</br>
 * 
 * * @sophosSolutions
 * <strong>Autor: </strong>Nelly Rocio Linares</br>
 * <strong>Version </strong>1.1</br>
 * 	
*/
@Service
public class BatchConfigurationBI {
	
	static Logger LOGGER = LoggerFactory.getLogger(BatchConfigurationBI.class);
	
	@Autowired(required=true)
	private JobBuilderFactory jobBuilderFactory;

	@Autowired(required=true)
	private StepBuilderFactory stepBuilderFactory;

	@Autowired(required=true)
	private JobLauncher jobLauncher;

	@Autowired(required=true)
	private FileMultiReaderBI fileMultiReaderBI;
	
	@Autowired(required=true)
	private DecryptTasklet decryptTasklet;
	
	@Autowired(required=true)
	private EncryptTasklet encryptTasklet;
	
	@Autowired(required=true)
	private FileLineProcessorBI fileLineProcessorBI;


	@Autowired(required=true)
	private FileLineWriterBI fileLineWriterBI;

	private Job job;
	
	private static final String JOB_NAME = "MERGE";

	private static final String STEP_NAME = "MERGE_LINES";

	private static final String TASKLET_DECRYPT = "DECRYPT_STEP";
	
	private static final String TASKLET_ENCRYPT = "ENCRYPT_STEP";
		
	
	@PostConstruct
	public void init() {
		this.job = this.createJob();
	}
	
	/**
	 * Sonda encargada de destokenizar los reportes.
	 * 
	 * @param fileName
	 *            Nombre del archivo.
	 *
	 * @param filePath
	 *            Ruta donde se encuetra el archivo especificado.
	 *
	 * @param fileType
	 *            Tipo de archivo (Recaudo, Comision).
	 * 
	 **/
	public void run(HashMap<String, String> parameters) {
		JobParametersBuilder jobParametersBuilder = this.generateParameters(parameters);
		this.executeJob(jobParametersBuilder);		
	}
	
	/**
	 * Ejecuta el Job del batch.
	 * 
	 * @return 
	 * 		JobExecution
	 **/
	private JobExecution executeJob(JobParametersBuilder jobParams) {
		JobExecution jobExecution;
		try {
			jobExecution = this.jobLauncher.run(this.job, jobParams.toJobParameters());
		} catch (Exception e) {
			jobExecution = null;
			LOGGER.error("Error en executeJob ", e);
		}
		return jobExecution;
	}
	
	/**
	 * Genera el job del batch.
	 * 
	 * @return 
	 * 		Job
	 **/
	private Job createJob() {
		return this.jobBuilderFactory.get(this.JOB_NAME)
				.flow(this.decryptFile())
				.next(this.mergeFiles())
				.next(this.encryptFile())
				.end()
				.build();
	}
	
	/**
	 * Genera el step de detokenizacion.
	 * 
	 * @return 
	 * 		Step
	 **/
	private Step decryptFile(){
			return this.stepBuilderFactory.get(this.TASKLET_DECRYPT)
					.tasklet(this.decryptTasklet)
					.build();
	}
	
	/**
	 * Genera la encripcion del archivo.
	 * 
	 * @return 
	 * 		Step
	 **/
	private Step encryptFile(){
			return this.stepBuilderFactory.get(this.TASKLET_ENCRYPT)
					.tasklet(this.encryptTasklet)
					.build();
	}
	
	
	/**
	 * Genera el step del job.
	 * 
	 * @return 
	 * 		Step
	 **/
	private Step mergeFiles() {
		
			return this.stepBuilderFactory.get(this.STEP_NAME)
					.<FileLineBI, FileLineBI> chunk(100)
					.reader(this.fileMultiReaderBI)
					.processor(this.fileLineProcessorBI)
					.writer(this.fileLineWriterBI)
					//.faultTolerant()
					//.retryPolicy(new AlwaysRetryPolicy())
					.build();
	}
	
	 // Final.Version.1.1
	
	/**
	 * Genera el objeto jobParametersBuilder con los parametros requeridos.
	 * 
	 * @param fileName
	 *            Nombre del archivo.
	 *
	 * @param filePath
	 *            Ruta donde se encuetra el archivo especificado.
	 *
	 * @param fileType
	 *            Tipo de archivo (Recaudo, Comision).
	 * 
	 **/
	private JobParametersBuilder generateParameters(HashMap<String, String> parameters) {
		LOGGER.info("Generando parametros");
		JobParametersBuilder jobParametersBuilder = new JobParametersBuilder();
		jobParametersBuilder.addLong("time", System.currentTimeMillis());
		jobParametersBuilder.addString("fileName", parameters.get("fileName"));
		jobParametersBuilder.addString("fileNameBIRS", parameters.get("fileNameBIRS"));
		jobParametersBuilder.addString("unifierFlag", parameters.get("unifierFlag"));
		jobParametersBuilder.addString("sPName", parameters.get("sPName"));
		jobParametersBuilder.addString("pathDownloadBI1", parameters.get("pathDownloadBI1"));
		jobParametersBuilder.addString("pathDownloadBI2", parameters.get("pathDownloadBI2"));
		jobParametersBuilder.addString("destinyBI", parameters.get("destinyBI"));
		jobParametersBuilder.addString("fileType", parameters.get("fileType"));
		jobParametersBuilder.addString("razonSocial", parameters.get("razonSocial"));
		jobParametersBuilder.addString("pasPrivKey", parameters.get("pasPrivKey"));
		jobParametersBuilder.addString("KeyPublicPGPBI", parameters.get("KeyPublicPGPBI"));
		jobParametersBuilder.addString("keyPrivateATHPGP", parameters.get("keyPrivateATHPGP"));
		LOGGER.info("Parametros Generados");
		LOGGER.info(jobParametersBuilder.toString());
		return jobParametersBuilder;
	}
	
}
