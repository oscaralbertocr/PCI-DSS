package co.com.ath.pgw.service;

import co.com.ath.pgw.util.CustomException;

/**
 * interfaz para el servicio de destokenizado. 
 *
 *
 * @author Jesus Octavio Avendaño Sierra <jesus.avendano@sophossolutions.com> 
 * @version 1.0 16/15/2019
 * 
 * @sophosSolutions
 * <strong>Autor: </strong>Jesus Octavio Avendaño Sierra</br>
 * <strong>Numero de Cambios: </strong>0</br>
 * 	
*/ 

public interface MergeService {
	
	/**
	 * Inicia el servicio.
	 * 
	 * @param **********
	 *            *******************************

	 * @return 
	 * 
	 **/
	public void run() throws CustomException, Exception;

	/**
	 * Inicia el merge.
	 * 
	 * @param **********
	 *            *******************************

	 * @return 
	 * 
	 **/
	public void merge();

}
