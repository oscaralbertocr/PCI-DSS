package co.com.ath.pgw.srv;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.batch.core.configuration.annotation.EnableBatchProcessing;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.scheduling.annotation.EnableScheduling;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import co.com.ath.pgw.batch.ExecuteCrons;
import co.com.ath.pgw.dto.GenericErrorResponse;
import co.com.ath.pgw.dto.RequestTransferService;
import co.com.ath.pgw.mapper.MapperResponseTransferService;
import co.com.ath.pgw.service.impl.MergeServiceImplementation;
import co.com.ath.pgw.util.CustomException;

/**
 * Facade del servicio. 
 *
 *
 * @author Jesus Octavio Avendaño Sierra <jesus.avendano@sophossolutions.com> 
 * @version 1.0 16/15/2019
 * 
 * @sophosSolutions
 * <strong>Autor: </strong>Jesus Octavio Avendaño Sierra</br>
 * <strong>Numero de Cambios: </strong>0</br>
 * 	
*/

@EnableBatchProcessing
@RestController
@EnableScheduling
@RequestMapping(value ="/unifierManagement")
public class UnifierManagementFacade {
	
	@Autowired
	private MergeServiceImplementation detokenizationServiceImplementation;
	
	@Autowired
	private ExecuteCrons executeCrons;

	private static final Logger LOGGER = LoggerFactory.getLogger(UnifierManagementFacade.class);
	
	@RequestMapping(value = "/initUnifier" , method = RequestMethod.POST)
	public ResponseEntity<Object> initTransfer(
			@RequestBody RequestTransferService requestTransferService) {
		LOGGER.info("@initTransfer input" + "\n" + requestTransferService);
		ResponseEntity<Object> response;
		GenericErrorResponse genericErrorResponse;
		try {
			detokenizationServiceImplementation.construct(requestTransferService);
			detokenizationServiceImplementation.run();
			response = new MapperResponseTransferService().responseTransferService(HttpStatus.NO_CONTENT, null);
		} catch(CustomException e) {
			genericErrorResponse = MapperResponseTransferService.mapperResponseErrorCore(e);
			response = new MapperResponseTransferService().responseTransferService(HttpStatus.PARTIAL_CONTENT, genericErrorResponse);
			LOGGER.error("@initTransfer error output" + "\n" + genericErrorResponse);
		} catch (Exception e) {
			genericErrorResponse = MapperResponseTransferService.mapperResponseErrorCore(e);
			response = new MapperResponseTransferService().responseTransferService(HttpStatus.INTERNAL_SERVER_ERROR, genericErrorResponse);
			LOGGER.error("@initTransfer error output" + "\n" + genericErrorResponse);
		}
		return response;
	}
}
