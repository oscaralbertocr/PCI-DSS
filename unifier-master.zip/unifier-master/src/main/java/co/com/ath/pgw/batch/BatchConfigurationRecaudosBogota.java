package co.com.ath.pgw.batch;

import java.util.HashMap;

import javax.annotation.PostConstruct;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;	
import org.springframework.batch.core.Job;
import org.springframework.batch.core.JobExecution;
import org.springframework.batch.core.JobParametersBuilder;
import org.springframework.batch.core.Step;
import org.springframework.batch.core.configuration.annotation.JobBuilderFactory;
import org.springframework.batch.core.configuration.annotation.StepBuilderFactory;
import org.springframework.batch.core.launch.JobLauncher;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import co.com.ath.pgw.dto.FileLineRecaudo;

@Service
public class BatchConfigurationRecaudosBogota {
	
	static final Logger LOGGER = LoggerFactory.getLogger(BatchConfigurationRecaudosBogota.class);
	
	@Value(value = "${frassSecretKeyBBTA}")
	private String frassSecretKeyBBTA;
	
	@Value(value = "${pasarela.llavefirma.tarjeta_credito.bogota}")
	private String PublicFirm;
	
	@Value(value = "${pasarela.llavepgp.descifrar_credito.bogota}")
	private String PrivatePGP;
	
	@Value(value = "${destinyRecaudoBogotaClaro}")
	private String pathDownloadBBTAClaro;
	
	@Value(value = "${pasarela.llavepgp.tarjeta_credito.bogota}")
	private String keyPGPBogota;
	
	
	
	
	@Autowired(required=true)
	private JobBuilderFactory jobBuilderFactory;

	@Autowired(required=true)
	private StepBuilderFactory stepBuilderFactory;

	@Autowired(required=true)
	private JobLauncher jobLauncher;

	@Autowired(required=true)
	private FileMultiReaderRecaudo fileMultiReaderRecaudo;

	@Autowired(required=true)
	private DecryptTasklet decryptTasklet;
	
	@Autowired(required=true)
	private EncryptTasklet encryptTasklet;
	
	@Autowired(required=true)
	private FileLineProcessorRecaudo fileLineProcessorRecaudo;

	@Autowired(required=true)
	private FileLineWriterRecaudo fileLineWriterRecaudo;

	private Job job;
	
	private static final String JOB_NAME = "MERGE";

	private static final String STEP_NAME = "MERGE_LINES";

	private static final String TASKLET_DECRYPT = "DECRYPT_STEP";
	
	private static final String TASKLET_ENCRYPT = "ENCRYPT_STEP";
		
	
	@PostConstruct
	public void init() {
		this.job = this.createJob();
	}
	

	public void run(HashMap<String, String> parameters) {
		JobParametersBuilder jobParametersBuilder = this.generateParameters(parameters);
		this.executeJob(jobParametersBuilder);		
	}
	
	/**
	 * Ejecuta el Job del batch. 
	 * @return JobExecution
	 **/
	private JobExecution executeJob(JobParametersBuilder jobParams) {
		JobExecution jobExecution;
		try {
			jobExecution = this.jobLauncher.run(this.job, jobParams.toJobParameters());
		} catch (Exception e) {
			jobExecution = null;
		}
		return jobExecution;
	}
	
	/**
	 * Genera el job del batch. 
	 * @return Job
	 **/
	private Job createJob() {
		return this.jobBuilderFactory.get(JOB_NAME)
				.flow(this.decryptFile())
				.next(this.mergeFiles())
				.next(this.encryptFile())
				.end()
				.build();
	}
	
	/**
	 * Genera el step de detokenizacion. 
	 * @return Step
	 **/
	private Step decryptFile(){
			return this.stepBuilderFactory.get(TASKLET_DECRYPT)
					.tasklet(this.decryptTasklet)
					.build();
	}
	
	/**
	 * Genera la encripcion del archivo. 
	 * @return Step
	 **/
	private Step encryptFile(){
			return this.stepBuilderFactory.get(TASKLET_ENCRYPT)
					.tasklet(this.encryptTasklet)
					.build();
	}
	
	
	/**
	 * Genera el step del job. 
	 * @return Step
	 **/
	private Step mergeFiles() {		
			return this.stepBuilderFactory.get(STEP_NAME)
					.<FileLineRecaudo, FileLineRecaudo> chunk(100)
					.reader(this.fileMultiReaderRecaudo)
					.processor(this.fileLineProcessorRecaudo)
					.writer(this.fileLineWriterRecaudo)
					.build();
	}

	/**
	 * Genera el objeto jobParametersBuilder con los parametros requeridos.
	 * @param parameters
	 * @return
	 */
	private JobParametersBuilder generateParameters(HashMap<String, String> parameters) {
		LOGGER.info("Generando parametros");
		JobParametersBuilder jobParametersBuilder = new JobParametersBuilder();
		jobParametersBuilder.addLong("time", System.currentTimeMillis());
		jobParametersBuilder.addString("fileName", parameters.get("fileName"));
		jobParametersBuilder.addString("fileDesc", parameters.get("fileDesc"));
		jobParametersBuilder.addString("sPName", parameters.get("sPName"));
		jobParametersBuilder.addString("pathDownloadRecaudo1", parameters.get("originRecaudoBogota"));
		jobParametersBuilder.addString("pathDownloadRecaudo2", parameters.get("originRecaudoBogota"));
		jobParametersBuilder.addString("destinyRecaudo", parameters.get("destinyRecaudoBogota"));
		jobParametersBuilder.addString("fileType", parameters.get("fileType"));
		jobParametersBuilder.addString("keyPrivateATHPGP", parameters.get("keyPrivateATHPGP"));
		jobParametersBuilder.addString("pasPrivKey", parameters.get("pasPrivKey"));
		jobParametersBuilder.addString("KeyPublicPGPRecaudo", parameters.get("keyPGPBogota"));
		jobParametersBuilder.addString("unifierFlag", parameters.get("unifierFlag"));
		jobParametersBuilder.addString("frassSecretKeyBBTA",this.frassSecretKeyBBTA );
		jobParametersBuilder.addString("PublicFirm", this.PublicFirm);
		jobParametersBuilder.addString("PrivatePGP",this.PrivatePGP );
		jobParametersBuilder.addString("pathDownloadBBTAClaro",this.pathDownloadBBTAClaro );
		jobParametersBuilder.addString("keyPGPBogota",this.keyPGPBogota );
		
		
		
		LOGGER.info("Parametros Generados");
		return jobParametersBuilder;
	}
	
}
