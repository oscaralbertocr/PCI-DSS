package co.com.ath.pgw.batch;

import java.io.File;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.batch.core.StepContribution;
import org.springframework.batch.core.configuration.annotation.StepScope;
import org.springframework.batch.core.scope.context.ChunkContext;
import org.springframework.batch.core.step.tasklet.Tasklet;
import org.springframework.batch.repeat.RepeatStatus;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.io.FileSystemResource;
import org.springframework.stereotype.Service;

import co.com.ath.pgw.util.PGPFileProcessor;

/**
 * 
 * custom Exception.
 *
 * @author Jesus Octavio Avendaño Sierra <jesus.avendano@sophossolutions.com> 
 * @version 1.0 16/15/2019
 * 
 * @sophosSolutions
 * <strong>Autor: </strong>Jesus Octavio Avendaño Sierra</br>
 * <strong>Numero de Cambios: </strong>0</br>
 * 
 * 	
*/

@Service
@StepScope
public class DecryptTasklet implements Tasklet {
	
	static Logger LOGGER = LoggerFactory.getLogger(DecryptTasklet.class);

	@Value("#{jobParameters[fileName]}")
	private String fileName;
	@Value("#{jobParameters[fileNameBIRS]}")
	private String fileNameBIRS;
	@Value("#{jobParameters[unifierFlag]}")
	private String unifierFlag;
	
	@Value("#{jobParameters[pathDownloadComision2]}")
	private String pathDownloadComision2;
	@Value("#{jobParameters[pathDownloadComision1]}")
	private String pathDownloadComision1;
	@Value("#{jobParameters[pathDownloadBaloto1]}")
	private String pathDownloadBaloto1;
	@Value("#{jobParameters[pathDownloadBaloto2]}")
	private String pathDownloadBaloto2;
	@Value("#{jobParameters[pathDownloadBI1]}")
	private String pathDownloadBI1;
	@Value("#{jobParameters[pathDownloadBI2]}")
	private String pathDownloadBI2;
	@Value("#{jobParameters[pathDownloadRecaudo2]}")
	private String pathDownloadRecaudo2;
	@Value("#{jobParameters[pathDownloadRecaudo1]}")
	private String pathDownloadRecaudo1;
	
	@Value("#{jobParameters[fileType]}")
	private String fileType;	
	
	@Value("#{jobParameters[keyPrivateATHPGP]}")
	private String keyPrivateATHPGP;
	
	@Value("#{jobParameters[pasPrivKey]}")
	private String ring;
	
	@Value("#{jobParameters[sPName]}")
	private String sPName;	
	
	@Value("#{jobParameters[frassSecretKeyBBTA]}")
	private String frassSecretKeyBBTA;	
	
	@Value("#{jobParameters[pasPrivKey]}")
	private String pasPrivKey;		
	
	@Value("#{jobParameters[PublicFirm]}")
	private String PublicFirm;	
	
	@Value("#{jobParameters[PrivatePGP]}")
	private String PrivatePGP;	
	
	@Value("#{jobParameters[pathDownloadBBTAClaro]}")
	private String pathDownloadBBTAClaro;
	

	@Override
	public RepeatStatus execute(StepContribution contribution, ChunkContext chunkContext) throws Exception {
		PGPFileProcessor pgpFileProcessorLZ = new PGPFileProcessor();
		PGPFileProcessor pgpFileProcessorRS = new PGPFileProcessor();
		if(this.fileType.equals("Comision")) {
			
			try {
				if (this.unifierFlag.equals("0")) {
				pgpFileProcessorRS.setInputFileName( this.pathDownloadComision2.concat("\\" + this.fileName + ".PGP"));
				pgpFileProcessorRS.setOutputFileName(this.pathDownloadComision2.concat("\\" + this.fileName));
				pgpFileProcessorRS.setSecretKeyFileName(this.keyPrivateATHPGP);
				pgpFileProcessorRS.setRing(ring);
				if (pgpFileProcessorRS.decrypt()) {
					LOGGER.info("Se desencripto correctamente el archivo Comision RackSpace :".concat(this.fileName));
				} else {
					throw new Exception("Decrypt Comision RackSpace Fail");
				}
				pgpFileProcessorLZ.setInputFileName( this.pathDownloadComision1.concat("\\" + this.fileName + ".PGP"));
				pgpFileProcessorLZ.setOutputFileName(this.pathDownloadComision1.concat("\\" + this.fileName));
				pgpFileProcessorLZ.setSecretKeyFileName(this.keyPrivateATHPGP);
				pgpFileProcessorLZ.setRing(ring);
				if (pgpFileProcessorLZ.decrypt()) {
					LOGGER.info("Se desencripto correctamente el archivo Comision LandingZone :".concat(this.fileName));
				} else {
					throw new Exception("Decrypt Comision LandingZone Fail");
				}
				}else if (this.unifierFlag.equals("1")) {
					
				pgpFileProcessorLZ.setInputFileName( this.pathDownloadComision1.concat("\\" + this.fileName + ".PGP"));
				pgpFileProcessorLZ.setOutputFileName(this.pathDownloadComision1.concat("\\" + this.fileName));
				pgpFileProcessorLZ.setSecretKeyFileName(this.keyPrivateATHPGP);
				pgpFileProcessorLZ.setRing(ring);
				if (pgpFileProcessorLZ.decrypt()) {
					LOGGER.info("Se desencripto correctamente el archivo :".concat(this.fileName));
				} else {
					throw new Exception("Decrypt Fail");
				}	
			 }
				else if (this.unifierFlag.equals("2")) {
					
					pgpFileProcessorRS.setInputFileName( this.pathDownloadComision2.concat("\\" + this.fileName + ".PGP"));
					pgpFileProcessorRS.setOutputFileName(this.pathDownloadComision2.concat("\\" + this.fileName));
					pgpFileProcessorRS.setSecretKeyFileName(this.keyPrivateATHPGP);
					pgpFileProcessorRS.setRing(ring);
					if (pgpFileProcessorRS.decrypt()) {
						LOGGER.info("Se desencripto correctamente el archivo Comision RackSpace :".concat(this.fileName));
					} else {
						throw new Exception("Decrypt Comision RackSpace Fail");
					}
				 }
			} catch (Exception e) {
				LOGGER.error("Error al tratar de desencriptar el archivo comision : ".concat(this.fileName));
				LOGGER.error(e.toString());
			} finally {
				pgpFileProcessorRS = null;
				pgpFileProcessorLZ = null;
			}
			
		}else if(this.fileType.equals("Baloto")) {
			try {
				if (this.unifierFlag.equals("0")) {
				pgpFileProcessorRS.setInputFileName( this.pathDownloadBaloto2.concat("\\" + this.fileName + ".PGP"));
				pgpFileProcessorRS.setOutputFileName(this.pathDownloadBaloto2.concat("\\" + this.fileName));
				pgpFileProcessorRS.setSecretKeyFileName(this.keyPrivateATHPGP);
				pgpFileProcessorRS.setRing(ring);
				if (pgpFileProcessorRS.decrypt()) {
					LOGGER.info("Se desencripto correctamente el archivo Baloto RackSpace:".concat(this.fileName));
				} else {
					throw new Exception("Decrypt Baloto RackSpace Fail");
				}
				pgpFileProcessorLZ.setInputFileName( this.pathDownloadBaloto1.concat("\\" + this.fileName + ".PGP"));
				pgpFileProcessorLZ.setOutputFileName(this.pathDownloadBaloto1.concat("\\" + this.fileName));
				pgpFileProcessorLZ.setSecretKeyFileName(this.keyPrivateATHPGP);
				pgpFileProcessorLZ.setRing(ring);
				if (pgpFileProcessorLZ.decrypt()) {
					LOGGER.info("Se desencripto correctamente el archivo Baloto LandingZone:".concat(this.fileName));
				} else {
					throw new Exception("Decrypt Baloto LandingZone Fail");
				}
				}else if (this.unifierFlag.equals("1")) {
					
				pgpFileProcessorLZ.setInputFileName( this.pathDownloadBaloto1.concat("\\" + this.fileName + ".PGP"));
				pgpFileProcessorLZ.setOutputFileName(this.pathDownloadBaloto1.concat("\\" + this.fileName));
				pgpFileProcessorLZ.setSecretKeyFileName(this.keyPrivateATHPGP);
				pgpFileProcessorLZ.setRing(ring);
				if (pgpFileProcessorLZ.decrypt()) {
					LOGGER.info("Se desencripto correctamente el archivo :".concat(this.fileName));
				} else {
					throw new Exception("Decrypt Fail");
				}	
			 }
			 	else if (this.unifierFlag.equals("2")) {
					
					pgpFileProcessorRS.setInputFileName( this.pathDownloadBaloto2.concat("\\" + this.fileName + ".PGP"));
					pgpFileProcessorRS.setOutputFileName(this.pathDownloadBaloto2.concat("\\" + this.fileName));
					pgpFileProcessorRS.setSecretKeyFileName(this.keyPrivateATHPGP);
					pgpFileProcessorRS.setRing(ring);
					if (pgpFileProcessorRS.decrypt()) {
						LOGGER.info("Se desencripto correctamente el archivo Baloto RackSpace:".concat(this.fileName));
					} else {
						throw new Exception("Decrypt Baloto RackSpace Fail");
					}	
				}
			} catch (Exception e) {
				LOGGER.error("Error al tratar de desencriptar el archivo Baloto: ".concat(this.fileName));
				LOGGER.error(e.toString());
			} finally {
				pgpFileProcessorRS = null;
				pgpFileProcessorLZ = null;
			}
			
		}else if(this.fileType.equals("Recaudo")) {
			try {
				if(this.sPName.equals("BBOGTC")) {
					pgpFileProcessorLZ.setInputFileName( this.pathDownloadRecaudo1.concat("\\" + this.fileName + ".PGP"));
					pgpFileProcessorLZ.setOutputFileName(this.pathDownloadBBTAClaro.concat("\\" + this.fileName));
					pgpFileProcessorLZ.setPassphrase(this.pasPrivKey);
					pgpFileProcessorLZ.setPublicKeyFileName(this.PublicFirm);
					pgpFileProcessorLZ.setSecretKeyFileName(this.PrivatePGP);
					if (pgpFileProcessorLZ.decryptfirm()) {
						LOGGER.info("Se desencripto correctamente el archivo :".concat(this.fileName));
					} else {
						throw new Exception("Decrypt Fail");
					}
				}
				else {
					pgpFileProcessorLZ.setInputFileName( this.pathDownloadRecaudo1.concat("\\" + this.fileName + ".PGP"));
					pgpFileProcessorLZ.setOutputFileName(this.pathDownloadRecaudo1.concat("\\" + this.fileName));
					pgpFileProcessorLZ.setSecretKeyFileName(this.keyPrivateATHPGP);
					pgpFileProcessorLZ.setRing(ring);
					if (pgpFileProcessorLZ.decrypt()) {
						LOGGER.info("Se desencripto correctamente el archivo :".concat(this.fileName));
					} else {
						throw new Exception("Decrypt Fail");
					}
				}
					
			 
			} catch (Exception e) {
				LOGGER.error("Error al tratar de desencriptar el archivo : ".concat(this.fileName));
				LOGGER.error(e.toString());
			} finally {
				pgpFileProcessorRS = null;
				pgpFileProcessorLZ = null;
			}
		}else if(this.fileType.equals("BI")) {
			try {
				if (this.unifierFlag.equals("0")) {
				pgpFileProcessorRS.setInputFileName( this.pathDownloadBI2.concat("\\" + this.fileNameBIRS + ".PGP"));
				pgpFileProcessorRS.setOutputFileName(this.pathDownloadBI2.concat("\\" + this.fileNameBIRS));
				pgpFileProcessorRS.setSecretKeyFileName(this.keyPrivateATHPGP);
				pgpFileProcessorRS.setRing(ring);
				if (pgpFileProcessorRS.decrypt()) {
					LOGGER.info("Se desencripto correctamente el archivo BI RackSpace:".concat(this.fileNameBIRS));
				} else {
					throw new Exception("Decrypt BI RackSpace Fail");
				}
				pgpFileProcessorLZ.setInputFileName( this.pathDownloadBI1.concat("\\" + this.fileName + ".PGP"));
				pgpFileProcessorLZ.setOutputFileName(this.pathDownloadBI1.concat("\\" + this.fileName));
				pgpFileProcessorLZ.setSecretKeyFileName(this.keyPrivateATHPGP);
				pgpFileProcessorLZ.setRing(ring);
				if (pgpFileProcessorLZ.decrypt()) {
					LOGGER.info("Se desencripto correctamente el archivo BI LandingZone:".concat(this.fileName));
				} else {
					throw new Exception("Decrypt BI LandingZone Fail");
				}
				}else if (this.unifierFlag.equals("1")) {
					
				pgpFileProcessorLZ.setInputFileName( this.pathDownloadBI1.concat("\\" + this.fileName + ".PGP"));
				pgpFileProcessorLZ.setOutputFileName(this.pathDownloadBI1.concat("\\" + this.fileName));
				pgpFileProcessorLZ.setSecretKeyFileName(this.keyPrivateATHPGP);
				pgpFileProcessorLZ.setRing(ring);
				if (pgpFileProcessorLZ.decrypt()) {
					LOGGER.info("Se desencripto correctamente el archivo :".concat(this.fileName));
				} else {
					throw new Exception("Decrypt Fail");
				}	
			 }
				else if (this.unifierFlag.equals("2")) {
					
					pgpFileProcessorRS.setInputFileName( this.pathDownloadBI2.concat("\\" + this.fileNameBIRS + ".PGP"));
					pgpFileProcessorRS.setOutputFileName(this.pathDownloadBI2.concat("\\" + this.fileNameBIRS));
					pgpFileProcessorRS.setSecretKeyFileName(this.keyPrivateATHPGP);
					pgpFileProcessorRS.setRing(ring);
					if (pgpFileProcessorRS.decrypt()) {
						LOGGER.info("Se desencripto correctamente el archivo BI RackSpace:".concat(this.fileNameBIRS));
					} else {
						throw new Exception("Decrypt BI RackSpace Fail");
					}
				 }
			} catch (Exception e) {
				LOGGER.error("Error al tratar de desencriptar el archivo BI: ".concat(this.fileName));
				LOGGER.error(e.toString());
			} finally {
				pgpFileProcessorRS = null;
				pgpFileProcessorLZ = null;
			}
			
		}
		return RepeatStatus.FINISHED;
	}

}
