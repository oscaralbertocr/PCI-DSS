package co.com.ath.pgw.batch;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.batch.core.StepContribution;
import org.springframework.batch.core.configuration.annotation.StepScope;
import org.springframework.batch.core.scope.context.ChunkContext;
import org.springframework.batch.core.step.tasklet.Tasklet;
import org.springframework.batch.repeat.RepeatStatus;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import co.com.ath.pgw.util.PGPFileProcessor;
import co.com.ath.pgw.util.Utils;

/**
 * 
 * custom Exception.
 *
 * @author Jesus Octavio Avendaño Sierra <jesus.avendano@sophossolutions.com> 
 * @version 1.0 16/15/2019
 * 
 * @sophosSolutions
 * <strong>Autor: </strong>Jesus Octavio Avendaño Sierra</br>
 * <strong>Numero de Cambios: </strong>0</br>
 * 
 * 	
*/

@Service
@StepScope
public class EncryptTasklet implements Tasklet{
	
	static Logger LOGGER = LoggerFactory.getLogger(EncryptTasklet.class);

	@Value("#{jobParameters[fileName]}")
	private String fileName;

	@Value("#{jobParameters[destinyComision]}")
	private String destinyComision;
	
	@Value("#{jobParameters[destinyBaloto]}")
	private String destinyBaloto;
	@Value("#{jobParameters[destinyBI]}")
	private String destinyBI;
	
	@Value("#{jobParameters[destinyRecaudo]}")
	private String destinyRecaudo;
	
	@Value("#{jobParameters[KeyPublicPGPComisionBOG]}")
	private String KeyPublicPGPComisionBOG;
	
	@Value("#{jobParameters[KeyPublicPGPComisionOCC]}")
	private String KeyPublicPGPComisionOCC;
	
	@Value("#{jobParameters[KeyPublicPGPComisionAVV]}")
	private String KeyPublicPGPComisionAVV;
	
	@Value("#{jobParameters[KeyPublicPGPComisionPOP]}")
	private String KeyPublicPGPComisionPOP;
	
	@Value("#{jobParameters[KeyPublicPGPBaloto]}")
	private String KeyPublicPGPBaloto;
	@Value("#{jobParameters[KeyPublicPGPBI]}")
	private String KeyPublicPGPBI;
	
	@Value("#{jobParameters[KeyPublicPGPRecaudo]}")
	private String KeyPublicPGPRecaudo;
	
	@Value("#{jobParameters[fileType]}")
	private String fileType;
	
	@Value("#{jobParameters[sPName]}")
	private String sPName;
	
	@Value("${report.zip}")
	private String conveniosZip;
	
	@Value("${report.zipName}")
	private String zipName;
	
	@Value("#{jobParameters[keyPGPBogota]}")
	private String keyPGPBogota;
	
	@Value("#{jobParameters[frassSecretKeyBBTA]}")
	private String frassSecretKeyBBTA;
	
	@Value("#{jobParameters[PublicFirm]}")
	private String PublicFirm;	
	
    @Autowired(required = true)
    Utils util;
	
	@Override
	public RepeatStatus execute(StepContribution contribution, ChunkContext chunkContext) throws Exception {
		PGPFileProcessor pgpFileProcessor = new PGPFileProcessor();
		if(this.fileType.equals("Comision")) {
			try {
				pgpFileProcessor.setInputFileName( this.destinyComision.concat("\\" + this.fileName));
				pgpFileProcessor.setOutputFileName(this.destinyComision.concat("\\" + this.fileName + ".PGP"));
				if(this.fileName.startsWith("BBOG")) {
					pgpFileProcessor.setPublicKeyFileName(this.KeyPublicPGPComisionBOG);
				}else if(this.fileName.startsWith("BOCC")) {
					pgpFileProcessor.setPublicKeyFileName(this.KeyPublicPGPComisionOCC);
				}else if(this.fileName.startsWith("BAVV")) {
					pgpFileProcessor.setPublicKeyFileName(this.KeyPublicPGPComisionAVV);
				}else if(this.fileName.startsWith("BPOP")) {
					pgpFileProcessor.setPublicKeyFileName(this.KeyPublicPGPComisionPOP);
				}
				
				if (pgpFileProcessor.encrypt()) {
					LOGGER.info("Se encripto correctamente el archivo :{}",	this.fileName);
				} else {
					throw new Exception("Encrypt Fail");
				}
			} catch (Exception e) {
				LOGGER.error("Error al tratar de encriptar el archivo a PGP : {}", this.fileName);
				LOGGER.error(e.toString());
			} finally {
				pgpFileProcessor = null;
			}
		}else if(this.fileType.equals("Baloto")) {
			try {
				pgpFileProcessor.setInputFileName( this.destinyBaloto.concat("\\" + this.fileName));
				pgpFileProcessor.setOutputFileName(this.destinyBaloto.concat("\\" + this.fileName + ".PGP"));
				pgpFileProcessor.setPublicKeyFileName(this.KeyPublicPGPBaloto);
				
				if (pgpFileProcessor.encrypt()) {
					LOGGER.info("Se encripto correctamente el archivo :{}", this.fileName);
				} else {
					throw new Exception("Encrypt Fail");
				}
			} catch (Exception e) {
				LOGGER.error("Error al tratar de encriptar el archivo a PGP : ".concat(this.fileName));
				LOGGER.error(e.toString());
			} finally {
				pgpFileProcessor = null;
			}
		}else if(this.fileType.equals("Recaudo")) {
			try {
				if(this.shouldCompress()) {
					String fileCompressed = this.generateZip(zipName, this.sPName, this.destinyRecaudo, this.destinyRecaudo.concat("\\" + this.fileName), this.fileName);
					LOGGER.info("Se creo correctamente el archivo :{}",fileCompressed);
				}else if(this.sPName.equals("BBOGTC")) {
					pgpFileProcessor.setInputFileName( this.destinyRecaudo.concat("\\" + this.fileName));
					pgpFileProcessor.setOutputFileName(this.destinyRecaudo.concat("\\" + this.fileName + ".PGP"));	
					pgpFileProcessor.setSecretKeyFileName(this.PublicFirm);
					pgpFileProcessor.setRing(this.frassSecretKeyBBTA);					
					
					pgpFileProcessor.setPublicKeyFileName(this.keyPGPBogota);
										
					if (pgpFileProcessor.signEncrypt()) {
						LOGGER.info("Se encripto y firmo correctamente el archivo :{}", this.fileName);
					} else {
						throw new Exception("Encrypt Fail");
					}
				}else {
					pgpFileProcessor.setInputFileName( this.destinyRecaudo.concat("\\" + this.fileName));
					pgpFileProcessor.setOutputFileName(this.destinyRecaudo.concat("\\" + this.fileName + ".PGP"));
					pgpFileProcessor.setPublicKeyFileName(this.KeyPublicPGPRecaudo);
					if (pgpFileProcessor.encrypt()) {
						LOGGER.info("Se encripto correctamente el archivo :{}", this.fileName);
					} else {
						throw new Exception("Encrypt Fail");
					}
				}
			} catch (Exception e) {
				LOGGER.error("Error al tratar de encriptar el archivo a PGP : {} {} ", this.fileName ,e);
			} finally {
				pgpFileProcessor = null;
			}
		}else if(this.fileType.equals("BI")) {
			try {
				pgpFileProcessor.setInputFileName( this.destinyBI.concat("\\" + this.fileName));
				pgpFileProcessor.setOutputFileName(this.destinyBI.concat("\\" + this.fileName + ".PGP"));
				pgpFileProcessor.setPublicKeyFileName(this.KeyPublicPGPBI);
				
				if (pgpFileProcessor.encrypt()) {
					LOGGER.info("Se encripto correctamente el archivo :{}", this.fileName);
				} else {
					throw new Exception("Encrypt Fail");
				}
			} catch (Exception e) {
				LOGGER.error("Error al tratar de encriptar el archivo a PGP : ".concat(this.fileName));
				LOGGER.error(e.toString());
			} finally {
				pgpFileProcessor = null;
			}
		}
		
		return RepeatStatus.FINISHED;
	}

	/**
	 * Metodo que crea reporte en zip segun convenio
	 * @param zipName
	 * @param obligaciones
	 * @param fileReport 
	 */
	private String generateZip(String zipName, String obligaciones, String finalPath, String filePath, String fileName) {
		try {
			return util.generaZip(zipName,obligaciones,finalPath ,filePath, fileName);			
		} catch (Exception e) {
			LOGGER.error("Error al tratar crear el reporte zip : ".concat(this.fileName+ " Convenio: " + this.sPName));
			e.printStackTrace();
			return null;
		}		
	}
	
	private boolean shouldCompress() {
		boolean response = false;
		String[] listCompress = this.conveniosZip.split(",");
		for(String item : listCompress) {
			if(this.sPName.equals(item)) {
				response = true;
				break;
			}	
		}
		return response;
	}
	
}
