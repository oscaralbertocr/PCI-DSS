package co.com.ath.pgw.util;

import java.io.BufferedOutputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.Vector;
import java.util.Properties;

import org.apache.commons.net.ftp.FTP;
import org.apache.commons.net.ftp.FTPFile;
import org.apache.commons.net.ftp.FTPSClient;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;

import com.jcraft.jsch.Channel;
import com.jcraft.jsch.ChannelSftp;
import com.jcraft.jsch.ChannelSftp.LsEntry;
import com.jcraft.jsch.JSch;
import com.jcraft.jsch.Session;
import com.jcraft.jsch.SftpATTRS;

import co.com.ath.pgw.srv.UnifierManagementFacade;
/**
 * Permite la conexion a un recurso FTP, SSH,
 *
 *
 * @author Jesus Octavio Avendaño Sierra <jesus.avendano@sophossolutions.com> 
 * @version 1.0 16/15/2019
 * 
 * @sophosSolutions
 * <strong>Autor: </strong>Jesus Octavio Avendaño Sierra</br>
 * <strong>Numero de Cambios: </strong>0</br>
 * 	
*/ 
public class FTPconnection {
	
	@Autowired
	Environment env;

	static Logger LOGGER = LoggerFactory.getLogger(UnifierManagementFacade.class);	

	private FTPSClient  connFTP = null;
	private ChannelSftp connSSH = null;
	@SuppressWarnings("unused")
	private String directory = null;
	private boolean connecOnSSH = false;
	private Integer port = (Integer) null;

	private String server;

	private String userName;

	private String password;

	
	/**
	 * inicializa los parametros para la conexion al recurso.
	 * @param srv
	 * 			srvr al que se desea conectar
	 * @param unam
	 * 			persona registrada para la conexion
	 * @param pas
	 * 			pas para establecer la conexion
	 * @param str
	 * 			ruta dentro del srvr FTP desde donde se desea descargar los archivos
	 * @param prt
	 * 			puerto requerido para establecer la conexion
	 * @param mode
	 * 			tipo de conexion a establecer, 0: S, Normal; 1: SH
	*/
	public FTPconnection(String srv,String unam,String pas,String str,String prt, int modeConnectionFtp) throws Exception {
		this.server = srv;
		this.userName = unam;
		this.password = pas;
		this.directory = str;
		this.port = Integer.parseInt(prt);
		try {
			switch (modeConnectionFtp) {
				case 0:
					this.connecOnSSH = false;
					this.connFTP = this.connectOnFTP();				
					break;
				case 1:
					this.connecOnSSH = true;
					this.connSSH = this.connectOnSSH();
					break;
				default:
					break;
			}
		} catch (Exception e) {
			throw new Exception(e.getMessage());
		}
	}

	
	/**
	 * Realiza la conexión a un recurso FTP.
	*/
	private FTPSClient connectOnFTP() throws Exception {
		try {
			FTPSClient ftp = new FTPSClient("TLS");
			LOGGER.info("Iniciando la conexion con el servidor FTP");
			ftp.connect(this.server,this.port);
			if(ftp.login(this.userName, this.password)) {
				LOGGER.info("Conexion Correcta");
				ftp.enterLocalPassiveMode();
				ftp.changeWorkingDirectory(this.directory);
			}else{
				LOGGER.info("Conexion Fallida");
				throw new Exception("Usuario o contrasena del FTP incorrectos");
			}
			return ftp;
		} catch (Exception e) {
			LOGGER.error("Error al tratar de conectar con el FTP: ", e);
			throw new Exception("Error al tratar de conectar con el FTP: "+ e.getMessage());
		}
	}
	
	/**
	 * Realiza la conexión a un recurso SSH.
	*/
	private ChannelSftp connectOnSSH() throws Exception {
		try {
			JSch jsch = new JSch();
			Session session = jsch.getSession( this.userName, this.server, this.port );
			session.setConfig( "PreferredAuthentications", "password" );
			session.setPassword( this.password );
			Properties config = new Properties();
			config.put("StrictHostKeyChecking", "no");
			session.setConfig(config);
			LOGGER.info("Iniciando la conexion con el servidor SSH");
			session.connect();
			Channel channel = session.openChannel( "sftp" );
			ChannelSftp ssh = ( ChannelSftp ) channel;
			ssh.connect();
			LOGGER.info("Conectado al SSH: {}", this.server);
			ssh.cd(directory);
			return ssh;
		} catch (Exception e) {
			LOGGER.error("Error al tratar de conectar con el servidor SSH: ", e);
			throw new Exception("Error al tratar de conectar con el servidor SSH: "+ e.getMessage());
		}
	}

	/**
	 * Lista los archivos destro de la carpeta actual del FTP.
	*/
	public void listFiles(){
		try {
			if(!this.connecOnSSH) {
				FTPFile[] ftpFiles = this.connFTP.listFiles();  
				if (ftpFiles != null && ftpFiles.length > 0) {
					//loop thru files
					for (FTPFile file : ftpFiles) {
						if (file.isFile()) {
							LOGGER.info("File is {}", file.getName());
						} else if (file.isDirectory()){
							LOGGER.info("Directory is {}", file.getName());
						}
					}
				}
			}else {
				LOGGER.info("Directory is {}", this.connSSH.pwd());
				Vector<?> filelist = this.connSSH.ls(".");
				for(int i=0; i<filelist.size();i++){
					LsEntry entry = (LsEntry) filelist.get(i);
					LOGGER.info("File {}", entry.getFilename());
				}
			}
		} catch (Exception e) {
			LOGGER.error(e.toString());
		}
		
	}
	/**
	 * Descarga un archivo de la conexion actual, y lo ubica en una ruta especifica.
	 * 
	 * @param
	 * 		destination
	 * 				carpeta de destino donde se colocara el archivo descargado
	 * 		fileToDownload
	 * 				Nombre del archivo que se debe descargar
	*/
	public void downloadFile(String destination, String fileToDownload){
		try {
			String outDest = destination + "\\" + fileToDownload; 
			BufferedOutputStream outStream = new BufferedOutputStream(new FileOutputStream(outDest));
			if(!this.connecOnSSH) {
				LOGGER.info("Se descargara desde la carpeta: {}", this.connFTP.printWorkingDirectory());
				LOGGER.info("El archivo: {}", fileToDownload);
				try {
					this.connFTP.setFileType(FTP.BINARY_FILE_TYPE);
					if(this.connFTP.retrieveFile(fileToDownload, outStream)) {
						LOGGER.info("Descarga correcta");	    	
					} else {
						LOGGER.info("Error Descarga");
					}
				} catch (Exception e) {
					LOGGER.info(e.toString());
				}
			}else {
				LOGGER.info("Se descargara desde la carpeta: {}", this.connSSH.pwd());
				LOGGER.info("El archivo: {}", fileToDownload);
				this.connSSH.get(fileToDownload , outStream);
				LOGGER.info("Descarga correcta");
			}
			outStream.close();
		} catch (Exception e) {
			LOGGER.error("Error Descarga", e);
		}
	}

	/**
	 * Cierra la conexion.
	*/
	public void close() {
		try {
			if(!connecOnSSH)
				this.connFTP.disconnect();
			else
				this.connSSH.disconnect();
		} catch (IOException e) {
			LOGGER.error("Error close", e);
		}
	}
	
	/**
	 * Verifica si existe un archivo en el servidor
	*/
	public boolean existsFile(String fileToDownload) {
		boolean existe = false;
		try {
			if(!this.connecOnSSH) {
				FTPFile[] ftpFiles = this.connFTP.listFiles(fileToDownload);  
				if (ftpFiles != null && ftpFiles.length > 0) {
					existe = true;
				}
			} else {
				SftpATTRS fileList = this.connSSH.stat(fileToDownload);
				if (fileList != null) {
					existe = true;
				}
			}
			return existe;
		} catch (Exception e) {
			LOGGER.error("Error existsFile", e);
			return false;
		}
	}

}