
package co.com.ath.pgw.client.tokenize.dto;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlSeeAlso;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Clase Java para TokenizedDtInfoRs_Type complex type.
 * 
 * <p>El siguiente fragmento de esquema especifica el contenido que se espera que haya en esta clase.
 * 
 * <pre>
 * &lt;complexType name="TokenizedDtInfoRs_Type"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element ref="{urn://ath.com.co/xsd/common/}Protect"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "TokenizedDtInfoRs_Type", propOrder = {
    "protect"
})
@XmlSeeAlso({
    TokenizedDataInfoRsType.class
})
public class TokenizedDtInfoRsType {

    @XmlElement(name = "Protect", required = true, namespace = "urn://ath.com.co/xsd/common/")
    protected ProtectType protect;

    /**
     * Obtiene el valor de la propiedad protect.
     * 
     * @return
     *     possible object is
     *     {@link ProtectType }
     *     
     */
    public ProtectType getProtect() {
        return protect;
    }

    /**
     * Define el valor de la propiedad protect.
     * 
     * @param value
     *     allowed object is
     *     {@link ProtectType }
     *     
     */
    public void setProtect(ProtectType value) {
        this.protect = value;
    }

}
