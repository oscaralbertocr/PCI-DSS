#  Script para generar la contingencia de los reportes del artefacto pgw-generateReport

PROPERTY=urlContingencia
PROPERTYFILE="D:/pgw-core-config/pgw-reportGenerator.properties"

function _menuPrincipal()
{
    clear
    echo "----------GENERACION REPORTE POR CONTINGENCIA----------"
    echo ""
    echo "1) Liquidacion de Comisiones"
    echo "2) Asobancaria"
    echo "3) Reportes Parciales"
    echo "4) Salir"
    echo
    echo -n "Indica una opcion: "
}

function _menuComisiones()
{
    clear
    echo "----------CONTINGENCIA LIQUIDACION DE COMISIONES----------"
    echo ""
    echo "1) Contingencia Diaria"
    echo "2) Contingencia Mensual"
    echo "3) Volver"
    echo
    echo -n "Indica una opcion: "
}

function _menuAsobancaria()
{
    clear
    echo "----------CONTINGENCIA ASOBANCARIA----------"
    echo ""
    echo "1) O0201"
    echo "2) O0202"
    echo "3) O0203"
    echo "4) O0204"
    echo "5) O0205"
    echo "6) O0208"
    echo "7) O0210"
    echo "8) O0211"
    echo "9) O0212"
    echo "10) O0213"
    echo "11) O0206"
    echo "12) O0216"
    echo "13) 00000104"
    echo "14) O0209"
    echo "15) O0214"
    echo "16) Volver"
    echo
    echo -n "Seleccione un convenio: "
}

function _menuParciales()
{
    clear
    echo "----------CONTINGENCIA REPORTES PARCIALES----------"
    echo ""
    echo "1) Generar Reporte Parcial"
    echo "2) Generar Reporte Completo"
    echo "3) Volver"
    echo
    echo -n "Indica una opcion: "
}

function _menuEntidades()
{
    clear
    echo "----------ENTIDADES LIQUIDACION DE COMISIONES----------"
    echo ""
    echo "1) Banco AV Villas"
    echo "2) Banco de Bogota"
    echo "3) Banco Popular"
    echo "4) Banco de Occidente"
    echo "5) Volver"
    echo
    echo -n "Seleccione una entidad: "
}


function _consumoServicio()
{
    var_nombre="{\"File\":{\"FileId\":\"$var_tipoReporte\",\"FileType\":\"$var_tipoContingencia\",\"FileName\":\"$var_nombre\",\"FileDesc\":\"O0204\",\"SPName\":\"string\",\"FileStatus\":\"prueba\",\"FileRqDt\":\"2019-05-10T15:26:00.741Z\"}}"

    curl -d $var_nombre  -H 'Content-Type:application/json' -H 'X-RqUID:13' -H 'X-Channel:1' -H 'X-IPAddr:1.1.1.1' $url/pgw-generateReport/transferManagement/initTransfer
}

function getProperty {
   PROPKEY=$1
   PROPVALUE=`cat $PROPERTYFILE | grep "$PROPKEY" | cut -d'=' -f2`
   echo $PROPVALUE
}

url="$(getProperty $PROPERTY)"
opc=0
until [ $opc -eq 4 ]
do
    case $opc in
        1)
            #Reporte liquidacion de comisiones
            var_tipoReporte='1'
            opc1=0
            until [ $opc1 -eq 3 ]
            do
                case $opc1 in
                    1)
                        opc1=0
                            var_validDateCD='^[0-9]{4}[/][0-9]{2}[/][0-9]{2}$' # variable para el formato de la fecha
                            var_tipoContingencia='CD'
                            until [ $opc1 -eq 5 ]
                            do
                                case $opc1 in
                                    1)  
                                        read -p "Introduzca la fecha con la siguiente estructura (yyyy/MM/dd):" fechaGeneracion
                                        if [[ $fechaGeneracion =~ $var_validDateCD ]]; then 
                                            fechaGeneracion="${fechaGeneracion///}" 
                                            var_nombre="BAVV_Pagos_PortalDePagos_$fechaGeneracion"
                                            echo ""                                                                              
                                            echo "Inicio Contingencia "$var_nombre
                                            echo ""
                                            _consumoServicio 
                                            echo ""
                                            echo 'Ejecucion Terminada'
                                        else
                                            echo 'Formato de fecha no Valido'
                                        fi
                                        ;;
                                    2)
                                        read -p "Introduzca la fecha con la siguiente estructura (yyyy/MM/dd):" fechaGeneracion                                        
                                        if [[ $fechaGeneracion =~ $var_validDateCD ]]; then                            
                                            fechaGeneracion="${fechaGeneracion///}" 
                                            var_nombre="BBOG_Pagos_PortalDePagos_$fechaGeneracion"
                                            echo ""                                                                              
                                            echo "Inicio Contingencia "$var_nombre
                                            echo ""
                                            _consumoServicio 
                                            echo ""
                                            echo 'Ejecucion Terminada'
                                        else
                                            echo 'Formato de fecha no Valido'
                                        fi
                                        ;;
                                    3)
                                        read -p "Introduzca la fecha con la siguiente estructura (yyyy/MM/dd):" fechaGeneracion
                                        if [[ $fechaGeneracion =~ $var_validDateCD ]]; then                            
                                            fechaGeneracion="${fechaGeneracion///}" 
                                            var_nombre="BPOP_Pagos_PortalDePagos_$fechaGeneracion"
                                            echo ""                                                                              
                                            echo "Inicio Contingencia "$var_nombre
                                            echo ""
                                            _consumoServicio 
                                            echo ""
                                            echo 'Ejecucion Terminada'
                                        else
                                            echo 'Formato de fecha no Valido'
                                        fi                                        
                                        ;;
                                    4)
                                        read -p "Introduzca la fecha con la siguiente estructura (yyyy/MM/dd):" fechaGeneracion
                                        if [[ $fechaGeneracion =~ $var_validDateCD ]]; then   
                                            fechaGeneracion="${fechaGeneracion///}"                      
                                            var_nombre="BOCC_Pagos_PortalDePagos_$fechaGeneracion"
                                            echo ""                                                                              
                                            echo "Inicio Contingencia "$var_nombre
                                            echo ""
                                            _consumoServicio 
                                            echo ""
                                            echo 'Ejecucion Terminada'
                                        else
                                            echo 'Formato de fecha no Valido'
                                        fi 
                                        ;;                                                                                
                                    *)
                                        _menuEntidades
                                        ;;
                                esac
                                read opc1
                            done
                            _menuComisiones
                        ;;
                    2)
                        opc1=0
                            var_validDateCM='^[0-9]{4}[/][0-9]{2}$' # variable para el formato de la fecha
                            var_tipoContingencia='CM'
                            until [ $opc1 -eq 5 ]
                            do
                                case $opc1 in
                                    1)  
                                        read -p "Introduzca la fecha con la siguiente estructura (yyyy/MM):" fechaGeneracion
                                        if [[ $fechaGeneracion =~ $var_validDateCM ]]; then  
                                            fechaGeneracion="${fechaGeneracion///}"                           
                                            var_nombre="BAVV_Pagos_PortalDePagos_$fechaGeneracion"
                                            echo ""                                                                              
                                            echo "Inicio Contingencia "$var_nombre
                                            echo ""
                                            _consumoServicio 
                                            echo ""
                                            echo 'Ejecucion Terminada'
                                        else
                                            echo 'Formato de fecha no Valido'
                                        fi 
                                        ;;
                                    2)
                                        read -p "Introduzca la fecha con la siguiente estructura (yyyy/MM):" fechaGeneracion
                                        if [[ $fechaGeneracion =~ $var_validDateCM ]]; then 
                                            fechaGeneracion="${fechaGeneracion///}"                            
                                            var_nombre="BOCC_Pagos_PortalDePagos_$fechaGeneracion"
                                            echo ""                                                                              
                                            echo "Inicio Contingencia "$var_nombre
                                            echo ""
                                            _consumoServicio 
                                            echo ""
                                            echo 'Ejecucion Terminada'
                                        else
                                            echo 'Formato de fecha no Valido'
                                        fi 
                                        ;;
                                    3)
                                        read -p "Introduzca la fecha con la siguiente estructura (yyyy/MM):" fechaGeneracion
                                        if [[ $fechaGeneracion =~ $var_validDateCM ]]; then  
                                            fechaGeneracion="${fechaGeneracion///}"                           
                                            var_nombre="BPOP_Pagos_PortalDePagos_$fechaGeneracion"
                                            echo ""                                                                              
                                            echo "Inicio Contingencia "$var_nombre
                                            echo ""
                                            _consumoServicio 
                                            echo ""
                                            echo 'Ejecucion Terminada'
                                        else
                                            echo 'Formato de fecha no Valido'
                                        fi                                        
                                        ;;
                                    4)
                                        read -p "Introduzca la fecha con la siguiente estructura (yyyy/MM):" fechaGeneracion
                                        if [[ $fechaGeneracion =~ $var_validDateCM ]]; then   
                                            fechaGeneracion="${fechaGeneracion///}"                          
                                            var_nombre="BOCC_Pagos_PortalDePagos_$fechaGeneracion"
                                            echo ""                                                                              
                                            echo "Inicio Contingencia "$var_nombre
                                            echo ""
                                            _consumoServicio 
                                            echo ""
                                            echo 'Ejecucion Terminada'
                                        else
                                            echo 'Formato de fecha no Valido'
                                        fi  
                                        ;;                                                                                
                                    *)
                                        _menuEntidades
                                        ;;
                                esac
                                read opc1
                            done
                            _menuComisiones
                            ;;
                    *)
                        _menuComisiones
                        ;;
                esac
                read opc1
            done
            _menuPrincipal
            ;;
        2)
            #Reporte Asobancaria
            var_tipoReporte='2'
            var_validDate='^[0-9]{2}[/][0-9]{2}[/][0-9]{4}$' # variable para el formato de la fecha
            opc2=0
            until [ $opc2 -eq 16 ]
            do
                case $opc2 in
                    1)                    
                        var_tipoContingencia='O0201'
                        read -p "Introduzca la fecha con la siguiente estructura (dd/MM/yyyy):" fechaGeneracion
                        if [[ $fechaGeneracion =~ $var_validDate ]]; then                           
                            var_nombre=$fechaGeneracion
                            echo "" 
                            echo "Inicio generación del archivo para el convenio "$var_tipoContingencia
                            echo ""
                            _consumoServicio 
                            echo ""
                            echo 'Ejecucion Terminada'
                        else
                            echo 'Formato de fecha no Valido'
                        fi 
                        ;;
                    2)
                        var_tipoContingencia='O0202'
                        read -p "Introduzca la fecha con la siguiente estructura (dd/MM/yyyy):" fechaGeneracion
                        if [[ $fechaGeneracion =~ $var_validDate ]]; then                           
                            var_nombre=$fechaGeneracion
                            echo "" 
                            echo "Inicio generación del archivo para el convenio "$var_tipoContingencia
                            echo ""
                            _consumoServicio 
                            echo ""
                            echo 'Ejecucion Terminada'
                        else
                            echo 'Formato de fecha no Valido'
                        fi 
                        ;;
                    3)
                        var_tipoContingencia='O0203'
                        read -p "Introduzca la fecha con la siguiente estructura (dd/MM/yyyy):" fechaGeneracion
                        if [[ $fechaGeneracion =~ $var_validDate ]]; then                           
                            var_nombre=$fechaGeneracion
                            echo "" 
                            echo "Inicio generación del archivo para el convenio "$var_tipoContingencia
                            echo ""
                            _consumoServicio 
                            echo ""
                            echo 'Ejecucion Terminada'
                        else
                            echo 'Formato de fecha no Valido'
                        fi 
                        ;;
                    4)
                        var_tipoContingencia='O0204'
                        read -p "Introduzca la fecha con la siguiente estructura (dd/MM/yyyy):" fechaGeneracion
                        if [[ $fechaGeneracion =~ $var_validDate ]]; then                           
                            var_nombre=$fechaGeneracion
                            echo "" 
                            echo "Inicio generación del archivo para el convenio "$var_tipoContingencia
                            echo ""
                            _consumoServicio 
                            echo ""
                            echo 'Ejecucion Terminada'
                        else
                            echo 'Formato de fecha no Valido'
                        fi 
                        ;;
                    5)
                        var_tipoContingencia='O0205'
                        read -p "Introduzca la fecha con la siguiente estructura (dd/MM/yyyy):" fechaGeneracion
                        if [[ $fechaGeneracion =~ $var_validDate ]]; then                           
                            var_nombre=$fechaGeneracion
                            echo "" 
                            echo "Inicio generación del archivo para el convenio "$var_tipoContingencia
                            echo ""
                            _consumoServicio 
                            echo ""
                            echo 'Ejecucion Terminada'
                        else
                            echo 'Formato de fecha no Valido'
                        fi 
                        ;;
                    6)
                        var_tipoContingencia='O0208'
                        read -p "Introduzca la fecha con la siguiente estructura (dd/MM/yyyy):" fechaGeneracion
                        if [[ $fechaGeneracion =~ $var_validDate ]]; then                           
                            var_nombre=$fechaGeneracion
                            echo "" 
                            echo "Inicio generación del archivo para el convenio "$var_tipoContingencia
                            echo ""
                            _consumoServicio 
                            echo ""
                            echo 'Ejecucion Terminada'
                        else
                            echo 'Formato de fecha no Valido'
                        fi 
                        ;;
                    7)
                        var_tipoContingencia='O0210'
                        read -p "Introduzca la fecha con la siguiente estructura (dd/MM/yyyy):" fechaGeneracion
                        if [[ $fechaGeneracion =~ $var_validDate ]]; then                           
                            var_nombre=$fechaGeneracion
                            echo "" 
                            echo "Inicio generación del archivo para el convenio "$var_tipoContingencia
                            echo ""
                            _consumoServicio 
                            echo ""
                            echo 'Ejecucion Terminada'
                        else
                            echo 'Formato de fecha no Valido'
                        fi 
                        ;;
                    8)
                        var_tipoContingencia='O0211'
                        read -p "Introduzca la fecha con la siguiente estructura (dd/MM/yyyy):" fechaGeneracion
                        if [[ $fechaGeneracion =~ $var_validDate ]]; then                           
                            var_nombre=$fechaGeneracion
                            echo "" 
                            echo "Inicio generación del archivo para el convenio "$var_tipoContingencia
                            echo ""
                            _consumoServicio 
                            echo ""
                            echo 'Ejecucion Terminada'
                        else
                            echo 'Formato de fecha no Valido'
                        fi 
                        ;;
                    9)
                        var_tipoContingencia='O0212'
                        read -p "Introduzca la fecha con la siguiente estructura (dd/MM/yyyy):" fechaGeneracion
                        if [[ $fechaGeneracion =~ $var_validDate ]]; then                           
                            var_nombre=$fechaGeneracion
                            echo "" 
                            echo "Inicio generación del archivo para el convenio "$var_tipoContingencia
                            echo ""
                            _consumoServicio 
                            echo ""
                            echo 'Ejecucion Terminada'
                        else
                            echo 'Formato de fecha no Valido'
                        fi 
                        ;;
                    10)
                        var_tipoContingencia='O0213'
                        read -p "Introduzca la fecha con la siguiente estructura (dd/MM/yyyy):" fechaGeneracion
                        if [[ $fechaGeneracion =~ $var_validDate ]]; then                           
                            var_nombre=$fechaGeneracion
                            echo "" 
                            echo "Inicio generación del archivo para el convenio "$var_tipoContingencia
                            echo ""
                            _consumoServicio 
                            echo ""
                            echo 'Ejecucion Terminada'
                        else
                            echo 'Formato de fecha no Valido'
                        fi 
                        ;;
                    11)
                        var_tipoContingencia='O0206'
                        read -p "Introduzca la fecha con la siguiente estructura (dd/MM/yyyy):" fechaGeneracion
                        if [[ $fechaGeneracion =~ $var_validDate ]]; then                           
                            var_nombre=$fechaGeneracion
                            echo "" 
                            echo "Inicio generación del archivo para el convenio "$var_tipoContingencia
                            echo ""
                            _consumoServicio 
                            echo ""
                            echo 'Ejecucion Terminada'
                        else
                            echo 'Formato de fecha no Valido'
                        fi 
                        ;;
                    12)
                        var_tipoContingencia='O0216'
                        read -p "Introduzca la fecha con la siguiente estructura (dd/MM/yyyy):" fechaGeneracion
                        if [[ $fechaGeneracion =~ $var_validDate ]]; then                           
                            var_nombre=$fechaGeneracion
                            echo "" 
                            echo "Inicio generación del archivo para el convenio "$var_tipoContingencia
                            echo ""
                            _consumoServicio 
                            echo ""
                            echo 'Ejecucion Terminada'
                        else
                            echo 'Formato de fecha no Valido'
                        fi 
                        ;;
                    13)
                        var_tipoContingencia='00000104'
                        read -p "Introduzca la fecha con la siguiente estructura (dd/MM/yyyy):" fechaGeneracion
                        if [[ $fechaGeneracion =~ $var_validDate ]]; then                           
                            var_nombre=$fechaGeneracion
                            echo "" 
                            echo "Inicio generación del archivo para el convenio "$var_tipoContingencia
                            echo ""
                            _consumoServicio 
                            echo ""
                            echo 'Ejecucion Terminada'
                        else
                            echo 'Formato de fecha no Valido'
                        fi 
                        ;;
                    14)
                        var_tipoContingencia='O0209'
                        read -p "Introduzca la fecha con la siguiente estructura (dd/MM/yyyy):" fechaGeneracion
                        if [[ $fechaGeneracion =~ $var_validDate ]]; then                           
                            var_nombre=$fechaGeneracion
                            echo "" 
                            echo "Inicio generación del archivo para el convenio "$var_tipoContingencia
                            echo ""
                            _consumoServicio 
                            echo ""
                            echo 'Ejecucion Terminada'
                        else
                            echo 'Formato de fecha no Valido'
                        fi 
                        ;;
                    15)
                        var_tipoContingencia='O0214'
                        read -p "Introduzca la fecha con la siguiente estructura (dd/MM/yyyy):" fechaGeneracion
                        if [[ $fechaGeneracion =~ $var_validDate ]]; then                           
                            var_nombre=$fechaGeneracion
                            echo "" 
                            echo "Inicio generación del archivo para el convenio "$var_tipoContingencia
                            echo ""
                            _consumoServicio 
                            echo ""
                            echo 'Ejecucion Terminada'
                        else
                            echo 'Formato de fecha no Valido'
                        fi 
                        ;;                                                
                    *)
                        _menuAsobancaria
                        ;;
                esac
                read opc2
            done
            _menuPrincipal
            ;;
        3)
            #Reporte Parciales  
            var_tipoReporte='3'   
            var_validDate='^[0-9]{2}[/][0-9]{2}[/][0-9]{4}$' # variable para el formato de la fecha
            var_validNumber='^[0-9]$'
            opc3=0
            until [ $opc3 -eq 3 ]
            do
                case $opc3 in
                    1)
                        read -p "Introduzca el numero del reporte parcial a ejecutar:" numeroReporte
                        var_tipoContingencia=$numeroReporte                        
                        if [[ $var_tipoContingencia =~ $var_validNumber ]]; then    
                            echo "" 
                            read -p "Introduzca la fecha con la siguiente estructura (dd/MM/yyyy):" fechaGeneracion
                            var_nombre=$fechaGeneracion
                                if [[ $var_nombre =~ $var_validDate ]]; then                            
                                    echo "" 
                                    echo "Inicio generación del archivo completo"
                                    echo ""
                                    _consumoServicio 
                                    echo ""
                                    echo 'Ejecucion Terminada'
                                else
                                    echo 'Formato de fecha no Valido'
                                fi

                        else
                            echo 'Número no valido'
                        fi
                        ;;
                    2)
                        read -p "Introduzca la fecha con la siguiente estructura (dd/MM/yyyy):" fechaGeneracion
                        var_nombre=$fechaGeneracion
                        var_tipoContingencia='C'
                            if [[ $var_nombre =~ $var_validDate ]]; then                            
                                echo "" 
                                echo "Inicio generación del archivo completo"
                                echo ""
                                _consumoServicio 
                                echo ""
                                echo 'Ejecucion Terminada'
                            else
                                echo 'Formato de fecha no Valido'
                            fi
                        ;;                       
                    *)
                        _menuParciales
                        ;;
                esac
                read opc3
            done
            _menuPrincipal
            ;;    
        *)
            _menuPrincipal
            ;;
    esac
    read opc
done