export const environment = {
  production: true,
  host_url:'http://localhost:7001',
  URL_getHistoricTransaction:'/pgw-conciliator/conciliatorManagement/Conciliator_Trn/Trn',
  XCHANEL:'conciliator'
};
