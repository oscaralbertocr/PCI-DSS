import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable, of, ConnectableObservable } from 'rxjs';
import { catchError, map, tap, publishReplay } from 'rxjs/operators';
import { environment } from '../environments/environment';
import { Result } from './modelos/result.model';
import { DataRequestConciliation } from './modelos/DataRequestConciliation';
@Injectable({
  providedIn: 'root'
})
export class ServiceService {

  constructor(public http:HttpClient) { }

  public getHistoricTransaction(data : DataRequestConciliation) : Observable<Result> {
  
    //this.logger.log("PaymentManagementService","getHistoricTransaction","Consumiendo servicio: getHistoricTransaction",JSON.stringify(data));
    return this.http.get(
        environment.host_url+environment.URL_getHistoricTransaction +"?conciliationDate="+data.conciliationDate,
        
        {// cabeceras de la petición
          headers: new HttpHeaders({ 'Content-Type': 'application/json; charset=utf-8' ,
                                      'X-RqUID'  : data.XRqUID.toString() ,
                                      'X-Channel' : data.XChannel,
                                      'X-CompanyId' : data.XCompanyId,
                                      'X-IPAddr' : data.XIPAddr,
                                     
                                  })
        } 
      ).pipe( map((response : Result)=> response),
        tap((responseHistoric: Result) => {
          //this.logger.log("PaymentManagementService","getHistoricTransaction","ResponseHistoric: ",JSON.stringify(responseHistoric));
         }),
         catchError(this.handleErrorTrx<Result>('Result error')));  
    }
    private handleErrorTrx<T> (operation = 'operation', result?: T) {
      return (error: any): Observable<T> => {
      return of(result as T);
    };
  }
}
