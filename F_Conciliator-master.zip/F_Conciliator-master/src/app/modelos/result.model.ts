import { InvoiceInfo } from './invoiceInfo.model';

export class Result{
    constructor(
        
        public InvoiceInfo:Array<InvoiceInfo>,
        
    ){
    
    }
    
    }