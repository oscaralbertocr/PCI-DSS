

export class InvoiceInfo{
constructor(
    
    
	public pmtid:string,
	public PMTID:string,
	public statusPasarela:string,
	public datePasarela:string,
	public statusAPC:string,
	public dateAPC:string,
	public statusMarcacion:string,
	public dateMarcacion:string,
	public paymentWay:string,
	public commerce:string,
	public bankCollecter:string,
	public amount:string,	
	public reference:string,	
	public cusPasarela:string,	
	public statusPSE:string,
	public datePSE:string,	
	public amountPSE:string
	
){

}

}

