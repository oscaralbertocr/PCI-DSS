
export class DataRequestConciliation{

    /**
     * XRqUID 
    */
    XRqUID : string ;
    /**
     * XChannel 
    */
    XChannel  :   string;
    /**
     * XCompanyId 
    */
    XCompanyId  :  string ;
    /**
     * XApprovalId 
    */
    XApprovalId  :  string ;
    /**
     * XIPAddr 
    */
    XIPAddr  :  string ;
    /**
     * XIdentSerialNum 
    */
    XIdentSerialNum  :  string ;
    /**
     * XGovIssueIdentType 
    */
    XGovIssueIdentType  :  string ;
    /**
     * PmtType 
    */
   conciliationDate  :  string ;
    /**
     * StartDt 
    */
    StartDt  :  string ;
    /**
     * EndDt 
    */
    EndDt  :  string  ;    
    
    /**
     * @description
     *  Constructor de la clase
     */
    constructor() {
        
        this.XRqUID = null;
        this.XChannel = null;
        this.XCompanyId = null;
        this.XApprovalId = null;
        this.XIPAddr = null;
        this.XIdentSerialNum = null;
        this.XGovIssueIdentType = null;
        this.conciliationDate = null;
        this.StartDt = null;
        this.EndDt = null;
    
    }
}