import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-foother',
  templateUrl: './foother.component.html',
  styleUrls: ['./foother.component.css']
})
export class FootherComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
