import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { AppComponent } from './app.component';
import { ConciliatorComponent } from './conciliator/conciliator.component';


const routes: Routes = [
   { path: 'wps/portal/conciliator-aval/bienvenidos',  component: ConciliatorComponent },
  { path: '', redirectTo: 'wps/portal/conciliator-aval/bienvenidos', pathMatch: 'full' }
  
  
];



@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
