import { Component,ViewChild,TemplateRef } from '@angular/core';
import { ServiceService } from '../service.service';
import { environment } from '../../environments/environment';
import {Result}from '../modelos/result.model'
import {DataRequestConciliation}from '../modelos/DataRequestConciliation'
import {  Observable, BehaviorSubject, ConnectableObservable } from 'rxjs';
import { FormGroup, FormBuilder } from '@angular/forms';
import {formatDate} from '@angular/common';
import {NgbModal} from '@ng-bootstrap/ng-bootstrap';
@Component({
  selector: 'app-conciliator',
  templateUrl: './conciliator.component.html',
  styleUrls: ['./conciliator.component.css']
})
export class ConciliatorComponent  {
  @ViewChild('content') templateRef: TemplateRef<any>;
  open(content) {
    this.modal.open(content);
  }
  fecha:Date;
  public submitted: boolean = false;
  /** Formulario principal */
  public mainForm : FormGroup;

  constructor(public service:ServiceService,private formBuilder :FormBuilder,public modal:NgbModal) { }
  public result : Observable<Result>;
  public dataRequestConciliation : ConnectableObservable<DataRequestConciliation>;
  public padre:any=[];
  public padreVS:any=0;
  /* public colaboradores:Colaborador[]=[]; */
  public mostrar1:boolean=false;
  public mostrar2:boolean=false;
  public mostrar3:boolean=false;
  public mostrar4:boolean=false;
  public checkLoaderAvailable : boolean=false;
  public onSubmit() {
  
    if((this.fecha==null ||this.fecha==undefined )){
      this.open(this.templateRef);
    return false;
  }
  this.checkLoaderAvailable=true;
  
  let date =formatDate(this.fecha, 'dd/MM/yyyy','en-US');
      //let date = this.getValueControl('conciliationDate');
 this.setConciliationTransaction(date)

  }
  
    public setConciliationTransaction(date){
      
      let header =  new DataRequestConciliation();
      
        header.XChannel = '15';
        header.XCompanyId = "Conciliador";
        header.XIPAddr="1.0.0.0";
        header.XRqUID = this.generateRqid().toString();
       
     header.conciliationDate = date;
    try {
      this.service.getHistoricTransaction(header).forEach(data=>{
        this.checkLoaderAvailable=false;
        
        if((data==null ||data==undefined )){
          this.open(this.templateRef);
          return false;
      }else{
        if((data.InvoiceInfo==null ||data.InvoiceInfo==undefined )){
          this.open(this.templateRef);
          return false;
      }else{
        this.padre=data.InvoiceInfo;
        this.mostrar('vs1');}
      }});
    } catch (error) {
      this.checkLoaderAvailable=false;
      this.open(this.templateRef);
    } 
    }
    public generateRqid() : number {
      
            var randomValuesArray = new Uint32Array(1);
            var crypto = window.crypto;
            crypto.getRandomValues(randomValuesArray)[0];
            
            return crypto.getRandomValues(randomValuesArray)[0];
            
      }

    public mostrar(vs){
if(vs=='vs1'){
  this.padreVS='1';
  this.mostrar1=true;
  this.mostrar2=false;
  this.mostrar3=false;
  this.mostrar4=false;
}
if(vs=='vs2'){
  this.padreVS='2';
  this.mostrar1=false;
  this.mostrar2=true;
  this.mostrar3=false;
  this.mostrar4=false;
}
if(vs=='vs3'){
  this.padreVS='3';
  this.mostrar1=false;
  this.mostrar2=false;
  this.mostrar3=true;
  this.mostrar4=false;
}
if(vs=='vs4'){
  this.padreVS='4';
  this.mostrar1=false;
  this.mostrar2=false;
  this.mostrar3=false;
  this.mostrar4=true;
}
}

    
public organizar(res){
      let dato:any=[];
         
    }
}
