import { Component } from '@angular/core';
import { ServiceService } from './service.service';
import { environment } from '../environments/environment';
import {Result}from './modelos/result.model'
import {DataRequestConciliation}from './modelos/DataRequestConciliation'
import {  Observable, BehaviorSubject, ConnectableObservable } from 'rxjs';
import { FormGroup, FormBuilder } from '@angular/forms';
import {formatDate} from '@angular/common';
@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {

}
