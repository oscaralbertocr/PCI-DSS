package co.com.ath.pgw.util.constants;

/**
 * constantes para el core de PGW
 * 
 * @author proveedor_cjmurillo
 * @version 1.0
 * @since 1.0
 * 
 * @RQ27199 <strong>Autor</strong>Mauricio Tascon y Jordan Cortes</br>
 *          <strong>Descripcion</strong> Validcación de Topes</br>
 *          <strong>Numero de Cambios</strong>4</br>
 *          <strong>Identificador corto</strong>C01</br>
 * 
 * @RQ27828 <strong>Autor</strong> Luis Hernando Bonilla Cortes</br>
 *          <strong>Descripcion</strong> Consumo operacion addTokenize para
 *          TC</br>
 *          <strong>Numero de Cambios</strong> 1</br>
 *          <strong>Identificador corto</strong> C01</br>
 * 
 * @IM717218 <strong>Autor</strong>Camilo Bustamante</br>
 *           <strong>Descripcion</strong>Validación Consumo Banco</br>
 *           <strong>Numero de Cambios</strong>1</br>
 *           <strong>Identificador corto</strong>C03</br>
 * 
 * @IM714148 <strong>Autor</strong>Andres Eduardo Hernandez</br>
 *           <strong>Descripcion</strong>Extracto Digital Pagos PSE</br>
 *           <strong>Numero de Cambios</strong>1</br>
 *           <strong>Identificador corto</strong>C02</br>
 * 
 * @RQ25675 <strong>Autor</strong>Efren Lopez Galvis</br>
 *          <strong>Descripcion</strong>Extracto Digital Pagos PSE</br>
 *          <strong>Numero de Cambios</strong>1</br>
 *          <strong>Identificador corto</strong>C04</br>
 *
 * @IM19113 <strong>Autor</strong>Henry Hernandez</br>
 *          <strong>Descripcion</strong>Validación Doble Pago TC y Aval</br>
 *          <strong>Numero de Cambios</strong>1</br>
 *          <strong>Identificador corto</strong>C07</br>
 * 
 * @RQ31820 <strong>Autor</strong>Roger Jans Leguizamon Cespedes</br>
 *          <strong>Descripcion</strong>URL de retorno a comercio para PSE</br>
 *          <strong>Numero de Cambios</strong>1</br>
 *          <strong>Identificador corto</strong>C08</br>
 * 
 * @PCI <strong>Autor</strong>Nelly Rocio Linares</br>
 *      <strong>Descripcion</strong>Constante del reporte TLF</br>
 *      <strong>Numero de Cambios</strong>1</br>
 *      <strong>Identificador corto</strong>C09</br>
 *
 * @PCI <strong>Autor</strong>Efren Lopez Galvis</br>
 *      <strong>Descripcion</strong>Constnates de respuesta API Agreement</br>
 *      <strong>Numero de Cambios</strong>1</br>
 *      <strong>Identificador corto</strong>C11</br>
 *      
 * @PDP-265 <strong>Autor</strong>Camilo Bustamante</br>
 *          <strong>Descripcion</strong>Integracion GlobalPay checkout</br>
 *          <strong>Numero de Cambios</strong>1</br>
 *          <strong>Identificador corto</strong>C12</br>
 *          
 */
public interface CoreConstants {

	public static final Integer SUCCESS_STATUS_CODE = 0;

	public static final Integer APPROVED_STATUS_CODE = 1;

	public static final Integer FAULT_STATUS_CODE = 1;

	public static final String FAULT_STATUS_ERROR_DESC = "En este momento no es posible realizar la transacción por favor intente más tarde";

	public static final Long TRUE = 1L;

	public static final Long FALSE = 0L;

	public static final Integer ERROR_DATA_VALIDATION_CODE = 200;

	public static final String SUCCESS_STATUS_DESC = "Transaccion exitosa";

	public static final String APPROVED_STATUS_DESC = "Transaccion Aprobada";

	public static final String FAULT_STATUS_DESC = "Error";

	/** INI C01 **/
	public static final String FAULT_STATUS_DESC_EXIST = "Error: El convenio ya existe con el medio de pago ";
	/** FIN C01 **/

	public static final Integer ERROR_STATUS_CODE_300 = 300;

	public static final Integer ERROR_STATUS_CODE_100 = 100;

	public static final Integer ERROR_STATUS_CODE_200 = 200;

	public static final Integer ERROR_STATUS_CODE_0 = 0;

	public static final String ERROR_STATUS_CODE_DESC = "No es posible procesar la transacción.";

	public static final String ERROR_STATUS_CODE_DESC_300 = "No es posible procesar la transacción - Problemas técnicos. Por favor intente más tarde.";

	public static final String ERROR_GENERIC_DESC = "Error Interno del servidor";

	public static final String SEPARATOR_TOKEN_GENERATOR = "|";

	/** Codigo de error tecnico generado por el ESB(bus) */
	public static final Integer ERROR_STATUS_CODE_700 = 700;

	/** INICIO-C01 **/
	public static final Integer ERROR_STATUS_CODE_710 = 710;
	/** FIN-C01 **/

	public static final String DISPLAY_DATE_FORMAT = "dd/MM/yyyy hh:mm:ss a";

	public static final String ZERO = "0";

	public static final String ONE = "1";

	public static final String FIVE = "5";

	public static final String SIX = "6";

	public static final String EMPTY = "";

	public static final String A = "A";

	public static final String BATCH_FORMAT_LOG_DATE = "yyyy-MM-dd HH:mm:ss,SSS";

	public static final String PSE_PENDING = "PENDING";

	public static final Integer ERROR_SERVER_STATUS_CODE_50 = 50;

	public static final String ERROR_SERVER_STATUS_CODE_50_DESC = "Token ya utilizado";

	public static final String LBL_AUTORIZATION_NUMBER = "Número de autorización";

	public static final String LBL_EMPTY_AUTORIZATION_NUMBER = "";

	public static final Integer ERROR_DATA_SECURITY_CODE = 30;

	public static final String ERROR_DATA_SECURITY_CODE_DESC = "La transacción que intenta realizar no ha sido autorizada, por favor comuníquese con nuestras líneas de atención al cliente.";

	/** Error al validar longitud del número documento de identidad */
	public static final int INVALID_LENGTH_INFORMATION = 1860;

	/** Error al validar longitud del número documento de identidad descripción */
	public static final String INVALID_LENGTH_INFORMATION_DES = "Número de documento inválido.";

	/** Error cálculo de iva */
	public static final int INVALID_TAX_AMOUNT = 3040;

	/** Error cálculo de iva descripción */
	public static final String INVALID_TAX_AMOUNT_DESC = "El monto de la obligación no concuerda con el valor a pagar";

	/** Respuesta status error servicio a portal pago RBM */
	public static final Long ERROR_RESPONSE_SERVER_PORTAL = 0L;

	public static final String PMTTYPE_NORMAL = "2";

	public static final String PMTTYPE_OBLIGACION = "3";

	public static final String CPV = "1";

	public static final String PYC = "2";

	/** Codigo de error time out para las trasnacciones de RBM */
	public static final Integer ERROR_STATUS_CODE_9001 = 9001;

	/** Codigo de error FAIL_ para las trasnacciones de PSE(ACH) */
	public static final Integer ERROR_STATUS_CODE_400 = 400;

	/** Descripcion de error FAIL_ para las trasnacciones de PSE(ACH) */
	public static final String ERROR_STATUS_CODE_400_DESC = "No es posible procesar la transacción. Comuníquese con la entidad.";

	/** Codigo de error 3520 para las trasnacciones de RBM */
	public static final Integer ERROR_STATUS_CODE_3520 = 3520;

	/** Descripcion de error 3520 para las trasnacciones de RBM */
	public static final String ERROR_STATUS_CODE_3520_DESC = "Reinicie Transaccion.";

	public static final Integer ERROR_STATUS_CODE_600 = 600;

	public static final String ERROR_STATUS_CODE_DESC_600 = "No es posible procesar la transacción - Problemas técnicos. Por favor intente más tarde.";

	// Hora de la fecha de compensación
	public static final Integer HOUR_COMPENSATION_DATE = 17;

	// Minitos de la fecha de compensación
	public static final Integer MINUTES_COMPENSATION_DATE = 30;

	// Ciclo actualizacion fecha compensación
	public static final String CICLE_COMPENSATION_DATE = "1";

	/** Codigo de error 1260 para las trasnacciones RBM */
	public static final Integer ERROR_STATUS_CODE_1260 = 1260;

	/** Codigo de verificaion de convenios agregadores PSE */
	public static final boolean IS_AGREGATOR = true;

	/** identificador convenios Av Villas */
	public static final Long ID_AVVILLAS = 1L;

	/* Descripcion manejo de intento repetitivo de pago PSE */
	public static final String ERROR_STATUS_PROCESING_PSE = "La transacción que intenta realizar se encuentra en proceso.";

	public static final Integer TIMEOUT_GETTXINFORMATION = 20000;
	public static final Integer TIMEOUT_CREATETXINFORMATION = 20000;
	public static final Integer TIMEOUT_FINALIZETXINFORMATION = 20000;

	/** INICIO-C07 **/
	/* Descripcion manejo de intento repetitivo de pago AVAL */
	public static final String ERROR_STATUS_PROCESING_AVAL = "La transacción que intenta realizar se encuentra en proceso.";

	/* Descripcion manejo de intento repetitivo de pago TC */
	public static final String ERROR_STATUS_PROCESING_TC = "La transacción que intenta realizar se encuentra en proceso.";
	/** FIN-C07 **/

	/* Define el estado de funcionamiento de Motor de riesgo */
	public static final String RSA_ON = "ON";
	public static final String RSA_OFF = "OFF";

	/* Define el valor de los valores de las referencias para RSA */
	public static final String RSA_DEVICE_PRINT = "DevicePrint";
	public static final String RSA_DEVICE_TOKEN_COOKIE = "DeviceTokenCookie";
	public static final String RSA_HTTPACCEPT = "httpAccept";
	public static final String RSA_HTTPACCEPTLANGUAGE = "httpAcceptLanguage";
	public static final String RSA_HTTPREFERRER = "httpReferrer";
	public static final String RSA_USERAGENT = "userAgent";
	public static final String RSA_TERMSNCONDITIONS = "termsAcept";

	/* Codigos de error de respuesta RSA */
	public static final String RSA_ERROR = "RSA_ERROR";
	public static final String RSA_DEVICE_PRINT_NOT_FOUND = "RSA_DEVICEPRINT_NOT_FOUND";
	public static final String RSA_SERVICE_ERROR = "RSA_SERVICE_ERROR";
	public static final String RSA_SWITCH_ERROR = "RSA_SWITCH_ERROR";
	public static final String RSA_USER_STATUS_ERROR = "RSA_USER_STATUS_ERROR";
	public static final String RSA_PPA_CHANNEL_INDICATOR = "PPA";

	/* Nombre de los Customs Facts para RSA */
	public static final String RSA_CF_ID_COMERCIO = "ID_COMERCIO";
	public static final String RSA_CF_REFERENCIA = "REFERENCIA";
	public static final String RSA_CF_MEDIO_PAGO = "MEDIO_PAGO";
	public static final String RSA_CF_BANCO = "BANCO_AUTORIZADOR";
	public static final String RSA_CF_TELEFONO = "TELEFONO";
	public static final String RSA_CF_CORREO = "CORREO";
	public static final String RSA_CF_FRANQUICIA = "FRANQUICIA";

	public static final String COMPRA = "C";
	public static final String RECAUDO = "R";

	public static final Long ID_PROP_LIQUIDACION_COMISION_CONTINGENCIA = 1L;
	public static final Long ID_PROP_REPORTE_BALOTO_CONTINGENCIA = 2L;
	public static final Long ID_PROP_REPORTE_ASOBANCARIA_CONTINGENCIA = 3L;
	public static final Long ID_PROP_REPORTE_TLF_CONTINGENCIA = 5L;
	public static final Long ID_PROP_REPORTE_BI_CONTINGENCIA = 6L;

	public static final String ENCENDIDO = "1";
	public static final String APAGADO = "0";

	public static final String FALLIDO_NEGOCIO = "3";
	public static final String RECHAZADO_NEGOCIO = "2";
	public static final String APROBADO_NEGOCIO = "4";

	public static final String FALLIDO_TX = "5";
	public static final String RECHAZADO_TX = "7";
	public static final String APROBADO_TX = "6";
	public static final String NO_AUTORIZADA_TX = "9";

	/** ReferenceID de la url del portal */
	public static final String URL = "URL";

	/** ReferenceID del logo para Ventanilla de pagos */
	public static final String VENTANILLA_LOGO = "LogoURL";

	/** ReferenceID del Template para Ventanilla de pagos */
	public static final String VENTANILLA_PLANTILLA = "Template";

	/** ReferenceID del Tema para Ventanilla de pagos */
	public static final String VENTANILLA_TEMA = "Theme";

	/** Indicativo para aplicar o no tema para Ventanilla de pagos */
	public static final Integer TAQUILLA_OFF = 0;
	public static final Integer TAQUILLA_ON = 1;

	/** Estilo por defecto para los correos de Confirmacion, Ventanilla de pagos */
	public static final String TAQUILLA_DEFAULT_NAME = "DEFAULT";

	/** Nombre del RefId para las referencias numeradas en addTransaction */
	public static final String REFERENCE_1 = "Reference1";
	public static final String REFERENCE_2 = "Reference2";
	public static final String REFERENCE_3 = "Reference3";

	/** Nombre del RefId para las referencias del Banco de Bogota */
	public static final String REFERENCE_ID_TYPE_DOC = "ReferenceIdTypeDoc";
	public static final String REFERENCE_NUM_DOC = "ReferenceNumdoc";

	public static final String REFERENCE_INCOCREDITO = "INCOCREDITO";
	public static final String REFERENCE_TERMINAL = "TERMINAL";

	/** Caracteres separadores para multiples referencias */
	public static final String SEPARATOR_MULTIPLES_REFERENCIAS = ";";
	public static final String SEPARATOR_MULTIPLES_REFERENCIAS_VALOR = ":";
	
	/**Constantes Sincronizacion de convenios*/
	public static final String ERRORS_BUNDLE = "ERRORS"; 
	public static final String MESSAGES_BUNDLE = "MESSAGES"; 
	public static final String OPERACION_ENROLL = "Enroll";
	public static final String OPERACION_MODIFY = "Modify";
	public static final String OPERACION_DELETE = "Delete";
	public static final String STATE_INDICATOR_ON = "1";
	public static final String STATE_INDICATOR_OFF = "0";
	public static final String EXTENSION_EMPTY = "0";
	public static final String CELLPHONE_EMPTY = "0";
	public static final String CUENTARECAUDO = "CuentaRecaudo";
	public static final String INCOCREDITO = "INCOCREDITO";
	public static final String TERMINAL = "TERMINAL";
	public static final String ACH_SERVICECODE = "ACH_SERVICECODE";
	public static final String AGREEMENT_CPV = "CPV";
	public static final String SEVERITY_INFO = "Info";
	public static final String SEVERITY_ERROR = "Error";
	/** Constantes Agreement */
	public static final String CREATE_OPERATION = "Crear";
	public static final String UPDATE_OPERATION = "Actualizar";
	public static final String DELETE_OPERATION = "Eliminar";
	public static final String CHANEL_PORTALADM = "PortalAdministrativo";
	public static final String REFERENCE_CODEAN = "CODIGOEAN";
	public static final String REFERENCE_CODACH = "CODIGOACH";
	public static final String REFERENCE_ADMTYPE = "AdmType";
	public static final String REFERENCE_ESTADO = "ESTADO";
	public static final String REFERENCE_BAVVCODE = "homologationBavvCode";
	public static final String REFERENCE_AGREGADOR = "agregador";
	public static final String TYPE_FAX = "FAX";
	public static final String REGELIMINADO_CREATE = "0";
	public static final String REGELIMINADO_DELETE_ON = "1";
	public static final String REGELIMINADO_DELETE_OFF = "0";
	public static final String STATE_OFF = "1";
	public static final String STATE_ON = "0";
	public static final String REFERENCE_TC = "TC";
	public static final String REFERENCE_TEMA = "idTema";
	public static final String REFERENCE_PLANTILLA = "idPlantilla";
	public static final String REFERENCE_LOGO = "logo";
	public static final String REFERENCE_URLCONFIRMACION = "urlConfirmacion";
	public static final String REFERENCE_RUTACERTIFICADO = "rutaCertificado";
	public static final String REFERENCE_GENDER = "gender";
	public static final String REFERENCE_TIPODESERVICIO = "tipodeservicio";
	public static final String REFERENCE_NOFACTMULTIREF = "nofactmultipleref";
	public static final String REFERENCE_ZIPASOBANCARIA = "zipasobancaria";
	public static final String REFERENCE_ARCHIVORECAUDO = "archivorecaudo";
	public static final String REFERENCE_TYPECEL = "celular";
	public static final String REFERENCE_TYPEFAX = "fax";
	public static final String REFERENCE_TIPOADMINISTRADOR = "tipoAdministrador";	
	public static final String DELETE_TYPE1 = "2";
	public static final String DELETE_TYPE2 = "3";
	public static final String ROL_COMERCIAL= "1";
	public static final String ROL_TECNICO= "3";
	public static final String ROL_OPERATIVO= "2";
	
	/**AVAL*/
	public static final String VALIDATOR_TC = "1";
	public static final Integer VALIDATOR_BLACKLIST = 1;
	public static final Integer FLAG_EMAIL_ON = 1;
	public static final Integer FLAG_EMAIL_OFF = 0;
	
	/** Codigos de error de respuesta TOPES */
	public static final String TOP_ERROR_CODE = "1200";

	/** INICIO-C03 **/
	/** Indicativo de inicio de codigos Nura */
	public static final String NURA_CODE_CPV = "CPV"; // Para CPV
	public static final String NURA_CODE_OBLIGATION = "O"; // Para Obligaciones
	/** FIN-C03 **/

	/** INICIO-C02 */
	public static final String NURA_CODE = "nuraCode";
	public static final String COMPLETED = "COMPLETED";
	public static final String INITIAL_BANK = "initialBank";

	public static final String ASOBANCARIA = "A";
	public static final String ASOBANCARIA_CONTINGENCY = "AC";
	public static final String BALOTO = "B";
	public static final String COMISION = "CD";
	public static final String COMISION_MENSUAL = "CM";
	public static final String COMISION_CONTINGENCY = "CC";

	/** FIN-C02 */

	/** INICIO-C04 */
	public static final String PMTID_K7 = "K7_PMTID";
	/** FIN-C04 */

	/** INICIO C08 */
	public static final String INITIAL = "INITIAL";
	public static final String RETURN_URL = "returnURL";
	public static final String SUCCESS = "SUCCESS";
	/** FIN C08 */

	/** INICIO C09 */
	public static final String HEADER_RQUID = "X-RqUID";
	public static final String HEADER_CHANNEL = "X-Channel";
	public static final String HEADER_VALUE_CHANNEL = "1";
	public static final String HEADER_COMPANY = "X-CompanyId";
	public static final String HEADER_VALUE_COMPANY = "CORE";
	public static final String HEADER_GOV_IDENT_ID = "X-IdentSerialNum";
	public static final String HEADER_GOV_IDENT_TYPE = "X-GovIssueIdentType";
	public static final String HEADER_SERVICE_NAME = "ServiceName";
	public static final String HEADER_VALUE_SERVICE_NAME_CONSULTA = "AuthorizationPayment";
	public static final String HEADER_VALUE_SERVICE_NAME_GENERACION = "AuthorizationPayment";
	public static final String HEADER_VALUE_SERVICE_NAME_ACTUALIZACION = "AuthorizationPayment";
	/** FIN C09 */

	public static final String PORTAL_URL = "PortalURL";
	public static final String CODIGO_NIE = "NIE";
	public static final String TEMPLATE = "Template";
	public static final String THEME = "Theme";
	public static final String TRAZABILITY_CODE = "TrazabilityCode";

	// * Flag que indica si un registro esta tokenizado **/
	public static final String BATCH_REPORT_TX_TOKENIZED = "*";
	public static final String BATCH_REPORT_TX_NOT_TOKENIZED = "+";

	/**
	 * INI-C10
	 */
	public static final Long ERROR_STATUS_COD_MOD_AGREEMENT = 206L;
	public static final Integer ERROR_STATUS_COD_AGREEMENT = 206;
	public static final String ERROR_STATUS_DESC_MOD_AGREEMENT = "No se pudo realizar la actualización del convenio";
	/**
	 * FIN-C10
	 */
	 
	public static final Long RETURN_ALL_BANKS = 2L;
	public static final Long RETURN_IS_AVAL = 1L;
	public static final Long RETURN_NOT_IS_AVAL = 0L;
	
	// CONSTANTS TOKENIZE
	public static final String SERVICE_TOKENIZE_VOLTAGE = "VOLTAGE";
	public static final String SERVICE_TOKENIZE_GEMALTO = "GEMALTO";
	public static final String TOKENIZE_FORMAT = "TOKEN_ALL";
	
	public static final String DEFAULT_APPROVAL = "0";	

	/**
	 * INI-C11
	 */
	public static final String DATA_NOT_FOUND_INQUIRIES_ENTITY_STATUS_CODE = "300";
	public static final String DATA_NOT_FOUND_INQUIRIES_ENTITY_STATUS_DESC = "No se encontraron entidades asociadas a la consulta realizada.";
	/**
	 * FIN-C11
	 */
	public static final String DATA_NOT_FOUND_CORE_BATCH_CONTINGENCY = "No se encontró información asociada al archivo solicitado.";
	

	public static final String ERROR_CORE_BATCH_CONTINGENCY_BALOTO = "Se presento un error ejecutando sonda BALOTO.";
	public static final String ERROR_CORE_BATCH_CONTINGENCY_TLF = "Se presento un error ejecutando sonda TLF.";
	public static final String ERROR_CORE_BATCH_CONTINGENCY_COMISION = "Se presento un error ejecutando sonda COMISION contingencia.";
	public static final String ERROR_CORE_BATCH_CONTINGENCY_ASOBANK = "Se presento un error ejecutando sonda Recaudos contingencia.";
	public static final String ERROR_CORE_BATCH_CONTINGENCY_BI = "Se presento un error ejecutando sonda BI.";
	
	public static final Integer ERROR_STATUS_COD_AGREEMENTINCOCREDITO = 207;
	public static final String ERROR_STATUS_DESC_AGREEMENTINCOCREDITO = "Lo sentimos, el código Incocredito se encuentra asignado a otro NIT";
	public static final Integer ERROR_STATUS_COD_AGREEMENTTERMINAL = 208;
	public static final String ERROR_STATUS_DESC_AGREEMENTTERMINAL = "Lo sentimos, el código Terminal se encuentra asignado a otro Código Incocredito";
	
	public static final Integer PMTID_LIMIT = 6;
	public static final String SEPARADOR = "\\";
	
	/**
	 * INI-C12
	 */
	public static final String GLOBALPAY_STATUS = "globalPayStatus";
	public static final String GLOBALPAY_ID = "globalPayId";
	public static final String GLOBALPAY_DETAIL = "globalPayStatusDetail";
	
	public static final String GLOBALPAY_PAYMENTDATE ="globalPayPaymentDate";
	public static final String GLOBALPAY_AMOUNT ="globalPayAmount";
	public static final String GLOBALPAY_AUTHORIZATIONCODE ="globalPayAuthorizationCode";
	public static final String GLOBALPAY_INSTALLMENTS ="globalPayInstallments";
	public static final String GLOBALPAY_DEVREFERENCE ="globalPayDevReference";
	public static final String GLOBALPAY_MESSAGE ="globalPayMessage";
	public static final String GLOBALPAY_CARRIERCODE ="globalPayCarrierCode";						   
	public static final String GLOBALPAY_CARDBIN ="globalPayCardBin";
	public static final String GLOBALPAY_CARDSTATUS ="globalPayCardStatus";
	public static final String GLOBALPAY_CARDTOKEN ="globalPayCardToken";
	public static final String GLOBALPAY_CARDEXPIRYYEAR ="globalPayCardExpiryYear";
	public static final String GLOBALPAY_CARDEXPIRYMONTH ="globalPayCardExpiryMonth";
	public static final String GLOBALPAY_CARDREFERENCE ="globalPayCardTransactionReference";
	public static final String GLOBALPAY_CARDTYPE ="globalPayCardType";
	public static final String GLOBALPAY_CARDNUMBER ="globalPayCardNumber";
	public static final String GLOBALPAY_CARDORIGIN ="globalPayCardOrigin";
	public static final String GLOBALPAY_VISA ="vi";
	public static final String GLOBALPAY_MASTERCARD ="mc";
	public static final String GLOBALPAY_CARDJOIN ="******";	
	
	public static final String GLOBALPAY_STATUS_APROBADA = "success";
	public static final String GLOBALPAY_STATUS_FALLIDA = "failure";
	public static final String GLOBALPAY_STATUS_PENDIENTE = "pending";
	
	public static final Long GLOBALPAY_ESTADO_PENDIENTE = 0L;
	public static final Long GLOBALPAY_ESTADO_APROBADA  = 1L;
	public static final Long GLOBALPAY_ESTADO_CANCELADA = 2L;
	public static final Long GLOBALPAY_ESTADO_RECHAZADA = 4L;
	public static final Long GLOBALPAY_ESTADO_EXPIRADA  = 5L;
		
	public static final String QR_VISA ="Visa";
	public static final String QR_MASTERCARD ="MasterCard";
	public static final String QR_STATUS_APROBADA = "APROBADO";
	public static final String QR_STATUS_FALLIDA = "FALLIDA";
	public static final String QR_STATUS_PENDIENTE = "PENDIENTE";
	public static final String QR_CODIGO="00";
	public static final String QR_PARAMETRO_NO_COMPLETADO="E01";
	public static final String QR_ERROR_TRANSFORMACION="E03";
	public static final String QR_ERROR_CONEXION="E08";
	public static final String QR_ERROR_INTERNO="E09";
	public static final String QR_TIMEOUT="E10";
	public static final String QR_EMPTY="E11";	
	public static final String ACTUALIZAR_QR_ERROR_ESTRUCTURA="E01";
	public static final String ACTUALIZAR_QR_ERROR_INVOCACION="E02";
	public static final String ACTUALIZAR_QR_ERROR_INTERNO="E09";
	
	public static final String GENERAR_QR_ERROR_INVOCACION="E02";
	public static final String GENERAR_QR_ERROR_CONEXION="E08";
	public static final String GENERAR_QR_ERROR_INTERNO="E09";
	public static final String GENERAR_QR_ERROR_TIMEOUT="E10";
	public static final String GENERAR_QR_ERROR_ESTRUCTURA="E01";
	public static final String GENERAR_QR_ERROR_INTERNO_PROVEEDOR="E28";
	public static final String GENERAR_QR_ERROR_PETICION="Error recibido del servicio GenerarQR(RBM).";
	public static final String GENERAR_QR_ERROR_GENERAL="Error general recibido del servicio GenerarQR(RBM).";
	public static final String ACTUALIZAR_QR_ERROR="Error recibido del servicio ActualizarQR(RBM).";
	public static final String CONSULTAR_QR_ERROR="Error recibido del servicio ConsultarEstadoQR(RBM).";
	

	/**
	 * FIN-C12
	 */

	 // Mensaje para la generación QR
	
	public static final String QR_ERROR_CARGA_PARAMETROS_CODE="01";
	public static final String QR_ERROR_CARGA_PARAMETROS="Error al cargar la lista de parámetros";
	
	public static final String QR_ERROR_TX_NO_EXISTE_CODE="02";
	public static final String QR_ERROR_TX_NO_EXISTE="La transacción no existe ";
	
	public static final String QR_ERROR_CONSULTA_DETALLADA_CODE="03";
	public static final String QR_ERROR_CONSULTA_DETALLADA="No pudo cargar la consulta detallada ";
	
	public static final String QR_ERROR_MARCA_TX_CODE="04";
	public static final String QR_ERROR_MARCA_TX="No pudo marcar la transacción como QR";
	public static final String PAR_SBTM_2020 = "58TM_47H_2020_PR0C3551N6";
}