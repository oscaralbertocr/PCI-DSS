/*
 * TokenGeneratorSHA1Service
 *  
 * GSI - Integración
 * Creado el: 6/10/2014
 *
 * Copyright (c) A Toda Hora S.A. Todos los derechos reservados
 * 
 * Este software es confidencial y es propietario de ATH, queda prohibido
 * su uso, reproducción y copia de manera parcial o permanente salvo autorización
 * expresa de A Toda Hora S.A o de quién represente sus derechos.
 */
package co.com.ath.pgw.util.security.impl;

import java.io.UnsupportedEncodingException;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;
import java.security.spec.InvalidKeySpecException;
import java.security.spec.KeySpec;
import java.util.Set;

import javax.crypto.BadPaddingException;
import javax.crypto.Cipher;
import javax.crypto.IllegalBlockSizeException;
import javax.crypto.NoSuchPaddingException;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESedeKeySpec;

import org.apache.commons.codec.binary.Base64;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;

import co.com.ath.pgw.util.constants.CoreConstants;
import co.com.ath.pgw.util.security.TokenGeneratorService;


//import org.apache.commons.codec.binary.Base64;

/**
 * Implementación para la generación de token con DES
 * 
 * @author proveedor_cjmurillo
 * @version 1.0 6/10/2014
 * @since 1.0
 * 
 * @PCI 
 * <strong>Autor: </strong>Dario Hernandez Rojas</br>
 * <strong>Fecha: </strong>08/01/2021</br>
 * <strong>Descripcion: </strong>se elimina el valor de la varible
 * pgwKeyDES ya que no esta en uso este metodo de encripcion</br>
 * <strong>Numero de Cambios: </strong>1</br>
 * <strong>Identificador corto: </strong>C01</br>
 * 
 **/
 
public class TokenGenerator3DESService implements TokenGeneratorService {

	
	private static final String UNICODE_FORMAT = "UTF8";

	private Logger logger = LoggerFactory.getLogger(getClass());
	
	/*Inicio-C01*/
	//@Value("${pasarela.security.des.key}")
	private String pgwKeyDES;
	/*Fin-C01*/
	
	@Override
	public String generate(Set<Object> args ) {
		
		String hashtext 	= "";;
		 
		StringBuilder sb = new StringBuilder();
		for (Object o : args) {
			sb.append(o.toString());
			sb.append(CoreConstants.SEPARATOR_TOKEN_GENERATOR);
		}
		
		final String algorithm = "AES/GCM/NoPadding";
		
		Cipher cipher;
		try {
			
			cipher = Cipher.getInstance(algorithm);
			KeySpec keySpec = new DESedeKeySpec(
					pgwKeyDES.getBytes(UNICODE_FORMAT));
			
			SecretKeyFactory keyFactory	= 
					SecretKeyFactory.getInstance(algorithm);
			SecretKey key = keyFactory.generateSecret(keySpec);
			
			cipher.init(Cipher.ENCRYPT_MODE, key);
			byte[] plainText = sb.toString().getBytes();
			byte[] crytedText = cipher.doFinal(plainText);
			hashtext = new String(Base64.encodeBase64(crytedText));
		} catch (NoSuchAlgorithmException e) {
			logger.info("No se pudo instanciar el algoritmo "+algorithm, e);
			return null;
		} catch (NoSuchPaddingException e) {
			logger.info("No se pudo instanciar el algoritmo "+algorithm, e);
			return null;
		} catch (InvalidKeyException e) {
			logger.info("No se pudo instanciar el algoritmo "+algorithm, e);
			return null;
		} catch (InvalidKeySpecException e) {
			logger.info("No se pudo instanciar el algoritmo "+algorithm, e);
			return null;
		} catch (IllegalBlockSizeException e) {
			logger.info("No se pudo instanciar el algoritmo "+algorithm, e);
			return null;
		} catch (BadPaddingException e) {
			logger.info("No se pudo instanciar el algoritmo "+algorithm, e);
			return null;
		} catch (UnsupportedEncodingException e) {
			logger.info("No se pudo instanciar el algoritmo "+algorithm, e);
			return null;
		}
		
        // Completa con ceros hasta lograr 32 caracteres
        while (hashtext.length() < 32) {
			hashtext = "0" + hashtext;
		}
        return hashtext;
	}
	
	
}
