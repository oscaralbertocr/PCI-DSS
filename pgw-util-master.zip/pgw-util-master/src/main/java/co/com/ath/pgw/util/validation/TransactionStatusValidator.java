/*
 * SimpleValidator
 *  
 * GSI - Integración
 * Creado el: 15/10/2014
 *
 * Copyright (c) A Toda Hora S.A. Todos los derechos reservados
 * 
 * Este software es confidencial y es propietario de ATH, queda prohibido
 * su uso, reproducción y copia de manera parcial o permanente salvo autorización
 * expresa de A Toda Hora S.A o de quién represente sus derechos.
 */
package co.com.ath.pgw.util.validation;



/**
 * Validador para el estado de la transacción.
 *
 * @author Andrés Méndez Juanias <proveedor_mamendez@ath.com.co> 
 * @version 1.0 15/10/2014
 * @since 1.0
 */
public interface TransactionStatusValidator {
	
	public void validate(Long transaction, String operation) throws ValidationException;

}
