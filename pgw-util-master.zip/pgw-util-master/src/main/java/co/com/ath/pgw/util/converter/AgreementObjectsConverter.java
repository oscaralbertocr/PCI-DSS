package co.com.ath.pgw.util.converter;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import co.com.ath.pgw.bsn.dto.in.AgreementSynchronizationInDTO;
import co.com.ath.pgw.bsn.dto.out.AgreementOutDTO;
import co.com.ath.pgw.in.dto.AgreementSynchronizationRqType;
import co.com.ath.pgw.in.dto.AgreementRsType;
import co.com.ath.pgw.in.model.SeverityType;
import co.com.ath.pgw.in.model.StatusType;
import co.com.ath.pgw.rest.request.dto.Header;
import co.com.ath.pgw.rest.request.dto.RequestAgrmSynch;
import co.com.ath.pgw.rest.response.dto.ResponseAgrmSynch;
import co.com.ath.pgw.util.constants.CoreConstants;

/**
 * Convertidor de objetos que vienen de los servicios a objetos del core
 * @author proveedor_cjmurillo
 * @version 1.0
 * @since 1.0
 */
public class AgreementObjectsConverter {
	
	static Logger LOGGER = LoggerFactory.getLogger(AgreementObjectsConverter.class);
	

	/**
	 * Convierte de AgreementSynchronizationRqType a AgreementSynchronizationInDTO
	 * @param inn
	 * @return out
	 */
	public static AgreementSynchronizationInDTO toAgreementSynchronizationInDTO(AgreementSynchronizationRqType agreementSynchronizationRqType){
		AgreementSynchronizationInDTO agreementSynchronizationInDTO = new AgreementSynchronizationInDTO();
		agreementSynchronizationInDTO.setClientDt(DateUtil.toDate(agreementSynchronizationRqType.getClientDt()));
		agreementSynchronizationInDTO.setIpAddr(agreementSynchronizationRqType.getIPAddr());
		agreementSynchronizationInDTO.setRqUID(agreementSynchronizationRqType.getRqUID());
		agreementSynchronizationInDTO.setAgreementSynchronizationRqType(agreementSynchronizationRqType);
		return agreementSynchronizationInDTO;
	}
	
	/**
	 * Convierte de AddTransactionOutDTO a TransactionAddRsType
	 * @param agreementOutDTO
	 * @return
	 */
	public static AgreementRsType toAgreementSynchronizationRsType(
			AgreementOutDTO agreementOutDTO) {
		
		StatusType status = new StatusType();
		status.setStatusCode(agreementOutDTO.getStatusCode());
		status.setStatusDesc(agreementOutDTO.getStatusDesc());
		status.setServerStatusCode(agreementOutDTO.getTrnServerStatusCode());
		status.setServerStatusDesc(agreementOutDTO.getTrnServerStatusDesc());
		status.setSeverity(SeverityType.fromValue(CoreConstants.SEVERITY_INFO));
		
		AgreementRsType agreementRsType = new AgreementRsType();
		agreementRsType.setStatus(status);
		agreementRsType.setRqUID(agreementOutDTO.getRqUID());
		agreementRsType.setApprovalId(agreementOutDTO.getApprovalId());
		return agreementRsType;
	}
	
	/**
	 * Convierte de AgreementSynchronizationOutDTO a AgreementSynchronizationRsTypeError
	 * @param inn
	 * @return
	 */
	public static AgreementRsType toAgreementSynchronizationRsTypeError(
		AgreementSynchronizationRqType agreementSynchronizationRqType, Exception ex) {
		
		StatusType status = new StatusType();
		status.setStatusCode(CoreConstants.ERROR_STATUS_CODE_600);
		status.setStatusDesc(CoreConstants.ERROR_STATUS_CODE_DESC_600);
		status.setServerStatusCode(CoreConstants.ERROR_STATUS_CODE_600.toString());
		status.setServerStatusDesc(ex.toString());
		status.setSeverity(SeverityType.fromValue("Error"));
		
		AgreementRsType agreementRsType = new AgreementRsType();
		agreementRsType.setStatus(status);
		agreementRsType.setRqUID(agreementSynchronizationRqType.getRqUID());
		agreementRsType.setApprovalId(null);
		return agreementRsType;
	}
	public static AgreementRsType toAgreementRsTypeError(Header headerDto, Exception ex) {
		
		StatusType status = new StatusType();
		status.setStatusCode(CoreConstants.ERROR_STATUS_CODE_600);
		status.setStatusDesc(CoreConstants.ERROR_STATUS_CODE_DESC_600);
		status.setServerStatusCode(CoreConstants.ERROR_STATUS_CODE_600.toString());
		status.setServerStatusDesc(ex.getMessage());
		status.setSeverity(SeverityType.fromValue(CoreConstants.SEVERITY_ERROR));
		
		AgreementRsType agreementRsType = new AgreementRsType();
		agreementRsType.setStatus(status);
		agreementRsType.setRqUID(headerDto.getRqUID());
		agreementRsType.setApprovalId(null);
		return agreementRsType;
	}
	public static AgreementRsType toAgreementDeleteRsTypeError(
		Header headerDto, Exception ex) {
			
		StatusType status = new StatusType();
		status.setStatusCode(CoreConstants.ERROR_STATUS_CODE_600);
		status.setStatusDesc(CoreConstants.ERROR_STATUS_CODE_DESC_600);
		status.setServerStatusCode(CoreConstants.ERROR_STATUS_CODE_600.toString());
		status.setServerStatusDesc(ex.getMessage());
		status.setSeverity(SeverityType.fromValue(CoreConstants.SEVERITY_ERROR));
		
		AgreementRsType agreementRsType = new AgreementRsType();
		agreementRsType.setStatus(status);
		agreementRsType.setRqUID(headerDto.getRqUID());
		agreementRsType.setApprovalId(null);
		return agreementRsType;
	}
	
	public static ResponseAgrmSynch toAgreementFindRsTypeError(
			Header headerDto, Exception ex) {
		
		ResponseAgrmSynch responseAgrmSynch = new ResponseAgrmSynch();
		
		responseAgrmSynch.setStatusCode(CoreConstants.ERROR_STATUS_CODE_600);
		responseAgrmSynch.setStatusDesc(CoreConstants.ERROR_STATUS_CODE_DESC_600);
		responseAgrmSynch.setTrnServerStatusCode(CoreConstants.ERROR_STATUS_CODE_600.toString());
		responseAgrmSynch.setTrnServerStatusDesc(ex.getMessage());
		
		return responseAgrmSynch;
		}
	
}
