package co.com.ath.pgw.util.validation;

import org.apache.commons.lang.StringUtils;
import org.springframework.stereotype.Service;

/**
 * Clase para validar si una rferencia pertenece a una tarjeta de crédito
 * 
 * @author leanys.pineda
 * @since 30/11/2020
 */
@Service
public class CreditCardValidator {

	/**
	 * Método que utiliza el algoritmo de Luhn para validar si un número enviado
	 * como refertencia pertenece a una tarjeta de crédito válida
	 * 
	 * @param numberCardCredit
	 * 
	 */
	public boolean isCreditCard(String creditCardNumber) {

		if (creditCardNumber.startsWith("0") || !(creditCardNumber.length() >= 13 && creditCardNumber.length() <= 16)) {

			return false;

		} else {

			int sum1 = 0, sum2 = 0;
			String reversa = new StringBuffer(creditCardNumber).reverse().toString();
			for (int i = 0; i < reversa.length(); i++) {
				int digito = Character.digit(reversa.charAt(i), 10);
				if (i % 2 == 0) {
					sum1 += digito;
				} else {
					sum2 += 2 * digito;
					if (digito >= 5) {
						sum2 -= 9;
					}
				}
			}

			if ((sum1 + sum2) % 10 == 0) {

				return true;

			}

			else {

				return false;

			}
		}

	}

	/**
	 * Método que valida si una referencia es un número
	 * 
	 * @param reference
	 * @return true o false
	 * @author leanys.pineda
	 */
	public boolean isNumeric(String reference) {

		if (StringUtils.isNumeric(reference)) {
			return true;
		} else {
			return false;
		}
	}

}
