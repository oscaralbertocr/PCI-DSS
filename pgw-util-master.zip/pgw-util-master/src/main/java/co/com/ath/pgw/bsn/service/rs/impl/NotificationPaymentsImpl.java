package co.com.ath.pgw.bsn.service.rs.impl;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

import javax.annotation.Resource;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpMethod;
import org.springframework.stereotype.Service;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;

import co.com.ath.pgw.bsn.service.rs.NotificationPayments;
import co.com.ath.pgw.in.model.AgreementInfoType;
import co.com.ath.pgw.in.model.PmtWayType;
import co.com.ath.pgw.util.converter.DateUtil;
import co.com.ath.pgw.util.enums.BusinessStatusEnum;
import co.com.ath.pgw.util.rest.AbstractRestClient;
import co.com.ath.ws.rs.NotificationPaymentsRq;
import co.com.ath.ws.rs.NotificationPaymentsRs;
import co.com.ath.ws.rs.objects.BankInfoNotification;
import co.com.ath.ws.rs.objects.CustName;
import co.com.ath.ws.rs.objects.DepAcctTrnNotification;
import co.com.ath.ws.rs.objects.Fee;
import co.com.ath.ws.rs.objects.GetTransactionByIdType;
import co.com.ath.ws.rs.objects.InvoiceReference;
import co.com.ath.ws.rs.objects.OrderInfo;
import co.com.ath.ws.rs.objects.PersonalData;
import co.com.ath.ws.rs.objects.PmtStatusNotification;
import co.com.ath.ws.rs.objects.Reference;
import co.com.ath.ws.rs.objects.TaxFee;
import co.com.ath.ws.rs.objects.TransactionNotification;
import co.com.ath.ws.rs.objects.TransactionStatus;
import co.com.ath.ws.rs.objects.UserId;


@Service
public class NotificationPaymentsImpl implements NotificationPayments {
	
	static Logger LOGGER = LoggerFactory.getLogger(NotificationPaymentsImpl.class);
	
	@Value("${pasarela.ws.rs.notificationPayments}")
	private String notificationPaymentsUrl;
	
	@Resource
	private AbstractRestClient restClient;
//	
	@Override
	public boolean notification(TransactionNotification tx) {
		
		boolean result = true;

		// Si la transaccion se encuentra en estado pendiente no es necesario consumir el servicio
		if (tx.getBusinessCode() == BusinessStatusEnum.PENDIENTE.getCode()) {
			LOGGER.info("@NotificationPayments, la Transaction pmtid:{} "
					+ "se encuentra en estado pendiente, No se debe consumir "
					+ "el servicio de notificacion.", tx.getPmtId());
			return result = false;
		}
		
		String msg = checkTransaction(tx); 
		if ( null != msg ) {
			LOGGER.error("@NotificationPayments, el objeto Transaction pmtid:{} "
					+ "no cuenta con el campo: {} necesario para generar el "
					+ "request", tx.getPmtId(), msg);
			return result = false;
		}
		
		PmtStatusNotification pmtStatus = new PmtStatusNotification();
		pmtStatus.setStatusDesc(tx.getBusinessCodeDesc());
		
		DepAcctTrnNotification depAcctTrnRec = new DepAcctTrnNotification();
		depAcctTrnRec.setPmtId(tx.getPmtId());
		
		BankInfoNotification bankInfo = new BankInfoNotification();
		bankInfo.setBankId(tx.getBankInfo().getBankId());
		
		AgreementInfoType agreementInfoType = new AgreementInfoType();	
		agreementInfoType.setAgreementId(tx.getAgreementId());
		agreementInfoType.setName(tx.getName());
		agreementInfoType.setNIT(tx.getNit());
		agreementInfoType.setPhone(tx.getPhone());
		
		PmtWayType pmtWayType = new PmtWayType();
		pmtWayType.setPmtWayId(tx.getPmtWayId());
		pmtWayType.setPmtWayType(tx.getPmtWayType());
		
		List<PmtWayType> listPmtWayType = new ArrayList<>();
		listPmtWayType.add(pmtWayType);

		TransactionStatus transactionStatus = new TransactionStatus();
		transactionStatus.setTrnStatusCode(tx.getStatusCode());
		transactionStatus.setTrnStatusDesc(tx.getStatusDesc());		
		transactionStatus.setEffDt(tx.getEffDt());		
		transactionStatus.setCompensationDt(tx.getCompensationDate());
		transactionStatus.setApprovalId(tx.getApprovalId());

		UserId userId = new UserId();
		userId.setCustIdType(tx.getCustomerDocType());
		userId.setCustIdNum(tx.getCustomerDocId());
		
		CustName custName = new CustName();
		custName.setFirstName(tx.getFirstName());
		custName.setMiddleName(tx.getMiddleName());
		custName.setLastName(tx.getLastName());
		custName.setSecondLastName(tx.getSecondLastName());
		
		PersonalData personalData = new PersonalData();		
		personalData.setCustname(custName);
		personalData.setCustIdType(tx.getCustIdType());
		personalData.setCustIdNum(tx.getCustIdNum());
		personalData.setEmailAddr(tx.getEmailAddr());
		personalData.setPhone(tx.getPhone());
		
		List<PersonalData> personalDatalist = new ArrayList<>();
		personalDatalist.add(personalData);
		
		OrderInfo orderInfo = new OrderInfo();
		orderInfo.setOrderId(tx.getOrderId());
		orderInfo.setDesc(tx.getOrderDesc());
		
		Fee fee = new Fee();
		fee.setAmt(tx.getAmt().toString());
		fee.setCurCode(tx.getCurCode());
		
		TaxFee taxFee = new TaxFee();
		taxFee.setAmt(tx.getAmt().toString());
		
		InvoiceReference invoiceReference= new InvoiceReference();
		invoiceReference.setPmtCodNIE(tx.getCodNIE());		
		
		List<InvoiceReference> listInvoiceReference = new ArrayList<>();
		listInvoiceReference.add(invoiceReference);
		
		List<Reference> mapReference = new ArrayList<>();
		mapReference.addAll(convertReferenceStringListToReferenceTypeList(tx.getReferenceMap()));

		List<Reference> listReference = new ArrayList<>();
	
		for(Reference reference: mapReference){
			Reference refInfo = new Reference();
			refInfo.setRefId(reference.getRefId());
			refInfo.setRefType(reference.getRefType());
			listReference.add(refInfo);
		}
				
		GetTransactionByIdType getTransactionByIdType = new GetTransactionByIdType();
		getTransactionByIdType.setStatusCode(String.valueOf(tx.getStatusCode()));
		getTransactionByIdType.setStatusDesc(tx.getStatusDesc());
		getTransactionByIdType.setRqUID(tx.getRquId());
		getTransactionByIdType.setTransactionStatus(transactionStatus);
		getTransactionByIdType.setUserId(userId);
		getTransactionByIdType.setPersonalData(personalDatalist);
		getTransactionByIdType.setAgreementInfoType(agreementInfoType);
		getTransactionByIdType.setPmtId(tx.getPmtId().toString());
		getTransactionByIdType.setOrderInfo(orderInfo);
		getTransactionByIdType.setFee(fee);
		getTransactionByIdType.setTaxFee(taxFee);
		getTransactionByIdType.setReference(listReference);
		getTransactionByIdType.setPmtWayType(listPmtWayType);
		getTransactionByIdType.setInvoiceReference(listInvoiceReference);
		getTransactionByIdType.setTrnChannel(tx.getTrnChannel());
		getTransactionByIdType.setTrm("");
		
		NotificationPaymentsRq request = new NotificationPaymentsRq();
		request.setDepAcctTrnRec(depAcctTrnRec);
		request.setPmtStatus(pmtStatus);
		request.setBankInfo(bankInfo); 
		request.setGetTransactionByIdType(getTransactionByIdType);
		
		HashMap<String, String> headers = new HashMap<>();
		headers.put("X-RqUID", tx.getRquId());
		headers.put("X-Channel", tx.getIdOrigenTransaccion());
		headers.put("X-CompanyId", tx.getCommerceNuraCode());
		headers.put("X-IPAddr", tx.getIpAddress());	
		headers.put("X-GovIssueIdentType", (tx.getCustomerDocType() == null || tx.getCustomerDocType().isEmpty() ? "-":tx.getCustomerDocType()));
		headers.put("X-IdentSerialNum", (tx.getCustomerDocId() ==null || tx.getCustomerDocId().isEmpty()  ?  "-" :tx.getCustomerDocId()));
		
		LOGGER.info("@NotificationPayments pmtid:{} input \n {}", tx.getPmtId(), request);
		
		String restClientStr = null;
		try {
			restClientStr = restClient.consumeRest(notificationPaymentsUrl, 
					request, HttpMethod.POST, headers,true);			
		} catch (Exception e) {
			
			LOGGER.info("@NotificationPayments pmtid:{} Consumo del servicio asincrono, "
					+ "no se obtiene ResponseEntity. {}", tx.getPmtId(), e.getMessage());
			
//			LOGGER.error("@NotificationPayments pmtid:{} error al consumir el "
//					+ "servicio \n{}", tx.getPmtId(), e.getMessage());
			
			result=false;
		}

		if (null == restClientStr || "".equals(restClientStr)) {
			
			result = true;
			LOGGER.info("@NotificationPayments pmtid:{}. output: "
					+ "El servicio no arrojo body en la respuesta.", tx.getPmtId());
			
		} else { // Si la respuesta contiene body se mapea el mensaje de error.
			
			result = true;
			
			TypeReference<NotificationPaymentsRs> typeRef = new TypeReference<NotificationPaymentsRs>() {};
	        ObjectMapper objectMapper = new ObjectMapper();
	        
	        try {
	        	NotificationPaymentsRs response = objectMapper.readValue(restClientStr, typeRef);
	        	LOGGER.info("@NotificationPayments pmtid:{} output:\n{}", tx.getPmtId(), response);
	        } catch (Exception e) {
	        	
		        LOGGER.error("@NotificationPayments pmtid:{} error al convertir el "
		        		+ "objeto Json \n{}", tx.getPmtId(), e);

		        LOGGER.error("@NotificationPayments pmtid:{} body del response: {}", 
		        			tx.getPmtId(), restClientStr);
	        }
		}
		return result;
		
	}

	/**
	 * Valida que la transaccion contenga los campos necesarios para el 
	 * generar el Request
	 * 
	 * @param tx
	 * @return
	 */
	private String checkTransaction(TransactionNotification tx) {
		
		String msg = "";

		if (null == tx.getBusinessCodeDesc()
				|| "".equals(tx.getBusinessCodeDesc()))
			msg += "Status, ";

		if (null == tx.getPmtId())
			msg += "PmtId, ";

		if (null == tx.getRquId().toString() || "".equals(tx.getRquId().toString()))
			msg += "RquId, ";

		if (null == tx.getTrnChannel() || "".equals(tx.getTrnChannel()))
			msg += "TrnChannel, ";

		if (null == tx.getCommerceNuraCode() || "".equals(tx.getCommerceNuraCode()))
			msg += "NuraCode, ";

		if (null == tx.getIpAddress() || "".equals(tx.getIpAddress()))
			msg += "IpAddress, ";
		
//		if (null == tx.getCustomerDocType() || "".equals(tx.getCustomerDocType()))
//			msg += "CustomerDocType, ";
//		
//		if (null == tx.getCustomerDocId() || "".equals(tx.getCustomerDocId()))
//			msg += "CustomerDocId, ";

		if("".equals(msg)) return null;
		else return msg;
		
	}
	
	private static List<Reference> convertReferenceStringListToReferenceTypeList(Map<String, String> inn) {
		List<Reference> out = new ArrayList<Reference>();
		Reference rt;
		if (inn == null) {
			rt = new Reference();
			rt.setRefId("0000000");
			rt.setRefType("0000000");
			out.add(rt);
			return out;
		}
		
		for(Entry<String, String> ref: inn.entrySet()){
			rt = new Reference();
			rt.setRefId(ref.getKey());
			rt.setRefType(ref.getValue());
			out.add(rt);
		}
		return out;
	}
	
}
