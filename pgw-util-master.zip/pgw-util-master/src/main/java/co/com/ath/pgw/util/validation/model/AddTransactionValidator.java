/*
 * AddTransactionValidator
 *  
 * GSI - Integración
 * Creado el: 19/09/2014
 *
 * Copyright (c) A Toda Hora S.A. Todos los derechos reservados
 * 
 * Este software es confidencial y es propietario de ATH, queda prohibido
 * su uso, reproducción y copia de manera parcial o permanente salvo autorización
 * expresa de A Toda Hora S.A o de quién represente sus derechos.
 */
package co.com.ath.pgw.util.validation.model;

import co.com.ath.pgw.bsn.dto.in.AddTransactionInDTO;
import co.com.ath.pgw.util.validation.ValidationException;

/**
 * Valida que las transacciones a ser añadidas en el core de la pasarela de pago
 * sean consistentes con los datos suministrados.
 * 
 * @author Andrés Méndez Juanias <proveedor_mamendez@ath.com.co>
 * @version 1.0 19 Sep 2014
 * @since 1.0
 */
public interface AddTransactionValidator {
	
	void validate(String pmtType, AddTransactionInDTO inDTO) throws ValidationException;
	
}
