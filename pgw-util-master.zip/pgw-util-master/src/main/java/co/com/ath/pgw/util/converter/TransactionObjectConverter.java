package co.com.ath.pgw.util.converter;

import java.math.BigDecimal;
import java.math.BigInteger;
import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.config.ConfigurableBeanFactory;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

import co.com.ath.pgw.in.dto.CreditCardPaymentAddRequest;
import co.com.ath.pgw.in.dto.CreditCardPaymentAddResponse;
import co.com.ath.pgw.in.dto.CreditCardPaymentAddRsType;
import co.com.ath.pgw.in.dto.PSETransactionAddRequest;
import co.com.ath.pgw.in.dto.PSETransactionAddResponse;
import co.com.ath.pgw.in.dto.PSETransactionAddRqType;
import co.com.ath.pgw.in.dto.PSETransactionAddRsType;
import co.com.ath.pgw.in.dto.RBMPaymentAddRqType;
import co.com.ath.pgw.in.dto.RBMPaymentAddRsType;
import co.com.ath.pgw.in.dto.TransactionAddRqType;
import co.com.ath.pgw.in.dto.TransactionAddRsType;
import co.com.ath.pgw.in.dto.TransactionInqRqType;
import co.com.ath.pgw.in.model.AgreementInfoType;
import co.com.ath.pgw.in.model.BankInfoType;
import co.com.ath.pgw.in.model.CardLogicalDataType;
import co.com.ath.pgw.in.model.CustNameType;
import co.com.ath.pgw.in.model.FeeType;
import co.com.ath.pgw.in.model.InvoiceReferenceType;
import co.com.ath.pgw.in.model.OrderInfoType;
import co.com.ath.pgw.in.model.PersonalDataType;
import co.com.ath.pgw.in.model.ReferenceType;
import co.com.ath.pgw.in.model.StatusType;
import co.com.ath.pgw.in.model.TaxFeeType;
import co.com.ath.pgw.in.model.TransactionStatusType;
import co.com.ath.pgw.in.model.TrnStatusType;
import co.com.ath.pgw.in.model.UserIdType;
import co.com.ath.pgw.util.constants.CoreConstants;

/**
 *  
 *  @RQ31820
 *  <strong>Autor</strong>Roger Jans Leguizamon Cespedes</br>
 *  <strong>Descripcion</strong>Integracion K7 con PSE</br>
 *  <strong>Numero de Cambios</strong>1</br>
 *  <strong>Identificador corto</strong>C01</br>
 * 
 */

@Component
@Scope(value= ConfigurableBeanFactory.SCOPE_SINGLETON)
public class TransactionObjectConverter {
	
	public  TransactionAddRqType  convertToTransactionAddRq(CreditCardPaymentAddRequest creditCardPaymentAddRq) {
		TransactionAddRqType transactionAddRqType = new TransactionAddRqType();
		
		transactionAddRqType.setAgreementId(creditCardPaymentAddRq.getCreditCardPaymentAddRq().getAgreementInfo().getAgreementId());
		transactionAddRqType.setChannel(creditCardPaymentAddRq.getCreditCardPaymentAddRq().getMsgRqHdr().getChannel());
		transactionAddRqType.setClientDt(creditCardPaymentAddRq.getCreditCardPaymentAddRq().getMsgRqHdr().getClientDt());
		transactionAddRqType.setIPAddr(creditCardPaymentAddRq.getCreditCardPaymentAddRq().getMsgRqHdr().getIPAddr());
		transactionAddRqType.setPmtType(creditCardPaymentAddRq.getCreditCardPaymentAddRq().getPmtType());
		transactionAddRqType.setRqUID(Long.valueOf(creditCardPaymentAddRq.getCreditCardPaymentAddRq().getRqUID()));
		transactionAddRqType.setTrnChannel(creditCardPaymentAddRq.getCreditCardPaymentAddRq().getTrnChannel());
		transactionAddRqType.setTrnType(creditCardPaymentAddRq.getCreditCardPaymentAddRq().getTrnType());
		
		FeeType feeType = creditCardPaymentAddRq.getCreditCardPaymentAddRq().getFee();
		transactionAddRqType.setFee(feeType);
		
		TaxFeeType taxFeeType = creditCardPaymentAddRq.getCreditCardPaymentAddRq().getTaxFee();
		taxFeeType.setCurRate(BigDecimal.ZERO);
		transactionAddRqType.setTaxFee(taxFeeType);
		 
		UserIdType userIdType = creditCardPaymentAddRq.getCreditCardPaymentAddRq().getMsgRqHdr().getUserId();
		transactionAddRqType.setUserId(userIdType);
		
		OrderInfoType orderInfoType = creditCardPaymentAddRq.getCreditCardPaymentAddRq().getOrderInfo();
		transactionAddRqType.setOrderInfo(orderInfoType);
		
		PersonalDataType personalDataType = new PersonalDataType();
		CustNameType custNameType = creditCardPaymentAddRq.getCreditCardPaymentAddRq().getPayingCustomer().getCustName();
		personalDataType.setCustName(custNameType);
		transactionAddRqType.setPersonalData(personalDataType);
		
		InvoiceReferenceType invoiceReferenceType = new InvoiceReferenceType();
		invoiceReferenceType.setPmtCodNIE(orderInfoType.getOrderId());
		transactionAddRqType.getInvoiceReference().add(invoiceReferenceType);
		
		ReferenceType refVentanilla = new ReferenceType();
		ReferenceType refTema = new ReferenceType();
		refVentanilla.setRefId(CoreConstants.VENTANILLA_PLANTILLA);
		refVentanilla.setRefType(BigDecimal.ZERO.toString());
		refTema.setRefId(CoreConstants.VENTANILLA_TEMA);
		refTema.setRefType(BigDecimal.ZERO.toString());
		
		transactionAddRqType.getReference().add(refVentanilla);
		transactionAddRqType.getReference().add(refTema);
		
		return transactionAddRqType;
	}
	
	public  RBMPaymentAddRqType  convertToRBMPaymentAddRq(CreditCardPaymentAddRequest creditCardPaymentAddRq) {
		RBMPaymentAddRqType paymentAddRqType = new RBMPaymentAddRqType();
		
		paymentAddRqType.setPmtId(creditCardPaymentAddRq.getCreditCardPaymentAddRq().getPmtId());
		paymentAddRqType.setRqUID(Long.valueOf(creditCardPaymentAddRq.getCreditCardPaymentAddRq().getRqUID()));
		paymentAddRqType.setChannel(creditCardPaymentAddRq.getCreditCardPaymentAddRq().getMsgRqHdr().getChannel());
		paymentAddRqType.setClientDt(creditCardPaymentAddRq.getCreditCardPaymentAddRq().getMsgRqHdr().getClientDt());
		paymentAddRqType.setIPAddr(creditCardPaymentAddRq.getCreditCardPaymentAddRq().getMsgRqHdr().getIPAddr());
		
		AgreementInfoType agreementInfoType = new AgreementInfoType();
		paymentAddRqType.setAgreementInfo(agreementInfoType);
		
		paymentAddRqType.getAgreementInfo().setAgreementId(creditCardPaymentAddRq.getCreditCardPaymentAddRq().getAgreementInfo().getAgreementId());
		paymentAddRqType.getAgreementInfo().setName(creditCardPaymentAddRq.getCreditCardPaymentAddRq().getAgreementInfo().getName());
		paymentAddRqType.getAgreementInfo().setNIT(creditCardPaymentAddRq.getCreditCardPaymentAddRq().getAgreementInfo().getNIT());
		
		UserIdType userIdType = creditCardPaymentAddRq.getCreditCardPaymentAddRq().getMsgRqHdr().getUserId();
		paymentAddRqType.setUserId(userIdType);
		
		paymentAddRqType.setInstalamentsNum(new BigInteger(creditCardPaymentAddRq.getCreditCardPaymentAddRq().getCardInfoUser().getInstalamentsNum()));
		
		CardLogicalDataType cardLogicalDataType = new CardLogicalDataType();
		cardLogicalDataType.setBrand(creditCardPaymentAddRq.getCreditCardPaymentAddRq().getCardInfoUser().getCardLogicalData().getBrand());
		cardLogicalDataType.setCardEmbossNum(creditCardPaymentAddRq.getCreditCardPaymentAddRq().getCardInfoUser().getCardLogicalData().getCardEmbossNum());
		cardLogicalDataType.setCardVrfyData(creditCardPaymentAddRq.getCreditCardPaymentAddRq().getCardInfoUser().getCardLogicalData().getCardVrfyData());
		cardLogicalDataType.setExpDt(creditCardPaymentAddRq.getCreditCardPaymentAddRq().getCardInfoUser().getCardLogicalData().getExpDt());
		cardLogicalDataType.setIssuerName(creditCardPaymentAddRq.getCreditCardPaymentAddRq().getCardInfoUser().getCardLogicalData().getIssuerName());
		cardLogicalDataType.setName(creditCardPaymentAddRq.getCreditCardPaymentAddRq().getCardInfoUser().getCardLogicalData().getName());
		paymentAddRqType.setCardLogicalData(cardLogicalDataType);
		
		FeeType feeType = creditCardPaymentAddRq.getCreditCardPaymentAddRq().getFee();
		paymentAddRqType.setFee(feeType);
		
		TaxFeeType taxFeeType = creditCardPaymentAddRq.getCreditCardPaymentAddRq().getTaxFee();
		taxFeeType.setCurRate(BigDecimal.ZERO);
		paymentAddRqType.setTaxFee(taxFeeType);
		
		OrderInfoType orderInfoType = creditCardPaymentAddRq.getCreditCardPaymentAddRq().getOrderInfo();
		paymentAddRqType.setOrderInfo(orderInfoType);
		
		List<PersonalDataType> listPersonal = new ArrayList<PersonalDataType>();
		PersonalDataType personalPayingData = new PersonalDataType();
		CustNameType custNameType = new CustNameType();
		personalPayingData.setCustName(custNameType);
		personalPayingData.getCustName().setFirstName(creditCardPaymentAddRq.getCreditCardPaymentAddRq().getPayingCustomer().getCustName().getFirstName());
		personalPayingData.getCustName().setLastName(creditCardPaymentAddRq.getCreditCardPaymentAddRq().getPayingCustomer().getCustName().getLastName());
		personalPayingData.getCustName().setLegalName(creditCardPaymentAddRq.getCreditCardPaymentAddRq().getPayingCustomer().getCustName().getLegalName());
		personalPayingData.getCustName().setNickName(creditCardPaymentAddRq.getCreditCardPaymentAddRq().getPayingCustomer().getCustName().getNickName());
		personalPayingData.setEmailAddr(creditCardPaymentAddRq.getCreditCardPaymentAddRq().getPayingCustomer().getEmailAddr());
		personalPayingData.setPhone(creditCardPaymentAddRq.getCreditCardPaymentAddRq().getPayingCustomer().getPhone());
		personalPayingData.setCustIdType(userIdType.getCustIdType());
		personalPayingData.setCustIdNum(userIdType.getCustIdNum());
		
		listPersonal.add(personalPayingData);
		listPersonal.add(personalPayingData);
		paymentAddRqType.setPersonalData(listPersonal);
		
		return paymentAddRqType;
	}
	
	public CreditCardPaymentAddResponse convertToRBMPaymentRs(RBMPaymentAddRsType paymentAddRType) {
		CreditCardPaymentAddResponse response = new CreditCardPaymentAddResponse(); 
		CreditCardPaymentAddRsType creditCardPaymentAddRsType = new CreditCardPaymentAddRsType();
		creditCardPaymentAddRsType.setApprovalId(paymentAddRType.getTransactionStatus().getApprovalId());
		creditCardPaymentAddRsType.setPmtId(paymentAddRType.getPmtId());
		creditCardPaymentAddRsType.setRqUID(paymentAddRType.getRqUID());
		
		StatusType status = new StatusType();
		status.setStatusCode(paymentAddRType.getStatusCode());
		status.setStatusDesc(paymentAddRType.getStatusDesc());
		
		creditCardPaymentAddRsType.setStatus(status);
		
		TransactionStatusType transactionStatus = new TransactionStatusType();
		transactionStatus.setTrnServerStatusCode(paymentAddRType.getTransactionStatus().getTrnServerStatusCode());
		transactionStatus.setTrnServerStatusDesc(paymentAddRType.getTransactionStatus().getTrnServerStatusDesc());
		TrnStatusType trnStatus = new TrnStatusType();
		
		if(paymentAddRType.getTransactionStatus().getTrnStatusCode() != null) {
			trnStatus.setTrnStatusCode(paymentAddRType.getTransactionStatus().getTrnStatusCode().toString());
			transactionStatus.setTrnStatus(trnStatus);
			transactionStatus.setTrnStatusDesc(paymentAddRType.getTransactionStatus().getTrnStatusDesc());
			transactionStatus.setTrnServerStatusCode(paymentAddRType.getTransactionStatus().getTrnServerStatusCode());
			transactionStatus.setTrnServerStatusDesc(paymentAddRType.getTransactionStatus().getTrnServerStatusDesc());
			if(paymentAddRType.getTransactionStatus().getCompensationDt() != null)
				transactionStatus.setCompensationDt(paymentAddRType.getTransactionStatus().getCompensationDt());
			if(paymentAddRType.getTransactionStatus().getApprovalId() != null)
				transactionStatus.setApprovalId(paymentAddRType.getTransactionStatus().getApprovalId());
			creditCardPaymentAddRsType.setTransactionStatus(transactionStatus);
		}		
		response.setCreditCardPaymentAddRs(creditCardPaymentAddRsType);
		return response;
	}
	
	
	public CreditCardPaymentAddResponse convertToRBMPaymentRs(TransactionAddRsType addRsType) {
		CreditCardPaymentAddResponse response = new CreditCardPaymentAddResponse(); 
		CreditCardPaymentAddRsType   creditCardPaymentAddRsType = new CreditCardPaymentAddRsType();
		if(addRsType.getTransactionStatus() != null && addRsType.getTransactionStatus().getApprovalId() != null)
			creditCardPaymentAddRsType.setApprovalId(addRsType.getTransactionStatus().getApprovalId());
		creditCardPaymentAddRsType.setPmtId(addRsType.getPmtId());
		creditCardPaymentAddRsType.setRqUID(addRsType.getRqUID());
		
		StatusType status = new StatusType();
		status.setStatusCode(addRsType.getStatusCode());
		status.setStatusDesc(addRsType.getStatusDesc());
		
		creditCardPaymentAddRsType.setStatus(status);
		creditCardPaymentAddRsType.setPortalURL(addRsType.getPortalURL());
		
		if( addRsType.getPortalURL() != null ) {
			String[] aToken = addRsType.getPortalURL().split("[?]");
			creditCardPaymentAddRsType.setToken(aToken[1].split("=")[1]);
		}
		
		TransactionStatusType transactionStatus = new TransactionStatusType();
		if( addRsType.getTransactionStatus() != null ) {
			transactionStatus.setTrnServerStatusCode(addRsType.getTransactionStatus().getTrnServerStatusCode());
			transactionStatus.setTrnServerStatusDesc(addRsType.getTransactionStatus().getTrnServerStatusDesc());
			creditCardPaymentAddRsType.setTransactionStatus(transactionStatus);
		}
		
		if( addRsType.getTransactionStatus() != null && addRsType.getTransactionStatus().getTrnStatusCode() != null) {
			TrnStatusType trnStatus = new TrnStatusType();
			trnStatus.setTrnStatusCode(addRsType.getTransactionStatus().getTrnStatusCode().toString());
			transactionStatus.setTrnStatus(trnStatus);
			transactionStatus.setTrnStatusDesc(addRsType.getTransactionStatus().getTrnStatusDesc());
			if(addRsType.getTransactionStatus().getCompensationDt() != null)
				transactionStatus.setCompensationDt(addRsType.getTransactionStatus().getCompensationDt());
			if(addRsType.getTransactionStatus().getApprovalId() != null)
				transactionStatus.setApprovalId(addRsType.getTransactionStatus().getApprovalId());
			transactionStatus.setTrnServerStatusCode(addRsType.getTransactionStatus().getTrnServerStatusCode());
			transactionStatus.setTrnServerStatusDesc(addRsType.getTransactionStatus().getTrnServerStatusDesc());
			creditCardPaymentAddRsType.setTransactionStatus(transactionStatus);
		}

		OrderInfoType orderInfoType = new OrderInfoType();
		orderInfoType.setOrderId(addRsType.getOrderInfo().getOrderId());
		orderInfoType.setDesc(addRsType.getOrderInfo().getDesc());

		creditCardPaymentAddRsType.setOrderInfo(orderInfoType);

		response.setCreditCardPaymentAddRs(creditCardPaymentAddRsType);
		return response;
	}
	
	public CreditCardPaymentAddResponse   createDefaultResponse(CreditCardPaymentAddRequest creditCardPaymentAddRq) {
		CreditCardPaymentAddResponse response = new CreditCardPaymentAddResponse(); 
		CreditCardPaymentAddRsType   CreditCardPaymentAddRsType = new CreditCardPaymentAddRsType();
		CreditCardPaymentAddRsType.setRqUID(creditCardPaymentAddRq.getCreditCardPaymentAddRq().getRqUID());
		StatusType status = new StatusType();
		status.setStatusCode(CoreConstants.ERROR_STATUS_CODE_300);
		status.setStatusDesc(CoreConstants.ERROR_STATUS_CODE_DESC_300);
		CreditCardPaymentAddRsType.setStatus(status);
		TransactionStatusType transactionStatus = new TransactionStatusType();
		transactionStatus.setTrnServerStatusCode(String.valueOf(CoreConstants.ERROR_STATUS_CODE_300));
		transactionStatus.setTrnServerStatusDesc(CoreConstants.ERROR_STATUS_CODE_DESC_300);
		CreditCardPaymentAddRsType.setTransactionStatus(transactionStatus);
		
		response.setCreditCardPaymentAddRs(CreditCardPaymentAddRsType);
		
		return response;
	}
	
	public CreditCardPaymentAddResponse convertToRBMPaymentRs(TransactionAddRsType addRsType, RBMPaymentAddRsType paymentAddRType) {
		CreditCardPaymentAddResponse response = new CreditCardPaymentAddResponse(); 
		CreditCardPaymentAddRsType   creditCardPaymentAddRsType = new CreditCardPaymentAddRsType();
		if(paymentAddRType.getTransactionStatus() != null && paymentAddRType.getTransactionStatus().getApprovalId() != null)
			creditCardPaymentAddRsType.setApprovalId(paymentAddRType.getTransactionStatus().getApprovalId());
		creditCardPaymentAddRsType.setPmtId(paymentAddRType.getPmtId());
		creditCardPaymentAddRsType.setRqUID(paymentAddRType.getRqUID());
		
		StatusType status = new StatusType();
		status.setStatusCode(paymentAddRType.getStatusCode());
		status.setStatusDesc(paymentAddRType.getStatusDesc());
		
		creditCardPaymentAddRsType.setStatus(status);
		creditCardPaymentAddRsType.setPortalURL(addRsType.getPortalURL());
		
		if( addRsType.getPortalURL() != null ) {
			String[] aToken = addRsType.getPortalURL().split("[?]");
			creditCardPaymentAddRsType.setToken(aToken[1].split("=")[1]);
		}
		
		TransactionStatusType transactionStatus = new TransactionStatusType();
		if( paymentAddRType.getTransactionStatus() != null ) {
			transactionStatus.setTrnServerStatusCode(paymentAddRType.getTransactionStatus().getTrnServerStatusCode());
			transactionStatus.setTrnServerStatusDesc(paymentAddRType.getTransactionStatus().getTrnServerStatusDesc());
			creditCardPaymentAddRsType.setTransactionStatus(transactionStatus);
		}
		
		if( paymentAddRType.getTransactionStatus() != null && paymentAddRType.getTransactionStatus().getTrnStatusCode() != null) {
			TrnStatusType trnStatus = new TrnStatusType();
			trnStatus.setTrnStatusCode(paymentAddRType.getTransactionStatus().getTrnStatusCode().toString());
			transactionStatus.setTrnStatus(trnStatus);
			transactionStatus.setTrnStatusCode(paymentAddRType.getTransactionStatus().getTrnStatusCode());
			transactionStatus.setTrnStatusDesc(paymentAddRType.getTransactionStatus().getTrnStatusDesc());
			if(paymentAddRType.getTransactionStatus().getCompensationDt() != null)
				transactionStatus.setCompensationDt(paymentAddRType.getTransactionStatus().getCompensationDt());
				transactionStatus.setEffDt(paymentAddRType.getTransactionStatus().getCompensationDt());
			if(paymentAddRType.getTransactionStatus().getApprovalId() != null)
				transactionStatus.setApprovalId(paymentAddRType.getTransactionStatus().getApprovalId());
			transactionStatus.setTrnServerStatusCode(paymentAddRType.getTransactionStatus().getTrnServerStatusCode());
			transactionStatus.setTrnServerStatusDesc(paymentAddRType.getTransactionStatus().getTrnServerStatusDesc());
			creditCardPaymentAddRsType.setTransactionStatus(transactionStatus);
		}

		OrderInfoType orderInfoType = new OrderInfoType();
		orderInfoType.setOrderId(addRsType.getOrderInfo().getOrderId());
		orderInfoType.setDesc(addRsType.getOrderInfo().getDesc());

		creditCardPaymentAddRsType.setOrderInfo(orderInfoType);

		response.setCreditCardPaymentAddRs(creditCardPaymentAddRsType);
		return response;
	}	
	
	/**
	 * INICIO C01
	 */
	public TransactionAddRqType convertToTransactionAddRq(PSETransactionAddRequest pseTransactionAddRq) {
		TransactionAddRqType transactionAddRqType = new TransactionAddRqType();
		
		transactionAddRqType.setAgreementId(pseTransactionAddRq.getPSETransactionAddRq().getAgreementInfo().getAgreementId());
		transactionAddRqType.setChannel(pseTransactionAddRq.getPSETransactionAddRq().getMsgRqHdr().getChannel());
		transactionAddRqType.setClientDt(pseTransactionAddRq.getPSETransactionAddRq().getMsgRqHdr().getClientDt());
		transactionAddRqType.setIPAddr(pseTransactionAddRq.getPSETransactionAddRq().getMsgRqHdr().getIPAddr());
		transactionAddRqType.setPmtType(pseTransactionAddRq.getPSETransactionAddRq().getPmtType());
		transactionAddRqType.setRqUID(Long.valueOf(pseTransactionAddRq.getPSETransactionAddRq().getRqUID()));
		transactionAddRqType.setTrnChannel(pseTransactionAddRq.getPSETransactionAddRq().getTrnChannel());
		transactionAddRqType.setTrnType(pseTransactionAddRq.getPSETransactionAddRq().getTrnType());
		
		FeeType feeType = pseTransactionAddRq.getPSETransactionAddRq().getFee();
		transactionAddRqType.setFee(feeType);
		
		TaxFeeType taxFeeType = pseTransactionAddRq.getPSETransactionAddRq().getTaxFee();
		taxFeeType.setCurRate(BigDecimal.ZERO);
		transactionAddRqType.setTaxFee(taxFeeType);
		
		UserIdType userIdType = pseTransactionAddRq.getPSETransactionAddRq().getMsgRqHdr().getUserId();
		transactionAddRqType.setUserId(userIdType);
		
		OrderInfoType orderInfoType = pseTransactionAddRq.getPSETransactionAddRq().getOrderInfo();
		transactionAddRqType.setOrderInfo(orderInfoType);
		
		PersonalDataType personalDataType = new PersonalDataType();
		CustNameType custNameType = pseTransactionAddRq.getPSETransactionAddRq().getPayingCustomer().getCustName();
		personalDataType.setCustName(custNameType);
		transactionAddRqType.setPersonalData(personalDataType);
		
		InvoiceReferenceType invoiceReferenceType = new InvoiceReferenceType();
		invoiceReferenceType.setPmtCodNIE(orderInfoType.getOrderId());
		transactionAddRqType.getInvoiceReference().add(invoiceReferenceType);
		
		ReferenceType refVentanilla = new ReferenceType();
		ReferenceType refTema = new ReferenceType();
		refVentanilla.setRefId(CoreConstants.VENTANILLA_PLANTILLA);
		refVentanilla.setRefType(BigDecimal.ZERO.toString());
		refTema.setRefId(CoreConstants.VENTANILLA_TEMA);
		refTema.setRefType(BigDecimal.ZERO.toString());
		
		transactionAddRqType.getReference().add(refVentanilla);
		transactionAddRqType.getReference().add(refTema);

		if(pseTransactionAddRq.getPSETransactionAddRq().getReference() != null && pseTransactionAddRq.getPSETransactionAddRq().getReference().size() > 0) {
			for (ReferenceType referenceType : pseTransactionAddRq.getPSETransactionAddRq().getReference()) {			
				if(referenceType.getRefId().equals(CoreConstants.REFERENCE_ID_TYPE_DOC)) {
					ReferenceType refIdTypeDoc = new ReferenceType();
					refIdTypeDoc.setRefId(referenceType.getRefId());
					refIdTypeDoc.setRefType(referenceType.getRefType());
					transactionAddRqType.getReference().add(refIdTypeDoc);
					break;
				}
			}
		}
		
		return transactionAddRqType;
	}
	
	public TransactionInqRqType convertToTransactionByTokenRq(TransactionAddRqType addRqType, TransactionAddRsType addRsType) {
		TransactionInqRqType transactionInqRqType = new TransactionInqRqType();
		
		transactionInqRqType.setRqUID(Long.valueOf(addRqType.getRqUID()));
		transactionInqRqType.setChannel(addRqType.getChannel());
		transactionInqRqType.setClientDt(addRqType.getClientDt());
		transactionInqRqType.setIPAddr(addRqType.getIPAddr());
		transactionInqRqType.setType(CoreConstants.INITIAL);
		
		if(addRsType.getPortalURL() != null) {
			String[] aToken = addRsType.getPortalURL().split("[?]");
			transactionInqRqType.setToken(aToken[1].split("=")[1]);
		}
		
		return transactionInqRqType;
	}
	
	public PSETransactionAddRqType convertToPSEPaymentAddRq(PSETransactionAddRequest pseTransactionAddRq) {
		PSETransactionAddRqType paymentAddRqType = new PSETransactionAddRqType();
		
		paymentAddRqType.setPmtId(pseTransactionAddRq.getPSETransactionAddRq().getPmtId());
		paymentAddRqType.setRqUID(Long.valueOf(pseTransactionAddRq.getPSETransactionAddRq().getRqUID()));
		paymentAddRqType.setChannel(pseTransactionAddRq.getPSETransactionAddRq().getMsgRqHdr().getChannel());
		paymentAddRqType.setClientDt(pseTransactionAddRq.getPSETransactionAddRq().getMsgRqHdr().getClientDt());
		paymentAddRqType.setIPAddr(pseTransactionAddRq.getPSETransactionAddRq().getMsgRqHdr().getIPAddr());
		
		AgreementInfoType agreementInfoType = new AgreementInfoType();
		paymentAddRqType.setAgreementInfo(agreementInfoType);
		
		paymentAddRqType.getAgreementInfo().setAgreementId(pseTransactionAddRq.getPSETransactionAddRq().getAgreementInfo().getAgreementId());
		paymentAddRqType.getAgreementInfo().setName(pseTransactionAddRq.getPSETransactionAddRq().getAgreementInfo().getName());
		paymentAddRqType.getAgreementInfo().setNIT(pseTransactionAddRq.getPSETransactionAddRq().getAgreementInfo().getNIT());
		
		UserIdType userIdType = pseTransactionAddRq.getPSETransactionAddRq().getMsgRqHdr().getUserId();
		paymentAddRqType.setUserId(userIdType);
		
		paymentAddRqType.setUserType(pseTransactionAddRq.getPSETransactionAddRq().getUserType());
		BankInfoType bankInfoType = new BankInfoType();
		bankInfoType.setBankId(pseTransactionAddRq.getPSETransactionAddRq().getBankInfo().getBankId());
		bankInfoType.setName(pseTransactionAddRq.getPSETransactionAddRq().getBankInfo().getName());
		bankInfoType.setBranchId(pseTransactionAddRq.getPSETransactionAddRq().getBankInfo().getBranchId());
		paymentAddRqType.setBankInfo(bankInfoType);
		
		FeeType feeType = pseTransactionAddRq.getPSETransactionAddRq().getFee();
		paymentAddRqType.setFee(feeType);
		
		TaxFeeType taxFeeType = pseTransactionAddRq.getPSETransactionAddRq().getTaxFee();
		taxFeeType.setCurRate(BigDecimal.ZERO);
		paymentAddRqType.setTaxFee(taxFeeType);
		
		OrderInfoType orderInfoType = pseTransactionAddRq.getPSETransactionAddRq().getOrderInfo();
		paymentAddRqType.setOrderInfo(orderInfoType);
		
		List<PersonalDataType> listPersonal = new ArrayList<PersonalDataType>();
		PersonalDataType personalPayingData = new PersonalDataType();
		CustNameType custNameType = new CustNameType();
		personalPayingData.setCustName(custNameType);
		personalPayingData.getCustName().setFirstName(pseTransactionAddRq.getPSETransactionAddRq().getPayingCustomer().getCustName().getFirstName());
		personalPayingData.getCustName().setLastName(pseTransactionAddRq.getPSETransactionAddRq().getPayingCustomer().getCustName().getLastName());
		personalPayingData.getCustName().setLegalName(pseTransactionAddRq.getPSETransactionAddRq().getPayingCustomer().getCustName().getLegalName());
		personalPayingData.getCustName().setNickName(pseTransactionAddRq.getPSETransactionAddRq().getPayingCustomer().getCustName().getNickName());
		personalPayingData.setEmailAddr(pseTransactionAddRq.getPSETransactionAddRq().getPayingCustomer().getEmailAddr());
		personalPayingData.setPhone(pseTransactionAddRq.getPSETransactionAddRq().getPayingCustomer().getPhone());
		personalPayingData.setCustIdType(userIdType.getCustIdType());
		personalPayingData.setCustIdNum(userIdType.getCustIdNum());
		
		listPersonal.add(personalPayingData);
		listPersonal.add(personalPayingData);
		paymentAddRqType.setPersonalData(listPersonal);
		
		ReferenceType refReturnURL = new ReferenceType();
		if(pseTransactionAddRq.getPSETransactionAddRq().getReference() != null && pseTransactionAddRq.getPSETransactionAddRq().getReference().size() > 0) {
			for (ReferenceType referenceType : pseTransactionAddRq.getPSETransactionAddRq().getReference()) {			
				if(referenceType.getRefId().equals( CoreConstants.RETURN_URL)) {
					refReturnURL.setRefId(referenceType.getRefId());
					refReturnURL.setRefType(referenceType.getRefType());
					break;
				}
			}
		}
		
		paymentAddRqType.getReference().add(refReturnURL);
		
		return paymentAddRqType;
	}
	
	public PSETransactionAddResponse convertToPSEPaymentRs(TransactionAddRsType addRsType, PSETransactionAddRsType paymentAddRType) {
		PSETransactionAddResponse response = new PSETransactionAddResponse(); 
		PSETransactionAddRsType pseTransactionAddRsType = new PSETransactionAddRsType();
		if(paymentAddRType.getTransactionStatus() != null && paymentAddRType.getTransactionStatus().getApprovalId() != null)
			pseTransactionAddRsType.setApprovalId(paymentAddRType.getTransactionStatus().getApprovalId());
		pseTransactionAddRsType.setPmtId(addRsType.getPmtId());
		pseTransactionAddRsType.setRqUID(paymentAddRType.getRqUID());
		
		pseTransactionAddRsType.setState("");
		pseTransactionAddRsType.setTrazabilityCode("");
		
		StatusType status = new StatusType();
		status.setStatusCode(paymentAddRType.getStatusCode());
		status.setStatusDesc(paymentAddRType.getStatusDesc());
		
		pseTransactionAddRsType.setStatus(status);
		pseTransactionAddRsType.setPortalURL(paymentAddRType.getPortalURL());
		
		if( addRsType.getPortalURL() != null ) {
			String[] aToken = addRsType.getPortalURL().split("[?]");
			pseTransactionAddRsType.setToken(aToken[1].split("=")[1]);
		}
		
		TransactionStatusType transactionStatus = new TransactionStatusType();
		if( paymentAddRType.getTransactionStatus() != null ) {
			transactionStatus.setTrnServerStatusCode(paymentAddRType.getTransactionStatus().getTrnServerStatusCode());
			transactionStatus.setTrnServerStatusDesc(paymentAddRType.getTransactionStatus().getTrnServerStatusDesc());	
			pseTransactionAddRsType.setTransactionStatus(transactionStatus);
		}
		
		if( paymentAddRType.getTransactionStatus() != null && paymentAddRType.getTransactionStatus().getTrnStatusCode() != null) {
			TrnStatusType trnStatus = new TrnStatusType();
			trnStatus.setTrnStatusCode(paymentAddRType.getTransactionStatus().getTrnStatusCode().toString());
			transactionStatus.setTrnStatus(trnStatus);
			transactionStatus.setTrnStatusDesc(paymentAddRType.getTransactionStatus().getTrnStatusDesc());
			if(paymentAddRType.getTransactionStatus().getCompensationDt() != null)
				transactionStatus.setCompensationDt(paymentAddRType.getTransactionStatus().getCompensationDt());
			if(paymentAddRType.getTransactionStatus().getApprovalId() != null)
				transactionStatus.setApprovalId(paymentAddRType.getTransactionStatus().getApprovalId());
			transactionStatus.setTrnServerStatusCode(paymentAddRType.getTransactionStatus().getTrnServerStatusCode());
			transactionStatus.setTrnServerStatusDesc(paymentAddRType.getTransactionStatus().getTrnServerStatusDesc());
			pseTransactionAddRsType.setTransactionStatus(transactionStatus);
		}

		OrderInfoType orderInfoType = new OrderInfoType();
		orderInfoType.setOrderId(addRsType.getOrderInfo().getOrderId());
		orderInfoType.setDesc(addRsType.getOrderInfo().getDesc());

		pseTransactionAddRsType.setOrderInfo(orderInfoType);

		response.setPSETransactionAddRs(pseTransactionAddRsType);
		return response;
	}
	
	public PSETransactionAddResponse convertToPSEPaymentRs(TransactionAddRsType addRsType) {
		PSETransactionAddResponse response = new PSETransactionAddResponse(); 
		PSETransactionAddRsType pseTransactionAddRsType = new PSETransactionAddRsType();
		if(addRsType.getTransactionStatus() != null && addRsType.getTransactionStatus().getApprovalId() != null)
			pseTransactionAddRsType.setApprovalId(addRsType.getTransactionStatus().getApprovalId());
		pseTransactionAddRsType.setPmtId(addRsType.getPmtId() != null && !addRsType.getPmtId().isEmpty() ? addRsType.getPmtId() : "");
		pseTransactionAddRsType.setRqUID(addRsType.getRqUID());
		
		pseTransactionAddRsType.setState("");
		pseTransactionAddRsType.setTrazabilityCode("");
		
		StatusType status = new StatusType();
		status.setStatusCode(addRsType.getStatusCode());
		status.setStatusDesc(addRsType.getStatusDesc());
		
		pseTransactionAddRsType.setStatus(status);
		pseTransactionAddRsType.setPortalURL("");
		
		if( addRsType.getPortalURL() != null ) {
			String[] aToken = addRsType.getPortalURL().split("[?]");
			pseTransactionAddRsType.setToken(aToken[1].split("=")[1]);
		}
		
		TransactionStatusType transactionStatus = new TransactionStatusType();
		if(addRsType.getTransactionStatus() != null ) {
			transactionStatus.setTrnServerStatusCode(addRsType.getTransactionStatus().getTrnServerStatusCode());
			transactionStatus.setTrnServerStatusDesc(addRsType.getTransactionStatus().getTrnServerStatusDesc());
			pseTransactionAddRsType.setTransactionStatus(transactionStatus);
		}
		
		if(addRsType.getTransactionStatus() != null && addRsType.getTransactionStatus().getTrnStatusCode() != null) {
			TrnStatusType trnStatus = new TrnStatusType();
			trnStatus.setTrnStatusCode(addRsType.getTransactionStatus().getTrnStatusCode().toString());
			transactionStatus.setTrnStatus(trnStatus);
			transactionStatus.setTrnStatusDesc(addRsType.getTransactionStatus().getTrnStatusDesc());
			if(addRsType.getTransactionStatus().getCompensationDt() != null)
				transactionStatus.setCompensationDt(addRsType.getTransactionStatus().getCompensationDt());
			if(addRsType.getTransactionStatus().getApprovalId() != null)
				transactionStatus.setApprovalId(addRsType.getTransactionStatus().getApprovalId());
			transactionStatus.setTrnServerStatusCode(addRsType.getTransactionStatus().getTrnServerStatusCode());
			transactionStatus.setTrnServerStatusDesc(addRsType.getTransactionStatus().getTrnServerStatusDesc());
			pseTransactionAddRsType.setTransactionStatus(transactionStatus);
		}

		OrderInfoType orderInfoType = new OrderInfoType();
		orderInfoType.setOrderId(addRsType.getOrderInfo().getOrderId());
		orderInfoType.setDesc(addRsType.getOrderInfo().getDesc());

		pseTransactionAddRsType.setOrderInfo(orderInfoType);

		response.setPSETransactionAddRs(pseTransactionAddRsType);
		return response;
	}
	/**
	 * FIN C01
	 */
}