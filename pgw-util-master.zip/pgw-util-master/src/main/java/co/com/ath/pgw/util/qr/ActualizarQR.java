package co.com.ath.pgw.util.qr;

import java.io.Serializable;

public class ActualizarQR implements Serializable {
	private String codigoUnico;
	private String terminalId;
	private String idTransaccion;
	private String fechaQR;
	private String estado;

	public ActualizarQR() {
		super();
	}

	public String getCodigoUnico() {
		return codigoUnico;
	}

	public void setCodigoUnico(String codigoUnico) {
		this.codigoUnico = codigoUnico;
	}

	public String getTerminalId() {
		return terminalId;
	}

	public void setTerminalId(String terminalId) {
		this.terminalId = terminalId;
	}

	public String getIdTransaccion() {
		return idTransaccion;
	}

	public void setIdTransaccion(String idTransaccion) {
		this.idTransaccion = idTransaccion;
	}

	public String getFechaQR() {
		return fechaQR;
	}

	public void setFechaQR(String fechaQR) {
		this.fechaQR = fechaQR;
	}

	public String getEstado() {
		return estado;
	}

	public void setEstado(String estado) {
		this.estado = estado;
	}

	public static long getSerialversionuid() {
		return serialVersionUID;
	}

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

}
