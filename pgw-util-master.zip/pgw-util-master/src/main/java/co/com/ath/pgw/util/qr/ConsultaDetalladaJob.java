package co.com.ath.pgw.util.qr;

import java.util.Date;

import org.quartz.Job;
import org.quartz.JobDataMap;
import org.quartz.JobExecutionContext;
import org.quartz.JobExecutionException;
import org.quartz.SchedulerException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class ConsultaDetalladaJob implements Job {
	
	private static final Logger LOGGER = LoggerFactory.getLogger(ConsultaDetalladaJob.class);
	
	
	private static int contador = 0;
	

	public void execute(JobExecutionContext context) throws JobExecutionException {
		JobDataMap dataMap = context.getJobDetail().getJobDataMap();
		long pmtId = dataMap.getLong("pmtId");
		int maxRepeticiones = dataMap.getInt("repeticion");

		int contador = ConsultaDetalladaJob.contador += 1;
		LOGGER.info("=========================>> ¡Hola, txt! :) " + pmtId + " contador " + contador + " de "
				+ maxRepeticiones + " " + new Date());
		try {
			if (contador == maxRepeticiones) {
				context.getScheduler().shutdown();
				LOGGER.info("===>>>>>> Fin del JOB");
			}
		} catch (SchedulerException e) {
			LOGGER.error("Error job consulta"+e);
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

}