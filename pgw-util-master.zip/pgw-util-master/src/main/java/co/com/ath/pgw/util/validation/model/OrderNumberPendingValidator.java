package co.com.ath.pgw.util.validation.model;

import co.com.ath.pgw.bsn.model.bo.TransactionBO;
import co.com.ath.pgw.util.validation.ValidationException;

/**
 * Validador del numero de orden en estado Pendiente.
 * 
 * @author proveedor_mamendez
 * @version 1.0 09-04-2015
 * @since 1.0
 */
public interface OrderNumberPendingValidator {

	/**
	 * Valida el numero de orden en estado Aprobado.
	 * @param transactionBO
	 * @throws ValidationException
	 */
	public void validate(String pmtType, TransactionBO transactionBO) throws ValidationException;

}