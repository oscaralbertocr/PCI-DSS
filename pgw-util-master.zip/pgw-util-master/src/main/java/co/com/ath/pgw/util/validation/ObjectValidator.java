/*
 * ObjectValidator
 *
 * GSI - Integración
 * Creado el: 5 de septiembre de 2014
 *
 * Copyright (c) A Toda Hora S.A. Todos los derechos reservados
 *
 * Este software es confidencial y es propietario de ATH, queda prohibido
 * su uso, reproducción y copia de manera parcial o permanente salvo autorización
 * expresa de A Toda Hora S.A o de quién represente sus derechos.
 */
package co.com.ath.pgw.util.validation;

import java.util.Locale;

import co.com.ath.pgw.util.i18n.ResourceBundleManager;

/**
 * Validador de objetos básicos: Contiene los atributos que comparten los 
 * validadores de objetos. Sirve como ayuda para implementar el patrón 
 * decorador para la validación de objetos simples.
 * 
 * @author proveedor_zagarcia
 * @version 1.0 05 Sep 2014
 * @since 1.0
 */
public abstract class ObjectValidator {

	/**
	 * Gestor de mensajes de Internacionalización.
	 */
	protected ResourceBundleManager bundleManager;
	
	/**
	 * Validador Interno
	 */
	protected ObjectValidator internalValidator;

	/**
	 * Construye un validador simple sin especificar el validador interno.
	 */
	protected ObjectValidator(){
		super();
	}
	
	/**
	 * Construye un validador simple especificando un validador interno.
	 * @param internalValidator	Validador interno
	 */
	protected ObjectValidator(ObjectValidator internalValidator){
		this.internalValidator = internalValidator;
	}

	/**
	 * Realiza la validación sobre el atributo y en caso de error arroja una excepción
	 * con el mensaje en el idioma seleccionado en el locale, si el Locale es nulo se
	 * utilizará el idioma por defecto del sistema.
	 * 
	 * @param object    Atributo a validar
	 * @param locale    Información de localización
	 * 
	 * @throws ObjectValidationException Esta excepción es lanzada si no se supera las
	 * 	validaciones.
	 */
	public void validate(Object object, Locale locale) throws ObjectValidationException{
		if (locale == null){
			locale = Locale.getDefault();
		}
		
		doValidate(object, locale);
		
		if (internalValidator != null) {
			internalValidator.validate(object, locale);
		}
	}

	/**
	 * Realiza la validación específica por parte del validador concreto.
	 * 
	 * @param object    Atributo a validar
	 * @param locale    Información de localización
	 * @throws ObjectValidationException Esta excepción es lanzada si no se supera las
	 * 	validaciones.
	 */
	protected abstract void doValidate(Object object, Locale locale) throws ObjectValidationException;

	/**
	 * Gestor de mensajes de Internacionalización.
	 * 
	 * @param bundleManager Gestor de Bundles
	 */
	public void setBundleManager(ResourceBundleManager bundleManager){
		this.bundleManager = bundleManager;
		if (internalValidator != null) {
			internalValidator.setBundleManager(bundleManager);
		}
	}

}