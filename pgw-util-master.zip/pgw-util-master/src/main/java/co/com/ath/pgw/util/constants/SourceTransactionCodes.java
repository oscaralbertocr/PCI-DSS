/*
 * SourceTransactionCodes
 *  
 * GSI - Integración
 * Creado el: 7/10/2014
 *
 * Copyright (c) A Toda Hora S.A. Todos los derechos reservados
 * 
 * Este software es confidencial y es propietario de ATH, queda prohibido
 * su uso, reproducción y copia de manera parcial o permanente salvo autorización
 * expresa de A Toda Hora S.A o de quién represente sus derechos.
 */
package co.com.ath.pgw.util.constants;

/**
 * Códigos de estado del origen de la transacción.
 * 
 * @author Andrés Méndez Juanias <proveedor_mamendez@ath.com.co>
 * @version 1.0 7/10/2014
 * @since 1.0
 * 
 *  @RQ28816
 *  <strong>Autor</strong>Camilo Bustamante</br>
 *  <strong>Descripcion</strong>Modificacion Reporte Comisiones - Baloto</br>
 *  <strong>Numero de Cambios</strong>1</br>
 *  <strong>Identificador corto</strong>C01</br>
 * 
 */
public interface SourceTransactionCodes {

	/** Código que identifica el origen Pasarela */
	Long PASARELA 		= 1L;
	
	/** Código que identifica el origen Call center */
	Long CALL_CENTER 	= 2L;
	
	/** Código que identifica el origen PB */
	Long PB 			= 3L;
	
	/** Código que identifica el origen de Core Pasarela */
	Long PASARELA_CORE 	= 4L;
	
	
	/**INICIO-C01*/
	
	/** Código que identifica el origen de K7 */
	Long K7 			= 5L;
	
	/** Código que identifica el origen del Banco AV Villas */
	Long BANCO_AV_VILLAS = 6L;

	/** Código que identifica el origen del Banco de Bogota  */
	Long BANCO_BOGOTA 	= 7L;
	
	/** Código que identifica el origen del Banco Popular*/
	Long BANCO_POPULAR 	= 8L;
	
	/** Código que identifica el origen del Banco de Occidente */
	Long BANCO_OCCIDENTE = 9L;
	
	/** Código que identifica el origen del Portal Baloto */
	Long BALOTO 		= 10L;
	
	
	
	/** Identificador de Transacciones Provenientes 
	 * Del Portal de Pagos Aval */
	String PORTAL_PAGOS_AVAL = "PPA";
	
	/** Identificador de Transacciones Provenientes 
	 * Del Portal Baloto */
	String PORTAL_PAGOS_BALOTO = "IGT";
	
	/**FIN-C01*/

}