package co.com.ath.pgw.bsn.service.rs;

import co.com.ath.ws.rs.objects.TransactionNotification;


public interface NotificationPayments {

	public boolean notification(TransactionNotification tx);
	
}
