package co.com.ath.pgw.util.mask;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Properties;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

/**
 * Utilidad de enmascarado de información
 * 
 * @author proveedor_sredondo
 * @version 1.0
 * @since 1.0
 */
@Service
public class MaskDataImpl implements MaskData {

	static Logger LOGGER = LoggerFactory.getLogger(MaskDataImpl.class);

	@Value("${pasarela.enmascara.initDigits}")
	private String initDigits;

	@Value("${pasarela.enmascara.finalDigits}")
	private String finalDigits;

	@Value("${pasarela.enmascara.indTruncar}")
	private String indTrunca;

	@Value("${pasarela.enmascara.trunkDigits}")
	private String trunkDigits;

	/**
	 * Método que enmascara la informacion enviada según los parámetros
	 * configurados en archivo de propiedades
	 * 
	 * @param data
	 *            - información a enmascarar
	 * @return maskedData - información enmascarada
	 */

	public String getMaskData(String data) {

		boolean indicativoTruncar = false;
		String maskedData = "";
		int initDig = 0;
		int finalDigit = 0;
		String parteEnmascarada = "";

		if (initDigits != null)
			initDig = Integer.parseInt(initDigits);
		if (finalDigits != null)
			finalDigit = Integer.parseInt(finalDigits);

		// Se realiza el proceso de enmascaramiento
		if (data != null) {
			try {
				String parteInicial = data.substring(0, initDig);
				String parteFinal = data.substring(data.length() - finalDigit);
				if ((parteInicial.length() + parteFinal.length()) <= data.length()) {
					parteEnmascarada = data.substring(initDig, data.length() - finalDigit);
				}
				// Se enmascara la información reemplazándola con *
				StringBuffer aux = new StringBuffer();
				for (int i = 0; i < parteEnmascarada.length(); i++) {
					aux.append('*');
				}

				parteEnmascarada = aux.toString();
				maskedData = parteInicial.concat(parteEnmascarada).concat(parteFinal);
			} catch (IndexOutOfBoundsException e) {
				LOGGER.info(
						"Error generado por longitud de cadena a enmascarar con respecto a parámetros de enmascarado."
								+ e);

			} catch (Exception e) {

				LOGGER.info("Error en llamado al método de enmascaramiento." + e);

			}

		}
		return maskedData;
	}

	/**
	 * Método que trunca una cadena de caracteres
	 * 
	 * @param string
	 *            - cadena a truncar
	 * @param charactersShow
	 *            - cantidad de caracteres a mostrar. Se muestran los últimos
	 *            caracteres
	 * @return truncatedString - cadena truncada
	 */

	public String getTruncateData(String data) {
		String truncatedString = null;
		int trunkDigit = 0;
		if (trunkDigits != null) {
			trunkDigit = Integer.parseInt(trunkDigits);
		}
		try {
			if (trunkDigit < data.length()) {
				truncatedString = data.substring(data.length() - trunkDigit);
				LOGGER.info("Dato Truncado."+truncatedString);
			} else {
				truncatedString = data;
			}
		} catch (Exception e) {

			LOGGER.info("Error truncando información."+e.getMessage());
		}
		return truncatedString;
	}

}
