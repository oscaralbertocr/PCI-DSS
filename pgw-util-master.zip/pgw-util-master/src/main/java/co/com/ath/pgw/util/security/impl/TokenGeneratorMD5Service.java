/*
 * TokenGeneratorMD5Service
 *  
 * GSI - Integración
 * Creado el: 3/10/2014
 *
 * Copyright (c) A Toda Hora S.A. Todos los derechos reservados
 * 
 * Este software es confidencial y es propietario de ATH, queda prohibido
 * su uso, reproducción y copia de manera parcial o permanente salvo autorización
 * expresa de A Toda Hora S.A o de quién represente sus derechos.
 */
package co.com.ath.pgw.util.security.impl;

import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.security.SecureRandom;
import java.util.ArrayList;
import java.util.List;
import java.util.Set;

import javax.crypto.Cipher;
import javax.crypto.KeyGenerator;
import javax.crypto.SecretKey;

import org.apache.commons.codec.binary.Base64;
import org.apache.commons.codec.binary.Hex;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import co.com.ath.pgw.util.constants.CoreConstants;
import co.com.ath.pgw.util.security.TokenGeneratorService;

/**
 * Class description goes here...
 * 
 * @author Andrés Méndez Juanias <proveedor_mamendez@ath.com.co>
 * @version 1.0 3/10/2014
 * @since 1.0
 */
@Service
public class TokenGeneratorMD5Service implements TokenGeneratorService {

	
	static Logger LOGGER = LoggerFactory.getLogger(TokenGeneratorMD5Service.class);
	
	@Override
	public String generate(Set<Object> args) {
		
		StringBuilder sb = new StringBuilder();
		StringBuilder result = new StringBuilder();
		
		for (Object o : args) {
			sb.append(o.toString());
			sb.append(CoreConstants.SEPARATOR_TOKEN_GENERATOR);
		}
		
		MessageDigest md;
		String algorithm = "SHA-256";
		
		try {
			md = MessageDigest.getInstance(algorithm);
		} catch (NoSuchAlgorithmException e) {
			LOGGER.info("No se pudo instanciar el algoritmo "+algorithm, e);
			return null;
		}
 
        byte[] messageDigest = md.digest(String.valueOf(sb.toString()).getBytes());
        
        for (int i = 0; i < messageDigest.length; i++) {
            result.append(Integer.toString((messageDigest[i] & 0xff) + 0x100, 16).substring(1));
        }
        
        String hashtext = result.toString();
        
        // Completa con ceros hasta lograr 64 caracteres
        while (hashtext.length() < 64) {
        	hashtext = "0" + hashtext;
		}
        return hashtext;
	}

}
