/*
 * IntValueValidator
 *
 * GSI - Integración
 * Creado el: 5 de septiembre de 2014
 *
 * Copyright (c) A Toda Hora S.A. Todos los derechos reservados
 *
 * Este software es confidencial y es propietario de ATH, queda prohibido
 * su uso, reproducción y copia de manera parcial o permanente salvo autorización
 * expresa de A Toda Hora S.A o de quién represente sus derechos.
 */
package co.com.ath.pgw.util.validation;

import java.util.Locale;

import co.com.ath.pgw.util.i18n.ResourceBundleManager;


/**
 * Realiza la validación de un atributo de tipo utilizando validadores simples
 * anidados
 * 
 * @author proveedor_zagarcia
 * @version 1.0 08 Sep 2014
 * @since 1.0
 */
public interface AtributeValidator {

	/**
	 * Realiza la validación de un atributo
	 * 
	 * @param object    Atributo a validar
	 * @param locale    Información de localización
	 * @throws ValidationException Cuando no se supera la validación del
	 * atributo
	 */
	public void validate(Object object, Locale locale) 
													throws ValidationException;

	/**
	 * Define el gestor de mensajes de internacionalización
	 * 
	 * @param bundleManager    Gestor de Bundles
	 */
	public void setBundleManager(ResourceBundleManager bundleManager);

}