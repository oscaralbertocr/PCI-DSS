/*
 * ErrorCode
 *
 * GSI - Integración
 * Creado el: 5 de septiembre de 2014
 *
 * Copyright (c) A Toda Hora S.A. Todos los derechos reservados
 *
 * Este software es confidencial y es propietario de ATH, queda prohibido
 * su uso, reproducción y copia de manera parcial o permanente salvo autorización
 * expresa de A Toda Hora S.A o de quién represente sus derechos.
 */
package co.com.ath.pgw.util.validation;

/**
 * Provee los códigos de error en la validación de atributos.
 * @author proveedor_zagarcia
 * @version 1.0 08 Sep 2014
 * @since 1.0
 */
public interface ErrorCode {
	
	/**
	 * Canal de origen inválido.
	 */
	int INVALID_CHANNEL_SOURCE = 1;
	
	/**
	 * Fecha de solicitud inválida.
	 */
	int INVALID_REQUEST_DATE = 2;
	
	/**
	 * Dirección IP Inválida.
	 */
	int INVALID_IP_ADDRESS = 3;
	
	/**
     * El tipo de documento del cliente no es válido.
     */
	int INVALID_DOCUMENT_TYPE = 4;
	
	/**
     * El número de identificación del cliente no es válido.
     */
	int INVALID_DOCUMENT_ID = 5;

	/**
	 * El identificador del convenio no es válido.
	 */
	int INVALID_AGREEMENT_ID = 6;
	
	/**
	 * La URL de retorno especificada no es válida.
	 */
	int INVALID_URL = 7;
	
	/**
	 * Datos de inicio de sesión inválidos.
	 */
	int INVALID_AUTH_DATA = 8;
	
	/**
	 * La dirección de email proporcionada no es válida.
	 */
	int INVALID_CUSTOMER_EMAIL = 9;
    
    /**
     * Error El valor total de la transaccion es inválido.
     */
    int INVALID_TOTAL_VALUE = 11;
    
    /** Error La moneda usada en la transacción no es válida. */
    int INVALID_CURRENCY_TYPE       = 12;
    
    /** Error El valor del impuesto no es válido. */
    int INVALID_TAX_VALUE           = 13;
    
    /** Error El tipo de transacción solicitada no es válida. */
    int INVALID_TRANSACTION_TYPE    = 14;
    
    /** Error El Identificador de la transacción es inválido. */
    int INVALID_TRANSACTION_ID      = 15;
    
    /** Error El token que identifica la transacción no es válido. */
    int INVALID_TRANSACTION_TOKEN   = 16;
    
    /** Error El número telefónico no es válido. */
    int INVALID_PHONE_NUMBER        = 17;
    
    /** Error El código del banco es inválido. */
    int INVALID_BANK_ID             = 18;
	
    /** Error El número de factura o referencia de pago es inválida. */
    int INVALID_ORDER_NUMBER        = 19;
    
    /** Error El tipo de cliente no es válido. */
    int INVALID_CUSTOMER_TYPE       = 20;
    
    /** Error La Franquicia es inválida. */
    int INVALID_BRAND               = 21;
    
    /** Error El número de la tarjeta de crédito no es válido. */
    int INVALID_CREDIT_CARD         = 22;
    
    /** Error El identficador del medio de pago no es válido. */
    int INVALID_PAYMENT_WAY         = 23;
    
    /** Error El identficador del medio de pago no es válido. */
    int INVALID_PRODUCT_TYPE        = 24;
    
    /** Error El identficador del medio de pago no es válido. */
    int INVALID_TRANSACTION_STATUS_FOR_OPERATON  = 25;
    
    /**
	 * Estado aprobado del numero de orden inválido.
	 */
	int INVALID_ORDER_NUMBER_APPROVED = 26;
	
	/**
	 * Estado pendiente del numero de orden inválido.
	 */
	int INVALID_ORDER_NUMBER_PENDING = 27;
	
	/**
	 * Estado de negocio inválido.
	 */
	int INVALID_BUSINES_STATUS = 28;
	
	/** Error El PmtId de la transacción es inválido. */
    int INVALID_TRANSACTION_PMTID      = 29;
    
    /** Error El campo {} es obligatorio. */
    int INVALID_FIELD_NULL_VALUE          = 500;
	
    /**
	 * Estado pendiente del transaccion pse.
	 */
	int INVALID_ORDER_NUMBER_PENDING_PSE = 30;
}