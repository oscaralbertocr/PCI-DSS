/*
 * TokenQueryType
 *  
 * GSI - Integración
 * Creado el: 17/04/2015
 *
 * Copyright (c) A Toda Hora S.A. Todos los derechos reservados
 * 
 * Este software es confidencial y es propietario de ATH, queda prohibido
 * su uso, reproducción y copia de manera parcial o permanente salvo autorización
 * expresa de A Toda Hora S.A o de quién represente sus derechos.
 */
package co.com.ath.pgw.util.constants;

/**
 * Enum con los posibles valores de Query type.
 *
 * @author Andrés Méndez Juanias <proveedor_mamendez@ath.com.co> 
 * @version 1.0 17/04/2015
 * @since 1.0
 */
public enum TokenQueryType {

	INITIAL,
	FINAL;
	
}
