/*
 * AbstractAttributeValidator
 *
 * GSI - Integración
 * Creado el: 5 de septiembre de 2014
 *
 * Copyright (c) A Toda Hora S.A. Todos los derechos reservados
 *
 * Este software es confidencial y es propietario de ATH, queda prohibido
 * su uso, reproducción y copia de manera parcial o permanente salvo autorización
 * expresa de A Toda Hora S.A o de quién represente sus derechos.
 */
package co.com.ath.pgw.util.validation;

import java.util.Locale;

import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;

import co.com.ath.pgw.util.i18n.ResourceBundleManager;

/**
 * Provee atributos para los validadores de atributos
 * 
 * @author proveedor_zagarcia
 * @created 1.0 08 Sep 2014
 * @since 1.0
 */
@Component
public abstract class AbstractAttributeValidator implements AtributeValidator {

	/**
	 * Gestor en la recuperación de mensajes de internacionalización
	 */
	protected ResourceBundleManager bundleManager;
	
	/**
	 * Determina si el atributo a validar es obligatorio
	 */
	private boolean mandatory;
	
	/**
	 * Construye un validador de un atributo.
	 */
	public AbstractAttributeValidator(){
		super();
	}

	/**
	 * Construye un validador de atributo indicando la obligatoriedad del 
	 * atributo a validar
	 * 
	 * @param mandatory    Indica si el atributo a validar es obligatorio
	 */
	public AbstractAttributeValidator(boolean mandatory){
		this.mandatory = mandatory;
	}

	/**
	 * Define el gestor de mensajes de internacionalización
	 * 
	 * @param bundleManager    Gestor de Bundles
	 */
	public void setBundleManager(ResourceBundleManager bundleManager){
		this.bundleManager = bundleManager;
	}

	/**
	 * Realiza la validación de un atributo
	 * 
	 * @param attribute    Atributo a validar
	 * @param locale    Información de localización
	 * @throws ValidationException 
	 */
	public void validate(Object attribute, Locale locale) 
													throws ValidationException{ 
		if (locale == null) {
			locale = Locale.getDefault();
		}
		
		if (mandatory) {
			doMandatoryValidate(attribute, locale);
		} else {
			doOptionalValidate(attribute, locale);
		}
	}
	
	/**
	 * Establece la obligatoriedad del atributo.
	 * 
	 * @param mandatory Obligatoriedad del atributo.
	 */
	public void setMandatory(boolean mandatory) {
		this.mandatory = mandatory;
	}

	/**
	 * Define la operación específica para que las subclases realicen la 
	 * validación cuando el atributo es obligatorio.
	 * 
	 * @param attribute Atributo a validar
	 * @param locale    Información de localización
	 * @throws ValidationException 
	 */
	protected abstract void doMandatoryValidate(Object attribute, Locale locale) 
													throws ValidationException;

	/**
	 * Define la operación específica para que las subclases realicen la 
	 * validación cuando el atributo es opcional.
	 * 
	 * @param attribute	Atributo a validar
	 * @param locale    Información de localización
	 */
	protected abstract void doOptionalValidate(Object attribute, Locale locale)
													throws ValidationException;

}