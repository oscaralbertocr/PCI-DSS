package co.com.ath.pgw.util.rest;

import java.util.Arrays;
import java.util.Collection;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.UUID;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.http.client.SimpleClientHttpRequestFactory;
import org.springframework.stereotype.Service;
import org.springframework.web.client.AsyncRestTemplate;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.util.UriComponentsBuilder;

import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;

import co.com.ath.pgw.util.constants.CoreConstants;

@Service
public class AbstractRestClient {
	
	static Logger LOGGER = LoggerFactory.getLogger(AbstractRestClient.class);

	public String consumeRest(String constantPathURL, Object request, HttpMethod method,
			HashMap<String, String> headersMap, boolean async) {
		String response = "";
		String urlInsertAuditLog = constantPathURL;
		AsyncRestTemplate asyncRestTemplate = new AsyncRestTemplate();
//		RestTemplate restTemplate = new RestTemplate();
		HttpHeaders headers = new HttpHeaders();
		headers.setContentType(MediaType.APPLICATION_JSON);
		headers.setAccept(Arrays.asList(MediaType.APPLICATION_JSON));
		headers.set(CoreConstants.HEADER_RQUID, String.valueOf(UUID.randomUUID()));
		headers.set(CoreConstants.HEADER_CHANNEL, CoreConstants.HEADER_VALUE_CHANNEL);
		headers.set(CoreConstants.HEADER_COMPANY, CoreConstants.HEADER_VALUE_COMPANY);

		if (headersMap != null && !headersMap.isEmpty()) {
			Iterator<String> iterator = headersMap.keySet().iterator();

			while (iterator.hasNext()) {
				String llave = iterator.next();
				String value = headersMap.get(llave);
				headers.set(llave, value);
			}
		}

		HttpEntity<Object> entity = new HttpEntity<>(request, headers);
		// System.out.println("Url: " + urlInsertAuditLog + "
		// <----------------------------------------------- > objeto " +
		// convertToJson(request));
		ResponseEntity<String> responseEntity = (ResponseEntity<String>) asyncRestTemplate.exchange(urlInsertAuditLog,
				method, entity, String.class);
		System.out.println("StatusCode from Service:" + responseEntity.getStatusCode());
		if (responseEntity.getStatusCode() == HttpStatus.CREATED || responseEntity.getStatusCode() == HttpStatus.OK
				|| responseEntity.getStatusCode() == HttpStatus.PARTIAL_CONTENT
				|| responseEntity.getStatusCode() == HttpStatus.INTERNAL_SERVER_ERROR) {
			response = responseEntity.getBody();
		}
		return response;
	}

	public String consumeRest(String constantPathURL, Object request, HttpMethod method,
			HashMap<String, String> headersMap) {
		String response = "";
		String urlInsertAuditLog = constantPathURL;
		RestTemplate restTemplate = new RestTemplate();
		HttpHeaders headers = new HttpHeaders();
		headers.setContentType(MediaType.APPLICATION_JSON);
		headers.setAccept(Arrays.asList(MediaType.APPLICATION_JSON));
		headers.set(CoreConstants.HEADER_RQUID, String.valueOf(UUID.randomUUID()));
		headers.set(CoreConstants.HEADER_CHANNEL, CoreConstants.HEADER_VALUE_CHANNEL);
		headers.set(CoreConstants.HEADER_COMPANY, CoreConstants.HEADER_VALUE_COMPANY);

		if (headersMap != null && !headersMap.isEmpty()) {
			Iterator<String> iterator = headersMap.keySet().iterator();

			while (iterator.hasNext()) {
				String llave = iterator.next();
				String value = headersMap.get(llave);
				headers.set(llave, value);
			}
		}
		
		LOGGER.info("Consumo servicio: \n{}", headers + "\n" + request);

		HttpEntity<Object> entity = new HttpEntity<>(request, headers);
		ResponseEntity<String> responseEntity = (ResponseEntity<String>) restTemplate.exchange(urlInsertAuditLog,
				method, entity, String.class);
		System.out.println("StatusCode from Service:" + responseEntity.getStatusCode());
		if (responseEntity.getStatusCode() == HttpStatus.CREATED || responseEntity.getStatusCode() == HttpStatus.OK
				|| responseEntity.getStatusCode() == HttpStatus.PARTIAL_CONTENT
				|| responseEntity.getStatusCode() == HttpStatus.INTERNAL_SERVER_ERROR) {
			response = responseEntity.getBody();
		}
		return response;
	}

	/**
	 * @param timeOut
	 * @return
	 */
	private SimpleClientHttpRequestFactory getClientHttpRequestFactory(String timeOut) {
		SimpleClientHttpRequestFactory clientHttpRequestFactory = new SimpleClientHttpRequestFactory();

		clientHttpRequestFactory.setConnectTimeout(Integer.parseInt(timeOut));
		clientHttpRequestFactory.setReadTimeout(Integer.parseInt(timeOut));
		return clientHttpRequestFactory;
	}

	/**
	 * Valida si un objeto dado esta vacio o nulo
	 * 
	 * @param object Objeto a ser validado
	 * @return true - si el objeto es vacio o nulo, false si el objeto tiene algún
	 *         valor
	 */
	public static boolean isObjectEmpty(Object object) {
		if (object == null)
			return true;
		else if (object instanceof String) {
			if (((String) object).trim().length() == 0) {
				return true;
			}
		} else if (object instanceof Collection) {
			return isCollectionEmpty((Collection<?>) object);
		}
		return false;
	}

	/**
	 * Valida si un objeto de tipo Collection es vacio o nulo
	 * 
	 * @param collection objeto a ser validad
	 * @return
	 */
	private static boolean isCollectionEmpty(Collection<?> collection) {
		if (collection == null || collection.isEmpty()) {
			return true;
		}
		return false;
	}

	public String convertToJson(Object object) {
		String jsonInString = "";
		if (!isObjectEmpty(object)) {
			ObjectMapper mapper = new ObjectMapper();
			// Ignore null field in serialization
			mapper.setSerializationInclusion(Include.NON_NULL);
			try {
				jsonInString = mapper.writeValueAsString(object);
				jsonInString.length();

			} catch (JsonProcessingException e) {
				jsonInString = "";
			}
		}
		jsonInString = jsonInString.replace('"', ' ');

		return jsonInString;

	}

	public String consumeGetRBM(String constantPathURL, Map<String, String> paramMap) {
		String response = "";
		String urlInsertAuditLog = constantPathURL;
		RestTemplate restTemplate = new RestTemplate();
		HttpHeaders headers = new HttpHeaders();
		headers.setContentType(MediaType.APPLICATION_JSON);
		headers.set(CoreConstants.HEADER_CHANNEL, CoreConstants.HEADER_VALUE_CHANNEL);
		headers.set(CoreConstants.HEADER_COMPANY, CoreConstants.HEADER_VALUE_COMPANY);
		headers.set(CoreConstants.HEADER_RQUID, String.valueOf(UUID.randomUUID()));
		headers.set(CoreConstants.HEADER_SERVICE_NAME, CoreConstants.HEADER_VALUE_SERVICE_NAME_CONSULTA);

		UriComponentsBuilder builder = UriComponentsBuilder.fromUriString(urlInsertAuditLog)
				.queryParam("idTerminal", paramMap.get("terminal"))
				.queryParam("idAdquiriente", paramMap.get("adquiriente"))
				.queryParam("idTransaccionTerminal", paramMap.get("transaccionTerminal"))
				.queryParam("fechaTransaccion", paramMap.get("fecTransaccion"));

		HttpEntity<Object> entity = new HttpEntity<>(headers);
		
		LOGGER.info("Inicio consulta detallada RBM: \n{}", headers + "\n" + builder.toUriString());

		ResponseEntity<String> responseEntity =  restTemplate.exchange(builder.toUriString(), HttpMethod.GET, entity,
				String.class);

		if (responseEntity.getStatusCode() == HttpStatus.CREATED || responseEntity.getStatusCode() == HttpStatus.OK
				|| responseEntity.getStatusCode() == HttpStatus.PARTIAL_CONTENT
				|| responseEntity.getStatusCode() == HttpStatus.INTERNAL_SERVER_ERROR) {
			response = responseEntity.getBody();
		}
		return response;
	}

}
