package co.com.ath.pgw.util.constants;

public enum Errors {

	VALIDATION0CODE("VALIDATION_0_CODE","0"),

	// Mensaje por llave desconocida
	UNKNOWNKEY("UNKNOWN_KEY","Llave no encontrada en Bundle: {0}"),

	// Mensajes globales de error
	GENERALERRORUNKNOWNERROR("GENERAL_ERROR_UNKNOWN_ERROR","Error desconocido"),

	// Mensajes para validadores de objetos
	VALIDATORATTRIBUTENULL("VALIDATORATTRIBUTE_NULL","El atributo es nulo."),
	VALIDATORATTRIBUTERQNULL("VALIDATOR_ATTRIBUTE_RQ_NULL","El RqUID es nulo."),
	VALIDATORATTRIBUTEEMPTY("VALIDATOR_ATTRIBUTE_EMPTY","El valor del atributo es vac\u00EDo."),
	VALIDATORATTRIBUTEINVALIDEMAIL("VALIDATOR_ATTRIBUTE_INVALIDEMAIL","Direcci\u00F3n de email inv\u00E1lida."),
	VALIDATORATTRIBUTENOINTVALUE("VALIDATOR_ATTRIBUTE_NOINTVALUE","{0} no puede representarse como un n\u00FAmero entero."),

	// Mensajes para validador de canal de origen
	VALIDATION1CODE("VALIDATION_1_CODE","1"),
	VALIDATION1DESCRIPTION("VALIDATION_1_DESCRIPTION","Canal de origen inv\u00E1lido."),
	VALIDATION1CODEIFX("VALIDATION_1_CODE_IFX","200"),
	VALIDATION1NOTFOUND("VALIDATION_1_NOTFOUND","No se encontr\u00F3 un canal de origen con el c\u00F3digo {0}."),

	// Mensajes para validador de fecha de solicitud
	VALIDATION2CODE("VALIDATION_2_CODE","2"),
	VALIDATION2DESCRIPTION("VALIDATION_2_DESCRIPTION","Fecha de solicitud inv\u00E1lida."),
	VALIDATION2CODEIFX("VALIDATION_2_CODE_IFX","200"),

	// Mensajes para validador de direccion IP
	VALIDATION3CODE("VALIDATION_3_CODE","3"),
	VALIDATION3DESCRIPTION("VALIDATION_3_DESCRIPTION","Direcci\u00F3n IP inv\u00E1lida."),
	VALIDATION3CODEIFX("VALIDATION_3_CODE_IFX","200"),

	// Mensajes para validador de tipo de documento.
	VALIDATION4CODE("VALIDATION_4_CODE","4"),
	VALIDATION4DESCRIPTION("VALIDATION_4_DESCRIPTION","El tipo de documento del cliente no es v\u00E1lido."),
	VALIDATION4CODEIFX("VALIDATION_4_CODE_IFX","200"),
	VALIDATION4NOTFOUND("VALIDATION_4_NOTFOUND","No existe un tipo de documento con id {0}."),

	// Mensajes para identificacion del cliente
	VALIDATION5CODE("VALIDATION_5_CODE","5"),
	VALIDATION5DESCRIPTION("VALIDATION_5_DESCRIPTION","El n\u00FAmero de identificaci\u00F3n del cliente no es v\u00E1lido."),
	VALIDATION5CODEIFX("VALIDATION_5_CODE_IFX","200"),
	
	// Mensajes para validador de convenios (Comercios)
	VALIDATION6CODE("VALIDATION_6_CODE","6"),
	VALIDATION6DESCRIPTION("VALIDATION_6_DESCRIPTION","El identificador del convenio no es v\u00E1lido."),
	VALIDATION6CODEIFX("VALIDATION_6_CODE_IFX","200"),
	VALIDATION6NOTFOUND("VALIDATION_6_NOTFOUND","No se encontr\u00F3 un comercio con el c\u00F3digo NURA {0}."),
	VALIDATION6DESCRIPTIONAGREEMENT("VALIDATION_6_DESCRIPTION_AGREEMENT", "Error: el convenio {0} ya existe."),
	VALIDATION6DESCRIPTIONTYPE("VALIDATION_6_DESCRIPTION_TYPE","El tipo de eliminado no existe"),
	VALIDATION6DESCRIPTIONINCOCREDITO("VALIDATION_6_DESCRIPTION_INCOCREDITO","el c\u00F3digo Incocredito {0}, se encuentra asignado a otro NIT"),
	VALIDATION6DESCRIPTIONTERMINAL("VALIDATION_6_DESCRIPTION_TERMINAL","el c\u00F3digo Terminal {0}, se encuentra asignado a otro c\u00F3digo Incocredito"),

	// Mensajes para validador de URL
	VALIDATION7CODE("VALIDATION_7_CODE","7"),
	VALIDATION7DESCRIPTION("VALIDATION_7_DESCRIPTION","La URL de retorno especificada no es v\u00E1lida."),
	VALIDATION7CODEIFX("VALIDATION_7_CODE_IFX","200"),

	// Mensajes para validador de Autenticacion
	VALIDATION8CODE("VALIDATION_8_CODE","8"),
	VALIDATION8DESCRIPTION("VALIDATION_8_DESCRIPTION","Datos de inicio de sesi\u00F3n inv\u00E1lidos."),
	VALIDATION8CODEIFX("VALIDATION_8_CODE_IFX","200"),

	// Mensajes para validador de email de cliente.

	VALIDATION9CODE("VALIDATION_9_CODE","9"),
	VALIDATION9DESCRIPTION("VALIDATION_9_DESCRIPTION","La direcci\u00F3n de email proporcionada no es v\u00E1lida."),
	VALIDATION9CODEIFX("VALIDATION_9_CODE_IFX","200"),
		
	// Mensajes para validador de valor total transaccion
	VALIDATION11CODE("VALIDATION_11_CODE","11"),
	VALIDATION11DESCRIPTION("VALIDATION_11_DESCRIPTION","El valor total de la transaccion es inv\u00E1lido."),
	VALIDATION11CODEIFX("VALIDATION_11_CODE_IFX","200"),
	VALIDATION11LESSOREQUALSTHANZERO("VALIDATION_11_LESSOREQUALSTHANZERO","El valor total es menor o igual a cero."),

	// Mensajes para validador de tipo de moneda (COP)
	VALIDATION12CODE("VALIDATION_12_CODE","12"),
	VALIDATION12DESCRIPTION("VALIDATION_12_DESCRIPTION","La moneda usada en la transacci\u00F3n no es v\u00E1lida."),
	VALIDATION12CODEIFX("VALIDATION_12_CODE_IFX","200"),
	VALIDATION12NOTSUPPORTED("VALIDATION_12_NOTSUPPORTED","El tipo de moenda {0} no est\u00E1 soportado."),

	// Mensajes para validador de Valor de impuesto
	VALIDATION13CODE("VALIDATION_13_CODE","13"),
	VALIDATION13DESCRIPTION("VALIDATION_13_DESCRIPTION","El valor del impuesto no es v\u00E1lido."),
	VALIDATION13CODEIFX("VALIDATION_13_CODE_IFX","200"),
	VALIDATION13LESSTHANZERO("VALIDATION_13_LESSTHANZERO","El valor del impuesto es menor que cero."),

	// Mensajes para validador de tipo de transaccion
	VALIDATION14CODE("VALIDATION_14_CODE","14"),
	VALIDATION14DESCRIPTION("VALIDATION_14_DESCRIPTION","El tipo de transacci\u00F3n solicitada no es v\u00E1lida."),
	VALIDATION14CODEIFX("VALIDATION_14_CODE_IFX","200"),
	VALIDATION14NOTFOUND("VALIDATION_14_NOTFOUND","No se encontr\u00F3 un tipo de tranzacci\u00F3n con c\u00F3digo {0}."),
	
	// Mensajes para validador de ID de transaccion
	VALIDATION15CODE("VALIDATION_15_CODE","15"),
	VALIDATION15DESCRIPTION("VALIDATION_15_DESCRIPTION","El Identificador de la transacci\u00F3n es inv\u00E1lido."),
	VALIDATION15CODEIFX("VALIDATION_15_CODE_IFX","200"),
	VALIDATION15NOTFOUND("VALIDATION_15_NOTFOUND","No se encontr\u00F3 una transacci\u00F3n con c\u00F3digo {0}"),
	VALIDATION15IDTRANSACTIONNURACODENOTFOUND("VALIDATION_15_IDTRANSACTIONNURACODE_NOTFOUND","No se ecnontr\u00F3 una transacci\u00F3n con el c\u00F3digo {0} del comercio {1}."),

	// Mensajes para validador de token de transaccion
	VALIDATION16CODE("VALIDATION_16_CODE","16"),
	VALIDATION16DESCRIPTION("VALIDATION_16_DESCRIPTION","El token que identifica la transacci\u00F3n no es v\u00E1lido."),
	VALIDATION16CODEIFX("VALIDATION_16_CODE_IFX","200"),
	VALIDATION16NOTFOUND("VALIDATION_16_NOTFOUND","No se encontr\u00F3 un token con el c\u00F3digo {0}."),
	VALIDATION16TIMEOUT("VALIDATION_16_TIMEOUT","El token con el c\u00F3digo {0} expiro."),

	// Mensajes para validador de numero telefonico
	VALIDATION17CODE("VALIDATION_17_CODE","17"),
	VALIDATION17DESCRIPTION("VALIDATION_17_DESCRIPTION","El n\u00FAmero telef\u00F3nico no es v\u00E1lido."),
	VALIDATION17CODEIFX("VALIDATION_17_CODE_IFX","200"),

	// Mensajes para validador de codigo del banco
	VALIDATION18CODE("VALIDATION_18_CODE","18"),
	VALIDATION18DESCRIPTION("VALIDATION_18_DESCRIPTION","El c\u00F3digo del banco es inv\u00E1lido."),
	VALIDATION18CODEIFX("VALIDATION_18_CODE_IFX","200"),
	VALIDATION18NOTFOUND("VALIDATION_18_NOTFOUND","No se encontr\u00F3 un banco con c\u00F3digo {0}."),
	VALIDATION18AVAVLCODENOTFOUND("VALIDATION_18_AVAVLCODENOTFOUND","No se encontr\u00F3 un banco con c\u00F3digo AVAL {0}."),

	// Mensajes para validador de numero de orden o factura
	VALIDATION19CODE("VALIDATION_19_CODE","19"),
	VALIDATION19DESCRIPTION("VALIDATION_19_DESCRIPTION","El n\u00FAmero de factura o referencia de pago es inv\u00E1lida."),
	VALIDATION19CODEIFX("VALIDATION_19_CODE_IFX","200"),

	// Mensajes para validador de numero de tipo de cliente
	VALIDATION20CODE("VALIDATION_20_CODE","20"),
	VALIDATION20DESCRIPTION("VALIDATION_20_DESCRIPTION","El tipo de cliente no es v\u00E1lido."),
	VALIDATION20CODEIFX("VALIDATION_20_CODE_IFX","200"),

	// Mensajes para validador de ID Franquicia 
	VALIDATION21CODE("VALIDATION_21_CODE","21"),
	VALIDATION21DESCRIPTION("VALIDATION_21_DESCRIPTION","La Franquicia es inv\u00E1lida."),
	VALIDATION21CODEIFX("VALIDATION_21_CODE_IFX","200"),
	VALIDATION21NOTFOUND("VALIDATION_21_NOTFOUND","No se encontr\u00F3 una franquicia con c\u00F3digo {0}."),

	// Mensajes para validador de Numero tarjeta de credito
	VALIDATION22CODE("VALIDATION_22_CODE","22"),
	VALIDATION22DESCRIPTION("VALIDATION_22_DESCRIPTION","El n\u00FAmero de la tarjeta de cr\u00E9dito no es v\u00E1lido."),
	VALIDATION22CODEIFX("VALIDATION_22_CODE_IFX","200"),

	// Mensajes para validador de medios de pago
	VALIDATION23CODE("VALIDATION_23_CODE","23"),
	VALIDATION23DESCRIPTION("VALIDATION_23_DESCRIPTION","El identificador del medio de pago no es v\u00E1lido"),
	VALIDATION23CODEIFX("VALIDATION_23_CODE_IFX","200"),
	VALIDATION23NOTFOUND("VALIDATION_23_NOTFOUND","No se encontr\u00F3 medio de pago con c\u00F3digo {0}."),

	// Mensajes para validador de tipos de producto
	VALIDATION24CODE("VALIDATION_24_CODE","24"),
	VALIDATION24DESCRIPTION("VALIDATION_24_DESCRIPTION","El tipo de producto no es v\u00E1lido."),
	VALIDATION24CODEIFX("VALIDATION_24_CODE_IFX","200"),
	VALIDATION24NOTFOUND("VALIDATION_24_NOTFOUND","No se encontr\u00F3 tipo de producto con c\u00F3digo {0}."),

	// Mensajes para validador de estado de la transaccion por operacion
	VALIDATION25CODE("VALIDATION_25_CODE","25"),
	VALIDATION25DESCRIPTION("VALIDATION_25_DESCRIPTION","El estado de la transacci\u00F3n para la operacion solicitada es inv\u00E1lido."),
	VALIDATION25CODEIFX("VALIDATION_25_CODE_IFX","200"),

	// Mensajes para validador de estado aprobado del numero de orden
	VALIDATION26CODE("VALIDATION_26_CODE","26"),
	VALIDATION26DESCRIPTION("VALIDATION_26_DESCRIPTION","No se puede iniciar la operaci\u00F3n debido a que el n\u00FAmero de referencia o n\u00FAmero de factura utilizado se encuentra actualmente asociado a otro proceso de pago iniciado previamente, por favor espere unos minutos e intente nuevamente hasta que el sistema obtenga el resultado final de la transacci\u00F3n"),
	VALIDATION26CODEIFX("VALIDATION_26_CODE_IFX","200"),
	
	// Mensajes para validador de estado pendiente del numero de orden
	VALIDATION27CODE("VALIDATION_27_CODE","27"),
	VALIDATION27DESCRIPTION("VALIDATION_27_DESCRIPTION","En este momento su #{0} presenta un proceso de pago cuya transacci\u00F3n se encuentra PENDIENTE de recibir confirmaci\u00F3n por parte de su entidad financiera, por favor espere unos minutos y vuelva a consultar mas tarde para verificar si su pago fue confirmado de forma exitosa. Si desea mayor informaci\u00F3n sobre el estado actual de su operaci\u00F3n puede comunicarse a nuestras l\u00EDneas de atenci\u00F3n al cliente al tel\u00E9fono {1} o enviar sus inquietudes al correo {2} y pregunte por el estado de la transacci\u00F3n id {3}"),
	VALIDATION27CODEIFX("VALIDATION_27_CODE_IFX","200"),
	
	// Mensajes para validador de estado pendiente del numero de orden
	VALIDATION28CODE("VALIDATION_28_CODE","28"),
	VALIDATION28DESCRIPTION("VALIDATION_28_DESCRIPTION","El estado de negocio no es v\u00E1lido"),
	VALIDATION28CODEIFX("VALIDATION_28_CODE_IFX","200"),
	VALIDATION28NOTFOUND("VALIDATION_28_NOTFOUND","No se encontr\u00F3 un estado de negocio con nombre {0}"),

	// Mensajes para validador de PMTID de transaccion
	VALIDATION29CODE("VALIDATION_29_CODE","29"),
	VALIDATION29DESCRIPTION("VALIDATION_29_DESCRIPTION","El pmtid de la transacci\u00F3n es inv\u00E1lido."),
	VALIDATION29CODEIFX("VALIDATION_29_CODE_IFX","200"),
	VALIDATION29NOTFOUND("VALIDATION_29_NOTFOUND","No se encontr\u00F3 una transacci\u00F3n con c\u00F3digo {0}"),
	VALIDATION29IDTRANSACTIONNURACODENOTFOUND("VALIDATION_29_IDTRANSACTIONNURACODE_NOTFOUND","No se encontr\u00F3 una transacci\u00F3n con el c\u00F3digo {0} del comercio {1}."),
	
	// Mensajes para validador de estado pendiente de las transacciones con medio de pago PSE
	VALIDATION30CODE("VALIDATION_30_CODE","30"),
	VALIDATION30DESCRIPTION("VALIDATION_30_DESCRIPTION","En este momento su #{0} presenta un proceso de pago cuya transacci\u00F3n se encuentra PENDIENTE de recibir confirmaci\u00F3n por parte de su entidad financiera, por favor espere unos minutos y vuelva a consultar mas tarde para verificar si su pago fue confirmado de forma exitosa. Si desea mayor informaci\u00F3n sobre el estado actual de su operaci\u00F3n puede comunicarse a nuestras l\u00EDneas de atenci\u00F3n al cliente al tel\u00E9fono {1} o enviar sus inquietudes al correo {2} y pregunte por el estado de la transacci\u00F3n {3}."),
	VALIDATION30CODEIFX("VALIDATION_30_CODE_IFX","200"),

	// Error en sincronizacion de convenios
	VALIDATION30SINCRONIZATIONENROLL("VALIDATION_30_SINCRONIZATION_ENROLL","Error en la operaci\u00F3n {0}, convenio CPV{1}."), 
	VALIDATION30SINCRONIZATIONMODIFY("VALIDATION_30_SINCRONIZATION_MODIFY","Error en la operaci\u00F3n {0}, convenio CPV{1}. Convenio no existe"),
	VALIDATION30SINCRONIZATIONDELETE("VALIDATION_30_SINCRONIZATION_DELETE","Error en la operaci\u00F3n {0}, convenio CPV{1}. Convenio no existe");
	
	private final String key;
	private final String value;
	
	Errors(String key, String value){
		this.key = key;
		this.value = value;
	}

	public String getKey() {
		return key;
	}

	public String getValue() {
		return value;
	}
	
}
