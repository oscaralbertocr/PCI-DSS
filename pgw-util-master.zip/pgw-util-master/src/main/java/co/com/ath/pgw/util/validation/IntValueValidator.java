/*
 * IntValueValidator
 *
 * GSI - Integración
 * Creado el: 5 de septiembre de 2014
 *
 * Copyright (c) A Toda Hora S.A. Todos los derechos reservados
 *
 * Este software es confidencial y es propietario de ATH, queda prohibido
 * su uso, reproducción y copia de manera parcial o permanente salvo autorización
 * expresa de A Toda Hora S.A o de quién represente sus derechos.
 */
package co.com.ath.pgw.util.validation;

import java.math.BigInteger;
import java.util.Locale;

import co.com.ath.pgw.util.i18n.BundleKeys;
import co.com.ath.pgw.util.i18n.BundleType;

/**
 * Valida si el valor del Objeto puede ser convertido a un valor entero.
 * 
 * @author proveedor_zagarcia
 * @version 1.0 05 Sep 2014
 * @since 1.0
 */
public class IntValueValidator extends ObjectValidator {

	/**
	 * Constuye un validador para números enteros.
	 */
	public IntValueValidator(){
		super();
	}
	
	/**
	 * Construye un validador para números enteros especificando el validador
	 * interno.
	 * 
	 * @param validator Validador interno.
	 */
	public IntValueValidator(ObjectValidator validator){
		super(validator);
	}

	@Override
	protected void doValidate(Object object, Locale locale) 
											throws ObjectValidationException{
		if (object instanceof Integer || object instanceof BigInteger) {
			return;
		}
		try {
			new BigInteger(object.toString());
		} catch (NumberFormatException e) {
			throw new ObjectValidationException(getMessage(object, locale));
		}
	}
	
	/**
	 * Retorna el mensaje de error en la validación en el idioma solicitado. Si
	 * el gestor de Bundle es nulo retorna el valor de la llave en el Bundle de
	 * error.
	 * 
	 * @param object Valor evaludado
	 * @param locale Información de idioma y localización
	 * @return Mensaje con el error
	 */
	private String getMessage(Object object, Locale locale) {
		if (bundleManager == null) {
			return BundleKeys.ERROR_NO_INT_VALUE;
		}
		bundleManager.setBundle(BundleType.ERRORS);
		return bundleManager.getMessage(
				BundleKeys.ERROR_NO_INT_VALUE, new Object[]{object}, locale);
	}

}