package co.com.ath.pgw.util.dto;

import java.io.Serializable;

import co.com.ath.pgw.core.logging.util.XMLUtil;

public class AuditEntityDTO implements Serializable{

	private static final long serialVersionUID = 1L;
	
	private String pmtId;

	private String codError;
	
	private String codAdiError;
	
	private int idService;
	
	public AuditEntityDTO() {
	}
	
	public AuditEntityDTO(String pmtId, String codError, String codAdiError, int idService) {
		this.pmtId = pmtId;
		this.codError = codError;
		this.codAdiError = codAdiError;
		this.idService = idService;
	}

	public String getPmtId() {
		return pmtId;
	}

	public void setPmtId(String pmtId) {
		this.pmtId = pmtId;
	}

	public String getCodError() {
		return codError;
	}

	public void setCodError(String codError) {
		this.codError = codError;
	}

	public String getCodAdiError() {
		return codAdiError;
	}

	public void setCodAdiError(String codAdiError) {
		this.codAdiError = codAdiError;
	}

	public int getIdService() {
		return idService;
	}

	public void setIdService(int idService) {
		this.idService = idService;
	}

	@Override
	public String toString() {
		XMLUtil<AuditEntityDTO> util = new XMLUtil<AuditEntityDTO>();
		return util.convertObjectToJson(this);
	}
	
}
