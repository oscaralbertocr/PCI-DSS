package co.com.ath.pgw.util.ftp;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.apache.commons.net.ftp.FTPSClient;

import com.jcraft.jsch.Channel;
import com.jcraft.jsch.ChannelSftp;
import com.jcraft.jsch.JSch;
import com.jcraft.jsch.JSchException;
import com.jcraft.jsch.Session;
import com.jcraft.jsch.SftpATTRS;
import com.jcraft.jsch.SftpException;




/**
 * 
 * Clase para enviar un archivo por SFTP.
 *
 * @author Nelly Rocio Linares <nelly.linares@sophossolutions.com>
 * @version 1.0 08/05/2019
 * 
 * 
 * @PCI 
 * <strong>Autor: </strong>Jesus Octavio Avendaño Sierra</br>
 * <strong>Fecha: </strong>23/07/2019</br>
 * <strong>Descripcion: </strong>Se agrega el envio del archivo por FTP</br>
 * <strong>Numero de Cambios: </strong>3</br>
 * <strong>Identificador corto: </strong>C01</br>
 * 
  * @PCI 
 * <strong>Autor: </strong>Dario Hernandez Rojas</br>
 * <strong>Fecha: </strong>08/01/2021</br>
 * <strong>Descripcion: </strong>se Agregan parametros de entrada 
 * a los metodos para que no sean tomados desde el archivo.properties</br>
 * <strong>Numero de Cambios: </strong>3</br>
 * <strong>Identificador corto: </strong>C02</br>
 * 

 *
 *
 **/

@Service
public class ConectionFTP {

	@Value(value = "${pasarela.ftp.host}")
	private String host;

	private String user;

	private String password;
	
	

	@Value(value = "${pasarela.ftp.basePath}")
	private String basePath;
	
	@Value(value = "${pasarela.ftp.port}") //C01
	private int port;

	static Logger LOGGER = LoggerFactory.getLogger(ConectionFTP.class);
	
	public ConectionFTP() {

	}
	
	/**
	 * 
	 * Constructor de la conexion
	 * 
	 * @param host el servidor al que se conectara
	 * @param user	el usuario con el se realizara la conexion
	 * @param basePath ruta origen del servidor
	 * @param contraseña del usuario
	 */
	/*Inicio-C02*/
	public ConectionFTP(String host, String user, String basePath, String password) {
		this.host = host;
		this.user = user;
		this.basePath = basePath;
		this.password = password;
	}

	/**
	 * 
	 * Método encargado de conectar al SSH (SFTP) y enviar el reporte de baloto.
	 * @author Nelly Rocio Linares
	 * @param fileName
	 * @param directorio
	 */
	public void conectar(String fileName, String directorio, String userFtp, String password) {
		Session session = null;
		Channel channel = null;
		ChannelSftp channelSftp = null;
		String pathFinal = basePath + directorio;
		JSch jsch = new JSch();
		try {
			LOGGER.info("Iniciando conexion FTP, se tratara de enviar el archivo: {}", fileName);
			LOGGER.info("Ruta: {}", directorio);
			session = jsch.getSession(userFtp, host, port);//C01
			session.setPassword(password);

			java.util.Properties config = new java.util.Properties();
			config.put("StrictHostKeyChecking", "no");
			session.setConfig(config);

			session.connect();

			channel = session.openChannel("sftp");
			channel.connect();

			LOGGER.info("Conectado al FTP ");
			channelSftp = (ChannelSftp) channel;

			SftpATTRS attrs = null;

				attrs = channelSftp.stat(pathFinal);

			if (attrs != null) {
				LOGGER.info("Directory exists IsDir= {}", attrs.isDir());
			} else {
				LOGGER.info("Creating dir {}", basePath);
				channelSftp.mkdir(pathFinal);
			}

			channelSftp.cd(pathFinal);

			File f = new File(fileName);
			channelSftp.put(new FileInputStream(f), f.getName());

		} catch (SftpException e) {
			LOGGER.error("Error para conectarse al ftp SftpException {}", e.getMessage());

		} catch (FileNotFoundException e) {
			LOGGER.error("El archivo no se encuentra en la ruta {}", e.getMessage());
		} catch (JSchException e) {
			LOGGER.error("Error para conectarse al ftp JSchException {}", e.getMessage());
		} catch (Exception e) {
			LOGGER.error("Excepcion {} ", e.getMessage());
			
		} finally {
			if (channelSftp != null) {
				channelSftp.exit();
			}
			if(channel != null) {
				channel.disconnect();
			}
			if(session != null) {
				session.disconnect();
			}
			LOGGER.info("Host Session disconnected.");
		}

	}
	
	//C01
	
	/**
	 * Método encargado de conectar al FTP y enviar el reporte de baloto.
	 * @author Jesus Octavio Avendaño
	 * @Idmodificación C01
	 * @return Step
	 */
	public void uploadReportFTP(String fileName, String directorio, String User, String password) {
		FTPSClient ftp = new FTPSClient("TLS");
		File file = new File(fileName);
		String pathFinal = basePath + directorio;
		try {
			ftp.connect(host,port);
			if(ftp.login(user, password)) {
				LOGGER.info("Conexion con el FTP Correcta");
				ftp.enterLocalPassiveMode();
				ftp.changeWorkingDirectory(pathFinal);
				ftp.storeFile(file.getName(), new FileInputStream(file));
				ftp.disconnect();
			}else{
				LOGGER.info("Conexion Fallida");
			}
		} catch (Exception e) {
			LOGGER.error("Error para conectarse al ftp");
			e.printStackTrace();
		}finally {
			file = null;
			ftp = null;
		}
	}
	/*Fin-C02*/
	public String getHost() {
		return host;
	}

	public void setHost(String host) {
		this.host = host;
	}

	public String getUser() {
		return user;
	}

	public void setUser(String user) {
		this.user = user;
	}

	public String getBasePath() {
		return basePath;
	}

	public void setBasePath(String basePath) {
		this.basePath = basePath;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

}
