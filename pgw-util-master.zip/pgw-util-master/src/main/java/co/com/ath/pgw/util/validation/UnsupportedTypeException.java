/*
 * UnsupportedTypeException
 *
 * GSI - Integración
 * Creado el: 5 de septiembre de 2014
 *
 * Copyright (c) A Toda Hora S.A. Todos los derechos reservados
 *
 * Este software es confidencial y es propietario de ATH, queda prohibido
 * su uso, reproducción y copia de manera parcial o permanente salvo autorización
 * expresa de A Toda Hora S.A o de quién represente sus derechos.
 */
package co.com.ath.pgw.util.validation;

/**
 * Excepci&oacute;n no chequeada que se lanza por un validador de objetos cuando no
 * soporta el tipo de objeto que va a validar.
 * 
 * @see ObjectValidator
 * 
 * @author proveedor_zagarcia
 * @version 1.0 05 Sep 2014
 * @since 1.0
 */
public class UnsupportedTypeException extends RuntimeException {

	/**
	 * Serial generado
	 */
	private static final long serialVersionUID = 6592594660217526001L;


	/**
	 * Crea un UnsupportedTypeException con el mensaje de error
	 * @param message    Mensaje de la Excepcion
	 */
	public UnsupportedTypeException(String message){
		super(message);
	}

}