package co.com.ath.pgw.util.qr;

import java.io.Serializable;
import java.util.Date;
import java.util.List;

public class InformacionQR implements Serializable {

	private long idTransaccion;
	private Date fechaRespuesta;
	private CodigoQR codigoQR;
	private List<ParametroDTO> lstParametro;

	public InformacionQR() {
		super();
	}

	public long getIdTransaccion() {
		return idTransaccion;
	}

	public void setIdTransaccion(long idTransaccion) {
		this.idTransaccion = idTransaccion;
	}

	public Date getFechaRespuesta() {
		return fechaRespuesta;
	}

	public void setFechaRespuesta(Date fechaRespuesta) {
		this.fechaRespuesta = fechaRespuesta;
	}

	public CodigoQR getCodigoQR() {
		return codigoQR;
	}

	public void setCodigoQR(CodigoQR codigoQR) {
		this.codigoQR = codigoQR;
	}

	public List<ParametroDTO> getLstParametro() {
		return lstParametro;
	}

	public void setLstParametro(List<ParametroDTO> lstParametro) {
		this.lstParametro = lstParametro;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "InformacionQR [idTransaccion=" + idTransaccion + ", fecha=" + fechaRespuesta + ", codigoQR=" + codigoQR
				+ ", lstParametro=" + lstParametro + "]";
	}

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

}
