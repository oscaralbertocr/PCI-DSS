/*
 * PropertiesResourceBundleManager
 *
 * GSI - Integración
 * Creado el: 22 de agosto de 2014
 *
 * Copyright (c) A Toda Hora S.A. Todos los derechos reservados
 *
 * Este software es confidencial y es propietario de ATH, queda prohibido
 * su uso, reproducción y copia de manera parcial o permanente salvo autorización
 * expresa de A Toda Hora S.A o de quién represente sus derechos.
 */
package co.com.ath.pgw.util.i18n;

import java.text.MessageFormat;
import java.util.Locale;
import java.util.MissingResourceException;

import org.springframework.stereotype.Component;

import co.com.ath.pgw.util.constants.Errors;
import co.com.ath.pgw.util.constants.Messages;

/**
 * Implementa las funcionalidades de {@link ResourceBundleManager} usando 
 * archivos de propiedades (.properties)
 * @author proveedor_zagarcia
 * @version 1.0
 * @since 1.0
 */
@Component
public class PropertiesResourceBundleManager implements ResourceBundleManager {

	/**
	 * Tipo de Bundle actual
	 */
	private BundleType bundleType;

	/**
	 * Formateador de texto
	 */
	private MessageFormat formatter;

	/**
	 * Constructor de {@link PropertiesResourceBundleManager}
	 */
	public PropertiesResourceBundleManager(){
		//Por defecto el Bundle es el de mensajes
		bundleType = BundleType.MESSAGES;
		formatter = new MessageFormat("");
	}

	@Override
	public void setBundle(BundleType bundleType) {
		this.bundleType = bundleType;
	}

	@Override
	public String getMessage(String key, Object[] args, Locale locale) {
		synchronized (formatter) {
			
			key = key.toUpperCase().replaceAll("\\.", "");
			
			if (bundleType.toString().endsWith("Messages")) {
				Messages mensaje = Messages.valueOf(key);	
				try {
					formatter.applyPattern(mensaje.getValue());
				} catch (MissingResourceException e) {
					formatter.applyPattern(Messages.valueOf("UNKNOWNKEY").getValue());
				}			
			}else if (bundleType.toString().endsWith("Errors")) {
				Errors error = Errors.valueOf(key);
				try {
					formatter.applyPattern(error.getValue());
				} catch (MissingResourceException e) {
					formatter.applyPattern(Messages.valueOf("UNKNOWNKEY").getValue());
				}
			}			

			return formatter.format(args);
		}

	}

}
