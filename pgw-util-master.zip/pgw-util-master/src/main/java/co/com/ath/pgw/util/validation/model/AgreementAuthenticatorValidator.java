package co.com.ath.pgw.util.validation.model;

import co.com.ath.pgw.util.validation.ValidationException;

/**
 * Validador de datos de autenticación de un convenio.
 * 
 * @author proveedor_zagarcia
 * @version 1.0 22-sep-2014
 * @since 1.0
 */
public interface AgreementAuthenticatorValidator {

	/**
	 * Valida los datos de autenticación de una comercio al iniciar una
	 * transacción.
	 * 
	 * @param authData    Datos de autenticación del comercio al iniciar una
	 * transacción
	 * @throws ValidationException Si el nombre de usuario no coincide con la
	 * contraseña del comercio.
	 */
	public void validate(AgreementAuthData authData) throws ValidationException;

}