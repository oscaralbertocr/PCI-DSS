/*
 * TransactionStatusEnum
 *  
 * GSI - Integración
 * Creado el: 22/10/2014
 *
 * Copyright (c) A Toda Hora S.A. Todos los derechos reservados
 * 
 * Este software es confidencial y es propietario de ATH, queda prohibido
 * su uso, reproducción y copia de manera parcial o permanente salvo autorización
 * expresa de A Toda Hora S.A o de quién represente sus derechos.
 */
package co.com.ath.pgw.util.enums;

/**
 * Class description goes here...
 *
 * @author Andrés Méndez Juanias <proveedor_mamendez@ath.com.co> 
 * @version 1.0 22/10/2014
 * @since 1.0
 * 
 *  @RQ27199
 *  <strong>Autor</strong>Camilo Bustamante</br>
 *  <strong>Descripcion</strong>Ajuste de Estado, Manejo de Topes</br>
 *  <strong>Numero de Cambios</strong>1</br>
 *  <strong>Identificador corto</strong>C01</br>
 *  
 */
public enum TransactionStatusEnum {
	
	REGISTERED  (1L, "transaction.status.registered"),
    LOGGED_IN   (2L, "transaction.status.logged_in"),
    PROCESSING  (3L, "transaction.status.processing"),
    CANCELLED   (4L, "transaction.status.cancelled"),
    FAILED		(5L, "transaction.status.failed"),
    CONFIRMED_OK(6L, "transaction.status.confirmed_ok"),
    CONFIRMED_NA(7L, "transaction.status.confirmed_na"),
	EXPIRED		(8L, "transaction.status.expired"),
	/** INI C01 **/
	REFUSED		(9L, "transaction.status.refused");
	/** FIN C01 **/
	
	/** ID único del estado de la transacción */
	private Long code;
	
	/** Código del mensaje para el estado de la transacción */
	private String messageCode;
	
	TransactionStatusEnum(Long code, String messageCode){
		this.code = code;
		this.messageCode = messageCode;
	}

	/**
	 * Método encargado de recuperar el valor del atributo id.
	 * @return El atributo id asociado a la clase.
	 */
	public Long getCode() {
		return code;
	}

	/**
	 * Método encargado de actualizar el atributo id.
	 * @param code Nuevo valor para id.
	 */
	public void setCode(Long code) {
		this.code = code;
	}

	/**
	 * Método encargado de recuperar el valor del atributo messageCode.
	 * @return El atributo messageCode asociado a la clase.
	 */
	public String getMessageCode() {
		return messageCode;
	}

	/**
	 * Método encargado de actualizar el atributo messageCode.
	 * @param messageCode Nuevo valor para messageCode.
	 */
	public void setMessageCode(String messageCode) {
		this.messageCode = messageCode;
	}
	
}
