package co.com.ath.pgw.util.converter;

import java.util.ArrayList;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.List;
import java.util.Objects;
import java.util.StringTokenizer;

import javax.xml.datatype.DatatypeConfigurationException;
import javax.xml.datatype.DatatypeFactory;
import javax.xml.datatype.XMLGregorianCalendar;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpStatus;

import co.com.ath.pgw.bsn.dto.in.ConsultarEstadoDePagoInDTO;
import co.com.ath.pgw.bsn.dto.in.CoreGetStateRBMPaymentInDTO;
import co.com.ath.pgw.bsn.dto.in.IniciarTransaccionInDTO;
import co.com.ath.pgw.bsn.dto.out.IniciarTransaccionOutDTO;
import co.com.ath.pgw.bsn.globalPay.dto.ConsultarEstadoDePagoRqType;
import co.com.ath.pgw.bsn.globalPay.dto.ConsultarEstadoDePagoRsType;
import co.com.ath.pgw.bsn.globalPay.dto.IniciarTransaccionDeCompraRqType;
import co.com.ath.pgw.bsn.globalPay.dto.IniciarTransaccionDeCompraRsType;
import co.com.ath.pgw.bsn.globalPay.model.AgreementInfoType;
import co.com.ath.pgw.bsn.globalPay.model.CoreGetStateRBMPaymentRqType;
import co.com.ath.pgw.bsn.globalPay.model.CoreGetStateRBMPaymentRsType;
import co.com.ath.pgw.bsn.globalPay.model.CoreInitTransactionRbmRqType;
import co.com.ath.pgw.bsn.globalPay.model.CoreInitTransactionRbmRsType;
import co.com.ath.pgw.bsn.globalPay.model.CustNameType;
import co.com.ath.pgw.bsn.globalPay.model.FeeType;
import co.com.ath.pgw.bsn.globalPay.model.OrderInfoType;
import co.com.ath.pgw.bsn.globalPay.model.PersonalDataType;
import co.com.ath.pgw.bsn.globalPay.model.ReferenceType;
import co.com.ath.pgw.bsn.globalPay.model.TaxFeeType;
import co.com.ath.pgw.bsn.globalPay.model.UserIdType;
import co.com.ath.pgw.bsn.dto.out.ConsultarEstadoDePagoOutDTO;
import co.com.ath.pgw.bsn.dto.out.CoreGetStateRBMPaymentOutDTO;
import co.com.ath.pgw.bsn.dto.out.CoreInitTransactionRbmOutDTO;
import co.com.ath.pgw.bsn.model.bo.TransactionBO;
import co.com.ath.pgw.bsn.model.bo.TransactionSourceBO;
import co.com.ath.pgw.client.globalPay.dto.ConsultarEstadoDePagoRespuestaResponse;
import co.com.ath.pgw.client.globalPay.dto.ConsultarEstadoDePagoSolicitudRequest;
import co.com.ath.pgw.client.globalPay.dto.IniciarTransaccionDeCompraRespuestaResponse;
import co.com.ath.pgw.client.globalPay.dto.IniciarTransaccionDeCompraSolicitudRequest;
import co.com.ath.pgw.client.globalPay.model.TipoCabeceraSolicitud;
import co.com.ath.pgw.client.globalPay.model.TipoEstadoActualTransaccion;
import co.com.ath.pgw.client.globalPay.model.TipoIdPersona;
import co.com.ath.pgw.client.globalPay.model.TipoInfoComercio;
import co.com.ath.pgw.client.globalPay.model.TipoInfoCompra;
import co.com.ath.pgw.client.globalPay.model.TipoInfoImpuestos;
import co.com.ath.pgw.client.globalPay.model.TipoInfoPersona;
import co.com.ath.pgw.client.globalPay.model.TipoInfoPuntoInteraccion;
import co.com.ath.pgw.client.globalPay.model.TipoTipoDocumento;
import co.com.ath.pgw.client.globalPay.model.TipoTipoImpuesto;
import co.com.ath.pgw.in.model.CabeceraRespuestaType;
import co.com.ath.pgw.in.model.InfoPuntoInteraccionType;
import co.com.ath.pgw.in.model.InfoRespuestaType;
import co.com.ath.pgw.in.model.InfoTransaccionRespType;
import co.com.ath.pgw.util.constants.CoreConstants;

/**
 * Implementación de servicio puente para las peticiones entre los servicios de
 * PaymentGlobalPay y el Core
 * 
 * @author camilo.bustamante@sophossolutions.com
 * @version 1.0 03 Enero 2019
 * @RQ31686 RBM_Integracion_Boton_TC_GlobalPay
 * 
 */
public class GlobalPayObjectConverter {

	static Logger LOGGER = LoggerFactory.getLogger(GlobalPayObjectConverter.class);
	
	private static final int PMTID_LIMIT = 6;
	private static final int NAME_LIMIT = 24;

	public static IniciarTransaccionInDTO convertIniciarTransaccionDeCompraRsTypeToIniciarTransaccionInDTO(
			IniciarTransaccionDeCompraRqType inn) {
		
		IniciarTransaccionInDTO out = new IniciarTransaccionInDTO();
		
		out.setClientDt(DateUtil.toDate(inn.getClientDt()));
		out.setIpAddr(inn.getIPAddr());
		out.setRqUID(Math.abs(inn.getRqUID()));
		out.setReferences(getIniciarTransaccionDeCompraRqTypeReferences(inn));
		out.setTransactionBO(convertRBM_rqTypeToTransactionBO(inn));
		
		return out;
	}


	/**
	 * Se encarga de transformar las referencias de entrada en las referencias para el DTO
	 * @param inn
	 * @return
	 */
	private static List<ReferenceType> getIniciarTransaccionDeCompraRqTypeReferences(IniciarTransaccionDeCompraRqType inn) {
		
		List<ReferenceType> references = new ArrayList<ReferenceType>();
		if (inn.getReference() != null) {
			for (co.com.ath.pgw.in.model.ReferenceType inReference : inn.getReference()) {
				ReferenceType ref = new ReferenceType();
				ref.setRefId(inReference.getRefId());
				ref.setRefType(inReference.getRefType());
				references.add(ref);
			}
			
			return references;
		} else {
			return null;
		}

	}


	private static TransactionBO convertRBM_rqTypeToTransactionBO(IniciarTransaccionDeCompraRqType inn) {

		TransactionBO out = new TransactionBO();
		
		out.setRqUID(inn.getRqUID());
		out.setTrnChannel(inn.getChannel());
		out.setSource(new TransactionSourceBO(inn.getChannel()));
		out.setIpAddress(inn.getIPAddr());
		
		if(inn.getInfoPersona() != null){
			
			out.setFirstNamePayer(inn.getInfoPersona().getNombres());
			out.setLastNamePayer(inn.getInfoPersona().getNombres());
			
			try {
				String name = inn.getInfoPersona().getNombres();
				
				StringTokenizer st = new StringTokenizer(name, " ");
				String firstName = st.nextToken();
				String lastName = ""; 
				
				while (st.hasMoreElements())
					lastName += st.nextToken() + " ";
				
				lastName = lastName.trim();
				firstName = firstName.trim();
				
				out.setFirstNamePayer(firstName);
				out.setLastNamePayer(lastName);

			} catch (Exception e) {
				LOGGER.error("Error al intentar extraer primer nombre del pagador.", e.getMessage());
			}

			out.setPayerMail(inn.getInfoPersona().getCorreo());
			out.setCustomerEmail(inn.getInfoPersona().getCorreo());
			out.setPayerPhone(inn.getInfoPersona().getNumeroTelefonoCelular());
			
			if(inn.getInfoPersona().getIdPersona() != null){
				out.setPayerDocType(inn.getInfoPersona().getIdPersona().getTipoDocumento());
				out.setPayerDocId(inn.getInfoPersona().getIdPersona().getNumDocumento().toString());
			}
			
		}
		

		if(inn.getInfoPersonaBeneficiario() != null){
	
			out.setCustomerName(inn.getInfoPersonaBeneficiario().getNombres());
			//out.setLastNameBuyer(inn.getInfoPersonaBeneficiario().getNombres());

			out.setCustomerEmail(inn.getInfoPersonaBeneficiario().getCorreo());
			out.setCustomerMobileNumber(inn.getInfoPersonaBeneficiario().getNumeroTelefonoCelular());
			
			if(inn.getInfoPersonaBeneficiario().getIdPersona() != null){
				out.setCustomerDocType(inn.getInfoPersonaBeneficiario().getIdPersona().getTipoDocumento());
				out.setCustomerDocId(inn.getInfoPersonaBeneficiario().getIdPersona().getNumDocumento().toString());
			}
			
		}

		
		if (inn.getPmtid() != null) out.setPmtId(inn.getPmtid());

		out.setReference1(PaymentsObjectsConverterUtil.getReference(inn.getReference(), 1));
		out.setReference2(PaymentsObjectsConverterUtil.getReference(inn.getReference(), 2));
		out.setReference3(PaymentsObjectsConverterUtil.getReference(inn.getReference(), 3));
		
		/*Referencias de Motor de Riesgo*/
		out.setDevicePrint(PaymentsObjectsConverterUtil.getReference(inn.getReference(), CoreConstants.RSA_DEVICE_PRINT));
		out.setDeviceTokenCookie(PaymentsObjectsConverterUtil.getReference(inn.getReference(), CoreConstants.RSA_DEVICE_TOKEN_COOKIE));
		out.setHttpAccept(PaymentsObjectsConverterUtil.getReference(inn.getReference(), CoreConstants.RSA_HTTPACCEPT));
		out.setHttpAcceptLanguage(PaymentsObjectsConverterUtil.getReference(inn.getReference(), CoreConstants.RSA_HTTPACCEPTLANGUAGE));
		out.setHttpReferrer(PaymentsObjectsConverterUtil.getReference(inn.getReference(), CoreConstants.RSA_HTTPREFERRER));
		out.setUserAgent(PaymentsObjectsConverterUtil.getReference(inn.getReference(), CoreConstants.RSA_USERAGENT));
		out.setTermsNConditions(PaymentsObjectsConverterUtil.getReference(inn.getReference(), CoreConstants.RSA_TERMSNCONDITIONS));
		return out;
	}


	public static IniciarTransaccionDeCompraRsType convertIniciarTransaccionOutDTOtoIniciarTransaccionDeCompraRsType(
			IniciarTransaccionOutDTO inn) {

		IniciarTransaccionDeCompraRsType out = new IniciarTransaccionDeCompraRsType();
		out.setIdTransaccion(inn.getApprovalId());
		
		CabeceraRespuestaType cabeceraRespuesta = new CabeceraRespuestaType();
		InfoPuntoInteraccionType infoPuntoInteraccion = new InfoPuntoInteraccionType();
		
		cabeceraRespuesta.setInfoPuntoInteraccion(infoPuntoInteraccion);
		out.setCabeceraRespuesta(cabeceraRespuesta );
		
		out.setCompensationDate(inn.getCompensationDate());
		
		out.setEffDt(inn.getEffDt());
		
		InfoRespuestaType infoRespuesta = new InfoRespuestaType();
		infoRespuesta.setCodRespuesta(inn.getTrnServerStatusCode());
		infoRespuesta.setDescRespuesta(inn.getTrnServerStatusDesc());
		infoRespuesta.setEstado(inn.getTrnStatusDesc());
		
		out.setInfoRespuesta(infoRespuesta);
		
		InfoTransaccionRespType infoTransaccion = new InfoTransaccionRespType();
		infoTransaccion.setIdTransaccionActual(inn.getApprovalId());
		infoTransaccion.setUrlRBM(inn.getUrlRBM());
		out.setInfoTransaccionResp(infoTransaccion );
		out.setPmtid(inn.getPmtId());
		
		List<co.com.ath.pgw.in.model.ReferenceType> references = new ArrayList<co.com.ath.pgw.in.model.ReferenceType>();
		
		//Motor de riesgo.
		if(inn.getToken() != null) {

			co.com.ath.pgw.in.model.ReferenceType reference = new co.com.ath.pgw.in.model.ReferenceType();
			reference.setRefId("token");
			reference.setRefType(inn.getToken());			
			references.add(reference);
			
			out.setReference(references );
		}	
		
		return out;
	}

	public static IniciarTransaccionDeCompraRsType convertIniciarTransaccionOutDTOtoIniciarTransaccionDeCompraRsTypeError(
			IniciarTransaccionDeCompraRqType transactionAddRq, Exception ex) {
		// TODO Auto-generated method stub
		return null;
	}

	public static ConsultarEstadoDePagoInDTO convertConsultarEstadoDePagoRqTypeToConsultarEstadoDePagoInDTO(
			ConsultarEstadoDePagoRqType consultarEstadoDePagoRq) {
		// TODO Auto-generated method stub
		return null;
	}

	public static ConsultarEstadoDePagoRsType convertConsultarEstadoDePagoOutDTOtoConsultarEstadoDePagoRsType(
			ConsultarEstadoDePagoOutDTO outDTO) {
		// TODO Auto-generated method stub
		return null;
	}

	public static ConsultarEstadoDePagoRsType convertConsultarEstadoDePagoOutDTOtoConsultarEstadoDePagoRsTypeError(
			ConsultarEstadoDePagoRqType consultarEstadoDePagoRq, Exception ex) {
		// TODO Auto-generated method stub
		return null;
	}

	public static IniciarTransaccionDeCompraSolicitudRequest convertCoreInitTransactionRbmInDtoToCoreInitTransactionRbmRqType(IniciarTransaccionInDTO inDTO, String tipoTerminal) {
		GregorianCalendar cal = new GregorianCalendar();
		cal.setTime(new Date());
		XMLGregorianCalendar xmlCal = null;
		try {
			xmlCal = DatatypeFactory.newInstance().newXMLGregorianCalendar(cal);
		} catch (DatatypeConfigurationException e) {
			LOGGER.error("No se pudo crear la instancia de XMLCalendar");
		}
		
		IniciarTransaccionDeCompraSolicitudRequest out = new IniciarTransaccionDeCompraSolicitudRequest();
		
		TipoCabeceraSolicitud cabeceraSolicitud = new TipoCabeceraSolicitud();
		TipoInfoPuntoInteraccion infoPuntoInteraccion = new TipoInfoPuntoInteraccion();
		infoPuntoInteraccion.setIdAdquiriente(inDTO.getTransactionBO().getCommerce().getIncocreditoCode());
		infoPuntoInteraccion.setIdTerminal(inDTO.getTransactionBO().getCommerce().getTerminalCode());
		infoPuntoInteraccion.setTipoTerminal(tipoTerminal);
		infoPuntoInteraccion.setIdTransaccionTerminal(Integer.parseInt(Util.cortaDerechaTexto(inDTO.getTransactionBO().getPmtId(), CoreConstants.PMTID_LIMIT)));
		
		/**
		 * Pendiente Identificador Transaccion terminal 
		 * 
		 */
		//infoPuntoInteraccion.setIdTransaccionTerminal(idTransaccionTerminal);
		/**
		 * Pendiente Identificador  Transaccion terminal 
		 * 
		 */
		cabeceraSolicitud.setInfoPuntoInteraccion(infoPuntoInteraccion );
		out.setCabeceraSolicitud(cabeceraSolicitud );
		
		TipoInfoPersona tipoInfoPersona = new TipoInfoPersona();
		TipoIdPersona tipoIdPersona = new TipoIdPersona();
		TipoTipoDocumento tipoTipoDocumento = TipoTipoDocumento.fromValue(inDTO.getTransactionBO().getPayerDocType());
		tipoIdPersona.setTipoDocumento(tipoTipoDocumento);
		tipoIdPersona.setNumDocumento(Long.parseLong(inDTO.getTransactionBO().getPayerDocId()));
		tipoInfoPersona.setIdPersona(tipoIdPersona);
		tipoInfoPersona.setNombres(null != inDTO.getTransactionBO().getFirstNamePayer() ? cortaIzqTexto(inDTO.getTransactionBO().getFirstNamePayer(),NAME_LIMIT) : null);
		tipoInfoPersona.setApellidos(null != inDTO.getTransactionBO().getLastNamePayer() ? cortaIzqTexto(inDTO.getTransactionBO().getLastNamePayer(),NAME_LIMIT) : null);
		tipoInfoPersona.setCorreo(inDTO.getTransactionBO().getPayerMail());
		tipoInfoPersona.setNumeroTelefonoCelular(Long.parseLong(inDTO.getTransactionBO().getPayerPhone()));
		tipoInfoPersona.setTelefono(Long.parseLong(inDTO.getTransactionBO().getPayerPhone()));
		out.setInfoPersona(tipoInfoPersona);
		
		TipoInfoCompra tipoInfoCompra = new TipoInfoCompra();
		/**
		 * INI
		 */
		tipoInfoCompra.setNumeroFactura(inDTO.getTransactionBO().getPmtId());
		
		tipoInfoCompra.setMontoTotal(inDTO.getTransactionBO().getTotalValue());

		if(inDTO.getTransactionBO().getTaxValue().intValue() != 0) {
			TipoInfoImpuestos tipoInfoImpuestos = new TipoInfoImpuestos();
			tipoInfoImpuestos.setMonto(inDTO.getTransactionBO().getTaxValue());
			TipoTipoImpuesto tipoTipoImpuesto = TipoTipoImpuesto.fromValue(TipoTipoImpuesto.IVA.value());
			tipoInfoImpuestos.setTipoImpuesto(tipoTipoImpuesto);
			tipoInfoCompra.getInfoImpuestos().add(tipoInfoImpuestos);
		}
		
		
		
		
		TipoInfoComercio tipoInfoComercio = new TipoInfoComercio();
		tipoInfoComercio.setInformacionComercio(inDTO.getTransactionBO().getCommerce().getNuraCode());
		tipoInfoComercio.setInformacionAdicional(inDTO.getTransactionBO().getCommerce().getSubscription().getCompanyName());

		tipoInfoCompra.setInfoComercio(tipoInfoComercio);
		out.setInfoCompra(tipoInfoCompra);
		
		return out;
	}

	/**
	 * Se encarga de armar el objeto de referencias para RBM
	 * 
	 * @param inDTO
	 * @return
	 */
	private static List<ReferenceType> getCoreInitTransactionRbmRqTypeReferences(IniciarTransaccionInDTO inDTO) {

		List<ReferenceType> out = new ArrayList<ReferenceType>();

		ReferenceType idTerminal = new ReferenceType();
		ReferenceType idAdquiriente = new ReferenceType();
		ReferenceType informacionComercio = new ReferenceType();
		ReferenceType informacionAdicional = new ReferenceType();
		ReferenceType orderId = new ReferenceType();
		ReferenceType idTransaccionTerminal = new ReferenceType();
		

		idTerminal.setRefId("idTerminal");
		idAdquiriente.setRefId("idAdquiriente");
		informacionComercio.setRefId("informacionComercio");
		informacionAdicional.setRefId("informacionAdicional");
		orderId.setRefId("numeroFactura");
		idTransaccionTerminal.setRefId("idTransaccionTerminal");

		idTerminal.setRefType(inDTO.getTransactionBO().getCommerce().getTerminalCode());
		idAdquiriente.setRefType(inDTO.getTransactionBO().getCommerce().getIncocreditoCode());
		informacionComercio.setRefType(inDTO.getTransactionBO().getDescription());
		informacionAdicional.setRefType(inDTO.getTransactionBO().getOrderNumber());
		orderId.setRefType(inDTO.getTransactionBO().getOrderNumber());
		idTransaccionTerminal.setRefType(cortaDerechaTexto(inDTO.getTransactionBO().getPmtId(),PMTID_LIMIT));

		out.add(idTerminal);
		out.add(idAdquiriente);
		out.add(informacionComercio);
		out.add(informacionAdicional);
		out.add(orderId);
		out.add(idTransaccionTerminal);

		return out;

	}
	
	/**
	 * Se encarga de cortar por Izquierda los caracteres de un texto.
	 *  
	 * @param texto
	 * @param limite
	 * @return
	 */
	private static String cortaIzqTexto(String texto, int limite) {
		
		if (texto.length() > limite)	
			texto = texto.substring(0, limite);
		
		return texto;
	}
	
	/**
	 * Se encarga de cortar por Derecha los caracteres de un texto.
	 *  
	 * @param texto
	 * @param limite
	 * @return
	 */
	private static String cortaDerechaTexto(String texto, int limite) {
		
		if (texto.length() > limite)	
			texto = texto.substring(texto.length()-limite, texto.length());
		
		return texto;
	}

	public static CoreInitTransactionRbmOutDTO CoreInitTransactionRbmRsTypeToCoreInitTransactionRbmOutDTO(IniciarTransaccionDeCompraRespuestaResponse inn) {
		CoreInitTransactionRbmOutDTO out = new CoreInitTransactionRbmOutDTO();
		
		out.setStatusCode(HttpStatus.OK.value());
		out.setStatusDesc(HttpStatus.OK.getReasonPhrase());
		
		if(inn.getInfoRespuesta() != null) {
			if(inn.getInfoRespuesta().getCodRespuesta() != null)
				out.setServerStatusCode(inn.getInfoRespuesta().getCodRespuesta());
			if(inn.getInfoRespuesta().getDescRespuesta() != null)
				out.setServerStatusDesc(inn.getInfoRespuesta().getDescRespuesta());
			if(inn.getInfoRespuesta().getEstado() != null)
				out.setEstado(inn.getInfoRespuesta().getEstado());
		}
		
		out.setIdTransaccion(inn.getInfoTransaccionResp() != null ? inn.getInfoTransaccionResp().getIdTransaccionActual() : null);
		out.setIdTerminal(inn.getCabeceraRespuesta() != null && inn.getCabeceraRespuesta().getInfoPuntoInteraccion() != null ? inn.getCabeceraRespuesta().getInfoPuntoInteraccion().getIdTerminal() : null);
		out.setIdAdquiriente(inn.getCabeceraRespuesta() != null && inn.getCabeceraRespuesta().getInfoPuntoInteraccion() != null ? inn.getCabeceraRespuesta().getInfoPuntoInteraccion().getIdAdquiriente() : null);
		out.setIdTransaccionTerminal(inn.getCabeceraRespuesta() != null && inn.getCabeceraRespuesta().getInfoPuntoInteraccion() != null ? String.valueOf(inn.getCabeceraRespuesta().getInfoPuntoInteraccion().getIdTransaccionTerminal()) : null);
		
		return out;
	}

	public static ConsultarEstadoDePagoSolicitudRequest convertCoreGetStateRBMPaymentInDTOToCoreGetStateRBMPaymentRqType(CoreGetStateRBMPaymentInDTO inDTO, String tipoTerminal) {
		GregorianCalendar cal = new GregorianCalendar();
		cal.setTime(new Date());
		XMLGregorianCalendar xmlCal = null;
		try {
			xmlCal = DatatypeFactory.newInstance().newXMLGregorianCalendar(cal);
		} catch (DatatypeConfigurationException e) {
			LOGGER.error("No se pudo crear la instancia de XMLCalendar");
		}
		
		ConsultarEstadoDePagoSolicitudRequest out = new ConsultarEstadoDePagoSolicitudRequest();
		out.setIdTransaccion(inDTO.getIdTxRbm());
		
		TipoCabeceraSolicitud tipoCabeceraSolicitud = new TipoCabeceraSolicitud();
		TipoInfoPuntoInteraccion tipoInfoPuntoInteraccion = new TipoInfoPuntoInteraccion();
		tipoInfoPuntoInteraccion.setTipoTerminal(tipoTerminal);
		tipoInfoPuntoInteraccion.setIdTerminal(inDTO.getTransactionBO().getCommerce().getTerminalCode());
		tipoInfoPuntoInteraccion.setIdAdquiriente(inDTO.getTransactionBO().getCommerce().getIncocreditoCode());
		tipoInfoPuntoInteraccion.setIdTransaccionTerminal(Integer.parseInt(cortaDerechaTexto(inDTO.getTransactionBO().getPmtId(),PMTID_LIMIT)));
		tipoCabeceraSolicitud.setInfoPuntoInteraccion(tipoInfoPuntoInteraccion);
		out.setCabeceraSolicitud(tipoCabeceraSolicitud);

		return out;
	}

	/**
	 * Se encarga de armar el objeto de referencias para RBM
	 * 
	 * @param inDTO
	 * @return
	 */
	private static List<ReferenceType> getCoreGetStateRBMPaymentRqTypeReferences(CoreGetStateRBMPaymentInDTO inDTO) {

		List<ReferenceType> out = new ArrayList<ReferenceType>();

		ReferenceType idTerminal = new ReferenceType();
		ReferenceType idAdquiriente = new ReferenceType();
		ReferenceType idTransaccion = new ReferenceType();
		ReferenceType idTransaccionTerminal = new ReferenceType();

		idTerminal.setRefId("idTerminal");
		idAdquiriente.setRefId("idAdquiriente");
		idTransaccion.setRefId("idTransaccion");
		idTransaccionTerminal.setRefId("idTransaccionTerminal");

		idTerminal.setRefType(inDTO.getTransactionBO().getCommerce().getTerminalCode());
		idAdquiriente.setRefType(inDTO.getTransactionBO().getCommerce().getIncocreditoCode());
		idTransaccion.setRefType(inDTO.getIdTxRbm());
		idTransaccionTerminal.setRefType( cortaDerechaTexto(inDTO.getTransactionBO().getPmtId(),PMTID_LIMIT));

		out.add(idTerminal);
		out.add(idAdquiriente);
		out.add(idTransaccion);
		out.add(idTransaccionTerminal);

		return out;

	}

	public static CoreGetStateRBMPaymentOutDTO CoreGetStateRBMPaymentRsTypeToCoreGetStateRBMPaymentOutDTO(ConsultarEstadoDePagoRespuestaResponse inn) {
		CoreGetStateRBMPaymentOutDTO out = new CoreGetStateRBMPaymentOutDTO();
		
		out.setStatusCode(HttpStatus.OK.value());
		out.setStatusDesc(HttpStatus.OK.getReasonPhrase());
		out.setServerStatusCode(inn.getInfoRespuesta().getCodRespuesta());
		
		
		if(inn.getEstadoActualTransaccion() == null) {
			inn.setEstadoActualTransaccion(TipoEstadoActualTransaccion.fromValue(inn.getInfoRespuesta().getEstado().trim()));
		}
		
		out.setEstadoTxConsultada(inn.getEstadoActualTransaccion().value());
		out.setTrnServerStatusDesc(inn.getEstadoActualTransaccion().value());
		
		if(inn.getInfoPago()!= null) {
			out.setNumeroAprobacion(inn.getInfoPago().getNumeroAprobacion());
			out.setIdTransaccionAutorizador(Objects.isNull(inn.getInfoPago().getIdTransaccionAutorizador()) ? inn.getInfoPago().getIdTransaccionAutorizador() : 0 );
			out.setFranquicia(inn.getInfoPago().getFranquicia() != null ? inn.getInfoPago().getFranquicia(): "");
			
			if(inn.getInfoPago().getFechaTransaccion()!= null) {
				out.setFechaTxRbm(inn.getInfoPago().getFechaTransaccion() != null ? DateUtil.toDate(inn.getInfoPago().getFechaTransaccion()) : null);
			}
			
			out.setMontoTotal(inn.getInfoPago().getMontoTotal());
			out.setCostoTx(String.valueOf(inn.getInfoPago().getCostoTransaccion()));
			out.setTipoCuenta(inn.getInfoPago().getTipoCuenta());
		}
		
		
		out.setIdTerminal(inn.getCabeceraRespuesta() != null && inn.getCabeceraRespuesta().getInfoPuntoInteraccion() != null ? inn.getCabeceraRespuesta().getInfoPuntoInteraccion().getIdTerminal() : null);
		out.setIdAdquiriente(inn.getCabeceraRespuesta() != null && inn.getCabeceraRespuesta().getInfoPuntoInteraccion() != null ? inn.getCabeceraRespuesta().getInfoPuntoInteraccion().getIdAdquiriente() : null);
		out.setIdTransaccionTerminal(inn.getCabeceraRespuesta() != null && inn.getCabeceraRespuesta().getInfoPuntoInteraccion() != null ? String.valueOf(inn.getCabeceraRespuesta().getInfoPuntoInteraccion().getIdTransaccionTerminal()) : null);
		
		return out;
	}

}
