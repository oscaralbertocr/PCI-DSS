/*
 * TokenQueryType
 *  
 * GSI - Integración
 * Creado el: 24/07/2015
 *
 * Copyright (c) A Toda Hora S.A. Todos los derechos reservados
 * 
 * Este software es confidencial y es propietario de ATH, queda prohibido
 * su uso, reproducción y copia de manera parcial o permanente salvo autorización
 * expresa de A Toda Hora S.A o de quién represente sus derechos.
 */
package co.com.ath.pgw.util.enums;

/**
 * Enum con los posibles valores de Query type.
 *
 * @author <proveedor_njmoreno@ath.com.co> 
 * @version 1.0 24/07/2015
 * @since 1.0
 */

public enum ResponseCodeEnum {

	NOT_AUTHORIZED_FRAUD_IP,
	NOT_AUTHORIZED_FRAUD_DOC;	
}