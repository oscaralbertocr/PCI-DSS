package co.com.ath.pgw.util.qr;

public class EstadoTransaccion {
	public Long idTx;
	public Long pmtId;
	public Long idEstado;
	public String descripcion;

	public EstadoTransaccion() {

	}

	public Long getIdTx() {
		return idTx;
	}

	public void setIdTx(Long idTx) {
		this.idTx = idTx;
	}

	public Long getIdEstado() {
		return idEstado;
	}

	public void setIdEstado(Long idEstado) {
		this.idEstado = idEstado;
	}

	public String getDescripcion() {
		return descripcion;
	}

	public void setDescripcion(String descripcion) {
		this.descripcion = descripcion;
	}

	public Long getPmtId() {
		return pmtId;
	}

	public void setPmtId(Long pmtId) {
		this.pmtId = pmtId;
	}

	@Override
	public String toString() {
		return "EstadoTransaccion [idTx=" + idTx + ", idEstado=" + idEstado + ", pmtId=" + pmtId + ", descripcion="
				+ descripcion + "]";
	}

}
