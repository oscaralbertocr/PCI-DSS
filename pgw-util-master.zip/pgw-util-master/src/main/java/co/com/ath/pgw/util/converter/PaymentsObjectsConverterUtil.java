/*
 * ConverterUtil
 *  
 * GSI - Integración
 * Creado el: 23/09/2014
 *
 * Copyright (c) A Toda Hora S.A. Todos los derechos reservados
 * 
 * Este software es confidencial y es propietario de ATH, queda prohibido
 * su uso, reproducción y copia de manera parcial o permanente salvo autorización
 * expresa de A Toda Hora S.A o de quién represente sus derechos.
 */
package co.com.ath.pgw.util.converter;


import java.util.Date;
import java.util.List;

import java.util.Calendar;

import javax.xml.datatype.XMLGregorianCalendar;

import co.com.ath.pgw.in.model.InvoiceReferenceType;
import co.com.ath.pgw.in.model.PersonalDataType;
import co.com.ath.pgw.in.model.ReferenceType;
import co.com.ath.pgw.in.model.SecretListType;


/**
 * Clase de utilidad para las conversiones de PaymentsInbConverter
 * 
 * @version 0.0.0 23/09/2014
 * @author Andrés Méndez Juanias <proveedor_mamendez@ath.com.co>
 */
public class PaymentsObjectsConverterUtil {

	/**
     * Obtiene la referencia según el indice indicado.
     * @param reference Lista de objetos que contiene la referencia.
     * @param refIdx Indice de la referencia que se desea obtener inicia en 1 la primer referencia.
     * @return Descripción de la referencia solicitada o cadena vacia "" en caso de no existir el indice.
     */
    public static String getReference(List<ReferenceType> reference, int refIdx) {
		if (reference != null) {
			int idx = 0;
			for (ReferenceType ref : reference) {
				if (++idx == refIdx) {
					return ref.getRefType();
				}
			}
		}
		return "";
	}
    
    /**
     * Obtiene la referencia según la referencia indicada.
     * @param reference Lista de objetos que contiene la referencia.
     * @param referenceName Nombre de la referencia que se desea obtener
     * @return
     */
    public static String getReference(List<ReferenceType> reference, String referenceName) {
		
    	for (ReferenceType referenceType : reference )			
			if( referenceType.getRefId() != null && referenceType.getRefId().equals( referenceName ) )
				return referenceType.getRefType();
    	
    	return "";
	}
    
    /**
     * Obtiene la referencia según el indice indicado.
     * @param reference Lista de objetos que contiene la referencia.
     * @param refIdx Indice de la referencia que se desea obtener inicia en 1 la primer referencia.
     * @return Descripción de la referencia solicitada o cadena vacia "" en caso de no existir el indice.
     */
    public static String getInvoiceReference(List<InvoiceReferenceType> invoiceReference, int invRefIdx) {
		if (invoiceReference != null) {
			int idx = 0;
			for (InvoiceReferenceType invRef : invoiceReference) {
				if (++idx == invRefIdx) {
					return invRef.getPmtCodNIE();
				}
			}
		}
		return "";
	}
    
    /**
     * Obtiene el nombre concatenado del cliente.
     * @param personalDataType Objeto con la información personal del cliente.
     * @return String con el nombre concatenado.
     */
    public static String getCustomerName(PersonalDataType personalDataType) {
    	if(personalDataType == null || personalDataType.getCustName() == null){
    		return null;
    	}
        StringBuilder customerName = new StringBuilder();
        if(personalDataType.getCustName().getFirstName() != null){
        	customerName.append(personalDataType.getCustName().getFirstName());
        }
        if(personalDataType.getCustName().getMiddleName() != null){
	        customerName.append(" ");
	        customerName.append(personalDataType.getCustName().getMiddleName());
        }
        if(personalDataType.getCustName().getLastName() != null){
	        customerName.append(" ");
	        customerName.append(personalDataType.getCustName().getLastName());
        }
        if(personalDataType.getCustName().getSecondLastName() != null){
	        customerName.append(" ");
	        customerName.append(personalDataType.getCustName().getSecondLastName());
        }
        return customerName.toString();
    }
    
    /**
     * Obtiene el argumento asociado a la clave enviada por parametro.
     * @param key Clave del argumento buscado.
     * @param secretList Lista con los registyros a recuperar.
     * @return Descripcion asociada a la clave enviada o null si no se ecnuentra.
     */
    public static String getSecretArgument(String key, List<SecretListType> secretList){
    	final boolean hasArguments = key != null && secretList != null &&
    			!key.trim().isEmpty() && !secretList.isEmpty();
		if (hasArguments) {
			for(SecretListType sa: secretList){
				if(key.equals(sa.getSecretId())){
					return sa.getSecret();					
				}
			}
		}
		return null;
    }
    
    /**
     * Obtiene la fecha de vencimiento en formato DDYYYY
     * @param expDt Fecha de vencimiento de la tarjeta.
     * @return String con la fecha en formato DDYYYY.
     */
    public static String getDueDate(XMLGregorianCalendar expDt){
        if(expDt == null){
            return null;                    
        }
        Calendar dueDate = Calendar.getInstance();
        dueDate.setTime(DateUtil.toDate(expDt));
        StringBuilder dd = new StringBuilder();
        dd.append(dueDate.get(Calendar.DAY_OF_MONTH));
        dd.append(dueDate.get(Calendar.YEAR));
        return dd.toString();
    }
    
    /**
     * Realiza la conversion a Long del string enviado, si no es posible 
     * convertir retorna null.
     * @param num String del numero que se desea convertir.
     * @return 
     */
    public static Long getLongValue(String num){
        Long out;
        try{
            out = Long.valueOf(num);
        } catch(NumberFormatException ex){
            out = null;
        }
        return out;
    }
    
    /**
     * Obtiene la fecha de nacimiento tipo Date
     * @param birthDate Fecha de nacimiento.
     * @return Date con la fecha de birthDate.
     */
    public static Date getBirthDate(XMLGregorianCalendar birthDate){
      if(birthDate == null){
	      return null;                    
	  }
        return birthDate.toGregorianCalendar().getTime();
    }
    
}
