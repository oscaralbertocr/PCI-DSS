/*
 * NotNullValidator
 *
 * GSI - Integración
 * Creado el: 5 de septiembre de 2014
 *
 * Copyright (c) A Toda Hora S.A. Todos los derechos reservados
 *
 * Este software es confidencial y es propietario de ATH, queda prohibido
 * su uso, reproducción y copia de manera parcial o permanente salvo autorización
 * expresa de A Toda Hora S.A o de quién represente sus derechos.
 */
package co.com.ath.pgw.util.validation;

import java.util.Locale;

import co.com.ath.pgw.util.i18n.BundleKeys;
import co.com.ath.pgw.util.i18n.BundleType;

/**
 * Verifica que el valor del objeto no sea nulo.
 * 
 * @author proveedor_zagarcia
 * @version 1.0 05 Sep 2014
 * @created 04-sep-2014 02:51:52 p.m.
 */
public class NotNullValidator extends ObjectValidator {
	
	/**
	 * Construye un validador sin especificar el validador interno.
	 */
	public NotNullValidator(){
		super();
	}
	
	/**
	 * Construye un validador especificando su validador interno.
	 * 
	 * @param internalValidator	Validador interno
	 */
	public NotNullValidator(ObjectValidator internalValidator) {
		super(internalValidator);
	}
	

	@Override
	protected void doValidate(Object object, Locale locale) throws ObjectValidationException {
		if (object == null) {
			throw new ObjectValidationException(getMessage(locale));
		}
		//"validator.attribute.null"
	}

	/**
	 * Retorna el mensaje de error en la validación en el idioma solicitado. Si
	 * el gestor de Bundle es nulo retorna el valor de la llave en el Bundle de
	 * error.
	 * 
	 * @param locale Información de idioma y localización
	 * @return Mensaje de error en la validación.
	 */
	private String getMessage(Locale locale) {
		if (bundleManager == null) {
			return BundleKeys.ERROR_NULL_VALUE;
		}
		bundleManager.setBundle(BundleType.ERRORS);
		return bundleManager.getMessage(
				BundleKeys.ERROR_NULL_VALUE, null, locale);
	}

}
