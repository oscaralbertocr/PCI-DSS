/**
 * 
 */
package co.com.ath.pgw.util.validation.model.dto;

import java.util.Locale;

/**
 * @author proveedor_japiza
 *
 */
public class TransactionIdNuraCodeInDTO {
	
	private String pmtIdTransaction;
	
	private String nuraCode;
	
	private Locale locale;
	
	/**
	 * @return the pmtIdTransaction
	 */
	public String getPmtIdTransaction() {
		return pmtIdTransaction;
	}
	
	/**
	 * @param pmtIdTransaction the pmtIdTransaction to set
	 */
	public void setPmtIdTransaction(String pmtIdTransaction) {
		this.pmtIdTransaction = pmtIdTransaction;
	}
	
	/**
	 * @return the nuraCode
	 */
	public String getNuraCode() {
		return nuraCode;
	}
	
	/**
	 * @param nuraCode the nuraCode to set
	 */
	public void setNuraCode(String nuraCode) {
		this.nuraCode = nuraCode;
	}
	
	/**
	 * @return the locale
	 */
	public Locale getLocale() {
		return locale;
	}
	
	/**
	 * @param locale the locale to set
	 */
	public void setLocale(Locale locale) {
		this.locale = locale;
	}
}
