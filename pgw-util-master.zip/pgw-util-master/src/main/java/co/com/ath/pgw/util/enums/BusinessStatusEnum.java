/*
 * BusinessStatusEnum
 *  
 * GSI - Integracion
 * Creado el: 31/10/2014
 *
 * Copyright (c) A Toda Hora S.A. Todos los derechos reservados
 * 
 * Este software es confidencial y es propietario de ATH, queda prohibido
 * su uso, reproduccion y copia de manera parcial o permanente salvo autorizacion
 * expresa de A Toda Hora S.A o de quien represente sus derechos.
 */

package co.com.ath.pgw.util.enums;

/**
 * Class description goes here...
 *
 * @author Jorge Andres Piza 
 * @version 1.0 31/10/2014
 * @since 1.0
 * 
 * 
 *  @RQ27199
 *  <strong>Autor</strong>Camilo Bustamante</br>
 *  <strong>Descripcion</strong>Ajuste de Estado, Manejo de Topes</br>
 *  <strong>Numero de Cambios</strong>1</br>
 *  <strong>Identificador corto</strong>C01</br>
 */

public enum BusinessStatusEnum {
	
	PENDIENTE (1L, "transaction.businessStatus.pending"),
	RECHAZADA (2L, "transaction.businessStatus.declined"),
	FALLIDA   (3L, "transaction.businessStatus.failed"),
	APROBADA  (4L, "transaction.businessStatus.approved"),
	EXPIRADA  (5L, "transaction.businessStatus.expired"),
	/** INI C01 **/
	NO_AUTORIZADA  (6L, "transaction.businessStatus.NotAuthorized");
	/** FIN C01 **/
		
	/** ID Unico del estado de negocio para la transaccion */
	private Long code;
	
	/** Codigo del mensaje para el estado del negocio de la transaccion */
	private String messageCode;
	
	BusinessStatusEnum(Long code, String messageCode){
		this.code = code;
		this.messageCode = messageCode;
	}

	/**
	 * Metodo encargado de recuperar el valor del atributo code.
	 * @return El atributo code asociado a la clase.
	 */
	public Long getCode() {
		return code;
	}

	/**
	 * Metodo encargado de actualizar el atributo code.
	 * @param code Nuevo valor para code.
	 */
	public void setCode(Long code) {
		this.code = code;
	}

	/**
	 * Metodo encargado de recuperar el valor del atributo messageCode.
	 * @return El atributo messageCode asociado a la clase.
	 */
	public String getMessageCode() {
		return messageCode;
	}

	/**
	 * Metodo encargado de actualizar el atributo messageCode.
	 * @param messageCode Nuevo valor para messageCode.
	 */
	public void setMessageCode(String messageCode) {
		this.messageCode = messageCode;
	}

}
