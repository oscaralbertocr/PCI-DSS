/**
 * 
 */
package co.com.ath.pgw.util.qr;

import java.io.Serializable;

/**
 * @author javier.capera
 *
 */
public class SolicitudQR implements Serializable {
	private String codigoUnico;
	private String canal;
	private String terminalId;
	private String idTransaccion;
	private String valorCompra;
	private String tipoOperacion;
	private String condicionIva;
	private int iva;
	private int baseIva;
	private String condicionInc;
	private int inc;
	private String condicionPropina;
	private int propina;
	private String tipoQR;

	public SolicitudQR() {
		super();
	}

	public String getCodigoUnico() {
		return codigoUnico;
	}

	public void setCodigoUnico(String codigoUnico) {
		this.codigoUnico = codigoUnico;
	}

	public String getCanal() {
		return canal;
	}

	public void setCanal(String canal) {
		this.canal = canal;
	}

	public String getTerminalId() {
		return terminalId;
	}

	public void setTerminalId(String terminalId) {
		this.terminalId = terminalId;
	}

	public String getIdTransaccion() {
		return idTransaccion;
	}

	public void setIdTransaccion(String idTransaccion) {
		this.idTransaccion = idTransaccion;
	}

	public String getValorCompra() {
		return valorCompra;
	}

	public void setValorCompra(String valorCompra) {
		this.valorCompra = valorCompra;
	}

	public String getTipoOperacion() {
		return tipoOperacion;
	}

	public void setTipoOperacion(String tipoOperacion) {
		this.tipoOperacion = tipoOperacion;
	}

	public String getCondicionIva() {
		return condicionIva;
	}

	public void setCondicionIva(String condicionIva) {
		this.condicionIva = condicionIva;
	}

	public int getIva() {
		return iva;
	}

	public void setIva(int iva) {
		this.iva = iva;
	}

	public int getBaseIva() {
		return baseIva;
	}

	public void setBaseIva(int baseIva) {
		this.baseIva = baseIva;
	}

	public String getCondicionInc() {
		return condicionInc;
	}

	public void setCondicionInc(String condicionInc) {
		this.condicionInc = condicionInc;
	}

	public int getInc() {
		return inc;
	}

	public void setInc(int inc) {
		this.inc = inc;
	}

	public String getCondicionPropina() {
		return condicionPropina;
	}

	public void setCondicionPropina(String condicionPropina) {
		this.condicionPropina = condicionPropina;
	}

	public int getPropina() {
		return propina;
	}

	public void setPropina(int propina) {
		this.propina = propina;
	}

	public String getTipoQR() {
		return tipoQR;
	}

	public void setTipoQR(String tipoQR) {
		this.tipoQR = tipoQR;
	}

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	@Override
	public String toString() {
		return "{\r\n" + 
				" \"codigoUnico\" : \"" + codigoUnico + "\",\r\n" +
				" \"canal\" : \"" + canal + "\",\r\n" +
				" \"terminalId\" : \"" + terminalId + "\",\r\n" +
				" \"idTransaccion\" : \"" + idTransaccion + "\",\r\n" +
				" \"valorCompra\" : \"" + valorCompra + "\",\r\n" +
				" \"tipoOperacion\" : \"" + tipoOperacion + "\",\r\n" +
				" \"condicionIva\" : \"" + condicionIva + "\",\r\n" +
				" \"iva\" : " + iva + ",\r\n" +
				" \"baseIva\" : " + baseIva + ",\r\n" +
				" \"condicionInc\" : \"" + condicionInc + "\",\r\n" +
				" \"inc\" : " + inc + ",\r\n" +
				" \"condicionPropina\" : \"" + condicionPropina + "\",\r\n" +
				" \"propina\" : " + propina + ",\r\n" +
				" \"tipoQR\" : \"" + tipoQR + "\"\r\n" +
				"}";
	}
		
}
