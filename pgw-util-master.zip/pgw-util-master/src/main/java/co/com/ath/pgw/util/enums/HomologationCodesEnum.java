package co.com.ath.pgw.util.enums;
/**
 * Enum de homologación de Codigos de Respuesta RBM a Core de la Pasarela 
 * 
 * @author efren.lopez
 *
 *@PCI-DSS
 *	<strong>Autor</strong>Efren Lopez </br>
 * <strong>Descripcion</strong>Códigos de error RBM</br>
 * <strong>Numero de Cambios</strong>1</br>
 * <strong>Identificador corto</strong>C01</br>
 */
public enum HomologationCodesEnum {
	
	_00 ("Transacción exitosa","0","00"),
	_01 ("Transacción rechazada.","1260","01"),
	_02 ("Transacción rechazada.","1260" ,"02"),
	_03 ("Transacción rechazada.","1260" ,"03"),
	_05 ("Transacción rechazada.","1260" ,"05"),
	_06 ("Transacción rechazada.","1260" ,"06"),
	_07 ("La Tarjeta esta restringida. Comuniquese con su entidad","6020" ,"07"),
	_08 ("Transacción Exitosa","0","08"),
	_09 ("No es posible procesar la transacción - Problemas técnicos. Por favor intente más tarde." ,"300","09"),
	_10 ("Transacción Exitosa","0","10"),
	_11 ("Transacción Exitosa","0","11"),
	_12 ("No es posible procesar la transacción - Problemas técnicos. Por favor intente más tarde." ,"300","12"),
	_13 ("Transacción rechazada.","1260" ,"13"),
	_14 ("Transacción rechazada.","1260" ,"14"),
	_15 ("No es posible procesar la transacción - Problemas técnicos. Por favor intente más tarde." ,"300"	,"15"),
	_16 ("No es posible procesar la transacción - Problemas técnicos. Por favor intente más tarde." ,"300"	,"16"),
	_19 ("No es posible procesar la transacción - Problemas técnicos. Por favor intente más tarde." ,"300"	,"19"),
	_25 ("No es posible procesar la transacción - Problemas técnicos. Por favor intente más tarde." ,"300"	,"25"),
	_30 ("No es posible procesar la transacción - Problemas técnicos. Por favor intente más tarde." ,"300"	,"30"),
	_31 ("Transacción rechazada.","1260" ,"31"),
	_41 ("Transacción rechazada.","1260" ,"41"),
	_43 ("Transacción rechazada.","1260" ,"43"),
	_45 ("Transacción rechazada.","1260" ,"45"),
	_48 ("Transacción rechazada.","1260" ,"48"),
	_49 ("No es posible procesar la transacción - Problemas técnicos. Por favor intente más tarde." ,"300"	,"49"),
	_50 ("No es posible procesar la transacción - Problemas técnicos. Por favor intente más tarde." ,"300"	,"50"),
	_51 ("Transacción rechazada.","1260" ,"51"),
	_54 ("Transacción rechazada.","1260" ,"54"),
	_55 ("Transacción rechazada.","1260" ,"55"),
	_56 ("Tarjeta Invalida.","1260" ,"56"),
	_57 ("Transacción rechazada.","1260" ,"57"),
	_58 ("No es posible procesar la transacción - Problemas técnicos. Por favor intente más tarde." ,"300"	,"58"),
	_61 ("No es posible procesar la transacción - Problemas técnicos. Por favor intente más tarde." ,"300"	,"61"),
	_62 ("Transacción rechazada.","1260" ,"62"),
	_65 ("Transacción rechazada.","1260" ,"65"),
	_66 ("Transacción rechazada.","1260" ,"66"),
	_67 ("Transacción rechazada.","1260" ,"67"),
	_68 ("Transacción rechazada.","1260" ,"68"),
	_69 ("Transacción rechazada.","1260" ,"69"),
	_71 ("Transacción rechazada.","1260" ,"71"),
	_72 ("Transacción rechazada.","1260" ,"72"),
	_73 ("Transacción rechazada.","1260" ,"73"),
	_74 ("Transacción rechazada.","1260" ,"74"),
	_75 ("Transacción rechazada.","1260" ,"75"),
	_76 ("No es posible procesar la transacción - Problemas técnicos. Por favor intente más tarde." ,"300"	,"76"),
	_77 ("No es posible procesar la transacción - Problemas técnicos. Por favor intente más tarde." ,"300"	,"77"),
	_78 ("No es posible procesar la transacción - Problemas técnicos. Por favor intente más tarde." ,"300"	,"78"),
	_79 ("No es posible procesar la transacción - Problemas técnicos. Por favor intente más tarde." ,"300"	,"79"),
	_80 ("Transacción rechazada","1260" ,"80"),
	_81 ("Transacción rechazada","1260" ,"81"),
	_82 ("Transacción","1260" ,"82"),
	_83 ("Transacción rechazada","1260" ,"83"),
	_84 ("Transacción rechazada","1260" ,"84"),
	_85 ("Transacción rechazada","1260" ,"85"),
	_86 ("Transacción rechazada","1260" ,"86"),
	_87 ("Transacción rechazada","1260" ,"87"),
	_88 ("No es posible procesar la transacción - Problemas técnicos. Por favor intente más tarde." ,"300"	,"88"),
	_89 ("No es posible procesar la transacción - Problemas técnicos. Por favor intente más tarde." ,"300"	,"89"),
	_90 ("No es posible procesar la transacción - Problemas técnicos. Por favor intente más tarde." ,"300"	,"90"),
	_91 ("No es posible procesar la transacción - Problemas técnicos. Por favor intente más tarde." ,"300"	,"91"),
	_92 ("Transacción rechazada","1260" ,"92"),
	_93 ("No es posible procesar la transacción - Problemas técnicos. Por favor intente más tarde." ,"300"	,"93"),
	_94 ("Transacción rechazada","1260" ,"94"),
	_95 ("No es posible procesar la transacción - Problemas técnicos. Por favor intente más tarde." ,"300"	,"95"),
	_96 ("No es posible procesar la transacción - Problemas técnicos. Por favor intente más tarde." ,"300"	,"96"),
	_97 ("No es posible procesar la transacción - Problemas técnicos. Por favor intente más tarde." ,"300"	,"97"),
	_98 ("No es posible procesar la transacción - Problemas técnicos. Por favor intente más tarde." ,"300"	,"98"),
	_B1 ("Transacción rechazada","1260" ,"B1"),
	_B2 ("No es posible procesar la transacción - Problemas técnicos. Por favor intente más tarde." ,"300"	,"B2"),
	_B3 ("Transacción rechazada","1260" ,"B3"),
	_B4 ("No es posible procesar la transacción - Problemas técnicos. Por favor intente más tarde." ,"300"	,"B4"),
	_B5 ("No es posible procesar la transacción - Problemas técnicos. Por favor intente más tarde." ,"300"	,"B5"),
	_B7 ("Transacción rechazada","1260" ,"B6"),
	_B6 ("Transacción rechazada","1260" ,"B7"),
	_B8 ("No es posible procesar la transacción - Problemas técnicos. Por favor intente más tarde." ,"300"	,"B8"),
	_SD ("No es posible procesar la transacción - Problemas técnicos. Por favor intente más tarde." ,"300"	,"SD"),
	_M2 ("No es posible procesar la transacción - Problemas técnicos. Por favor intente más tarde." ,"300"	,"M2"),
	_N0 ("No es posible procesar la transacción - Problemas técnicos. Por favor intente más tarde." ,"300"	,"N0"),
	_N1 ("No es posible procesar la transacción - Problemas técnicos. Por favor intente más tarde." ,"300"	,"N1"),
	_N2 ("No es posible procesar la transacción - Problemas técnicos. Por favor intente más tarde." ,"300"	,"N2"),
	_N3 ("No es posible procesar la transacción - Problemas técnicos. Por favor intente más tarde." ,"300"	,"N3"),
	_N4 ("No es posible procesar la transacción - Problemas técnicos. Por favor intente más tarde." ,"300"	,"N4"),
	_N5 ("No es posible procesar la transacción - Problemas técnicos. Por favor intente más tarde." ,"300"	,"N5"),
	_N6 ("No es posible procesar la transacción - Problemas técnicos. Por favor intente más tarde." ,"300"	,"N6"),
	_N7 ("No es posible procesar la transacción - Problemas técnicos. Por favor intente más tarde." ,"300"	,"N7"),
	_N8 ("No es posible procesar la transacción - Problemas técnicos. Por favor intente más tarde." ,"300"	,"N8"),
	_N9 ("No es posible procesar la transacción - Problemas técnicos. Por favor intente más tarde." ,"300"	,"N9"),
	_P0 ("No es posible procesar la transacción - Problemas técnicos. Por favor intente más tarde." ,"300"	,"P0"),
	_P1 ("No es posible procesar la transacción - Problemas técnicos. Por favor intente más tarde." ,"300"	,"P1"),
	_P2 ("No es posible procesar la transacción - Problemas técnicos. Por favor intente más tarde." ,"300"	,"P2"),
	_P3 ("No es posible procesar la transacción - Problemas técnicos. Por favor intente más tarde." ,"300"	,"P3"),
	_P4 ("No es posible procesar la transacción - Problemas técnicos. Por favor intente más tarde." ,"300"	,"P4"),
	_P5 ("No es posible procesar la transacción - Problemas técnicos. Por favor intente más tarde." ,"300"	,"P5"),
	_P6 ("No es posible procesar la transacción - Problemas técnicos. Por favor intente más tarde." ,"300"	,"P6"),
	_P7 ("No es posible procesar la transacción - Problemas técnicos. Por favor intente más tarde." ,"300"	,"P7"),
	_P8 ("No es posible procesar la transacción - Problemas técnicos. Por favor intente más tarde." ,"300"	,"P8"),
	_P9 ("No es posible procesar la transacción - Problemas técnicos. Por favor intente más tarde." ,"300"	,"P9"),
	_Q0 ("No es posible procesar la transacción - Problemas técnicos. Por favor intente más tarde." ,"300"	,"Q0"),
	_Q1 ("No es posible procesar la transacción - Problemas técnicos. Por favor intente más tarde." ,"300"	,"Q1"),
	_Q2 ("No es posible procesar la transacción - Problemas técnicos. Por favor intente más tarde." ,"300"	,"Q2"),
	_Q3 ("Transacción rechazada","1260" ,"Q3"),
	_Q4 ("No es posible procesar la transacción - Problemas técnicos. Por favor intente más tarde." ,"300"	,"Q4"),
	_Q5 ("No es posible procesar la transacción - Problemas técnicos. Por favor intente más tarde." ,"300"	,"Q5"),
	_Q6 ("No es posible procesar la transacción - Problemas técnicos. Por favor intente más tarde." ,"300"	,"Q6"),
	_Q7 ("No es posible procesar la transacción - Problemas técnicos. Por favor intente más tarde." ,"300"	,"Q7"),
	_Q8 ("No es posible procesar la transacción - Problemas técnicos. Por favor intente más tarde." ,"300"	,"Q8"),
	_Q9 ("No es posible procesar la transacción - Problemas técnicos. Por favor intente más tarde." ,"300"	,"Q9"),
	_R0 ("No es posible procesar la transacción - Problemas técnicos. Por favor intente más tarde." ,"300"	,"R0"),
	_R1 ("No es posible procesar la transacción - Problemas técnicos. Por favor intente más tarde." ,"300"	,"R1"),
	_R2 ("No es posible procesar la transacción - Problemas técnicos. Por favor intente más tarde." ,"300"	,"R2"),
	_R3 ("No es posible procesar la transacción - Problemas técnicos. Por favor intente más tarde." ,"300"	,"R3"),
	_R4 ("No es posible procesar la transacción - Problemas técnicos. Por favor intente más tarde." ,"300"	,"R4"),
	_R5 ("No es posible procesar la transacción - Problemas técnicos. Por favor intente más tarde." ,"300"	,"R5"),
	_R6 ("No es posible procesar la transacción - Problemas técnicos. Por favor intente más tarde." ,"300"	,"R6"),
	_R7 ("No es posible procesar la transacción - Problemas técnicos. Por favor intente más tarde." ,"300"	,"R7"),
	_R8 ("No es posible procesar la transacción - Problemas técnicos. Por favor intente más tarde." ,"300"	,"R8"),
	_S4 ("No es posible procesar la transacción - Problemas técnicos. Por favor intente más tarde." ,"300"	,"S4"),
	_S5 ("No es posible procesar la transacción - Problemas técnicos. Por favor intente más tarde." ,"300"	,"S5"),
	_S6 ("No es posible procesar la transacción - Problemas técnicos. Por favor intente más tarde." ,"300"	,"S6"),
	_S7 ("No es posible procesar la transacción - Problemas técnicos. Por favor intente más tarde." ,"300"	,"S7"),
	_S8 ("No es posible procesar la transacción - Problemas técnicos. Por favor intente más tarde." ,"300"	,"S8"),
	_S9 ("No es posible procesar la transacción - Problemas técnicos. Por favor intente más tarde." ,"300"	,"S9"),
	_T1 ("No es posible procesar la transacción - Problemas técnicos. Por favor intente más tarde." ,"300"	,"T1"),
	_T2 ("No es posible procesar la transacción - Problemas técnicos. Por favor intente más tarde." ,"1260" ,"T2"),
	_T3 ("No es posible procesar la transacción - Problemas técnicos. Por favor intente más tarde." ,"300"	,"T3"),
	_T4 ("No es posible procesar la transacción - Problemas técnicos. Por favor intente más tarde." ,"300"	,"T4"),
	_T5 ("No es posible procesar la transacción - Problemas técnicos. Por favor intente más tarde." ,"300"	,"T5"),
	_T6 ("No es posible procesar la transacción - Problemas técnicos. Por favor intente más tarde." ,"300"	,"T6"),  
	_T7 ("No es posible procesar la transacción - Problemas técnicos. Por favor intente más tarde." ,"300"	,"T7"),
	/**
	 * INI-C01
	 */
	_04 ("No es posible procesar la transacción - Problemas técnicos. Por favor intente más tarde." ,"300","04"),
	_33 ("No es posible procesar la transacción - Problemas técnicos. Por favor intente más tarde." ,"300","33"),
	_34 ("No es posible procesar la transacción - Problemas técnicos. Por favor intente más tarde." ,"300","34"),
	_35 ("No es posible procesar la transacción - Problemas técnicos. Por favor intente más tarde." ,"300","35"),
	_36 ("No es posible procesar la transacción - Problemas técnicos. Por favor intente más tarde." ,"300","36"),
	_37 ("No es posible procesar la transacción - Problemas técnicos. Por favor intente más tarde." ,"300","37"),
	_38 ("No es posible procesar la transacción - Problemas técnicos. Por favor intente más tarde." ,"300","38"),
	_39 ("No es posible procesar la transacción - Problemas técnicos. Por favor intente más tarde." ,"300","39"),
	_53 ("No es posible procesar la transacción - Problemas técnicos. Por favor intente más tarde." ,"300","53"),
	_O1 ("No es posible procesar la transacción - Problemas técnicos. Por favor intente más tarde." ,"300","O1"),
	_O2 ("No es posible procesar la transacción - Problemas técnicos. Por favor intente más tarde." ,"300","O2"),
	_O3 ("No es posible procesar la transacción - Problemas técnicos. Por favor intente más tarde." ,"300","O3"),
	_O4 ("No es posible procesar la transacción - Problemas técnicos. Por favor intente más tarde." ,"300","O4"),
	_O5 ("No es posible procesar la transacción - Problemas técnicos. Por favor intente más tarde." ,"300","O5"),
	_O6 ("No es posible procesar la transacción - Problemas técnicos. Por favor intente más tarde." ,"300","O6"),
	_O7 ("No es posible procesar la transacción - Problemas técnicos. Por favor intente más tarde." ,"300","O7"),
	_O8 ("No es posible procesar la transacción - Problemas técnicos. Por favor intente más tarde." ,"300","O8"),
	_O9 ("No es posible procesar la transacción - Problemas técnicos. Por favor intente más tarde." ,"300","O9"),
	_X1 ("No es posible procesar la transacción - Problemas técnicos. Por favor intente más tarde." ,"300","X1"),
	_X2 ("No es posible procesar la transacción - Problemas técnicos. Por favor intente más tarde." ,"300","X2"),
	_X3 ("No es posible procesar la transacción - Problemas técnicos. Por favor intente más tarde." ,"300","X3"),
	_X4 ("No es posible procesar la transacción - Problemas técnicos. Por favor intente más tarde." ,"300","X4"),
	_X5 ("No es posible procesar la transacción - Problemas técnicos. Por favor intente más tarde." ,"300","X5"),
	_X6 ("No es posible procesar la transacción - Problemas técnicos. Por favor intente más tarde." ,"300","X6"),
	_X7 ("No es posible procesar la transacción - Problemas técnicos. Por favor intente más tarde." ,"300","X7"),
	_9009 ("No es posible procesar la transacción - Problemas técnicos. Por favor intente más tarde." ,"300","9009"),
	_DEFAULT ("No es posible procesar la transacción - Problemas técnicos. Por favor intente más tarde." ,"300","DEFAULT");
	/**
	 * FIN-C01
	 */
	private final String desc;
    private final String homologationCode;
    private final String rbmCode;
    
    HomologationCodesEnum(String desc, String homologationCode, String rbmCode) {
        this.desc = desc;
        this.homologationCode = homologationCode;
        this.rbmCode= rbmCode;
    }

    public String getDesc() {
        return desc;
    }
    public String getHomologationCode() {
        return homologationCode;
    }
    public String getRbmCode() {
        return rbmCode;
    }
    /**
     * Metodo para realizar busqueda de codigo por los enum.
     * @param rbmCode
     * @return
     */
    public static HomologationCodesEnum findByRBMCode(String rbmCode) {
    	HomologationCodesEnum[] listHomologationCodeEnums = HomologationCodesEnum.values();
        for (HomologationCodesEnum homologationCodeEnum : listHomologationCodeEnums) {
            if (homologationCodeEnum.rbmCode.equals(rbmCode)) {
                return homologationCodeEnum;
            }
        }
        return HomologationCodesEnum._DEFAULT;
    }
}
