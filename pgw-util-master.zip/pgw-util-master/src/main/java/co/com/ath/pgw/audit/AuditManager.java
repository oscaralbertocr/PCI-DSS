package co.com.ath.pgw.audit;

import java.util.HashMap;

import javax.annotation.Resource;


import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpMethod;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;


import co.com.ath.pgw.bsn.service.rs.impl.NotificationPaymentsImpl;
import co.com.ath.pgw.util.dto.AuditEntityDTO;
import co.com.ath.pgw.util.rest.AbstractRestClient;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

@Service
public class AuditManager {
	

	static Logger LOGGER = LoggerFactory.getLogger(AuditManager.class);
	
	@Value("${core.services.in.host}")
	private String restHost;

	@Value("${core.services.in.post.audit.core}")
	private String restPostAuditCore;
	
	@Resource
	private AbstractRestClient abstractRestClient;
	
	@Async
	public void error(AuditEntityDTO auditEntityDTO, String iPAddr) {
		try {
			LOGGER.info("@AuditEntityDTO IP:{} \n" + auditEntityDTO, iPAddr);
			String uri = restHost+restPostAuditCore;
			HashMap<String, String> headersMap = new HashMap<String, String>();
			headersMap.put("X-IPAddr", iPAddr);
			abstractRestClient.consumeRest(uri, auditEntityDTO, HttpMethod.POST, headersMap);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
}
