package co.com.ath.pgw.util.converter;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import co.com.ath.pgw.bsn.dto.in.AgreementSynchronizationInDTO;
import co.com.ath.pgw.bsn.dto.out.AgreementOutDTO;
import co.com.ath.pgw.bsn.dto.out.AgreementSynchronizationOutDTO;
import co.com.ath.pgw.in.dto.AgreementRsType;
import co.com.ath.pgw.in.dto.AgreementSynchronizationRqType;
import co.com.ath.pgw.in.dto.AgreementSynchronizationRsType;
import co.com.ath.pgw.in.model.SeverityType;
import co.com.ath.pgw.in.model.StatusType;
import co.com.ath.pgw.rest.request.dto.Header;
import co.com.ath.pgw.rest.request.dto.RequestAgrmSynch;
import co.com.ath.pgw.util.constants.CoreConstants;

/**
* Convertidor de objetos que vienen de los servicios a objetos del core
* @author proveedor_cjmurillo
* @version 1.0
* @since 1.0
*/

public class AgreementSynchronizationObjectsConverter {
    
    static Logger LOGGER = LoggerFactory.getLogger(AgreementSynchronizationObjectsConverter.class);
    

    /**
    * Convierte de AgreementSynchronizationRqType a AgreementSynchronizationInDTO
    * @param inn
    * @return out
    */
    public static AgreementSynchronizationInDTO toAgreementSynchronizationInDTO(AgreementSynchronizationRqType inn){
       AgreementSynchronizationInDTO out = new AgreementSynchronizationInDTO();
       out.setClientDt(DateUtil.toDate(inn.getClientDt()));
       out.setIpAddr(inn.getIPAddr());
       out.setRqUID(inn.getRqUID());
       out.setAgreementSynchronizationRqType(inn);
       return out;
    }
    
    /**
    * Convierte de AddTransactionOutDTO a TransactionAddRsType
    * @param inn
    * @return
    */
    public static AgreementRsType toAgreementSynchronizationRsType(AgreementOutDTO inn) {
       
       StatusType status = new StatusType();
       status.setStatusCode(inn.getStatusCode());
       status.setStatusDesc(inn.getStatusDesc());
       status.setServerStatusCode(inn.getTrnServerStatusCode());
       status.setServerStatusDesc(inn.getTrnServerStatusDesc());
       status.setSeverity(SeverityType.fromValue("Info"));
       
       AgreementRsType out = new AgreementRsType();
       out.setStatus(status);
       out.setRqUID(inn.getRqUID());
       out.setApprovalId(inn.getApprovalId());
       return out;
    }
    
    /**
    * Convierte de AgreementSynchronizationOutDTO a AgreementSynchronizationRsTypeError
    * @param inn
    * @return
    */
    public static AgreementRsType toAgreementSynchronizationRsTypeError(
                   AgreementSynchronizationRqType inn, Exception ex) {
                   
       StatusType status = new StatusType();
       status.setStatusCode(CoreConstants.ERROR_STATUS_CODE_600);
       status.setStatusDesc(CoreConstants.ERROR_STATUS_CODE_DESC_600);
       status.setServerStatusCode(CoreConstants.ERROR_STATUS_CODE_600.toString());
       status.setServerStatusDesc(ex.toString());
       status.setSeverity(SeverityType.fromValue("Error"));
       
       AgreementRsType out = new AgreementRsType();
       out.setStatus(status);
       out.setRqUID(inn.getRqUID());
       out.setApprovalId(null);
       return out;
    }
    public static AgreementRsType toAgreementRsTypeError(RequestAgrmSynch inn, Header headerDto, Exception ex) {
       
       StatusType status = new StatusType();
       status.setStatusCode(CoreConstants.ERROR_STATUS_CODE_600);
       status.setStatusDesc(CoreConstants.ERROR_STATUS_CODE_DESC_600);
       status.setServerStatusCode(CoreConstants.ERROR_STATUS_CODE_600.toString());
       status.setServerStatusDesc(ex.toString());
       status.setSeverity(SeverityType.fromValue("Error"));
       
       AgreementRsType out = new AgreementRsType();
       out.setStatus(status);
       out.setRqUID(headerDto.getRqUID());
       out.setApprovalId(null);
       return out;
   }
}

