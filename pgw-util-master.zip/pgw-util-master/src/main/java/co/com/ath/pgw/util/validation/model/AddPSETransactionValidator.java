/*
 * AddPSETransactionValidator
 *  
 * GSI - Integración
 * Creado el: 19/09/2014
 *
 * Copyright (c) A Toda Hora S.A. Todos los derechos reservados
 * 
 * Este software es confidencial y es propietario de ATH, queda prohibido
 * su uso, reproducción y copia de manera parcial o permanente salvo autorización
 * expresa de A Toda Hora S.A o de quién represente sus derechos.
 */
package co.com.ath.pgw.util.validation.model;

import co.com.ath.pgw.bsn.dto.in.AddPSETransactionInDTO;
import co.com.ath.pgw.util.validation.ValidationException;

/**
 * Validación para los datos de entrada para la operación AddPSETransaction.
 * 
 * @author Andrés Méndez Juanias <proveedor_mamendez@ath.com.co>
 * @version 1.0.0 19/09/2014
 */
public interface AddPSETransactionValidator {

	public void validate(AddPSETransactionInDTO inDTO)
			throws ValidationException;
}
