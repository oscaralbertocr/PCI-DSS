/*
 * PaymentGatewayOperation
 *  
 * GSI - Integración
 * Creado el: 15/10/2014
 *
 * Copyright (c) A Toda Hora S.A. Todos los derechos reservados
 * 
 * Este software es confidencial y es propietario de ATH, queda prohibido
 * su uso, reproducción y copia de manera parcial o permanente salvo autorización
 * expresa de A Toda Hora S.A o de quién represente sus derechos.
 */
package co.com.ath.pgw.util.constants;

/**
 * Class description goes here...
 *
 * @author Andrés Méndez Juanias <proveedor_mamendez@ath.com.co> 
 * @version 1.0 15/10/2014
 * @since 1.0
 */
public interface PaymentGatewayOperation {
	
	String ADD_TRANSACTION = "addTransaction";
	
	String GET_TRANSACTION = "getTransaction";
	
	String ADD_AVAL_PAYMENT = "addAVALPayment";
	
	String ADD_PSE_TRANSACTION = "addPSETransaction";
	
	String ADD_RBM_PAYMENT = "addRBMPayment";
	
	String GET_TRANSACTION_BY_ID = "getTransactionById";
	
	String GET_TRANSACTION_BY_TOKEN = "getTransactionByToken";

	String GET_TRANSACTION_STATUS = "getTransactionStatus";
}
