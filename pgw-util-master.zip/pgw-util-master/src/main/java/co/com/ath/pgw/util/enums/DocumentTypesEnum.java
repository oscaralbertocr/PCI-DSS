/*
 * DocumentTypesEnum
 *  
 * GSI - Integración
 * Creado el: 23/04/2015
 *
 * Copyright (c) A Toda Hora S.A. Todos los derechos reservados
 * 
 * Este software es confidencial y es propietario de ATH, queda prohibido
 * su uso, reproducción y copia de manera parcial o permanente salvo autorización
 * expresa de A Toda Hora S.A o de quién represente sus derechos.
 */
package co.com.ath.pgw.util.enums;

/**
 * Enum con los tipos de documento válidos en pasarela.
 *
 * @author Andrés Méndez Juanias <proveedor_mamendez@ath.com.co> 
 * @version 1.0 23/04/2015
 * @since 1.0
 */
public enum DocumentTypesEnum {

	CC, //Cédula de ciudadanía.
	CE, //Cédula de extranjería.
	TI, //Tarjeta de identidad.
	PP, //Pasaporte.
	RC, //Registro civil.
	NIT, //NIT.
	GUEST; //Invitado.
}
