package co.com.ath.pgw.util.qr;

/**
 * Constantes requeridas para la respuesta del servicio.
 * 
 * @author Sophos Solutions.
 * @author Jesus Octavio Avenda�o <strong>jesus.avendano@sophossolutions.com</strong>
 * @version 0.0.0 01/11/2020
 */
public interface Constants {
	
	public static final String URL_AUTORIZACION_USER = "/pgw-services/usuarios/user/";
	public static final String URL_PARAMETRO = "/pgw-services/rest/parametro/{clave}";
	public static final String URL_LISTA = "/pgw-services/rest/parametro/lista";
	
}
