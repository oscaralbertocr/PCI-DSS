/**
 * 
 */
package co.com.ath.pgw.util.validation.model;

import co.com.ath.pgw.util.validation.ValidationException;
import co.com.ath.pgw.util.validation.model.dto.TransactionIdNuraCodeInDTO;

/**
 * @author proveedor_japiza
 *
 */
public interface TransactionIdNuraCodeValidator {
	
	public void validate(TransactionIdNuraCodeInDTO inDTO)
			throws ValidationException;

}
