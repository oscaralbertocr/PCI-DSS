/*
 * ObjectValidationException
 *
 * GSI - Integración
 * Creado el: 5 de septiembre de 2014
 *
 * Copyright (c) A Toda Hora S.A. Todos los derechos reservados
 *
 * Este software es confidencial y es propietario de ATH, queda prohibido
 * su uso, reproducción y copia de manera parcial o permanente salvo autorización
 * expresa de A Toda Hora S.A o de quién represente sus derechos.
 */
package co.com.ath.pgw.util.validation;

/**
 * Esta excepción es lanzada cuando una validación sobre un 
 * objeto simple no es satisfactoria.
 * 
 * @author proveedor_zagarcia
 * @version 1.0 05 Sep 2014
 * @since 1.0
 */
public class ObjectValidationException extends Exception {

	/**
	 * Serial generado
	 */
	private static final long serialVersionUID = 9035097831905759438L;

	/**
	 * Construye una excepción de validación de atributo con un mensaje de error
	 * 
	 * @param message    Mensaje de error
	 */
	public ObjectValidationException(String message){
		super(message);
	}

}