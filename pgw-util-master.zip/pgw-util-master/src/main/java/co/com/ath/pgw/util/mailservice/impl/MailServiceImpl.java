/*
 * PgwMailService
 *  
 * GSI - Integración
 * Creado el: 27/10/2014
 *
 * Copyright (c) A Toda Hora S.A. Todos los derechos reservados
 * 
 * Este software es confidencial y es propietario de ATH, queda prohibido
 * su uso, reproducción y copia de manera parcial o permanente salvo autorización
 * expresa de A Toda Hora S.A o de quién represente sus derechos.
 */
package co.com.ath.pgw.util.mailservice.impl;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.Iterator;
import java.util.Map;
import java.util.Properties;
import java.util.Set;
import java.util.regex.Matcher;

import javax.annotation.PostConstruct;
import javax.annotation.Resource;
import javax.mail.MessagingException;
import javax.mail.internet.MimeMessage;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.env.Environment;
import org.springframework.core.io.FileSystemResource;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.mail.javamail.JavaMailSenderImpl;
import org.springframework.mail.javamail.MimeMessageHelper;
import org.springframework.stereotype.Service;

import co.com.ath.pgw.util.converter.Util;
import co.com.ath.pgw.util.enums.MailTypeEnum;
import co.com.ath.pgw.util.exception.IllegalLineSizeException;
import co.com.ath.pgw.util.mail.dto.MailServiceInDTO;


/**
 * Implementación por defecto del envío de correo.
 *
 * @author Andrés Méndez Juanias <proveedor_mamendez@ath.com.co> 
 * @version 1.0 27/10/2014
 * @since 1.0
 * 
 * @IM714148 <strong>Autor</strong>Andres Eduardo Hernandez</br>
 * 			 <strong>Descripcion</strong>Extracto Digital Pagos PSE</br>
 * 			 <strong>Numero de Cambios</strong>1</br>
 * 			 <strong>Identificador corto</strong>C01</br>
 * 
 *  @PDP-374
 * <strong>Autor</strong>Camilo Bustamante</br>
 * <strong>Descripcion</strong>Envio de correo promocional</br>
 * <strong>Numero de Cambios</strong>1</br>
 * <strong>Identificador corto</strong>C01</br>
 * 
 */
@Service
public class MailServiceImpl {
	
	/**
	 * Tamaño máximo de la línea que podrá ser procesada al cargar una
	 * plantilla de correo
	 */
	private static final int MAX_LINE_SIZE = 300;
	
	private static Logger logger = LoggerFactory.getLogger(MailServiceImpl.class);
	
	@Value("${pasarela.mail.from}")
	private String from;
	
	@Value("${pasarela.mail.encoding:UTF-8}")
    private String encoding;
	
	@Value("${pasarela.mail.template.path}")
    private String mailTemplatePath;
	
	@Resource
	private Environment environment;
	
	private JavaMailSender javaMailSender;
	
	private MailTypeEnum mailType = MailTypeEnum.CONFIRMATION_PLAIN_TEXT;
	
	/**
	 * Constructor por defecto del servicio de mail.
	 */
	public MailServiceImpl() {
		super();
	}
	
	/**
	 * Método que inicializa la configuración del servicio de email.
	 */
	@PostConstruct
	public void init() {
		JavaMailSenderImpl mailSenderImpl = new JavaMailSenderImpl();
		mailSenderImpl.setHost(environment.getProperty("pasarela.mail.host"));
		mailSenderImpl.setPort(environment.getProperty("pasarela.mail.port", Integer.class));
		if(environment.containsProperty("pasarela.mail.username") && !environment.getProperty("pasarela.mail.username").isEmpty()){
			mailSenderImpl.setUsername(environment.getProperty("pasarela.mail.username"));
		}
		if(environment.containsProperty("pasarela.mail.password") && !environment.getProperty("pasarela.mail.password").isEmpty()){
			mailSenderImpl.setPassword(environment.getProperty("pasarela.mail.password"));
		}
		mailSenderImpl.setJavaMailProperties(getMailProperties());
		javaMailSender = mailSenderImpl;
	}
	
	/**
	 * Obtiene las propiedades adicionales para el servicio de email. 
	 * @return Propiedades adicionales para la conexion de email.
	 */	
	private Properties getMailProperties() {
		Properties mailProperties = new Properties();
		if(environment.containsProperty("mail.smtp.auth")){
			mailProperties.put("mail.smtp.auth", environment.getProperty("mail.smtp.auth"));
		}
		if(environment.containsProperty("mail.transport.protocol")){
			mailProperties.put("mail.transport.protocol", environment.getProperty("mail.transport.protocol"));
		}
		if(environment.containsProperty("mail.smtp.starttls.enable")){
			mailProperties.put("mail.smtp.starttls.enable", environment.getProperty("mail.smtp.starttls.enable"));
		}
		if(environment.containsProperty("mail.smtp.ssl.trust")){
			mailProperties.put("mail.smtp.ssl.trust", environment.getProperty("mail.smtp.ssl.trust"));
		}
		if(environment.containsProperty("mail.debug")){
			mailProperties.put("mail.debug", environment.getProperty("mail.debug"));
		}
        return mailProperties;
	}
	
	
	public void send(MailServiceInDTO inDTO, String mailTemplate) throws MessagingException {
		
		if(null!=inDTO.getArgs().get("transactionId")){
			logger.info("Enviando Correo... PmtId: {}", inDTO.getArgs().get("transactionId"));
		}else{
			logger.info("Enviando Correo... Sin PmtId");
		}
		
		if(inDTO.getMailTypeEnum() != null){
			mailType = inDTO.getMailTypeEnum();
		}
		
		MimeMessage message = javaMailSender.createMimeMessage();
		MimeMessageHelper helper = new MimeMessageHelper(message, true, encoding);
		helper.setFrom((inDTO.getFrom() != null)? inDTO.getFrom(): from);
		helper.setTo(inDTO.getTo());
		if(inDTO.getCc() != null){
			helper.setCc(inDTO.getCc());
		}
		if(inDTO.getBcc() != null){
			helper.setBcc(inDTO.getBcc());
		}
		helper.setSubject(replaceArgs(inDTO.getSubject(), inDTO.getArgs()));
		helper.setText(getMessageText(inDTO.getArgs(), mailTemplate), mailType.isHTML());

		// Adjuntar archivos al correo
		if(inDTO.getAttachmentList() != null){
			for(File file : inDTO.getAttachmentList()){
				helper.addAttachment(file.getName(), file);
			}
		}
		// Envía el email
		javaMailSender.send(message);
	}
	
	public void send(MailServiceInDTO inDTO, String mailTemplate, Map<String, String> imagenes) throws MessagingException {
		
		if(null!=inDTO.getArgs().get("transactionId")){
			logger.info("Enviando Correo... PmtId: {}", inDTO.getArgs().get("transactionId"));
		}else{
			logger.info("Enviando Correo... Sin PmtId");
		}
		
		if(inDTO.getMailTypeEnum() != null){
			mailType = inDTO.getMailTypeEnum();
		}
		
		MimeMessage message = javaMailSender.createMimeMessage();
		MimeMessageHelper helper = new MimeMessageHelper(message, true, encoding);
		helper.setFrom((inDTO.getFrom() != null)? inDTO.getFrom(): from);
		helper.setTo(inDTO.getTo());
		if(inDTO.getCc() != null){
			helper.setCc(inDTO.getCc());
		}
		if(inDTO.getBcc() != null){
			helper.setBcc(inDTO.getBcc());
		}
		helper.setSubject(replaceArgs(inDTO.getSubject(), inDTO.getArgs()));
		helper.setText(getMessageText(inDTO.getArgs(), mailTemplate), Boolean.TRUE);
		
		
		// Se agregan las imagenes al correo.
		Iterator<String> it = imagenes.keySet().iterator();
		while(it.hasNext()){
		  String key = it.next();
		  String val = imagenes.get(key);

		  org.springframework.core.io.Resource resource1 = new FileSystemResource(new File(val));
		  helper.addInline(key, resource1);
		}

		// Adjuntar archivos al correo
		if(inDTO.getAttachmentList() != null){
			for(File file : inDTO.getAttachmentList()){
				helper.addAttachment(file.getName(), file);
			}
		}
		
		// Envía el email
		javaMailSender.send(message);
	}
	
	/**
	 * Lee un archivo css y lo retorna en un String
	 * @param css
	 * @return
	 */
	public String getEmailCSS(String css) {

		File archivo = null;
		FileReader fr = null;
		BufferedReader br = null;
		
		try {

			archivo = new File(css);
			fr = new FileReader(archivo);
			br = new BufferedReader(fr);
			css = "";

			String linea;
			while ((linea = br.readLine()) != null)
				css+=linea; 
			
		} catch (Exception e) {
			logger.error(e.getLocalizedMessage());
		} finally {
			try {
				if (null != fr) {
					fr.close();
				}
			} catch (Exception e2) {
				logger.error(e2.getLocalizedMessage());
			}
		}
		
		return css;
	}
		
		
	/**
	 * Realiza el formateo del texto enviado con los parametros. 
	 * @param text 
	 * @param args
	 * @return
	 */
	private String getMessageText(Map<String, String> args, String mailTemplate) {

		String text = "";

		/** INICIO-C01 */
		if(null==mailTemplate || "".equals(mailTemplate))
			text = readFile(mailTemplatePath, mailType.getTemplate());
		else
			text = readFile(mailTemplatePath, mailTemplate);
		/** FIN-C01 */
		
		return replaceArgs(text, args);
		
	}
	
	/**
	 * Método encargado de reemplazar los argumentos en una cadena de texto dada.
	 * @param text Cadena de texto.
	 * @param args Argumentos a remplazar.
	 * @return Cadena de texto procesada.
	 */
	private String replaceArgs(String text, Map<String, String> args) {
		if (args != null && text != null) {
			Set<String> keySet = args.keySet();
			for (String key : keySet) {
				String value = args.get(key) != null ? args.get(key): "";
				text = text.replaceAll("\\{\\{[ ]*" + key + "[ ]*\\}\\}",
						Matcher.quoteReplacement(value));
			}
		}
		return text;
	}
	
	/**
	 * Método encargado leer un archivo como String.
	 * @param path Ruta del archivo.
	 * @param fileName Nombre del archivo.
	 * @return String con el contenido del archivo.
	 * @throws IOException
	 */
	private String readFile(String path, String fileName) {

		StringBuilder sb = new StringBuilder();
		File file = new File(path, fileName);
		BufferedReader br = null;
		
		try {
			
			br = new BufferedReader(new FileReader(file));
			String ls = System.getProperty("line.separator");
			String line = br.readLine();
			
			while (line != null) {
				
				if (line.length() > MAX_LINE_SIZE) {
					br.close();
					throw new IllegalLineSizeException("Tamaño ilegal en alguna línea de la plantilla");
				}
				
				sb.append(line);
				sb.append(ls);
				
				line = br.readLine();
			}
			
		} catch (FileNotFoundException e) {
			logger.info("No fue posible cargar el template de email {} en la ruta {}\n{}", mailType.getTemplate(), mailTemplatePath, e.getLocalizedMessage());
		} catch (IOException e) {
			logger.info("No fue posible cargar el template de email {} en la ruta {}\n{}", mailType.getTemplate(), mailTemplatePath, e.getLocalizedMessage());
		} catch (IllegalLineSizeException e) {
			logger.info("Tamaño ilegal en alguna línea del template de email {} en la ruta {}\n{}", mailType.getTemplate(), mailTemplatePath, e.getLocalizedMessage());
		}finally{
			
			if(null!=br)
				Util.safeClose(br);
			
		}

		return sb.toString();
	}
	
	/** INICIO-C01 **/
	public void sendNotification(MailServiceInDTO inDTO) throws MessagingException {
		MimeMessage message = javaMailSender.createMimeMessage();
		MimeMessageHelper helper = new MimeMessageHelper(message, true, encoding);
		helper.setFrom((inDTO.getFrom() != null)? inDTO.getFrom(): from);
		helper.setTo(inDTO.getTo());
		helper.setSubject(replaceArgs(inDTO.getSubject(), inDTO.getArgs()));
		helper.setText(inDTO.getText());
		javaMailSender.send(message);
	}
	/** FIN-C01 **/

}