package co.com.ath.pgw.util.mask;

public interface MaskData {
	
	public String getMaskData(String data);
	public String getTruncateData(String data);

}
