package co.com.ath.pgw.util.qr;

import java.io.Serializable;

public class EstadoQR implements Serializable {

	private String codigoRespuesta;
	private String descripcionRespuesta;

	public EstadoQR() {
		super();
	}

	public String getCodigoRespuesta() {
		return codigoRespuesta;
	}

	public void setCodigoRespuesta(String codigoRespuesta) {
		this.codigoRespuesta = codigoRespuesta;
	}

	public String getDescripcionRespuesta() {
		return descripcionRespuesta;
	}

	public void setDescripcionRespuesta(String descripcionRespuesta) {
		this.descripcionRespuesta = descripcionRespuesta;
	}

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

}
