package co.com.ath.pgw.util.validation.model;

import java.util.Locale;

/**
 * Objeto para validación de autenticación del comercio en el método 
 * addTransaction
 * @author proveedor_zagarcia
 *
 */
public class AgreementAuthData {
	
	/**
	 * Código NURA del comercio.
	 */
	private String commerceId;
	
	/**
	 * Usuario del comercio
	 */
	private String user;
	
	/**
	 * El identificador secreto del comercio
	 */
	private String password;
	
	/**
	 * Tipo de cifrado usado
	 */
	private String crypType;
	
	/**
	 * Longitud de clave
	 */
	private Long binLength;
	
	/**
	 * Información de localización e idioma.
	 */
	private Locale locale;

	/**
	 * @return Código de identificación del comercio
	 */
	public String getCommerceId() {
		return commerceId;
	}

	/**
	 * @param commerceId Establece el código de identificación del comercio.
	 */
	public void setCommerceId(String commerceId) {
		this.commerceId = commerceId;
	}

	/**
	 * @return ID usuario del comercio.
	 */
	public String getUser() {
		return user;
	}

	/**
	 * Establece el ID de usuario del comercio
	 * @param user ID usuario del comercio.
	 */
	public void setUser(String user) {
		this.user = user;
	}

	/**
	 * 
	 * @return El identificador secreto del comercio
	 */
	public String getPassword() {
		return password;
	}

	/**
	 * @param pwd Identificador secreto del comercio
	 */
	public void setPassword(String pwd) {
		this.password = pwd;
	}

	/**
	 * Retorna el tipo de cifrado usado
	 * @return Tipo de cifrado
	 */
	public String getCrypType() {
		return crypType;
	}

	/**
	 * Establece el tipo de cifrado
	 * @param crypType Tipo de cifrado
	 */
	public void setCrypType(String crypType) {
		this.crypType = crypType;
	}

	/**
	 * Retorna la longitud de la clave
	 * @return Longitud de la clave
	 */
	public Long getBinLength() {
		return binLength;
	}

	/**
	 * Establece la longitud de la clave
	 * @param binLength Longitud de la clave.
	 */
	public void setBinLength(Long binLength) {
		this.binLength = binLength;
	}

	/**
	 * Retorna la información de localización e idioma
	 * @return the locale
	 */
	public Locale getLocale() {
		return locale;
	}

	/**
	 * Establece la información de localización e idioma.
	 * @param locale the locale to set
	 */
	public void setLocale(Locale locale) {
		this.locale = locale;
	}
	
}
