/*
 * SourceTransactionCodes
 *  
 * GSI - Integración
 * Creado el: 7/10/2014
 *
 * Copyright (c) A Toda Hora S.A. Todos los derechos reservados
 * 
 * Este software es confidencial y es propietario de ATH, queda prohibido
 * su uso, reproducción y copia de manera parcial o permanente salvo autorización
 * expresa de A Toda Hora S.A o de quién represente sus derechos.
 */
package co.com.ath.pgw.util.enums;

/**
 * Códigos del Portal de origen de la transacción.
 * 
 * @author Camilo Andres Bustamante <camilo.bustamante@sophossolutions.com>
 * @version 1.0 11/07/2018
 * @since 1.0
 * @RQ30455
 * 
 * 
 */
public interface SourcePortalCodesEnum {

	/** Portal de Pagos Aval */
	Long PORTAL_PAGOS_AVAL			= 1L;
	
	/** Portal del Grupo Aval (BAVV, BBOG, BPOP, BOCC) */
	Long PORTAL_BANCO_GRUPO_AVAL	= 2L;
	
	/** Otros (Baloto, K7, ...) */
	Long OTROS						= 3L;
	
	/** convenios externos (Codensa, ...) **/
	Long EXTERNOS =4L;
}