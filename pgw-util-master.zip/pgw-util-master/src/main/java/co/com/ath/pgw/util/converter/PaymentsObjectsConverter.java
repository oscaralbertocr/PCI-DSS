package co.com.ath.pgw.util.converter;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

import javax.xml.datatype.DatatypeConfigurationException;
import javax.xml.datatype.DatatypeConstants;
import javax.xml.datatype.DatatypeFactory;
import javax.xml.datatype.XMLGregorianCalendar;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import co.com.ath.pgw.bsn.dto.in.ACHCreateTransactionInDTO;
import co.com.ath.pgw.bsn.dto.in.ACHgetTransactionInformationInDTO;
import co.com.ath.pgw.bsn.dto.in.AddAVALPaymentInDTO;
import co.com.ath.pgw.bsn.dto.in.AddPSETransactionInDTO;
import co.com.ath.pgw.bsn.dto.in.AddRBMPaymentInDTO;
import co.com.ath.pgw.bsn.dto.in.AddTransactionInDTO;
import co.com.ath.pgw.bsn.dto.in.GetHistoricTransactionInDTO;
import co.com.ath.pgw.bsn.dto.in.GetTransactionByIdInDTO;
import co.com.ath.pgw.bsn.dto.in.GetTransactionByTokenInDTO;
import co.com.ath.pgw.bsn.dto.in.GetTransactionInDTO;
import co.com.ath.pgw.bsn.dto.in.GetTransactionStatusInDTO;
import co.com.ath.pgw.bsn.dto.in.ModRevRBMPaymentInDTO;
import co.com.ath.pgw.bsn.dto.in.ModTransactionInfoInDTO;
import co.com.ath.pgw.bsn.dto.in.ModTransactionStatusInDTO;
import co.com.ath.pgw.bsn.dto.in.TokenizeInDTO;
import co.com.ath.pgw.bsn.dto.out.ACHCreateTransactionOutDTO;
import co.com.ath.pgw.bsn.dto.out.ACHFinalizeTransactionPaymentInDTO;
import co.com.ath.pgw.bsn.dto.out.ACHFinalizeTransactionPaymentOutDTO;
import co.com.ath.pgw.bsn.dto.out.ACHgetTransactionInformationOutDTO;
import co.com.ath.pgw.bsn.dto.out.AddAVALPaymentOutDTO;
import co.com.ath.pgw.bsn.dto.out.AddPSETransactionOutDTO;
import co.com.ath.pgw.bsn.dto.out.AddRBMPaymentOutDTO;
import co.com.ath.pgw.bsn.dto.out.AddTransactionOutDTO;
import co.com.ath.pgw.bsn.dto.out.GetHistoricTransactionOutDTO;
import co.com.ath.pgw.bsn.dto.out.GetTransactionByIdOutDTO;
import co.com.ath.pgw.bsn.dto.out.GetTransactionByTokenOutDTO;
import co.com.ath.pgw.bsn.dto.out.GetTransactionOutDTO;
import co.com.ath.pgw.bsn.dto.out.GetTransactionStatusOutDTO;
import co.com.ath.pgw.bsn.dto.out.ModRevRBMPaymentOutDTO;
import co.com.ath.pgw.bsn.dto.out.ModTransactionInfoOutDTO;
import co.com.ath.pgw.bsn.dto.out.ModTransactionStatusOutDTO;
import co.com.ath.pgw.bsn.dto.out.TokenizeOutDTO;
import co.com.ath.pgw.bsn.dto.out.TransactionInfoOutDTO;
import co.com.ath.pgw.bsn.model.bo.BankBO;
import co.com.ath.pgw.bsn.model.bo.BrandBO;
import co.com.ath.pgw.bsn.model.bo.CommerceBO;
import co.com.ath.pgw.bsn.model.bo.CommerceConfigurationBO;
import co.com.ath.pgw.bsn.model.bo.CreditCardBO;
import co.com.ath.pgw.bsn.model.bo.PaymentWayBO;
import co.com.ath.pgw.bsn.model.bo.ProductTypeBO;
import co.com.ath.pgw.bsn.model.bo.ProtectBO;
import co.com.ath.pgw.bsn.model.bo.StatusBO;
import co.com.ath.pgw.bsn.model.bo.SubscriptionBO;
import co.com.ath.pgw.bsn.model.bo.TokenBO;
import co.com.ath.pgw.bsn.model.bo.TokenizeDataInfoBO;
import co.com.ath.pgw.bsn.model.bo.TransactionBO;
import co.com.ath.pgw.bsn.model.bo.TransactionSourceBO;
import co.com.ath.pgw.bsn.model.bo.TransactionStatusBO;
import co.com.ath.pgw.bsn.model.bo.TransactionTypeBO;
import co.com.ath.pgw.bsn.model.bo.UserBO;
import co.com.ath.pgw.client.ach.dto.FinalizeTransactionPaymentInp;
import co.com.ath.pgw.client.ach.dto.FinalizeTransactionPaymentOut;
import co.com.ath.pgw.client.ach.dto.TransactionInformationInp;
import co.com.ath.pgw.client.ach.dto.TransactionInformationOut;
import co.com.ath.pgw.client.ach.dto.TransactionPaymentInp;
import co.com.ath.pgw.client.ach.dto.TransactionPaymentOut;
import co.com.ath.pgw.client.rbm.dto.TipoRespuesta;
import co.com.ath.pgw.client.rbm.dto.TipoSolicitudCompra;
import co.com.ath.pgw.client.rbm.model.TipoIdPersona;
import co.com.ath.pgw.client.rbm.model.TipoIdTarjetaCredito;
import co.com.ath.pgw.client.rbm.model.TipoInfoCompra;
import co.com.ath.pgw.client.rbm.model.TipoInfoImpuestos;
import co.com.ath.pgw.client.rbm.model.TipoInfoMedioPago;
import co.com.ath.pgw.client.rbm.model.TipoTipoDocumento;
import co.com.ath.pgw.client.rbm.model.TipoTipoImpuesto;
import co.com.ath.pgw.client.tokenize.dto.TokenizedDataRqType;
import co.com.ath.pgw.client.tokenize.dto.TokenizedDataRsType;
import co.com.ath.pgw.client.tokenize.model.TokenizedDataInfoRqType;
import co.com.ath.pgw.in.dto.AVALPaymentAddRqType;
import co.com.ath.pgw.in.dto.AVALPaymentAddRsType;
import co.com.ath.pgw.in.dto.HistoricTransactionInqRqType;
import co.com.ath.pgw.in.dto.HistoricTransactionInqRsType;
import co.com.ath.pgw.in.dto.PSETransactionAddRqType;
import co.com.ath.pgw.in.dto.PSETransactionAddRsType;
import co.com.ath.pgw.in.dto.RBMPaymentAddRqType;
import co.com.ath.pgw.in.dto.RBMPaymentAddRsType;
import co.com.ath.pgw.in.dto.TransactionAddRqType;
import co.com.ath.pgw.in.dto.TransactionAddRsType;
import co.com.ath.pgw.in.dto.TransactionInfoModRqType;
import co.com.ath.pgw.in.dto.TransactionInfoModRsType;
import co.com.ath.pgw.in.dto.TransactionInqRqType;
import co.com.ath.pgw.in.dto.TransactionInqRsType;
import co.com.ath.pgw.in.dto.TransactionStatusInqRqType;
import co.com.ath.pgw.in.dto.TransactionStatusInqRsType;
import co.com.ath.pgw.in.dto.TransactionStatusModRqType;
import co.com.ath.pgw.in.dto.TransactionStatusModRsType;
import co.com.ath.pgw.in.model.AgreementInfoType;
import co.com.ath.pgw.in.model.CommerceSettingType;
import co.com.ath.pgw.in.model.CustNameType;
import co.com.ath.pgw.in.model.FeeType;
import co.com.ath.pgw.in.model.InvoiceReferenceType;
import co.com.ath.pgw.in.model.OrderInfoType;
import co.com.ath.pgw.in.model.PersonalDataType;
import co.com.ath.pgw.in.model.PmtWayType;
import co.com.ath.pgw.in.model.RecordTransactionInfoType;
import co.com.ath.pgw.in.model.ReferenceType;
import co.com.ath.pgw.in.model.SecretListType;
import co.com.ath.pgw.in.model.SeverityType;
import co.com.ath.pgw.in.model.StatusType;
import co.com.ath.pgw.in.model.TaxFeeType;
import co.com.ath.pgw.in.model.TransactionStatusType;
import co.com.ath.pgw.in.model.TrmType;
import co.com.ath.pgw.in.model.UserIdType;
import co.com.ath.pgw.util.constants.CoreConstants;
import co.com.ath.pgw.util.enums.BusinessStatusEnum;
import co.com.ath.pgw.util.enums.HomologationCodesEnum;
import co.com.ath.pgw.util.validation.ValidationException;

/**
 * Convertidor de objetos que vienen de los servicios a objetos del core
 * @author proveedor_cjmurillo
 * @version 1.0
 * @since 1.0
 * 
 * @RQ27528
 * <strong>Autor</strong> Jordan Andrei Cortes </br>
 * <strong>Descripcion</strong> Multireferencias No Facturadores </br>
 * <strong>Numero de Cambios</strong> 1</br>
 * <strong>Identificador corto</strong> C01</br>
 *
 *  @RQ27828
 * 	<strong>Autor</strong> Luis Hernando Bonilla Cortes</br>
 *  <strong>Descripcion</strong>COnvertir objetos del servicio de tokenizacion a DTOs</br>
 *  <strong>Numero de Cambios</strong> 5</br>
 *  <strong>Numero de Cambios</strong> 5</br>
 *  <strong>Identificador corto</strong> C02</br>
 * 
 *  
 *  @RQ24519
 *  <strong>Autor</strong>Camilo Bustamante</br>
 *  <strong>Descripcion</strong>Motor de Riesgo</br>
 *  <strong>Numero de Cambios</strong>1</br>
 *  <strong>Identificador corto</strong>C02</br>
 *  
 *  @RQ25675
 *  <strong>Autor</strong>Efren Lopez Galvis</br>
 *  <strong>Descripcion</strong>Persistencia PMTID</br>
 *  <strong>Numero de Cambios</strong>1</br>
 *  <strong>Identificador corto</strong>C03</br>
 *  
 *  @RQ31820
 *  <strong>Autor</strong>Roger Jans Leguizamon Cespedes</br>
 *  <strong>Descripcion</strong>URL de retorno a comercio para PSE</br>
 *  <strong>Numero de Cambios</strong>1</br>
 *  <strong>Identificador corto</strong>C04</br>
 *  
 *  @PCI
 *  <strong>Autor</strong>Efren Lopez Galvis</br>
 *  <strong>Descripcion</strong>Codigos de Homologación RBM</br>
 *  <strong>Numero de Cambios</strong>1</br>
 *  <strong>Identificador corto</strong>C05</br>
 */
public class PaymentsObjectsConverter {



	/**INICIO-C01**/
	private static final String BANK_PPA = "CorePasarela";
	private static final String BANK_PPA_ID = "901";
	private static final String BANK_CHANNEL = "COREPP";
	private static final String USER_CORE_NUM = "0";
	private static final String USER_CORE_TYPE = "0";
	private static final String USER_CORE_LOGIN = "CORE_PASARELA";
	/**FIN-C01**/



	static Logger LOGGER = LoggerFactory.getLogger(PaymentsObjectsConverter.class);

	/**
	 * Convierte de TransactionAddRqType a TransactionBO
	 * @param inn
	 * @return out
	 */
	public static TransactionBO convertTransactionAddRqTypeToTransactionBO(TransactionAddRqType inn){
		CommerceConfigurationBO commerceConfiguration = new CommerceConfigurationBO();
		commerceConfiguration.setUser(PaymentsObjectsConverterUtil.getSecretArgument(SecretListType.USER_KEY, inn.getSecretList()));
		/** INICIO-C03 **/
		commerceConfiguration.setPhrase(PaymentsObjectsConverterUtil.getSecretArgument(SecretListType.WORD_KEY, inn.getSecretList()));
		/** FIN-C03 **/
		commerceConfiguration.setResponseURL(inn.getPortalURL());

		TransactionBO out = new TransactionBO();
		out.setSource(new TransactionSourceBO(inn.getChannel()));
		out.setIpAddress(inn.getIPAddr());

		//INFORMACION DE COMPRADOR
		/*out.setCustomerDocType(inn.getUserId().getCustIdType());
		out.setCustomerDocId(inn.getUserId().getCustIdNum());
		out.setCustomerName(inn.getPersonalData().getCustName().getFirstName());
		out.setMiddleNameBuyer(inn.getPersonalData().getCustName().getMiddleName());
		out.setLastNameBuyer(inn.getPersonalData().getCustName().getLastName());
		out.setSecondLastNameBuyer(inn.getPersonalData().getCustName().getSecondLastName());
		out.setCustomerEmail(inn.getPersonalData().getEmailAddr());
		out.setCustomerMobileNumber(inn.getPersonalData().getPhone());*/

		//INFORMACION DE PAGADOR
		out.setPayerDocType(inn.getUserId().getCustIdType());
		out.setPayerDocId(inn.getUserId().getCustIdNum());
		out.setFirstNamePayer(inn.getPersonalData().getCustName().getFirstName());
		out.setMiddleNamePayer(inn.getPersonalData().getCustName().getMiddleName());
		out.setLastNamePayer(inn.getPersonalData().getCustName().getLastName());
		out.setSecondLastNamePayer(inn.getPersonalData().getCustName().getSecondLastName());
		out.setPayerMail(inn.getPersonalData().getEmailAddr());
		out.setPayerPhone(inn.getPersonalData().getPhone());

		out.setCommerce(new CommerceBO(inn.getAgreementId(),commerceConfiguration));
		out.setUrlResponse(inn.getPortalURL());
		out.setOrderNumber(PaymentsObjectsConverterUtil.getInvoiceReference(inn.getInvoiceReference(), 1));
		out.setDescription(inn.getOrderInfo().getDesc());
		out.setTotalValue(inn.getFee().getAmt());
		out.setCurrency(inn.getFee().getCurCode());
		out.setTaxValue(inn.getTaxFee().getAmt());

		out.setTransactionType(new TransactionTypeBO(inn.getTrnType()));
		out.setTrnType(inn.getTrnType());
		out.setInvoiceReference2(PaymentsObjectsConverterUtil.getInvoiceReference(inn.getInvoiceReference(), 2));
		out.setInvoiceReference3(PaymentsObjectsConverterUtil.getInvoiceReference(inn.getInvoiceReference(), 3));
		out.setInvoiceReference4(PaymentsObjectsConverterUtil.getInvoiceReference(inn.getInvoiceReference(), 4));
		out.setCategoryId(inn.getCategoryId());
		out.setPmtType(inn.getPmtType());
		out.setTrnChannel(inn.getTrnChannel());

		/**
		 * RQ25510 Motor de Riesgo.
		 */
		out.setRqUID(inn.getRqUID());

		//Referencias
		for (ReferenceType ref : inn.getReference()){

			//Referencias 1, 2 y 3
			if(ref.getRefId().equals(CoreConstants.REFERENCE_1))
				out.setReference1(ref.getRefType());
			else if(ref.getRefId().equals(CoreConstants.REFERENCE_2))
				out.setReference2(ref.getRefType());
			else if(ref.getRefId().equals(CoreConstants.REFERENCE_3))
				out.setReference3(ref.getRefType());

			//Referencias de ventanilla de pagos
			else if(ref.getRefId().equals(CoreConstants.VENTANILLA_LOGO))
				out.setLogoURL(ref.getRefType());
			else if(ref.getRefId().equals(CoreConstants.VENTANILLA_PLANTILLA))
				out.setTemplate(ref.getRefType());
			else if(ref.getRefId().equals(CoreConstants.VENTANILLA_TEMA))
				out.setTheme(ref.getRefType());

			//Referencias Banco de Bogota y Manejo de 
			else if(ref.getRefId().equals(CoreConstants.REFERENCE_ID_TYPE_DOC))
				out.setIdTypeDoc(ref.getRefType());
			else if(ref.getRefId().equals(CoreConstants.REFERENCE_NUM_DOC))
				out.setNumDoc(ref.getRefType());
		}

		if (inn.getTRM() != null) {
			out.setTrm(inn.getTRM().getAmt());
			out.setCurCodeTrm(inn.getTRM().getCurCode());
		}
		return out;
	}

	/**
	 * Convierte de TransactionStatusInqRqType a TransactionBO
	 * @param inn
	 * @return out
	 */
	public static TransactionBO convertTransactionAddRqTypeToTransactionBO(TransactionStatusInqRqType inn){
		TransactionBO out = new TransactionBO();
		out.setSource(new TransactionSourceBO(inn.getChannel()));
		out.setIpAddress(inn.getIPAddr());
		out.setCommerce(new CommerceBO(inn.getAgreementId(), null));
		if (inn.getPmtId() != null){
			out.setId(inn.getPmtId());
		}
		return out;
	}

	/**
	 * Convierte de TransactionInqRqType a TransactionBO
	 * @param inn
	 * @return out
	 */
	public static TransactionBO convertTransactionInqRqTypeToTransactionBO(TransactionInqRqType inn){
		TransactionBO out = new TransactionBO();
		out.setSource(new TransactionSourceBO(inn.getChannel()));
		out.setIpAddress(inn.getIPAddr());
		/**INICIO-C01*/
		if (inn.getType() != null) {
			out.setTrnType(inn.getType());
		}
		/**FIN-C01*/
		if (inn.getPmtId() != null) {
			out.setPmtId(inn.getPmtId());
		}
		return out;
	}

	/**
	 * Convierte de RBMPaymentAddRqType a TransactionBO
	 * @param inn
	 * @return out
	 */
	public static TransactionBO convertRBMPaymentAddRqTypeToTransactionBO(RBMPaymentAddRqType inn){
		CreditCardBO creditCard = new CreditCardBO();
		creditCard.setNumber(inn.getCardLogicalData().getCardEmbossNum()); 
		creditCard.setBrand(new BrandBO(inn.getCardLogicalData().getBrand()));
		creditCard.setDueDate(PaymentsObjectsConverterUtil.getDueDate(inn.getCardLogicalData().getExpDt()));
		creditCard.setSecurityCode(inn.getCardLogicalData().getCardVrfyData());

		TransactionBO out = new TransactionBO();
		out.setSource(new TransactionSourceBO(inn.getChannel()));
		out.setIpAddress(inn.getIPAddr());
		out.setCustomerDocType(inn.getUserId().getCustIdType());
		out.setCustomerDocId(inn.getUserId().getCustIdNum());

		/**
		 * RQ25510 Motor de Riesgo.
		 */
		out.setRqUID(inn.getRqUID());

		if (inn.getPmtId() != null) {
			out.setPmtId(inn.getPmtId());
		}

		if(inn.getPersonalData() != null){
			//info comprador
			out.setCustomerName(inn.getPersonalData().get(0).getCustName().getFirstName());
			out.setMiddleNameBuyer(inn.getPersonalData().get(0).getCustName().getMiddleName());
			out.setLastNameBuyer(inn.getPersonalData().get(0).getCustName().getLastName());
			out.setSecondLastNameBuyer(inn.getPersonalData().get(0).getCustName().getSecondLastName());
			out.setCustomerEmail(inn.getPersonalData().get(0).getEmailAddr());
			out.setCustomerMobileNumber(inn.getPersonalData().get(0).getPhone());

			//info pagador
			if(inn.getPersonalData().size() > 1){
				out.setPayerCompany(inn.getPersonalData().get(1).getCustName().getLegalName());
				out.setFirstNamePayer(inn.getPersonalData().get(1).getCustName().getFirstName());
				out.setMiddleNamePayer(inn.getPersonalData().get(1).getCustName().getMiddleName());
				out.setLastNamePayer(inn.getPersonalData().get(1).getCustName().getLastName());
				out.setSecondLastNamePayer(inn.getPersonalData().get(1).getCustName().getSecondLastName());				
				out.setPayerNickName(inn.getPersonalData().get(1).getCustName().getNickName());
				out.setPayerDocType(inn.getPersonalData().get(1).getCustIdType());
				out.setPayerDocId(inn.getPersonalData().get(1).getCustIdNum());
				out.setPayerGender(inn.getPersonalData().get(1).getGender());
				out.setPayerBirthDate(PaymentsObjectsConverterUtil.getBirthDate(inn.getPersonalData().get(1).getBirthDt()));
				out.setPayerCity(inn.getPersonalData().get(1).getCityName());
				out.setPayerDepartment(inn.getPersonalData().get(1).getStateProvName());
				out.setPayerCountry(inn.getPersonalData().get(1).getCountryName());
				out.setPayerAddress(inn.getPersonalData().get(1).getAddress());
				out.setPayerMail(inn.getPersonalData().get(1).getEmailAddr());
				out.setPayerPhone(inn.getPersonalData().get(1).getPhone());
			}
		}

		if (inn.getAgreementInfo() != null){
			CommerceBO commerce = new CommerceBO(inn.getAgreementInfo().getAgreementId(), null);			
			SubscriptionBO subscriptionBO = new SubscriptionBO();
			subscriptionBO.setCompanyName(inn.getAgreementInfo().getName());
			subscriptionBO.setPhone(inn.getAgreementInfo().getPhone());
			commerce.setNit(inn.getAgreementInfo().getNIT());
			commerce.setSubscription(subscriptionBO);
			out.setCommerce(commerce);
		}

		out.setCreditCard(creditCard);
		out.setOrderNumber(inn.getOrderInfo().getOrderId()+"");
		out.setDescription(inn.getOrderInfo().getDesc());
		out.setTotalValue(inn.getFee().getAmt());
		out.setCurrency(inn.getFee().getCurCode());
		out.setTaxValue(inn.getTaxFee().getAmt());
		out.setReference1(PaymentsObjectsConverterUtil.getReference(inn.getReference(), 1));
		out.setReference2(PaymentsObjectsConverterUtil.getReference(inn.getReference(), 2));
		out.setReference3(PaymentsObjectsConverterUtil.getReference(inn.getReference(), 3));

		/*Referencias de Motor de Riesgo*/
		out.setDevicePrint(PaymentsObjectsConverterUtil.getReference(inn.getReference(), CoreConstants.RSA_DEVICE_PRINT));
		out.setDeviceTokenCookie(PaymentsObjectsConverterUtil.getReference(inn.getReference(), CoreConstants.RSA_DEVICE_TOKEN_COOKIE));
		out.setHttpAccept(PaymentsObjectsConverterUtil.getReference(inn.getReference(), CoreConstants.RSA_HTTPACCEPT));
		out.setHttpAcceptLanguage(PaymentsObjectsConverterUtil.getReference(inn.getReference(), CoreConstants.RSA_HTTPACCEPTLANGUAGE));
		out.setHttpReferrer(PaymentsObjectsConverterUtil.getReference(inn.getReference(), CoreConstants.RSA_HTTPREFERRER));
		out.setUserAgent(PaymentsObjectsConverterUtil.getReference(inn.getReference(), CoreConstants.RSA_USERAGENT));
		out.setTermsNConditions(PaymentsObjectsConverterUtil.getReference(inn.getReference(), CoreConstants.RSA_TERMSNCONDITIONS));
		return out;
	}

	/**
	 * Convierte de PSETransactionAddRqType a TransactionBO
	 * @param inn
	 * @return out
	 */
	public static TransactionBO convertPSETransactionAddRqTypeToTransactionBO(PSETransactionAddRqType inn){
		TransactionBO out = new TransactionBO();
		BankBO bankBO = new BankBO();
		bankBO.setAchCode(inn.getBankInfo().getBankId());
		out.setSource(new TransactionSourceBO(inn.getChannel()));
		out.setIpAddress(inn.getIPAddr());
		out.setCustomerDocType(inn.getUserId().getCustIdType());
		out.setCustomerDocId(inn.getUserId().getCustIdNum());

		/**
		 * RQ25510 Motor de Riesgo.
		 */
		out.setRqUID(inn.getRqUID());

		if (inn.getPmtId() != null){
			out.setPmtId(inn.getPmtId());
		}
		// nombre del comprador PSE
		out.setCustomerName(inn.getPersonalData().get(0).getCustName().getFirstName());
		if(inn.getPersonalData() != null){
			//info comprador PSE
			out.setMiddleNameBuyer(inn.getPersonalData().get(0).getCustName().getMiddleName());
			out.setLastNameBuyer(inn.getPersonalData().get(0).getCustName().getLastName());
			out.setSecondLastNameBuyer(inn.getPersonalData().get(0).getCustName().getSecondLastName());
			out.setCustomerEmail(inn.getPersonalData().get(0).getEmailAddr());
			out.setCustomerMobileNumber(inn.getPersonalData().get(0).getPhone());

			//info pagador PSE
			out.setPayerCompany(inn.getPersonalData().get(1).getCustName().getLegalName());
			out.setFirstNamePayer(inn.getPersonalData().get(1).getCustName().getFirstName());
			out.setMiddleNamePayer(inn.getPersonalData().get(1).getCustName().getMiddleName());
			out.setLastNamePayer(inn.getPersonalData().get(1).getCustName().getLastName());
			out.setSecondLastNamePayer(inn.getPersonalData().get(1).getCustName().getSecondLastName());
			out.setPayerNickName(inn.getPersonalData().get(1).getCustName().getNickName());
			out.setPayerDocType(inn.getPersonalData().get(1).getCustIdType());
			out.setPayerDocId(inn.getPersonalData().get(1).getCustIdNum());
			out.setPayerGender(inn.getPersonalData().get(1).getGender());
			out.setPayerBirthDate(PaymentsObjectsConverterUtil.getBirthDate(inn.getPersonalData().get(1).getBirthDt()));
			out.setPayerCity(inn.getPersonalData().get(1).getCityName());
			out.setPayerDepartment(inn.getPersonalData().get(1).getStateProvName());
			out.setPayerCountry(inn.getPersonalData().get(1).getCountryName());
			out.setPayerAddress(inn.getPersonalData().get(1).getAddress());
			out.setPayerMail(inn.getPersonalData().get(1).getEmailAddr());
			out.setPayerPhone(inn.getPersonalData().get(1).getPhone());
		}
		out.setCustomerType(Integer.valueOf(inn.getUserType()));        
		out.setCommerce(new CommerceBO(inn.getAgreementInfo().getAgreementId(), null));
		out.setBank(bankBO);
		out.setOrderNumber(inn.getOrderInfo().getOrderId()+"");
		out.setDescription(inn.getOrderInfo().getDesc());
		out.setTotalValue(inn.getFee().getAmt());
		out.setCurrency(inn.getFee().getCurCode());
		out.setTaxValue(inn.getTaxFee().getAmt());
		out.setReference1(PaymentsObjectsConverterUtil.getReference(inn.getReference(), 1));
		out.setReference2(PaymentsObjectsConverterUtil.getReference(inn.getReference(), 2));
		out.setReference3(PaymentsObjectsConverterUtil.getReference(inn.getReference(), 3));

		/*Referencias de Motor de Riesgo*/
		out.setDevicePrint(PaymentsObjectsConverterUtil.getReference(inn.getReference(), CoreConstants.RSA_DEVICE_PRINT));
		out.setDeviceTokenCookie(PaymentsObjectsConverterUtil.getReference(inn.getReference(), CoreConstants.RSA_DEVICE_TOKEN_COOKIE));
		out.setHttpAccept(PaymentsObjectsConverterUtil.getReference(inn.getReference(), CoreConstants.RSA_HTTPACCEPT));
		out.setHttpAcceptLanguage(PaymentsObjectsConverterUtil.getReference(inn.getReference(), CoreConstants.RSA_HTTPACCEPTLANGUAGE));
		out.setHttpReferrer(PaymentsObjectsConverterUtil.getReference(inn.getReference(), CoreConstants.RSA_HTTPREFERRER));
		out.setUserAgent(PaymentsObjectsConverterUtil.getReference(inn.getReference(), CoreConstants.RSA_USERAGENT));
		out.setTermsNConditions(PaymentsObjectsConverterUtil.getReference(inn.getReference(), CoreConstants.RSA_TERMSNCONDITIONS));

		/**
		 * INICIO C04
		 */
		out.setReturnURL(PaymentsObjectsConverterUtil.getReference(inn.getReference(), CoreConstants.RETURN_URL));
		/**
		 * FIN C04
		 */

		return out;
	}

	/**
	 * Convierte de AVALPaymentAddRqType a TransactionBO
	 * @param inn
	 * @return out
	 */
	public static TransactionBO convertAVALPaymentAddRqTypeToTransactionBO(AVALPaymentAddRqType inn){
		TransactionBO out = new TransactionBO();
		out.setSource(new TransactionSourceBO(inn.getChannel()));
		out.setIpAddress(inn.getIPAddr());
		out.setCustomerDocType(inn.getUserId().getCustIdType());
		out.setCustomerDocId(inn.getUserId().getCustIdNum());

		/**
		 * RQ25510 Motor de Riesgo.
		 */
		out.setRqUID(inn.getRqUID());

		if (inn.getPmtId() != null) {
			out.setPmtId(inn.getPmtId());
		}

		out.setCustomerName(inn.getPersonalData().get(0).getCustName().getFirstName());
		if(inn.getPersonalData() != null){
			List<PersonalDataType> lstPdt = new ArrayList<PersonalDataType>();
			lstPdt = inn.getPersonalData();
			//info comprador AVAL
			out.setMiddleNameBuyer(inn.getPersonalData().get(0).getCustName().getMiddleName());
			out.setLastNameBuyer(inn.getPersonalData().get(0).getCustName().getLastName());
			out.setSecondLastNameBuyer(inn.getPersonalData().get(0).getCustName().getSecondLastName());
			out.setCustomerEmail(lstPdt.get(0).getEmailAddr());
			out.setCustomerMobileNumber(lstPdt.get(0).getPhone());

			//info pagador AVAL
			out.setPayerCompany(lstPdt.get(1).getCustName().getLegalName());
			out.setFirstNamePayer(inn.getPersonalData().get(1).getCustName().getFirstName());
			out.setMiddleNamePayer(inn.getPersonalData().get(1).getCustName().getMiddleName());
			out.setLastNamePayer(inn.getPersonalData().get(1).getCustName().getLastName());
			out.setSecondLastNamePayer(inn.getPersonalData().get(1).getCustName().getSecondLastName());
			out.setPayerNickName(lstPdt.get(1).getCustName().getNickName());
			out.setPayerDocType(lstPdt.get(1).getCustIdType());
			out.setPayerDocId(lstPdt.get(1).getCustIdNum());
			out.setPayerGender(lstPdt.get(1).getGender());
			out.setPayerBirthDate(PaymentsObjectsConverterUtil.getBirthDate(inn.getPersonalData().get(1).getBirthDt()));
			out.setPayerCity(lstPdt.get(1).getCityName());
			out.setPayerDepartment(lstPdt.get(1).getStateProvName());
			out.setPayerCountry(lstPdt.get(1).getCountryName());
			out.setPayerAddress(lstPdt.get(1).getAddress());
			out.setPayerMail(lstPdt.get(1).getEmailAddr());
			out.setPayerPhone(lstPdt.get(1).getPhone());
		}

		//		if(inn.getPersonalData().size() == 2) {
		//			//Datos del comprador/Beneficiario
		//			personalDataBuyer = inn.getPersonalData().get(0);
		//			
		//			//Datos del Pagador
		//			personalDataPayer = inn.getPersonalData().get(1);
		//		}
		//		
		//		//out.setCustomerName(PaymentsObjectsConverterUtil.getCustomerName(inn.getPersonalData()));
		//		out.setCustomerName(PaymentsObjectsConverterUtil.getCustomerName(personalDataBuyer));
		//		if(personalDataBuyer != null){
		//			out.setCustomerEmail(personalDataBuyer.getEmailAddr());
		//			out.setCustomerMobileNumber(personalDataBuyer.getPhone());
		//			out.setCustomerName(personalDataBuyer.getCustName().getFirstName() + " " + 
		//			personalDataBuyer.getCustName().getMiddleName() + " " +
		//					personalDataBuyer.getCustName().getLastName());
		//		}

		out.setCommerce(new CommerceBO(inn.getAgreementInfo().getAgreementId(), null));        
		out.setBank(new BankBO(inn.getBankInfo().getBankId()));
		out.setOrderNumber(inn.getOrderInfo().getOrderId()+"");
		out.setDescription(inn.getOrderInfo().getDesc());
		out.setTotalValue(inn.getFee().getAmt());
		out.setCurrency(inn.getFee().getCurCode());
		out.setTaxValue(inn.getTaxFee().getAmt());
		out.setReference1(PaymentsObjectsConverterUtil.getReference(inn.getReference(), 1));
		out.setReference2(PaymentsObjectsConverterUtil.getReference(inn.getReference(), 2));
		out.setReference3(PaymentsObjectsConverterUtil.getReference(inn.getReference(), 3));

		/*Referencias de Motor de Riesgo*/
		out.setDevicePrint(PaymentsObjectsConverterUtil.getReference(inn.getReference(), CoreConstants.RSA_DEVICE_PRINT));
		out.setDeviceTokenCookie(PaymentsObjectsConverterUtil.getReference(inn.getReference(), CoreConstants.RSA_DEVICE_TOKEN_COOKIE));
		out.setHttpAccept(PaymentsObjectsConverterUtil.getReference(inn.getReference(), CoreConstants.RSA_HTTPACCEPT));
		out.setHttpAcceptLanguage(PaymentsObjectsConverterUtil.getReference(inn.getReference(), CoreConstants.RSA_HTTPACCEPTLANGUAGE));
		out.setHttpReferrer(PaymentsObjectsConverterUtil.getReference(inn.getReference(), CoreConstants.RSA_HTTPREFERRER));
		out.setUserAgent(PaymentsObjectsConverterUtil.getReference(inn.getReference(), CoreConstants.RSA_USERAGENT));
		out.setTermsNConditions(PaymentsObjectsConverterUtil.getReference(inn.getReference(), CoreConstants.RSA_TERMSNCONDITIONS));


		return out;
	}

	/**
	 * Convierte de TransactionStatusInqRqType a TransactionBO
	 * @param inn
	 * @return out
	 */
	public static TransactionBO convertTransactionStatusInqRqTypeToTransactionBO(TransactionStatusInqRqType inn){
		TransactionBO out = new TransactionBO();
		out.setSource(new TransactionSourceBO(inn.getChannel()));
		out.setIpAddress(inn.getIPAddr());
		out.setCommerce(new CommerceBO(inn.getAgreementId(), null));
		if (inn.getPmtId() != null) {
			out.setPmtId(inn.getPmtId());
		}
		return out;
	}

	/**
	 * Convierte de TransactionStatusModRqType a TransactionBO
	 * @param inn
	 * @return out
	 */
	public static TransactionBO convertTransactionStatusModRqTypeToTransactionBO(TransactionStatusModRqType inn){
		TransactionStatusBO transactionStatus = new TransactionStatusBO();
		transactionStatus.setCode(inn.getTransactionStatus().getTrnStatusCode());
		transactionStatus.setDescription(inn.getTransactionStatus().getTrnStatusDesc());
		TransactionBO out = new TransactionBO();
		if (inn.getPmtId() != null) {
			out.setId(inn.getPmtId());
		}
		out.setSource(new TransactionSourceBO(inn.getChannel()));
		out.setIpAddress(inn.getIPAddr());
		out.setStatus(transactionStatus);
		out.setPayDate(DateUtil.toDate(inn.getTransactionStatus().getEffDt()));
		out.setCompensationDate(DateUtil.toDate(inn.getTransactionStatus().getCompensationDt()));
		out.setApprovalNumber(inn.getTransactionStatus().getApprovalId());
		return out;
	}

	/**
	 * Convierte de TransactionInfoModRqType a TransactionBO
	 * @param inn
	 * @return out
	 */
	public static TransactionBO convertTransactionInfoModRqTypeToTransactionBO(TransactionInfoModRqType inn){
		CreditCardBO creditCard = new CreditCardBO();
		if(inn.getCardLogicalData() != null){
			creditCard.setNumber(inn.getCardLogicalData().getCardEmbossNum());
			creditCard.setBrand(new BrandBO(inn.getCardLogicalData().getBrand()));
			creditCard.setDueDate(PaymentsObjectsConverterUtil.getDueDate(inn.getCardLogicalData().getExpDt()));
			if(inn.getCardLogicalData().getCardVrfyData() != null){
				creditCard.setSecurityCode(inn.getCardLogicalData().getCardVrfyData());
			}
		}
		TransactionStatusBO transactionStatus = new TransactionStatusBO();
		transactionStatus.setCode(inn.getTransactionStatus().getTrnStatusCode());
		transactionStatus.setDescription(inn.getTransactionStatus().getTrnStatusDesc());
		TransactionBO out = new TransactionBO();
		out.setSource(new TransactionSourceBO(inn.getChannel()));
		out.setIpAddress(inn.getIPAddr());
		if (inn.getPmtId() != null) {
			out.setPmtId(inn.getPmtId());
		}
		if(inn.getPersonalData() != null){
			out.setCustomerName(PaymentsObjectsConverterUtil.getCustomerName(inn.getPersonalData()));
			out.setCustomerEmail(inn.getPersonalData().getEmailAddr());
			out.setCustomerMobileNumber(inn.getPersonalData().getPhone());
		}
		out.setPaymentWay(new PaymentWayBO(PaymentsObjectsConverterUtil.getLongValue(inn.getPmtWayId())));
		out.setBank(new BankBO(PaymentsObjectsConverterUtil.getLongValue(inn.getBankId())));
		out.setProductType(new ProductTypeBO(PaymentsObjectsConverterUtil.getLongValue(inn.getProductType())));
		out.setCreditCard(creditCard);
		out.setStatus(transactionStatus);
		out.setPayDate(DateUtil.toDate(inn.getTransactionStatus().getEffDt()));
		out.setCompensationDate(DateUtil.toDate(inn.getTransactionStatus().getCompensationDt()));
		out.setApprovalNumber(inn.getTransactionStatus().getApprovalId());
		return out;
	}

	/**
	 * Convierte de TransactionAddRqTyp a AddTransactionInDTO
	 * @param inn
	 * @return out
	 */
	public static AddTransactionInDTO toAddTransactionInDTO(TransactionAddRqType inn){
		AddTransactionInDTO out = new AddTransactionInDTO();
		out.setClientDt(DateUtil.toDate(inn.getClientDt()));
		out.setIpAddr(inn.getIPAddr());
		out.setRqUID(inn.getRqUID());
		out.setTransactionBO(convertTransactionAddRqTypeToTransactionBO(inn));
		/** INI-C03 */
		for(ReferenceType refType: inn.getReference()) {
			if(refType.getRefId().equals(CoreConstants.PMTID_K7))
				out.getTransactionBO().setPmtId(refType.getRefType());
		}
		/** FIN-C03 */	
		return out;
	}

	/**
	 * Convierte de AddTransactionOutDTO a TransactionAddRsType
	 * @param inn
	 * @return
	 */
	public static TransactionAddRsType toTransactionAddRsType(AddTransactionOutDTO inn) {
		TransactionStatusType transactionStatus = new TransactionStatusType();
		transactionStatus.setTrnStatusCode(inn.getTrnStatusCode());
		transactionStatus.setTrnStatusDesc(inn.getTrnStatusDesc());
		transactionStatus.setTrnServerStatusCode(inn.getTrnServerStatusCode());
		transactionStatus.setTrnServerStatusDesc(inn.getTrnServerStatusDesc());
		transactionStatus.setEffDt(DateUtil.toXMLGregorianCalendar(inn.getEffDt()));
		transactionStatus.setCompensationDt(DateUtil.toXMLGregorianCalendar(inn.getCompensationDt()));
		transactionStatus.setApprovalId(inn.getApprovalId());
		OrderInfoType orderInfo = new OrderInfoType();
		orderInfo.setOrderId(inn.getOrderId());
		orderInfo.setDesc(inn.getOrderDesc());
		TransactionAddRsType out = new TransactionAddRsType();
		out.setRqUID(inn.getRqUID());
		out.setStatusCode(inn.getStatusCode());
		out.setStatusDesc(inn.getStatusDesc());
		out.setTransactionStatus(transactionStatus);
		if (inn.getPmtId() != null) {
			out.setPmtId(inn.getPmtId().toString());
		}
		out.setPortalURL(inn.getPortalURL());
		out.setOrderInfo(orderInfo); 
		return out;
	}

	/**
	 * Convierte de AddTransactionOutDTO a TransactionAddRsTypeError
	 * @param inn
	 * @return
	 */
	public static TransactionAddRsType toTransactionAddRsTypeError(TransactionAddRqType inn, Exception ex){
		TransactionStatusType ts = new TransactionStatusType();
		OrderInfoType ot = new OrderInfoType();
		ts.setTrnStatusCode(Long.valueOf(CoreConstants.ERROR_STATUS_CODE_300));
		ts.setTrnStatusDesc(CoreConstants.ERROR_STATUS_CODE_DESC);
		ts.setTrnServerStatusCode(CoreConstants.ERROR_STATUS_CODE_300.toString());
		ts.setTrnServerStatusDesc(ex.toString());
		ot.setOrderId("0");
		ot.setDesc("ERROR");

		TransactionAddRsType out = new TransactionAddRsType();
		out.setStatusCode(CoreConstants.ERROR_STATUS_CODE_300);
		out.setStatusDesc(CoreConstants.ERROR_STATUS_CODE_DESC);
		out.setRqUID(inn.getRqUID());
		out.setTransactionStatus(ts);
		out.setOrderInfo(ot);
		return out;
	}
	
	/**
	 * Convierte de AddTransactionOutDTO a TransactionAddRsTypeError
	 * @param inn
	 * @return
	 */
	public static TransactionAddRsType toTransactionAddRsTypeErrorGeneric(TransactionAddRqType inn){
		TransactionStatusType ts = new TransactionStatusType();
		OrderInfoType ot = new OrderInfoType();
		ts.setTrnStatusCode(Long.valueOf(CoreConstants.ERROR_STATUS_CODE_300));
		ts.setTrnStatusDesc(CoreConstants.ERROR_STATUS_CODE_DESC);
		ts.setTrnServerStatusCode(CoreConstants.ERROR_STATUS_CODE_300.toString());
		ts.setTrnServerStatusDesc(CoreConstants.ERROR_GENERIC_DESC);
		ot.setOrderId("0");
		ot.setDesc("ERROR");

		TransactionAddRsType out = new TransactionAddRsType();
		out.setStatusCode(CoreConstants.ERROR_STATUS_CODE_300);
		out.setStatusDesc(CoreConstants.ERROR_STATUS_CODE_DESC);
		out.setRqUID(inn.getRqUID());
		out.setTransactionStatus(ts);
		out.setOrderInfo(ot);
		return out;
	}

	/**
	 * Convierte de TransactionStatusInqRqType a GetTransactionInDTO
	 * @param inn
	 * @return
	 */
	public static GetTransactionInDTO convertTransactionStatusInqRqTypeToGetTransactionInDTO(TransactionStatusInqRqType inn) {
		GetTransactionInDTO out = new GetTransactionInDTO();
		out.setClientDt(DateUtil.toDate(inn.getClientDt()));
		out.setIpAddr(inn.getIPAddr());
		out.setRqUID(inn.getRqUID());
		out.setTransactionBO(convertTransactionStatusInqRqTypeToTransactionBO(inn));
		return out;
	}

	/**
	 * Convierte de GetTransactionOutDTO a TransactionStatusInqRsType
	 * @param inn
	 * @return
	 */
	public static TransactionStatusInqRsType convertGetTransactionOutDTOToTransactionStatusInqRsType(GetTransactionOutDTO inn) {
		TransactionStatusType transactionStatus = new TransactionStatusType();
		transactionStatus.setTrnStatusCode(inn.getTrnStatusCode());
		transactionStatus.setTrnStatusDesc(inn.getTrnStatusDesc());
		transactionStatus.setTrnServerStatusCode(inn.getTrnServerStatusCode());
		transactionStatus.setTrnServerStatusDesc(inn.getTrnServerStatusDesc());
		transactionStatus.setEffDt(DateUtil.toXMLGregorianCalendar(inn.getEffDt()));
		transactionStatus.setCompensationDt(DateUtil.toXMLGregorianCalendar(inn.getCompensationDt()));
		transactionStatus.setApprovalId(inn.getApprovalId());
		TransactionStatusInqRsType out = new TransactionStatusInqRsType();
		out.setPmtId(inn.getPmtId()+"");
		out.setStatusCode(inn.getStatusCode());
		out.setStatusDesc(inn.getStatusDesc());
		out.setTransactionStatus(transactionStatus);
		out.setRqUID(inn.getRqUID());
		return out;
	}

	/**
	 * Convierte de AVALPaymentAddRqType a AddAVALPaymentInDTO
	 * @param inn
	 * @return
	 */
	public static AddAVALPaymentInDTO convertAVALPaymentAddRqTypeToAddAVALPaymentInDTO(AVALPaymentAddRqType inn){
		AddAVALPaymentInDTO out = new AddAVALPaymentInDTO();
		out.setClientDt(DateUtil.toDate(inn.getClientDt()));
		out.setIpAddr(inn.getIPAddr());
		out.setRqUID(inn.getRqUID());
		out.setTransactionBO(convertAVALPaymentAddRqTypeToTransactionBO(inn));
		return out;
	}

	/**
	 * Convierte de AddAVALPaymentOutDTO a AVALPaymentAddRsType
	 * @param inn
	 * @return
	 */
	public static AVALPaymentAddRsType convertAddAVALPaymentOutDTOToAVALPaymentAddRsType(AddAVALPaymentOutDTO inn) {
		TransactionStatusType transactionStatus = new TransactionStatusType();
		transactionStatus.setTrnStatusCode(inn.getTrnStatusCode());
		transactionStatus.setTrnStatusDesc(inn.getTrnStatusDesc());
		transactionStatus.setTrnServerStatusCode(inn.getTrnServerStatusCode());
		transactionStatus.setTrnServerStatusDesc(inn.getTrnServerStatusDesc());
		transactionStatus.setEffDt(DateUtil.toXMLGregorianCalendar(inn.getEffDt()));
		transactionStatus.setCompensationDt(DateUtil.toXMLGregorianCalendar(inn.getCompensationDate()));
		transactionStatus.setApprovalId(inn.getApprovalId());
		AVALPaymentAddRsType out = new AVALPaymentAddRsType();
		out.setPmtId(inn.getPmtId());
		out.setRqUID(inn.getRqUID());
		out.setStatusCode(inn.getStatusCode());
		out.setStatusDesc(inn.getStatusDesc());
		out.setTransactionStatus(transactionStatus);

		/**INICIO-C01*/
		if(inn.getToken() != null) {
			out.setToken(inn.getToken());
		}
		/**FIN-C01*/

		return out;
	}

	public static AVALPaymentAddRsType convertAddAVALPaymentOutDTOToAVALPaymentAddRsTypeError(AVALPaymentAddRqType inn, Exception ex) {
		AVALPaymentAddRsType out = new AVALPaymentAddRsType();
		TransactionStatusType transactionStatusType = new TransactionStatusType();
		transactionStatusType.setTrnServerStatusCode(String.valueOf(CoreConstants.ERROR_STATUS_CODE_300));
		transactionStatusType.setTrnServerStatusDesc(ex.toString());
		out.setStatusCode(CoreConstants.ERROR_STATUS_CODE_300);
		out.setStatusDesc(CoreConstants.ERROR_STATUS_CODE_DESC);
		out.setRqUID(inn.getRqUID());
		out.setPmtId("0");
		out.setTransactionStatus(transactionStatusType);
		return out;
	}

	/**
	 * Convierte de PSETransactionAddRqType a AddPSETransactionInDTO
	 * @param inn
	 * @return
	 */
	public static AddPSETransactionInDTO convertPSETransactionAddRqTypeToAddPSETransactionInDTO(PSETransactionAddRqType inn) {
		AddPSETransactionInDTO out = new AddPSETransactionInDTO();
		out.setClientDt(DateUtil.toDate(inn.getClientDt()));
		out.setIpAddr(inn.getIPAddr());
		out.setRqUID(inn.getRqUID());
		out.setTransactionBO(convertPSETransactionAddRqTypeToTransactionBO(inn));
		return out;
	}

	/**
	 * Convierte de AddPSETransactionOutDTO a PSETransactionAddRsType
	 * @param inn
	 * @return
	 */
	public static PSETransactionAddRsType convertAddPSETransactionOutDTOToPSETransactionAddRsType(AddPSETransactionOutDTO inn){
		TransactionStatusType transactionStatus = new TransactionStatusType();
		transactionStatus.setTrnStatusCode(inn.getTrnStatusCode());
		transactionStatus.setTrnStatusDesc(inn.getTrnStatusDesc());
		transactionStatus.setTrnServerStatusCode(inn.getTrnServerStatusCode());
		transactionStatus.setTrnServerStatusDesc(inn.getTrnServerStatusDesc());
		transactionStatus.setEffDt(DateUtil.toXMLGregorianCalendar(inn.getEffDt()));
		transactionStatus.setCompensationDt(DateUtil.toXMLGregorianCalendar(inn.getCompensationDate()));
		transactionStatus.setApprovalId(inn.getApprovalId());
		PSETransactionAddRsType out = new PSETransactionAddRsType();
		out.setStatusCode(inn.getStatusCode());
		out.setStatusDesc(inn.getStatusDesc());
		out.setRqUID(inn.getRqUID());
		out.setTransactionStatus(transactionStatus); 
		out.setTrazabilityCode(inn.getTrazabilityCode());

		/**INICIO-C02*/
		if(inn.getToken() != null) {
			out.setToken(inn.getToken());
		}
		/**FIN-C02*/

		if(inn.getPortalURL() != null) {
			out.setPortalURL(inn.getPortalURL());
		}
		return out;
	}	

	/**
	 * Convierte de AddPSETransactionOutDTO a PSETransactionAddRsType
	 * @param inn
	 * @return
	 */
	public static PSETransactionAddRsType convertAddPSETransactionOutDTOToPSETransactionAddRsTypeError(PSETransactionAddRqType inn, Exception ex) {
		TransactionStatusType transactionStatusType = new TransactionStatusType();
		transactionStatusType.setTrnStatusCode(Long.valueOf(CoreConstants.ERROR_STATUS_CODE_300));
		transactionStatusType.setTrnStatusDesc(CoreConstants.ERROR_STATUS_CODE_DESC);		
		transactionStatusType.setTrnServerStatusCode(CoreConstants.ERROR_STATUS_CODE_300.toString());
		transactionStatusType.setTrnServerStatusDesc(ex.toString());
		PSETransactionAddRsType out = new PSETransactionAddRsType();
		out.setStatusCode(CoreConstants.ERROR_STATUS_CODE_300);
		out.setStatusDesc(CoreConstants.ERROR_STATUS_CODE_DESC);
		out.setRqUID(inn.getRqUID());
		out.setTransactionStatus(transactionStatusType);
		return out;
	}

	/**
	 * Convierte de RBMPaymentAddRqType a AddRBMPaymentInDTO
	 * @param inn
	 * @return
	 */
	public static AddRBMPaymentInDTO convertRBMPaymentAddRqTypeToAddRBMPaymentInDTO(RBMPaymentAddRqType inn) {
		AddRBMPaymentInDTO out = new AddRBMPaymentInDTO();
		out.setClientDt(DateUtil.toDate(inn.getClientDt()));
		out.setIpAddr(inn.getIPAddr());
		out.setRqUID(Math.abs(inn.getRqUID()));
		out.setInstalamentsNum(inn.getInstalamentsNum());
		out.setExpDate(DateUtil.toDate(inn.getCardLogicalData().getExpDt()));
		out.setTransactionBO(convertRBMPaymentAddRqTypeToTransactionBO(inn));
		return out;
	}

	/**
	 * Convierte de AddRBMPaymentOutDTO a RBMPaymentAddRsType
	 * @param inn
	 * @return
	 */
	public static RBMPaymentAddRsType convertAddRBMPaymentOutDTOToRBMPaymentAddRsType(AddRBMPaymentOutDTO inn) {
		TransactionStatusType transactionStatus = new TransactionStatusType();
		transactionStatus.setTrnStatusCode(inn.getTrnStatusCode());
		transactionStatus.setTrnStatusDesc(inn.getTrnStatusDesc());
		transactionStatus.setTrnServerStatusCode(inn.getTrnServerStatusCode());
		transactionStatus.setTrnServerStatusDesc(inn.getTrnServerStatusDesc());
		transactionStatus.setEffDt(DateUtil.toXMLGregorianCalendar(inn.getEffDt()));
		transactionStatus.setCompensationDt(DateUtil.toXMLGregorianCalendar(inn.getCompensationDate()));
		transactionStatus.setApprovalId(inn.getApprovalId());
		RBMPaymentAddRsType out = new RBMPaymentAddRsType();
		out.setStatusCode(inn.getStatusCode());
		out.setStatusDesc(inn.getStatusDesc());
		out.setRqUID(inn.getRqUID());
		out.setPmtId(inn.getPmtId());        
		out.setTransactionStatus(transactionStatus);

		/**INICIO-C02*/
		if(inn.getToken() != null) {
			out.setToken(inn.getToken());
		}
		/**FIN-C02*/

		return out;
	}

	/**
	 * Convierte de TransactionInqRqType a GetTransactionByIdInDTO
	 * @param inn
	 * @return
	 */
	public static GetTransactionByIdInDTO convertTransactionInqRqTypeToGetTransactionByIdInDTO(TransactionInqRqType inn) {
		GetTransactionByIdInDTO out = new GetTransactionByIdInDTO();
		out.setClientDt(DateUtil.toDate(inn.getClientDt()));
		out.setIpAddr(inn.getIPAddr());
		out.setRqUID(inn.getRqUID());
		out.setTransactionBO(convertTransactionInqRqTypeToTransactionBO(inn)); 
		/**INICIO C01**/
		out.setChannel(inn.getChannel());
		/**INICIO C01**/
		return out;
	}

	/**
	 * Convierte de TransactionInqRqType a GetTransactionByTokenInDTO
	 * @param inn
	 * @return
	 */
	public static GetTransactionByTokenInDTO convertTransactionInqRqTypeToGetTransactionByTokenInDTO(TransactionInqRqType inn) {
		GetTransactionByTokenInDTO out = new GetTransactionByTokenInDTO();
		out.setClientDt(DateUtil.toDate(inn.getClientDt()));
		out.setIpAddr(inn.getIPAddr());
		out.setRqUID(inn.getRqUID());
		out.setQueryType(inn.getType());
		out.setTokenBO(convertTransactionInqRqTypeToTokenBO(inn));
		return out;
	}

	/**
	 * Convierte de TransactionInqRqType a TokenBO
	 * @param inn
	 * @return
	 */
	public static TokenBO convertTransactionInqRqTypeToTokenBO(TransactionInqRqType inn) {
		TokenBO tokenBO = new TokenBO();
		tokenBO.setId(inn.getToken());
		tokenBO.setTransaction(new TransactionBO(new TransactionSourceBO(inn.getChannel())));
		return tokenBO;
	}

	/**
	 * Convierte de TransactionStatusInqRqType a GetTransactionStatusInDTO
	 * @param inn
	 * @return
	 */
	public static GetTransactionStatusInDTO convertTransactionStatusInqRqTypeToGetTransactionStatusInDTO(TransactionStatusInqRqType inn) {
		GetTransactionStatusInDTO out = new GetTransactionStatusInDTO();
		out.setClientDt(DateUtil.toDate(inn.getClientDt()));
		out.setIpAddr(inn.getIPAddr());
		out.setRqUID(inn.getRqUID());
		out.setTransactionBO(convertTransactionStatusInqRqTypeToTransactionBO(inn)); 
		return out;
	}

	/**
	 * Convierte de GetTransactionByIdOutDTO a TransactionInqRsType
	 * @param inn
	 * @return
	 */
	public static TransactionInqRsType convertGetTransactionByIdOutDTOToTransactionInqRsType(GetTransactionByIdOutDTO inn) {
		List<PmtWayType> pmtWayTypeList = new ArrayList<PmtWayType>();
		PmtWayType pmtWayType = new PmtWayType();

		pmtWayType.setPmtWayId(inn.getPmtWayId());
		pmtWayType.setPmtWayType(inn.getPmtWayType());
		pmtWayTypeList.add(pmtWayType);

		TransactionStatusType transactionStatus = new TransactionStatusType();
		transactionStatus.setTrnStatusCode(inn.getTrnStatusCode());
		transactionStatus.setTrnStatusDesc(inn.getTrnStatusDesc());
		transactionStatus.setTrnServerStatusCode(inn.getTrnServerStatusCode());
		transactionStatus.setTrnServerStatusDesc(inn.getTrnServerStatusDesc());
		transactionStatus.setEffDt(DateUtil.toXMLGregorianCalendar(inn.getEffDt()));
		transactionStatus.setCompensationDt(DateUtil.toXMLGregorianCalendar(inn.getCompensationDate()));
		transactionStatus.setApprovalId(inn.getApprovalId());
		UserIdType userIdType = new UserIdType();
		userIdType.setCustIdType(inn.getCustomerDocType());
		userIdType.setCustIdNum(inn.getCustomerDocId());

		TransactionInqRsType out = new TransactionInqRsType();
		out.setStatusCode(inn.getStatusCode());
		out.setStatusDesc(inn.getStatusDesc());
		out.setRqUID(inn.getRqUID());
		out.setTransactionStatus(transactionStatus);
		out.setPersonalData(convertGetTransactionByIdOutDTOToPersonalDataType(inn));
		out.setAgreementInfo(convertGetTransactionByIdOutDTOOToAgreementInfoType(inn));
		out.setPmtId(inn.getPmtId());
		out.setPmtWay(pmtWayTypeList);
		out.setOrderInfo(convertGetTransactionByIdOutDTOToOrderInfoType(inn));
		out.setFee(convertGetTransactionByIdOutDTOToFeeType(inn));
		out.setTaxFee(convertGetTransactionByIdOutDTOTokenOutDTOToTaxFeeType(inn));
		out.setReference(convertReferenceStringListToReferenceTypeList(inn.getReferenceMap()));
		//out.setTrnType(inn.getTrnType());
		out.setInvoiceReference(convertInvoiceReferenceStringListToInvoiceReferenceTypeList(inn.getInvoiceReferenceMap()));
		out.setPortalURL(inn.getPortalURL());
		out.setUserId(userIdType);
		out.setCategoryId(inn.getCategoryId());
		out.setPmtType(inn.getPmtType());
		out.setTrnChannel(inn.getTrnChannel());
		out.setTRM(convertGetTransactionByIdOutDTOToTrmType(inn));
		return out;
	}

	public static TransactionInqRsType convertGetTransactionByIdOutDTOToTransactionInqRsTypeError(TransactionInqRqType inn, Exception ex) {
		List<PmtWayType> pmtWayTypeList = new ArrayList<PmtWayType>();
		PmtWayType pmtWayType = new PmtWayType();

		pmtWayType.setPmtWayId("0");
		pmtWayType.setPmtWayType("ERROR");
		pmtWayTypeList.add(pmtWayType);

		TransactionInqRsType transactionInqRsType = new TransactionInqRsType();
		TransactionStatusType transactionStatusType = new TransactionStatusType();
		OrderInfoType orderInfoType = new OrderInfoType();
		CommerceSettingType commerceSettingType = new CommerceSettingType();

		transactionStatusType.setTrnServerStatusCode(String.valueOf(CoreConstants.ERROR_STATUS_CODE_300));
		transactionStatusType.setTrnServerStatusDesc(ex.toString());

		orderInfoType.setOrderId("0");
		orderInfoType.setDesc("ERROR");
		FeeType ft = new FeeType();
		ft.setAmt(BigDecimal.ZERO);
		TaxFeeType tf = new TaxFeeType();
		tf.setAmt(BigDecimal.ZERO);

		commerceSettingType.setLogoURL("http://ERROR");
		commerceSettingType.setTemplate("ERROR");
		commerceSettingType.setTheme("ERROR");

		transactionInqRsType.setStatusCode(CoreConstants.ERROR_STATUS_CODE_300);
		transactionInqRsType.setStatusDesc(CoreConstants.ERROR_STATUS_CODE_DESC);
		transactionInqRsType.setRqUID(inn.getRqUID());
		transactionInqRsType.setPmtWay(pmtWayTypeList);
		transactionInqRsType.setTransactionStatus(transactionStatusType);
		transactionInqRsType.setOrderInfo(orderInfoType);
		transactionInqRsType.setFee(ft);
		transactionInqRsType.setTaxFee(tf);
		transactionInqRsType.setCommerceSetting(commerceSettingType);
		transactionInqRsType.setPortalURL("http://ERROR");
		return transactionInqRsType;
	}

	/**
	 * Convierte de GetTransactionByTokenOutDTO a TransactionInqRsType
	 * @param inn
	 * @return
	 */
	public static TransactionInqRsType convertGetTransactionByTokenOutDTOToTransactionInqRsType(GetTransactionByTokenOutDTO inn) {
		TransactionStatusType transactionStatus = new TransactionStatusType();
		transactionStatus.setTrnStatusCode(inn.getTrnStatusCode());
		transactionStatus.setTrnStatusDesc(inn.getTrnStatusDesc());
		transactionStatus.setTrnServerStatusCode(inn.getTrnServerStatusCode());
		transactionStatus.setTrnServerStatusDesc(inn.getTrnServerStatusDesc());
		transactionStatus.setEffDt(DateUtil.toXMLGregorianCalendar(inn.getEffDt()));
		transactionStatus.setCompensationDt(DateUtil.toXMLGregorianCalendar(inn.getCompensationDate()));
		transactionStatus.setApprovalId(inn.getApprovalId());
		UserIdType userIdType = new UserIdType();
		userIdType.setCustIdType(inn.getCustomerDocType());
		userIdType.setCustIdNum(inn.getCustomerDocId());

		TransactionInqRsType out = new TransactionInqRsType();
		out.setStatusCode(inn.getStatusCode());
		out.setStatusDesc(inn.getStatusDesc());
		out.setRqUID(inn.getRqUID());
		out.setIpAddress(inn.getIpAddress());
		out.setSource(inn.getSource());
		out.setTransactionStatus(transactionStatus); 
		out.setPersonalData(convertGetTransactionByTokenOutDTOToPersonalDataType(inn));
		out.setAgreementInfo(convertGetTransactionByTokenOutDTOToAgreementInfoType(inn));
		out.setPmtId(inn.getPmtId());
		out.setOrderInfo(convertGetTransactionByTokenOutDTOToOrderInfoType(inn));
		out.setFee(convertGetTransactionByTokenOutDTOToFeeType(inn));
		out.setTaxFee(convertGetTransactionByTokenOutDTOToTaxFeeType(inn));
		out.setReference(convertReferenceStringListToReferenceTypeList(inn.getReferenceMap()));
		out.setInvoiceReference(convertInvoiceReferenceStringListToInvoiceReferenceTypeList(inn.getInvoiceReferenceMap()));
		out.setPmtWay(convertPaymentWayBOListToPaymentWayTypeList(inn.getPaymentWayList()));
		out.setCommerceSetting(convertGetTransactionByTokenOutDTOToCommerceSettingType(inn));
		out.setPortalURL(inn.getPortalURL());
		out.setCategoryId(inn.getCategoryId());
		out.setPmtType(inn.getPmtType());
		//out.setTrnType(inn.getTrnType());
		out.setTrnChannel(inn.getTrnChannel());
		out.setTRM(convertGetTransactionByTokenOutDTOToTrmType(inn));
		out.setUserId(userIdType);
		return out;
	}

	/**
	 * Convierte de GetTransactionByTokenOutDTO a TaxFeeType
	 * @param inn
	 * @return
	 */
	public static TaxFeeType convertGetTransactionByTokenOutDTOToTaxFeeType(GetTransactionByTokenOutDTO inn) {
		TaxFeeType out = new TaxFeeType();
		out.setAmt(inn.getTaxAmt());
		out.setCurCode(inn.getTaxCurCode());
		out.setCurRate(inn.getTaxCurRate());
		return out;
	}

	/**
	 * Convierte de GetTransactionByIdOutDTO a TaxFeeType
	 * @param inn
	 * @return
	 */
	public static TaxFeeType convertGetTransactionByIdOutDTOTokenOutDTOToTaxFeeType(GetTransactionByIdOutDTO inn) {
		TaxFeeType out = new TaxFeeType();
		out.setAmt(inn.getTaxAmt());
		out.setCurCode(inn.getTaxCurCode());
		out.setCurRate(inn.getTaxCurRate());
		return out;
	}

	/**
	 * Convierte de GetTransactionByIdOutDTO a PersonalDataType
	 * @param inn
	 * @return
	 */
	public static List<PersonalDataType> convertGetTransactionByTokenOutDTOToPersonalDataType(GetTransactionByTokenOutDTO inn) {
		List<PersonalDataType> out = new ArrayList<PersonalDataType>();
		CustNameType custNameBuyer = new CustNameType();
		PersonalDataType outBuyer = new PersonalDataType();
		/** Info Comprador */
		custNameBuyer.setFirstName(inn.getFirstNameBuyer());
		custNameBuyer.setMiddleName(inn.getMiddleNameBuyer());
		custNameBuyer.setLastName(inn.getLastNameBuyer());
		custNameBuyer.setSecondLastName(inn.getSecondLastNameBuyer());
		outBuyer.setCustName(custNameBuyer);
		outBuyer.setCustIdType(inn.getCustomerDocType());
		outBuyer.setCustIdNum(inn.getCustomerDocId());
		outBuyer.setEmailAddr(inn.getEmailAddr());
		outBuyer.setPhone(inn.getCustomerPhone());

		/*outBuyer.setAddress(inn.getAddress());
		outBuyer.setBirthDt(DateUtil.toXMLGregorianCalendar(inn.getBirthDt()));
		outBuyer.setCityName(inn.getCityName());
		outBuyer.setCountryName(inn.getCountryName());
		outBuyer.setCustName(custName); 
		outBuyer.setGender(inn.getGender());
		outBuyer.setMaritalStatus(null); 
		outBuyer.setStateProvName(inn.getStateProvName());*/
		out.add(outBuyer);
		/** Info Pagador */
		CustNameType custNamePayer = new CustNameType();
		PersonalDataType outPayer = new PersonalDataType();
		custNamePayer.setFirstName(inn.getFirstNamePayer());
		custNamePayer.setMiddleName(inn.getMiddleNamePayer());
		custNamePayer.setLastName(inn.getLastNamePayer());
		custNamePayer.setSecondLastName(inn.getSecondLastNamePayer());
		outPayer.setCustName(custNamePayer);
		outPayer.setCustIdType(inn.getCustomerDocTypePayer());
		outPayer.setCustIdNum(inn.getCustomerDocIdPayer());
		outPayer.setEmailAddr(inn.getEmailAddrPayer());
		outPayer.setPhone(inn.getCustomerPhonePayer());

		/*outPayer.setAddress(inn.getAddress());
		outPayer.setBirthDt(DateUtil.toXMLGregorianCalendar(inn.getBirthDt()));
		outPayer.setCityName(inn.getCityName());
		outPayer.setCountryName(inn.getCountryName());
		outPayer.setCustName(custName); 
		outPayer.setEmailAddr(inn.getEmailAddr());
		outPayer.setGender(inn.getGender());
		outPayer.setMaritalStatus(null); 
		outPayer.setPhone(inn.getCustomerPhone()); 
		outPayer.setStateProvName(inn.getStateProvName());*/
		out.add(outPayer);
		return out;
	}

	/**
	 * Convierte de GetTransactionByTokenOutDTO a PersonalDataType
	 * @param inn
	 * @return
	 */
	/*public static PersonalDataType convertGetTransactionByTokenOutDTOToPersonalDataType(GetTransactionByTokenOutDTO inn) {
		CustNameType custName = new CustNameType();
		custName.setFirstName(inn.getFirstName());
		PersonalDataType out = new PersonalDataType();
		out.setCustName(custName);
		out.setGender(inn.getGender());
		out.setBirthDt(DateUtil.toXMLGregorianCalendar(inn.getBirthDt()));
		out.setCityName(inn.getCityName());
		out.setStateProvName(inn.getStateProvName());
		out.setCountryName(inn.getCountryName());
		out.setAddress(inn.getAddress());
		if(inn.getEmailAddr() != null) {
			out.setEmailAddr(inn.getEmailAddr());
		}
		if(inn.getCustomerPhone() != null) {
			out.setPhone(inn.getCustomerPhone());
		}
		return out;
	}*/

	/**
	 * Convierte de GetTransactionByIdOutDTO a PersonalDataType
	 * @param inn
	 * @return
	 */
	public static List<PersonalDataType> convertGetTransactionByIdOutDTOToPersonalDataType(GetTransactionByIdOutDTO inn) {
		List<PersonalDataType> out = new ArrayList<PersonalDataType>();
		CustNameType custNameBuyer = new CustNameType();
		PersonalDataType outBuyer = new PersonalDataType();
		/** Info Comprador */
		custNameBuyer.setFirstName(inn.getFirstNameBuyer());
		custNameBuyer.setMiddleName(inn.getMiddleNameBuyer());
		custNameBuyer.setLastName(inn.getLastNameBuyer());
		custNameBuyer.setSecondLastName(inn.getSecondLastNameBuyer());
		outBuyer.setCustName(custNameBuyer);
		outBuyer.setCustIdType(inn.getCustomerDocType());
		outBuyer.setCustIdNum(inn.getCustomerDocId());
		if(inn.getEmailAddr() != null) {
			outBuyer.setEmailAddr(inn.getEmailAddr());
		}
		if(inn.getCustomerPhone() != null) {
			outBuyer.setPhone(inn.getCustomerPhone());
		}

		/*outBuyer.setAddress(inn.getAddress());
		outBuyer.setBirthDt(DateUtil.toXMLGregorianCalendar(inn.getBirthDt()));
		outBuyer.setCityName(inn.getCityName());
		outBuyer.setCountryName(inn.getCountryName());
		outBuyer.setCustName(custName); 
		outBuyer.setGender(inn.getGender());
		outBuyer.setMaritalStatus(null); 
		outBuyer.setStateProvName(inn.getStateProvName());*/
		out.add(outBuyer);
		/** Info Pagador */
		CustNameType custNamePayer = new CustNameType();
		PersonalDataType outPayer = new PersonalDataType();
		custNamePayer.setFirstName(inn.getFirstNamePayer());
		custNamePayer.setMiddleName(inn.getMiddleNamePayer());
		custNamePayer.setLastName(inn.getLastNamePayer());
		custNamePayer.setSecondLastName(inn.getSecondLastNamePayer());
		outPayer.setCustName(custNamePayer);
		outPayer.setCustIdType(inn.getCustomerDocTypePayer());
		outPayer.setCustIdNum(inn.getCustomerDocIdPayer());
		if(inn.getEmailAddrPayer() != null) {
			outPayer.setEmailAddr(inn.getEmailAddrPayer());
		}
		if(inn.getCustomerPhonePayer() != null) {
			outPayer.setPhone(inn.getCustomerPhonePayer());
		}

		/*outPayer.setAddress(inn.getAddress());
		outPayer.setBirthDt(DateUtil.toXMLGregorianCalendar(inn.getBirthDt()));
		outPayer.setCityName(inn.getCityName());
		outPayer.setCountryName(inn.getCountryName());
		outPayer.setCustName(custName); 
		outPayer.setEmailAddr(inn.getEmailAddr());
		outPayer.setGender(inn.getGender());
		outPayer.setMaritalStatus(null); 
		outPayer.setPhone(inn.getCustomerPhone()); 
		outPayer.setStateProvName(inn.getStateProvName());*/
		out.add(outPayer);
		return out;
	}

	/**
	 * Convierte de GetTransactionByIdOutDTO a PersonalDataType
	 * @param inn
	 * @return
	 */
	/*public static PersonalDataType convertGetTransactionByIdOutDTOToPersonalDataType(GetTransactionByIdOutDTO inn) {
		CustNameType custName = new CustNameType();
		custName.setFirstName(inn.getFirstName());
		PersonalDataType out = new PersonalDataType();
		out.setAddress(inn.getAddress());
		out.setBirthDt(DateUtil.toXMLGregorianCalendar(inn.getBirthDt()));
		out.setCityName(inn.getCityName());
		out.setCountryName(inn.getCountryName());
		out.setCustName(custName); 
		out.setEmailAddr(inn.getEmailAddr());
		out.setGender(inn.getGender());
		out.setMaritalStatus(null); 
		out.setPhone(inn.getCustomerPhone()); 
		out.setStateProvName(inn.getStateProvName());
		return out;
	}*/

	/**
	 * Convierte de GetTransactionByTokenOutDTO a FeeType
	 * @param inn
	 * @return
	 */
	public static OrderInfoType convertGetTransactionByTokenOutDTOToOrderInfoType(GetTransactionByTokenOutDTO inn) {
		OrderInfoType out = new OrderInfoType();
		if (inn.getOrderId() != null){
			out.setOrderId(inn.getOrderId());
		} else {
			out.setOrderId("0");
		}
		out.setDesc(inn.getOrderDescription());
		out.setEndDt(DateUtil.toXMLGregorianCalendar(inn.getEndDt()));
		out.setExpDt(DateUtil.toXMLGregorianCalendar(inn.getExpDt()));
		return out;
	}

	/**
	 * Convierte de GetTransactionByIdOutDTO a FeeType
	 * @param inn
	 * @return
	 */
	public static OrderInfoType convertGetTransactionByIdOutDTOToOrderInfoType(GetTransactionByIdOutDTO inn) {
		OrderInfoType out = new OrderInfoType();
		out.setOrderId(inn.getOrderId());
		out.setDesc(inn.getOrderDescription());
		out.setExpDt(DateUtil.toXMLGregorianCalendar(inn.getExpDt()));
		out.setEndDt(DateUtil.toXMLGregorianCalendar(inn.getEndDt()));
		return out;
	}

	/**
	 * Convierte de GetTransactionByTokenOutDTO a FeeType
	 * @param inn
	 * @return
	 */
	public static FeeType convertGetTransactionByTokenOutDTOToFeeType(GetTransactionByTokenOutDTO inn) {
		FeeType out = new FeeType();
		out.setAmt(inn.getAmt());
		out.setCurCode(inn.getCurCode());
		out.setCurRate(inn.getCurRate());
		return out;
	}

	/**
	 * Convierte de GetTransactionByIdOutDTO a FeeType
	 * @param inn
	 * @return
	 */
	public static FeeType convertGetTransactionByIdOutDTOToFeeType(GetTransactionByIdOutDTO inn) {
		FeeType out = new FeeType();
		out.setAmt(inn.getAmt());
		out.setCurCode(inn.getCurCode());
		out.setCurRate(inn.getCurRate());
		return out;
	}

	/**
	 * Convierte de GetTransactionByTokenOutDTO a AgreementInfoType
	 * @param inn
	 * @return
	 */
	public static AgreementInfoType convertGetTransactionByTokenOutDTOToAgreementInfoType(GetTransactionByTokenOutDTO inn) {
		AgreementInfoType out = new AgreementInfoType();
		out.setAgreementId(inn.getAgreementId());
		out.setName(inn.getCommerceName()); 
		out.setNIT(inn.getNit());
		out.setPhone(inn.getCommerceContactPhone());
		return out;
	}

	/**
	 * Convierte de GetTransactionByIdOutDTO a AgreementInfoType
	 * @param inn
	 * @return
	 */
	public static AgreementInfoType convertGetTransactionByIdOutDTOOToAgreementInfoType(GetTransactionByIdOutDTO inn) {
		AgreementInfoType out = new AgreementInfoType();
		out.setAgreementId(inn.getAgreementId());
		out.setName(inn.getCommerceName()); 
		out.setNIT(inn.getNit());
		out.setPhone(inn.getCommerceContactPhone());
		return out;
	}

	/**
	 * Convierte de GetTransactionByTokenOutDTO a CommerceSettingType
	 * @param inn
	 * @return
	 */
	public static CommerceSettingType convertGetTransactionByTokenOutDTOToCommerceSettingType(GetTransactionByTokenOutDTO inn) {
		CommerceSettingType out = new CommerceSettingType();
		out.setLogoURL(inn.getLogoURL());
		out.setTemplate(inn.getTemplate());
		out.setTheme(inn.getTheme());
		return out;
	}

	/**
	 * Convierte de GetTransactionByIdOutDTO a CommerceSettingType
	 * @param inn
	 * @return
	 */
	public static CommerceSettingType convertGetTransactionByIdOutDTOToCommerceSettingType(GetTransactionByIdOutDTO inn) {
		CommerceSettingType out = new CommerceSettingType();
		out.setLogoURL(inn.getLogoURL());
		out.setTemplate(inn.getTemplate());
		out.setTheme(inn.getTheme());
		return out;
	}

	/**
	 * Convierte los objetos de GetTransactionStatusOutDTO a TransactionStatusInqRsType.
	 * @param inn
	 * @return 
	 */
	public static TransactionStatusInqRsType convertGetTransactionStatusOutDTOToTransactionStatusInqRsType(GetTransactionStatusOutDTO inn) {
		TransactionStatusInqRsType out = new TransactionStatusInqRsType();
		out.setStatusCode(inn.getStatusCode().longValue());
		out.setStatusDesc(inn.getStatusDesc());
		out.setRqUID(inn.getRqUID());
		out.setTransactionStatus(convertGetTransactionStatusOutDTOToTransactionStatusType(inn));
		out.setPmtId(inn.getPmtId());
		out.setPmtWay(getPaymentWayList(inn));
		out.setPersonalData(getPersonalData(inn));
		return out;		
	}

	private static PersonalDataType getPersonalData(GetTransactionStatusOutDTO inn){
		PersonalDataType pd = new PersonalDataType();
		CustNameType cus = new CustNameType();
		cus.setFirstName(inn.getFirstNameBuyer());
		cus.setMiddleName(inn.getMiddleNameBuyer());
		cus.setLastName(inn.getLastNameBuyer());
		cus.setSecondLastName(inn.getSecondLastNameBuyer());
		pd.setCustName(cus);
		pd.setEmailAddr(inn.getCustomerEmail());
		pd.setPhone(inn.getCustomerPhone());
		return pd;
	}

	private static List<PmtWayType> getPaymentWayList(
			GetTransactionStatusOutDTO inn) {
		List<PmtWayType> out = new ArrayList<PmtWayType>();
		PmtWayType pw = new PmtWayType();
		pw.setPmtWayId(inn.getPmtWayId());
		pw.setPmtWayType(inn.getPmtWayDesc());
		out.add(pw);
		return out;
	}

	/**
	 * Convierte los objetos de GetTransactionStatusOutDTO a TransactionStatusInqRsType.
	 * @param inn
	 * @return 
	 */
	public static TransactionStatusType convertGetTransactionStatusOutDTOToTransactionStatusType(GetTransactionStatusOutDTO inn){
		TransactionStatusType out = new TransactionStatusType();
		out.setTrnStatusCode(inn.getTrnStatusCode());
		out.setTrnStatusDesc(inn.getTrnStatusDesc());
		out.setTrnServerStatusCode(inn.getTrnServerStatusCode());
		out.setTrnServerStatusDesc(inn.getTrnServerStatusDesc());
		out.setEffDt(DateUtil.toXMLGregorianCalendar(inn.getEffDt()));
		out.setCompensationDt(DateUtil.toXMLGregorianCalendar(inn.getCompensationDate()));
		out.setApprovalId(inn.getApprovalId());
		return out;
	}

	/**
	 * Convierte de TransactionInfoModRqType a ModTransactionInfoInDTO
	 * @param inn
	 * @return
	 */
	public static ModTransactionInfoInDTO convertTransactionInfoModRqTypeToModTransactionInfoInDTO(TransactionInfoModRqType inn) {
		ModTransactionInfoInDTO out = new ModTransactionInfoInDTO();
		out.setRqUID(inn.getRqUID());
		out.setClientDt(DateUtil.toDate(inn.getClientDt()));
		out.setIpAddr(inn.getIPAddr());
		out.setTransactionBO(convertTransactionInfoModRqTypeToTransactionBO(inn));
		return out;
	}

	/**
	 * Convierte de ModTransactionInfoOutDTO a TransactionInfoModRsType
	 * @param inn
	 * @return
	 */
	public static TransactionInfoModRsType convertModTransactionInfoOutDTOToTransactionInfoModRsType(ModTransactionInfoOutDTO inn) {
		TransactionStatusType transactionStatus = new TransactionStatusType();
		transactionStatus.setTrnStatusCode(inn.getTrnStatusCode());
		transactionStatus.setTrnStatusDesc(inn.getTrnStatusDesc());
		transactionStatus.setTrnServerStatusCode(inn.getTrnServerStatusCode());
		transactionStatus.setTrnServerStatusDesc(inn.getTrnServerStatusDesc());
		transactionStatus.setEffDt(DateUtil.toXMLGregorianCalendar(inn.getEffDt()));
		transactionStatus.setCompensationDt(DateUtil.toXMLGregorianCalendar(inn.getCompensationDt()));
		transactionStatus.setApprovalId(inn.getApprovalId());
		TransactionInfoModRsType out = new TransactionInfoModRsType();
		out.setStatusCode(inn.getStatusCode());
		out.setStatusDesc(inn.getStatusDesc());
		out.setRqUID(inn.getRqUID());
		out.setTransactionStatus(transactionStatus); 		
		return out;
	}

	/**
	 * Convierte de TransactionStatusModRqType a ModTransactionStatusInDTO
	 * 
	 * @param inn
	 * @return
	 */
	public static ModTransactionStatusInDTO convertTransactionStatusModRqTypeToModTransactionStatusInDTO(TransactionStatusModRqType inn) {
		ModTransactionStatusInDTO out = new ModTransactionStatusInDTO();
		out.setRqUID(inn.getRqUID());
		out.setClientDt(DateUtil.toDate(inn.getClientDt()));
		out.setIpAddr(inn.getIPAddr());
		out.setTransactionBO(convertTransactionStatusModRqTypeToTransactionBO(inn));
		return out;
	}

	/**
	 * Convierte de ModTransactionStatusOutDTO a TransactionStatusModRsType
	 * @param inn
	 * @return
	 */
	public static TransactionStatusModRsType convertModTransactionStatusOutDTOToTransactionStatusModRsType(ModTransactionStatusOutDTO inn) {
		TransactionStatusType transactionStatus = new TransactionStatusType();
		transactionStatus.setTrnStatusCode(inn.getTrnStatusCode());
		transactionStatus.setTrnStatusDesc(inn.getTrnStatusDesc());
		transactionStatus.setTrnServerStatusCode(inn.getTrnServerStatusCode());
		transactionStatus.setTrnServerStatusDesc(inn.getTrnServerStatusDesc());
		transactionStatus.setEffDt(DateUtil.toXMLGregorianCalendar(inn.getEffDt()));
		transactionStatus.setCompensationDt(DateUtil.toXMLGregorianCalendar(inn.getCompensationDt()));
		transactionStatus.setApprovalId(inn.getApprovalId());
		TransactionStatusModRsType out = new TransactionStatusModRsType();
		out.setStatusCode(inn.getStatusCode());
		out.setStatusDesc(inn.getStatusDesc());
		out.setRqUID(inn.getRqUID());
		out.setTransactionStatus(transactionStatus);
		out.setPmtId(inn.getPmtId());
		return out;
	}

	/**
	 * Conviente GetTransactionByIdOutDTO a List<ReferenceType>
	 * @param reffList
	 * @return 
	 */
	private static List<ReferenceType> convertReferenceStringListToReferenceTypeList(Map<String, String> inn) {
		List<ReferenceType> out = new ArrayList<ReferenceType>();
		ReferenceType rt;
		if (inn == null) {
			rt = new ReferenceType();
			rt.setRefId("0000000");
			rt.setRefType("0000000");
			out.add(rt);
			return out;
		}

		for(Entry<String, String> ref: inn.entrySet()){
			rt = new ReferenceType();
			rt.setRefId(ref.getKey());
			rt.setRefType(ref.getValue());
			out.add(rt);
		}
		return out;
	}

	/**
	 * Conviente GetTransactionByIdOutDTO a List<InvoiceReferenceType>
	 * @param invoiceReferenList
	 * @return 
	 */
	private static List<InvoiceReferenceType> convertInvoiceReferenceStringListToInvoiceReferenceTypeList(Map<String, String> inn){
		List<InvoiceReferenceType> out = new ArrayList<InvoiceReferenceType>();
		InvoiceReferenceType rt;
		if (inn == null) {
			rt = new InvoiceReferenceType();
			rt.setPmtCodNIE("0000000");
			out.add(rt);
			return out;
		}

		for(Entry<String, String> ref: inn.entrySet()) {
			if(ref.getKey().equals("InvoiceReferen1")) {
				rt = new InvoiceReferenceType();
				rt.setPmtCodNIE(ref.getValue());
				out.add(rt);
			}
		}

		for(Entry<String, String> ref: inn.entrySet()) {
			if(ref.getKey().equals("InvoiceReferen2")) {
				rt = new InvoiceReferenceType();
				rt.setPmtCodNIE(ref.getValue());
				out.add(rt);
			}
		}

		for(Entry<String, String> ref: inn.entrySet()) {
			if(ref.getKey().equals("InvoiceReferen3")) {
				rt = new InvoiceReferenceType();
				rt.setPmtCodNIE(ref.getValue());
				out.add(rt);
			}
		}

		for(Entry<String, String> ref: inn.entrySet()) {
			if(ref.getKey().equals("InvoiceReferen4")) {
				rt = new InvoiceReferenceType();
				rt.setPmtCodNIE(ref.getValue());
				out.add(rt);
			}
		}
		return out;
	}

	/**
	 * Conviente List<PaymentWayBO> a List<PmtWayType>
	 * @param inn
	 * @return 
	 */
	private static List<PmtWayType> convertPaymentWayBOListToPaymentWayTypeList(List<PaymentWayBO> inn) {
		List<PmtWayType> out = new ArrayList<PmtWayType>();
		if(inn == null || inn.isEmpty()){
			return out;
		}
		PmtWayType pwt;
		for(PaymentWayBO pwBO: inn){
			pwt = new PmtWayType();
			pwt.setPmtWayId(pwBO.getId()+"");
			pwt.setPmtWayType(pwBO.getName());
			out.add(pwt);
		}
		return out;
	}

	/**
	 * Conviente ACHCreateTransactionInDTO a TransactionPaymentInp
	 * @param inn
	 * @return
	 */
	public static TransactionPaymentInp convertACHCreateTransactionInDTOToTransactionPaymentInp (ACHCreateTransactionInDTO inn){
		TransactionPaymentInp transactionPaymentInp = new TransactionPaymentInp();
		transactionPaymentInp.setEntityCode(inn.getCommerceNIT());
		transactionPaymentInp.setEntityUrl(inn.getReturnURL());
		transactionPaymentInp.setFinantialInstitutionCode(inn.getBankACHCode());
		transactionPaymentInp.setPaymentDescription(inn.getDescription());
		transactionPaymentInp.setReferenceNumber1(inn.getReference1());
		transactionPaymentInp.setReferenceNumber2(inn.getReference2());
		transactionPaymentInp.setReferenceNumber3(inn.getReference3());
		transactionPaymentInp.setReferenceNumber4(inn.getReference4());
		transactionPaymentInp.setServiceCode(inn.getCommerceACHCode());
		GregorianCalendar calendar = new GregorianCalendar();
		calendar.setTime(new Date());
		try {
			transactionPaymentInp.setSoliciteDate(DatatypeFactory.newInstance().newXMLGregorianCalendar(calendar));
		} catch (DatatypeConfigurationException e) {
			transactionPaymentInp.setSoliciteDate(null);
		}
		transactionPaymentInp.setTicketId(inn.getOrderId());
		transactionPaymentInp.setTransactionValue(inn.getTransactionValue());
		transactionPaymentInp.setUserType(inn.getUserType());
		transactionPaymentInp.setVatValue(inn.getTaxValue());
		return transactionPaymentInp;
	}

	/**
	 * Conviente TransactionPaymentOut a ACHCreateTransactionOutDTO
	 * @param inn
	 * @return
	 */
	public static ACHCreateTransactionOutDTO convertTransactionPaymentOutToACHCreateTransactionOutDTO(TransactionPaymentOut inn) {
		ACHCreateTransactionOutDTO achCreateTransactionOutDTO = new ACHCreateTransactionOutDTO();
		achCreateTransactionOutDTO.setBankUrl(inn.getBankUrl() == null ? "" : inn.getBankUrl());
		achCreateTransactionOutDTO.setReturnCode(inn.getReturnCode() == null ? "" : inn.getReturnCode());
		achCreateTransactionOutDTO.setSoliciteDate(DateUtil.toDate(inn.getSoliciteDate()));
		achCreateTransactionOutDTO.setTrazabilityCode(inn.getTrazabilityCode() == null ? "" : inn.getTrazabilityCode());
		return achCreateTransactionOutDTO;
	}

	public static TransactionStatusInqRsType toTransactionStatusInqRsTypeError(
			TransactionStatusInqRqType transactionStatusInqRq, Exception e) {
		TransactionStatusInqRsType response = new TransactionStatusInqRsType();
		TransactionStatusType trnStatus = new TransactionStatusType();
		response.setStatusCode(300);
		response.setStatusDesc(CoreConstants.ERROR_STATUS_CODE_DESC); 
		response.setRqUID(transactionStatusInqRq.getRqUID());
		trnStatus.setTrnStatusCode(2L);
		trnStatus.setTrnStatusDesc("Error");
		trnStatus.setTrnServerStatusCode(String.valueOf(300));
		trnStatus.setTrnServerStatusDesc(e.getMessage());
		response.setTransactionStatus(trnStatus);
		return response;
	}

	public static RBMPaymentAddRsType toRBMPaymentAddRsTypeError(RBMPaymentAddRqType rbmPaymentAddRq,Exception e){
		RBMPaymentAddRsType response = new RBMPaymentAddRsType();
		TransactionStatusType trnStatus = new TransactionStatusType();
		response.setStatusCode(300);
		response.setStatusDesc(CoreConstants.ERROR_STATUS_CODE_DESC); 
		response.setRqUID(rbmPaymentAddRq.getRqUID());
		trnStatus.setTrnStatusCode(2L);
		trnStatus.setTrnStatusDesc("Error");
		trnStatus.setTrnServerStatusCode(String.valueOf(300));
		trnStatus.setTrnServerStatusDesc(e.getClass().getCanonicalName());
		response.setTransactionStatus(trnStatus);
		return response;
	}

	public static TransactionInformationInp convertACHgetTransactionInformationInDTOToTransactionInformationInp(ACHgetTransactionInformationInDTO inDTO) {
		TransactionInformationInp out = new TransactionInformationInp();
		out.setEntityCode(inDTO.getEntityCode());
		out.setTrazabilityCode(inDTO.getTrazabilityCode());
		return out;
	}

	public static ACHgetTransactionInformationOutDTO convertTransactionInformationOutToACHgetTransactionInformationOutDTO(TransactionInformationOut transactionPaymentOut) {
		ACHgetTransactionInformationOutDTO out = new ACHgetTransactionInformationOutDTO();
		out.setTicketID(transactionPaymentOut.getTicketID());
		out.setTrazabilityCode(transactionPaymentOut.getTrazabilityCode());
		out.setEntityCode(transactionPaymentOut.getEntityCode());
		out.setTransactionValue(transactionPaymentOut.getTransactionValue());
		out.setVatValue(transactionPaymentOut.getVatValue());
		out.setVatValue(transactionPaymentOut.getVatValue());
		out.setSoliciteDate(DateUtil.toDate(transactionPaymentOut.getSoliciteDate()));
		out.setBankProcessDate(DateUtil.toDate(transactionPaymentOut.getBankProcessDate()));
		out.setTransactionCycle(transactionPaymentOut.getTransactionCycle());
		out.setTransactionState(transactionPaymentOut.getTransactionState());
		out.setReturnCode(transactionPaymentOut.getReturnCode());
		return out;
	}

	public static TipoSolicitudCompra convertModRevRBMPaymentInDTOToRevRBMPaymentModRqType(ModRevRBMPaymentInDTO inDTO){
		TipoSolicitudCompra out = new TipoSolicitudCompra();

		TipoIdPersona tipoIdPersona = new TipoIdPersona();
		tipoIdPersona.setNumDocumento(Long.parseLong(inDTO.getCustIdNum()));
		TipoTipoDocumento tipoTipoDocumento = TipoTipoDocumento.fromValue(mapRBMIdentification(inDTO.getCustIdType()));
		tipoIdPersona.setTipoDocumento(tipoTipoDocumento);
		out.setIdPersona(tipoIdPersona);

		TipoInfoMedioPago tipoInfoMedioPago = new TipoInfoMedioPago();
		TipoIdTarjetaCredito tipoIdTarjetaCredito = new TipoIdTarjetaCredito();
		tipoIdTarjetaCredito.setNumTarjeta(inDTO.getCardEmbossNum());
		tipoIdTarjetaCredito.setFranquicia(inDTO.getBrand());

		XMLGregorianCalendar fechaExpiracion = DateUtil.toXMLGregorianCalendar(inDTO.getCardExpDt());
		fechaExpiracion.setTimezone(DatatypeConstants.FIELD_UNDEFINED);
		tipoIdTarjetaCredito.setFechaExpiracion(fechaExpiracion);

		tipoIdTarjetaCredito.setCodVerificacion(inDTO.getCardVrfyData());
		tipoInfoMedioPago.setIdTarjetaCredito(tipoIdTarjetaCredito);
		out.setInfoMedioPago(tipoInfoMedioPago);

		TipoInfoCompra tipoInfoCompra = new TipoInfoCompra();
		tipoInfoCompra.setReferencia(inDTO.getOrderId());
		tipoInfoCompra.setMontoTotal(inDTO.getAmt());

		if (inDTO.getTaxAmt() != null && inDTO.getTaxAmt() != BigDecimal.ZERO) {
			TipoInfoImpuestos tipoInfoImpuestos = new TipoInfoImpuestos();
			tipoInfoImpuestos.setMonto(inDTO.getTaxAmt());
			TipoTipoImpuesto tipoTipoImpuesto = TipoTipoImpuesto.fromValue(TipoTipoImpuesto.IVA.value());
			tipoInfoImpuestos.setTipoImpuesto(tipoTipoImpuesto);
			tipoInfoCompra.getInfoImpuestos().add(tipoInfoImpuestos);
		}

		out.setInfoCompra(tipoInfoCompra);

		return out;
	}

	public static ModRevRBMPaymentOutDTO convertRevRBMPaymentModRsTypeToModRevRBMPaymentOutDTO(TipoRespuesta inn){
		ModRevRBMPaymentOutDTO out = new ModRevRBMPaymentOutDTO();
		out.setStatusCode(new Integer(inn.getInfoRespuesta().getCodRespuesta()));
		out.setStatusDesc(inn.getInfoRespuesta().getDescRespuesta());
		out.setEffDt(DateUtil.toDate(inn.getInfoCompraResp().getFechaTransaccion()));
		out.setCompensationDt(DateUtil.toDate(inn.getInfoCompraResp().getFechaPosteo()));
		out.setApprovalId(inn.getInfoCompraResp().getNumAprobacion());
		return out;
	}

	public static TipoSolicitudCompra convertAddRBMPaymentInDTOToRBMPaymentAddRqType(AddRBMPaymentInDTO inDTO){
		TipoSolicitudCompra out = new TipoSolicitudCompra();

		TipoIdPersona tipoIdPersona = new TipoIdPersona();
		tipoIdPersona.setNumDocumento(Long.parseLong(inDTO.getTransactionBO().getPayerDocId()));
		TipoTipoDocumento tipoTipoDocumento = TipoTipoDocumento.fromValue(mapRBMIdentification(inDTO.getTransactionBO().getPayerDocType()));
		tipoIdPersona.setTipoDocumento(tipoTipoDocumento);
		out.setIdPersona(tipoIdPersona);

		TipoInfoMedioPago tipoInfoMedioPago = new TipoInfoMedioPago();
		TipoIdTarjetaCredito tipoIdTarjetaCredito = new TipoIdTarjetaCredito();
		tipoIdTarjetaCredito.setNumTarjeta(inDTO.getTransactionBO().getCreditCard().getNumber());
		tipoIdTarjetaCredito.setFranquicia(inDTO.getTransactionBO().getCreditCard().getBrand().getName());

		XMLGregorianCalendar fechaExpiracion = DateUtil.toXMLGregorianCalendar(inDTO.getExpDate());
		fechaExpiracion.setTimezone(DatatypeConstants.FIELD_UNDEFINED);
		tipoIdTarjetaCredito.setFechaExpiracion(fechaExpiracion);

		tipoIdTarjetaCredito.setCodVerificacion(inDTO.getTransactionBO().getCreditCard().getSecurityCode());
		tipoInfoMedioPago.setIdTarjetaCredito(tipoIdTarjetaCredito);
		out.setInfoMedioPago(tipoInfoMedioPago);

		TipoInfoCompra tipoInfoCompra = new TipoInfoCompra();
		tipoInfoCompra.setReferencia(inDTO.getTransactionBO().getOrderNumber());
		tipoInfoCompra.setMontoTotal(inDTO.getTransactionBO().getTotalValue());
		tipoInfoCompra.setCantidadCuotas(inDTO.getInstalamentsNum().intValue());

		if (inDTO.getTransactionBO().getTaxValue() != null && inDTO.getTransactionBO().getTaxValue() != BigDecimal.ZERO) {
			TipoInfoImpuestos tipoInfoImpuestos = new TipoInfoImpuestos();
			tipoInfoImpuestos.setMonto(inDTO.getTransactionBO().getTaxValue());
			TipoTipoImpuesto tipoTipoImpuesto = TipoTipoImpuesto.fromValue(TipoTipoImpuesto.IVA.value());
			tipoInfoImpuestos.setTipoImpuesto(tipoTipoImpuesto);
			tipoInfoCompra.getInfoImpuestos().add(tipoInfoImpuestos);
		}

		out.setInfoCompra(tipoInfoCompra);

		return out;
	}

	private static String mapRBMIdentification(String customerDocType) {
		// Equivalencia de tipos de documento
		Map<String, String> rbmIdentificationMap = new HashMap<String, String>();
		rbmIdentificationMap.put("CC", "CC");
		rbmIdentificationMap.put("TI", "TI");
		rbmIdentificationMap.put("CE", "CE");
		rbmIdentificationMap.put("NIT", "NI");
		return rbmIdentificationMap.get(customerDocType);
	}

	private static List<ReferenceType> convertAddRBMPaymentInDTOToReferenceType(AddRBMPaymentInDTO inDTO) {
		String refType;
		List<ReferenceType> out = new ArrayList<ReferenceType>();
		if(inDTO.getTransactionBO().getReference1()!=null) {
			refType = inDTO.getTransactionBO().getReference1().toString();
			ReferenceType ref = new ReferenceType();
			ref.setRefId("INCOCREDITO");
			ref.setRefType(refType);
			out.add(ref);
		}
		if(inDTO.getTransactionBO().getReference2()!=null) {
			refType = inDTO.getTransactionBO().getReference2().toString();
			ReferenceType ref = new ReferenceType();
			ref.setRefId("TERMINAL");
			ref.setRefType(refType);
			out.add(ref);
		}
		if(inDTO.getTransactionBO().getReference3()!=null) {
			if(inDTO.getTransactionBO().getReference3().length() > 0) {
				ReferenceType ref = new ReferenceType();
				ref.setRefId("REF 3");
				ref.setRefType(inDTO.getTransactionBO().getReference3());
				out.add(ref);
			}
		}
		return out;
	}

	/**
	 * Método encargado convertir una lista de referencias a ReferenceType.
	 * @param referenceList
	 * @return
	 */
	private static List<ReferenceType> convertReferenceListToReferenceType(List<String> referenceList) {
		List<ReferenceType> out = new ArrayList<ReferenceType>();

		if (referenceList != null) {
			for (int idx = 0; idx < referenceList.size(); idx++) {
				ReferenceType ref = new ReferenceType();
				if(idx == 0) {
					ref.setRefId("INCOCREDITO");
					ref.setRefType(referenceList.get(idx) != null ? referenceList.get(idx) : "");
					out.add(ref);
				} else if(idx == 1) {
					ref.setRefId("TERMINAL");
					ref.setRefType(referenceList.get(idx) != null ? referenceList.get(idx) : "");
					out.add(ref);
				} else {
					if(referenceList.get((idx)).length() > 0) {
						ref.setRefId("REF " + (idx + 1));
						ref.setRefType(referenceList.get((idx)) != null ? referenceList.get((idx)) : "");
						out.add(ref);
					}
				}
			}
		}
		return out;
	}

	public static AddRBMPaymentOutDTO convertRBMPaymentAddRsTypeToAddRBMPaymentOutDTO(TipoRespuesta inn) {
		AddRBMPaymentOutDTO out = new AddRBMPaymentOutDTO();
		out.setStatusCode(new Integer(inn.getInfoRespuesta().getCodRespuesta()));
		out.setStatusDesc(inn.getInfoRespuesta().getDescRespuesta());
		out.setEffDt(DateUtil.toDate(inn.getInfoCompraResp().getFechaTransaccion()));
		out.setCompensationDate(DateUtil.toDate(inn.getInfoCompraResp().getFechaPosteo()));
		out.setApprovalId(inn.getInfoCompraResp().getNumAprobacion());
		if(inn.getInfoRespuesta().getCodRespuesta().equals(HomologationCodesEnum._00.getHomologationCode())) {
			out.setTrnStatusCode(BusinessStatusEnum.APROBADA.getCode());
		} else {
			out.setTrnStatusCode(Long.valueOf(inn.getInfoRespuesta().getCodRespuesta()));
			out.setTrnStatusDesc(inn.getInfoRespuesta().getDescRespuesta());
		}
		return out;
	}

	/**
	 * Método encargado de convertir los objetos de negocio en objetos WS.
	 * @param inDTO DTO con la información de negocio.
	 * @return Objeto con la información de WS.
	 */
	public static FinalizeTransactionPaymentInp convertACHFinalizeTransactionPaymentInDTOToFinalizeTransactionPaymentInp(ACHFinalizeTransactionPaymentInDTO inDTO) {
		FinalizeTransactionPaymentInp out = new FinalizeTransactionPaymentInp();
		out.setEntityCode(inDTO.getEntityCode());
		out.setTrazabilityCode(inDTO.getTrazabilityCode());
		return out;
	}

	/**
	 * Método encargado de convertir los objetos de WS en objetos de negocio.
	 * @param outDTOCLient Información del objeto de WS.
	 * @return DTO con la información del objeto de negocio.
	 */
	public static ACHFinalizeTransactionPaymentOutDTO convertFinalizeTransactionPaymentOutToACHFinalizeTransactionPaymentOutDTO(FinalizeTransactionPaymentOut outDTOCLient) {
		ACHFinalizeTransactionPaymentOutDTO out = new ACHFinalizeTransactionPaymentOutDTO();
		out.setReturnCode(outDTOCLient.getReturnCode());
		out.setTrazabilityCode(outDTOCLient.getTrazabilityCode());
		return out;
	}

	/**
	 * Método encargado de convertir los objetos de WS en objetos de negocio.
	 * @param inn
	 * @return
	 */
	public static GetHistoricTransactionInDTO convertHistoricTransactionInqRqTypeToGetHistoricTransactionInDTO(HistoricTransactionInqRqType inn) {
		GetHistoricTransactionInDTO response = new GetHistoricTransactionInDTO();
		response.setRqUID(inn.getRqUID());
		response.setChannelSource(inn.getChannel());
		response.setClientDt(DateUtil.toDate(inn.getClientDt()));
		response.setIpAddr(inn.getIPAddr());
		response.setDocType(inn.getUserId().getCustIdType());
		response.setDocNumber(inn.getUserId().getCustIdNum());
		response.setBankId(inn.getBankId());
		response.setStartDate(DateUtil.toDate(inn.getStartDt()));
		response.setEndDate(DateUtil.toDate(inn.getEndDt()));
		response.setState(inn.getState());
		response.setPaymentWayId(inn.getPmtWayId());
		return response;
	}

	public static HistoricTransactionInqRsType convertGetHistoricTransactionOutDTOToHistoricTransactionInqRsType(
			GetHistoricTransactionOutDTO inDTO) {
		// Se crean los estados de retorno
		StatusType statusType = new StatusType();
		statusType.setServerStatusCode(inDTO.getServerStatusCode());
		statusType.setServerStatusDesc(inDTO.getServerStatusDesc());
		statusType.setSeverity(SeverityType.valueOf(inDTO.getSeverity()));
		statusType.setStatusCode(inDTO.getStatusCode());
		statusType.setStatusDesc(inDTO.getStatusDesc());
		// Crear objeto de salida
		HistoricTransactionInqRsType response = new HistoricTransactionInqRsType();
		response.setRqUID(inDTO.getRqUID());
		response.setStatus(statusType);
		// Llenar la lista de salida
		for(TransactionInfoOutDTO transactionRow : inDTO.getTransactionInfoList()){
			RecordTransactionInfoType infoRow = new RecordTransactionInfoType();
			infoRow.setEffDt(DateUtil.toXMLGregorianCalendar(transactionRow.getTransactionDate()));
			infoRow.setRefId(transactionRow.getOrderNumber());
			infoRow.setAmt(transactionRow.getTotalValue());
			infoRow.setTrazabilityCode(transactionRow.getTrazabilityCode());
			infoRow.setState(transactionRow.getStatus());
			infoRow.setPmtId(transactionRow.getPmtId());
			infoRow.setPmtWayId(transactionRow.getPmtWayId());
			infoRow.setAprovalId(transactionRow.getAprovalId());
			// Agregar elemento a la lista
			response.getRecordTransactionInfo().add(infoRow);
		}
		return response;
	}

	public static HistoricTransactionInqRsType buidHistoricTransactionFailedResponse(
			HistoricTransactionInqRqType inn, Exception ex) {
		// Se crea el status
		StatusType status = new StatusType();
		if(ex instanceof ValidationException){
			// Error de validación
			ValidationException vex = (ValidationException)ex;
			status.setStatusCode(CoreConstants.ERROR_DATA_VALIDATION_CODE);
			status.setStatusDesc(vex.getMessage());
			status.setServerStatusCode(String.valueOf(vex.getErrorCode()));
			status.setServerStatusDesc(vex.getCause() != null? vex.getCause().getMessage(): vex.toString());
			status.setSeverity(SeverityType.WARN);
		} else {
			// Error inesperado del sistema
			status.setStatusCode(CoreConstants.ERROR_STATUS_CODE_300);
			status.setStatusDesc(CoreConstants.ERROR_STATUS_CODE_DESC);
			status.setServerStatusCode(String.valueOf(CoreConstants.ERROR_STATUS_CODE_300));
			status.setServerStatusDesc(ex.toString());
			status.setSeverity(SeverityType.ERROR);
			LOGGER.error(CoreConstants.ERROR_STATUS_CODE_DESC+": ", ex);
		}
		// Objeto de retorno
		HistoricTransactionInqRsType response = new HistoricTransactionInqRsType();
		response.setRqUID(inn.getRqUID());
		response.setStatus(status);
		//out.setBankId(inn.getBankId());
		return response;
	}

	/**
	 * Convierte de GetTransactionByTokenOutDTO a TrmType
	 * @param inn
	 * @return
	 */
	public static TrmType convertGetTransactionByTokenOutDTOToTrmType(GetTransactionByTokenOutDTO inn) {
		TrmType out = new TrmType();
		out.setAmt(inn.getTrm());
		out.setCurCode(inn.getCurCodeTrm());
		return out;
	}

	/**
	 * Convierte de GetTransactionByIdOutDTO a TrmType
	 * @param inn
	 * @return
	 */
	public static TrmType convertGetTransactionByIdOutDTOToTrmType(GetTransactionByIdOutDTO inn) {
		TrmType out = new TrmType();
		out.setAmt(inn.getTrm());
		out.setCurCode(inn.getCurCodeTrm());
		return out;
	}

	/**INICIO-C02**/
	/**
	 * 
	 * @param transactionAddRq
	 */
	public static TokenizeInDTO toTokenizeInDTO(TransactionAddRqType transactionAddRq) {
		TokenizeInDTO tokenizeInDTO = new TokenizeInDTO();
		tokenizeInDTO.setClientDt(new Date());
		tokenizeInDTO.setIpAddr(transactionAddRq.getIPAddr());
		tokenizeInDTO.setRqUID(transactionAddRq.getRqUID());
		tokenizeInDTO.setChannel(transactionAddRq.getChannel());

		UserBO userBO = new UserBO();
		userBO.setCustIdNum(transactionAddRq.getUserId().getCustIdNum());
		userBO.setCustIdType(transactionAddRq.getUserId().getCustIdType() );
		userBO.setCustLoginId(transactionAddRq.getUserId().getCustLoginId());

		//TODO: Mapear de acurdo a especificacion o eliminar
		BankBO bankBO = new BankBO();
		bankBO.setId(0l);
		bankBO.setName(BANK_PPA);
		bankBO.setBranchId(BANK_PPA_ID);

		tokenizeInDTO.setUserBO(userBO);
		tokenizeInDTO.setBankBO(bankBO);

		return tokenizeInDTO;

	}

	/**FIN-C02**/

	/**INICIO-C02**/
	/**
	 * 
	 * @param transactionAddRq
	 */
	public static TokenizedDataRqType toTokenizedDataRqType(TokenizeInDTO inDTO) {
		TokenizedDataRqType tokenizedDataRqType = new TokenizedDataRqType();
		tokenizedDataRqType.setChannel(inDTO.getChannel());

		GregorianCalendar cal = new GregorianCalendar();
		cal.setTime(inDTO.getClientDt());
		XMLGregorianCalendar xmlCal = null;
		try {
			xmlCal = DatatypeFactory.newInstance().newXMLGregorianCalendar(cal);
		} catch (DatatypeConfigurationException e) {
			LOGGER.error("No se pudo crear la instancia de XMLCalendar");
		}

		tokenizedDataRqType.setClientDt(xmlCal);
		tokenizedDataRqType.setIPAddr(inDTO.getIpAddr());
		tokenizedDataRqType.setRqUID(inDTO.getRqUID());
		tokenizedDataRqType.setChannel(inDTO.getChannel());

		co.com.ath.pgw.client.tokenize.model.BankInfoType bank = new co.com.ath.pgw.client.tokenize.model.BankInfoType();
		bank.setName(BANK_PPA);
		bank.setBankId(BANK_PPA_ID);

		tokenizedDataRqType.setBankInfo(bank);


		TokenizedDataInfoRqType tokenizedDataInfoRqType = new TokenizedDataInfoRqType();

		co.com.ath.pgw.client.tokenize.model.AuthType authType = new co.com.ath.pgw.client.tokenize.model.AuthType();
		authType.setInfo(inDTO.getTokenizeDataInfoBO().getAuth().getInfo());
		authType.setMethod(inDTO.getTokenizeDataInfoBO().getAuth().getMethod());

		tokenizedDataInfoRqType.setAuth(authType);
		tokenizedDataInfoRqType.setIdSecKey(inDTO.getTokenizeDataInfoBO().getIdSecKey());

		co.com.ath.pgw.client.tokenize.model.ProtectType ProtectType = new co.com.ath.pgw.client.tokenize.model.ProtectType();
		ProtectType.setData(inDTO.getTokenizeDataInfoBO().getProtect().getData());
		ProtectType.setFormat(inDTO.getTokenizeDataInfoBO().getProtect().getFormat());

		if(inDTO.getTokenizeDataInfoBO().getProtect().getStrRefine() != null && !inDTO.getTokenizeDataInfoBO().getProtect().getStrRefine().isEmpty())
			ProtectType.setStrRefine(inDTO.getTokenizeDataInfoBO().getProtect().getStrRefine());

		tokenizedDataInfoRqType.setProtect(ProtectType);
		tokenizedDataRqType.setTokenizedDataInfoRq(tokenizedDataInfoRqType);


		co.com.ath.pgw.client.tokenize.model.UserIdType userIdType = new co.com.ath.pgw.client.tokenize.model.UserIdType();
		userIdType.setCustIdNum(inDTO.getUserBO() == null ? "0" : inDTO.getUserBO().getCustIdNum());
		userIdType.setCustIdType(inDTO.getUserBO() == null ? "CC" : inDTO.getUserBO().getCustIdType());
		userIdType.setCustLoginId(inDTO.getUserBO() == null ? "0" : inDTO.getUserBO().getCustLoginId());

		tokenizedDataRqType.setUserId(userIdType);

		return tokenizedDataRqType;

	}
	/**FIN-C02**/

	/**INICIO-C02**/
	/**
	 * 
	 * @param tokenizedDataRsType
	 * @return
	 */
	public static TokenizeOutDTO toTokenizeOutDTO(TokenizedDataRsType tokenizedDataRsType) {
		TokenizeOutDTO tokenizeOutDTO = new TokenizeOutDTO();

		tokenizeOutDTO.setRqUID(tokenizedDataRsType.getRqUID());
		StatusBO statusBO = new StatusBO();
		statusBO.setServerStatusCode(tokenizedDataRsType.getStatus().getServerStatusCode());
		statusBO.setServerStatusDesc(tokenizedDataRsType.getStatus().getServerStatusDesc());
		statusBO.setSeverity(tokenizedDataRsType.getStatus().getSeverity().toString());
		statusBO.setStatusCode(tokenizedDataRsType.getStatus().getStatusCode());
		statusBO.setStatusDesc(tokenizedDataRsType.getStatus().getStatusDesc());

		tokenizeOutDTO.setStatusBO(statusBO);


		if(tokenizedDataRsType.getTokenizedDataInfoRs() !=null){
			TokenizeDataInfoBO tokenizeDataInfoBO = new TokenizeDataInfoBO();
			ProtectBO protect = new ProtectBO();
			protect.setData(tokenizedDataRsType.getTokenizedDataInfoRs().getProtect().getData());
			protect.setFormat(tokenizedDataRsType.getTokenizedDataInfoRs().getProtect().getFormat());
			protect.setStrRefine(tokenizedDataRsType.getTokenizedDataInfoRs().getProtect().getStrRefine());
			tokenizeDataInfoBO.setProtect(protect);
			tokenizeOutDTO.setTokenizeDataInfoBO(tokenizeDataInfoBO);
		}




		return tokenizeOutDTO;
	}
	/**FIN-C02**/


	/**INICIO-C02**/
	/**
	 * 
	 * @param inDTO
	 * @return
	 */
	public static TokenizeInDTO toTokenizeInDTO(GetTransactionByIdInDTO inDTO) {
		TokenizeInDTO tokenizeInDTO = new TokenizeInDTO();
		tokenizeInDTO.setClientDt(new Date());
		tokenizeInDTO.setIpAddr(inDTO.getIpAddr());
		tokenizeInDTO.setRqUID(inDTO.getRqUID());
		tokenizeInDTO.setChannel(BANK_CHANNEL);

		//TODO: Mapear de acurdo a especificacion o eliminar
		UserBO userBO = new UserBO();
		userBO.setCustIdNum(USER_CORE_NUM);
		userBO.setCustIdType(USER_CORE_TYPE);
		userBO.setCustLoginId(USER_CORE_LOGIN);

		//TODO: Mapear de acurdo a especificacion o eliminar
		BankBO bankBO = new BankBO();
		bankBO.setName(BANK_PPA);
		bankBO.setId(Long.valueOf(BANK_PPA_ID));

		tokenizeInDTO.setBankBO(bankBO);

		TokenizeDataInfoBO tokenizeDataInfoBO = new TokenizeDataInfoBO();
		tokenizeDataInfoBO.setProtect(new ProtectBO());
		tokenizeInDTO.setTokenizeDataInfoBO(tokenizeDataInfoBO);

		return tokenizeInDTO;
	}
	/**FIN-C02**/


	/**INICIO-C02**/
	/**
	 * 
	 * @param inDTO 
	 * @return
	 */
	public static TokenizeInDTO toTokenizeInDTO(GetTransactionInDTO inDTO) {
		TokenizeInDTO tokenizeInDTO = new TokenizeInDTO();
		tokenizeInDTO.setClientDt(new Date());
		tokenizeInDTO.setIpAddr(inDTO.getIpAddr());
		tokenizeInDTO.setRqUID(inDTO.getRqUID());
		tokenizeInDTO.setChannel(BANK_CHANNEL);

		UserBO userBO = new UserBO();
		userBO.setCustIdNum(inDTO.getTransactionBO().getCustomerDocId());
		userBO.setCustIdType(inDTO.getTransactionBO().getCustomerDocType());
		//userBO.setCustLoginId(inDTO.getTransactionBO().);

		BankBO bankBO = new BankBO();
		bankBO.setName(BANK_PPA);
		bankBO.setId(Long.valueOf(BANK_PPA_ID));

		tokenizeInDTO.setBankBO(bankBO);

		TokenizeDataInfoBO tokenizeDataInfoBO = new TokenizeDataInfoBO();
		tokenizeDataInfoBO.setProtect(new ProtectBO());
		tokenizeInDTO.setTokenizeDataInfoBO(tokenizeDataInfoBO);

		return tokenizeInDTO;
	}
	/**FIN-C02**/

	/**INI-C05**/
	public static void mapHomologationCodeRBM(TipoRespuesta inDTOTipoRespuesta){
		if(inDTOTipoRespuesta.getInfoRespuesta().getCodRespuesta()!=null) {
			HomologationCodesEnum resHomologationCodeEnum = HomologationCodesEnum.findByRBMCode(inDTOTipoRespuesta.getInfoRespuesta().getCodRespuesta());
			inDTOTipoRespuesta.getInfoRespuesta().setCodRespuesta(resHomologationCodeEnum.getHomologationCode());
			inDTOTipoRespuesta.getInfoRespuesta().setDescRespuesta(resHomologationCodeEnum.getDesc());
		}
	}
	/**FIN-C05**/

}