/*
 * TokenStatus
 *  
 * GSI - Integración
 * Creado el: 6/10/2014
 *
 * Copyright (c) A Toda Hora S.A. Todos los derechos reservados
 * 
 * Este software es confidencial y es propietario de ATH, queda prohibido
 * su uso, reproducción y copia de manera parcial o permanente salvo autorización
 * expresa de A Toda Hora S.A o de quién represente sus derechos.
 */
package co.com.ath.pgw.util.constants;

/**
 * Class description goes here...
 *
 * @author Andrés Méndez Juanias <proveedor_mamendez@ath.com.co> 
 * @version 1.0 6/10/2014
 * @since 1.0
 */
public interface TokenStatus {
	
	/** Código que identifica el token como inactivo */
	String INACTIVE 	= "0";
	
	/** Código que identifica el token como activo */
	String ACTIVE		= "1";
	
	/** Código que identifica al token como expirado */
	String EXPIRED		= "2";
	
	/** Código que identifica al token como bloqueado */
	String BLOCKED		= "3";

}
