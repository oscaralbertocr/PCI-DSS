/*
 * TokenGeneratorService
 *  
 * GSI - Integración
 * Creado el: 3/10/2014
 *
 * Copyright (c) A Toda Hora S.A. Todos los derechos reservados
 * 
 * Este software es confidencial y es propietario de ATH, queda prohibido
 * su uso, reproducción y copia de manera parcial o permanente salvo autorización
 * expresa de A Toda Hora S.A o de quién represente sus derechos.
 */
package co.com.ath.pgw.util.security;

import java.util.Set;


/**
 * Genera el token de las transaccines.
 *
 * @author Andrés Méndez Juanias <proveedor_mamendez@ath.com.co> 
 * @version 1.0 3/10/2014
 * @since 1.0
 */
public interface TokenGeneratorService {

	/**
	 * 
	 * Genera el token a partir del conjunto de argumentos pasado por parámetro.
	 * @param args Argumentos para generar el token.
	 * @return token generado.
	 */
	String generate(Set<Object> args);
}
