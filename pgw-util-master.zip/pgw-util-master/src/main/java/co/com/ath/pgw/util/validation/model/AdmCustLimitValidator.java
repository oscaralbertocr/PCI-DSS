/*
 * AddAVALPaymentValidator
 *  
 * GSI - Integración
 * Creado el: 19/09/2014
 *
 * Copyright (c) A Toda Hora S.A. Todos los derechos reservados
 * 
 * Este software es confidencial y es propietario de ATH, queda prohibido
 * su uso, reproducción y copia de manera parcial o permanente salvo autorización
 * expresa de A Toda Hora S.A o de quién represente sus derechos.
 */
package co.com.ath.pgw.util.validation.model;

import co.com.ath.pgw.bsn.dto.in.GatewayCustLimitInDTO;
import co.com.ath.pgw.util.validation.ValidationException;

/**
 * Validación para los datos de entrada para la operación AddAVALPayment.
 * 
 * @author Andrés Méndez Juanias <proveedor_mamendez@ath.com.co>
 * @version 1.0
 * @created 19-sep-2014 03:30:58 p.m.
 */
public interface AdmCustLimitValidator  {

	public void validate(GatewayCustLimitInDTO inDTO) throws ValidationException;
	
	
	public void validateDelete(GatewayCustLimitInDTO inDTO) throws ValidationException;
	
	public void validateFechaInicioFinal(GatewayCustLimitInDTO inDTO) throws ValidationException;

}