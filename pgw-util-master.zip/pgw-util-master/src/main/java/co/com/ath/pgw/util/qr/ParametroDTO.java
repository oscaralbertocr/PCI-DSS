package co.com.ath.pgw.util.qr;

import java.io.Serializable;

/*
 * Clase : ParametroDTO
 * Date  : 18-Nov-2020
 * Author: Javier Capera
 *         SOPHOS SOLUTIONS
 */
public class ParametroDTO implements Serializable {

	private String nombre;
	private String descripcion;
	private String valor;
	private String tipoValor;
	private boolean activo;

	public ParametroDTO() {

	}

	public String getNombre() {
		return nombre;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	public String getDescripcion() {
		return descripcion;
	}

	public void setDescripcion(String descripcion) {
		this.descripcion = descripcion;
	}

	public String getValor() {
		return valor;
	}

	public void setValor(String valor) {
		this.valor = valor;
	}

	public String getTipoValor() {
		return tipoValor;
	}

	public void setTipoValor(String tipoValor) {
		this.tipoValor = tipoValor;
	}

	public boolean isActivo() {
		return activo;
	}

	public void setActivo(boolean activo) {
		this.activo = activo;
	}

	@Override
	public String toString() {
		return "ParametroDTO [nombre=" + nombre + ", descripcion=" + descripcion + ", valor=" + valor + ", tipoValor="
				+ tipoValor + ", activo=" + activo + "]";
	}

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

}
