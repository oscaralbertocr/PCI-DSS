package co.com.ath.pgw.util.constants;

public interface TransactionChannels {

	public static final String PASARELA = "Pasarela";
}
