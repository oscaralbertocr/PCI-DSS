/*
 * PaymentWayCodes
 *  
 * GSI - Integración
 * Creado el: 7/10/2014
 *
 * Copyright (c) A Toda Hora S.A. Todos los derechos reservados
 * 
 * Este software es confidencial y es propietario de ATH, queda prohibido
 * su uso, reproducción y copia de manera parcial o permanente salvo autorización
 * expresa de A Toda Hora S.A o de quién represente sus derechos.
 */
package co.com.ath.pgw.util.constants;

/**
 * Class description goes here...
 * 
 * @author Andrés Méndez Juanias <proveedor_mamendez@ath.com.co>
 * @version 1.0 7/10/2014
 * @since 1.0
 */
public interface PaymentWayCodes {

	/** Código del tippo de pago CB */
	Long UNDEFINED = 0L;
	
	/** Código del tippo de pago AVAL */
	Long PAGOS_AVAL = 1L;
	
	/** Código del tippo de pago TC */
	Long TC = 2L;
	
	/** Código del tippo de pago PSE */
	Long PSE = 3L;
	
	/** Código del tippo de pago Pagos online */
	Long PAGOS_ONLINE = 4L;
	
	/** Código del tippo de pago Paypal */
	Long PAYPAL = 5L;
	
	/** Código del tippo de pago POS */
	Long POS = 6L;
	
	/** Código del tippo de pago Cajero */
	Long CAJERO = 7L;
	
	/** Código del tippo de pago CB */
	Long CB = 8L;
	
	/** Código del tippo de pago vacío */
	Long EMTPY = 9L;
	
	/** Código del tippo de pago vacío */
	Long RBM = 10L;
	
	/** Acrónimo del tipo de pago Aval */
	String PAGOS_AVAL_PAYMENT = "AVAL";
	
	/** Acrónimo del tipo de pago TC */
	String PAGOS_TC_PAYMENT = "TC";
	
	/** Acrónimo del tipo de pago PSE */
	String PAGOS_PSE_PAYMENT = "PSE";
	
	/** Acrónimo del tipo de pago RBM */
	String PAGOS_RBM_PAYMENT = "RBM";
}
