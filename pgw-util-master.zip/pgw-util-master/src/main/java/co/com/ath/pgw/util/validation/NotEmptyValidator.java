/*
 * NotEmptyValidator
 *
 * GSI - Integración
 * Creado el: 5 de septiembre de 2014
 *
 * Copyright (c) A Toda Hora S.A. Todos los derechos reservados
 *
 * Este software es confidencial y es propietario de ATH, queda prohibido
 * su uso, reproducción y copia de manera parcial o permanente salvo autorización
 * expresa de A Toda Hora S.A o de quién represente sus derechos.
 */
package co.com.ath.pgw.util.validation;

import java.util.Locale;

import org.springframework.stereotype.Component;

import co.com.ath.pgw.util.i18n.BundleKeys;
import co.com.ath.pgw.util.i18n.BundleType;

/**
 * Valida que un objeto que represente una cadena de texto no esté vacío luego de
 * eliminar los espacios innecesarios al principio y final de la cadena (trim).
 * Este validador soporta unicamente objetos de tipo CharSequence y sus subtipos.
 * 
 * @see CharSequence
 * 
 * @author proveedor_zagarcia
 * @version 1.0 05 Sep 2014
 * @since 1.0
 */
@Component
public class NotEmptyValidator extends ObjectValidator {

	/**
	 * Construye un validator para verificar el contenido de una cadena de 
	 * texto.
	 * 
	 */
	public NotEmptyValidator() {
		super();
	}

	/**
	 * Construye un validator para verificar el contenido de una cadena de 
	 * texto especificando el validador interno.
	 * 
	 * @param internalValidator		Validador interno
	 */
	public NotEmptyValidator(ObjectValidator internalValidator) {
		super(internalValidator);
	}

	@Override
	protected void doValidate(Object object, Locale locale) 
											throws ObjectValidationException{
		if (!(object instanceof CharSequence)) {
			throw new UnsupportedTypeException(
					object.getClass().getCanonicalName());
		}
		
		final String sequence = object.toString();
		if (sequence.trim().length() == 0) {
			throw new ObjectValidationException(getMessage(locale));
		}
	}

	/**
	 * Retorna el mensaje de error en la validación en el idioma solicitado. Si
	 * el gestor de Bundle es nulo retorna el valor de la llave en el Bundle de
	 * error.
	 * 
	 * @param locale Información de idioma y localización.
	 * @return Mensaje de error en la validación.
	 */
	private String getMessage(Locale locale) {
		if (bundleManager == null) {
			return BundleKeys.ERROR_EMPTY_VALUE;
		}
		bundleManager.setBundle(BundleType.ERRORS);
		return bundleManager.getMessage(
				BundleKeys.ERROR_EMPTY_VALUE, null, locale);
	}

}