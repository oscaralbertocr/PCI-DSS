/*
 * GetTransactionValidator
 *  
 * GSI - Integración
 * Creado el: 19/09/2014
 *
 * Copyright (c) A Toda Hora S.A. Todos los derechos reservados
 * 
 * Este software es confidencial y es propietario de ATH, queda prohibido
 * su uso, reproducción y copia de manera parcial o permanente salvo autorización
 * expresa de A Toda Hora S.A o de quién represente sus derechos.
 */
package co.com.ath.pgw.util.validation.model;

import co.com.ath.pgw.bsn.dto.in.GetTransactionInDTO;
import co.com.ath.pgw.util.validation.ValidationException;

/**
 * Validación para los datos de entrada para la operación GetTransaction.
 *  
 * @author Andrés Mendez Juanias <proveedor_mamendez@ath.com.co>
 * @version 1.0
 * @created 19-sep-2014 03:22:41 p.m.
 */
public interface GetTransactionValidator {

	public void validate(GetTransactionInDTO inDTO) throws ValidationException;
	public void validateAgreement(String agrmId) throws ValidationException;

}