package co.com.ath.pgw.util.constants;

public enum AuditConstants {
	
	CREATETXPAY(1),
	FINALIZETXPAY(2),
	GETTXPAY(3),
	PSECOMMERCE(4),
	ATH(5),
	BUS_ATH(6),
	DEFAULT(7);
	
	private int id;
	
	private AuditConstants(int id) {
		this.id = id;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}
}	
