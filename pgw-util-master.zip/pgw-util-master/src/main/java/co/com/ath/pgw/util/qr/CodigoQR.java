package co.com.ath.pgw.util.qr;

import java.io.Serializable;

public class CodigoQR implements Serializable{

	private String tipoQR;
	private String codigoSeguridadQr;
	private String codigoQR;

	public CodigoQR() {
		super();
	}

	public String getTipoQR() {
		return tipoQR;
	}

	public void setTipoQR(String tipoQR) {
		this.tipoQR = tipoQR;
	}

	public String getCodigoSeguridadQr() {
		return codigoSeguridadQr;
	}

	public void setCodigoSeguridadQr(String codigoSeguridadQr) {
		this.codigoSeguridadQr = codigoSeguridadQr;
	}

	public String getCodigoQR() {
		return codigoQR;
	}

	public void setCodigoQR(String codigoQR) {
		this.codigoQR = codigoQR;
	}

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
}
