package co.com.ath.pgw.util.converter;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.text.Normalizer;
import java.util.zip.ZipEntry;
import java.util.zip.ZipOutputStream;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import co.com.ath.pgw.util.constants.CoreConstants;


/**
 * Clase con metodos utilitarios
 * 
 * @version 0.0.0 06/07/2017
 * @author Camilo Andres Bustamante <proveedor_cbustamant@ath.com.co>
 * 
 *  @IM717218
 *  <strong>Autor</strong>Camilo Bustamante</br>
 *  <strong>Descripcion</strong>Validación Consumo Banco</br>
 *  <strong>Numero de Cambios</strong>3</br>
 *  <strong>Identificador corto</strong>C01</br>
 *  
 */
public class Util {
	
	private static Logger logger = LoggerFactory.getLogger(Util.class);
	
	/**
	 * Ejecuta de manera segura el cierre del objeto FileInputStream de entrada.
	 * 
	 * @param foo
	 */
	public static void safeClose(FileInputStream foo) {
		if (foo != null) {
			try {
				foo.close();
			} catch (IOException ex) {
				logger.info("No fue posible cerrar el FileInputStream.\n{}", ex.getLocalizedMessage());
			}
		}
	}
	
	/**
	 * Ejecuta de manera segura el cierre del objeto FileInputStream de entrada.
	 * 
	 * @param foo
	 */
	public static void safeClose(FileOutputStream foo) {
		if (foo != null) {
			try {
				foo.close();
			} catch (IOException ex) {
				logger.info("No fue posible cerrar el FileOutputStream.\n{}", ex.getLocalizedMessage());
			}
		}
	}

	/**
	 * Ejecuta de manera segura el cierre del objeto BufferedReader de entrada.
	 * 
	 * @param foo
	 */
	public static void safeClose(BufferedReader foo) {
		if (foo != null) {
			try {
				foo.close();
			} catch (IOException ex) {
				logger.info("No fue posible cerrar el BufferedReader.\n{}", ex.getLocalizedMessage());
			}
		}
	}
	
	/**
	 * Ejecuta de manera segura el cierre del objeto ZipOutputStream de entrada.
	 * 
	 * @param foo
	 */
	public static void safeClose(ZipOutputStream foo) {
		if (foo != null) {
			try {
				foo.closeEntry();
				foo.close();
			} catch (IOException ex) {
				logger.info("No fue posible cerrar el ZipOutputStream.\n{}", ex.getLocalizedMessage());
			}
		}
	}
	
	/**
	 * Elimina acentos del texto de entrada.
	 * 
	 * @param text
	 * @return
	 */
	public static String normalize(String text){
		
		String newText = text; 
		
		try {
			newText = Normalizer.normalize(text, Normalizer.Form.NFD).replaceAll("[^\\p{ASCII}]", "");
		} catch (Exception e) {
			logger.info("No fue posible Normalizar el texto: {}.\n{}", text, e.getLocalizedMessage());
		} 
		
		return newText;
	}
	
	/**
	 * Se encarga de comprimir un archivo a ZIP
	 * 
	 * @param archivoOrigen		Nombre del archivo que se desea comprimir
	 * @param urlOrigen			Url del archivoOrigen 
	 * @param archivoDestino	Nombre del archivo ZIP que se desea generar
	 * @param urlDestino		Url del archivoDestino
	 * 
	 * @return	Indica si el archivo se genero
	 *  
	 */
	public boolean generaZip(String archivoOrigen, String urlOrigen,
			String archivoDestino, String urlDestino){
		
		logger.info("Comprimiendo archivo: {}", archivoOrigen);

		String separador = CoreConstants.SEPARADOR;
		
		byte[]buffer = new byte[1024];
		ZipOutputStream zipOutputStream = null;
		FileInputStream fileInputStream = null;
		
		try {

			zipOutputStream = new ZipOutputStream(new FileOutputStream(urlDestino + separador + archivoDestino));
			zipOutputStream.putNextEntry(new ZipEntry(archivoOrigen));
			zipOutputStream.setMethod(ZipOutputStream.DEFLATED);
			zipOutputStream.setLevel(5);

			fileInputStream = new FileInputStream(new File(urlOrigen + separador + archivoOrigen));

			int len = 0;
			while ((len = fileInputStream.read(buffer)) > 0)
				zipOutputStream.write(buffer, 0, len);

			logger.info("Archivo generado: {} en la ruta: {}", archivoDestino, urlDestino);
			return true;
			
		} catch (Exception e) {
			logger.info("Error en la compresion de archivo ZIP: {}", e.getMessage());
			return false;
		} finally{
			
			if(null!=fileInputStream)
				safeClose(fileInputStream);
			
			if(null!=zipOutputStream)
				safeClose(zipOutputStream);
		}
	}
	
	/**INICIO-C01**/
	/**
	 * Se encarga de retirar los ceros a la izquierda de un Codigo Nura
	 * 
	 * @param NuraCode
	 * @return
	 */
	public static String getCleanNuraCode(String nuraCode){
		return nuraCode.replaceFirst("^0*", "");
	}
	/**FIN-C01**/
	
	/**INICIO-C01**/
	public static boolean esConvenioObligacion(String nuraCode) {
		
		nuraCode = Util.getCleanNuraCode(nuraCode);
		nuraCode = nuraCode.toUpperCase();
		
		if ( nuraCode.startsWith(CoreConstants.NURA_CODE_OBLIGATION) ) {
			logger.info("El convenio {} es Obligacion.", nuraCode);
			return true;
		} else { 
			return false;
		}
	}
	/**FIN-C01**/

	/**INICIO-C01**/
	public static boolean esConvenioCPV(String nuraCode) {
		
		nuraCode = Util.getCleanNuraCode(nuraCode);
		nuraCode = nuraCode.toUpperCase();
		
		if ( nuraCode.startsWith(CoreConstants.NURA_CODE_CPV) ) {
			logger.info("El convenio {} es CPV.", nuraCode);
			return true;
		} else { 
			return false;
		}
	}
	/**FIN-C01**/
	
	/**
     * Se encarga de cortar por Derecha los caracteres de un texto.
     *  
     * @param texto
     * @param limite
     * @return
     */
	public static String cortaDerechaTexto(String texto, int limite) {
		if (texto.length() > limite)    
    		texto = texto.substring(texto.length()-limite, texto.length());
		return texto;
	}

}