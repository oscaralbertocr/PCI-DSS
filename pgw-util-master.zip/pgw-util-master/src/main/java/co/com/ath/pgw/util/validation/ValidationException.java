/*
 * ValidationException
 *
 * GSI - Integración
 * Creado el: 5 de septiembre de 2014
 *
 * Copyright (c) A Toda Hora S.A. Todos los derechos reservados
 *
 * Este software es confidencial y es propietario de ATH, queda prohibido
 * su uso, reproducción y copia de manera parcial o permanente salvo autorización
 * expresa de A Toda Hora S.A o de quién represente sus derechos.
 */
package co.com.ath.pgw.util.validation;

/**
 * Excepción que es lanzada cuando se realiza una validación de un atributo de un
 * objeto de negocio.
 * 
 * @author proveedor_zagarcia
 * @version 1.0 08 Sep 2014
 * @since 1.0
 */
public class ValidationException extends Exception {

	/**
	 * Serial autogenerado
	 */
	private static final long serialVersionUID = -7054015732773268477L;
	
	/**
	 * Código de error asociado a la excepción
	 */
	private int errorCode;

	/**
	 * Construye una excepción de validación con un mensaje de error
	 * 
	 * @param message	Mensaje de error
	 * @param errorCode	Tipo de error de validación
	 */
	public ValidationException(String message, int errorCode){
		super(message);
		this.errorCode = errorCode;
	}

	/**
	 * Construye una excepción de validación con un mensaje de error
	 * 
	 * @param message	Mensaje de error
	 * @param errorCode	Tipo de error de validación
	 * @param cause		Causa de la excepción
	 */
	public ValidationException(String message, int errorCode, Throwable cause){
		super(message, cause);
		this.errorCode = errorCode;
	}

	/**
	 * Retorna el código de error asociado a la excepción
	 */
	public int getErrorCode(){
		return errorCode;
	}

}