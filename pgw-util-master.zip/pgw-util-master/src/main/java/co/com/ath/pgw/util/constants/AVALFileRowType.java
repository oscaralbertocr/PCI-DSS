/*
 * AVALFileRowType
 *  
 * GSI - Integración
 * Creado el: 17/12/2014
 *
 * Copyright (c) A Toda Hora S.A. Todos los derechos reservados
 * 
 * Este software es confidencial y es propietario de ATH, queda prohibido
 * su uso, reproducción y copia de manera parcial o permanente salvo autorización
 * expresa de A Toda Hora S.A o de quién represente sus derechos.
 */
package co.com.ath.pgw.util.constants;

/**
 * Class description goes here...
 *
 * @author Andrés Méndez Juanias <proveedor_mamendez@ath.com.co> 
 * @version 1.0 17/12/2014
 * @since 1.0
 */
public enum AVALFileRowType {
	
	HEADER("01"),
	BATCH("05"),
	DETAIL("06"),
	CONTROL_BATCH("08"),
	FOOTER("09");
	
	private String code;
	
	private AVALFileRowType(String code){
		this.code = code;
	}

	/**
	 * Método encargado de recuperar el valor del atributo code.
	 * @return El atributo code asociado a la clase.
	 */
	public String getCode() {
		return code;
	}

	/**
	 * Método encargado de actualizar el atributo code.
	 * @param code Nuevo valor para code.
	 */
	public void setCode(String code) {
		this.code = code;
	}
}
