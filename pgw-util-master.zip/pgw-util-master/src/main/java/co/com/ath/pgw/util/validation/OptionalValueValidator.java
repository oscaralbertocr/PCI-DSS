/*
 * OptionalValueValidator
 *
 * GSI - Integración
 * Creado el: 5 de septiembre de 2014
 *
 * Copyright (c) A Toda Hora S.A. Todos los derechos reservados
 *
 * Este software es confidencial y es propietario de ATH, queda prohibido
 * su uso, reproducción y copia de manera parcial o permanente salvo autorización
 * expresa de A Toda Hora S.A o de quién represente sus derechos.
 */
package co.com.ath.pgw.util.validation;

import java.util.Locale;

/**
 * Realiza la validación del atributo si y solo si el valor del atributo no es
 * nulo. La validación la realiza llamando a su validador interno cuando el valor
 * de la referencia no es nulo.
 * <br/><br/>
 * Este validador está diseñado como ayuda para validar objetos que se han 
 * definido como opcionales.
 * 
 * @author proveedor_zagarcia
 * @version 1.0 05 Sep 2014
 * @since 1.0
 */
public class OptionalValueValidator extends ObjectValidator {

	/**
	 * Construye el validador especificando el validador interno.
	 */
	public OptionalValueValidator(ObjectValidator validator){
		super(validator);
	}

	@Override
	protected void doValidate(Object object, Locale locale){
		if (object == null || object.toString().trim().length() == 0) {
			internalValidator = null;
		}
	}

}