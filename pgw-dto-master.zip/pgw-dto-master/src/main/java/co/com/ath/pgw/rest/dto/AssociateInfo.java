package co.com.ath.pgw.rest.dto;

import java.io.Serializable;
import com.fasterxml.jackson.annotation.JsonProperty;



public class AssociateInfo implements Serializable
{

    @JsonProperty("AstName")
    private String astName;
    @JsonProperty("ContactInfo")
    private ContactInfo contactInfo;
    @JsonProperty("AstType")
    private String astType;
    @JsonProperty("PersonInfo")
    private PersonInfo personInfo;
    private final static long serialVersionUID = -8794208138220366071L;

    
    public String getAstName() {
        return astName;
    }

   
    public void setAstName(String astName) {
        this.astName = astName;
    }

  
    public ContactInfo getContactInfo() {
        return contactInfo;
    }

    
    public void setContactInfo(ContactInfo contactInfo) {
        this.contactInfo = contactInfo;
    }


    public String getAstType() {
        return astType;
    }

    
    public void setAstType(String astType) {
        this.astType = astType;
    }

 
    public PersonInfo getPersonInfo() {
        return personInfo;
    }


    public void setPersonInfo(PersonInfo personInfo) {
        this.personInfo = personInfo;
    }


}
