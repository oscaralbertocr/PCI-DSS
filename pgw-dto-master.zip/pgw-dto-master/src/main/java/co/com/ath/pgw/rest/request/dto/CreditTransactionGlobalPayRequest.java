package co.com.ath.pgw.rest.request.dto;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonProperty;

import co.com.ath.pgw.core.logging.util.XMLUtil;
import co.com.ath.pgw.rest.dto.CustInfo;
import co.com.ath.pgw.rest.dto.CustPayeeInfo;
import co.com.ath.pgw.rest.dto.PmtStatus;
import co.com.ath.pgw.rest.dto.RefInfo;

public class CreditTransactionGlobalPayRequest implements Serializable {

	@JsonProperty("CustPayeeInfo")
	private CustPayeeInfo custPayeeInfo;
	@JsonProperty("CustInfo")
	private CustInfo custInfo;
	@JsonProperty("RefInfo")
	private List<RefInfo> refInfo = null;
	@JsonProperty("PmtStatus")
	private PmtStatus pmtStatus;
	private static final long serialVersionUID = 4266626717525345391L;

	public CustPayeeInfo getCustPayeeInfo() {
		return custPayeeInfo;
	}

	public void setCustPayeeInfo(CustPayeeInfo custPayeeInfo) {
		this.custPayeeInfo = custPayeeInfo;
	}

	public CustInfo getCustInfo() {
		return custInfo;
	}

	public void setCustInfo(CustInfo custInfo) {
		this.custInfo = custInfo;
	}

	public List<RefInfo> getRefInfo() {
		if (refInfo == null) {
			refInfo = new ArrayList<RefInfo>();
		}
		return refInfo;
	}

	public void setRefInfo(List<RefInfo> refInfo) {
		this.refInfo = refInfo;
	}

	public PmtStatus getPmtStatus() {
		return pmtStatus;
	}

	public void setPmtStatus(PmtStatus pmtStatus) {
		this.pmtStatus = pmtStatus;
	}
	
	@Override
	public String toString() {
		XMLUtil<CreditTransactionGlobalPayRequest> util = new XMLUtil<CreditTransactionGlobalPayRequest>();
		return util.convertObjectToJson(this);
	}

}