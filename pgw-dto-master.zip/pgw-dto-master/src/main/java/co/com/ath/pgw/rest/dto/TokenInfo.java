package co.com.ath.pgw.rest.dto;

import java.io.Serializable;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.Pattern;

import com.fasterxml.jackson.annotation.JsonProperty;

import co.com.ath.pgw.rest.util.ConstantFormat;

public class TokenInfo implements Serializable {

	@JsonProperty("Token")
	@NotBlank
	@Pattern( regexp = ConstantFormat.FORMAT_NUMEROS_LETRAS, message = ConstantFormat.MESSAGE_CARACTER_NO_VALIDOS)
	private String token;
	
	@JsonProperty("TokenType")
	@NotBlank
	@Pattern( regexp = ConstantFormat.FORMAT_SOLO_LETRAS, message = ConstantFormat.MESSAGE_CARACTER_NO_VALIDOS)
	private String tokenType;
	
	private static final long serialVersionUID = 5831828677738276934L;

	public String getToken() {
		return token;
	}

	public void setToken(String token) {
		this.token = token;
	}

	public String getTokenType() {
		return tokenType;
	}

	public void setTokenType(String tokenType) {
		this.tokenType = tokenType;
	}

}
