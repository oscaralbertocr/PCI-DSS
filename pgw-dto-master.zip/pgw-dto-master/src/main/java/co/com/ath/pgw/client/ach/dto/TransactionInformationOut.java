
package co.com.ath.pgw.client.ach.dto;

import java.math.BigDecimal;
import java.math.BigInteger;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlSchemaType;
import javax.xml.bind.annotation.XmlType;
import javax.xml.datatype.XMLGregorianCalendar;

import co.com.ath.pgw.core.logging.util.XMLUtil;


/**
 * <p>Clase Java para TransactionInformationOut complex type.
 * 
 * <p>El siguiente fragmento de esquema especifica el contenido que se espera que haya en esta clase.
 * 
 * <pre>
 * &lt;complexType name="TransactionInformationOut">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="TicketID" type="{http://www.w3.org/2001/XMLSchema}nonNegativeInteger" minOccurs="0"/>
 *         &lt;element name="trazabilityCode" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="EntityCode" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="transactionValue" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="VatValue" type="{http://www.w3.org/2001/XMLSchema}decimal" minOccurs="0"/>
 *         &lt;element name="SoliciteDate" type="{http://www.w3.org/2001/XMLSchema}dateTime" minOccurs="0"/>
 *         &lt;element name="BankProcessDate" type="{http://www.w3.org/2001/XMLSchema}dateTime" minOccurs="0"/>
 *         &lt;element name="transactionCycle" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="transactionState" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="returnCode" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "TransactionInformationOut", propOrder = {
    "ticketID",
    "trazabilityCode",
    "entityCode",
    "transactionValue",
    "vatValue",
    "soliciteDate",
    "bankProcessDate",
    "transactionCycle",
    "transactionState",
    "returnCode"
})
@XmlRootElement
public class TransactionInformationOut {

    @XmlElement(name = "TicketID")
    @XmlSchemaType(name = "nonNegativeInteger")
    protected BigInteger ticketID;
    protected String trazabilityCode;
    @XmlElement(name = "EntityCode")
    protected String entityCode;
    protected String transactionValue;
    @XmlElement(name = "VatValue")
    protected BigDecimal vatValue;
    @XmlElement(name = "SoliciteDate")
    @XmlSchemaType(name = "dateTime")
    protected XMLGregorianCalendar soliciteDate;
    @XmlElement(name = "BankProcessDate")
    @XmlSchemaType(name = "dateTime")
    protected XMLGregorianCalendar bankProcessDate;
    protected String transactionCycle;
    protected String transactionState;
    protected String returnCode;

    /**
     * Obtiene el valor de la propiedad ticketID.
     * 
     * @return
     *     possible object is
     *     {@link BigInteger }
     *     
     */
    public BigInteger getTicketID() {
        return ticketID;
    }

    /**
     * Define el valor de la propiedad ticketID.
     * 
     * @param value
     *     allowed object is
     *     {@link BigInteger }
     *     
     */
    public void setTicketID(BigInteger value) {
        this.ticketID = value;
    }

    /**
     * Obtiene el valor de la propiedad trazabilityCode.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getTrazabilityCode() {
        return trazabilityCode;
    }

    /**
     * Define el valor de la propiedad trazabilityCode.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setTrazabilityCode(String value) {
        this.trazabilityCode = value;
    }

    /**
     * Obtiene el valor de la propiedad entityCode.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getEntityCode() {
        return entityCode;
    }

    /**
     * Define el valor de la propiedad entityCode.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setEntityCode(String value) {
        this.entityCode = value;
    }

    /**
     * Obtiene el valor de la propiedad transactionValue.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getTransactionValue() {
        return transactionValue;
    }

    /**
     * Define el valor de la propiedad transactionValue.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setTransactionValue(String value) {
        this.transactionValue = value;
    }

    /**
     * Obtiene el valor de la propiedad vatValue.
     * 
     * @return
     *     possible object is
     *     {@link BigDecimal }
     *     
     */
    public BigDecimal getVatValue() {
        return vatValue;
    }

    /**
     * Define el valor de la propiedad vatValue.
     * 
     * @param value
     *     allowed object is
     *     {@link BigDecimal }
     *     
     */
    public void setVatValue(BigDecimal value) {
        this.vatValue = value;
    }

    /**
     * Obtiene el valor de la propiedad soliciteDate.
     * 
     * @return
     *     possible object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public XMLGregorianCalendar getSoliciteDate() {
        return soliciteDate;
    }

    /**
     * Define el valor de la propiedad soliciteDate.
     * 
     * @param value
     *     allowed object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public void setSoliciteDate(XMLGregorianCalendar value) {
        this.soliciteDate = value;
    }

    /**
     * Obtiene el valor de la propiedad bankProcessDate.
     * 
     * @return
     *     possible object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public XMLGregorianCalendar getBankProcessDate() {
        return bankProcessDate;
    }

    /**
     * Define el valor de la propiedad bankProcessDate.
     * 
     * @param value
     *     allowed object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public void setBankProcessDate(XMLGregorianCalendar value) {
        this.bankProcessDate = value;
    }

    /**
     * Obtiene el valor de la propiedad transactionCycle.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getTransactionCycle() {
        return transactionCycle;
    }

    /**
     * Define el valor de la propiedad transactionCycle.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setTransactionCycle(String value) {
        this.transactionCycle = value;
    }

    /**
     * Obtiene el valor de la propiedad transactionState.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getTransactionState() {
        return transactionState;
    }

    /**
     * Define el valor de la propiedad transactionState.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setTransactionState(String value) {
        this.transactionState = value;
    }

    /**
     * Obtiene el valor de la propiedad returnCode.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getReturnCode() {
        return returnCode;
    }

    /**
     * Define el valor de la propiedad returnCode.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setReturnCode(String value) {
        this.returnCode = value;
    }

	@Override
	public String toString() {
		XMLUtil<TransactionInformationOut> requestParser = new XMLUtil<TransactionInformationOut>();
		return requestParser.convertObjectToXml(this);
	}

}
