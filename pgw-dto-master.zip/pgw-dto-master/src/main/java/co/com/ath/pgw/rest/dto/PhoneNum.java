
package co.com.ath.pgw.rest.dto;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonProperty;

public class PhoneNum implements Serializable
{
	@JsonProperty("PhoneType")
    private String phoneType;
	
	@JsonProperty("Phone")
    private String phone;
	
    private final static long serialVersionUID = -6929535947425970242L;

    public String getPhoneType() {
        return phoneType;
    }

    public void setPhoneType(String phoneType) {
        this.phoneType = phoneType;
    }

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

}
