
package co.com.ath.pgw.in.model;

/**
 * <p>
 * Clase Java para CardInfoUser_Type.xsd complex type.
 * 
 * <p>
 * El siguiente fragmento de esquema especifica el contenido que se espera que
 * haya en esta clase.
 * 
 * <pre>
 * &lt;complexType name="CardInfoUser_Type.xsd"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element ref="{urn://grupoaval.com/xsd/ifx/}CardLogicalData"/&gt;
 *         &lt;element ref="{urn://grupoaval.com/xsd/ifx/}InstalamentsNum"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
public class CardInfoUserTypeXsd {

	protected CardLogicalDataType cardLogicalData = new CardLogicalDataType();

	protected String instalamentsNum;

	/**
	 * Obtiene el valor de la propiedad cardLogicalData.
	 * 
	 * @return possible object is {@link CardLogicalDataType }
	 * 
	 */
	public CardLogicalDataType getCardLogicalData() {
		return cardLogicalData;
	}

	/**
	 * Define el valor de la propiedad cardLogicalData.
	 * 
	 * @param value allowed object is {@link CardLogicalDataType }
	 * 
	 */
	public void setCardLogicalData(CardLogicalDataType value) {
		this.cardLogicalData = value;
	}

	/**
	 * Obtiene el valor de la propiedad instalamentsNum.
	 * 
	 * @return possible object is {@link String }
	 * 
	 */
	public String getInstalamentsNum() {
		return instalamentsNum;
	}

	/**
	 * Define el valor de la propiedad instalamentsNum.
	 * 
	 * @param value allowed object is {@link String }
	 * 
	 */
	public void setInstalamentsNum(String value) {
		this.instalamentsNum = value;
	}

}
