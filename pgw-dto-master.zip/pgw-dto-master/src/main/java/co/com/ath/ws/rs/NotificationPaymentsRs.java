package co.com.ath.ws.rs;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.fasterxml.jackson.annotation.JsonProperty;

import co.com.ath.pgw.core.logging.util.XMLUtil;
import co.com.ath.ws.rs.objects.MsgRsHdr;
import co.com.ath.ws.rs.objects.MsgRsHdrNotification;

@JsonInclude(Include.NON_NULL)
public class NotificationPaymentsRs implements Serializable {

	private static final long serialVersionUID = 1L;

	@JsonProperty("msgRsHdr")
	private MsgRsHdrNotification msgRsHdr;

	public MsgRsHdrNotification getMsgRsHdr() {
		return msgRsHdr;
	}

	public void setMsgRsHdr(MsgRsHdrNotification msgRsHdr) {
		this.msgRsHdr = msgRsHdr;
	}

	@Override
	public String toString() {
		XMLUtil<NotificationPaymentsRs> util = new XMLUtil<NotificationPaymentsRs>();
		return util.convertObjectToJson(this);
	}

}
