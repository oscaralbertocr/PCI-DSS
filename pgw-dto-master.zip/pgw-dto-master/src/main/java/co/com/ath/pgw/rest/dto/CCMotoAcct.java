
package co.com.ath.pgw.rest.dto;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonProperty;

public class CCMotoAcct implements Serializable {

	@JsonProperty("CardVrfyData")
	private String cardVrfyData;
	
	@JsonProperty("ExpDt")
	private String expDt;
	
	@JsonProperty("Brand")
	private String brand;
	
	@JsonProperty("CardMagData")
	private CardMagData cardMagData;
	
	private static final long serialVersionUID = 8745753424882844269L;

	public String getCardVrfyData() {
		return cardVrfyData;
	}

	public void setCardVrfyData(String cardVrfyData) {
		this.cardVrfyData = cardVrfyData;
	}

	public String getExpDt() {
		return expDt;
	}

	public void setExpDt(String expDt) {
		this.expDt = expDt;
	}

	public String getBrand() {
		return brand;
	}

	public void setBrand(String brand) {
		this.brand = brand;
	}

}
