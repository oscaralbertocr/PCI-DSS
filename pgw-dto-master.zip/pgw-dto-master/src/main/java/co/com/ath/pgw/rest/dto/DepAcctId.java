package co.com.ath.pgw.rest.dto;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonProperty;



public class DepAcctId implements Serializable
{

    @JsonProperty("AcctType")
    private String acctType;
    @JsonProperty("AcctKey")
    private String acctKey;
    @JsonProperty("Desc")
    private String desc;
    private final static long serialVersionUID = -8764075782498431613L;

   
    public String getAcctType() {
        return acctType;
    }

    
    public void setAcctType(String acctType) {
        this.acctType = acctType;
    }

    public String getAcctKey() {
        return acctKey;
    }

 
    public void setAcctKey(String acctKey) {
        this.acctKey = acctKey;
    }


	public String getDesc() {
		return desc;
	}


	public void setDesc(String desc) {
		this.desc = desc;
	}
    
    



}
