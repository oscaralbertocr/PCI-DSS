
package co.com.ath.pgw.client.tokenize.model;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlSeeAlso;
import javax.xml.bind.annotation.XmlType;

import co.com.ath.pgw.client.tokenize.dto.TokenizedDataRsType;


/**
 * <p>Clase Java para SvcRs_Type complex type.
 * 
 * <p>El siguiente fragmento de esquema especifica el contenido que se espera que haya en esta clase.
 * 
 * <pre>
 * &lt;complexType name="SvcRs_Type"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element ref="{urn://ath.com.co/xsd/common/}Status"/&gt;
 *         &lt;element ref="{urn://ath.com.co/xsd/common/}RqUID"/&gt;
 *         &lt;element ref="{urn://ath.com.co/xsd/common/}ApprovalId" minOccurs="0"/&gt;
 *         &lt;element ref="{urn://ath.com.co/xsd/common/}TokenizedDataInfoRs"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "SvcRs_Type", propOrder = {
    "status",
    "rqUID",
    "approvalId",
    "tokenizedDataInfoRs"
})
@XmlSeeAlso({
    TokenizedDataRsType.class
})
public class SvcRsType {

    @XmlElement(name = "Status", required = true, namespace = "urn://ath.com.co/xsd/common/")
    protected StatusType status;
    @XmlElement(name = "RqUID", namespace = "urn://ath.com.co/xsd/common/")
    protected long rqUID;
    @XmlElement(name = "ApprovalId", namespace = "urn://ath.com.co/xsd/common/")
    protected String approvalId;
    @XmlElement(name = "TokenizedDataInfoRs", required = true, namespace = "urn://ath.com.co/xsd/common/")
    protected TokenizedDataInfoRsType tokenizedDataInfoRs;

    /**
     * Obtiene el valor de la propiedad status.
     * 
     * @return
     *     possible object is
     *     {@link StatusType }
     *     
     */
    public StatusType getStatus() {
        return status;
    }

    /**
     * Define el valor de la propiedad status.
     * 
     * @param value
     *     allowed object is
     *     {@link StatusType }
     *     
     */
    public void setStatus(StatusType value) {
        this.status = value;
    }

    /**
     * Obtiene el valor de la propiedad rqUID.
     * 
     */
    public long getRqUID() {
        return rqUID;
    }

    /**
     * Define el valor de la propiedad rqUID.
     * 
     */
    public void setRqUID(long value) {
        this.rqUID = value;
    }

    /**
     * Obtiene el valor de la propiedad approvalId.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getApprovalId() {
        return approvalId;
    }

    /**
     * Define el valor de la propiedad approvalId.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setApprovalId(String value) {
        this.approvalId = value;
    }

    /**
     * Obtiene el valor de la propiedad tokenizedDataInfoRs.
     * 
     * @return
     *     possible object is
     *     {@link TokenizedDataInfoRsType }
     *     
     */
    public TokenizedDataInfoRsType getTokenizedDataInfoRs() {
        return tokenizedDataInfoRs;
    }

    /**
     * Define el valor de la propiedad tokenizedDataInfoRs.
     * 
     * @param value
     *     allowed object is
     *     {@link TokenizedDataInfoRsType }
     *     
     */
    public void setTokenizedDataInfoRs(TokenizedDataInfoRsType value) {
        this.tokenizedDataInfoRs = value;
    }

}
