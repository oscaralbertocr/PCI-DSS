
package co.com.ath.pgw.in.model;


/**
*
* @author camilo.bustamante@sophossolutions.com
* @version 1.0 03 Enero 2019
* @RQ31686 RBM_Integracion_Boton_TC_GlobalPay
* 
*/

/**
 * <p>Clase Java para InfoTransaccionResp_Type complex type.
 * 
 * <p>El siguiente fragmento de esquema especifica el contenido que se espera que haya en esta clase.
 * 
 * <pre>
 * &lt;complexType name="InfoTransaccionResp_Type">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element ref="{urn://ath.com.co/xsd/common/}IdTransaccionActual" minOccurs="0"/>
 *         &lt;element ref="{urn://ath.com.co/xsd/common/}UrlRBM" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
public class InfoTransaccionRespType {
    
    protected String idTransaccionActual;
    
    protected String urlRBM;

	public String getIdTransaccionActual() {
		return idTransaccionActual;
	}

	public void setIdTransaccionActual(String idTransaccionActual) {
		this.idTransaccionActual = idTransaccionActual;
	}

	public String getUrlRBM() {
		return urlRBM;
	}

	public void setUrlRBM(String urlRBM) {
		this.urlRBM = urlRBM;
	}

}
