package co.com.ath.pgw.rest.dto;

import java.io.Serializable;

import javax.validation.constraints.Pattern;

import com.fasterxml.jackson.annotation.JsonProperty;

import co.com.ath.pgw.rest.util.ConstantFormat;

public class CustNameAddTx implements Serializable {

	private static final long serialVersionUID = 1465469688037523149L;
	
	@JsonProperty("LastName")
	@Pattern( regexp = ConstantFormat.FORMAT_NOMBRE_FRONT, message = ConstantFormat.MESSAGE_CARACTER_NO_VALIDOS)
	private String lastName;
	
	@JsonProperty("FirstName")
	@Pattern( regexp = ConstantFormat.FORMAT_NOMBRE_FRONT, message = ConstantFormat.MESSAGE_CARACTER_NO_VALIDOS)
    private String firstName;
    
	@JsonProperty("Nickname")
	@Pattern( regexp = ConstantFormat.FORMAT_NOMBRE_FRONT, message = ConstantFormat.MESSAGE_CARACTER_NO_VALIDOS)
    private String nickname;
      
	@JsonProperty("LegalName")
	@Pattern( regexp = ConstantFormat.FORMAT_NOMBRE_FRONT, message = ConstantFormat.MESSAGE_CARACTER_NO_VALIDOS)
    private String legalName;

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getNickname() {
		return nickname;
	}

	public void setNickname(String nickname) {
		this.nickname = nickname;
	}

	public String getLegalName() {
		return legalName;
	}

	public void setLegalName(String legalName) {
		this.legalName = legalName;
	}


}
