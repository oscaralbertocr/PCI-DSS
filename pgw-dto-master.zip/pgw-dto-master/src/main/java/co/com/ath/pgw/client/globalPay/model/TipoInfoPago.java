
package co.com.ath.pgw.client.globalPay.model;

import java.math.BigDecimal;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlSchemaType;
import javax.xml.bind.annotation.XmlType;
import javax.xml.datatype.XMLGregorianCalendar;


/**
 * <p>Clase Java para TipoInfoPago complex type.
 * 
 * <p>El siguiente fragmento de esquema especifica el contenido que se espera que haya en esta clase.
 * 
 * <pre>
 * &lt;complexType name="TipoInfoPago"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="franquicia" type="{http://www.w3.org/2001/XMLSchema}string"/&gt;
 *         &lt;element name="tipoMedioDePago" type="{http://www.rbm.com.co/esb/globalpay/}TipoTipoMedioDePago"/&gt;
 *         &lt;element name="tipoCuenta" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="fechaTransaccion" type="{http://www.w3.org/2001/XMLSchema}dateTime"/&gt;
 *         &lt;element name="numeroAprobacion" type="{http://www.w3.org/2001/XMLSchema}string"/&gt;
 *         &lt;element name="montoTotal" type="{http://www.w3.org/2001/XMLSchema}decimal"/&gt;
 *         &lt;element name="costoTransaccion" type="{http://www.w3.org/2001/XMLSchema}decimal" minOccurs="0"/&gt;
 *         &lt;element name="idTransaccionAutorizador" type="{http://www.w3.org/2001/XMLSchema}long"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "TipoInfoPago", propOrder = {
    "franquicia",
    "tipoMedioDePago",
    "tipoCuenta",
    "fechaTransaccion",
    "numeroAprobacion",
    "montoTotal",
    "costoTransaccion",
    "idTransaccionAutorizador"
})
public class TipoInfoPago {

    @XmlElement(required = true)
    protected String franquicia;
    @XmlElement(required = true)
    @XmlSchemaType(name = "string")
    protected TipoTipoMedioDePago tipoMedioDePago;
    protected String tipoCuenta;
    @XmlElement(required = true)
    @XmlSchemaType(name = "dateTime")
    protected XMLGregorianCalendar fechaTransaccion;
    @XmlElement(required = true)
    protected String numeroAprobacion;
    @XmlElement(required = true)
    protected BigDecimal montoTotal;
    protected BigDecimal costoTransaccion;
    protected long idTransaccionAutorizador;

    /**
     * Obtiene el valor de la propiedad franquicia.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getFranquicia() {
        return franquicia;
    }

    /**
     * Define el valor de la propiedad franquicia.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setFranquicia(String value) {
        this.franquicia = value;
    }

    /**
     * Obtiene el valor de la propiedad tipoMedioDePago.
     * 
     * @return
     *     possible object is
     *     {@link TipoTipoMedioDePago }
     *     
     */
    public TipoTipoMedioDePago getTipoMedioDePago() {
        return tipoMedioDePago;
    }

    /**
     * Define el valor de la propiedad tipoMedioDePago.
     * 
     * @param value
     *     allowed object is
     *     {@link TipoTipoMedioDePago }
     *     
     */
    public void setTipoMedioDePago(TipoTipoMedioDePago value) {
        this.tipoMedioDePago = value;
    }

    /**
     * Obtiene el valor de la propiedad tipoCuenta.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getTipoCuenta() {
        return tipoCuenta;
    }

    /**
     * Define el valor de la propiedad tipoCuenta.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setTipoCuenta(String value) {
        this.tipoCuenta = value;
    }

    /**
     * Obtiene el valor de la propiedad fechaTransaccion.
     * 
     * @return
     *     possible object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public XMLGregorianCalendar getFechaTransaccion() {
        return fechaTransaccion;
    }

    /**
     * Define el valor de la propiedad fechaTransaccion.
     * 
     * @param value
     *     allowed object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public void setFechaTransaccion(XMLGregorianCalendar value) {
        this.fechaTransaccion = value;
    }

    /**
     * Obtiene el valor de la propiedad numeroAprobacion.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getNumeroAprobacion() {
        return numeroAprobacion;
    }

    /**
     * Define el valor de la propiedad numeroAprobacion.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setNumeroAprobacion(String value) {
        this.numeroAprobacion = value;
    }

    /**
     * Obtiene el valor de la propiedad montoTotal.
     * 
     * @return
     *     possible object is
     *     {@link BigDecimal }
     *     
     */
    public BigDecimal getMontoTotal() {
        return montoTotal;
    }

    /**
     * Define el valor de la propiedad montoTotal.
     * 
     * @param value
     *     allowed object is
     *     {@link BigDecimal }
     *     
     */
    public void setMontoTotal(BigDecimal value) {
        this.montoTotal = value;
    }

    /**
     * Obtiene el valor de la propiedad costoTransaccion.
     * 
     * @return
     *     possible object is
     *     {@link BigDecimal }
     *     
     */
    public BigDecimal getCostoTransaccion() {
        return costoTransaccion;
    }

    /**
     * Define el valor de la propiedad costoTransaccion.
     * 
     * @param value
     *     allowed object is
     *     {@link BigDecimal }
     *     
     */
    public void setCostoTransaccion(BigDecimal value) {
        this.costoTransaccion = value;
    }

    /**
     * Obtiene el valor de la propiedad idTransaccionAutorizador.
     * 
     */
    public long getIdTransaccionAutorizador() {
        return idTransaccionAutorizador;
    }

    /**
     * Define el valor de la propiedad idTransaccionAutorizador.
     * 
     */
    public void setIdTransaccionAutorizador(long value) {
        this.idTransaccionAutorizador = value;
    }

}
