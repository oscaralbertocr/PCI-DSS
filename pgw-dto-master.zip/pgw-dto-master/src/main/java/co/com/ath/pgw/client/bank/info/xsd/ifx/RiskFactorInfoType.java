
package co.com.ath.pgw.client.bank.info.xsd.ifx;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;

import co.com.ath.pgw.core.logging.util.XMLUtil;


/**
 * <p>Clase Java para RiskFactorInfo_Type complex type.
 * 
 * <p>El siguiente fragmento de esquema especifica el contenido que se espera que haya en esta clase.
 * 
 * <pre>
 * &lt;complexType name="RiskFactorInfo_Type">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element ref="{urn://grupoaval.com/xsd/ifx/}AuthFactor" minOccurs="0"/>
 *         &lt;element ref="{urn://grupoaval.com/xsd/ifx/}CustStatusCode" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "RiskFactorInfo_Type", propOrder = {
    "authFactor",
    "custStatusCode"
})
public class RiskFactorInfoType {

    @XmlElement(name = "AuthFactor")
    protected String authFactor;
    @XmlElement(name = "CustStatusCode")
    protected String custStatusCode;

    /**
     * Obtiene el valor de la propiedad authFactor.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getAuthFactor() {
        return authFactor;
    }

    /**
     * Define el valor de la propiedad authFactor.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setAuthFactor(String value) {
        this.authFactor = value;
    }

    /**
     * Obtiene el valor de la propiedad custStatusCode.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCustStatusCode() {
        return custStatusCode;
    }

    /**
     * Define el valor de la propiedad custStatusCode.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCustStatusCode(String value) {
        this.custStatusCode = value;
    }
    
    public String toString() {
    	XMLUtil<RiskFactorInfoType> requestParser = 
    							new XMLUtil<RiskFactorInfoType>();
		return requestParser.convertObjectToXml(this);
    }

}
