
package co.com.ath.pgw.rest.dto;

import java.io.Serializable;

import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.Pattern;

import com.fasterxml.jackson.annotation.JsonProperty;

import co.com.ath.pgw.rest.util.ConstantFormat;

public class AgreementAddTx implements Serializable
{

    @JsonProperty("AgrmId")
    @NotEmpty
    @Pattern( regexp = ConstantFormat.FORMAT_NUMEROS_LETRAS, message = ConstantFormat.MESSAGE_CARACTER_NO_VALIDOS)
    private String agrmId;
    
    @JsonProperty("CategCode")
    private String categCode;
    @JsonProperty("Name")
    private String name;
    @JsonProperty("NIT")
    private String nit;
    @JsonProperty("AgrmVfrCode")
    private String agrmVfrCode;
    @JsonProperty("ContactInfo")
    private ContactInfoAddTx contactInfo;
    @JsonProperty("Image")
    private ImageAddTx image;
    @JsonProperty("DepAcctId")
    private DepAcctIdAddTx depAcctId;
    private final static long serialVersionUID = -7749967594758311520L;


    public String getAgrmId() {
        return agrmId;
    }

    public void setAgrmId(String agrmId) {
        this.agrmId = agrmId;
    }

    public String getCategCode() {
		return categCode;
	}

	public void setCategCode(String categCode) {
		this.categCode = categCode;
	}

	public String getName() {
        return name;
    }
	
    public String getAgrmVfrCode() {
		return agrmVfrCode;
	}

	public void setAgrmVfrCode(String agrmVfrCode) {
		this.agrmVfrCode = agrmVfrCode;
	}


	public void setName(String name) {
        this.name = name;
    }

    public String getNit() {
        return nit;
    }

    public void setNit(String nit) {
        this.nit = nit;
    }

    public ContactInfoAddTx getContactInfo() {
        return contactInfo;
    }

    public void setContactInfo(ContactInfoAddTx contactInfo) {
        this.contactInfo = contactInfo;
    }

    public DepAcctIdAddTx getDepAcctId() {
        return depAcctId;
    }
 
    public void setDepAcctId(DepAcctIdAddTx depAcctId) {
        this.depAcctId = depAcctId;
    }

	public ImageAddTx getImage() {
		return image;
	}

	public void setImage(ImageAddTx image) {
		this.image = image;
	}
    
    

}

