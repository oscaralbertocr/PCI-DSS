
package co.com.ath.pgw.client.tokenize.dto;

import java.io.Serializable;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonProperty;

import co.com.ath.pgw.core.logging.util.XMLUtil;

public class TokenizeRequest implements Serializable {
	
	@JsonProperty("naeUser")
	private String naeUser;
	@JsonProperty("naePassword")
	private String naePassword;
	@JsonProperty("value")
	private String value;
	@JsonProperty("values")
	private List<String> values;
	@JsonProperty("format")
	private String format;
	@JsonProperty("groupID")
	private String groupID;
	@JsonProperty("keyName")
	private String keyName;
	@JsonProperty("clearTextSensitive")
	private String clearTextSensitive;
	@JsonProperty("version")
	private String version;
	private static final long serialVersionUID = 1L;

	public String getNaeUser() {
		return naeUser;
	}

	public void setNaeUser(String naeUser) {
		this.naeUser = naeUser;
	}

	public String getNaePassword() {
		return naePassword;
	}

	public void setNaePassword(String naePassword) {
		this.naePassword = naePassword;
	}

	public String getValue() {
		return value;
	}

	public void setValue(String value) {
		this.value = value;
	}

	public List<String> getValues() {
		return values;
	}

	public void setValues(List<String> values) {
		this.values = values;
	}

	public String getFormat() {
		return format;
	}

	public void setFormat(String format) {
		this.format = format;
	}

	public String getGroupID() {
		return groupID;
	}

	public void setGroupID(String groupID) {
		this.groupID = groupID;
	}

	public String getKeyName() {
		return keyName;
	}

	public void setKeyName(String keyName) {
		this.keyName = keyName;
	}

	public String getClearTextSensitive() {
		return clearTextSensitive;
	}

	public void setClearTextSensitive(String clearTextSensitive) {
		this.clearTextSensitive = clearTextSensitive;
	}

	public String getVersion() {
		return version;
	}

	public void setVersion(String version) {
		this.version = version;
	}

	@Override
	public String toString() {
		XMLUtil<TokenizeRequest> util = new XMLUtil<TokenizeRequest>();
		return util.convertObjectToJson(this);
	}

}
