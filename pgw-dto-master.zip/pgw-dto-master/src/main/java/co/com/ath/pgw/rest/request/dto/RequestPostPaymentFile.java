package co.com.ath.pgw.rest.request.dto;

import com.fasterxml.jackson.annotation.JsonProperty;

import co.com.ath.pgw.rest.dto.File;

public class RequestPostPaymentFile {

	@JsonProperty("File")
	private File file;

	public File getFile() {
		return file;
	}

	public void setFile(File file) {
		this.file = file;
	}

	@Override
	public String toString() {
		return "RequestPutPaymentFile [file=" + file + "]";
	}

	
}
