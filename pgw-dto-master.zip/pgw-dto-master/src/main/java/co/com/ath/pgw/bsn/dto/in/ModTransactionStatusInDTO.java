/*
 * ModTransactionStatusInDTO
 *  
 * GSI - Integración
 * Creado el: 22/09/2014
 *
 * Copyright (c) A Toda Hora S.A. Todos los derechos reservados
 * 
 * Este software es confidencial y es propietario de ATH, queda prohibido
 * su uso, reproducción y copia de manera parcial o permanente salvo autorización
 * expresa de A Toda Hora S.A o de quién represente sus derechos.
 */
package co.com.ath.pgw.bsn.dto.in;

import co.com.ath.pgw.bsn.model.bo.TransactionBO;
import co.com.ath.pgw.core.logging.util.XMLUtil;


/**
 * DTO de entrada con la información para la operación ModTransactionStatus.
 *
 * @author Andrés Méndez Juanias <proveedor_mamendez@ath.com.co>
 * @version 1.0 22/09/2014
 * @since 1.0
 */
public class ModTransactionStatusInDTO extends CommonObjectInDTO {

	private TransactionBO transactionBO;
	
	/**
	 * Método encargado de recuperar el valor del atributo transactionBO.
	 * @return El atributo transactionBO asociado a la clase.
	 */
	public TransactionBO getTransactionBO() {
		return transactionBO;
	}

	/**
	 * Método encargado de actualizar el atributo transactionBO.
	 * @param transactionBO Nuevo valor para transactionBO.
	 */
	public void setTransactionBO(TransactionBO transactionBO) {
		this.transactionBO = transactionBO;
	}

	@Override
	public String toString() {
		XMLUtil<ModTransactionStatusInDTO> requestParser = new XMLUtil<ModTransactionStatusInDTO>();
		return requestParser.convertObjectToXml(this);
	}
	
}
