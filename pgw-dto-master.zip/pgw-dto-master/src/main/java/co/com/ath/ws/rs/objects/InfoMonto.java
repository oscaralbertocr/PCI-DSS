package co.com.ath.ws.rs.objects;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonProperty;

public class InfoMonto implements Serializable{

	private static final long serialVersionUID = 6972135134146216839L;
	
	@JsonProperty("valorTotal")
    private String valorTotal;
	
	@JsonProperty("iva")
    private String iva;
	
	@JsonProperty("impoconsumo")
    private String impoconsumo;
	
	@JsonProperty("montoAdicional")
    private String montoAdicional;
	
	@JsonProperty("propina")
    private String propina;

	public String getValorTotal() {
		return valorTotal;
	}

	public void setValorTotal(String valorTotal) {
		this.valorTotal = valorTotal;
	}

	public String getIva() {
		return iva;
	}

	public void setIva(String iva) {
		this.iva = iva;
	}

	public String getImpoconsumo() {
		return impoconsumo;
	}

	public void setImpoconsumo(String impoconsumo) {
		this.impoconsumo = impoconsumo;
	}

	public String getMontoAdicional() {
		return montoAdicional;
	}

	public void setMontoAdicional(String montoAdicional) {
		this.montoAdicional = montoAdicional;
	}

	public String getPropina() {
		return propina;
	}

	public void setPropina(String propina) {
		this.propina = propina;
	}
		
}
