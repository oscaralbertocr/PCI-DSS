
package co.com.ath.pgw.in.dto;

import co.com.ath.pgw.core.logging.util.XMLUtil;


/**
 * <p>Clase Java para anonymous complex type.
 * 
 * <p>El siguiente fragmento de esquema especifica el contenido que se espera que haya en esta clase.
 * 
 * <pre>
 * &lt;complexType&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element ref="{urn://grupoaval.com/payments/v1/}PSETransactionAddRs"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
public class PSETransactionAddResponse {
    
    protected PSETransactionAddRsType pseTransactionAddRs = new PSETransactionAddRsType();

    /**
     * Obtiene el valor de la propiedad pseTransactionAddRs.
     * 
     * @return
     *     possible object is
     *     {@link PSETransactionAddRsType }
     *     
     */
    public PSETransactionAddRsType getPSETransactionAddRs() {
        return pseTransactionAddRs;
    }

    /**
     * Define el valor de la propiedad pseTransactionAddRs.
     * 
     * @param value
     *     allowed object is
     *     {@link PSETransactionAddRsType }
     *     
     */
    public void setPSETransactionAddRs(PSETransactionAddRsType value) {
        this.pseTransactionAddRs = value;
    }

    
    @Override
   	public String toString() {
   		XMLUtil<PSETransactionAddResponse> requestParser = 
   				new XMLUtil<PSETransactionAddResponse>();
   		return requestParser.convertObjectToXml(this);
   	}
}
