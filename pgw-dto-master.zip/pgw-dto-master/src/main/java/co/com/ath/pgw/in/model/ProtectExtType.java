package co.com.ath.pgw.in.model;


import org.apache.commons.lang.builder.ToStringBuilder;
import org.apache.cxf.xjc.runtime.JAXBToStringStyle;
import org.xml.sax.Locator;

/**
 * <p>Clase Java para ProtectExt_Type complex type.
 * 
 * <p>El siguiente fragmento de esquema especifica el contenido que se espera que haya en esta clase.
 * 
 * <pre>
 * &lt;complexType name="ProtectExt_Type"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element ref="{urn://ath.com.co/xsd/common/}Data"/&gt;
 *         &lt;element ref="{urn://ath.com.co/xsd/common/}Format" minOccurs="0"/&gt;
 *         &lt;element ref="{urn://ath.com.co/xsd/common/}StrRefine" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
public class ProtectExtType
    implements  Cloneable 
{

    
    protected String data;
    
    protected String format;
    
    protected String strRefine;
    
    protected Locator locator;

    /**
     * Obtiene el valor de la propiedad data.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    
    public synchronized String getData() {
        return data;
    }

    /**
     * Define el valor de la propiedad data.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */    
    public synchronized void setData(String value) {
        this.data = value;
    }

    /**
     * Obtiene el valor de la propiedad format.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */    
    public synchronized String getFormat() {
        return format;
    }

    /**
     * Define el valor de la propiedad format.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    
    public synchronized void setFormat(String value) {
        this.format = value;
    }

    /**
     * Obtiene el valor de la propiedad strRefine.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    
    public synchronized String getStrRefine() {
        return strRefine;
    }

    /**
     * Define el valor de la propiedad strRefine.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    
    public synchronized void setStrRefine(String value) {
        this.strRefine = value;
    }

    /**
     * Generates a String representation of the contents of this type.
     * This is an extension method, produced by the 'ts' xjc plugin
     * 
     */
    @Override    
    public synchronized String toString() {
        return ToStringBuilder.reflectionToString(this, JAXBToStringStyle.SIMPLE_STYLE);
    }
    
    public synchronized Locator sourceLocation() {
        return locator;
    }

    public synchronized void setSourceLocation(Locator newLocator) {
        locator = newLocator;
    }

    @Override
	public Object clone() throws CloneNotSupportedException {
		return super.clone();
	}

}
