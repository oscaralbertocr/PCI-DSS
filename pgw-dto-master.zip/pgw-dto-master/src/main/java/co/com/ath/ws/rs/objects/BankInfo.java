package co.com.ath.ws.rs.objects;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonProperty;

public class BankInfo implements Serializable {

	private static final long serialVersionUID = 1L;

	@JsonProperty("BankId")
	private String bankId;

	public String getBankId() {
		return bankId;
	}

	public void setBankId(String bankId) {
		this.bankId = bankId;
	}

}
