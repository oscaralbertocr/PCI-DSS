
package co.com.ath.pgw.client.rbm.model;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlSchemaType;
import javax.xml.bind.annotation.XmlType;
import javax.xml.datatype.XMLGregorianCalendar;

/**
 * <p>
 * Clase Java para TipoInfoCompraResp complex type.
 * 
 * <p>
 * El siguiente fragmento de esquema especifica el contenido que se espera que
 * haya en esta clase.
 * 
 * <pre>
 * &lt;complexType name="TipoInfoCompraResp"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="fechaTransaccion" type="{http://www.w3.org/2001/XMLSchema}dateTime"/&gt;
 *         &lt;element name="fechaPosteo" type="{http://www.w3.org/2001/XMLSchema}date"/&gt;
 *         &lt;element name="numAprobacion" type="{http://www.rbm.com.co/esb/}TipoNumAprobacion"/&gt;
 *         &lt;element name="costoTransaccion" type="{http://www.rbm.com.co/esb/}TipoMonto" minOccurs="0"/&gt;
 *         &lt;element name="infoAdicional" type="{http://www.rbm.com.co/esb/}TipoInfoAdicional" maxOccurs="unbounded" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "infoCompraResp", propOrder = { "fechaTransaccion", "fechaPosteo", "numAprobacion",
		"costoTransaccion", "infoAdicional" }, namespace= "http://www.rbm.com.co/esb/comercio/compra/")
public class TipoInfoCompraResp {

	@XmlElement(namespace = "http://www.rbm.com.co/esb/comercio/compra/", name="fechaTransaccion")
	@XmlSchemaType(name = "dateTime")
	protected XMLGregorianCalendar fechaTransaccion;
	@XmlElement(namespace = "http://www.rbm.com.co/esb/comercio/compra/", name="fechaPosteo")
	@XmlSchemaType(name = "date")
	protected XMLGregorianCalendar fechaPosteo;
	@XmlElement(namespace = "http://www.rbm.com.co/esb/comercio/compra/", name="numAprobacion")
	protected String numAprobacion;
	@XmlElement(namespace = "http://www.rbm.com.co/esb/comercio/compra/", name="costoTransaccion")
	protected BigDecimal costoTransaccion;
	@XmlElement(namespace = "http://www.rbm.com.co/esb/comercio/compra/", name="infoAdicional")
	protected List<TipoInfoAdicional> infoAdicional;

	/**
	 * Obtiene el valor de la propiedad fechaTransaccion.
	 * 
	 * @return possible object is {@link XMLGregorianCalendar }
	 * 
	 */
	public XMLGregorianCalendar getFechaTransaccion() {
		return fechaTransaccion;
	}

	/**
	 * Define el valor de la propiedad fechaTransaccion.
	 * 
	 * @param value allowed object is {@link XMLGregorianCalendar }
	 * 
	 */
	public void setFechaTransaccion(XMLGregorianCalendar value) {
		this.fechaTransaccion = value;
	}

	/**
	 * Obtiene el valor de la propiedad fechaPosteo.
	 * 
	 * @return possible object is {@link XMLGregorianCalendar }
	 * 
	 */
	public XMLGregorianCalendar getFechaPosteo() {
		return fechaPosteo;
	}

	/**
	 * Define el valor de la propiedad fechaPosteo.
	 * 
	 * @param value allowed object is {@link XMLGregorianCalendar }
	 * 
	 */
	public void setFechaPosteo(XMLGregorianCalendar value) {
		this.fechaPosteo = value;
	}

	/**
	 * Obtiene el valor de la propiedad numAprobacion.
	 * 
	 * @return possible object is {@link String }
	 * 
	 */
	public String getNumAprobacion() {
		return numAprobacion;
	}

	/**
	 * Define el valor de la propiedad numAprobacion.
	 * 
	 * @param value allowed object is {@link String }
	 * 
	 */
	public void setNumAprobacion(String value) {
		this.numAprobacion = value;
	}

	/**
	 * Obtiene el valor de la propiedad costoTransaccion.
	 * 
	 * @return possible object is {@link BigDecimal }
	 * 
	 */
	public BigDecimal getCostoTransaccion() {
		return costoTransaccion;
	}

	/**
	 * Define el valor de la propiedad costoTransaccion.
	 * 
	 * @param value allowed object is {@link BigDecimal }
	 * 
	 */
	public void setCostoTransaccion(BigDecimal value) {
		this.costoTransaccion = value;
	}

	/**
	 * Gets the value of the infoAdicional property.
	 * 
	 * <p>
	 * This accessor method returns a reference to the live list, not a snapshot.
	 * Therefore any modification you make to the returned list will be present
	 * inside the JAXB object. This is why there is not a <CODE>set</CODE> method
	 * for the infoAdicional property.
	 * 
	 * <p>
	 * For example, to add a new item, do as follows:
	 * 
	 * <pre>
	 * getInfoAdicional().add(newItem);
	 * </pre>
	 * 
	 * 
	 * <p>
	 * Objects of the following type(s) are allowed in the list
	 * {@link TipoInfoAdicional }
	 * 
	 * 
	 */
	public List<TipoInfoAdicional> getInfoAdicional() {
		if (infoAdicional == null) {
			infoAdicional = new ArrayList<TipoInfoAdicional>();
		}
		return this.infoAdicional;
	}

}
