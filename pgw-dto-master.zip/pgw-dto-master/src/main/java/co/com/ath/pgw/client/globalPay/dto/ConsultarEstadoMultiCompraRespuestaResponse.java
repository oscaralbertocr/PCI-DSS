
package co.com.ath.pgw.client.globalPay.dto;

import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;

import co.com.ath.pgw.client.globalPay.model.TipoCabeceraSolicitud;
import co.com.ath.pgw.client.globalPay.model.TipoInfoDispersionPago;
import co.com.ath.pgw.client.globalPay.model.TipoInfoRespuesta;
import co.com.ath.pgw.core.logging.util.XMLUtil;


/**
 * <p>Clase Java para anonymous complex type.
 * 
 * <p>El siguiente fragmento de esquema especifica el contenido que se espera que haya en esta clase.
 * 
 * <pre>
 * &lt;complexType&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="cabeceraRespuesta" type="{http://www.rbm.com.co/esb/globalpay/}TipoCabeceraSolicitud"/&gt;
 *         &lt;element name="infoDispersionPago" type="{http://www.rbm.com.co/esb/globalpay/}TipoInfoDispersionPago" maxOccurs="unbounded" minOccurs="0"/&gt;
 *         &lt;element name="infoRespuesta" type="{http://www.rbm.com.co/esb/}TipoInfoRespuesta"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "", propOrder = {
    "cabeceraRespuesta",
    "infoDispersionPago",
    "infoRespuesta"
})
@XmlRootElement(name = "ConsultarEstadoMultiCompraRespuesta")
public class ConsultarEstadoMultiCompraRespuestaResponse {

    @XmlElement(required = true)
    protected TipoCabeceraSolicitud cabeceraRespuesta;
    protected List<TipoInfoDispersionPago> infoDispersionPago;
    @XmlElement(required = true)
    protected TipoInfoRespuesta infoRespuesta;

    /**
     * Obtiene el valor de la propiedad cabeceraRespuesta.
     * 
     * @return
     *     possible object is
     *     {@link TipoCabeceraSolicitud }
     *     
     */
    public TipoCabeceraSolicitud getCabeceraRespuesta() {
        return cabeceraRespuesta;
    }

    /**
     * Define el valor de la propiedad cabeceraRespuesta.
     * 
     * @param value
     *     allowed object is
     *     {@link TipoCabeceraSolicitud }
     *     
     */
    public void setCabeceraRespuesta(TipoCabeceraSolicitud value) {
        this.cabeceraRespuesta = value;
    }

    /**
     * Gets the value of the infoDispersionPago property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the infoDispersionPago property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getInfoDispersionPago().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link TipoInfoDispersionPago }
     * 
     * 
     */
    public List<TipoInfoDispersionPago> getInfoDispersionPago() {
        if (infoDispersionPago == null) {
            infoDispersionPago = new ArrayList<TipoInfoDispersionPago>();
        }
        return this.infoDispersionPago;
    }

    /**
     * Obtiene el valor de la propiedad infoRespuesta.
     * 
     * @return
     *     possible object is
     *     {@link TipoInfoRespuesta }
     *     
     */
    public TipoInfoRespuesta getInfoRespuesta() {
        return infoRespuesta;
    }

    /**
     * Define el valor de la propiedad infoRespuesta.
     * 
     * @param value
     *     allowed object is
     *     {@link TipoInfoRespuesta }
     *     
     */
    public void setInfoRespuesta(TipoInfoRespuesta value) {
        this.infoRespuesta = value;
    }
    
    @Override
	public String toString() {
		XMLUtil<ConsultarEstadoMultiCompraRespuestaResponse> requestParser = new XMLUtil<ConsultarEstadoMultiCompraRespuestaResponse>();
		return requestParser.convertObjectToXml(this);
	}

}
