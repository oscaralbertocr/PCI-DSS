package co.com.ath.pgw.rest.dto;

import java.io.Serializable;

import javax.validation.Valid;
import javax.validation.constraints.NotNull;

import com.fasterxml.jackson.annotation.JsonProperty;

public class CustInfoAddTx implements Serializable {
	
	@JsonProperty("PersonInfo")
	@Valid
	@NotNull
	private PersonInfoAddTx personInfo;
	
	@JsonProperty("CustName")
	@Valid
	private CustNameAddTx custName;
	

	@JsonProperty("CustType")
	private String custType;
	
	private final static long serialVersionUID = 1042615171471496392L;

	public PersonInfoAddTx getPersonInfo() {
		return personInfo;
	}

	public void setPersonInfo(PersonInfoAddTx personInfo) {
		this.personInfo = personInfo;
	}

	public String getCustType() {
		return custType;
	}

	public void setCustType(String custType) {
		this.custType = custType;
	}

	public CustNameAddTx getCustName() {
		return custName;
	}
	
	public void setCustName(CustNameAddTx custName) {
		this.custName = custName;
	}
	
}