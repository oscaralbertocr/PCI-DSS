package co.com.ath.pgw.rest.response.dto;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonProperty;

import co.com.ath.pgw.core.logging.util.XMLUtil;

public class PaymentStatusResponse implements Serializable{

	private static final long serialVersionUID = -460820978615729906L;
	
	@JsonProperty("status")
	private String status;
	
	@JsonProperty("pmtId")
	private String pmtId;

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getPmtId() {
		return pmtId;
	}

	public void setPmtId(String pmtId) {
		this.pmtId = pmtId;
	}

	@Override
	public String toString() {
		XMLUtil<PaymentStatusResponse> util = new XMLUtil<PaymentStatusResponse>();
		return util.convertObjectToJson(this);
	}
	
}
