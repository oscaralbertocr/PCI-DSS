package co.com.ath.pgw.rest.request.dto;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonProperty;

import co.com.ath.pgw.core.logging.util.XMLUtil;

public class PaymentStatusRequest implements Serializable {

	private static final long serialVersionUID = 6450160528954666536L;
	
	@JsonProperty("pmtId")
	private String pmtId;
	
	@JsonProperty("timeoutFront")
	private String timeoutFrontms;

	public String getPmtId() {
		return pmtId;
	}

	public void setPmtId(String pmtId) {
		this.pmtId = pmtId;
	}

	public String getTimeoutFrontms() {
		return timeoutFrontms;
	}

	public void setTimeoutFrontms(String timeoutFrontms) {
		this.timeoutFrontms = timeoutFrontms;
	}
		
	@Override
	public String toString() {
		XMLUtil<PaymentStatusRequest> util = new XMLUtil<PaymentStatusRequest>();
		return util.convertObjectToJson(this);
	}
}
