
package co.com.ath.pgw.client.tokenize.dto;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlType;

import co.com.ath.pgw.client.tokenize.model.SvcRsType;
import co.com.ath.pgw.core.logging.util.XMLUtil;


/**
 * <p>Clase Java para TokenizedDataRs_Type complex type.
 * 
 * <p>El siguiente fragmento de esquema especifica el contenido que se espera que haya en esta clase.
 * 
 * <pre>
 * &lt;complexType name="TokenizedDataRs_Type"&gt;
 *   &lt;complexContent&gt;
 *     &lt;extension base="{urn://ath.com.co/xsd/common/}SvcRs_Type"&gt;
 *     &lt;/extension&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "TokenizedDataRs_Type", namespace = "urn://ath.com.co/support/v1/")
public class TokenizedDataRsType
    extends SvcRsType
{

	@Override
	public String toString() {
		XMLUtil<TokenizedDataRsType> requestParser = new XMLUtil<TokenizedDataRsType>();
		return requestParser.convertObjectToXml(this);
	}

}
