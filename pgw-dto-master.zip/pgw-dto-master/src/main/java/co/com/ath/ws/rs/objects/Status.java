package co.com.ath.ws.rs.objects;

import java.util.Date;

import com.fasterxml.jackson.annotation.JsonProperty;

import co.com.ath.pgw.core.logging.util.XMLUtil;

public class Status extends CommonStatus {

	private static final long serialVersionUID = 1L;

	@JsonProperty("EndDt")
	private Date endDt;

	@JsonProperty("AdditionalStatus")
	private AdditionalStatus additionalStatus;

	
	public Date getEndDt() {
		return endDt;
	}

	public void setEndDt(Date endDt) {
		this.endDt = endDt;
	}

	public AdditionalStatus getAdditionalStatus() {
		return additionalStatus;
	}

	public void setAdditionalStatus(AdditionalStatus additionalStatus) {
		this.additionalStatus = additionalStatus;
	}

	@Override
	public String toString() {
		XMLUtil<Status> util = new XMLUtil<Status>();
		return util.convertObjectToJson(this);
	}

}
