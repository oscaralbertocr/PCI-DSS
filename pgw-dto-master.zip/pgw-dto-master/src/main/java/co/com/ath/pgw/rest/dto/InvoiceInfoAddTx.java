
package co.com.ath.pgw.rest.dto;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.validation.Valid;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.Pattern;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonProperty;

import co.com.ath.pgw.rest.util.ConstantFormat;
import co.com.ath.pgw.rest.util.DTOConstants;

public class InvoiceInfoAddTx implements Serializable {
	@JsonProperty("InvoiceType")
	@NotBlank
	@Pattern( regexp = ConstantFormat.FORMAT_SOLO_NUMEROS, message = ConstantFormat.MESSAGE_CARACTER_NO_VALIDOS)
	private String invoiceType;
	
	@JsonProperty("InvoiceNum")
	private String invoiceNum;
	
	@JsonProperty("Desc")
	@NotBlank
	@Pattern( regexp = ConstantFormat.FORMAT_NO_CARACTERES_DESC_ADDTX, message = ConstantFormat.MESSAGE_CARACTER_NO_VALIDOS)
	private String desc;
	
	@JsonProperty("NIE")
	private List<String> nie;
	
	@JsonFormat(pattern="yyyy-MM-dd HH:mm:ss", timezone = DTOConstants.TIMEZONE)
	@JsonProperty("EffDt")
	private Date effDt;
	
	@JsonProperty("InvoiceSender")
	@Valid
	private InvoiceSenderAddTx invoiceSender;
	
	@JsonProperty("InvoiceVouchNum")
	private String invoiceVouchNum;

	@JsonProperty("TotalCurAmt")
	private TotalCurAmtAddTx totalCurAmt;
	
	@JsonProperty("RefInfo")
	private List<RefInfoAddTx> refInfo = null;
	
	private final static long serialVersionUID = -7122502907082175299L;

	public String getInvoiceType() {
		return invoiceType;
	}

	public void setInvoiceType(String invoiceType) {
		this.invoiceType = invoiceType;
	}

	public List<String> getNie() {
		if (nie == null) {
			nie = new ArrayList<String>();
		}
		return nie;
	}

	public void setNie(List<String> nie) {
		this.nie = nie;
	}

	public String getDesc() {
		return desc;
	}

	public void setDesc(String desc) {
		this.desc = desc;
	}

	public Date getEffDt() {
		return effDt;
	}

	public void setEffDt(Date effDt) {
		this.effDt = effDt;
	}

	public InvoiceSenderAddTx getInvoiceSender() {
		return invoiceSender;
	}

	public void setInvoiceSender(InvoiceSenderAddTx invoiceSender) {
		this.invoiceSender = invoiceSender;
	}

	public String getInvoiceVouchNum() {
		return invoiceVouchNum;
	}

	public void setInvoiceVouchNum(String invoiceVouchNum) {
		this.invoiceVouchNum = invoiceVouchNum;
	}

	public String getInvoiceNum() {
		return invoiceNum;
	}

	public void setInvoiceNum(String invoiceNum) {
		this.invoiceNum = invoiceNum;
	}

	public TotalCurAmtAddTx getTotalCurAmt() {
		return totalCurAmt;
	}

	public void setTotalCurAmt(TotalCurAmtAddTx totalCurAmt) {
		this.totalCurAmt = totalCurAmt;
	}

	public List<RefInfoAddTx> getRefInfo() {
		if (refInfo == null) {
			refInfo = new ArrayList<RefInfoAddTx>();
		}
		return refInfo;
	}

	public void setRefInfo(List<RefInfoAddTx> refInfo) {
		this.refInfo = refInfo;
	}

}
