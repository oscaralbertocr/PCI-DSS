
package co.com.ath.pgw.bsn.globalPay.model;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Clase Java para anonymous complex type.
 * 
 * <p>El siguiente fragmento de esquema especifica el contenido que se espera que haya en esta clase.
 * 
 * <pre>
 * &lt;complexType>
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element ref="{urn://ath.com.co/payments/v1/}CoreInitTransactionRbmRq"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "", propOrder = {
    "coreInitTransactionRbmRq"
})
@XmlRootElement(name = "coreInitTransactionRbm", namespace = "urn://ath.com.co/payments/v1/")
public class CoreInitTransactionRbm {

    @XmlElement(name = "CoreInitTransactionRbmRq", namespace = "urn://ath.com.co/payments/v1/", required = true)
    protected CoreInitTransactionRbmRqType coreInitTransactionRbmRq;

    /**
     * Obtiene el valor de la propiedad coreInitTransactionRbmRq.
     * 
     * @return
     *     possible object is
     *     {@link CoreInitTransactionRbmRqType }
     *     
     */
    public CoreInitTransactionRbmRqType getCoreInitTransactionRbmRq() {
        return coreInitTransactionRbmRq;
    }

    /**
     * Define el valor de la propiedad coreInitTransactionRbmRq.
     * 
     * @param value
     *     allowed object is
     *     {@link CoreInitTransactionRbmRqType }
     *     
     */
    public void setCoreInitTransactionRbmRq(CoreInitTransactionRbmRqType value) {
        this.coreInitTransactionRbmRq = value;
    }

}
