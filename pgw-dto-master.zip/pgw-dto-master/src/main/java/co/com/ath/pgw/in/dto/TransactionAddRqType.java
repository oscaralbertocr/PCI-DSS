package co.com.ath.pgw.in.dto;

import java.util.ArrayList;
import java.util.List;

import co.com.ath.pgw.core.logging.util.XMLUtil;
import co.com.ath.pgw.in.model.FeeType;
import co.com.ath.pgw.in.model.InvoiceReferenceType;
import co.com.ath.pgw.in.model.OrderInfoType;
import co.com.ath.pgw.in.model.PersonalDataType;
import co.com.ath.pgw.in.model.ReferenceType;
import co.com.ath.pgw.in.model.SecretListType;
import co.com.ath.pgw.in.model.SvcRqType;
import co.com.ath.pgw.in.model.TaxFeeType;
import co.com.ath.pgw.in.model.TrmType;


public class TransactionAddRqType extends SvcRqType {

   
    protected String agreementId;
    
   
    protected String portalURL;
    
    
    protected List<SecretListType> secretList;
    
   
    protected PersonalDataType personalData;
    
    
    protected OrderInfoType orderInfo;
    
   
    protected FeeType fee;
    
    
    protected TaxFeeType taxFee;
    
    
    protected List<ReferenceType> reference;
    
   
    protected String trnType;
   
    protected List<InvoiceReferenceType> invoiceReference;
    
    protected String categoryId;
    
    protected String pmtType;
    
    protected String trnChannel;
   
    protected TrmType trm;

    /**
     * Obtiene el valor de la propiedad agreementId.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getAgreementId() {
        return agreementId;
    }

    /**
     * Define el valor de la propiedad agreementId.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setAgreementId(String value) {
        this.agreementId = value;
    }

    /**
     * Obtiene el valor de la propiedad portalURL.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPortalURL() {
        return portalURL;
    }

    /**
     * Define el valor de la propiedad portalURL.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPortalURL(String value) {
        this.portalURL = value;
    }

    /**
     * Gets the value of the secretList property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the secretList property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getSecretList().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link SecretListType }
     * 
     * 
     */
    public List<SecretListType> getSecretList() {
        if (secretList == null) {
            secretList = new ArrayList<SecretListType>();
        }
        return this.secretList;
    }

    /**
     * Obtiene el valor de la propiedad personalData.
     * 
     * @return
     *     possible object is
     *     {@link PersonalDataType }
     *     
     */
    public PersonalDataType getPersonalData() {
        return personalData;
    }

    /**
     * Define el valor de la propiedad personalData.
     * 
     * @param value
     *     allowed object is
     *     {@link PersonalDataType }
     *     
     */
    public void setPersonalData(PersonalDataType value) {
        this.personalData = value;
    }

    /**
     * Obtiene el valor de la propiedad orderInfo.
     * 
     * @return
     *     possible object is
     *     {@link OrderInfoType }
     *     
     */
    public OrderInfoType getOrderInfo() {
        return orderInfo;
    }

    /**
     * Define el valor de la propiedad orderInfo.
     * 
     * @param value
     *     allowed object is
     *     {@link OrderInfoType }
     *     
     */
    public void setOrderInfo(OrderInfoType value) {
        this.orderInfo = value;
    }

    /**
     * Obtiene el valor de la propiedad fee.
     * 
     * @return
     *     possible object is
     *     {@link FeeType }
     *     
     */
    public FeeType getFee() {
        return fee;
    }

    /**
     * Define el valor de la propiedad fee.
     * 
     * @param value
     *     allowed object is
     *     {@link FeeType }
     *     
     */
    public void setFee(FeeType value) {
        this.fee = value;
    }

    /**
     * Obtiene el valor de la propiedad taxFee.
     * 
     * @return
     *     possible object is
     *     {@link TaxFeeType }
     *     
     */
    public TaxFeeType getTaxFee() {
        return taxFee;
    }

    /**
     * Define el valor de la propiedad taxFee.
     * 
     * @param value
     *     allowed object is
     *     {@link TaxFeeType }
     *     
     */
    public void setTaxFee(TaxFeeType value) {
        this.taxFee = value;
    }

    /**
     * Gets the value of the reference property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the reference property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getReference().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link ReferenceType }
     * 
     * 
     */
    public List<ReferenceType> getReference() {
        if (reference == null) {
            reference = new ArrayList<ReferenceType>();
        }
        return this.reference;
    }

    /**
     * Obtiene el valor de la propiedad trnType.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getTrnType() {
        return trnType;
    }

    /**
     * Define el valor de la propiedad trnType.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setTrnType(String value) {
        this.trnType = value;
    }
    
    
    /**
     * Gets the value of the invoiceReference property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the invoiceReference property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getInvoiceReference().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link InvoiceReferenceType }
     * 
     * 
     */
    public List<InvoiceReferenceType> getInvoiceReference() {
        if (invoiceReference == null) {
            invoiceReference = new ArrayList<InvoiceReferenceType>();
        }
        return this.invoiceReference;
    }

    /**
     * Obtiene el valor de la propiedad categoryId.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCategoryId() {
        return categoryId;
    }

    /**
     * Define el valor de la propiedad categoryId.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCategoryId(String value) {
        this.categoryId = value;
    }

    /**
     * Obtiene el valor de la propiedad pmtType.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPmtType() {
        return pmtType;
    }

    /**
     * Define el valor de la propiedad pmtType.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPmtType(String value) {
        this.pmtType = value;
    }

    /**
     * Obtiene el valor de la propiedad trnChannel.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getTrnChannel() {
        return trnChannel;
    }

    /**
     * Define el valor de la propiedad trnChannel.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setTrnChannel(String value) {
        this.trnChannel = value;
    }
    
    /**
     * Obtiene el valor de la propiedad trm.
     * 
     * @return
     *     possible object is
     *     {@link TrmType }
     *     
     */
    public TrmType getTRM() {
        return trm;
    }

    /**
     * Define el valor de la propiedad trm.
     * 
     * @param value
     *     allowed object is
     *     {@link TrmType }
     *     
     */
    public void setTRM(TrmType value) {
        this.trm = value;
    }
    
    @Override
    public String toString() {
    	XMLUtil<TransactionAddRqType> requestParser = new XMLUtil<TransactionAddRqType>();
		return requestParser.convertObjectToXml(this);			
    }
    
}
