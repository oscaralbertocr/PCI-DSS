
package co.com.ath.pgw.rest.dto;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonProperty;

public class RefInfo implements Serializable
{
	@JsonProperty("RefId")
    private String refId;
	
	@JsonProperty("RefType")
    private String refType;
	
    private final static long serialVersionUID = 164215267971914750L;

    public RefInfo() {
    }
    
    public RefInfo(String refId, String refType) {
		this.refId = refId;
		this.refType = refType;
	}

	public String getRefId() {
        return refId;
    }

    public void setRefId(String refId) {
        this.refId = refId;
    }

    public String getRefType() {
        return refType;
    }

    public void setRefType(String refType) {
        this.refType = refType;
    }

}
