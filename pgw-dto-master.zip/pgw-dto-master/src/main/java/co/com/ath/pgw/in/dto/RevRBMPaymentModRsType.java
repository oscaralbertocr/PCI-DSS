
package co.com.ath.pgw.in.dto;

import co.com.ath.pgw.core.logging.util.XMLUtil;
import co.com.ath.pgw.in.model.TransactionStatusType;


/**
 * <p>Clase Java para RevRBMPaymentModRs_Type complex type.
 * 
 * <p>El siguiente fragmento de esquema especifica el contenido que se espera que haya en esta clase.
 * 
 * <pre>
 * &lt;complexType name="RevRBMPaymentModRs_Type">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element ref="{urn://ath.com.co/xsd/common/}StatusCode"/>
 *         &lt;element ref="{urn://ath.com.co/xsd/common/}StatusDesc"/>
 *         &lt;element ref="{urn://ath.com.co/xsd/common/}RqUID"/>
 *         &lt;element ref="{urn://ath.com.co/xsd/common/}TransactionStatus" minOccurs="0"/>
 *         &lt;element ref="{urn://ath.com.co/xsd/common/}PmtId" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
public class RevRBMPaymentModRsType {

  
    protected long statusCode;
   
    protected String statusDesc;
  
    protected long rqUID;
  
    protected TransactionStatusType transactionStatus;
   
    protected String pmtId;

    /**
     * Obtiene el valor de la propiedad statusCode.
     * 
     */
    public long getStatusCode() {
        return statusCode;
    }

    /**
     * Define el valor de la propiedad statusCode.
     * 
     */
    public void setStatusCode(long value) {
        this.statusCode = value;
    }

    /**
     * Obtiene el valor de la propiedad statusDesc.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getStatusDesc() {
        return statusDesc;
    }

    /**
     * Define el valor de la propiedad statusDesc.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setStatusDesc(String value) {
        this.statusDesc = value;
    }

    /**
     * Obtiene el valor de la propiedad rqUID.
     * 
     */
    public long getRqUID() {
        return rqUID;
    }

    /**
     * Define el valor de la propiedad rqUID.
     * 
     */
    public void setRqUID(long value) {
        this.rqUID = value;
    }

    /**
     * Obtiene el valor de la propiedad transactionStatus.
     * 
     * @return
     *     possible object is
     *     {@link TransactionStatusType }
     *     
     */
    public TransactionStatusType getTransactionStatus() {
        return transactionStatus;
    }

    /**
     * Define el valor de la propiedad transactionStatus.
     * 
     * @param value
     *     allowed object is
     *     {@link TransactionStatusType }
     *     
     */
    public void setTransactionStatus(TransactionStatusType value) {
        this.transactionStatus = value;
    }

    /**
     * Obtiene el valor de la propiedad pmtId.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPmtId() {
        return pmtId;
    }

    /**
     * Define el valor de la propiedad pmtId.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPmtId(String value) {
        this.pmtId = value;
    }

    @Override
    public String toString() {
        XMLUtil<RevRBMPaymentModRsType> requestParser = 
				new XMLUtil<RevRBMPaymentModRsType>();
		return requestParser.convertObjectToXml(this);
    }
}
