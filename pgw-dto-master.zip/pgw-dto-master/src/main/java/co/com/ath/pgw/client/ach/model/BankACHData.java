
package co.com.ath.pgw.client.ach.model;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Clase Java para BankACHData complex type.
 * 
 * <p>El siguiente fragmento de esquema especifica el contenido que se espera que haya en esta clase.
 * 
 * <pre>
 * &lt;complexType name="BankACHData">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="financialInstitutionCode" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="financialInstitutionName" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "BankACHData", propOrder = {
    "financialInstitutionCode",
    "financialInstitutionName"
})
public class BankACHData {

    protected String financialInstitutionCode;
    protected String financialInstitutionName;

    /**
     * Obtiene el valor de la propiedad financialInstitutionCode.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getFinancialInstitutionCode() {
        return financialInstitutionCode;
    }

    /**
     * Define el valor de la propiedad financialInstitutionCode.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setFinancialInstitutionCode(String value) {
        this.financialInstitutionCode = value;
    }

    /**
     * Obtiene el valor de la propiedad financialInstitutionName.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getFinancialInstitutionName() {
        return financialInstitutionName;
    }

    /**
     * Define el valor de la propiedad financialInstitutionName.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setFinancialInstitutionName(String value) {
        this.financialInstitutionName = value;
    }

}
