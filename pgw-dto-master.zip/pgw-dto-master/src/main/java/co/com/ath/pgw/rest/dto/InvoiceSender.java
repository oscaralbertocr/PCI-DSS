
package co.com.ath.pgw.rest.dto;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonProperty;

public class InvoiceSender implements Serializable
{
	@JsonProperty("Category")
    private String category;
	
    private final static long serialVersionUID = 7592807778459124109L;

    public String getCategory() {
        return category;
    }

    public void setCategory(String category) {
        this.category = category;
    }

}
