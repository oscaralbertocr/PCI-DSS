/*
 * CommerceRoleContactVO
 *  
 * GSI - Integración
 * Creado el: 28/08/2014
 *
 * Copyright (c) A Toda Hora S.A. Todos los derechos reservados
 * 
 * Este software es confidencial y es propietario de ATH, queda prohibido
 * su uso, reproducción y copia de manera parcial o permanente salvo autorización
 * expresa de A Toda Hora S.A o de quién represente sus derechos.
 */
package co.com.ath.pgw.bsn.model.bo;


/**
 * Clase que representa un rol válido para los contactos de un comercio. Esta es
 * una entidad del modelo de negocio. 
 * 
 * @author proveedor_japiza
 * @version 1.0 29 Ago 2014
 * @since 1.0
 *
 */
public class CommerceRoleContactBO {

	/**
	 * Identificador único del rol
	 */
	private Long id;

	/**
	 * Nombre del rol
	 */
	private String name;
	
	/**
	 * Construye un rol para un contacto de un comercio.	
	 */
	public CommerceRoleContactBO(){
		super();
	}

	/**
	 * Retorna el Identificador único del rol.
	 * 
	 * @return Identificador único del rol
	 */
	public Long getId() {
		return id;
	}

	/**
	 * Establece el identificador único del rol
	 * 
	 * @param id Identificador único del rol
	 */
	public void setId(Long id) {
		this.id = id;
	}
	
	/**
	 * Retorna el nombre del rol.
	 * 
	 * @return Nombre del rol.
	 */
	public String getName() {
		return name;
	}

	/**
	 * Establece el nombre del rol.
	 * 
	 * @param name Nombre del rol.
	 */
	public void setName(String name) {
		this.name = name;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((id == null) ? 0 : id.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		CommerceRoleContactBO other = (CommerceRoleContactBO) obj;
		if (id == null) {
			if (other.id != null)
				return false;
		} else if (!id.equals(other.id))
			return false;
		return true;
	}

	@Override
	public String toString() {
		return "CommerceRoleContactVO [id=" + id + ", name=" + name + "]";
	}
	
}