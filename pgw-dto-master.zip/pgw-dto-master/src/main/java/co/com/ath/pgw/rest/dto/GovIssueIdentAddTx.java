
package co.com.ath.pgw.rest.dto;

import java.io.Serializable;

import javax.validation.constraints.Pattern;

import com.fasterxml.jackson.annotation.JsonProperty;

import co.com.ath.pgw.rest.util.ConstantFormat;

public class GovIssueIdentAddTx implements Serializable
{
	@JsonProperty("GovIssueIdentType")
	@Pattern( regexp = ConstantFormat.FORMAT_SOLO_LETRAS, message = ConstantFormat.MESSAGE_CARACTER_NO_VALIDOS)
    private String govIssueIdentType;
	
	@JsonProperty("IdentSerialNum")
	@Pattern( regexp = ConstantFormat.FORMAT_NUMEROS_LETRAS_ACENTOS_IDENTSERIALNUM, message = ConstantFormat.MESSAGE_CARACTER_NO_VALIDOS)
    private String identSerialNum;
	
    private final static long serialVersionUID = 4124988563701526371L;

    public String getGovIssueIdentType() {
        return govIssueIdentType;
    }

    public void setGovIssueIdentType(String govIssueIdentType) {
        this.govIssueIdentType = govIssueIdentType;
    }

    public String getIdentSerialNum() {
        return identSerialNum;
    }

    public void setIdentSerialNum(String identSerialNum) {
        this.identSerialNum = identSerialNum;
    }

}
