package co.com.ath.pgw;

import co.com.ath.pgw.core.logging.util.XMLUtil;

public class Greeting {

    private final long id;
    private final String content;
    private final String cardEmbossNum;
    private final Greeting2 greeting2;

    public Greeting(long id, String content, String cardEmbossNum) {
        this.id = id;
        this.content = content;
        this.cardEmbossNum = cardEmbossNum;
        this.greeting2 = new Greeting2();
    }

    public long getId() {
        return id;
    }

    public String getContent() {
        return content;
    }
    
    public String getCardEmbossNum() {
        return cardEmbossNum;
    }
    
    public Greeting2 getGreeting2() {
		return greeting2;
	}

	@Override
	public String toString() {
    	XMLUtil<Greeting> requestParser = new XMLUtil<Greeting>();
    	return requestParser.convertObjectToJson(this);
	}
    
}
