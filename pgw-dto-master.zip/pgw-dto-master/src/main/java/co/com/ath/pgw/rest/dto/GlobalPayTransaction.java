
package co.com.ath.pgw.rest.dto;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonProperty;

public class GlobalPayTransaction implements Serializable {


	private static final long serialVersionUID = 1775862011815021124L;

	@JsonProperty("status")
	private String status;
	
	@JsonProperty("order_description")
	private String orderDescription;
	
	@JsonProperty("authorization_code")
	private String authorizationCode;
	
	@JsonProperty("status_detail")
	private String statusDetail;
	
	@JsonProperty("date")
	private String date;
	
	@JsonProperty("message")
	private String message;
	
	@JsonProperty("id")
	private String id;
	
	@JsonProperty("dev_reference")
	private String devReference;
	
	@JsonProperty("carrier_code")
	private String carrieCode;
	
	@JsonProperty("amount")
	private String amount;
	
	@JsonProperty("paid_date")
	private String paidDate;
	
	@JsonProperty("installments")
	private String installments;
	
	@JsonProperty("stoken")
	private String stoken;
	
	@JsonProperty("application_code")
	private String applicationCode;

	
	
	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getOrderDescription() {
		return orderDescription;
	}

	public void setOrderDescription(String orderDescription) {
		this.orderDescription = orderDescription;
	}

	public String getAuthorizationCode() {
		return authorizationCode;
	}

	public void setAuthorizationCode(String authorizationCode) {
		this.authorizationCode = authorizationCode;
	}

	public String getStatusDetail() {
		return statusDetail;
	}

	public void setStatusDetail(String statusDetail) {
		this.statusDetail = statusDetail;
	}

	public String getDate() {
		return date;
	}

	public void setDate(String date) {
		this.date = date;
	}

	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getDevReference() {
		return devReference;
	}

	public void setDevReference(String devReference) {
		this.devReference = devReference;
	}

	public String getCarrieCode() {
		return carrieCode;
	}

	public void setCarrieCode(String carrieCode) {
		this.carrieCode = carrieCode;
	}

	public String getAmount() {
		return amount;
	}

	public void setAmount(String amount) {
		this.amount = amount;
	}

	public String getPaidDate() {
		return paidDate;
	}

	public void setPaidDate(String paidDate) {
		this.paidDate = paidDate;
	}

	public String getInstallments() {
		return installments;
	}

	public void setInstallments(String installments) {
		this.installments = installments;
	}

	public String getStoken() {
		return stoken;
	}

	public void setStoken(String stoken) {
		this.stoken = stoken;
	}

	public String getApplicationCode() {
		return applicationCode;
	}

	public void setApplicationCode(String applicationCode) {
		this.applicationCode = applicationCode;
	}
	

}
