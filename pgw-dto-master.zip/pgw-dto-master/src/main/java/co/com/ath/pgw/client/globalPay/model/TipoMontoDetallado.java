
package co.com.ath.pgw.client.globalPay.model;

import java.math.BigDecimal;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlSchemaType;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Clase Java para TipoMontoDetallado complex type.
 * 
 * <p>El siguiente fragmento de esquema especifica el contenido que se espera que haya en esta clase.
 * 
 * <pre>
 * &lt;complexType name="TipoMontoDetallado"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="tipoMontoDetallado" type="{http://www.rbm.com.co/esb/}TipoTipoMontoDetallado"/&gt;
 *         &lt;element name="monto"&gt;
 *           &lt;simpleType&gt;
 *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}decimal"&gt;
 *               &lt;minExclusive value="0"/&gt;
 *               &lt;maxExclusive value="999999999999"/&gt;
 *             &lt;/restriction&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "TipoMontoDetallado", propOrder = {
    "tipoMontoDetallado",
    "monto"
})
public class TipoMontoDetallado {

    @XmlElement(required = true, namespace= "http://www.rbm.com.co/esb/", name="tipoMontoDetallado")
    @XmlSchemaType(name = "string")
    protected TipoTipoMontoDetallado tipoMontoDetallado;
    @XmlElement(required = true, namespace= "http://www.rbm.com.co/esb/", name="monto")
    protected BigDecimal monto;

    /**
     * Obtiene el valor de la propiedad tipoMontoDetallado.
     * 
     * @return
     *     possible object is
     *     {@link TipoTipoMontoDetallado }
     *     
     */
    public TipoTipoMontoDetallado getTipoMontoDetallado() {
        return tipoMontoDetallado;
    }

    /**
     * Define el valor de la propiedad tipoMontoDetallado.
     * 
     * @param value
     *     allowed object is
     *     {@link TipoTipoMontoDetallado }
     *     
     */
    public void setTipoMontoDetallado(TipoTipoMontoDetallado value) {
        this.tipoMontoDetallado = value;
    }

    /**
     * Obtiene el valor de la propiedad monto.
     * 
     * @return
     *     possible object is
     *     {@link BigDecimal }
     *     
     */
    public BigDecimal getMonto() {
        return monto;
    }

    /**
     * Define el valor de la propiedad monto.
     * 
     * @param value
     *     allowed object is
     *     {@link BigDecimal }
     *     
     */
    public void setMonto(BigDecimal value) {
        this.monto = value;
    }

}
