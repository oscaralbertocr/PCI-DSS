
package co.com.ath.pgw.rest.dto;

import java.io.Serializable;

import javax.validation.constraints.Pattern;

import com.fasterxml.jackson.annotation.JsonProperty;

import co.com.ath.pgw.rest.util.ConstantFormat;

public class PhoneNumAddTx implements Serializable
{
	@JsonProperty("PhoneType")
	@Pattern( regexp = ConstantFormat.FORMAT_NUMEROS_LETRAS, message = ConstantFormat.MESSAGE_CARACTER_NO_VALIDOS)
    private String phoneType;
	
	@JsonProperty("Phone")
	@Pattern( regexp = ConstantFormat.FORMAT_SOLO_NUMEROS_PARENTESIS, message = ConstantFormat.MESSAGE_CARACTER_NO_VALIDOS)
    private String phone;
	
    private final static long serialVersionUID = -6929535947425970242L;

    public String getPhoneType() {
        return phoneType;
    }

    public void setPhoneType(String phoneType) {
        this.phoneType = phoneType;
    }

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

}
