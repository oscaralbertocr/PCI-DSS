package co.com.ath.ws.rs.objects;

import java.io.Serializable;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonProperty;

import co.com.ath.pgw.in.model.AgreementInfoType;
import co.com.ath.pgw.in.model.PmtWayType;

public class GetTransactionByIdType implements Serializable {

	private static final long serialVersionUID = 1L;
	
	@JsonProperty("statusCode")
	private String statusCode;
	
	@JsonProperty("statusDesc")
	private String statusDesc;
	
	@JsonProperty("rqUID")
	private String rqUID;
	
	@JsonProperty("transactionStatus")
	private TransactionStatus transactionStatus;
	
	@JsonProperty("userId")
	private UserId userId;
	
	@JsonProperty("personalData")
	private List<PersonalData>  personalData;

	@JsonProperty("agreementInfo")
	private AgreementInfoType agreementInfoType;
	
	@JsonProperty("pmtId")
	private String pmtId;
	
	@JsonProperty("orderInfo")
	private OrderInfo orderInfo;
	
	@JsonProperty("fee")
	private Fee fee;
	
	@JsonProperty("taxFee")
	private TaxFee taxFee;
	
	@JsonProperty("reference")
	private List<Reference> reference;
	
	@JsonProperty("pmtWay")
	private List<PmtWayType> pmtWayType;
	
	@JsonProperty("invoiceReference")
	private List<InvoiceReference> invoiceReference;
	
	@JsonProperty("trnChannel")
	private String trnChannel;
	
	@JsonProperty("trm")
	private String trm;

	public String getStatusCode() {
		return statusCode;
	}

	public void setStatusCode(String statusCode) {
		this.statusCode = statusCode;
	}

	public String getStatusDesc() {
		return statusDesc;
	}

	public void setStatusDesc(String statusDesc) {
		this.statusDesc = statusDesc;
	}

	public String getRqUID() {
		return rqUID;
	}

	public void setRqUID(String rqUID) {
		this.rqUID = rqUID;
	}

	public TransactionStatus getTransactionStatus() {
		return transactionStatus;
	}

	public void setTransactionStatus(TransactionStatus transactionStatus) {
		this.transactionStatus = transactionStatus;
	}

	public UserId getUserId() {
		return userId;
	}

	public void setUserId(UserId userId) {
		this.userId = userId;
	}

	public List<PersonalData> getPersonalData() {
		return personalData;
	}

	public void setPersonalData(List<PersonalData> personalData) {
		this.personalData = personalData;
	}

	public AgreementInfoType getAgreementInfoType() {
		return agreementInfoType;
	}

	public void setAgreementInfoType(AgreementInfoType agreementInfoType) {
		this.agreementInfoType = agreementInfoType;
	}

	public String getPmtId() {
		return pmtId;
	}

	public void setPmtId(String pmtId) {
		this.pmtId = pmtId;
	}

	public OrderInfo getOrderInfo() {
		return orderInfo;
	}

	public void setOrderInfo(OrderInfo orderInfo) {
		this.orderInfo = orderInfo;
	}

	public Fee getFee() {
		return fee;
	}

	public void setFee(Fee fee) {
		this.fee = fee;
	}

	public TaxFee getTaxFee() {
		return taxFee;
	}

	public void setTaxFee(TaxFee taxFee) {
		this.taxFee = taxFee;
	}

	public List<Reference> getReference() {
		return reference;
	}

	public void setReference(List<Reference> reference) {
		this.reference = reference;
	}

	public List<PmtWayType> getPmtWayType() {
		return pmtWayType;
	}

	public void setPmtWayType(List<PmtWayType> pmtWayType) {
		this.pmtWayType = pmtWayType;
	}

	public List<InvoiceReference> getInvoiceReference() {
		return invoiceReference;
	}

	public void setInvoiceReference(List<InvoiceReference> invoiceReference) {
		this.invoiceReference = invoiceReference;
	}

	public String getTrnChannel() {
		return trnChannel;
	}

	public void setTrnChannel(String trnChannel) {
		this.trnChannel = trnChannel;
	}

	public String getTrm() {
		return trm;
	}

	public void setTrm(String trm) {
		this.trm = trm;
	}
		
	

}
