/*
 * DepartmentVO
 *  
 * GSI - Integración
 * Creado el: 29/08/2014
 *
 * Copyright (c) A Toda Hora S.A. Todos los derechos reservados
 * 
 * Este software es confidencial y es propietario de ATH, queda prohibido
 * su uso, reproducción y copia de manera parcial o permanente salvo autorización
 * expresa de A Toda Hora S.A o de quién represente sus derechos.
 */
package co.com.ath.pgw.bsn.model.bo;


/**
 * Representa un departamento según la división politico administrativa del
 * DANE.
 * 
 * @author proveedor_japiza
 * @version 1.0 29 Ago 2014
 * @since 1.0
 */
public class DepartmentBO {

	/**
	 * Identificador del departamento en el sistema.
	 */
	private Long id;

	/**
	 * Código DANE del Departamento
	 */
	private String daneCode;

	/**
	 * Nombre del departamento.
	 */
	private String name;

	/**
	 * Construye un departamento.
	 */
	public DepartmentBO() {
		super();
	}

	/**
	 * Retorna el identificador del departamento en el sistema.
	 * 
	 * @return Identificador del departamento en el sistema.
	 */
	public Long getId(){
		return id;
	}

	/**
	 * Establece el identificador del departamento en el sistema.
	 * 
	 * @param id Identificador del departamento en el sistema.
	 */
	public void setId(Long id){
		this.id = id;
	}

	/**
	 * Retorna el código DANE del Departamento.
	 * 
	 * @return Código DANE del Departamento.
	 */
	public String getDaneCode(){
		return daneCode;
	}

	/**
	 * Código DANE del Departamento.
	 * 
	 * @param daneCode Código DANE del Departamento.
	 */
	public void setDaneCode(String daneCode){
		this.daneCode = daneCode;
	}

	/**
	 * Retorna el nombre del departamento.
	 * 
	 * @return Nombre del departamento.
	 */
	public String getName(){
		return name;
	}

	/**
	 * Establece el nombre del departamento.
	 * 
	 * @param name Nombre del departamento.
	 */
	public void setName(String name){
		this.name = name;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result
				+ ((daneCode == null) ? 0 : daneCode.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		DepartmentBO other = (DepartmentBO) obj;
		if (daneCode == null) {
			if (other.daneCode != null)
				return false;
		} else if (!daneCode.equals(other.daneCode))
			return false;
		return true;
	}

	@Override
	public String toString() {
		return "DepartmentVO [daneCode=" + daneCode + ", name=" + name + "]";
	}
	
}