package co.com.ath.pgw.rest.dto;


import java.io.Serializable;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import org.apache.commons.lang.builder.ToStringBuilder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "OptOrgIdNum",
    "OrgIdNum"
})
public class OrgId implements Serializable
{

    @JsonProperty("OptOrgIdNum")
    private String optOrgIdNum;
    @JsonProperty("OrgIdNum")
    private String orgIdNum;
    private final static long serialVersionUID = 2968221563996449389L;

    @JsonProperty("OptOrgIdNum")
    public String getOptOrgIdNum() {
        return optOrgIdNum;
    }

    @JsonProperty("OptOrgIdNum")
    public void setOptOrgIdNum(String optOrgIdNum) {
        this.optOrgIdNum = optOrgIdNum;
    }

    @JsonProperty("OrgIdNum")
    public String getOrgIdNum() {
        return orgIdNum;
    }

    @JsonProperty("OrgIdNum")
    public void setOrgIdNum(String orgIdNum) {
        this.orgIdNum = orgIdNum;
    }

    @Override
    public String toString() {
        return new ToStringBuilder(this).append("optOrgIdNum", optOrgIdNum).append("orgIdNum", orgIdNum).toString();
    }

}
