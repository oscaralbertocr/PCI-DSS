
package co.com.ath.pgw.rest.dto;

import java.io.Serializable;

import javax.validation.Valid;

import com.fasterxml.jackson.annotation.JsonProperty;

public class FeeAddTx implements Serializable {
	
	@JsonProperty("FeeType")
	private String feeType;
	
	@JsonProperty("CurAmt")
	@Valid
	private CurAmtAddTx curAmt;
	
	@JsonProperty("Rate")
	private String rate;
	
	private final static long serialVersionUID = 6022825277604435772L;

	public CurAmtAddTx getCurAmt() {
		return curAmt;
	}

	public void setCurAmt(CurAmtAddTx curAmt) {
		this.curAmt = curAmt;
	}

	public String getFeeType() {
		return feeType;
	}

	public void setFeeType(String feeType) {
		this.feeType = feeType;
	}

	public String getRate() {
		return rate;
	}

	public void setRate(String rate) {
		this.rate = rate;
	}

}
