package co.com.ath.ws.rs.objects;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonProperty;

public class InfoPago implements Serializable {

	private static final long serialVersionUID = 3419753429016511653L;
	
	@JsonProperty("consecutivo")
    private String consecutivo;
	
	@JsonProperty("tipoCuenta")
    private String tipoCuenta;
	
	@JsonProperty("tipoTarjeta")
    private String tipoTarjeta;
	
	@JsonProperty("tarjeta")
    private String tarjeta;
	
	@JsonProperty("franquicia")
    private String franquicia; 
 
	@JsonProperty("cuotas")
	private String cuotas;
	
	@JsonProperty("modoCapturaPAN")
    private String modoCapturaPAN;
	
	@JsonProperty("capacidadPIN")
    private String capacidadPIN;
	
	@JsonProperty("fechaExpiracion")
    private String fechaExpiracion;

	public String getConsecutivo() {
		return consecutivo;
	}

	public void setConsecutivo(String consecutivo) {
		this.consecutivo = consecutivo;
	}

	public String getTipoCuenta() {
		return tipoCuenta;
	}

	public void setTipoCuenta(String tipoCuenta) {
		this.tipoCuenta = tipoCuenta;
	}

	public String getTipoTarjeta() {
		return tipoTarjeta;
	}

	public void setTipoTarjeta(String tipoTarjeta) {
		this.tipoTarjeta = tipoTarjeta;
	}

	public String getTarjeta() {
		return tarjeta;
	}

	public void setTarjeta(String tarjeta) {
		this.tarjeta = tarjeta;
	}

	public String getFranquicia() {
		return franquicia;
	}

	public void setFranquicia(String franquicia) {
		this.franquicia = franquicia;
	}

	public String getCuotas() {
		return cuotas;
	}

	public void setCuotas(String cuotas) {
		this.cuotas = cuotas;
	}

	public String getModoCapturaPAN() {
		return modoCapturaPAN;
	}

	public void setModoCapturaPAN(String modoCapturaPAN) {
		this.modoCapturaPAN = modoCapturaPAN;
	}

	public String getCapacidadPIN() {
		return capacidadPIN;
	}

	public void setCapacidadPIN(String capacidadPIN) {
		this.capacidadPIN = capacidadPIN;
	}

	public String getFechaExpiracion() {
		return fechaExpiracion;
	}

	public void setFechaExpiracion(String fechaExpiracion) {
		this.fechaExpiracion = fechaExpiracion;
	} 
			
}
