
package co.com.ath.pgw.in.model;

import java.math.BigDecimal;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;

/**
*
* @author camilo.bustamante@sophossolutions.com
* @version 1.0 03 Enero 2019
* @RQ31686 RBM_Integracion_Boton_TC_GlobalPay
* 
*/

/**
 * <p>Clase Java para InfoImpuestos_Type complex type.
 * 
 * <p>El siguiente fragmento de esquema especifica el contenido que se espera que haya en esta clase.
 * 
 * <pre>
 * &lt;complexType name="InfoImpuestos_Type">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element ref="{urn://ath.com.co/xsd/common/}TipoImpuesto" minOccurs="0"/>
 *         &lt;element ref="{urn://ath.com.co/xsd/common/}Monto" minOccurs="0"/>
 *         &lt;element ref="{urn://ath.com.co/xsd/common/}BaseImpuesto" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
public class InfoImpuestosType {
    
    protected String tipoImpuesto;
    
    protected BigDecimal monto;
      
    protected BigDecimal baseImpuesto;

    
	public String getTipoImpuesto() {
		return tipoImpuesto;
	}

	public void setTipoImpuesto(String tipoImpuesto) {
		this.tipoImpuesto = tipoImpuesto;
	}

	public BigDecimal getMonto() {
		return monto;
	}

	public void setMonto(BigDecimal monto) {
		this.monto = monto;
	}

	public BigDecimal getBaseImpuesto() {
		return baseImpuesto;
	}

	public void setBaseImpuesto(BigDecimal baseImpuesto) {
		this.baseImpuesto = baseImpuesto;
	}
    
}
