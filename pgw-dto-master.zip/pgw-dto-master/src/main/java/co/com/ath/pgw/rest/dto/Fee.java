
package co.com.ath.pgw.rest.dto;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonProperty;

public class Fee implements Serializable {
	
	@JsonProperty("FeeType")
	private String feeType;
	
	@JsonProperty("CurAmt")
	private CurAmt curAmt;
	
	@JsonProperty("Rate")
	private String rate;
	
	private final static long serialVersionUID = 6022825277604435772L;

	public CurAmt getCurAmt() {
		return curAmt;
	}

	public void setCurAmt(CurAmt curAmt) {
		this.curAmt = curAmt;
	}

	public String getFeeType() {
		return feeType;
	}

	public void setFeeType(String feeType) {
		this.feeType = feeType;
	}

	public String getRate() {
		return rate;
	}

	public void setRate(String rate) {
		this.rate = rate;
	}

}
