package co.com.ath.ws.rs.objects;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonProperty;

public class PersonalData implements Serializable{

	private static final long serialVersionUID = 1L;
	
	@JsonProperty("custName")
	private CustName custname;	
	
	@JsonProperty("custIdType")
	private String custIdType;
	
	@JsonProperty("custIdNum")
	private String custIdNum;
	
	@JsonProperty("emailAddr")
	private String emailAddr;
	
	@JsonProperty("phone")
	private String phone;

	public CustName getCustname() {
		return custname;
	}

	public void setCustname(CustName custname) {
		this.custname = custname;
	}

	public String getCustIdType() {
		return custIdType;
	}

	public void setCustIdType(String custIdType) {
		this.custIdType = custIdType;
	}

	public String getCustIdNum() {
		return custIdNum;
	}

	public void setCustIdNum(String custIdNum) {
		this.custIdNum = custIdNum;
	}

	public String getEmailAddr() {
		return emailAddr;
	}

	public void setEmailAddr(String emailAddr) {
		this.emailAddr = emailAddr;
	}

	public String getPhone() {
		return phone;
	}

	public void setPhone(String phone) {
		this.phone = phone;
	}
	
	

}
