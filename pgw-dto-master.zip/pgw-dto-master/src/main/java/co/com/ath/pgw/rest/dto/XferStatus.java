
package co.com.ath.pgw.rest.dto;

import java.io.Serializable;
import java.util.Date;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonProperty;

import co.com.ath.pgw.rest.util.DTOConstants;

public class XferStatus implements Serializable
{
	@JsonProperty("StatusCode")
    private String statusCode;
	@JsonProperty("StatusDesc")
    private String statusDesc;
	@JsonFormat(pattern="yyyy-MM-dd HH:mm:ss", timezone = DTOConstants.TIMEZONE)
	@JsonProperty("EffDt")
    private Date effDt;
	@JsonFormat(pattern="yyyy-MM-dd HH:mm:ss", timezone = DTOConstants.TIMEZONE)
	@JsonProperty("CompensationDt")
    private Date compensationDt;
    private final static long serialVersionUID = -5405201342261665853L;

    public String getStatusCode() {
        return statusCode;
    }

    public void setStatusCode(String statusCode) {
        this.statusCode = statusCode;
    }

    public String getStatusDesc() {
        return statusDesc;
    }

    public void setStatusDesc(String statusDesc) {
        this.statusDesc = statusDesc;
    }

    public Date getEffDt() {
        return effDt;
    }

    public void setEffDt(Date effDt) {
        this.effDt = effDt;
    }

	public Date getCompensationDt() {
		return compensationDt;
	}

	public void setCompensationDt(Date compensationDt) {
		this.compensationDt = compensationDt;
	}

}
