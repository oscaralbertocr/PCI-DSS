
package co.com.ath.pgw.bsn.globalPay.model;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlSchemaType;
import javax.xml.bind.annotation.XmlType;
import javax.xml.datatype.XMLGregorianCalendar;


/**
 * <p>Clase Java para CardLogicalData_Type complex type.
 * 
 * <p>El siguiente fragmento de esquema especifica el contenido que se espera que haya en esta clase.
 * 
 * <pre>
 * &lt;complexType name="CardLogicalData_Type">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element ref="{urn://ath.com.co/xsd/common/}CardEmbossNum"/>
 *         &lt;element ref="{urn://ath.com.co/xsd/common/}CardSeqNum" minOccurs="0"/>
 *         &lt;element ref="{urn://ath.com.co/xsd/common/}Brand"/>
 *         &lt;element ref="{urn://ath.com.co/xsd/common/}IssuerName" minOccurs="0"/>
 *         &lt;element ref="{urn://ath.com.co/xsd/common/}IssDt" minOccurs="0"/>
 *         &lt;element ref="{urn://ath.com.co/xsd/common/}ExpDt"/>
 *         &lt;element ref="{urn://ath.com.co/xsd/common/}CardVrfyData"/>
 *         &lt;element ref="{urn://ath.com.co/xsd/common/}Name" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "CardLogicalData_Type", propOrder = {
    "cardEmbossNum",
    "cardSeqNum",
    "brand",
    "issuerName",
    "issDt",
    "expDt",
    "cardVrfyData",
    "name"
})
public class CardLogicalDataType {

    @XmlElement(name = "CardEmbossNum", required = true)
    protected String cardEmbossNum;
    @XmlElement(name = "CardSeqNum")
    protected String cardSeqNum;
    @XmlElement(name = "Brand", required = true)
    protected String brand;
    @XmlElement(name = "IssuerName")
    protected String issuerName;
    @XmlElement(name = "IssDt")
    @XmlSchemaType(name = "dateTime")
    protected XMLGregorianCalendar issDt;
    @XmlElement(name = "ExpDt", required = true)
    @XmlSchemaType(name = "dateTime")
    protected XMLGregorianCalendar expDt;
    @XmlElement(name = "CardVrfyData", required = true)
    protected String cardVrfyData;
    @XmlElement(name = "Name")
    protected String name;

    /**
     * Obtiene el valor de la propiedad cardEmbossNum.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCardEmbossNum() {
        return cardEmbossNum;
    }

    /**
     * Define el valor de la propiedad cardEmbossNum.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCardEmbossNum(String value) {
        this.cardEmbossNum = value;
    }

    /**
     * Obtiene el valor de la propiedad cardSeqNum.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCardSeqNum() {
        return cardSeqNum;
    }

    /**
     * Define el valor de la propiedad cardSeqNum.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCardSeqNum(String value) {
        this.cardSeqNum = value;
    }

    /**
     * Obtiene el valor de la propiedad brand.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getBrand() {
        return brand;
    }

    /**
     * Define el valor de la propiedad brand.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setBrand(String value) {
        this.brand = value;
    }

    /**
     * Obtiene el valor de la propiedad issuerName.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getIssuerName() {
        return issuerName;
    }

    /**
     * Define el valor de la propiedad issuerName.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setIssuerName(String value) {
        this.issuerName = value;
    }

    /**
     * Obtiene el valor de la propiedad issDt.
     * 
     * @return
     *     possible object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public XMLGregorianCalendar getIssDt() {
        return issDt;
    }

    /**
     * Define el valor de la propiedad issDt.
     * 
     * @param value
     *     allowed object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public void setIssDt(XMLGregorianCalendar value) {
        this.issDt = value;
    }

    /**
     * Obtiene el valor de la propiedad expDt.
     * 
     * @return
     *     possible object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public XMLGregorianCalendar getExpDt() {
        return expDt;
    }

    /**
     * Define el valor de la propiedad expDt.
     * 
     * @param value
     *     allowed object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public void setExpDt(XMLGregorianCalendar value) {
        this.expDt = value;
    }

    /**
     * Obtiene el valor de la propiedad cardVrfyData.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCardVrfyData() {
        return cardVrfyData;
    }

    /**
     * Define el valor de la propiedad cardVrfyData.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCardVrfyData(String value) {
        this.cardVrfyData = value;
    }

    /**
     * Obtiene el valor de la propiedad name.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getName() {
        return name;
    }

    /**
     * Define el valor de la propiedad name.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setName(String value) {
        this.name = value;
    }

}
