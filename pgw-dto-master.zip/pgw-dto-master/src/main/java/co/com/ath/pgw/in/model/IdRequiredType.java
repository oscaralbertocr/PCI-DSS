package co.com.ath.pgw.in.model;


public class IdRequiredType {

    
    protected Boolean required;

    /**
     * Obtiene el valor de la propiedad required.
     * 
     * @return
     *     possible object is
     *     {@link Boolean }
     *     
     */
    public Boolean isRequired() {
        return required;
    }

    /**
     * Define el valor de la propiedad required.
     * 
     * @param value
     *     allowed object is
     *     {@link Boolean }
     *     
     */
    public void setRequired(Boolean value) {
        this.required = value;
    }

}
