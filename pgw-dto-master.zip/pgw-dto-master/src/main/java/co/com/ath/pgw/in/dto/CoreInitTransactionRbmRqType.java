
package co.com.ath.pgw.in.dto;

import java.util.ArrayList;
import java.util.List;

import co.com.ath.pgw.core.logging.util.XMLUtil;
import co.com.ath.pgw.in.model.AgreementInfoType;
import co.com.ath.pgw.in.model.CurrencyAmtType;
import co.com.ath.pgw.in.model.FeeType;
import co.com.ath.pgw.in.model.OrderInfoType;
import co.com.ath.pgw.in.model.PersonalDataType;
import co.com.ath.pgw.in.model.ReferenceType;
import co.com.ath.pgw.in.model.SvcRqType;
import co.com.ath.pgw.in.model.TaxFeeType;


/**
 * <p>Clase Java para CoreInitTransactionRbmRq_Type complex type.
 * 
 * <p>El siguiente fragmento de esquema especifica el contenido que se espera que haya en esta clase.
 * 
 * <pre>
 * &lt;complexType name="CoreInitTransactionRbmRq_Type">
 *   &lt;complexContent>
 *     &lt;extension base="{urn://ath.com.co/xsd/common/}SvcRq_Type">
 *       &lt;sequence>
 *         &lt;element ref="{urn://ath.com.co/xsd/common/}PmtId"/>
 *         &lt;element ref="{urn://ath.com.co/xsd/common/}PersonalData" maxOccurs="50" minOccurs="0"/>
 *         &lt;element ref="{urn://ath.com.co/xsd/common/}UserType"/>
 *         &lt;element ref="{urn://ath.com.co/xsd/common/}AgreementInfo" minOccurs="0"/>
 *         &lt;element ref="{urn://ath.com.co/xsd/common/}OrderInfo" minOccurs="0"/>
 *         &lt;element ref="{urn://ath.com.co/xsd/common/}Fee" minOccurs="0"/>
 *         &lt;element ref="{urn://ath.com.co/xsd/common/}TaxFee" maxOccurs="unbounded"/>
 *         &lt;element ref="{urn://ath.com.co/xsd/common/}Reference" maxOccurs="50" minOccurs="0"/>
 *         &lt;element ref="{urn://ath.com.co/xsd/common/}CurrencyAmt" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/extension>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
public class CoreInitTransactionRbmRqType
    extends SvcRqType implements Cloneable
{
    
    protected String pmtId;

    protected List<PersonalDataType> personalData;
   
    protected String userType;
   
    protected AgreementInfoType agreementInfo;
   
    protected OrderInfoType orderInfo;
   
    protected FeeType fee;
   
    protected List<TaxFeeType> taxFee;
   
    protected List<ReferenceType> reference;
   
    protected CurrencyAmtType currencyAmt;

    /**
     * Obtiene el valor de la propiedad pmtId.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPmtId() {
        return pmtId;
    }

    /**
     * Define el valor de la propiedad pmtId.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPmtId(String value) {
        this.pmtId = value;
    }

    /**
     * Gets the value of the personalData property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the personalData property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getPersonalData().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link PersonalDataType }
     * 
     * 
     */
    public List<PersonalDataType> getPersonalData() {
        if (personalData == null) {
            personalData = new ArrayList<PersonalDataType>();
        }
        return this.personalData;
    }

    /**
     * Obtiene el valor de la propiedad userType.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getUserType() {
        return userType;
    }

    /**
     * Define el valor de la propiedad userType.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setUserType(String value) {
        this.userType = value;
    }

    /**
     * Obtiene el valor de la propiedad agreementInfo.
     * 
     * @return
     *     possible object is
     *     {@link AgreementInfoType }
     *     
     */
    public AgreementInfoType getAgreementInfo() {
        return agreementInfo;
    }

    /**
     * Define el valor de la propiedad agreementInfo.
     * 
     * @param value
     *     allowed object is
     *     {@link AgreementInfoType }
     *     
     */
    public void setAgreementInfo(AgreementInfoType value) {
        this.agreementInfo = value;
    }

    /**
     * Obtiene el valor de la propiedad orderInfo.
     * 
     * @return
     *     possible object is
     *     {@link OrderInfoType }
     *     
     */
    public OrderInfoType getOrderInfo() {
        return orderInfo;
    }

    /**
     * Define el valor de la propiedad orderInfo.
     * 
     * @param value
     *     allowed object is
     *     {@link OrderInfoType }
     *     
     */
    public void setOrderInfo(OrderInfoType value) {
        this.orderInfo = value;
    }

    /**
     * Obtiene el valor de la propiedad fee.
     * 
     * @return
     *     possible object is
     *     {@link FeeType }
     *     
     */
    public FeeType getFee() {
        return fee;
    }

    /**
     * Define el valor de la propiedad fee.
     * 
     * @param value
     *     allowed object is
     *     {@link FeeType }
     *     
     */
    public void setFee(FeeType value) {
        this.fee = value;
    }

    /**
     * Gets the value of the taxFee property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the taxFee property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getTaxFee().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link TaxFeeType }
     * 
     * 
     */
    public List<TaxFeeType> getTaxFee() {
        if (taxFee == null) {
            taxFee = new ArrayList<TaxFeeType>();
        }
        return this.taxFee;
    }

    /**
     * Gets the value of the reference property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the reference property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getReference().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link ReferenceType }
     * 
     * 
     */
    public List<ReferenceType> getReference() {
        if (reference == null) {
            reference = new ArrayList<ReferenceType>();
        }
        return this.reference;
    }

    /**
     * Obtiene el valor de la propiedad currencyAmt.
     * 
     * @return
     *     possible object is
     *     {@link CurrencyAmtType }
     *     
     */
    public CurrencyAmtType getCurrencyAmt() {
        return currencyAmt;
    }

    /**
     * Define el valor de la propiedad currencyAmt.
     * 
     * @param value
     *     allowed object is
     *     {@link CurrencyAmtType }
     *     
     */
    public void setCurrencyAmt(CurrencyAmtType value) {
        this.currencyAmt = value;
    }

	public void setPersonalData(List<PersonalDataType> personalData) {
		this.personalData = personalData;
	}

	public void setTaxFee(List<TaxFeeType> taxFee) {
		this.taxFee = taxFee;
	}

	public void setReference(List<ReferenceType> reference) {
		this.reference = reference;
	}
    
	@Override
	public String toString() {
		XMLUtil<CoreInitTransactionRbmRqType> requestParser = new XMLUtil<CoreInitTransactionRbmRqType>();
		return requestParser.convertObjectToXml(this);
	}    

}
