
package co.com.ath.pgw.rest.response.dto;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonProperty;

import co.com.ath.pgw.core.logging.util.XMLUtil;
import co.com.ath.pgw.rest.dto.InvoicePmtInfo;
import co.com.ath.pgw.rest.dto.RefInfo;

public class TransactionCreateResponse implements Serializable {

	@JsonProperty("InvoicePmtInfo")
	private InvoicePmtInfo invoicePmtInfo;
	@JsonProperty("RefInfo")
	private List<RefInfo> refInfo;
	private static final long serialVersionUID = -249001333125035261L;

	public InvoicePmtInfo getInvoicePmtInfo() {
		return invoicePmtInfo;
	}

	public void setInvoicePmtInfo(InvoicePmtInfo invoicePmtInfo) {
		this.invoicePmtInfo = invoicePmtInfo;
	}
	
	public List<RefInfo> getRefInfo() {
		if (refInfo == null) {
			refInfo = new ArrayList<RefInfo>();
		}
		return refInfo;
	}

	public void setRefInfo(List<RefInfo> refInfo) {
		this.refInfo = refInfo;
	}

	@Override
	public String toString() {
		XMLUtil<TransactionCreateResponse> util = new XMLUtil<TransactionCreateResponse>();
		return util.convertObjectToJson(this);
	}

}
