package co.com.ath.ws.rs.objects;

import java.io.Serializable;
import java.util.Date;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.fasterxml.jackson.annotation.JsonProperty;

@JsonInclude(Include.NON_NULL)
public class MsgRsHdrNotification implements Serializable {

	private static final long serialVersionUID = 1L;

	@JsonProperty("status")
	private StatusNotification status;

	@JsonProperty("endDt")
	private Date endDt;

	public StatusNotification getStatus() {
		return status;
	}

	public void setStatus(StatusNotification status) {
		this.status = status;
	}

	public Date getEndDt() {
		return endDt;
	}

	public void setEndDt(Date endDt) {
		this.endDt = endDt;
	}
	
	
}
