package co.com.ath.ws.rs;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.fasterxml.jackson.annotation.JsonProperty;

import co.com.ath.pgw.core.logging.util.XMLUtil;
import co.com.ath.ws.rs.objects.BankInfoNotification;
import co.com.ath.ws.rs.objects.DepAcctTrnNotification;
import co.com.ath.ws.rs.objects.GetTransactionByIdType;
import co.com.ath.ws.rs.objects.PmtStatusNotification;


@JsonInclude(Include.NON_NULL)
public class NotificationPaymentsRq implements Serializable {

	private static final long serialVersionUID = 1L;

	@JsonProperty("depAcctTrnRec")
	private DepAcctTrnNotification depAcctTrnRec;

	@JsonProperty("pmtStatus")
	private PmtStatusNotification pmtStatus;

	@JsonProperty("bankInfo")	
	private BankInfoNotification bankInfo;
	
	@JsonProperty("getTransactionByIdType")
	private GetTransactionByIdType getTransactionByIdType;

	public DepAcctTrnNotification getDepAcctTrnRec() {
		return depAcctTrnRec;
	}

	public PmtStatusNotification getPmtStatus() {
		return pmtStatus;
	}

	public void setPmtStatus(PmtStatusNotification pmtStatus) {
		this.pmtStatus = pmtStatus;
	}

	public void setDepAcctTrnRec(DepAcctTrnNotification depAcctTrnRec) {
		this.depAcctTrnRec = depAcctTrnRec;
	}

	public BankInfoNotification getBankInfo() {
		return bankInfo;
	}

	public void setBankInfo(BankInfoNotification bankInfo) {
		this.bankInfo = bankInfo;
	}

	public GetTransactionByIdType getGetTransactionByIdType() {
		return getTransactionByIdType;
	}

	public void setGetTransactionByIdType(GetTransactionByIdType getTransactionByIdType) {
		this.getTransactionByIdType = getTransactionByIdType;
	}

	@Override
	public String toString() {
		XMLUtil<NotificationPaymentsRq> util = new XMLUtil<NotificationPaymentsRq>();
		return util.convertObjectToJson(this);
	}

}
