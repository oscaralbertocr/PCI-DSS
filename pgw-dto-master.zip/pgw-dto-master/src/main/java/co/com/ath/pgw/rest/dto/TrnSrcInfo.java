
package co.com.ath.pgw.rest.dto;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonProperty;

public class TrnSrcInfo implements Serializable
{
	@JsonProperty("TrnSrc")
    private String trnSrc;
	
	@JsonProperty("Desc")
    private String desc;
	
    private final static long serialVersionUID = -7966246337956737590L;

    public String getTrnSrc() {
        return trnSrc;
    }

    public void setTrnSrc(String trnSrc) {
        this.trnSrc = trnSrc;
    }

	public String getDesc() {
		return desc;
	}

	public void setDesc(String desc) {
		this.desc = desc;
	}
    
    

}
