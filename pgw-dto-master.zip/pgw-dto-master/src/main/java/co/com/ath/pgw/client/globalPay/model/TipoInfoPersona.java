
package co.com.ath.pgw.client.globalPay.model;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlType;

import co.com.ath.pgw.client.globalPay.model.TipoIdPersona;


/**
 * <p>Clase Java para TipoInfoPersona complex type.
 * 
 * <p>El siguiente fragmento de esquema especifica el contenido que se espera que haya en esta clase.
 * 
 * <pre>
 * &lt;complexType name="TipoInfoPersona"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="nombres" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="apellidos" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="idPersona" type="{http://www.rbm.com.co/esb/}TipoIdPersona" minOccurs="0"/&gt;
 *         &lt;element name="telefono" type="{http://www.rbm.com.co/esb/globalpay/}TipoTelefono" minOccurs="0"/&gt;
 *         &lt;element name="correo" type="{http://www.rbm.com.co/esb/globalpay/}TipoCorreoElectronico" minOccurs="0"/&gt;
 *         &lt;element name="numeroTelefonoCelular" type="{http://www.rbm.com.co/esb/globalpay/}TipoTelefono" minOccurs="0"/&gt;
 *         &lt;element name="direccion" type="{http://www.rbm.com.co/esb/globalpay/}TipoDireccion" minOccurs="0"/&gt;
 *         &lt;element name="ciudad" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="direccionEntrega" type="{http://www.rbm.com.co/esb/globalpay/}TipoDireccion" minOccurs="0"/&gt;
 *         &lt;element name="ciudadEntrega" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "TipoInfoPersona", propOrder = {
    "nombres",
    "apellidos",
    "idPersona",
    "telefono",
    "correo",
    "numeroTelefonoCelular",
    "direccion",
    "ciudad",
    "direccionEntrega",
    "ciudadEntrega"
})
public class TipoInfoPersona {

    protected String nombres;
    protected String apellidos;
    protected TipoIdPersona idPersona;
    protected Long telefono;
    protected String correo;
    protected Long numeroTelefonoCelular;
    protected String direccion;
    protected String ciudad;
    protected String direccionEntrega;
    protected String ciudadEntrega;

    /**
     * Obtiene el valor de la propiedad nombres.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getNombres() {
        return nombres;
    }

    /**
     * Define el valor de la propiedad nombres.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setNombres(String value) {
        this.nombres = value;
    }

    /**
     * Obtiene el valor de la propiedad apellidos.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getApellidos() {
        return apellidos;
    }

    /**
     * Define el valor de la propiedad apellidos.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setApellidos(String value) {
        this.apellidos = value;
    }

    /**
     * Obtiene el valor de la propiedad idPersona.
     * 
     * @return
     *     possible object is
     *     {@link TipoIdPersona }
     *     
     */
    public TipoIdPersona getIdPersona() {
        return idPersona;
    }

    /**
     * Define el valor de la propiedad idPersona.
     * 
     * @param value
     *     allowed object is
     *     {@link TipoIdPersona }
     *     
     */
    public void setIdPersona(TipoIdPersona value) {
        this.idPersona = value;
    }

    /**
     * Obtiene el valor de la propiedad telefono.
     * 
     * @return
     *     possible object is
     *     {@link Long }
     *     
     */
    public Long getTelefono() {
        return telefono;
    }

    /**
     * Define el valor de la propiedad telefono.
     * 
     * @param value
     *     allowed object is
     *     {@link Long }
     *     
     */
    public void setTelefono(Long value) {
        this.telefono = value;
    }

    /**
     * Obtiene el valor de la propiedad correo.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCorreo() {
        return correo;
    }

    /**
     * Define el valor de la propiedad correo.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCorreo(String value) {
        this.correo = value;
    }

    /**
     * Obtiene el valor de la propiedad numeroTelefonoCelular.
     * 
     * @return
     *     possible object is
     *     {@link Long }
     *     
     */
    public Long getNumeroTelefonoCelular() {
        return numeroTelefonoCelular;
    }

    /**
     * Define el valor de la propiedad numeroTelefonoCelular.
     * 
     * @param value
     *     allowed object is
     *     {@link Long }
     *     
     */
    public void setNumeroTelefonoCelular(Long value) {
        this.numeroTelefonoCelular = value;
    }

    /**
     * Obtiene el valor de la propiedad direccion.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDireccion() {
        return direccion;
    }

    /**
     * Define el valor de la propiedad direccion.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDireccion(String value) {
        this.direccion = value;
    }

    /**
     * Obtiene el valor de la propiedad ciudad.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCiudad() {
        return ciudad;
    }

    /**
     * Define el valor de la propiedad ciudad.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCiudad(String value) {
        this.ciudad = value;
    }

    /**
     * Obtiene el valor de la propiedad direccionEntrega.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDireccionEntrega() {
        return direccionEntrega;
    }

    /**
     * Define el valor de la propiedad direccionEntrega.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDireccionEntrega(String value) {
        this.direccionEntrega = value;
    }

    /**
     * Obtiene el valor de la propiedad ciudadEntrega.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCiudadEntrega() {
        return ciudadEntrega;
    }

    /**
     * Define el valor de la propiedad ciudadEntrega.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCiudadEntrega(String value) {
        this.ciudadEntrega = value;
    }

}
