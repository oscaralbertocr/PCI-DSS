
package co.com.ath.pgw.client.bank.info.xsd.ifx;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlSchemaType;
import javax.xml.bind.annotation.XmlType;
import javax.xml.datatype.XMLGregorianCalendar;

import co.com.ath.pgw.core.logging.util.XMLUtil;


/**
 * <p>Clase Java para BillPmtInfo_Type complex type.
 * 
 * <p>El siguiente fragmento de esquema especifica el contenido que se espera que haya en esta clase.
 * 
 * <pre>
 * &lt;complexType name="BillPmtInfo_Type">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element ref="{urn://grupoaval.com/xsd/ifx/}DepAcctIdFrom"/>
 *         &lt;element ref="{urn://grupoaval.com/xsd/ifx/}CurAmt"/>
 *         &lt;element ref="{urn://grupoaval.com/xsd/ifx/}NIE"/>
 *         &lt;element ref="{urn://grupoaval.com/xsd/ifx/}ServiceCode"/>
 *         &lt;element ref="{urn://grupoaval.com/xsd/ifx/}CompositeCurAmt"/>
 *         &lt;element ref="{urn://grupoaval.com/xsd/ifx/v2/}PmtCodServ" minOccurs="0"/>
 *         &lt;element ref="{urn://grupoaval.com/xsd/ifx/v2/}OptPmtCodServ" minOccurs="0"/>
 *         &lt;element ref="{urn://grupoaval.com/xsd/ifx/v2/}InvoiceNum" minOccurs="0"/>
 *         &lt;element ref="{urn://grupoaval.com/xsd/ifx/v2/}ExpDt" minOccurs="0"/>
 *         &lt;element ref="{urn://grupoaval.com/xsd/ifx/v2/}Reference" minOccurs="0"/>
 *         &lt;element ref="{urn://grupoaval.com/xsd/ifx/}RiskFactorInfo" minOccurs="0"/>
 *         &lt;element name="TrxDt" type="{http://www.w3.org/2001/XMLSchema}dateTime" minOccurs="0"/>
 *         &lt;element name="ApprovalId" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="TrxState" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "BillPmtInfo_Type", propOrder = {
    "depAcctIdFrom",
    "curAmt",
    "nie",
    "serviceCode",
    "compositeCurAmt",
    "pmtCodServ",
    "optPmtCodServ",
    "invoiceNum",
    "expDt",
    "reference",
    "riskFactorInfo",
    "trxDt",
    "approvalId",
    "trxState"
})
public class BillPmtInfoType {

    @XmlElement(name = "DepAcctIdFrom", namespace = "urn://grupoaval.com/xsd/ifx/", required = true)
    protected DepAcctIdFromType depAcctIdFrom;
    @XmlElement(name = "CurAmt", required = true)
    protected CurAmtType curAmt;
    @XmlElement(name = "NIE", required = true)
    protected String nie;
    @XmlElement(name = "ServiceCode", required = true)
    protected String serviceCode;
    @XmlElement(name = "CompositeCurAmt", required = true)
    protected CompositeCurAmtType compositeCurAmt;
    @XmlElement(name = "PmtCodServ", namespace = "urn://grupoaval.com/xsd/ifx/v2/")
    protected String pmtCodServ;
    @XmlElement(name = "OptPmtCodServ", namespace = "urn://grupoaval.com/xsd/ifx/v2/")
    protected String optPmtCodServ;
    @XmlElement(name = "InvoiceNum", namespace = "urn://grupoaval.com/xsd/ifx/v2/")
    protected String invoiceNum;
    @XmlElement(name = "ExpDt", namespace = "urn://grupoaval.com/xsd/ifx/v2/")
    @XmlSchemaType(name = "dateTime")
    protected String expDt;
    @XmlElement(name = "Reference", namespace = "urn://grupoaval.com/xsd/ifx/v2/")
    protected String reference;
    @XmlElement(name = "RiskFactorInfo")
    protected RiskFactorInfoType riskFactorInfo;
    @XmlElement(name = "TrxDt", namespace = "")
    @XmlSchemaType(name = "dateTime")
    protected String trxDt;
    @XmlElement(name = "ApprovalId", namespace = "")
    protected String approvalId;
    @XmlElement(name = "TrxState", namespace = "")
    protected String trxState;

    /**
     * Obtiene el valor de la propiedad depAcctIdFrom.
     * 
     * @return
     *     possible object is
     *     {@link DepAcctIdFromType }
     *     
     */
    public DepAcctIdFromType getDepAcctIdFrom() {
        return depAcctIdFrom;
    }

    /**
     * Define el valor de la propiedad depAcctIdFrom.
     * 
     * @param value
     *     allowed object is
     *     {@link DepAcctIdFromType }
     *     
     */
    public void setDepAcctIdFrom(DepAcctIdFromType value) {
        this.depAcctIdFrom = value;
    }

    /**
     * Obtiene el valor de la propiedad curAmt.
     * 
     * @return
     *     possible object is
     *     {@link CurAmtType }
     *     
     */
    public CurAmtType getCurAmt() {
        return curAmt;
    }

    /**
     * Define el valor de la propiedad curAmt.
     * 
     * @param value
     *     allowed object is
     *     {@link CurAmtType }
     *     
     */
    public void setCurAmt(CurAmtType value) {
        this.curAmt = value;
    }

    /**
     * Obtiene el valor de la propiedad nie.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getNIE() {
        return nie;
    }

    /**
     * Define el valor de la propiedad nie.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setNIE(String value) {
        this.nie = value;
    }

    /**
     * Obtiene el valor de la propiedad serviceCode.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getServiceCode() {
        return serviceCode;
    }

    /**
     * Define el valor de la propiedad serviceCode.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setServiceCode(String value) {
        this.serviceCode = value;
    }

    /**
     * Obtiene el valor de la propiedad compositeCurAmt.
     * 
     * @return
     *     possible object is
     *     {@link CompositeCurAmtType }
     *     
     */
    public CompositeCurAmtType getCompositeCurAmt() {
        return compositeCurAmt;
    }

    /**
     * Define el valor de la propiedad compositeCurAmt.
     * 
     * @param value
     *     allowed object is
     *     {@link CompositeCurAmtType }
     *     
     */
    public void setCompositeCurAmt(CompositeCurAmtType value) {
        this.compositeCurAmt = value;
    }

    /**
     * Obtiene el valor de la propiedad pmtCodServ.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPmtCodServ() {
        return pmtCodServ;
    }

    /**
     * Define el valor de la propiedad pmtCodServ.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPmtCodServ(String value) {
        this.pmtCodServ = value;
    }

    /**
     * Obtiene el valor de la propiedad optPmtCodServ.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getOptPmtCodServ() {
        return optPmtCodServ;
    }

    /**
     * Define el valor de la propiedad optPmtCodServ.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setOptPmtCodServ(String value) {
        this.optPmtCodServ = value;
    }

    /**
     * Obtiene el valor de la propiedad invoiceNum.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getInvoiceNum() {
        return invoiceNum;
    }

    /**
     * Define el valor de la propiedad invoiceNum.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setInvoiceNum(String value) {
        this.invoiceNum = value;
    }

    /**
     * Obtiene el valor de la propiedad expDt.
     * 
     * @return
     *     possible object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public String getExpDt() {
        return expDt;
    }

    /**
     * Define el valor de la propiedad expDt.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setExpDt(String value) {
        this.expDt = value;
    }

    /**
     * Obtiene el valor de la propiedad reference.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getReference() {
        return reference;
    }

    /**
     * Define el valor de la propiedad reference.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setReference(String value) {
        this.reference = value;
    }

    /**
     * Obtiene el valor de la propiedad riskFactorInfo.
     * 
     * @return
     *     possible object is
     *     {@link RiskFactorInfoType }
     *     
     */
    public RiskFactorInfoType getRiskFactorInfo() {
        return riskFactorInfo;
    }

    /**
     * Define el valor de la propiedad riskFactorInfo.
     * 
     * @param value
     *     allowed object is
     *     {@link RiskFactorInfoType }
     *     
     */
    public void setRiskFactorInfo(RiskFactorInfoType value) {
        this.riskFactorInfo = value;
    }

    /**
     * Obtiene el valor de la propiedad trxDt.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getTrxDt() {
        return trxDt;
    }

    /**
     * Define el valor de la propiedad trxDt.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setTrxDt(String value) {
        this.trxDt = value;
    }

    /**
     * Obtiene el valor de la propiedad approvalId.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getApprovalId() {
        return approvalId;
    }

    /**
     * Define el valor de la propiedad approvalId.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setApprovalId(String value) {
        this.approvalId = value;
    }

    /**
     * Obtiene el valor de la propiedad trxState.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getTrxState() {
        return trxState;
    }

    /**
     * Define el valor de la propiedad trxState.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setTrxState(String value) {
        this.trxState = value;
    }
    
    public String toString() {
    	XMLUtil<BillPmtInfoType> requestParser = 
    							new XMLUtil<BillPmtInfoType>();
		return requestParser.convertObjectToXml(this);
    }

}
