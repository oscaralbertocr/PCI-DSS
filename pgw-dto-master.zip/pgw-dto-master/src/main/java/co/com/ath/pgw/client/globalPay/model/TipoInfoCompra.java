
package co.com.ath.pgw.client.globalPay.model;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;

import co.com.ath.pgw.client.globalPay.model.TipoInfoImpuestos;
import co.com.ath.pgw.client.globalPay.model.TipoMontoDetallado;


/**
 * <p>Clase Java para TipoInfoCompra complex type.
 * 
 * <p>El siguiente fragmento de esquema especifica el contenido que se espera que haya en esta clase.
 * 
 * <pre>
 * &lt;complexType name="TipoInfoCompra"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="numeroFactura"&gt;
 *           &lt;simpleType&gt;
 *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string"&gt;
 *               &lt;maxLength value="20"/&gt;
 *             &lt;/restriction&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="montoTotal"&gt;
 *           &lt;simpleType&gt;
 *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}decimal"&gt;
 *               &lt;minExclusive value="0"/&gt;
 *               &lt;maxExclusive value="999999999999"/&gt;
 *             &lt;/restriction&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="infoImpuestos" type="{http://www.rbm.com.co/esb/}TipoInfoImpuestos" maxOccurs="unbounded" minOccurs="0"/&gt;
 *         &lt;element name="montoDetallado" type="{http://www.rbm.com.co/esb/}TipoMontoDetallado" maxOccurs="unbounded" minOccurs="0"/&gt;
 *         &lt;element name="infoComercio" type="{http://www.rbm.com.co/esb/globalpay/}TipoInfoComercio" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "TipoInfoCompra", propOrder = {
    "numeroFactura",
    "montoTotal",
    "infoImpuestos",
    "montoDetallado",
    "infoComercio"
})
public class TipoInfoCompra {

    @XmlElement(required = true)
    protected String numeroFactura;
    @XmlElement(required = true)
    protected BigDecimal montoTotal;
    @XmlElement(nillable = true)
    protected List<TipoInfoImpuestos> infoImpuestos;
    @XmlElement(nillable = true)
    protected List<TipoMontoDetallado> montoDetallado;
    protected TipoInfoComercio infoComercio;

    /**
     * Obtiene el valor de la propiedad numeroFactura.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getNumeroFactura() {
        return numeroFactura;
    }

    /**
     * Define el valor de la propiedad numeroFactura.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setNumeroFactura(String value) {
        this.numeroFactura = value;
    }

    /**
     * Obtiene el valor de la propiedad montoTotal.
     * 
     * @return
     *     possible object is
     *     {@link BigDecimal }
     *     
     */
    public BigDecimal getMontoTotal() {
        return montoTotal;
    }

    /**
     * Define el valor de la propiedad montoTotal.
     * 
     * @param value
     *     allowed object is
     *     {@link BigDecimal }
     *     
     */
    public void setMontoTotal(BigDecimal value) {
        this.montoTotal = value;
    }

    /**
     * Gets the value of the infoImpuestos property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the infoImpuestos property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getInfoImpuestos().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link TipoInfoImpuestos }
     * 
     * 
     */
    public List<TipoInfoImpuestos> getInfoImpuestos() {
        if (infoImpuestos == null) {
            infoImpuestos = new ArrayList<TipoInfoImpuestos>();
        }
        return this.infoImpuestos;
    }

    /**
     * Gets the value of the montoDetallado property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the montoDetallado property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getMontoDetallado().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link TipoMontoDetallado }
     * 
     * 
     */
    public List<TipoMontoDetallado> getMontoDetallado() {
        if (montoDetallado == null) {
            montoDetallado = new ArrayList<TipoMontoDetallado>();
        }
        return this.montoDetallado;
    }

    /**
     * Obtiene el valor de la propiedad infoComercio.
     * 
     * @return
     *     possible object is
     *     {@link TipoInfoComercio }
     *     
     */
    public TipoInfoComercio getInfoComercio() {
        return infoComercio;
    }

    /**
     * Define el valor de la propiedad infoComercio.
     * 
     * @param value
     *     allowed object is
     *     {@link TipoInfoComercio }
     *     
     */
    public void setInfoComercio(TipoInfoComercio value) {
        this.infoComercio = value;
    }

}
