
package co.com.ath.pgw.client.rbm.v1;

import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;
import co.com.ath.pgw.client.rbm.common.AgreementInfoType;
import co.com.ath.pgw.client.rbm.common.BankInfoType;
import co.com.ath.pgw.client.rbm.common.FeeType;
import co.com.ath.pgw.client.rbm.common.OrderInfoType;
import co.com.ath.pgw.client.rbm.common.PersonalDataType;
import co.com.ath.pgw.client.rbm.common.ReferenceType;
import co.com.ath.pgw.client.rbm.common.SvcRqType;
import co.com.ath.pgw.client.rbm.common.TaxFeeType;


/**
 * 
 * @author Jesus Octavio Avendaño <jesus.avendano@sophossolutions.com> 
 * @version 1.0 17/06/2020
 * @since 1.0
 * 
 * <p>Clase Java para AVALPaymentAddRq_Type complex type.
 * 
 * <p>El siguiente fragmento de esquema especifica el contenido que se espera que haya en esta clase.
 * 
 * <pre>
 * &lt;complexType name="AVALPaymentAddRq_Type">
 *   &lt;complexContent>
 *     &lt;extension base="{urn://ath.com.co/xsd/common/}SvcRq_Type">
 *       &lt;sequence>
 *         &lt;element ref="{urn://ath.com.co/xsd/common/}PmtId"/>
 *         &lt;element ref="{urn://ath.com.co/xsd/common/}PersonalData" maxOccurs="50" minOccurs="0"/>
 *         &lt;element ref="{urn://ath.com.co/xsd/common/}AgreementInfo"/>
 *         &lt;element ref="{urn://ath.com.co/xsd/common/}BankInfo"/>
 *         &lt;element ref="{urn://ath.com.co/xsd/common/}OrderInfo"/>
 *         &lt;element ref="{urn://ath.com.co/xsd/common/}Fee"/>
 *         &lt;element ref="{urn://ath.com.co/xsd/common/}TaxFee"/>
 *         &lt;element ref="{urn://ath.com.co/xsd/common/}Reference" maxOccurs="50" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/extension>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "AVALPaymentAddRq_Type", propOrder = {
    "pmtId",
    "personalData",
    "agreementInfo",
    "bankInfo",
    "orderInfo",
    "fee",
    "taxFee",
    "reference"
})
public class AVALPaymentAddRqType
    extends SvcRqType
{

    @XmlElement(name = "PmtId", namespace = "urn://ath.com.co/xsd/common/", required = true)
    protected String pmtId;
    @XmlElement(name = "PersonalData", namespace = "urn://ath.com.co/xsd/common/")
    protected List<PersonalDataType> personalData;
    @XmlElement(name = "AgreementInfo", namespace = "urn://ath.com.co/xsd/common/", required = true)
    protected AgreementInfoType agreementInfo;
    @XmlElement(name = "BankInfo", namespace = "urn://ath.com.co/xsd/common/", required = true)
    protected BankInfoType bankInfo;
    @XmlElement(name = "OrderInfo", namespace = "urn://ath.com.co/xsd/common/", required = true)
    protected OrderInfoType orderInfo;
    @XmlElement(name = "Fee", namespace = "urn://ath.com.co/xsd/common/", required = true)
    protected FeeType fee;
    @XmlElement(name = "TaxFee", namespace = "urn://ath.com.co/xsd/common/", required = true)
    protected TaxFeeType taxFee;
    @XmlElement(name = "Reference", namespace = "urn://ath.com.co/xsd/common/")
    protected List<ReferenceType> reference;

    /**
     * Obtiene el valor de la propiedad pmtId.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPmtId() {
        return pmtId;
    }

    /**
     * Define el valor de la propiedad pmtId.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPmtId(String value) {
        this.pmtId = value;
    }

    /**
     * Gets the value of the personalData property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the personalData property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getPersonalData().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link PersonalDataType }
     * 
     * 
     */
    public List<PersonalDataType> getPersonalData() {
        if (personalData == null) {
            personalData = new ArrayList<PersonalDataType>();
        }
        return this.personalData;
    }

    /**
     * Obtiene el valor de la propiedad agreementInfo.
     * 
     * @return
     *     possible object is
     *     {@link AgreementInfoType }
     *     
     */
    public AgreementInfoType getAgreementInfo() {
        return agreementInfo;
    }

    /**
     * Define el valor de la propiedad agreementInfo.
     * 
     * @param value
     *     allowed object is
     *     {@link AgreementInfoType }
     *     
     */
    public void setAgreementInfo(AgreementInfoType value) {
        this.agreementInfo = value;
    }

    /**
     * Obtiene el valor de la propiedad bankInfo.
     * 
     * @return
     *     possible object is
     *     {@link BankInfoType }
     *     
     */
    public BankInfoType getBankInfo() {
        return bankInfo;
    }

    /**
     * Define el valor de la propiedad bankInfo.
     * 
     * @param value
     *     allowed object is
     *     {@link BankInfoType }
     *     
     */
    public void setBankInfo(BankInfoType value) {
        this.bankInfo = value;
    }

    /**
     * Obtiene el valor de la propiedad orderInfo.
     * 
     * @return
     *     possible object is
     *     {@link OrderInfoType }
     *     
     */
    public OrderInfoType getOrderInfo() {
        return orderInfo;
    }

    /**
     * Define el valor de la propiedad orderInfo.
     * 
     * @param value
     *     allowed object is
     *     {@link OrderInfoType }
     *     
     */
    public void setOrderInfo(OrderInfoType value) {
        this.orderInfo = value;
    }

    /**
     * Obtiene el valor de la propiedad fee.
     * 
     * @return
     *     possible object is
     *     {@link FeeType }
     *     
     */
    public FeeType getFee() {
        return fee;
    }

    /**
     * Define el valor de la propiedad fee.
     * 
     * @param value
     *     allowed object is
     *     {@link FeeType }
     *     
     */
    public void setFee(FeeType value) {
        this.fee = value;
    }

    /**
     * Obtiene el valor de la propiedad taxFee.
     * 
     * @return
     *     possible object is
     *     {@link TaxFeeType }
     *     
     */
    public TaxFeeType getTaxFee() {
        return taxFee;
    }

    /**
     * Define el valor de la propiedad taxFee.
     * 
     * @param value
     *     allowed object is
     *     {@link TaxFeeType }
     *     
     */
    public void setTaxFee(TaxFeeType value) {
        this.taxFee = value;
    }

    /**
     * Gets the value of the reference property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the reference property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getReference().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link ReferenceType }
     * 
     * 
     */
    public List<ReferenceType> getReference() {
        if (reference == null) {
            reference = new ArrayList<ReferenceType>();
        }
        return this.reference;
    }

}
