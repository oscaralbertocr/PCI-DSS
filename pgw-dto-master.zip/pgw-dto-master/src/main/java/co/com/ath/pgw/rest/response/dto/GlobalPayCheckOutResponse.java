package co.com.ath.pgw.rest.response.dto;

import co.com.ath.pgw.core.logging.util.XMLUtil;

public class GlobalPayCheckOutResponse {

	private String status;
	private Long IdStatus;
	
	
	public GlobalPayCheckOutResponse(Long idStatus, String status) {
		this.status = status;
		this.IdStatus = idStatus;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public Long getIdStatus() {
		return IdStatus;
	}

	public void setIdStatus(Long idStatus) {
		IdStatus = idStatus;
	}

	@Override
	public String toString() {
		XMLUtil<GlobalPayCheckOutResponse> util = new XMLUtil<GlobalPayCheckOutResponse>();
		return util.convertObjectToJson(this);
	}

}