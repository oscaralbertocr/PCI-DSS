
package co.com.ath.pgw.client.rbm.v1;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;
import co.com.ath.pgw.client.rbm.common.TransactionStatusType;


/**
 * 
 * @author Jesus Octavio Avendaño <jesus.avendano@sophossolutions.com> 
 * @version 1.0 17/06/2020
 * @since 1.0
 * 
 * <p>Clase Java para RBMPaymentAddRs_Type complex type.
 * 
 * <p>El siguiente fragmento de esquema especifica el contenido que se espera que haya en esta clase.
 * 
 * <pre>
 * &lt;complexType name="RBMPaymentAddRs_Type">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element ref="{urn://ath.com.co/xsd/common/}StatusCode"/>
 *         &lt;element ref="{urn://ath.com.co/xsd/common/}StatusDesc"/>
 *         &lt;element ref="{urn://ath.com.co/xsd/common/}RqUID"/>
 *         &lt;element ref="{urn://ath.com.co/xsd/common/}PmtId" minOccurs="0"/>
 *         &lt;element ref="{urn://ath.com.co/xsd/common/}TransactionStatus" minOccurs="0"/>
 *         &lt;element ref="{urn://ath.com.co/xsd/common/}Token" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "RBMPaymentAddRs_Type", propOrder = {
    "statusCode",
    "statusDesc",
    "rqUID",
    "pmtId",
    "transactionStatus",
    "token"
})
public class RBMPaymentAddRsType {

    @XmlElement(name = "StatusCode", namespace = "urn://ath.com.co/xsd/common/")
    protected long statusCode;
    @XmlElement(name = "StatusDesc", namespace = "urn://ath.com.co/xsd/common/", required = true)
    protected String statusDesc;
    @XmlElement(name = "RqUID", namespace = "urn://ath.com.co/xsd/common/")
    protected long rqUID;
    @XmlElement(name = "PmtId", namespace = "urn://ath.com.co/xsd/common/")
    protected String pmtId;
    @XmlElement(name = "TransactionStatus", namespace = "urn://ath.com.co/xsd/common/")
    protected TransactionStatusType transactionStatus;
    @XmlElement(name = "Token", namespace = "urn://ath.com.co/xsd/common/")
    protected String token;

    /**
     * Obtiene el valor de la propiedad statusCode.
     * 
     */
    public long getStatusCode() {
        return statusCode;
    }

    /**
     * Define el valor de la propiedad statusCode.
     * 
     */
    public void setStatusCode(long value) {
        this.statusCode = value;
    }

    /**
     * Obtiene el valor de la propiedad statusDesc.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getStatusDesc() {
        return statusDesc;
    }

    /**
     * Define el valor de la propiedad statusDesc.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setStatusDesc(String value) {
        this.statusDesc = value;
    }

    /**
     * Obtiene el valor de la propiedad rqUID.
     * 
     */
    public long getRqUID() {
        return rqUID;
    }

    /**
     * Define el valor de la propiedad rqUID.
     * 
     */
    public void setRqUID(long value) {
        this.rqUID = value;
    }

    /**
     * Obtiene el valor de la propiedad pmtId.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPmtId() {
        return pmtId;
    }

    /**
     * Define el valor de la propiedad pmtId.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPmtId(String value) {
        this.pmtId = value;
    }

    /**
     * Obtiene el valor de la propiedad transactionStatus.
     * 
     * @return
     *     possible object is
     *     {@link TransactionStatusType }
     *     
     */
    public TransactionStatusType getTransactionStatus() {
        return transactionStatus;
    }

    /**
     * Define el valor de la propiedad transactionStatus.
     * 
     * @param value
     *     allowed object is
     *     {@link TransactionStatusType }
     *     
     */
    public void setTransactionStatus(TransactionStatusType value) {
        this.transactionStatus = value;
    }

    /**
     * Obtiene el valor de la propiedad token.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getToken() {
        return token;
    }

    /**
     * Define el valor de la propiedad token.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setToken(String value) {
        this.token = value;
    }

}
