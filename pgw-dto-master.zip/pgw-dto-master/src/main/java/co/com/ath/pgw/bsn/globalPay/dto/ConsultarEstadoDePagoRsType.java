
package co.com.ath.pgw.bsn.globalPay.dto;

import java.util.List;


import co.com.ath.pgw.core.logging.util.XMLUtil;
import co.com.ath.pgw.in.model.CabeceraRespuestaType;
import co.com.ath.pgw.in.model.InfoPagoType;
import co.com.ath.pgw.in.model.InfoRespuestaType;
import co.com.ath.pgw.in.model.ReferenceType;

/**
*
* @author camilo.bustamante@sophossolutions.com
* @version 1.0 03 Enero 2019
* @RQ31686 RBM_Integracion_Boton_TC_GlobalPay
* 
*/

/**
 * <p>Clase Java para ConsultarEstadoDePagoRs_Type complex type.
 * 
 * <p>El siguiente fragmento de esquema especifica el contenido que se espera que haya en esta clase.
 * 
 * <pre>
 * &lt;complexType name="ConsultarEstadoDePagoRs_Type">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element ref="{urn://ath.com.co/xsd/common/}CabeceraRespuesta"/>
 *         &lt;element ref="{urn://ath.com.co/xsd/common/}InfoPago"/>
 *         &lt;element ref="{urn://ath.com.co/xsd/common/}InfoRespuesta"/>
 *         &lt;element ref="{urn://ath.com.co/xsd/common/}Pmtid"/>
 *         &lt;element ref="{urn://ath.com.co/xsd/common/}Reference" maxOccurs="50" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 */
public class ConsultarEstadoDePagoRsType {

    
    protected CabeceraRespuestaType cabeceraRespuesta;
    
    protected List<InfoPagoType> infoPago;
    
    
    protected InfoRespuestaType infoRespuesta;
    
    
    protected String pmtid;
    
    
    protected List<ReferenceType> reference;

    
	public CabeceraRespuestaType getCabeceraRespuesta() {
		return cabeceraRespuesta;
	}

	public void setCabeceraRespuesta(CabeceraRespuestaType cabeceraRespuesta) {
		this.cabeceraRespuesta = cabeceraRespuesta;
	}

	public List<InfoPagoType> getInfoPago() {
		return infoPago;
	}

	public void setInfoPago(List<InfoPagoType> infoPago) {
		this.infoPago = infoPago;
	}

	public InfoRespuestaType getInfoRespuesta() {
		return infoRespuesta;
	}

	public void setInfoRespuesta(InfoRespuestaType infoRespuesta) {
		this.infoRespuesta = infoRespuesta;
	}

	public String getPmtid() {
		return pmtid;
	}

	public void setPmtid(String pmtid) {
		this.pmtid = pmtid;
	}
	
	public List<ReferenceType> getReference() {
		return reference;
	}

	public void setReference(List<ReferenceType> reference) {
		this.reference = reference;
	}

	@Override
	public String toString() {
		XMLUtil<ConsultarEstadoDePagoRsType> requestParser = 
				new XMLUtil<ConsultarEstadoDePagoRsType>();
		return requestParser.convertObjectToXml(this);
	}

}
