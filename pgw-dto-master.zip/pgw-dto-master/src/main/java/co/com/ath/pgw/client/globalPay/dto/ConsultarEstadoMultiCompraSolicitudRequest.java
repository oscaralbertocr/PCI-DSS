
package co.com.ath.pgw.client.globalPay.dto;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;

import co.com.ath.pgw.client.globalPay.model.TipoCabeceraSolicitud;
import co.com.ath.pgw.client.globalPay.model.TipoCredenciales;
import co.com.ath.pgw.core.logging.util.XMLUtil;


/**
 * <p>Clase Java para anonymous complex type.
 * 
 * <p>El siguiente fragmento de esquema especifica el contenido que se espera que haya en esta clase.
 * 
 * <pre>
 * &lt;complexType&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="credenciales" type="{http://www.rbm.com.co/esb/globalpay/}TipoCredenciales" minOccurs="0"/&gt;
 *         &lt;element name="cabeceraSolicitud" type="{http://www.rbm.com.co/esb/globalpay/}TipoCabeceraSolicitud"/&gt;
 *         &lt;element name="idTransaccion" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string"&gt;
 *               &lt;maxLength value="22"/&gt;
 *             &lt;/restriction&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "", propOrder = {
    "credenciales",
    "cabeceraSolicitud",
    "idTransaccion"
})
@XmlRootElement(name = "ConsultarEstadoMultiCompraSolicitud")
public class ConsultarEstadoMultiCompraSolicitudRequest {

    protected TipoCredenciales credenciales;
    @XmlElement(required = true)
    protected TipoCabeceraSolicitud cabeceraSolicitud;
    protected String idTransaccion;

    /**
     * Obtiene el valor de la propiedad credenciales.
     * 
     * @return
     *     possible object is
     *     {@link TipoCredenciales }
     *     
     */
    public TipoCredenciales getCredenciales() {
        return credenciales;
    }

    /**
     * Define el valor de la propiedad credenciales.
     * 
     * @param value
     *     allowed object is
     *     {@link TipoCredenciales }
     *     
     */
    public void setCredenciales(TipoCredenciales value) {
        this.credenciales = value;
    }

    /**
     * Obtiene el valor de la propiedad cabeceraSolicitud.
     * 
     * @return
     *     possible object is
     *     {@link TipoCabeceraSolicitud }
     *     
     */
    public TipoCabeceraSolicitud getCabeceraSolicitud() {
        return cabeceraSolicitud;
    }

    /**
     * Define el valor de la propiedad cabeceraSolicitud.
     * 
     * @param value
     *     allowed object is
     *     {@link TipoCabeceraSolicitud }
     *     
     */
    public void setCabeceraSolicitud(TipoCabeceraSolicitud value) {
        this.cabeceraSolicitud = value;
    }

    /**
     * Obtiene el valor de la propiedad idTransaccion.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getIdTransaccion() {
        return idTransaccion;
    }

    /**
     * Define el valor de la propiedad idTransaccion.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setIdTransaccion(String value) {
        this.idTransaccion = value;
    }
    
    @Override
	public String toString() {
		XMLUtil<ConsultarEstadoMultiCompraSolicitudRequest> requestParser = new XMLUtil<ConsultarEstadoMultiCompraSolicitudRequest>();
		return requestParser.convertObjectToXml(this);
	}

}
