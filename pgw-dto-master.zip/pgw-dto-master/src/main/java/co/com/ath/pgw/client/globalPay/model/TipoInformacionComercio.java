
package co.com.ath.pgw.client.globalPay.model;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Clase Java para TipoInformacionComercio complex type.
 * 
 * <p>El siguiente fragmento de esquema especifica el contenido que se espera que haya en esta clase.
 * 
 * <pre>
 * &lt;complexType name="TipoInformacionComercio"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="politicaEntrega" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string"&gt;
 *               &lt;maxLength value="100"/&gt;
 *             &lt;/restriction&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="politicaDevoluciones" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string"&gt;
 *               &lt;maxLength value="100"/&gt;
 *             &lt;/restriction&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="serviciosOfrecidos" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string"&gt;
 *               &lt;maxLength value="100"/&gt;
 *             &lt;/restriction&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="infoAtencionCliente" type="{http://www.rbm.com.co/esb/globalpay/}TipoInfoAtencionCliente" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "TipoInformacionComercio", propOrder = {
    "politicaEntrega",
    "politicaDevoluciones",
    "serviciosOfrecidos",
    "infoAtencionCliente"
})
public class TipoInformacionComercio {

    protected String politicaEntrega;
    protected String politicaDevoluciones;
    protected String serviciosOfrecidos;
    protected TipoInfoAtencionCliente infoAtencionCliente;

    /**
     * Obtiene el valor de la propiedad politicaEntrega.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPoliticaEntrega() {
        return politicaEntrega;
    }

    /**
     * Define el valor de la propiedad politicaEntrega.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPoliticaEntrega(String value) {
        this.politicaEntrega = value;
    }

    /**
     * Obtiene el valor de la propiedad politicaDevoluciones.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPoliticaDevoluciones() {
        return politicaDevoluciones;
    }

    /**
     * Define el valor de la propiedad politicaDevoluciones.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPoliticaDevoluciones(String value) {
        this.politicaDevoluciones = value;
    }

    /**
     * Obtiene el valor de la propiedad serviciosOfrecidos.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getServiciosOfrecidos() {
        return serviciosOfrecidos;
    }

    /**
     * Define el valor de la propiedad serviciosOfrecidos.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setServiciosOfrecidos(String value) {
        this.serviciosOfrecidos = value;
    }

    /**
     * Obtiene el valor de la propiedad infoAtencionCliente.
     * 
     * @return
     *     possible object is
     *     {@link TipoInfoAtencionCliente }
     *     
     */
    public TipoInfoAtencionCliente getInfoAtencionCliente() {
        return infoAtencionCliente;
    }

    /**
     * Define el valor de la propiedad infoAtencionCliente.
     * 
     * @param value
     *     allowed object is
     *     {@link TipoInfoAtencionCliente }
     *     
     */
    public void setInfoAtencionCliente(TipoInfoAtencionCliente value) {
        this.infoAtencionCliente = value;
    }

}
