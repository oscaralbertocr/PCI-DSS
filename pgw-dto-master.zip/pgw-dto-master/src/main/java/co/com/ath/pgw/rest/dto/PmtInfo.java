
package co.com.ath.pgw.rest.dto;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonProperty;

public class PmtInfo implements Serializable {

	@JsonProperty("PmtInfoId")
	private String pmtInfoId;
	@JsonProperty("PmtInfoType")
	private String pmtInfoType;
	@JsonProperty("PmtInfoDesc")
	private String pmtInfoDesc;
	private static final long serialVersionUID = -4165243196797606626L;

	public String getPmtInfoId() {
		return pmtInfoId;
	}

	public void setPmtInfoId(String pmtInfoId) {
		this.pmtInfoId = pmtInfoId;
	}

	public String getPmtInfoType() {
		return pmtInfoType;
	}

	public void setPmtInfoType(String pmtInfoType) {
		this.pmtInfoType = pmtInfoType;
	}

	public String getPmtInfoDesc() {
		return pmtInfoDesc;
	}

	public void setPmtInfoDesc(String pmtInfoDesc) {
		this.pmtInfoDesc = pmtInfoDesc;
	}

}
