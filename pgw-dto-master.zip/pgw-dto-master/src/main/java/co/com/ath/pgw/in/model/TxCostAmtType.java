package co.com.ath.pgw.in.model;

import javax.xml.bind.annotation.XmlElement;

import co.com.ath.pgw.client.bank.info.CurrencyAmountType;

public class TxCostAmtType {

	@XmlElement(name = "CurAmt", required = true)
	protected CurrencyAmountType curAmt = new CurrencyAmountType();

	/**
	 * Obtiene el valor de la propiedad curAmt.
	 * 
	 * @return possible object is {@link CurrencyAmountType }
	 * 
	 */
	public CurrencyAmountType getCurAmt() {
		return curAmt;
	}

	/**
	 * Define el valor de la propiedad curAmt.
	 * 
	 * @param value allowed object is {@link CurrencyAmountType }
	 * 
	 */
	public void setCurAmt(CurrencyAmountType value) {
		this.curAmt = value;
	}

}
