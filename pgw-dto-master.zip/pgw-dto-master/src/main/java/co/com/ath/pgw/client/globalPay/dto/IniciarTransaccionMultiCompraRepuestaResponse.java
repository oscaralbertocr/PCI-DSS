
package co.com.ath.pgw.client.globalPay.dto;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;

import co.com.ath.pgw.client.globalPay.model.TipoCabeceraSolicitud;
import co.com.ath.pgw.client.globalPay.model.TipoInfoRespuesta;
import co.com.ath.pgw.client.globalPay.model.TipoInfoTransaccionResp;
import co.com.ath.pgw.core.logging.util.XMLUtil;


/**
 * <p>Clase Java para anonymous complex type.
 * 
 * <p>El siguiente fragmento de esquema especifica el contenido que se espera que haya en esta clase.
 * 
 * <pre>
 * &lt;complexType&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="cabeceraRespuesta" type="{http://www.rbm.com.co/esb/globalpay/}TipoCabeceraSolicitud"/&gt;
 *         &lt;element name="infoRespuesta" type="{http://www.rbm.com.co/esb/}TipoInfoRespuesta"/&gt;
 *         &lt;element name="infoTransaccionResp" type="{http://www.rbm.com.co/esb/globalpay/}TipoInfoTransaccionResp" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "", propOrder = {
    "cabeceraRespuesta",
    "infoRespuesta",
    "infoTransaccionResp"
})
@XmlRootElement(name = "IniciarTransaccionMultiCompraRepuesta")
public class IniciarTransaccionMultiCompraRepuestaResponse {

    @XmlElement(required = true)
    protected TipoCabeceraSolicitud cabeceraRespuesta;
    @XmlElement(required = true)
    protected TipoInfoRespuesta infoRespuesta;
    protected TipoInfoTransaccionResp infoTransaccionResp;

    /**
     * Obtiene el valor de la propiedad cabeceraRespuesta.
     * 
     * @return
     *     possible object is
     *     {@link TipoCabeceraSolicitud }
     *     
     */
    public TipoCabeceraSolicitud getCabeceraRespuesta() {
        return cabeceraRespuesta;
    }

    /**
     * Define el valor de la propiedad cabeceraRespuesta.
     * 
     * @param value
     *     allowed object is
     *     {@link TipoCabeceraSolicitud }
     *     
     */
    public void setCabeceraRespuesta(TipoCabeceraSolicitud value) {
        this.cabeceraRespuesta = value;
    }

    /**
     * Obtiene el valor de la propiedad infoRespuesta.
     * 
     * @return
     *     possible object is
     *     {@link TipoInfoRespuesta }
     *     
     */
    public TipoInfoRespuesta getInfoRespuesta() {
        return infoRespuesta;
    }

    /**
     * Define el valor de la propiedad infoRespuesta.
     * 
     * @param value
     *     allowed object is
     *     {@link TipoInfoRespuesta }
     *     
     */
    public void setInfoRespuesta(TipoInfoRespuesta value) {
        this.infoRespuesta = value;
    }

    /**
     * Obtiene el valor de la propiedad infoTransaccionResp.
     * 
     * @return
     *     possible object is
     *     {@link TipoInfoTransaccionResp }
     *     
     */
    public TipoInfoTransaccionResp getInfoTransaccionResp() {
        return infoTransaccionResp;
    }

    /**
     * Define el valor de la propiedad infoTransaccionResp.
     * 
     * @param value
     *     allowed object is
     *     {@link TipoInfoTransaccionResp }
     *     
     */
    public void setInfoTransaccionResp(TipoInfoTransaccionResp value) {
        this.infoTransaccionResp = value;
    }
    
    @Override
	public String toString() {
		XMLUtil<IniciarTransaccionMultiCompraRepuestaResponse> requestParser = new XMLUtil<IniciarTransaccionMultiCompraRepuestaResponse>();
		return requestParser.convertObjectToXml(this);
	}

}
