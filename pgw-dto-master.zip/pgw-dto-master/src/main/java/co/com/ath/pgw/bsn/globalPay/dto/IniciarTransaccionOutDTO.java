/*
 * AddTransactionOutDTO
 *  
 * GSI - Integración
 * Creado el: 20/09/2014
 *
 * Copyright (c) A Toda Hora S.A. Todos los derechos reservados
 * 
 * Este software es confidencial y es propietario de ATH, queda prohibido
 * su uso, reproducción y copia de manera parcial o permanente salvo autorización
 * expresa de A Toda Hora S.A o de quién represente sus derechos.
 */
package co.com.ath.pgw.bsn.globalPay.dto;

import java.util.Date;

import co.com.ath.pgw.bsn.dto.out.CommonObjectOutDTO;

/**
 * DTO con la información de respuesta de la operación ConsultarEstadoDePago
 * 
 * @author camilo.bustamante@sophossolutions.com
 * @version 1.0 03 Enero 2019
 * @RQ31686 RBM_Integracion_Boton_TC_GlobalPay
 * 
 */
public class IniciarTransaccionOutDTO extends CommonObjectOutDTO {

	private String pmtId;
	private Long trnStatusCode;
	private String trnStatusDesc;
	private String trnServerStatusCode;
	private String trnServerStatusDesc;
	private Date effDt;
	private Date compensationDate;
	private String approvalId;
	private String token;
	private String urlRBM;

	
	public String getPmtId() {
		return pmtId;
	}

	public void setPmtId(String pmtId) {
		this.pmtId = pmtId;
	}

	public Long getTrnStatusCode() {
		return trnStatusCode;
	}

	public void setTrnStatusCode(Long trnStatusCode) {
		this.trnStatusCode = trnStatusCode;
	}

	public String getTrnStatusDesc() {
		return trnStatusDesc;
	}

	public void setTrnStatusDesc(String trnStatusDesc) {
		this.trnStatusDesc = trnStatusDesc;
	}

	public String getTrnServerStatusCode() {
		return trnServerStatusCode;
	}

	public void setTrnServerStatusCode(String trnServerStatusCode) {
		this.trnServerStatusCode = trnServerStatusCode;
	}

	public String getTrnServerStatusDesc() {
		return trnServerStatusDesc;
	}

	public void setTrnServerStatusDesc(String trnServerStatusDesc) {
		this.trnServerStatusDesc = trnServerStatusDesc;
	}

	public Date getEffDt() {
		return effDt;
	}

	public void setEffDt(Date effDt) {
		this.effDt = effDt;
	}

	public Date getCompensationDate() {
		return compensationDate;
	}

	public void setCompensationDate(Date compensationDate) {
		this.compensationDate = compensationDate;
	}

	public String getApprovalId() {
		return approvalId;
	}

	public void setApprovalId(String approvalId) {
		this.approvalId = approvalId;
	}

	public String getToken() {
		return token;
	}

	public void setToken(String token) {
		this.token = token;
	}

	public String getUrlRBM() {
		return urlRBM;
	}

	public void setUrlRBM(String urlRBM) {
		this.urlRBM = urlRBM;
	}
	
	

}