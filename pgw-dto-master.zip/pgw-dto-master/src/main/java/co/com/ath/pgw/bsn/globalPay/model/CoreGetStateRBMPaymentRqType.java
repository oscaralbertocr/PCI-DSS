
package co.com.ath.pgw.bsn.globalPay.model;

import java.util.ArrayList;
import java.util.List;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;

import co.com.ath.pgw.core.logging.util.XMLUtil;


/**
 * <p>Clase Java para CoreGetStateRBMPaymentRq_Type complex type.
 * 
 * <p>El siguiente fragmento de esquema especifica el contenido que se espera que haya en esta clase.
 * 
 * <pre>
 * &lt;complexType name="CoreGetStateRBMPaymentRq_Type">
 *   &lt;complexContent>
 *     &lt;extension base="{urn://ath.com.co/xsd/common/}SvcRq_Type">
 *       &lt;sequence>
 *         &lt;element ref="{urn://ath.com.co/xsd/common/}PmtId"/>
 *         &lt;element ref="{urn://ath.com.co/xsd/common/}Reference" maxOccurs="unbounded" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/extension>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "CoreGetStateRBMPaymentRq_Type", namespace = "urn://ath.com.co/payments/v1/", propOrder = {
    "pmtId",
    "reference"
})
@XmlRootElement
public class CoreGetStateRBMPaymentRqType
    extends SvcRqType implements Cloneable
{

    @XmlElement(name = "PmtId", namespace = "urn://ath.com.co/xsd/common/", required = true)
    protected String pmtId;
    @XmlElement(name = "Reference", namespace = "urn://ath.com.co/xsd/common/")
    protected List<ReferenceType> reference;

    /**
     * Obtiene el valor de la propiedad pmtId.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPmtId() {
        return pmtId;
    }

    /**
     * Define el valor de la propiedad pmtId.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPmtId(String value) {
        this.pmtId = value;
    }

    /**
     * Gets the value of the reference property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the reference property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getReference().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link ReferenceType }
     * 
     * 
     */
    public List<ReferenceType> getReference() {
        if (reference == null) {
            reference = new ArrayList<ReferenceType>();
        }
        return this.reference;
    }

	public void setReference(List<ReferenceType> reference) {
		this.reference = reference;
	}
    
	
	@Override
	public String toString() {
		XMLUtil<CoreGetStateRBMPaymentRqType> requestParser = new XMLUtil<CoreGetStateRBMPaymentRqType>();
		return requestParser.convertObjectToXml(this);
	}

}
