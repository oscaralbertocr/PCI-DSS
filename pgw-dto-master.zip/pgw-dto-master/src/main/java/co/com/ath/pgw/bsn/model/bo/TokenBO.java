/*
 * TokenVO
 *  
 * GSI - Integración
 * Creado el: 29/08/2014
 *
 * Copyright (c) A Toda Hora S.A. Todos los derechos reservados
 * 
 * Este software es confidencial y es propietario de ATH, queda prohibido
 * su uso, reproducción y copia de manera parcial o permanente salvo autorización
 * expresa de A Toda Hora S.A o de quién represente sus derechos.
 */
package co.com.ath.pgw.bsn.model.bo;

import java.util.Date;

/**
 * Representa el token generado para una transacción. Esta entidad pertenece
 * al modelo de negocio.
 * 
 * @author proveedor_japiza
 * @version 1.0 29 Ago 2014
 * @since 1.0
 */
public class TokenBO {

	/**
	 * Identificador único del Token.
	 */
	private String id;
	
	/**
	 * PmtId de la transacción.
	 */
	private String pmtId;
	
	/**
	 * Transacción asociada con el Token.
	 */
	private TransactionBO transaction;
	
	/**
	 * Fecha de creación del Token.
	 */
	private Date creationDate;

	/**
	 * Fecha de expiración del Token.
	 */
	private Date expirationDate;
	
	/**
	 * Estado del Token
	 */
	private String status;	

	/**
	 * Número de intentos de consulta del token.
	 */
	private Integer retryCount;

	/**
	 * Construye el Token de una transacción.
	 */
	public TokenBO(){
		super();
	}

	/**
	 * Retorna el identificador único del Token.
	 * 
	 * @return Identificador del Token.
	 */
	public String getId() {
		return id;
	}

	/**
	 * Establece el identificador único del Token.
	 * 
	 * @param id Identificador del Token.
	 */
	public void setId(String id) {
		this.id = id;
	}
	
	/**
	 * Retorna el pmtId de la Transacción.
	 * 
	 * @return PmtId de la Transacción.
	 */
	public String getPmtId() {
		return pmtId;
	}

	/**
	 * Establece el PmtId de la Transacción.
	 * 
	 * @param pmtId de la Transacción.
	 */
	public void setPmtId(String pmtId) {
		this.pmtId = pmtId;
	}

	/**
	 * Retorna la transacción asociada al Token.
	 * 
	 * @return Transacción asociada al Token.
	 */
	public TransactionBO getTransaction() {
		return transaction;
	}

	/**
	 * Establece la transacción asociada al Token.
	 * 
	 * @param transaction Transacción asociada al Token.
	 */
	public void setTransaction(TransactionBO transaction) {
		this.transaction = transaction;
	}

	/**
	 * Retorna la fecha de creación del Token.
	 * 
	 * @return Fecha de creación del Token.
	 */
	public Date getCreationDate() {
		return creationDate;
	}

	/**
	 * Establece la fecha de creación del Token.
	 * 
	 * @param creationDate Fecha de creación del Token.
	 */
	public void setCreationDate(Date creationDate) {
		this.creationDate = creationDate;
	}

	/**
	 * Retorna la fecha de expiración del Token.
	 * 
	 * @return Fecha de expiración del Token.
	 */
	public Date getExpirationDate() {
		return expirationDate;
	}

	/**
	 * Establece la fecha de expiración del Token.
	 * 
	 * @param expirationDate Fecha de expiración del Token.
	 */
	public void setExpirationDate(Date expirationDate) {
		this.expirationDate = expirationDate;
	}

	/**
	 * Retorna el estado del Token.
	 * 
	 * @return Estado del Token.
	 */
	public String getStatus() {
		return status;
	}

	/**
	 * Establece el estado del Token.
	 * 
	 * @param status Estado del Token.
	 */
	public void setStatus(String status) {
		this.status = status;
	}

	/**
	 * Retorna el número de intentos de consulta del token.
	 * 
	 * @return Número de intentos de consulta del token.
	 */
	public Integer getRetryCount() {
		return retryCount;
	}

	/**
	 * Establece el número de intentos de consulta del token.
	 * 
	 * @param retryCount Número de intentos de consulta.
	 */
	public void setRetryCount(Integer retryCount) {
		this.retryCount = retryCount;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((id == null) ? 0 : id.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		TokenBO other = (TokenBO) obj;
		if (id == null) {
			if (other.id != null)
				return false;
		} else if (!id.equals(other.id))
			return false;
		return true;
	}

	@Override
	public String toString() {
		return "TokenVO [id=" + id + ", transaction=" + transaction
				+ ", status=" + status + ", retryCount=" + retryCount + "]";
	}

}