package co.com.ath.pgw.client.bank.info;

import java.math.BigDecimal;

public class CurrencyAmountType {

	protected BigDecimal amt;

	protected String curCode;

	protected BigDecimal curRate;

	protected String curConvertRule;

	/**
	 * Obtiene el valor de la propiedad amt.
	 * 
	 * @return possible object is {@link BigDecimal }
	 * 
	 */
	public BigDecimal getAmt() {
		return amt;
	}

	/**
	 * Define el valor de la propiedad amt.
	 * 
	 * @param value allowed object is {@link BigDecimal }
	 * 
	 */
	public void setAmt(BigDecimal value) {
		this.amt = value;
	}

	/**
	 * Obtiene el valor de la propiedad curCode.
	 * 
	 * @return possible object is {@link String }
	 * 
	 */
	public String getCurCode() {
		return curCode;
	}

	/**
	 * Define el valor de la propiedad curCode.
	 * 
	 * @param value allowed object is {@link String }
	 * 
	 */
	public void setCurCode(String value) {
		this.curCode = value;
	}

	/**
	 * Obtiene el valor de la propiedad curRate.
	 * 
	 * @return possible object is {@link BigDecimal }
	 * 
	 */
	public BigDecimal getCurRate() {
		return curRate;
	}

	/**
	 * Define el valor de la propiedad curRate.
	 * 
	 * @param value allowed object is {@link BigDecimal }
	 * 
	 */
	public void setCurRate(BigDecimal value) {
		this.curRate = value;
	}

	/**
	 * Obtiene el valor de la propiedad curConvertRule.
	 * 
	 * @return possible object is {@link String }
	 * 
	 */
	public String getCurConvertRule() {
		return curConvertRule;
	}

	/**
	 * Define el valor de la propiedad curConvertRule.
	 * 
	 * @param value allowed object is {@link String }
	 * 
	 */
	public void setCurConvertRule(String value) {
		this.curConvertRule = value;
	}

}
