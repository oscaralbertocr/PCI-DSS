package co.com.ath.pgw.in.model;


public class SecretListType {

	/** Constante para identificar el usuario */
	public static final String USER_KEY = "user";
	/** Constante para identificar la contraseña */
	public static final String WORD_KEY = "password"; // Correccion de hallazgo Fortify
	
   
    protected String secretId;
   
    protected String cryptType;
   
    protected Long binLength;
    
    protected String secret;

    /**
     * Obtiene el valor de la propiedad secretId.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSecretId() {
        return secretId;
    }

    /**
     * Define el valor de la propiedad secretId.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSecretId(String value) {
        this.secretId = value;
    }

    /**
     * Obtiene el valor de la propiedad cryptType.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCryptType() {
        return cryptType;
    }

    /**
     * Define el valor de la propiedad cryptType.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCryptType(String value) {
        this.cryptType = value;
    }

    /**
     * Obtiene el valor de la propiedad binLength.
     * 
     * @return
     *     possible object is
     *     {@link Long }
     *     
     */
    public Long getBinLength() {
        return binLength;
    }

    /**
     * Define el valor de la propiedad binLength.
     * 
     * @param value
     *     allowed object is
     *     {@link Long }
     *     
     */
    public void setBinLength(Long value) {
        this.binLength = value;
    }

    /**
     * Obtiene el valor de la propiedad secret.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSecret() {
        return secret;
    }

    /**
     * Define el valor de la propiedad secret.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSecret(String value) {
        this.secret = value;
    }

}
