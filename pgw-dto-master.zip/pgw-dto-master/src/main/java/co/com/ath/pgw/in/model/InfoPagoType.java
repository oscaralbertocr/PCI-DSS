
package co.com.ath.pgw.in.model;

import java.math.BigDecimal;
import java.math.BigInteger;

import javax.xml.datatype.XMLGregorianCalendar;

/**
*
* @author camilo.bustamante@sophossolutions.com
* @version 1.0 03 Enero 2019
* @RQ31686 RBM_Integracion_Boton_TC_GlobalPay
* 
*/

/**
 * <p>Clase Java para InfoPago_Type complex type.
 * 
 * <p>El siguiente fragmento de esquema especifica el contenido que se espera que haya en esta clase.
 * 
 * <pre>
 * &lt;complexType name="InfoPago_Type">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element ref="{urn://ath.com.co/xsd/common/}Franquicia" minOccurs="0"/>
 *         &lt;element ref="{urn://ath.com.co/xsd/common/}TipoMedioDePago" minOccurs="0"/>
 *         &lt;element ref="{urn://ath.com.co/xsd/common/}TipoCuenta" minOccurs="0"/>
 *         &lt;element ref="{urn://ath.com.co/xsd/common/}FechaTransaccion" minOccurs="0"/>
 *         &lt;element ref="{urn://ath.com.co/xsd/common/}NumeroAprobacion" minOccurs="0"/>
 *         &lt;element ref="{urn://ath.com.co/xsd/common/}MontoTotal" minOccurs="0"/>
 *         &lt;element ref="{urn://ath.com.co/xsd/common/}CostoTransaccion" minOccurs="0"/>
 *         &lt;element ref="{urn://ath.com.co/xsd/common/}IdTransaccionAutorizador" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
public class InfoPagoType {

   
    protected String franquicia;
    
   
    protected String tipoMedioDePago;

   
    protected String tipoCuenta;

    
    protected XMLGregorianCalendar fechaTransaccion;
        
    
    protected String numeroAprobacion;
    
   
    protected BigDecimal montoTotal;
    
    
    protected BigDecimal costoTransaccion;
    
    
    protected BigInteger idTransaccionAutorizador;

    
	public String getFranquicia() {
		return franquicia;
	}

	public void setFranquicia(String franquicia) {
		this.franquicia = franquicia;
	}

	public String getTipoMedioDePago() {
		return tipoMedioDePago;
	}

	public void setTipoMedioDePago(String tipoMedioDePago) {
		this.tipoMedioDePago = tipoMedioDePago;
	}

	public String getTipoCuenta() {
		return tipoCuenta;
	}

	public void setTipoCuenta(String tipoCuenta) {
		this.tipoCuenta = tipoCuenta;
	}

	public XMLGregorianCalendar getFechaTransaccion() {
		return fechaTransaccion;
	}

	public void setFechaTransaccion(XMLGregorianCalendar fechaTransaccion) {
		this.fechaTransaccion = fechaTransaccion;
	}

	public String getNumeroAprobacion() {
		return numeroAprobacion;
	}

	public void setNumeroAprobacion(String numeroAprobacion) {
		this.numeroAprobacion = numeroAprobacion;
	}

	public BigDecimal getMontoTotal() {
		return montoTotal;
	}

	public void setMontoTotal(BigDecimal montoTotal) {
		this.montoTotal = montoTotal;
	}

	public BigDecimal getCostoTransaccion() {
		return costoTransaccion;
	}

	public void setCostoTransaccion(BigDecimal costoTransaccion) {
		this.costoTransaccion = costoTransaccion;
	}

	public BigInteger getIdTransaccionAutorizador() {
		return idTransaccionAutorizador;
	}

	public void setIdTransaccionAutorizador(BigInteger idTransaccionAutorizador) {
		this.idTransaccionAutorizador = idTransaccionAutorizador;
	}

}
