
package co.com.ath.pgw.rest.response.dto;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonProperty;

import co.com.ath.pgw.core.logging.util.XMLUtil;
import co.com.ath.pgw.rest.dto.InvoicePmtInfo;

public class HistoricTransactionResponse implements Serializable {

	@JsonProperty("InvoicePmtInfo")
	private List<InvoicePmtInfo> invoicePmtInfo;
	private static final long serialVersionUID = 2626059669762512373L;

	public List<InvoicePmtInfo> getInvoicePmtInfo() {
		if(invoicePmtInfo == null) {
			invoicePmtInfo = new ArrayList<InvoicePmtInfo>();
		}
		return invoicePmtInfo;
	}

	public void setInvoicePmtInfo(List<InvoicePmtInfo> invoicePmtInfo) {
		this.invoicePmtInfo = invoicePmtInfo;
	}

	@Override
	public String toString() {
		XMLUtil<HistoricTransactionResponse> util = new XMLUtil<HistoricTransactionResponse>();
		return util.convertObjectToJson(this);
	}

}
