/*
 * ThemeVO
 *  
 * GSI - Integración
 * Creado el: 28/08/2014
 *
 * Copyright (c) A Toda Hora S.A. Todos los derechos reservados
 * 
 * Este software es confidencial y es propietario de ATH, queda prohibido
 * su uso, reproducción y copia de manera parcial o permanente salvo autorización
 * expresa de A Toda Hora S.A o de quién represente sus derechos.
 */
package co.com.ath.pgw.bsn.model.bo;




/**
 * Representa un tema para el esquema gráfico de un comercio. Esta es una 
 * entidad del modelo de negocio.
 * 
 * @author proveedor_japiza
 * @version 1.0 29 Ago 2012
 * @since 1.0
 *
 */
public class ThemeBO {
	
	/**
	 * Identificador único del tema
	 */
	private Long id;

	/**
	 * Nombre del tema.
	 */
	private String name;

	/**
	 * Construye un tema sin especificar sus parámetros.
	 */
	public ThemeBO(){
		super();
	}
	
	/**
	 * Retorna el identificador único del tema.
	 * 
	 * @return Identificador del tema.
	 */
	public Long getId() {
		return id;
	}

	/**
	 * Establece el identificador único del tema.
	 * 
	 * @param id Identificador del tema.
	 */
	public void setId(Long id) {
		this.id = id;
	}

	/**
	 * Retorna el nombre del tema.
	 * 
	 * @return Nombre del tema.
	 */
	public String getName() {
		return name;
	}

	/**
	 * Establece el nombre del tema.
	 * 
	 * @param name Nombre del tema.
	 */
	public void setName(String name) {
		this.name = name;
	}
	
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + (int) (id ^ (id >>> 32));
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		ThemeBO other = (ThemeBO) obj;
		if (id != other.id)
			return false;
		return true;
	}

	@Override
	public String toString() {
		return "ThemeVO [id=" + id + ", name=" + name + "]";
	}
	
}