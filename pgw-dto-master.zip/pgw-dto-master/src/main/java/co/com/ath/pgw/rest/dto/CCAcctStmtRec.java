package co.com.ath.pgw.rest.dto;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonProperty;

public class CCAcctStmtRec implements Serializable {

	@JsonProperty("NumberOfInstalments")
	private String numberOfInstalments;
	private static final long serialVersionUID = 4113017292270523846L;

	public String getNumberOfInstalments() {
		return numberOfInstalments;
	}

	public void setNumberOfInstalments(String numberOfInstalments) {
		this.numberOfInstalments = numberOfInstalments;
	}

}