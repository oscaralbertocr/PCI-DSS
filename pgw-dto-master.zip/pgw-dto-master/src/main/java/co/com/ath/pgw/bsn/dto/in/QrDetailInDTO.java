package co.com.ath.pgw.bsn.dto.in;

public class QrDetailInDTO {

	private Long pmtid;

	public Long getPmtid() {
		return pmtid;
	}

	public void setPmtid(Long pmtid) {
		this.pmtid = pmtid;
	}
	
	
}
