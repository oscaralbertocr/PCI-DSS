
package co.com.ath.pgw.rest.dto;

import java.io.Serializable;

import javax.validation.constraints.Pattern;

import com.fasterxml.jackson.annotation.JsonProperty;

import co.com.ath.pgw.rest.util.ConstantFormat;

public class PersonNameAddTx implements Serializable
{
	@JsonProperty("LastName")
	@Pattern( regexp = ConstantFormat.FORMAT_NOMBRE_FRONT, message = ConstantFormat.MESSAGE_CARACTER_NO_VALIDOS)
    private String lastName;
	
	@JsonProperty("FirstName")
	@Pattern( regexp = ConstantFormat.FORMAT_NOMBRE_FRONT, message = ConstantFormat.MESSAGE_CARACTER_NO_VALIDOS)
    private String firstName;
	
	@JsonProperty("MiddleName")
	@Pattern( regexp = ConstantFormat.FORMAT_NOMBRE_FRONT, message = ConstantFormat.MESSAGE_CARACTER_NO_VALIDOS)
    private String middleName;
	
	@JsonProperty("SecondLastName")
	@Pattern( regexp = ConstantFormat.FORMAT_NOMBRE_FRONT, message = ConstantFormat.MESSAGE_CARACTER_NO_VALIDOS)
    private String secondLastName;
	
	@JsonProperty("LegalName")
	@Pattern( regexp = ConstantFormat.FORMAT_NOMBRE_FRONT, message = ConstantFormat.MESSAGE_CARACTER_NO_VALIDOS)
    private String legalName;
	
	@JsonProperty("Nickname")
	@Pattern( regexp = ConstantFormat.FORMAT_NO_CARACTERES_O_ESPACIO, message = ConstantFormat.MESSAGE_CARACTER_NO_VALIDOS)
    private String nickname;
	
	@JsonProperty("FullName")
	@Pattern( regexp = ConstantFormat.FORMAT_NOMBRE_FRONT, message = ConstantFormat.MESSAGE_CARACTER_NO_VALIDOS)
    private String fullName;
	
    private final static long serialVersionUID = 1418169688037523149L;

    public String getLastName() {
        return lastName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    public String getFirstName() {
        return firstName;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public String getMiddleName() {
        return middleName;
    }

    public void setMiddleName(String middleName) {
        this.middleName = middleName;
    }

    public String getSecondLastName() {
        return secondLastName;
    }

    public void setSecondLastName(String secondLastName) {
        this.secondLastName = secondLastName;
    }

    public String getLegalName() {
        return legalName;
    }

    public void setLegalName(String legalName) {
        this.legalName = legalName;
    }
    
    public String getNickname() {
        return nickname;
    }
    
    public void setNickname(String nickname) {
        this.nickname = nickname;
    }

	public String getFullName() {
		return fullName;
	}

	public void setFullName(String fullName) {
		this.fullName = fullName;
	}
    
}
