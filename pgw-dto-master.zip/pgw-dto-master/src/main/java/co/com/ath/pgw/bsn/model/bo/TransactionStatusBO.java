/*
 * TransactionStatusVO
 *  
 * GSI - Integración
 * Creado el: 29/08/2014
 *
 * Copyright (c) A Toda Hora S.A. Todos los derechos reservados
 * 
 * Este software es confidencial y es propietario de ATH, queda prohibido
 * su uso, reproducción y copia de manera parcial o permanente salvo autorización
 * expresa de A Toda Hora S.A o de quién represente sus derechos.
 */
package co.com.ath.pgw.bsn.model.bo;


/**
 * Estado de una transacción.
 * 
 * @author proveedor_japiza
 * @version 1.0 29 Ago 2014
 * @since 1.0
 */
public class TransactionStatusBO {
	
	/**
	 * Código de estado.
	 */
	private Long code;

	/**
	 * Descripcón del estado.
	 */
	private String description;
	
	/**
	 * Construye el estado de una transacción.
	 */
	public TransactionStatusBO(){
		super();
	}
	
	/**
	 * Retorna el código del estado.
	 * 
	 * @return Código del estado.
	 */
	public Long getCode(){
		return code;
	}

	/**
	 * Establece el código del estado.
	 * 
	 * @param code Código del estado.
	 */
	public void setCode(Long code){
		this.code = code;
	}

	/**
	 * Retorna la descripción del estado.
	 * 
	 * @return Descripción del estado.
	 */
	public String getDescription(){
		return description;
	}

	/**
	 * Establece la descripción del estado.
	 * @param description Descripción del estado.
	 */
	public void setDescription(String description){
		this.description = description;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((code == null) ? 0 : code.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		TransactionStatusBO other = (TransactionStatusBO) obj;
		if (code == null) {
			if (other.code != null)
				return false;
		} else if (!code.equals(other.code))
			return false;
		return true;
	}

	@Override
	public String toString() {
		return "TransactionStatusVO [code=" + code + ", description="
				+ description + "]";
	}
	
}