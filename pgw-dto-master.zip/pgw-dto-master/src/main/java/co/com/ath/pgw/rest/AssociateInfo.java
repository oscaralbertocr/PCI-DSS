package co.com.ath.pgw.rest;

import java.io.Serializable;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

import co.com.ath.pgw.rest.dto.ContactInfo;
import co.com.ath.pgw.rest.dto.PersonInfo;

import org.apache.commons.lang.builder.ToStringBuilder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "AstName",
    "ContactInfo",
    "AstType",
    "PersonInfo"
})
public class AssociateInfo implements Serializable
{

    @JsonProperty("AstName")
    private String astName;
    @JsonProperty("ContactInfo")
    private ContactInfo contactInfo;
    @JsonProperty("AstType")
    private String astType;
    @JsonProperty("PersonInfo")
    private PersonInfo personInfo;
    private final static long serialVersionUID = -8794208138220366071L;

    @JsonProperty("AstName")
    public String getAstName() {
        return astName;
    }

    @JsonProperty("AstName")
    public void setAstName(String astName) {
        this.astName = astName;
    }

    @JsonProperty("ContactInfo")
    public ContactInfo getContactInfo() {
        return contactInfo;
    }

    @JsonProperty("ContactInfo")
    public void setContactInfo(ContactInfo contactInfo) {
        this.contactInfo = contactInfo;
    }

    @JsonProperty("AstType")
    public String getAstType() {
        return astType;
    }

    @JsonProperty("AstType")
    public void setAstType(String astType) {
        this.astType = astType;
    }

    @JsonProperty("PersonInfo")
    public PersonInfo getPersonInfo() {
        return personInfo;
    }

    @JsonProperty("PersonInfo")
    public void setPersonInfo(PersonInfo personInfo) {
        this.personInfo = personInfo;
    }

    @Override
    public String toString() {
        return new ToStringBuilder(this).append("astName", astName).append("contactInfo", contactInfo).append("astType", astType).append("personInfo", personInfo).toString();
    }

}
