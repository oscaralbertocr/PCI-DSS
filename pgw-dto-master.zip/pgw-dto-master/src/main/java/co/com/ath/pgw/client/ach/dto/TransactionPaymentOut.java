package co.com.ath.pgw.client.ach.dto;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlSchemaType;
import javax.xml.bind.annotation.XmlType;
import javax.xml.datatype.XMLGregorianCalendar;

import co.com.ath.pgw.core.logging.util.XMLUtil;


/**
 * <p>Clase Java para TransactionPaymentOut complex type.
 * 
 * <p>El siguiente fragmento de esquema especifica el contenido que se espera que haya en esta clase.
 * 
 * <pre>
 * &lt;complexType name="TransactionPaymentOut">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="trazabilityCode" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="returnCode" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="bankUrl" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="soliciteDate" type="{http://www.w3.org/2001/XMLSchema}dateTime" minOccurs="0"/>
 *         &lt;element name="transactionCycle" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "TransactionPaymentOut", propOrder = {
    "trazabilityCode",
    "returnCode",
    "bankUrl",
    "soliciteDate",
    "transactionCycle"
})
@XmlRootElement
public class TransactionPaymentOut {

    protected String trazabilityCode;
    protected String returnCode;
    protected String bankUrl;
    @XmlSchemaType(name = "dateTime")
    protected XMLGregorianCalendar soliciteDate;
    protected String transactionCycle;

    /**
     * Obtiene el valor de la propiedad trazabilityCode.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getTrazabilityCode() {
        return trazabilityCode;
    }

    /**
     * Define el valor de la propiedad trazabilityCode.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setTrazabilityCode(String value) {
        this.trazabilityCode = value;
    }

    /**
     * Obtiene el valor de la propiedad returnCode.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getReturnCode() {
        return returnCode;
    }

    /**
     * Define el valor de la propiedad returnCode.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setReturnCode(String value) {
        this.returnCode = value;
    }

    /**
     * Obtiene el valor de la propiedad bankUrl.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getBankUrl() {
        return bankUrl;
    }

    /**
     * Define el valor de la propiedad bankUrl.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setBankUrl(String value) {
        this.bankUrl = value;
    }

    /**
     * Obtiene el valor de la propiedad soliciteDate.
     * 
     * @return
     *     possible object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public XMLGregorianCalendar getSoliciteDate() {
        return soliciteDate;
    }

    /**
     * Define el valor de la propiedad soliciteDate.
     * 
     * @param value
     *     allowed object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public void setSoliciteDate(XMLGregorianCalendar value) {
        this.soliciteDate = value;
    }

    /**
     * Obtiene el valor de la propiedad transactionCycle.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getTransactionCycle() {
        return transactionCycle;
    }

    /**
     * Define el valor de la propiedad transactionCycle.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setTransactionCycle(String value) {
        this.transactionCycle = value;
    }

	@Override
	public String toString() {
		XMLUtil<TransactionPaymentOut> requestParser = new XMLUtil<TransactionPaymentOut>();
		return requestParser.convertObjectToXml(this);
	}

}
