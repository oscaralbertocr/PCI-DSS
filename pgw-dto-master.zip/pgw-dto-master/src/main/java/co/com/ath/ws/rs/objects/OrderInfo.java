package co.com.ath.ws.rs.objects;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonProperty;

public class OrderInfo implements Serializable {

	private static final long serialVersionUID = 1L;
	
	@JsonProperty("orderId")
    private String orderId;
    
	@JsonProperty("desc")
    private String desc;

	public String getOrderId() {
		return orderId;
	}

	public void setOrderId(String orderId) {
		this.orderId = orderId;
	}

	public String getDesc() {
		return desc;
	}

	public void setDesc(String desc) {
		this.desc = desc;
	}
	
	

}
