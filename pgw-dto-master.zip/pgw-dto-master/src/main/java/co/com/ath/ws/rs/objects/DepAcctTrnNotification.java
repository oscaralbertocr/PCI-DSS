package co.com.ath.ws.rs.objects;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonProperty;

public class DepAcctTrnNotification implements Serializable {

	private static final long serialVersionUID = 1L;
	
	@JsonProperty("pmtId")
	private Long pmtId;

	public Long getPmtId() {
		return pmtId;
	}

	public void setPmtId(Long pmtId) {
		this.pmtId = pmtId;
	}

}
