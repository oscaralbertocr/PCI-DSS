package co.com.ath.pgw.rest.globalPay.qr;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.fasterxml.jackson.annotation.JsonProperty;

import co.com.ath.pgw.core.logging.util.XMLUtil;

@JsonInclude(Include.NON_NULL)
public class CoreUpdateQrRBMRs implements Serializable{

	private static final long serialVersionUID = 3405963752165351205L;

	@JsonProperty("codigoRespuesta")
	private String codigoRespuesta;
	
	@JsonProperty("descripcionRespuesta")
	private String descripcionRespuesta;

	public String getCodigoRespuesta() {
		return codigoRespuesta;
	}

	public void setCodigoRespuesta(String codigoRespuesta) {
		this.codigoRespuesta = codigoRespuesta;
	}

	public String getDescripcionRespuesta() {
		return descripcionRespuesta;
	}

	public void setDescripcionRespuesta(String descripcionRespuesta) {
		this.descripcionRespuesta = descripcionRespuesta;
	}
	
	@Override
	public String toString() {
		XMLUtil<CoreUpdateQrRBMRs> util = new XMLUtil<CoreUpdateQrRBMRs>();
		return util.convertObjectToJson(this);
	}	
	
}
