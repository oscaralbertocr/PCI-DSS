package co.com.ath.pgw.in.dto;

import co.com.ath.pgw.in.model.OrderInfoType;
import co.com.ath.pgw.in.model.SvcRsType;
import co.com.ath.pgw.in.model.TransactionStatusType;

public class CreditCardPaymentAddRsType extends SvcRsType {

	protected String state;

	protected String pmtId;

	protected TransactionStatusType transactionStatus;

	protected String trazabilityCode;

	protected String portalURL;

	protected String token;

	protected OrderInfoType orderInfo = new OrderInfoType();

	/**
	 * Obtiene el valor de la propiedad state.
	 * 
	 * @return possible object is {@link String }
	 * 
	 */
	public String getState() {
		return state;
	}

	/**
	 * Define el valor de la propiedad state.
	 * 
	 * @param value allowed object is {@link String }
	 * 
	 */
	public void setState(String value) {
		this.state = value;
	}

	/**
	 * Obtiene el valor de la propiedad pmtId.
	 * 
	 * @return possible object is {@link String }
	 * 
	 */
	public String getPmtId() {
		return pmtId;
	}

	/**
	 * Define el valor de la propiedad pmtId.
	 * 
	 * @param value allowed object is {@link String }
	 * 
	 */
	public void setPmtId(String value) {
		this.pmtId = value;
	}

	/**
	 * Obtiene el valor de la propiedad transactionStatus.
	 * 
	 * @return possible object is {@link TransactionStatusType }
	 * 
	 */
	public TransactionStatusType getTransactionStatus() {
		return transactionStatus;
	}

	/**
	 * Define el valor de la propiedad transactionStatus.
	 * 
	 * @param value allowed object is {@link TransactionStatusType }
	 * 
	 */
	public void setTransactionStatus(TransactionStatusType value) {
		this.transactionStatus = value;
	}

	/**
	 * Obtiene el valor de la propiedad trazabilityCode.
	 * 
	 * @return possible object is {@link String }
	 * 
	 */
	public String getTrazabilityCode() {
		return trazabilityCode;
	}

	/**
	 * Define el valor de la propiedad trazabilityCode.
	 * 
	 * @param value allowed object is {@link String }
	 * 
	 */
	public void setTrazabilityCode(String value) {
		this.trazabilityCode = value;
	}

	/**
	 * Obtiene el valor de la propiedad portalURL.
	 * 
	 * @return possible object is {@link String }
	 * 
	 */
	public String getPortalURL() {
		return portalURL;
	}

	/**
	 * Define el valor de la propiedad portalURL.
	 * 
	 * @param value allowed object is {@link String }
	 * 
	 */
	public void setPortalURL(String value) {
		this.portalURL = value;
	}

	/**
	 * Obtiene el valor de la propiedad token.
	 * 
	 * @return possible object is {@link String }
	 * 
	 */
	public String getToken() {
		return token;
	}

	/**
	 * Define el valor de la propiedad token.
	 * 
	 * @param value allowed object is {@link String }
	 * 
	 */
	public void setToken(String value) {
		this.token = value;
	}

	/**
	 * Obtiene el valor de la propiedad orderInfo.
	 * 
	 * @return possible object is {@link OrderInfoType }
	 * 
	 */
	public OrderInfoType getOrderInfo() {
		return orderInfo;
	}

	/**
	 * Define el valor de la propiedad orderInfo.
	 * 
	 * @param value allowed object is {@link OrderInfoType }
	 * 
	 */
	public void setOrderInfo(OrderInfoType value) {
		this.orderInfo = value;
	}

}