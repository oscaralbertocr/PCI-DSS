package co.com.ath.pgw.in.dto;


import co.com.ath.pgw.core.logging.util.XMLUtil;
import co.com.ath.pgw.in.model.OrderInfoType;
import co.com.ath.pgw.in.model.TransactionStatusType;

public class TransactionAddRsType {

	protected long statusCode;

	protected String statusDesc;

	protected long rqUID;

	protected TransactionStatusType transactionStatus;

	protected String pmtId;

	protected String portalURL;

	protected OrderInfoType orderInfo;

	/**
	 * Obtiene el valor de la propiedad statusCode.
	 * 
	 */
	public long getStatusCode() {
		return statusCode;
	}

	/**
	 * Define el valor de la propiedad statusCode.
	 * 
	 */
	public void setStatusCode(long value) {
		this.statusCode = value;
	}

	/**
	 * Obtiene el valor de la propiedad statusDesc.
	 * 
	 * @return
	 *     possible object is
	 *     {@link String }
	 *     
	 */
	public String getStatusDesc() {
		return statusDesc;
	}

	/**
	 * Define el valor de la propiedad statusDesc.
	 * 
	 * @param value
	 *     allowed object is
	 *     {@link String }
	 *     
	 */
	public void setStatusDesc(String value) {
		this.statusDesc = value;
	}

	/**
	 * Obtiene el valor de la propiedad rqUID.
	 * 
	 */
	public long getRqUID() {
		return rqUID;
	}

	/**
	 * Define el valor de la propiedad rqUID.
	 * 
	 */
	public void setRqUID(long value) {
		this.rqUID = value;
	}

	/**
	 * Obtiene el valor de la propiedad transactionStatus.
	 * 
	 * @return
	 *     possible object is
	 *     {@link TransactionStatusType }
	 *     
	 */
	public TransactionStatusType getTransactionStatus() {
		return transactionStatus;
	}

	/**
	 * Define el valor de la propiedad transactionStatus.
	 * 
	 * @param value
	 *     allowed object is
	 *     {@link TransactionStatusType }
	 *     
	 */
	public void setTransactionStatus(TransactionStatusType value) {
		this.transactionStatus = value;
	}

	/**
	 * Obtiene el valor de la propiedad pmtId.
	 * 
	 * @return
	 *     possible object is
	 *     {@link String }
	 *     
	 */
	public String getPmtId() {
		return pmtId;
	}

	/**
	 * Define el valor de la propiedad pmtId.
	 * 
	 * @param value
	 *     allowed object is
	 *     {@link String }
	 *     
	 */
	public void setPmtId(String value) {
		this.pmtId = value;
	}

	/**
	 * Obtiene el valor de la propiedad portalURL.
	 * 
	 * @return
	 *     possible object is
	 *     {@link String }
	 *     
	 */
	public String getPortalURL() {
		return portalURL;
	}

	/**
	 * Define el valor de la propiedad portalURL.
	 * 
	 * @param value
	 *     allowed object is
	 *     {@link String }
	 *     
	 */
	public void setPortalURL(String value) {
		this.portalURL = value;
	}

	/**
	 * Obtiene el valor de la propiedad orderInfo.
	 * 
	 * @return
	 *     possible object is
	 *     {@link OrderInfoType }
	 *     
	 */
	public OrderInfoType getOrderInfo() {
		return orderInfo;
	}

	/**
	 * Define el valor de la propiedad orderInfo.
	 * 
	 * @param value
	 *     allowed object is
	 *     {@link OrderInfoType }
	 *     
	 */
	public void setOrderInfo(OrderInfoType value) {
		this.orderInfo = value;
	}
	
	@Override
	public String toString() {
		XMLUtil<TransactionAddRsType> requestParser = new XMLUtil<TransactionAddRsType>();
		return requestParser.convertObjectToXml(this);	
	}

}
