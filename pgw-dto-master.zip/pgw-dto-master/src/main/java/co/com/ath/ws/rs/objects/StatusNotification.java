package co.com.ath.ws.rs.objects;

import java.io.Serializable;
import java.util.Date;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonProperty;

import co.com.ath.pgw.rest.util.DTOConstants;

public class StatusNotification implements Serializable{

	private static final long serialVersionUID = 1L;
	
	@JsonProperty("statusCode")
    private String statusCode;
	
	@JsonProperty("serverStatusCode")
    private String serverStatusCode;
	
	@JsonProperty("severity")	
    private String severity;
	
	@JsonProperty("statusDesc")	
    private String statusDesc;
	
	@JsonProperty("additionalStatus")
    private AdditionalStatusNotification additionalStatus;
	
	@JsonFormat(pattern="yyyy-MM-dd'T'HH:mm:ss.SSS'Z'", timezone = DTOConstants.TIMEZONE)
	@JsonProperty("endDt")
    private Date endDt;

	public String getStatusCode() {
		return statusCode;
	}

	public void setStatusCode(String statusCode) {
		this.statusCode = statusCode;
	}

	public String getServerStatusCode() {
		return serverStatusCode;
	}

	public void setServerStatusCode(String serverStatusCode) {
		this.serverStatusCode = serverStatusCode;
	}

	public String getSeverity() {
		return severity;
	}

	public void setSeverity(String severity) {
		this.severity = severity;
	}

	public String getStatusDesc() {
		return statusDesc;
	}

	public void setStatusDesc(String statusDesc) {
		this.statusDesc = statusDesc;
	}

	public AdditionalStatusNotification getAdditionalStatus() {
		return additionalStatus;
	}

	public void setAdditionalStatus(AdditionalStatusNotification additionalStatus) {
		this.additionalStatus = additionalStatus;
	}

	public Date getEndDt() {
		return endDt;
	}

	public void setEndDt(Date endDt) {
		this.endDt = endDt;
	}

}
