
package co.com.ath.pgw.rest.dto;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonProperty;

public class Agreement implements Serializable
{

    @JsonProperty("AgrmId")
    private String agrmId;
    @JsonProperty("CategCode")
    private String categCode;
    @JsonProperty("Name")
    private String name;
    @JsonProperty("NIT")
    private String nit;
    @JsonProperty("AgrmVfrCode")
    private String agrmVfrCode;
    @JsonProperty("ContactInfo")
    private ContactInfo contactInfo;
    @JsonProperty("Image")
    private Image image;
    @JsonProperty("DepAcctId")
    private DepAcctId depAcctId;
    private final static long serialVersionUID = -7749967594758311520L;


    public String getAgrmId() {
        return agrmId;
    }

    public void setAgrmId(String agrmId) {
        this.agrmId = agrmId;
    }

    public String getCategCode() {
		return categCode;
	}

	public void setCategCode(String categCode) {
		this.categCode = categCode;
	}

	public String getName() {
        return name;
    }
	
    public String getAgrmVfrCode() {
		return agrmVfrCode;
	}

	public void setAgrmVfrCode(String agrmVfrCode) {
		this.agrmVfrCode = agrmVfrCode;
	}


	public void setName(String name) {
        this.name = name;
    }

    public String getNit() {
        return nit;
    }

    public void setNit(String nit) {
        this.nit = nit;
    }

    public ContactInfo getContactInfo() {
        return contactInfo;
    }

    public void setContactInfo(ContactInfo contactInfo) {
        this.contactInfo = contactInfo;
    }

    public DepAcctId getDepAcctId() {
        return depAcctId;
    }
 
    public void setDepAcctId(DepAcctId depAcctId) {
        this.depAcctId = depAcctId;
    }

	public Image getImage() {
		return image;
	}

	public void setImage(Image image) {
		this.image = image;
	}
    
    

}

