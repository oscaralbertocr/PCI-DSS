package co.com.ath.ws.rs.objects;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonProperty;

public class InfoEstado implements Serializable {

	private static final long serialVersionUID = -2257249108973208108L;
    
	@JsonProperty("codigoRespuesta")
	private String codigoRespuesta; 
	
	@JsonProperty("estado")
    private String estado;
	
	@JsonProperty("estadoDetallado")
    private String estadoDetallado;

	public String getCodigoRespuesta() {
		return codigoRespuesta;
	}

	public void setCodigoRespuesta(String codigoRespuesta) {
		this.codigoRespuesta = codigoRespuesta;
	}

	public String getEstado() {
		return estado;
	}

	public void setEstado(String estado) {
		this.estado = estado;
	}

	public String getEstadoDetallado() {
		return estadoDetallado;
	}

	public void setEstadoDetallado(String estadoDetallado) {
		this.estadoDetallado = estadoDetallado;
	}
	
}
