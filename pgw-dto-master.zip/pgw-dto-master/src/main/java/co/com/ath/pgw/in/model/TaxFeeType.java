package co.com.ath.pgw.in.model;

import co.com.ath.pgw.client.bank.info.CurrencyAmountType;

public class TaxFeeType extends CurrencyAmtType {
	
	protected CurrencyAmountType curAmt = new CurrencyAmountType();

	public CurrencyAmountType getCurAmt() {
		return curAmt;
	}

	public void setCurAmt(CurrencyAmountType curAmt) {
		this.curAmt = curAmt;
	}

}