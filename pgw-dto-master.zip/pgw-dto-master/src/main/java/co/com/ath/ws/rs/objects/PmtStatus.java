package co.com.ath.ws.rs.objects;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonProperty;

public class PmtStatus implements Serializable {

	private static final long serialVersionUID = 1L;

	@JsonProperty("StatusDesc")
	private String statusDesc;

	
	public String getStatusDesc() {
		return statusDesc;
	}

	public void setStatusDesc(String statusDesc) {
		this.statusDesc = statusDesc;
	}

}
