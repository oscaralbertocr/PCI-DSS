
package co.com.ath.pgw.in.model;

import java.math.BigDecimal;
import java.util.List;

/**
*
* @author camilo.bustamante@sophossolutions.com
* @version 1.0 03 Enero 2019
* @RQ31686 RBM_Integracion_Boton_TC_GlobalPay
* 
*/

/**
 * <p>Clase Java para InfoCompra_Type complex type.
 * 
 * <p>El siguiente fragmento de esquema especifica el contenido que se espera que haya en esta clase.
 * 
 * <pre>
 * &lt;complexType name="InfoCompra_Type">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element ref="{urn://ath.com.co/xsd/common/}NumeroFactura" minOccurs="0"/>
 *         &lt;element ref="{urn://ath.com.co/xsd/common/}MontoTotal" minOccurs="0"/>
 *         &lt;element ref="{urn://ath.com.co/xsd/common/}InfoImpuestos"/>
 *         &lt;element ref="{urn://ath.com.co/xsd/common/}MontoDetallado"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
public class InfoCompraType {

    
    protected String numeroFactura;
    
    
    protected BigDecimal montoTotal;
    
    
    protected List<InfoImpuestosType> infoImpuestos;
    
   
    protected List<MontoDetalladoType> montoDetallado;

    
	public String getNumeroFactura() {
		return numeroFactura;
	}

	public void setNumeroFactura(String numeroFactura) {
		this.numeroFactura = numeroFactura;
	}

	public BigDecimal getMontoTotal() {
		return montoTotal;
	}

	public void setMontoTotal(BigDecimal montoTotal) {
		this.montoTotal = montoTotal;
	}

	public List<InfoImpuestosType> getInfoImpuestos() {
		return infoImpuestos;
	}

	public void setInfoImpuestos(List<InfoImpuestosType> infoImpuestos) {
		this.infoImpuestos = infoImpuestos;
	}

	public List<MontoDetalladoType> getMontoDetallado() {
		return montoDetallado;
	}

	public void setMontoDetallado(List<MontoDetalladoType> montoDetallado) {
		this.montoDetallado = montoDetallado;
	}
	
	
    
}
