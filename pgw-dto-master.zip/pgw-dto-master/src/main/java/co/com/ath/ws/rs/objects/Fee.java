package co.com.ath.ws.rs.objects;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonProperty;

public class Fee implements Serializable{

	private static final long serialVersionUID = 1L;
	
	@JsonProperty("amt")
	private String amt;
	
	@JsonProperty("curCode")
	private String curCode;

	public String getAmt() {
		return amt;
	}

	public void setAmt(String amt) {
		this.amt = amt;
	}

	public String getCurCode() {
		return curCode;
	}

	public void setCurCode(String curCode) {
		this.curCode = curCode;
	}
	
	

}
