/*
 * ProductTypeVO
 *  
 * GSI - Integración
 * Creado el: 28/08/2014
 *
 * Copyright (c) A Toda Hora S.A. Todos los derechos reservados
 * 
 * Este software es confidencial y es propietario de ATH, queda prohibido
 * su uso, reproducción y copia de manera parcial o permanente salvo autorización
 * expresa de A Toda Hora S.A o de quién represente sus derechos.
 */
package co.com.ath.pgw.bsn.model.bo;


/**
 * Representa un tupo de producto financiero válido en la Pasarela de Pagos.
 * Esta entidad pertenece al modelo persistente.
 * 
 * @author proveedor_japiza
 * @version 1.0 29 Ago 2014
 * @since 1.0
 *
 */
public class ProductTypeBO {

	/**
	 * Identificador del tipo de producto.
	 */
	private Long id;
	
	/**
	 * Nombre o descripción del tipo de producto.
	 */
	private String name;

    /**
     * Constructor por defecto de la clase.
     */
    public ProductTypeBO() {
    }

    /**
     * Contructor con inicialización por id
     * @param id 
     */
    public ProductTypeBO(Long id) {
        this.id = id;
    }
    
	/**
	 * Retorna el identificador del tipo de producto.
	 * 
	 * @return Identificador del tipo de producto.
	 */
	public Long getId() {
		return id;
	}

	/**
	 * Establece el identificador del tipo de producto.
	 * 
	 * @param id Identificador del tipo de producto.
	 */
	public void setId(Long id) {
		this.id = id;
	}

	/**
	 * Retorna el nombre o descripción del tipo de producto.
	 * 
	 * @return Nombre del tipo de producto.
	 */
	public String getName() {
		return name;
	}

	/**
	 * Establece el nombre o descripción del tipo de producto.
	 * 
	 * @param name Nombre del tipo de producto.
	 */
	public void setName(String name) {
		this.name = name;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + (int) (id ^ (id >>> 32));
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		ProductTypeBO other = (ProductTypeBO) obj;
		if (id != other.id)
			return false;
		return true;
	}

	@Override
	public String toString() {
		return "ProductTypeVO [id=" + id + ", name=" + name + "]";
	}
	
}