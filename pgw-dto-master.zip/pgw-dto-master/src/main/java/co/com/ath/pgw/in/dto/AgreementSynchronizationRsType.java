package co.com.ath.pgw.in.dto;

import co.com.ath.pgw.core.logging.util.XMLUtil;
import co.com.ath.pgw.in.model.SvcRsType;

public class AgreementSynchronizationRsType extends SvcRsType {
	
	@Override
	public String toString() {
		XMLUtil<AgreementSynchronizationRsType> requestParser = 
				new XMLUtil<AgreementSynchronizationRsType>();
		return requestParser.convertObjectToXml(this);
	}
	
	
}
