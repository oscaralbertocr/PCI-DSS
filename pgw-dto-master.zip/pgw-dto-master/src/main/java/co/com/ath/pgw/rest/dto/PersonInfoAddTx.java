
package co.com.ath.pgw.rest.dto;

import java.io.Serializable;

import javax.validation.Valid;
import javax.validation.constraints.NotNull;
import javax.xml.datatype.XMLGregorianCalendar;
import com.fasterxml.jackson.annotation.JsonProperty;

public class PersonInfoAddTx implements Serializable
{

    @JsonProperty("PersonName")
	@Valid
	@NotNull
    private PersonNameAddTx personName;
    
    @JsonProperty("ContactInfo")
	@Valid
	@NotNull
    private ContactInfoAddTx contactInfo;
    
    @JsonProperty("GovIssueIdent")
	@Valid
    private GovIssueIdentAddTx govIssueIdent;
    
    @JsonProperty("BirthDt")
    private XMLGregorianCalendar birthDt;
    
    @JsonProperty("Gender")
    private String gender;
    
    private final static long serialVersionUID = -3627699914877345394L;

    
    public PersonNameAddTx getPersonName() {
        return personName;
    }

    public void setPersonName(PersonNameAddTx personName) {
        this.personName = personName;
    }

    public ContactInfoAddTx getContactInfo() {
        return contactInfo;
    }
    
    public void setContactInfo(ContactInfoAddTx contactInfo) {
        this.contactInfo = contactInfo;
    }
    public GovIssueIdentAddTx getGovIssueIdent() {
        return govIssueIdent;
    }

    public void setGovIssueIdent(GovIssueIdentAddTx govIssueIdent) {
        this.govIssueIdent = govIssueIdent;
    }

    public XMLGregorianCalendar getBirthDt() {
        return birthDt;
    }

    public void setBirthDt(XMLGregorianCalendar birthDt) {
        this.birthDt = birthDt;
    }
        
    public String getGender() {
        return gender;
    }
    
    public void setGender(String gender) {
        this.gender = gender;
    }
}