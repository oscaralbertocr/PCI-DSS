/*
 * TransactionVO
 *  
 * GSI - Integración
 * Creado el: 28/08/2014
 *
 * Copyright (c) A Toda Hora S.A. Todos los derechos reservados
 * 
 * Este software es confidencial y es propietario de ATH, queda prohibido
 * su uso, reproducción y copia de manera parcial o permanente salvo autorización
 * expresa de A Toda Hora S.A o de quién represente sus derechos.
 */
package co.com.ath.pgw.bsn.model.bo;

import java.math.BigDecimal;
import java.util.Date;

/**
 * Representa una transacción de pago en el Core de la Pasarela de Pago. Esta
 * entidad pertenece al modelo de negocio.
 * 
 * @author proveedor_japiza
 * @version 1.0 29 Ago 2014
 * @since 1.0
 * 
 *  @RQ31820
 *  <strong>Autor</strong>Roger Jans Leguizamon Cespedes</br>
 *  <strong>Descripcion</strong>URL de retorno a comercio para PSE</br>
 *  <strong>Numero de Cambios</strong>2</br>
 *  <strong>Identificador corto</strong>C01</br>
 */
public class TransactionBO {

	/**
	 * Identificador de la transacción en el Core de la Pasarela de Pagos.
	 */
	private String id;
	
	/**
	 * Llave unica con digito de verificación de la transacción en el Core de la Pasarela de Pagos.
	 */
	private String pmtId;
	
	/**
	 * Comercio que inicia la transacción.
	 */
	private CommerceBO commerce;


	/**
	 * Estado de la transacción.
	 */
	private TransactionStatusBO status;
	
	/**
	 * Tipo de transacción.
	 */
	private TransactionTypeBO transactionType;
	
	/**
	 * Origen de la transacción.
	 */
	private TransactionSourceBO source;

	/**
	 * Medio de pago.
	 */
	private PaymentWayBO paymentWay;
	
	/**
	 * Tipo de producto financiero usado para el pago.
	 */
	private ProductTypeBO productType;
	
	/**
	 * Tarjeta de crédito asociada a la transacción.
	 */
	private CreditCardBO creditCard;

	/**
	 * Código de trazabilidad con redes externas (ACH, Redeban, etc)
	 */
	private String trazabilityCode;
	
	/**
	 * Banco autorizador de la transacción. Este campo se usa solo con pagos
	 * AVAL y PSE 
	 */
	private BankBO bank;

	/**
	 * Dirección IP relacionada a la transacción.
	 */
	private String ipAddress;
	
	/**
	 * Código de respuesta de los servicios de pago.
	 */
	private ResponseCodeBO responseCode;

	/**
	 * Fecha en la que se inició la transacción.
	 */
	private Date transactionDate;

	/**
	 * Referencia de pago que envia el comercio.
	 */
	private String orderNumber;

	/**
	 * Valor total de la transacción.
	 */
	private BigDecimal totalValue;

	/**
	 * Valor del impuesto de la transacción.
	 */
	private BigDecimal taxValue;

	/**
	 * Código de la moneda usada para la transacción. (Currency code).
	 */
	private String currency;

	/**
	 * Descripción de la transacción.
	 */
	private String description;

	/**
	 * Número de aprobación del pago de la transacción para AVAL y RBM.
	 */
	private String approvalNumber;

	/**
	 * Fecha de pago de la transacción.
	 */
	private Date payDate;

	/**
	 * Fecha en que se hace efectiva la compensación del pago de la transacción.
	 */
	private Date compensationDate;

	/**
	 * Indicador del tipo de persona (0 Natural, 1 Jurídica).
	 */
	private Integer customerType;
	
	/**
	 * Tipo de documento del comprador que generó la transacción.
	 */
	private String customerDocType;
	
	/**
	 * Número de documento del comprador que generó la transacción.
	 */
	private String customerDocId;

	/**
	 * Nombre del comprador que generó la transacción.
	 */
	private String customerName;
	
	/**
	 * Correo electrónico del comprador que generó la transacción.
	 */
	private String customerEmail;

	/**
	 * Número de celular del comprador que generó la transacción.
	 */
	private String customerMobileNumber;

	/**
	 * Referencia 1 adicional en la transacción
	 */
	private String reference1;

	/**
	 * Referencia 2 adicional en la transacción
	 */
	private String reference2;

	/**
	 * Referencia 3 adicional en la transacción
	 */
	private String reference3;

	/**
	 * DevicePrint para RSA
	 */
	private String devicePrint;
	
	/**
	 * DeviceTokenCookie para RSA
	 */
	private String deviceTokenCookie;
	
	/**
	 * httpAccept para RSA
	 */
	private String httpAccept;
	
	/**
	 * httpAcceptLanguage para RSA
	 */
	private String httpAcceptLanguage;
	
	/**
	 * httpReferrer para RSA
	 */
	private String httpReferrer;
	
	/**
	 * userAgent para RSA
	 */
	private String userAgent;

	/**
	 * Construye una transacción.
	 */
	
	/**
	 * Nombre compañía del pagador.
	 */
	private String payerCompany;
	
	/**
	 * Nombre del pagador.
	 */
	private String firstNamePayer;
	
	/**
	 * Nombre alias pagador.
	 */
	private String payerNickName;
	
	/**
	 * Tipo de documento del pagador.
	 */
	private String payerDocType;
	
	/**
	 * Número de documento del pagador.
	 */
	private String payerDocId;
	
	/**
	 * Género del pagador.
	 */
	private String payerGender;
	
	/**
	 * Fecha de nacimiento del pagador.
	 */
	private Date payerBirthDate;
	
	/**
	 * Ciudad de nacimiento del pagador.
	 */
	private String payerCity;
	
	/**
	 * Departamento de nacimiento del pagador.
	 */
	private String payerDepartment;
	
	/**
	 * País de nacimiento del pagador.
	 */
	private String payerCountry;
	
	/**
	 * Dirección del pagador.
	 */
	private String payerAddress;
	
	/**
	 * Mail del pagador.
	 */
	private String payerMail;
	
	/**
	 * Telefono del pagador.
	 */
	private String payerPhone;
	
	/**
	 * Url de respesta.
	 */
	private String urlResponse;
	
	/**
	 * Tipo de transaccion
	 */
	private String trnType;
	
	/**
	 * Referencia 2 de pago en la transacción
	 */
	private String invoiceReference2;
	
	/**
	 * Referencia 3 de pago en la transacción
	 */
	private String invoiceReference3;
	
	/**
	 * Referencia 4 de pago en la transacción
	 */
	private String invoiceReference4;
	
	/**
	 * Intención de pago
	 */
	private String categoryId;
	
	/**
	 * Tipo de pago
	 */
	private String pmtType;
	
	/**
	 * Canal de la transacción
	 */
	private String trnChannel;
	
	/**
	 * Trm
	 */
	private String trm;
	
	/**
	 * CurCodeTrm
	 */
	private String curCodeTrm;
	
/**
	 * Segundo Nombre del comprador que generó la transacción.
	 */
	private String middleNameBuyer;
	
	/**
	 * Primer Apellido del comprador que generó la transacción.
	 */
	private String lastNameBuyer;
	
	/**
	 * Segundo Apellido del comprador que generó la transacción.
	 */
	private String secondLastNameBuyer;
	
	/**
	 * Segundo Nombre del pagador que generó la transacción.
	 */
	private String middleNamePayer;
	
	/**
	 * Primer Apellido del pagador que generó la transacción.
	 */
	private String lastNamePayer;
	
	/**
	 * Segundo Apellido del pagador que generó la transacción.
	 */
	private String secondLastNamePayer;

	/**
	 * Url del logo para la transaccion, Ventanilla de pagos, 
	 */
	private String logoURL;
	
	/**
	 * Indica si existe template, Ventanilla de pagos, 
	 */
	private String template;
	
	/**
	 * Tema que se usara en la transaccion, Ventanilla de pagos, 
	 */
	private String theme;
	
	/**
	 * Referencia BBOG, indica el id del tipo de documento del dueño de la referencia de pago
	 */
	private String idTypeDoc;
	
	/**
	 * Referencia BBOG, indica el numero de documento del dueño de la referencia de pago 
	 */
	private String numDoc;
	/**
	 * Referencia BBOG, indica si se han aceptado los terminos y condiciones del pago 
	 */
	private String termsNConditions;
	
	/**
	 * RQ25510 Motor de Riesgo.
	 * Persistencia del RqUID
	 */
	private Long rqUID;
	
	private String tokenized;
	
	/** INICIO C01 */
	private String returnURL;
	/** FIN C01 */
	
	public TransactionBO(){
		super();
	}

	public TransactionBO(TransactionSourceBO source) {
		super();
		this.source = source;
	}

	/**
	 * Retorna el identificador de la transacción en el Core de la Pasarela de
	 * Pagos.
	 * 
	 * @return Identificador de la transacción.
	 */
	public String getId(){
		return id;
	}

	/**
	 * Retorna el identificador de la transacción en el Core de la Pasarela de
	 * Pagos.
	 * 
	 * @param id Identificador de la transacción.
	 */
	public void setId(String id){
		this.id = id;
	}
	
	/**
	 * Retorna el PmtId de la transacción en el Core de la Pasarela de
	 * Pagos.
	 * 
	 * @return pmtid de la transacción.
	 */
	public String getPmtId(){
		return pmtId;
	}

	/**
	 * Retorna el PmtId de la transacción en el Core de la Pasarela de
	 * Pagos.
	 * 
	 * @param pmtid de la transacción.
	 */
	public void setPmtId(String pmtid){
		this.pmtId = pmtid;
	}

	/**
	 * Retorna el comercio beneficiario del pago.
	 * 
	 * @return Comercio involucrado.
	 */
	public CommerceBO getCommerce(){
		return commerce;
	}

	/**
	 * Establece el comercio beneficiario del pago.
	 * 
	 * @param commerce Comercio involucrado.
	 */
	public void setCommerce(CommerceBO commerce){
		this.commerce = commerce;
	}

	/**
	 * Retorna el estado de la transacción.
	 * 
	 * @return Estado de la transacción.
	 */
	public TransactionStatusBO getStatus(){
		return status;
	}

	/**
	 * Establece el estado de la transacción.
	 * 
	 * @param status Estado de la transacción.
	 */
	public void setStatus(TransactionStatusBO status){
		this.status = status;
	}

	/**
	 * Retorna el tipo de transacción.
	 * 
	 * @return Tipo de transacción.
	 */
	public TransactionTypeBO getTransactionType(){
		return transactionType;
	}

	/**
	 * Retorna el tipo de transacción.
	 * 
	 * @return Tipo de transacción.
	 */
	public void setTransactionType(TransactionTypeBO transactionType){
		this.transactionType = transactionType;
	}

	/**
	 * Retorna el origen de la transacción.
	 * 
	 * @return Origen de la transacción.
	 */
	public TransactionSourceBO getSource(){
		return source;
	}

	/**
	 * Establece el origen de la transacción.
	 * 
	 * @param source Origen de la transacción.
	 */
	public void setSource(TransactionSourceBO source){
		this.source = source;
	}

	/**
	 * Retorna el medio de pago de la transacción.
	 * 
	 * @return Medio de pago.
	 */
	public PaymentWayBO getPaymentWay(){
		return paymentWay;
	}

	/**
	 * Establece el medio de pago de la transacción.
	 * 
	 * @param paymentWay Medio de pago.
	 */
	public void setPaymentWay(PaymentWayBO paymentWay){
		this.paymentWay = paymentWay;
	}

	/**
	 * Retorna el tipo de producto financiero usado para el pago.
	 * 
	 * @return Tipo de producto.
	 */
	public ProductTypeBO getProductType(){
		return productType;
	}

	/**
	 * Establece el tipo de producto financiero usado para el pago.
	 * 
	 * @param productType Tipo de producto.
	 */
	public void setProductType(ProductTypeBO productType){
		this.productType = productType;
	}

	/**
	 * Retorna la tarjeta de crédito asociada a la transacción.
	 * 
	 * @return Tarjeta de crédito asociada a la transacción.
	 */
	public CreditCardBO getCreditCard(){
		return creditCard;
	}

	/**
	 * Establece la tarjeta de crédito asociada a la transacción.
	 * 
	 * @param creditCard Tarjeta de crédito asociada a la transacción.
	 */
	public void setCreditCard(CreditCardBO creditCard){
		this.creditCard = creditCard;
	}

	/**
	 * Retorna el código de trazabilidad con redes externas (ACH, Redeban, etc).
	 * 
	 * @return Código de trazabilidad con redes externas.
	 */
	public String getTrazabilityCode(){
		return trazabilityCode;
	}

	/**
	 * Establece el código de trazabilidad con redes externas 
	 * (ACH, Redeban, etc).
	 * 
	 * @param trazabilityCode Código de trazabilidad con redes externas..
	 */
	public void setTrazabilityCode(String trazabilityCode){
		this.trazabilityCode = trazabilityCode;
	}

	/**
	 * Retorna el Banco autorizador del pago de la transacción. Este campo se 
	 * usa únicamente con pagos AVAL y PSE.
	 *  
	 * @return  Banco autorizador del pago.
	 */
	public BankBO getBank(){
		return bank;
	}

	/**
	 * Establece el Banco autorizador del pago de la transacción. Este campo se 
	 * usa únicamente con pagos AVAL y PSE.
	 * 
	 * @param bank Banco atorizador del pago.
	 */
	public void setBank(BankBO bank){
		this.bank = bank;
	}

	
	/**
	 * Retorna la dirección IP relacionada con la transacción.
	 * 
	 * @return Dirección IP relacionada.
	 */
	public String getIpAddress(){
		return ipAddress;
	}

	/**
	 * Establece la dirección IP relacionada con la transacción.
	 * 
	 * @param ipAddress Dirección IP relacionada.
	 */
	public void setIpAddress(String ipAddress){
		this.ipAddress = ipAddress;
	}
	
	/**
	 * Retorna el código de respuesta emitido por los servicios de pago.
	 * 
	 * @return Código de respuesta de los servicios de pago.
	 */
	public ResponseCodeBO getResponseCode(){
		return responseCode;
	}

	/**
	 * Establece el código de respuesta emitido por los servicios de pago.
	 * 
	 * @param responseCode Código de respuesta de los servicios de pago.
	 */
	public void setResponseCode(ResponseCodeBO responseCode){
		this.responseCode = responseCode;
	}

	/**
	 * Retorna la fecha en la que se inició la transacción.
	 * 
	 * @return Fecha en la que se inició la transacción.
	 */
	public Date getTransactionDate(){
		return transactionDate;
	}

	/**
	 * Establede la fecha en la que se inició la transacción.
	 * @param transactionDate Fecha en la que se inició la transacción.
	 */
	public void setTransactionDate(Date transactionDate){
		this.transactionDate = transactionDate;
	}

	/**
	 * Retorna la referencia de pago que envia el comercio.
	 * 
	 * @return La referencia de pago que envia el comercio.
	 */
	public String getOrderNumber(){
		return orderNumber;
	}

	/**
	 * Establece la referencia de pago que envia el comercio.
	 * 
	 * @param orderNumber Referencia de pago.
	 */
	public void setOrderNumber(String orderNumber){
		this.orderNumber = orderNumber;
	}

	/**
	 * Retorna el valor total de la transacción.
	 * 
	 * @return Valor total de la transacción.
	 */
	public BigDecimal getTotalValue(){
		return totalValue;
	}

	/**
	 * Establece el valor total de la transacción.
	 * 
	 * @param totalValue Valor total de la transacción.
	 */
	public void setTotalValue(BigDecimal totalValue){
		this.totalValue = totalValue;
	}

	/**
	 * Retorna el valor del impuesto de la transacción.
	 * 
	 * @return Valor del impuesto de la transacción.
	 */
	public BigDecimal getTaxValue(){
		return taxValue;
	}

	/**
	 * Establece el valor del impuesto de la transacción.
	 * 
	 * @param taxValue Valor del impuesto.
	 */
	public void setTaxValue(BigDecimal taxValue){
		this.taxValue = taxValue;
	}

	/**
	 * Retorna el código de la moneda usada en la transacción. (Currency code).
	 * 
	 * @return Código de la moneda usada.
	 */
	public String getCurrency(){
		return currency;
	}

	/**
	 * Establece el código de la moneda usada en la transacción. 
	 * (Currency code).
	 * 
	 * @param currency Código de la moneda usada.
	 */
	public void setCurrency(String currency){
		this.currency = currency;
	}

	/**
	 * Retorna la descripción de la transacción.
	 * 
	 * @return Descripción de la transacción.
	 */
	public String getDescription(){
		return description;
	}

	/**
	 * Retorna la descripción de la transacción.
	 * 
	 * @param description Descripción de la transacción.
	 */
	public void setDescription(String description){
		this.description = description;
	}

	/**
	 * Retorna el número de aprobación del pago de la transacción para AVAL y
	 * RBM.
	 * 
	 * @return Número de aprobación del pago.
	 */
	public String getApprovalNumber(){
		return approvalNumber;
	}

	/**
	 * Establece el número de aprobación del pago de la transacción para AVAL y
	 * RBM.
	 * 
	 * @param approvalNumber Número de aprobación del pago.
	 */
	public void setApprovalNumber(String approvalNumber){
		this.approvalNumber = approvalNumber;
	}

	/**
	 * Retorna la fecha de pago de la transacción.
	 * 
	 * @return Fecha de pago de la transacción.
	 */
	public Date getPayDate(){
		return payDate;
	}

	/**
	 * Establece la fecha de pago de la transacción.
	 * 
	 * @param payDate Fecha de pago de la transacción.
	 */
	public void setPayDate(Date payDate){
		this.payDate = payDate;
	}

	/**
	 * Retorna la fecha en que se hace efectiva la compensación del pago de la 
	 * transacción.
	 * 
	 * @return Fecha de compensación.
	 */
	public Date getCompensationDate(){
		return compensationDate;
	}

	/**
	 * Establece la fecha en que se hace efectiva la compensación del pago de la 
	 * transacción.
	 * 
	 * @param compensationDate Fecha de compensación.
	 */
	public void setCompensationDate(Date compensationDate){
		this.compensationDate = compensationDate;
	}

	/**
	 * Retorna el tipo de cliente (0 Natural, 1 Jurídica).
	 * 
	 * @return Tipo de cliente.
	 */
	public Integer getCustomerType(){
		return customerType;
	}

	/**
	 * Establece el tipo de cliente (0 Natural, 1 Jurídica).
	 * 
	 * @param customerType Tipo de cliente.
	 */
	public void setCustomerType(Integer customerType){
		this.customerType = customerType;
	}

	/**
	 * Retorna el tipo de documento del comprador que generó la transacción.
	 * @return Tipo de documento del comprador.
	 */
	public String getCustomerDocType(){
		return customerDocType;
	}

	/**
	 * Establece el tipo de documento del comprador que generó la transacción.
	 * 
	 * @param customerDocType Tipo de documento del comprador.
	 */
	public void setCustomerDocType(String customerDocType){
		this.customerDocType = customerDocType;
	}

	/**
	 * Retorna el número de documento del comprador que generó la transacción.
	 * 
	 * @return Número de documento del comprador.
	 */
	public String getCustomerDocId(){
		return customerDocId;
	}

	/**
	 * Establece el número de documento del comprador que generó la transacción.
	 * 
	 * @param customerDocId Número de documento del comprador.
	 */
	public void setCustomerDocId(String customerDocId){
		this.customerDocId = customerDocId;
	}

	/**
	 * Retorna el nombre del comprador que generó la transacción.
	 * 
	 * @return Nombre del comprador.
	 */
	public String getCustomerName(){
		return customerName;
	}

	/**
	 * Establece el nombre del comprador que generó la transacción.
	 * 
	 * @param customerName Nombre del comprador.
	 */
	public void setCustomerName(String customerName){
		this.customerName = customerName;
	}

	/**
	 * Retorna la dirección de correo electrónico del comprador que generó la 
	 * transacción.
	 * 
	 * @return Correo electrónico del comprador.
	 */
	public String getCustomerEmail(){
		return customerEmail;
	}

	/**
	 * Establece la dirección de correo electrónico del comprador que generó la 
	 * transacción.
	 * 
	 * @param customerEmail Correo electrónico del comprador.
	 */
	public void setCustomerEmail(String customerEmail){
		this.customerEmail = customerEmail;
	}

	/**
	 * Retorna el número de celular del comprador que generó la transacción.
	 * 
	 * @return Número celular del comprador.
	 */
	public String getCustomerMobileNumber(){
		return customerMobileNumber;
	}

	/**
	 * Establece el número de celular del comprador que generó la transacción.
	 * 
	 * @param customerMobileNumber Número celular del comprador.
	 */
	public void setCustomerMobileNumber(String customerMobileNumber){
		this.customerMobileNumber = customerMobileNumber;
	}

	/**
	 * Retorna la primera referencia adicional relacionada con la transacción.
	 * 
	 * @return Primera referencia adicional.
	 */
	public String getReference1(){
		return reference1;
	}

	/**
	 * Establece la primera referencia adicional relacionada con la transacción.
	 * 
	 * @param reference1 Primera referencia adicional.
	 */
	public void setReference1(String reference1){
		this.reference1 = reference1;
	}

	/**
	 * Retorna la segunda referencia adicional relacionada con la transacción.
	 * 
	 * @return Segunda referencia adicional.
	 */
	public String getReference2(){
		return reference2;
	}

	/**
	 * Establece la segunda referencia adicional relacionada con la transacción.
	 * 
	 * @param reference2 Segunda referencia adicional.
	 */
	public void setReference2(String reference2){
		this.reference2 = reference2;
	}

	/**
	 * Retorna la tercera referencia adicional relacionada con la transacción.
	 * @return Tercera referencia adicional.
	 */
	public String getReference3(){
		return reference3;
	}

	/**
	 * Establece la tercera referencia adicional relacionada con la transacción.
	 * 
	 * @param reference3 Tercera referencia adicional.
	 */
	public void setReference3(String reference3){
		this.reference3 = reference3;
	}

	@Override
	public int hashCode(){
		final int prime = 31;
		int result = 1;
		result = prime * result + ((id == null) ? 0 : id.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj){
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		TransactionBO other = (TransactionBO) obj;
		if (id == null){
			if (other.id != null)
				return false;
		} else if (!id.equals(other.id))
			return false;
		return true;
	}

	@Override
	public String toString(){
		return "TransactionVO [id=" + id + ", commerce=" + commerce
				+ ", status=" + status
				+ ", trazabilityCode=" + trazabilityCode + "]";
	}
	
	/**
	 * Método encargado de recuperar el valor del atributo payerCompany.
	 * @return El atributo payerCompany asociado a la clase payerCompany.
	 */
	public String getPayerCompany() {
		return payerCompany;
	}

	/**
	 * Método encargado de actualizar el atributo payerCompany.
	 * @param payerCompany Nuevo valor para payerCompany.
	 */
	public void setPayerCompany(String payerCompany) {
		this.payerCompany = payerCompany;
	}

	/**
	 * Método encargado de recuperar el valor del atributo firstNamePayer.
	 * @return El atributo firstNamePayer asociado a la clase firstNamePayer.
	 */
	public String getFirstNamePayer() {
		return firstNamePayer;

	}

	/**
	 * Método encargado de actualizar el atributo firstNamePayer.
	 * @param firstNamePayer Nuevo valor para firstNamePayer.
	 */
	public void setFirstNamePayer(String firstNamePayer) {

		this.firstNamePayer = firstNamePayer;

	}

	/**
	 * Método encargado de recuperar el valor del atributo payerNickName.
	 * @return El atributo payerNickName asociado a la clase.
	 */
	public String getPayerNickName() {
		return payerNickName;
	}

	/**
	 * Método encargado de actualizar el atributo payerNickName.
	 * @param payerNickName Nuevo valor para payerNickName.
	 */
	public void setPayerNickName(String payerNickName) {
		this.payerNickName = payerNickName;
	}

	/**
	 * Método encargado de recuperar el valor del atributo payerDocType.
	 * @return El atributo jobLockId asociado a la clase payerDocType.
	 */
	public String getPayerDocType() {
		return payerDocType;
	}

	/**
	 * Método encargado de actualizar el atributo payerDocType.
	 * @param payerDocType Nuevo valor para payerDocType.
	 */
	public void setPayerDocType(String payerDocType) {
		this.payerDocType = payerDocType;
	}

	/**
	 * Método encargado de recuperar el valor del atributo payerDocId.
	 * @return El atributo payerDocId asociado a la clase.
	 */
	public String getPayerDocId() {
		return payerDocId;
	}

	/**
	 * Método encargado de actualizar el atributo payerDocId.
	 * @param payerDocId Nuevo valor para payerDocId.
	 */
	public void setPayerDocId(String payerDocId) {
		this.payerDocId = payerDocId;
	}

	/**
	 * Método encargado de recuperar el valor del atributo payerGender.
	 * @return El atributo payerGender asociado a la clase.
	 */
	public String getPayerGender() {
		return payerGender;
	}

	/**
	 * Método encargado de actualizar el atributo payerGender.
	 * @param payerGender Nuevo valor para payerGender.
	 */
	public void setPayerGender(String payerGender) {
		this.payerGender = payerGender;
	}

	/**
	 * Método encargado de recuperar el valor del atributo payerBirthDate.
	 * @return El atributo payerBirthDate asociado a la clase.
	 */
	public Date getPayerBirthDate() {
		return payerBirthDate;
	}

	/**
	 * Método encargado de actualizar el atributo payerBirthDate.
	 * @param payerBirthDate Nuevo valor para payerBirthDate.
	 */
	public void setPayerBirthDate(Date payerBirthDate) {
		this.payerBirthDate = payerBirthDate;
	}

	/**
	 * Método encargado de recuperar el valor del atributo payerCity.
	 * @return El atributo payerCity asociado a la clase.
	 */
	public String getPayerCity() {
		return payerCity;
	}

	/**
	 * Método encargado de actualizar el atributo payerCity.
	 * @param payerCity Nuevo valor para payerCity.
	 */
	public void setPayerCity(String payerCity) {
		this.payerCity = payerCity;
	}

	/**
	 * Método encargado de recuperar el valor del atributo payerDepartment.
	 * @return El atributo payerDepartment asociado a la clase.
	 */
	public String getPayerDepartment() {
		return payerDepartment;
	}

	/**
	 * Método encargado de actualizar el atributo payerDepartment.
	 * @param payerDepartment Nuevo valor para payerDepartment.
	 */
	public void setPayerDepartment(String payerDepartment) {
		this.payerDepartment = payerDepartment;
	}

	/**
	 * Método encargado de recuperar el valor del atributo payerCountry.
	 * @return El atributo payerCountry asociado a la clase.
	 */
	public String getPayerCountry() {
		return payerCountry;
	}

	/**
	 * Método encargado de actualizar el atributo payerCountry.
	 * @param payerCountry Nuevo valor para payerCountry.
	 */
	public void setPayerCountry(String payerCountry) {
		this.payerCountry = payerCountry;
	}

	/**
	 * Método encargado de recuperar el valor del atributo payerAddress.
	 * @return El atributo payerAddress asociado a la clase.
	 */
	public String getPayerAddress() {
		return payerAddress;
	}

	/**
	 * Método encargado de actualizar el atributo payerAddress.
	 * @param payerAddress Nuevo valor para payerAddress.
	 */
	public void setPayerAddress(String payerAddress) {
		this.payerAddress = payerAddress;
	}

	/**
	 * Método encargado de recuperar el valor del atributo payerMail.
	 * @return El atributo payerMail asociado a la clase.
	 */
	public String getPayerMail() {
		return payerMail;
	}

	/**
	 * Método encargado de actualizar el atributo payerMail.
	 * @param payerMail Nuevo valor para payerMail.
	 */
	public void setPayerMail(String payerMail) {
		this.payerMail = payerMail;
	}

	/**
	 * Método encargado de recuperar el valor del atributo payerPhone.
	 * @return El atributo payerPhone asociado a la clase.
	 */
	public String getPayerPhone() {
		return payerPhone;
	}

	/**
	 * Método encargado de actualizar el atributo payerPhone.
	 * @param payerPhone Nuevo valor para payerPhone.
	 */
	public void setPayerPhone(String payerPhone) {
		this.payerPhone = payerPhone;
	}
	
	/**
	 * Retorna la url de respuesta.
	 * 
	 * @return Url de respuesta.
	 */
	public String getUrlResponse(){
		return urlResponse;
	}

	/**
	 * Método encargado de actualizar el atributo urlResponse.
	 * @param urlResponse Nuevo valor para urlResponse.
	 */
	public void setUrlResponse(String urlResponse){
		this.urlResponse = urlResponse;
	}
	
	/**
	 * Retorna el tipo de transaccion.
	 * 
	 * @return Tipo de transaccion.
	 */
	public String getTrnType(){
		return trnType;
	}

	/**
	 * Método encargado de actualizar el atributo trnType.
	 * @param trnType nuevo valor para trnType.
	 */
	public void setTrnType(String trnType){
		this.trnType = trnType;
	}
	
	/**
	 * Método encargado de actualizar el atributo invoiceReference2.
	 * @param invoiceReference2 nuevo valor para invoiceReference2.
	 */
	public void setInvoiceReference2(String invoiceReference2){
		this.invoiceReference2 = invoiceReference2;
	}
	
	/**
	 * Retorna el valor invoiceReference2.
	 * 
	 * @return invoiceReference2.
	 */
	public String getInvoiceReference2(){
		return invoiceReference2;
	}
	
	/**
	 * Método encargado de actualizar el atributo invoiceReference3.
	 * @param invoiceReference3 nuevo valor para invoiceReference3.
	 */
	public void setInvoiceReference3(String invoiceReference3){
		this.invoiceReference3 = invoiceReference3;
	}
	
	/**
	 * Retorna el valor invoiceReference3.
	 * 
	 * @return invoiceReference3.
	 */
	public String getInvoiceReference3(){
		return invoiceReference3;
	}
	
	/**
	 * Método encargado de actualizar el atributo invoiceReference4.
	 * @param invoiceReference4 nuevo valor para invoiceReference4.
	 */
	public void setInvoiceReference4(String invoiceReference4){
		this.invoiceReference4 = invoiceReference4;
	}
	
	/**
	 * Retorna el valor invoiceReference4.
	 * 
	 * @return invoiceReference4.
	 */
	public String getInvoiceReference4(){
		return invoiceReference4;
	}

	/**
	 * Método encargado de actualizar el atributo invoiceReference4.
	 * @param invoiceReference4 nuevo valor para invoiceReference4.
	 */
	public void setCategoryId(String categoryId){
		this.categoryId = categoryId;
	}
	
	/**
	 * Retorna el valor categoryId.
	 * 
	 * @return categoryId.
	 */
	public String getCategoryId(){
		return categoryId;
	}
	
	/**
	 * Método encargado de actualizar el atributo pmtType.
	 * @param pmtType nuevo valor para pmtType.
	 */
	public void setPmtType(String pmtType){
		this.pmtType = pmtType;
	}
	
	/**
	 * Retorna el valor pmtType.
	 * 
	 * @return pmtType.
	 */
	public String getPmtType(){
		return pmtType;
	}
	
	/**
	 * Método encargado de actualizar el atributo trnChannel.
	 * @param trnChannel nuevo valor para trnChannel.
	 */
	public void setTrnChannel(String trnChannel){
		this.trnChannel = trnChannel;
	}
	
	/**
	 * Retorna el valor trnChannel.
	 * 
	 * @return trnChannel.
	 */
	public String getTrnChannel(){
		return trnChannel;
	}
	
	/**
	 * Método encargado de actualizar el atributo trm.
	 * @param trm nuevo valor para trm.
	 */
	public void setTrm(String trm){
		this.trm = trm;
	}
	
	/**
	 * Retorna el valor trm.
	 * 
	 * @return trm.
	 */
	public String getTrm(){
		return trm;
	}
	
	/**
	 * Método encargado de actualizar el atributo curCode.
	 * @param curCode nuevo valor para curCode.
	 */
	public void setCurCodeTrm(String curCodeTrm){
		this.curCodeTrm = curCodeTrm;
	}
	
	/**
	 * Retorna el valor curCodeTrm.
	 * 
	 * @return curCodeTrm.
	 */
	public String getCurCodeTrm(){
		return curCodeTrm;
	}
/**
	 * Retorna el segundo nombre del comprador que generó la transacción.
	 * 
	 * @return Segundo Nombre del comprador.
	 */
	public String getMiddleNameBuyer(){
		return middleNameBuyer;
	}

	/**
	 * Establece el segundo nombre del comprador que generó la transacción.
	 * 
	 * @param middleNameBuyer Segundo Nombre del comprador.
	 */
	public void setMiddleNameBuyer(String middleNameBuyer){
		this.middleNameBuyer = middleNameBuyer;
	}
	
	/**
	 * Retorna el primer apellido del comprador que generó la transacción.
	 * 
	 * @return Primer Apellido del comprador.
	 */
	public String getLastNameBuyer(){
		return lastNameBuyer;
	}

	/**
	 * Establece el primer apellido del comprador que generó la transacción.
	 * 
	 * @param lastNameBuyer Primer Apellido del comprador.
	 */
	public void setLastNameBuyer(String lastNameBuyer){
		this.lastNameBuyer = lastNameBuyer;
	}
	
	/**
	 * Retorna el segundo apellido del comprador que generó la transacción.
	 * 
	 * @return Segundo Apellido del comprador.
	 */
	public String getSecondLastNameBuyer(){
		return secondLastNameBuyer;
	}

	/**
	 * Establece el segundo apellido del comprador que generó la transacción.
	 * 
	 * @param secondLastNameBuyer Segundo Apellido del comprador.
	 */
	public void setSecondLastNameBuyer(String secondLastNameBuyer){
		this.secondLastNameBuyer = secondLastNameBuyer;
	}
	
	/**
	 * Retorna el segundo nombre del pagador que generó la transacción.
	 * 
	 * @return Segundo Nombre del pag.
	 */
	public String getMiddleNamePayer(){
		return middleNamePayer;
	}

	/**
	 * Establece el segundo nombre del pagador que generó la transacción.
	 * 
	 * @param middleNamePayer Segundo Nombre del pagador.
	 */
	public void setMiddleNamePayer(String middleNamePayer){
		this.middleNamePayer = middleNamePayer;
	}
	
	/**
	 * Retorna el primer apellido del pagador que generó la transacción.
	 * 
	 * @return Primer Apellido del pagador.
	 */
	public String getLastNamePayer(){
		return lastNamePayer;
	}

	/**
	 * Establece el primer apellido del pagador que generó la transacción.
	 * 
	 * @param lastNamePayer Primer Apellido del pagador.
	 */
	public void setLastNamePayer(String lastNamePayer){
		this.lastNamePayer = lastNamePayer;
	}
	
	/**
	 * Retorna el segundo apellido del pagador que generó la transacción.
	 * 
	 * @return Segundo Apellido del pagador.
	 */
	public String getSecondLastNamePayer(){
		return secondLastNamePayer;
	}

	/**
	 * Establece el segundo apellido del pagador que generó la transacción.
	 * 
	 * @param secondLastNamePager Segundo Apellido del pagador.
	 */
	public void setSecondLastNamePayer(String secondLastNamePayer){
		this.secondLastNamePayer = secondLastNamePayer;
	}

	/**
	 * @return the logoURL
	 */
	public String getLogoURL() {
		return logoURL;
	}

	/**
	 * @param logoURL the logoURL to set
	 */
	public void setLogoURL(String logoURL) {
		this.logoURL = logoURL;
	}

	/**
	 * @return the template
	 */
	public String getTemplate() {
		return template;
	}

	/**
	 * @param template the template to set
	 */
	public void setTemplate(String template) {
		this.template = template;
	}

	/**
	 * @return the theme
	 */
	public String getTheme() {
		return theme;
	}

	/**
	 * @param theme the theme to set
	 */
	public void setTheme(String theme) {
		this.theme = theme;
	}
	
	/**
	 * @return the idTypeDoc
	 */
	public String getIdTypeDoc() {
		return idTypeDoc;
	}

	/**
	 * @param idTypeDoc the idTypeDoc to set
	 */
	public void setIdTypeDoc(String idTypeDoc) {
		this.idTypeDoc = idTypeDoc;
	}

	/**
	 * @return the numDoc
	 */
	public String getNumDoc() {
		return numDoc;
	}

	/**
	 * @param numDoc the numDoc to set
	 */
	public void setNumDoc(String numDoc) {
		this.numDoc = numDoc;
	}
	
	
	/**
	 * @return the tokenized
	 */
	public String getTokenized() {
		return tokenized;
	}
	

	/**
	 * @param tokenized to set
	 */
	public void setTokenized(String tokenized) {
		this.tokenized = tokenized;
	}

	/**
	 * @return the devicePrint
	 */
	public String getDevicePrint() {
		return devicePrint;
	}

	/**
	 * @param devicePrint the devicePrint to set
	 */
	public void setDevicePrint(String devicePrint) {
		this.devicePrint = devicePrint;
	}

	/**
	 * @return the deviceTokenCookie
	 */
	public String getDeviceTokenCookie() {
		return deviceTokenCookie;
	}

	/**
	 * @param deviceTokenCookie the deviceTokenCookie to set
	 */
	public void setDeviceTokenCookie(String deviceTokenCookie) {
		this.deviceTokenCookie = deviceTokenCookie;
	}

	public String getHttpAccept() {
		return httpAccept;
	}

	public void setHttpAccept(String httpAccept) {
		this.httpAccept = httpAccept;
	}

	public String getHttpAcceptLanguage() {
		return httpAcceptLanguage;
	}

	public void setHttpAcceptLanguage(String httpAcceptLanguage) {
		this.httpAcceptLanguage = httpAcceptLanguage;
	}

	public String getHttpReferrer() {
		return httpReferrer;
	}

	public void setHttpReferrer(String httpReferrer) {
		this.httpReferrer = httpReferrer;
	}

	public String getUserAgent() {
		return userAgent;
	}

	public void setUserAgent(String userAgent) {
		this.userAgent = userAgent;
	}
	
	public Long getRqUID() {
		return rqUID;
	}

	public void setRqUID(Long rqUID) {
		this.rqUID = rqUID;
	}

	/** INICIO C01 */
	public String getReturnURL() {
		return returnURL;
	}

	public void setReturnURL(String returnURL) {
		this.returnURL = returnURL;
	}
	/** FIN C01 */

	public String getTermsNConditions() {
		return termsNConditions;
	}

	public void setTermsNConditions(String termsNConditions) {
		this.termsNConditions = termsNConditions;
	}
	
}