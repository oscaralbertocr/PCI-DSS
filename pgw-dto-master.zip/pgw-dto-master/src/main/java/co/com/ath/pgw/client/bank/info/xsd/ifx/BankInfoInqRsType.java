
package co.com.ath.pgw.client.bank.info.xsd.ifx;

import java.util.ArrayList;
import java.util.List;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;

import co.com.ath.pgw.core.logging.util.XMLUtil;
import co.com.ath.pgw.in.model.SvcRsType;


/**
 * <p>Clase Java para BankInfoInqRs_Type complex type.
 * 
 * <p>El siguiente fragmento de esquema especifica el contenido que se espera que haya en esta clase.
 * 
 * <pre>
 * &lt;complexType name="BankInfoInqRs_Type">
 *   &lt;complexContent>
 *     &lt;extension base="{urn://grupoaval.com/xsd/ifx/}SvcRs_Type">
 *       &lt;sequence>
 *         &lt;element name="BillPmtInfo" type="{urn://grupoaval.com/xsd/ifx/}BillPmtInfo_Type" maxOccurs="unbounded"/>
 *       &lt;/sequence>
 *     &lt;/extension>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "BankInfoInqRs_Type", propOrder = {
    "billPmtInfo"
})
public class BankInfoInqRsType
    extends SvcRsType
{

    @XmlElement(name = "BillPmtInfo", namespace = "", required = true)
    protected List<BillPmtInfoType> billPmtInfo;

    /**
     * Gets the value of the billPmtInfo property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the billPmtInfo property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getBillPmtInfo().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link BillPmtInfoType }
     * 
     * 
     */
    public List<BillPmtInfoType> getBillPmtInfo() {
        if (billPmtInfo == null) {
            billPmtInfo = new ArrayList<BillPmtInfoType>();
        }
        return this.billPmtInfo;
    }
    
    public String toString() {
    	XMLUtil<BankInfoInqRsType> requestParser = 
    							new XMLUtil<BankInfoInqRsType>();
		return requestParser.convertObjectToXml(this);
    }

}
