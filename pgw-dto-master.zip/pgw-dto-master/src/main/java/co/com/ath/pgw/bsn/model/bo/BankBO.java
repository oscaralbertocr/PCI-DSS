/*
 * BankVO
 *  
 * GSI - Integración
 * Creado el: 28/08/2014
 *
 * Copyright (c) A Toda Hora S.A. Todos los derechos reservados
 * 
 * Este software es confidencial y es propietario de ATH, queda prohibido
 * su uso, reproducción y copia de manera parcial o permanente salvo autorización
 * expresa de A Toda Hora S.A o de quién represente sus derechos.
 */
package co.com.ath.pgw.bsn.model.bo;

/**
 * Clase que representa un Banco del sistema financiero colombiano, esta entidad
 * pertenece al modelo de negocio.
 *
 * @author proveedor_japiza
 * @version 1.0 29 Ago 2014
 * @since 1.0
 */
public class BankBO{

	/**
	 * Identificador único del Banco en el Core de la Pararela de Pagos
	 */
	private Long id;

	/**
	 * Nombre del banco
	 */
	private String name;
	
	/**
	 * Indica si el banco pertenece al grupo aval
	 */
	private boolean avalEntity;
	
	/**
	 * Código asignado por el Banco de la República
	 */
	private String banRepublicaCode;

	/**
	 * Código asignado por ACH al banco.
	 */
	private String achCode;
	
	/**
	 * Código asignado al banco en la red AVAL
	 */
	private String avalCode;
	
	/**
	 * Código de compensación asignado al banco.
	 */
	private String compensationCode;
	
	/**
	 * 
	 */
	private String branchId;
	
	/**
	 * Constructor por defecto de un Banco
	 */
	public BankBO(){
		super();
	}

    /**
     * Constuctor del banco con id
     * @param id 
     */
    public BankBO(Long id) {
        this.id = id;
    }
    
    /**
     * Constuctor para el banco con código AVAL
     * @param avalCode 
     */
    public BankBO(String avalCode) {
        this.avalCode = avalCode;
    }
	
	/**
	 * Retorna el identificador único del Banco en el Core de la Pararela de
	 * Pagos
	 * 
	 * @return Identificador del Banco
	 */
	public Long getId() {
		return id;
	}

	/**
	 * Establece el identificador único del Banco en el Core de la Pararela de
	 * Pagos
	 * 
	 * @param id Identificador del Banco
	 */
	public void setId(Long id) {
		this.id = id;
	}

	/**
	 * Retorna el nombre del banco.
	 * @return Nombre del banco
	 */
	public String getName() {
		return name;
	}

	/**
	 * Establece el nombre del banco.
	 * @param name Nombre del banco
	 */
	public void setName(String name) {
		this.name = name;
	}

	/**
	 * Indica si el banco pertence al Grupo AVAL
	 * @return <strong>true</strong> si el banco pertenece al grupo AVAL, 
	 *   <strong>false</strong> de lo contrario
	 */
	public boolean getAvalEntity() {
		return avalEntity;
	}

	/**
	 * Establece la pertenencia del banco al Grupo AVAL
	 * @param avalEntity Valor de pertenencia al Grupo AVAL
	 */
	public void setAvalEntity(boolean avalEntity) {
		this.avalEntity = avalEntity;
	}

	/**
	 * Retorna el código que el Banco de la República ha asignado al banco 
	 * actual.
	 * 
	 * @return Código asignado por el Banco de la República
	 */
	public String getBanRepublicaCode() {
		return banRepublicaCode;
	}

	/**
	 * Establece el código que ha asignado el Banco de la República.
	 * @param banRepublicaCode Nuevo código BanRepública
	 */
	public void setBanRepublicaCode(String banRepublicaCode) {
		this.banRepublicaCode = banRepublicaCode;
	}

	/**
	 * Retorna el código asignado por ACH al banco.
	 * @return Código asignado por ACH al banco.
	 */
	public String getAchCode() {
		return achCode;
	}

	/**
	 * Establece el código ACH del Banco
	 * @param achCode Nuevo código ACH
	 */
	public void setAchCode(String achCode) {
		this.achCode = achCode;
	}

	/**
	 * Retorna código asignado al banco en la red AVAL
	 * @return Código AVAL
	 */
	public String getAvalCode() {
		return avalCode;
	}

	/**
	 * Establece el código asignado al banco en la red AVAL
	 * @param avalCode Nuevo código AVAL
	 */
	public void setAvalCode(String avalCode) {
		this.avalCode = avalCode;
	}

	/**
	 * Retorna el código de compensación asignado al banco.
	 * @return código de compensación.
	 */
	public String getCompensationCode() {
		return compensationCode;
	}

	/**
	 * Establece el código de compensación asignado al banco.
	 * @param compensationCode Código de compensación
	 */
	public void setCompensationCode(String compensationCode) {
		this.compensationCode = compensationCode;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime
				* result
				+ ((banRepublicaCode == null) ? 0 : banRepublicaCode.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		BankBO other = (BankBO) obj;
		if (banRepublicaCode == null) {
			if (other.banRepublicaCode != null)
				return false;
		} else if (!banRepublicaCode.equals(other.banRepublicaCode))
			return false;
		return true;
	}

	@Override
	public String toString() {
		return "Bank [id=" + id + ", name=" + name + ", banRepublicaCode="
				+ banRepublicaCode + " ]";
	}

	public String getBranchId() {
		return branchId;
	}

	public void setBranchId(String branchId) {
		this.branchId = branchId;
	}

}