
package co.com.ath.pgw.rest.dto;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonProperty;

public class SecretList implements Serializable
{

	@JsonProperty("SecretId")
    private String secretId;
	
	@JsonProperty("Secret")
    private String secret;
	
    private final static long serialVersionUID = 1029438724602038862L;

    public String getSecretId() {
        return secretId;
    }

    public void setSecretId(String secretId) {
        this.secretId = secretId;
    }

    public String getSecret() {
        return secret;
    }

    public void setSecret(String secret) {
        this.secret = secret;
    }

}
