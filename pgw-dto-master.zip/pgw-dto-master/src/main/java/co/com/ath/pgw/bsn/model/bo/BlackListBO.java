/*
 * BlackListVO
 *  
 * GSI - Integración
 * Creado el: 23/06/2015
 *
 * Copyright (c) A Toda Hora S.A. Todos los derechos reservados
 * 
 * Este software es confidencial y es propietario de ATH, queda prohibido
 * su uso, reproducción y copia de manera parcial o permanente salvo autorización
 * expresa de A Toda Hora S.A o de quién represente sus derechos.
 */
package co.com.ath.pgw.bsn.model.bo;


/**
 * Representa una lista negra de usuarios. Esta es una 
 * entidad del modelo de negocio.
 * 
 * @author proveedor_edrobles
 * @version 1.0 23 Jun 2015
 * @since 1.0
 *
 */
public class BlackListBO {
	
	/**
	 * identificador de lista negra
	 */
	private Long id;
	
	/**
	 * Tipo documento
	 */
	private String documentType;
	 
	/**
	 * Número documento
	 */
	private String documentId;
	
	/**
	 * Nombre
	 */
	private String name;
	
	/**
	 * Descripción
	 */
	private String description;
	
	/**
	 * Estado
	 */
	private short status;

	/**
	 * Construye un tema sin especificar sus parámetros.
	 */
	public BlackListBO(){
		super();
	}
	
	/**
	 * Retorna el identificador único la lista negra.
	 * 
	 * @return id.
	 */
	public Long getId() {
		return id;
	}

	/**
	 * Establece el identificador único de la lista negra.
	 * 
	 * @param id.
	 */
	public void setId(Long id) {
		this.id = id;
	}
	
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + (int) (id ^ (id >>> 32));
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		BlackListBO other = (BlackListBO) obj;
		if (id != other.id)
			return false;
		return true;
	}

	@Override
	public String toString() {
		return "BlackListVO [id=" + id + ", name=" + name + "]";
	}

	/**
	 * Retorna el documentType de la lista negra.
	 * 
	 * @return documentType
	 */
	public String getDocumentType() {
		return documentType;
	}

	/**
	 *  Establece el documentType de la lista negra.
	 *  
	 * @param documentType
	 */
	public void setDocumentType(String documentType) {
		this.documentType = documentType;
	}

	/**
	 * Retorna el documentId de la lista negra.
	 * 
	 * @return documentId
	 */
	public String getDocumentId() {
		return documentId;
	}

	/**
	 *  Establece el documentId de la lista negra.
	 *  
	 * @param documentId
	 */
	public void setDocumentId(String documentId) {
		this.documentId = documentId;
	}

	/**
	 * Retorna el name de la lista negra.
	 * 
	 * @return name
	 */
	public String getName() {
		return name;
	}

	/**
	 *  Establece el name de la lista negra.
	 *  
	 * @param name
	 */
	public void setName(String name) {
		this.name = name;
	}

	/**
	 * Retorna description de la lista negra.
	 * 
	 * @return description
	 */
	public String getDescription() {
		return description;
	}

	/**
	 *  Establece description de la lista negra.
	 *  
	 * @param description
	 */
	public void setDescription(String description) {
		this.description = description;
	}

	/**
	 * Retorna status de la lista negra.
	 * 
	 * @return status
	 */
	public short getStatus() {
		return status;
	}

	/**
	 *  Establece status de la lista negra.
	 *  
	 * @param status de la lista negra
	 */
	public void setStatus(short status) {
		this.status = status;
	}
	
}