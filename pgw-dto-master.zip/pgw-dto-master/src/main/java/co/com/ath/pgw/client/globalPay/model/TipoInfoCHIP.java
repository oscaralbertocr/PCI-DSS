
package co.com.ath.pgw.client.globalPay.model;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Clase Java para TipoInfoCHIP complex type.
 * 
 * <p>El siguiente fragmento de esquema especifica el contenido que se espera que haya en esta clase.
 * 
 * <pre>
 * &lt;complexType name="TipoInfoCHIP"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="codSeguridadEMV" type="{http://www.w3.org/2001/XMLSchema}string"/&gt;
 *         &lt;element name="dataEMV" type="{http://www.w3.org/2001/XMLSchema}string"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "TipoInfoCHIP", propOrder = {
    "codSeguridadEMV",
    "dataEMV"
})
public class TipoInfoCHIP {

    @XmlElement(required = true)
    protected String codSeguridadEMV;
    @XmlElement(required = true)
    protected String dataEMV;

    /**
     * Obtiene el valor de la propiedad codSeguridadEMV.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCodSeguridadEMV() {
        return codSeguridadEMV;
    }

    /**
     * Define el valor de la propiedad codSeguridadEMV.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCodSeguridadEMV(String value) {
        this.codSeguridadEMV = value;
    }

    /**
     * Obtiene el valor de la propiedad dataEMV.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDataEMV() {
        return dataEMV;
    }

    /**
     * Define el valor de la propiedad dataEMV.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDataEMV(String value) {
        this.dataEMV = value;
    }

}
