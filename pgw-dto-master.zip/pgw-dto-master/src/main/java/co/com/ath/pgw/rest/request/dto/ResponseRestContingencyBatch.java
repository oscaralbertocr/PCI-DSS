package co.com.ath.pgw.rest.request.dto;

import com.fasterxml.jackson.annotation.JsonProperty;

public class ResponseRestContingencyBatch {

	
	@JsonProperty("Response")
	private String response;

	public String getResponse() {
		return response;
	}

	public void setResponse(String file) {
		this.response = file;
	}

	@Override
	public String toString() {
		return "RequestPutPaymentFile [file=" + response + "]";
	}

	
	
}
