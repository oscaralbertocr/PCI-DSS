package co.com.ath.ws.rs.objects;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonProperty;

public class InvoiceReference implements Serializable{

	private static final long serialVersionUID = 1L;
	
	@JsonProperty("pmtCodNIE")
	private String pmtCodNIE;

	public String getPmtCodNIE() {
		return pmtCodNIE;
	}

	public void setPmtCodNIE(String pmtCodNIE) {
		this.pmtCodNIE = pmtCodNIE;
	}

	
}
