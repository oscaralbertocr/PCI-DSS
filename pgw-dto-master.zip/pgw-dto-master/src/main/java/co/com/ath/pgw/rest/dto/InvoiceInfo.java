
package co.com.ath.pgw.rest.dto;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonProperty;

import co.com.ath.pgw.rest.util.DTOConstants;

public class InvoiceInfo implements Serializable {
	@JsonProperty("InvoiceType")
	private String invoiceType;
	
	@JsonProperty("InvoiceNum")
	private String invoiceNum;
	
	@JsonProperty("Desc")
	private String desc;
	
	@JsonProperty("NIE")
	private List<String> nie;
	
	@JsonFormat(pattern="yyyy-MM-dd HH:mm:ss", timezone = DTOConstants.TIMEZONE)
	@JsonProperty("EffDt")
	private Date effDt;
	
	@JsonProperty("InvoiceSender")
	private InvoiceSender invoiceSender;
	
	@JsonProperty("InvoiceVouchNum")
	private String invoiceVouchNum;

	@JsonProperty("TotalCurAmt")
	private TotalCurAmt totalCurAmt;
	
	@JsonProperty("RefInfo")
	private List<RefInfo> refInfo = null;
	
	private final static long serialVersionUID = -7122502907082175299L;

	public String getInvoiceType() {
		return invoiceType;
	}

	public void setInvoiceType(String invoiceType) {
		this.invoiceType = invoiceType;
	}

	public List<String> getNie() {
		if (nie == null) {
			nie = new ArrayList<String>();
		}
		return nie;
	}

	public void setNie(List<String> nie) {
		this.nie = nie;
	}

	public String getDesc() {
		return desc;
	}

	public void setDesc(String desc) {
		this.desc = desc;
	}

	public Date getEffDt() {
		return effDt;
	}

	public void setEffDt(Date effDt) {
		this.effDt = effDt;
	}

	public InvoiceSender getInvoiceSender() {
		return invoiceSender;
	}

	public void setInvoiceSender(InvoiceSender invoiceSender) {
		this.invoiceSender = invoiceSender;
	}

	public String getInvoiceVouchNum() {
		return invoiceVouchNum;
	}

	public void setInvoiceVouchNum(String invoiceVouchNum) {
		this.invoiceVouchNum = invoiceVouchNum;
	}

	public String getInvoiceNum() {
		return invoiceNum;
	}

	public void setInvoiceNum(String invoiceNum) {
		this.invoiceNum = invoiceNum;
	}

	public TotalCurAmt getTotalCurAmt() {
		return totalCurAmt;
	}

	public void setTotalCurAmt(TotalCurAmt totalCurAmt) {
		this.totalCurAmt = totalCurAmt;
	}

	public List<RefInfo> getRefInfo() {
		if (refInfo == null) {
			refInfo = new ArrayList<RefInfo>();
		}
		return refInfo;
	}

	public void setRefInfo(List<RefInfo> refInfo) {
		this.refInfo = refInfo;
	}

}
