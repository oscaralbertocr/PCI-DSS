package co.com.ath.ws.rs.objects;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonProperty;

public class CustName implements Serializable {

	private static final long serialVersionUID = 1L;
	
	@JsonProperty("lastName")
	private String lastName;
	
	@JsonProperty("firstName")
    private String firstName;
    
	@JsonProperty("middleName")
    private String middleName;
      
	@JsonProperty("secondLastName")
    private String secondLastName;

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getMiddleName() {
		return middleName;
	}

	public void setMiddleName(String middleName) {
		this.middleName = middleName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public String getSecondLastName() {
		return secondLastName;
	}

	public void setSecondLastName(String secondLastName) {
		this.secondLastName = secondLastName;
	}
	
	

}
