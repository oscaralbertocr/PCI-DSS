
package co.com.ath.pgw.client.rbm.model;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlSchemaType;
import javax.xml.bind.annotation.XmlType;

/**
 * <p>
 * Clase Java para TipoInfoPuntoInteraccion complex type.
 * 
 * <p>
 * El siguiente fragmento de esquema especifica el contenido que se espera que
 * haya en esta clase.
 * 
 * <pre>
 * &lt;complexType name="TipoInfoPuntoInteraccion"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="tipoTerminal" type="{http://www.rbm.com.co/esb/comercio/}TipoTipoTerminal"/&gt;
 *         &lt;element name="idTerminal" type="{http://www.rbm.com.co/esb/comercio/}TipoIdTerminal"/&gt;
 *         &lt;element name="idAdquiriente" type="{http://www.rbm.com.co/esb/comercio/}TipoIdAdquiriente"/&gt;
 *         &lt;element name="idTransaccionTerminal" type="{http://www.rbm.com.co/esb/comercio/}TipoIdTransaccionTerminal"/&gt;
 *         &lt;element name="modoCapturaPAN" type="{http://www.rbm.com.co/esb/comercio/}TipoModoCapturaPAN"/&gt;
 *         &lt;element name="capacidadPIN" type="{http://www.rbm.com.co/esb/comercio/}TipoCapacidadPIN"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "infoPuntoInteraccion", propOrder = { "tipoTerminal", "idTerminal", "idAdquiriente",
		"idTransaccionTerminal", "modoCapturaPAN", "capacidadPIN" }, namespace= "http://www.rbm.com.co/esb/comercio/")
public class TipoInfoPuntoInteraccion {

	@XmlElement(name="tipoTerminal", namespace="http://www.rbm.com.co/esb/comercio/")
	protected String tipoTerminal;
	@XmlElement(name="idTerminal", namespace="http://www.rbm.com.co/esb/comercio/")
	protected String idTerminal;
	@XmlElement(name="idAdquiriente", namespace= "http://www.rbm.com.co/esb/comercio/" )
	protected String idAdquiriente;
	@XmlElement(name="idTransaccionTerminal" , namespace="http://www.rbm.com.co/esb/comercio/")
	protected long idTransaccionTerminal;
	@XmlElement(name="modoCapturaPAN", namespace= "http://www.rbm.com.co/esb/comercio/")
	@XmlSchemaType(name = "string")
	protected TipoModoCapturaPAN modoCapturaPAN;
	@XmlElement(name="capacidadPIN", namespace= "http://www.rbm.com.co/esb/comercio/")
	@XmlSchemaType(name = "string")
	protected TipoCapacidadPIN capacidadPIN;

	/**
	 * Obtiene el valor de la propiedad tipoTerminal.
	 * 
	 * @return possible object is {@link String }
	 * 
	 */
	public String getTipoTerminal() {
		return tipoTerminal;
	}

	/**
	 * Define el valor de la propiedad tipoTerminal.
	 * 
	 * @param value allowed object is {@link String }
	 * 
	 */
	public void setTipoTerminal(String value) {
		this.tipoTerminal = value;
	}

	/**
	 * Obtiene el valor de la propiedad idTerminal.
	 * 
	 * @return possible object is {@link String }
	 * 
	 */
	public String getIdTerminal() {
		return idTerminal;
	}

	/**
	 * Define el valor de la propiedad idTerminal.
	 * 
	 * @param value allowed object is {@link String }
	 * 
	 */
	public void setIdTerminal(String value) {
		this.idTerminal = value;
	}

	/**
	 * Obtiene el valor de la propiedad idAdquiriente.
	 * 
	 * @return possible object is {@link String }
	 * 
	 */
	public String getIdAdquiriente() {
		return idAdquiriente;
	}

	/**
	 * Define el valor de la propiedad idAdquiriente.
	 * 
	 * @param value allowed object is {@link String }
	 * 
	 */
	public void setIdAdquiriente(String value) {
		this.idAdquiriente = value;
	}

	/**
	 * Obtiene el valor de la propiedad idTransaccionTerminal.
	 * 
	 */
	public long getIdTransaccionTerminal() {
		return idTransaccionTerminal;
	}

	/**
	 * Define el valor de la propiedad idTransaccionTerminal.
	 * 
	 */
	public void setIdTransaccionTerminal(long value) {
		this.idTransaccionTerminal = value;
	}

	/**
	 * Obtiene el valor de la propiedad modoCapturaPAN.
	 * 
	 * @return possible object is {@link TipoModoCapturaPAN }
	 * 
	 */
	public TipoModoCapturaPAN getModoCapturaPAN() {
		return modoCapturaPAN;
	}

	/**
	 * Define el valor de la propiedad modoCapturaPAN.
	 * 
	 * @param value allowed object is {@link TipoModoCapturaPAN }
	 * 
	 */
	public void setModoCapturaPAN(TipoModoCapturaPAN value) {
		this.modoCapturaPAN = value;
	}

	/**
	 * Obtiene el valor de la propiedad capacidadPIN.
	 * 
	 * @return possible object is {@link TipoCapacidadPIN }
	 * 
	 */
	public TipoCapacidadPIN getCapacidadPIN() {
		return capacidadPIN;
	}

	/**
	 * Define el valor de la propiedad capacidadPIN.
	 * 
	 * @param value allowed object is {@link TipoCapacidadPIN }
	 * 
	 */
	public void setCapacidadPIN(TipoCapacidadPIN value) {
		this.capacidadPIN = value;
	}

}
