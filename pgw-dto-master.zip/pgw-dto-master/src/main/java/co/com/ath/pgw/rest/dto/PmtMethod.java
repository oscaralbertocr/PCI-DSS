
package co.com.ath.pgw.rest.dto;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonProperty;

public class PmtMethod implements Serializable {

	@JsonProperty("PmtMethodId")
	private String pmtMethodId;
	@JsonProperty("PmtMethodDesc")
	private String pmtMethodDesc;
	private static final long serialVersionUID = -8235589648438095416L;

	public String getPmtMethodId() {
		return pmtMethodId;
	}

	public void setPmtMethodId(String pmtMethodId) {
		this.pmtMethodId = pmtMethodId;
	}

	public String getPmtMethodDesc() {
		return pmtMethodDesc;
	}

	public void setPmtMethodDesc(String pmtMethodDesc) {
		this.pmtMethodDesc = pmtMethodDesc;
	}

}
