
package co.com.ath.pgw.rest.dto;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonProperty;

import co.com.ath.pgw.rest.util.DTOConstants;

public class PmtStatus implements Serializable
{
	@JsonProperty("PmtAuthId")
    private String pmtAuthId;
	
	@JsonProperty("PmtType")
    private String pmtType;
	
	@JsonProperty("PmtMethod")
    private String pmtMethod;
	
	@JsonProperty("ApprovalId")
    private String approvalId ;
	
	@JsonProperty("PmtInfo") 
    private List<PmtInfo> pmtInfo;
	
	@JsonProperty("StatusCode")
    private String statusCode;
	
	@JsonProperty("StatusDesc")
    private String statusDesc;
	
	@JsonFormat(pattern="yyyy-MM-dd HH:mm:ss", timezone = DTOConstants.TIMEZONE)
	@JsonProperty("EffDt")
    private Date effDt;
	
	@JsonFormat(pattern="yyyy-MM-dd HH:mm:ss", timezone = DTOConstants.TIMEZONE)
	@JsonProperty("NextDt")
    private Date nextDt;
	
	@JsonFormat(pattern="yyyy-MM-dd HH:mm:ss", timezone = DTOConstants.TIMEZONE)
	@JsonProperty("CompensationDt")
	private Date compensationDt ;
	
    private final static long serialVersionUID = -8046845354313078572L;

    public String getPmtAuthId() {
        return pmtAuthId;
    }

    public String getApprovalId() {
		return approvalId;
	}

	public void setApprovalId(String approvalId) {
		this.approvalId = approvalId;
	}

	public Date getCompensationDt() {
		return compensationDt;
	}

	public void setCompensationDt(Date compensationDt) {
		this.compensationDt = compensationDt;
	}

	public void setPmtAuthId(String pmtAuthId) {
        this.pmtAuthId = pmtAuthId;
    }

    public String getPmtType() {
		return pmtType;
	}

	public void setPmtType(String pmtType) {
		this.pmtType = pmtType;
	}

	public String getPmtMethod() {
        return pmtMethod;
    }

    public void setPmtMethod(String pmtMethod) {
        this.pmtMethod = pmtMethod;
    }

	public List<PmtInfo> getPmtInfo() {
		if(pmtInfo == null) {
			pmtInfo = new ArrayList<PmtInfo>();
		}
		return pmtInfo;
	}

	public void setPmtInfo(List<PmtInfo> pmtInfo) {
		this.pmtInfo = pmtInfo;
	}

	public String getStatusCode() {
		return statusCode;
	}

	public void setStatusCode(String statusCode) {
		this.statusCode = statusCode;
	}

	public String getStatusDesc() {
		return statusDesc;
	}

	public void setStatusDesc(String statusDesc) {
		this.statusDesc = statusDesc;
	}

	public Date getEffDt() {
		return effDt;
	}

	public void setEffDt(Date effDt) {
		this.effDt = effDt;
	}

	public Date getNextDt() {
		return nextDt;
	}

	public void setNextDt(Date nextDt) {
		this.nextDt = nextDt;
	}

}
