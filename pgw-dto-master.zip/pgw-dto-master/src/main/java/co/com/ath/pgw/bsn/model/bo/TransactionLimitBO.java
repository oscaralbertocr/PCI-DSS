/*
 * CommerceVO
 *  
 * GSI - Integración
 * Creado el: 29/08/2014
 *
 * Copyright (c) A Toda Hora S.A. Todos los derechos reservados
 * 
 * Este software es confidencial y es propietario de ATH, queda prohibido
 * su uso, reproducción y copia de manera parcial o permanente salvo autorización
 * expresa de A Toda Hora S.A o de quién represente sus derechos.
 */
package co.com.ath.pgw.bsn.model.bo;

import java.math.BigDecimal;
import java.util.Date;




/**
 * Entidad de negocio que representa el limite de las transacciones de un medio de pago
 * que son manejados por el Core Pasarela.
 * 
 * @author Mauricio Tascon
 * @Fecha 23/08/207
 * @version 1.0
 * @since 1.0
 */
public class TransactionLimitBO {	
	
	
	
	/**
	 * Tipo de documento del cliente que realiza la transacción.
	 * 
	 * En caso de que el comercio no requiera enviar esta información se debe enviar por defecto el valor:
	 * •	GUEST – Invitado.
	 */
	private String payerDocType;
	
	
	/**
	 * Número de identificación del cliente.
	 * 
	 * En caso de que el comercio no requiera enviar esta información se debe
	 * enviar por defecto el valor cero (0).
	 */
	private String payerDocId;
	
	
	/** Login del usuario solicitante. **/
	private String custLoginId;
	

	/**
	 * Tipo tope
	 */
	private String  lmtType;
	
	/**
	 * Descripción del tipo de tope
	 * 
	 */
	private String lmtTypeDesc;
	
	/**
	 * Información del monto.
	 */
	private String curAmt;
	
	/**
	 * Tope Maximo.Valor moneda como cantidad monto mínimo de pago permitido.
	 */
	private BigDecimal topAmt;

	/**
	 * Tope Mínimo: Valor moneda como cantidad monto máximo de pago  permitido.
	 */
	private BigDecimal LstAmt;
	
	/**
	 * Tipo de transacción del tope.
	 */
	private String operationLmtType;
	
	/**
	 * Tipo de servicio o comercio para el que aplica el tope 
	 * (Servicios Públicos, Obligaciones Bancarias, TC).
	 */
	private String typeFieldLmt;
	
	/**
	 * Indica si el tope es permanente.
	 */
	private String termLmt;
	 
	 
	 /**
	 * Tipo de medio de pago para el que aplica el tope..
	 */
	private String pmtWayType;
	
	
	/**
	 * Fecha de inicio aplicación para el tope
	 * 
	 * Obligatorio por negocio siempre y cuando la validación del tope no sea permanente.
	 * 
     *Si el tope es permanente, este campo no se debe enviar.
	 */
	private Date effDt;
	
	
	/**
	 * Fecha de fin aplicación para el tope.
	 * 
	 * Obligatorio por negocio siempre y cuando la validación del tope no sea permanente.
	 * 
	 * Si el tope es permanente, este campo no se debe enviar.
	 */
	private Date endDt;
	
	
	/**
	 * Cantidad máxima de transacciones que puede realizar un determinado convenio.
	 */
	private String topTrnLmt;
	
	
	/**
	 * Periodo Limite programado (Asociado a programación de topes para transacciones).
	 */
	private String trnLmtCode;
	
	
	/**
	 * Periodo de tiempo asociado a la cantidad de transacciones permitidas por convenio.
	 * Diario, Mensual, Semanal, Anual
	 */
	private String trnLmtDesc;
	 
	
	/**
	 *  Tipo de moneda:	COP – Pesos Colombianos.
	 */
	private String curCode;
	
	
	


	public String getPayerDocType() {
		return payerDocType;
	}


	public void setPayerDocType(String payerDocType) {
		this.payerDocType = payerDocType;
	}


	public String getPayerDocId() {
		return payerDocId;
	}


	public void setPayerDocId(String payerDocId) {
		this.payerDocId = payerDocId;
	}


	public String getCustLoginId() {
		return custLoginId;
	}


	public void setCustLoginId(String custLoginId) {
		this.custLoginId = custLoginId;
	}


	public String getLmtType() {
		return lmtType;
	}


	public void setLmtType(String lmtType) {
		this.lmtType = lmtType;
	}


	public String getLmtTypeDesc() {
		return lmtTypeDesc;
	}


	public void setLmtTypeDesc(String lmtTypeDesc) {
		this.lmtTypeDesc = lmtTypeDesc;
	}


	public String getCurAmt() {
		return curAmt;
	}


	public void setCurAmt(String curAmt) {
		this.curAmt = curAmt;
	}


	public BigDecimal getTopAmt() {
		return topAmt;
	}


	public void setTopAmt(BigDecimal topAmt) {
		this.topAmt = topAmt;
	}


	public BigDecimal getLstAmt() {
		return LstAmt;
	}


	public void setLstAmt(BigDecimal lstAmt) {
		LstAmt = lstAmt;
	}


	public String getOperationLmtType() {
		return operationLmtType;
	}


	public void setOperationLmtType(String operationLmtType) {
		this.operationLmtType = operationLmtType;
	}


	public String getTypeFieldLmt() {
		return typeFieldLmt;
	}


	public void setTypeFieldLmt(String typeFieldLmt) {
		this.typeFieldLmt = typeFieldLmt;
	}


	public String getTermLmt() {
		return termLmt;
	}


	public void setTermLmt(String termLmt) {
		this.termLmt = termLmt;
	}


	public String getPmtWayType() {
		return pmtWayType;
	}


	public void setPmtWayType(String pmtWayType) {
		this.pmtWayType = pmtWayType;
	}


	public Date getEffDt() {
		return effDt;
	}


	public void setEffDt(Date effDt) {
		this.effDt = effDt;
	}


	public Date getEndDt() {
		return endDt;
	}


	public void setEndDt(Date endDt) {
		this.endDt = endDt;
	}


	public String getTopTrnLmt() {
		return topTrnLmt;
	}


	public void setTopTrnLmt(String topTrnLmt) {
		this.topTrnLmt = topTrnLmt;
	}


	public String getTrnLmtCode() {
		return trnLmtCode;
	}


	public void setTrnLmtCode(String trnLmtCode) {
		this.trnLmtCode = trnLmtCode;
	}


	public String getTrnLmtDesc() {
		return trnLmtDesc;
	}


	public void setTrnLmtDesc(String trnLmtDesc) {
		this.trnLmtDesc = trnLmtDesc;
	}


	public String getCurCode() {
		return curCode;
	}


	public void setCurCode(String curCode) {
		this.curCode = curCode;
	}
	
	
	
	
	

	
}