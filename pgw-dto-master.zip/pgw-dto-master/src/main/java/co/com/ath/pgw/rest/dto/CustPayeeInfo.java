
package co.com.ath.pgw.rest.dto;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonProperty;

public class CustPayeeInfo implements Serializable {

	@JsonProperty("PersonName")
	private PersonName personName;
	@JsonProperty("ContactInfo")
	private ContactInfo contactInfo;
	@JsonProperty("GovIssueIdent")
    private GovIssueIdent govIssueIdent;
	private static final long serialVersionUID = -1416572032986115124L;

	public PersonName getPersonName() {
		return personName;
	}

	public void setPersonName(PersonName personName) {
		this.personName = personName;
	}

	public ContactInfo getContactInfo() {
		return contactInfo;
	}

	public void setContactInfo(ContactInfo contactInfo) {
		this.contactInfo = contactInfo;
	}

	public GovIssueIdent getGovIssueIdent() {
		return govIssueIdent;
	}

	public void setGovIssueIdent(GovIssueIdent govIssueIdent) {
		this.govIssueIdent = govIssueIdent;
	}

}
