
package co.com.ath.pgw.client.bank.info.xsd.ifx;

import java.math.BigDecimal;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;

import co.com.ath.pgw.client.bank.info.CurrencyAmountType;
import co.com.ath.pgw.core.logging.util.XMLUtil;


/**
 * <p>Clase Java para CompositeCurAmt_Type complex type.
 * 
 * <p>El siguiente fragmento de esquema especifica el contenido que se espera que haya en esta clase.
 * 
 * <pre>
 * &lt;complexType name="CompositeCurAmt_Type">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element ref="{urn://grupoaval.com/xsd/ifx/}CompositeCurAmtId" minOccurs="0"/>
 *         &lt;element ref="{urn://grupoaval.com/xsd/ifx/}CompositeCurAmtType"/>
 *         &lt;sequence>
 *           &lt;element ref="{urn://grupoaval.com/xsd/ifx/}CurAmt" minOccurs="0"/>
 *           &lt;element ref="{urn://grupoaval.com/xsd/ifx/}Rate" minOccurs="0"/>
 *         &lt;/sequence>
 *         &lt;element ref="{urn://grupoaval.com/xsd/ifx/}MinCurAmt" minOccurs="0"/>
 *         &lt;element ref="{urn://grupoaval.com/xsd/ifx/}MaxCurAmt" minOccurs="0"/>
 *         &lt;element ref="{urn://grupoaval.com/xsd/ifx/}SpecialHandling" minOccurs="0"/>
 *         &lt;element ref="{urn://grupoaval.com/xsd/ifx/}Memo" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "CompositeCurAmt_Type", propOrder = {
    "compositeCurAmtId",
    "compositeCurAmtType",
    "curAmt",
    "rate",
    "minCurAmt",
    "maxCurAmt",
    "specialHandling",
    "memo"
})
public class CompositeCurAmtType {

    @XmlElement(name = "CompositeCurAmtId")
    protected String compositeCurAmtId;
    @XmlElement(name = "CompositeCurAmtType", required = true)
    protected String compositeCurAmtType;
    @XmlElement(name = "CurAmt")
    protected CurAmtType curAmt;
    @XmlElement(name = "Rate")
    protected BigDecimal rate;
    @XmlElement(name = "MinCurAmt")
    protected CurrencyAmountType minCurAmt;
    @XmlElement(name = "MaxCurAmt")
    protected CurrencyAmountType maxCurAmt;
    @XmlElement(name = "SpecialHandling")
    protected String specialHandling;
    @XmlElement(name = "Memo")
    protected String memo;

    /**
     * Obtiene el valor de la propiedad compositeCurAmtId.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCompositeCurAmtId() {
        return compositeCurAmtId;
    }

    /**
     * Define el valor de la propiedad compositeCurAmtId.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCompositeCurAmtId(String value) {
        this.compositeCurAmtId = value;
    }

    /**
     * Obtiene el valor de la propiedad compositeCurAmtType.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCompositeCurAmtType() {
        return compositeCurAmtType;
    }

    /**
     * Define el valor de la propiedad compositeCurAmtType.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCompositeCurAmtType(String value) {
        this.compositeCurAmtType = value;
    }

    /**
     * Obtiene el valor de la propiedad curAmt.
     * 
     * @return
     *     possible object is
     *     {@link CurAmtType }
     *     
     */
    public CurAmtType getCurAmt() {
        return curAmt;
    }

    /**
     * Define el valor de la propiedad curAmt.
     * 
     * @param value
     *     allowed object is
     *     {@link CurAmtType }
     *     
     */
    public void setCurAmt(CurAmtType value) {
        this.curAmt = value;
    }

    /**
     * Obtiene el valor de la propiedad rate.
     * 
     * @return
     *     possible object is
     *     {@link BigDecimal }
     *     
     */
    public BigDecimal getRate() {
        return rate;
    }

    /**
     * Define el valor de la propiedad rate.
     * 
     * @param value
     *     allowed object is
     *     {@link BigDecimal }
     *     
     */
    public void setRate(BigDecimal value) {
        this.rate = value;
    }

    /**
     * Obtiene el valor de la propiedad minCurAmt.
     * 
     * @return
     *     possible object is
     *     {@link CurrencyAmountType }
     *     
     */
    public CurrencyAmountType getMinCurAmt() {
        return minCurAmt;
    }

    /**
     * Define el valor de la propiedad minCurAmt.
     * 
     * @param value
     *     allowed object is
     *     {@link CurrencyAmountType }
     *     
     */
    public void setMinCurAmt(CurrencyAmountType value) {
        this.minCurAmt = value;
    }

    /**
     * Obtiene el valor de la propiedad maxCurAmt.
     * 
     * @return
     *     possible object is
     *     {@link CurrencyAmountType }
     *     
     */
    public CurrencyAmountType getMaxCurAmt() {
        return maxCurAmt;
    }

    /**
     * Define el valor de la propiedad maxCurAmt.
     * 
     * @param value
     *     allowed object is
     *     {@link CurrencyAmountType }
     *     
     */
    public void setMaxCurAmt(CurrencyAmountType value) {
        this.maxCurAmt = value;
    }

    /**
     * Obtiene el valor de la propiedad specialHandling.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSpecialHandling() {
        return specialHandling;
    }

    /**
     * Define el valor de la propiedad specialHandling.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSpecialHandling(String value) {
        this.specialHandling = value;
    }

    /**
     * Obtiene el valor de la propiedad memo.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getMemo() {
        return memo;
    }

    /**
     * Define el valor de la propiedad memo.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setMemo(String value) {
        this.memo = value;
    }
    
    public String toString() {
    	XMLUtil<CompositeCurAmtType> requestParser = 
    							new XMLUtil<CompositeCurAmtType>();
		return requestParser.convertObjectToXml(this);
    }

}
