
package co.com.ath.pgw.rest.dto;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonProperty;

public class Image implements Serializable {

	@JsonProperty("URL")
	private String url;
	private static final long serialVersionUID = -2489058608358103374L;
	
	public String getUrl() {
		return url;
	}
	public void setUrl(String url) {
		this.url = url;
	}

}
