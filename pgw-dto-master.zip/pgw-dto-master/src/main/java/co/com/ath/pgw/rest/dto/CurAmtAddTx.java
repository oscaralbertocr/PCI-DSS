
package co.com.ath.pgw.rest.dto;

import java.io.Serializable;
import java.math.BigDecimal;

import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;

import org.springframework.format.annotation.NumberFormat;

import com.fasterxml.jackson.annotation.JsonProperty;

import co.com.ath.pgw.rest.util.ConstantFormat;

public class CurAmtAddTx implements Serializable
{

	@JsonProperty("Amt")
	@NotNull
	@NumberFormat(pattern = "^\\d*([.,]{0,1})(\\d+)$")
    private BigDecimal amt;
	
	@JsonProperty("CurCode")
	@NotNull
	@Pattern( regexp = ConstantFormat.FORMAT_SOLO_LETRAS, message = ConstantFormat.MESSAGE_CARACTER_NO_VALIDOS)
    private String curCode;
	
    private final static long serialVersionUID = 5131904000808967745L;

    public BigDecimal getAmt() {
        return amt;
    }

    public void setAmt(BigDecimal amt) {
        this.amt = amt;
    }

    public String getCurCode() {
        return curCode;
    }

    public void setCurCode(String curCode) {
        this.curCode = curCode;
    }

}
