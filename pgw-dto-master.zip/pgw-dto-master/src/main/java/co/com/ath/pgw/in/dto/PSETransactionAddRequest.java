
package co.com.ath.pgw.in.dto;

import co.com.ath.pgw.core.logging.util.XMLUtil;


/**
 * <p>Clase Java para anonymous complex type.
 * 
 * <p>El siguiente fragmento de esquema especifica el contenido que se espera que haya en esta clase.
 * 
 * <pre>
 * &lt;complexType&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element ref="{urn://grupoaval.com/payments/v1/}PSETransactionAddRq"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
public class PSETransactionAddRequest {
    
    protected PSETransactionAddRqType pseTransactionAddRq = new PSETransactionAddRqType();

    /**
     * Obtiene el valor de la propiedad pseTransactionAddRq.
     * 
     * @return
     *     possible object is
     *     {@link PSETransactionAddRqType }
     *     
     */
    public PSETransactionAddRqType getPSETransactionAddRq() {
        return pseTransactionAddRq;
    }

    /**
     * Define el valor de la propiedad pseTransactionAddRq.
     * 
     * @param value
     *     allowed object is
     *     {@link PSETransactionAddRqType }
     *     
     */
    public void setPSETransactionAddRq(PSETransactionAddRqType value) {
        this.pseTransactionAddRq = value;
    }
    
    @Override
   	public String toString() {
   		XMLUtil<PSETransactionAddRequest> requestParser = 
   				new XMLUtil<PSETransactionAddRequest>();
   		return requestParser.convertObjectToXml(this);
   	}

}
