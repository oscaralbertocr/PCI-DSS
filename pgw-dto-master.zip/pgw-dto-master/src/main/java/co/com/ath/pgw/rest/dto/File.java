package co.com.ath.pgw.rest.dto;

import com.fasterxml.jackson.annotation.JsonProperty;

public class File {

	@JsonProperty("FileId")
	private String fileId;
	@JsonProperty("FileType")
	private String fileType;
	@JsonProperty("FileName")
	private String fileName;
	@JsonProperty("FileDesc")
	private String fileDesc;
	@JsonProperty("SPName")
	private String spName;
	@JsonProperty("FileStatus")
	private String fileStatus;
	@JsonProperty("FileRqDt")
	private String fileRqDt;

	public String getFileId() {
		return fileId;
	}

	public void setFileId(String fileId) {
		this.fileId = fileId;
	}

	public String getFileName() {
		return fileName;
	}

	public void setFileName(String fileName) {
		this.fileName = fileName;
	}

	public String getFileDesc() {
		return fileDesc;
	}

	public void setFileDesc(String fileDesc) {
		this.fileDesc = fileDesc;
	}

	public String getSpName() {
		return spName;
	}

	public void setSpName(String spName) {
		this.spName = spName;
	}

	public String getFileStatus() {
		return fileStatus;
	}

	public void setFileStatus(String fileStatus) {
		this.fileStatus = fileStatus;
	}

	public String getFileRqDt() {
		return fileRqDt;
	}

	public void setFileRqDt(String fileRqDt) {
		this.fileRqDt = fileRqDt;
	}

	public String getFileType() {
		return fileType;
	}

	public void setFileType(String fileType) {
		this.fileType = fileType;
	}

	@Override
	public String toString() {
		return "File [fileId=" + fileId + ", fileType=" + fileType + ", fileName=" + fileName + ", fileDesc=" + fileDesc
				+ ", spName=" + spName + ", fileStatus=" + fileStatus + ", fileRqDt=" + fileRqDt + "]";
	}

}
