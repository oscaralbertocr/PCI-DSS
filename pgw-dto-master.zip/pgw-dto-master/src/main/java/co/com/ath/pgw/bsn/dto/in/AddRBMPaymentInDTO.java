/*
 * AddRBMPaymentInDTO
 *  
 * GSI - Integración
 * Creado el: 20/09/2014
 *
 * Copyright (c) A Toda Hora S.A. Todos los derechos reservados
 * 
 * Este software es confidencial y es propietario de ATH, queda prohibido
 * su uso, reproducción y copia de manera parcial o permanente salvo autorización
 * expresa de A Toda Hora S.A o de quién represente sus derechos.
 */
package co.com.ath.pgw.bsn.dto.in;

import co.com.ath.pgw.bsn.model.bo.TransactionBO;
import co.com.ath.pgw.core.logging.util.XMLUtil;

import java.math.BigInteger;
import java.util.Date;


/**
 * DTO de entrada con la información para la operación AddRBMPayment.
 *
 * @version 0.0.0 22/09/2014
 * @author Andrés Méndez Juanias <proveedor_mamendez@ath.com.co>
 */

public class AddRBMPaymentInDTO extends CommonObjectInDTO {

    private TransactionBO transactionBO;
    
    private BigInteger instalamentsNum;
    
    private Date expDate;
    
	public AddRBMPaymentInDTO(){

	}

	@Override
	public String toString() {
		XMLUtil<AddRBMPaymentInDTO> requestParser = new XMLUtil<AddRBMPaymentInDTO>();
		return requestParser.convertObjectToXml(this);
	}

    public TransactionBO getTransactionBO() {
        return transactionBO;
    }

    public void setTransactionBO(TransactionBO transactionBO) {
        this.transactionBO = transactionBO;
    }

    public BigInteger getInstalamentsNum() {
        return instalamentsNum;
    }

    public void setInstalamentsNum(BigInteger instalamentsNum) {
        this.instalamentsNum = instalamentsNum;
    }

	/**
	 * Método encargado de recuperar el valor del atributo expDate.
	 * @return El atributo expDate asociado a la clase.
	 */
	public Date getExpDate() {
		return expDate;
	}

	/**
	 * Método encargado de actualizar el atributo expDate.
	 * @param expDate Nuevo valor para expDate.
	 */
	public void setExpDate(Date expDate) {
		this.expDate = expDate;
	}
    
}