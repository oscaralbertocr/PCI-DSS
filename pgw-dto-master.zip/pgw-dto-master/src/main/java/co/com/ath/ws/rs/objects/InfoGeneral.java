package co.com.ath.ws.rs.objects;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonProperty;

public class InfoGeneral implements Serializable{

	private static final long serialVersionUID = -4270709134672559987L;
	
	@JsonProperty("tipoTransaccion")
	private String tipoTransaccion;
	
	@JsonProperty("numeroAprobacion")
	private String numeroAprobacion;
	
	@JsonProperty("idTransaccion")
	private String idTransaccion;
	
	@JsonProperty("idTransaccionAutorizador")
	private String idTransaccionAutorizador;
	
	@JsonProperty("origenTransaccion")
	private String origenTransaccion;
	
	@JsonProperty("hora")
	private String hora;

	public String getTipoTransaccion() {
		return tipoTransaccion;
	}

	public void setTipoTransaccion(String tipoTransaccion) {
		this.tipoTransaccion = tipoTransaccion;
	}

	public String getNumeroAprobacion() {
		return numeroAprobacion;
	}

	public void setNumeroAprobacion(String numeroAprobacion) {
		this.numeroAprobacion = numeroAprobacion;
	}

	public String getIdTransaccion() {
		return idTransaccion;
	}

	public void setIdTransaccion(String idTransaccion) {
		this.idTransaccion = idTransaccion;
	}

	public String getIdTransaccionAutorizador() {
		return idTransaccionAutorizador;
	}

	public void setIdTransaccionAutorizador(String idTransaccionAutorizador) {
		this.idTransaccionAutorizador = idTransaccionAutorizador;
	}

	public String getOrigenTransaccion() {
		return origenTransaccion;
	}

	public void setOrigenTransaccion(String origenTransaccion) {
		this.origenTransaccion = origenTransaccion;
	}

	public String getHora() {
		return hora;
	}

	public void setHora(String hora) {
		this.hora = hora;
	}
	
	
}
