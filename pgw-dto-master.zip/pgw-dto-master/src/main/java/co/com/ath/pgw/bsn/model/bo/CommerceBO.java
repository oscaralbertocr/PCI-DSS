/*
 * CommerceVO
 *  
 * GSI - Integración
 * Creado el: 29/08/2014
 *
 * Copyright (c) A Toda Hora S.A. Todos los derechos reservados
 * 
 * Este software es confidencial y es propietario de ATH, queda prohibido
 * su uso, reproducción y copia de manera parcial o permanente salvo autorización
 * expresa de A Toda Hora S.A o de quién represente sus derechos.
 */
package co.com.ath.pgw.bsn.model.bo;

import java.util.List;



/**
 * Representa un comercio asociado. Esta entidad pertenece al modelo
 * de negocio.
 * 
 * @author proveedor_japiza
 * @version 1.0 29 Ago 2014
 * @since 1.0
 */
public class CommerceBO {	

	/**
	 * Identificador único del comercio en el sistema.
	 */
	private Long id;
	
	/**
	 * Número de identificación tributaria (NIT) de la empresa que inscribe
	 * el comercio.
	 */
	private String nit;
	
	/**
	 * Código NURA del comercio.
	 */
	private String nuraCode;
	
	/**
	 * Código ACH del comercio.
	 */
	private String achCode;

	/**
	 * Código EAN del comercio.
	 */
	private String eanCode;
	
	/**
	 * Código Incocredito del comercio.
	 */
	private String incocreditoCode;
	
	/**
	 * Código Terminal del comercio.
	 */
	private String terminalCode;
	
	/**
	 * Estado del comercio.
	 */
	private String status;
	
	/**
	 * Indicativo de referencia con tarjeta de crédito.
	 */
	private String creditCardInd;
	
	/**
	 * Configuración técnica del comercio.
	 */
	private CommerceConfigurationBO configuration;
	
	/**
	 * Medios de pago habilidatos para el comercio.
	 */
	private List<PaymentWayBO> paymentWays;
	
	/**
	 * Información detallada del comercio.
	 */
	private SubscriptionBO subscription;

	/**
	 * Información detallada del comercio.
	 */
	private boolean aggregator;
			
	/**
	 * constructor por defecto
	 */
	public CommerceBO() {}
	
	/**
	 * constructor con parametros
	 * @param nura
	 * @param config
	 */
	public CommerceBO(String nura, CommerceConfigurationBO config) {
		this.nuraCode		= nura;
		this.configuration	= config;
	}
	
	
	/**
	 * Retorna el identificador único del comercio en el sistema.
	 * 
	 * @return Identificador único del comercio en el sistema.
	 */
	public Long getId() {
		return id;
	}

	/**
	 * Establece el identificador único del comercio en el sistema.
	 * 
	 * @param id identificador único del comercio.
	 */
	public void setId(Long id) {
		this.id = id;
	}

	/**
	 * Retorna el número de identificación tributaria (NIT) de la empresa que
	 * inscribe el comercio.
	 * 
	 * @return NIT del comercio.
	 */
	public String getNit() {
		return nit;
	}

	/**
	 * Establece el número de identificación tributaria (NIT) de la empresa que
	 * inscribe el comercio.
	 * 
	 * @param nit NIT del comercio.
	 */
	public void setNit(String nit) {
		this.nit = nit;
	}

	/**
	 * Retorna el código NURA del comercio.
	 * 
	 * @return Código NURA.
	 */
	public String getNuraCode() {
		return nuraCode;
	}

	/**
	 * Establece el código NURA del comercio.
	 *  
	 * @param nuraCode Código NURA.
	 */
	public void setNuraCode(String nuraCode) {
		this.nuraCode = nuraCode;
	}

	/**
	 * Retorna el código ACH del comercio.
	 * 
	 * @return Código ACH.
	 */
	public String getAchCode() {
		return achCode;
	}

	/**
	 * Establece el código ACH del comercio.
	 * 
	 * @param achCode Código ACH.
	 */
	public void setAchCode(String achCode) {
		this.achCode = achCode;
	}

	/**
	 * Retorna el código EAN del comercio.
	 * 
	 * @return Código EAN.
	 */
	public String getEanCode() {
		return eanCode;
	}

	/**
	 * Establece el código EAN del comercio.
	 * 
	 * @param eanCode Código EAN.
	 */
	public void setEanCode(String eanCode) {
		this.eanCode = eanCode;
	}

	/**
	 * Retorna el código asignado por Incocrédito al comercio.
	 * 
	 * @return Código Incocrédito.
	 */
	public String getIncocreditoCode() {
		return incocreditoCode;
	}

	/**
	 * Establece el código que Incocrédito asignó al comercio.
	 * 
	 * @param incocreditoCode Código Incocrédito.
	 */
	public void setIncocreditoCode(String incocreditoCode) {
		this.incocreditoCode = incocreditoCode;
	}

	/**
	 * Retorna Código Terminal del comercio.
	 * @return String
	 */
	public String getTerminalCode() {
		return terminalCode;
	}

	/**
	 * Establece Código Terminal del comercio.
	 * @param terminalCode
	 */
	public void setTerminalCode(String terminalCode) {
		this.terminalCode = terminalCode;
	}
	
	/**
	 * Retorna el estado del comercio.
	 * 
	 * @return Estado del comercio.
	 */
	public String getStatus() {
		return status;
	}

	/**
	 * Establece el estado del comericio.
	 * 
	 * @param status Estado del comercio.
	 */
	public void setStatus(String status) {
		this.status = status;
	}

	/**
	 * Retorna la configuración técnica del comercio. Incluye la información
	 * gráfica del comercio.
	 * 
	 * @return Configuración técnica.
	 */
	public CommerceConfigurationBO getConfiguration() {
		return configuration;
	}

	/**
	 * Establece la configuración técnica del comercio.
	 * 
	 * @param configuration Configuración técnica.
	 */
	public void setConfiguration(CommerceConfigurationBO configuration) {
		this.configuration = configuration;
	}

	/**
	 * Retorna los medios de pago disponibles para el comercio.
	 * 
	 * @return Medios de pago disponibles.
	 */
	public List<PaymentWayBO> getPaymentWays() {
		return paymentWays;
	}

	/**
	 * Establece los medios de pago disponibles para el comercio.
	 * 
	 * @param paymentWays Medios de pago.
	 */
	public void setPaymentWays(List<PaymentWayBO> paymentWays) {
		this.paymentWays = paymentWays;
	}

	/**
	 * Retorna la información detallada del comercio.
	 * 
	 * @return Infomación detallada del comercio.
	 */
	public SubscriptionBO getSubscription() {
		return subscription;
	}

	/**
	 * Establece la información detallada del comercio.
	 * 
	 * @param subscription Información detallada del comercio.
	 */
	public void setSubscription(SubscriptionBO subscription) {
		this.subscription = subscription;
	}

	/**
	 * Retorna si el comercio es agregador.
	 * 
	 * @return Infomación si el comercio es agregador.
	 */
	public boolean getAggregator() {
		return aggregator;
	}

	/**
	 * Establece la información si el comercio es agregador.
	 * 
	 * @param información si el comercio es agregador.
	 */
	public void setAggregator(boolean aggregator) {
		this.aggregator = aggregator;
    }	

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result
				+ ((nuraCode == null) ? 0 : nuraCode.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		CommerceBO other = (CommerceBO) obj;
		if (nuraCode == null) {
			if (other.nuraCode != null)
				return false;
		} else if (!nuraCode.equals(other.nuraCode))
			return false;
		return true;
	}

	@Override
	public String toString() {
		return "CommerceVO [id=" + id + ", nit=" + nit + ", nuraCode="
				+ nuraCode + ", status=" + status + "]";
	}
}