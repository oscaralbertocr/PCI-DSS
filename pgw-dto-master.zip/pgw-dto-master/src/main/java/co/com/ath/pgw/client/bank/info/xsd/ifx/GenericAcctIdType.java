
package co.com.ath.pgw.client.bank.info.xsd.ifx;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlSeeAlso;
import javax.xml.bind.annotation.XmlType;

import co.com.ath.pgw.core.logging.util.XMLUtil;


/**
 * <p>Clase Java para GenericAcctId_Type complex type.
 * 
 * <p>El siguiente fragmento de esquema especifica el contenido que se espera que haya en esta clase.
 * 
 * <pre>
 * &lt;complexType name="GenericAcctId_Type">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element ref="{urn://grupoaval.com/xsd/ifx/}AcctId" minOccurs="0"/>
 *         &lt;element ref="{urn://grupoaval.com/xsd/ifx/}AcctType"/>
 *         &lt;element ref="{urn://grupoaval.com/xsd/ifx/}BankInfo" minOccurs="0"/>
 *         &lt;element ref="{urn://grupoaval.com/xsd/ifx/}AcctCur" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "GenericAcctId_Type", propOrder = {
    "acctId",
    "acctType",
    "bankInfo",
    "acctCur"
})
@XmlSeeAlso({
    LoanAcctIdType.class,
    DepAcctIdType.class
})
public class GenericAcctIdType {

    @XmlElement(name = "AcctId")
    protected String acctId;
    @XmlElement(name = "AcctType", required = true)
    protected String acctType;
    @XmlElement(name = "BankInfo", namespace = "urn://grupoaval.com/xsd/ifx/")
    protected BankInfoType bankInfo;
    @XmlElement(name = "AcctCur")
    protected String acctCur;

    /**
     * Obtiene el valor de la propiedad acctId.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getAcctId() {
        return acctId;
    }

    /**
     * Define el valor de la propiedad acctId.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setAcctId(String value) {
        this.acctId = value;
    }

    /**
     * Obtiene el valor de la propiedad acctType.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getAcctType() {
        return acctType;
    }

    /**
     * Define el valor de la propiedad acctType.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setAcctType(String value) {
        this.acctType = value;
    }

    /**
     * Obtiene el valor de la propiedad bankInfo.
     * 
     * @return
     *     possible object is
     *     {@link BankInfoType }
     *     
     */
    public BankInfoType getBankInfo() {
        return bankInfo;
    }

    /**
     * Define el valor de la propiedad bankInfo.
     * 
     * @param value
     *     allowed object is
     *     {@link BankInfoType }
     *     
     */
    public void setBankInfo(BankInfoType value) {
        this.bankInfo = value;
    }

    /**
     * Obtiene el valor de la propiedad acctCur.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getAcctCur() {
        return acctCur;
    }

    /**
     * Define el valor de la propiedad acctCur.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setAcctCur(String value) {
        this.acctCur = value;
    }
    
    public String toString() {
    	XMLUtil<GenericAcctIdType> requestParser = 
    							new XMLUtil<GenericAcctIdType>();
		return requestParser.convertObjectToXml(this);
    }

}
