
package co.com.ath.pgw.in.model;

import org.apache.commons.lang.builder.ToStringBuilder;
import org.apache.cxf.xjc.runtime.JAXBToStringStyle;
import org.xml.sax.Locator;

import com.sun.xml.bind.Locatable;


/**
 * <p>Clase Java para AuthExt_Type complex type.
 * 
 * <p>El siguiente fragmento de esquema especifica el contenido que se espera que haya en esta clase.
 * 
 * <pre>
 * &lt;complexType name="AuthExt_Type"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element ref="{urn://ath.com.co/xsd/common/}Method"/&gt;
 *         &lt;element ref="{urn://ath.com.co/xsd/common/}Info"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
public class AuthExtType 
    implements Locatable , Cloneable 
{
    protected String method;
    
    protected String info;
    
    protected Locator locator;

    /**
     * Obtiene el valor de la propiedad method.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */   
    public synchronized String getMethod() {
        return method;
    }

    /**
     * Define el valor de la propiedad method.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public synchronized void setMethod(String value) {
        this.method = value;
    }

    /**
     * Obtiene el valor de la propiedad info.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
   
    public synchronized String getInfo() {
        return info;
    }

    /**
     * Define el valor de la propiedad info.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */  
    public synchronized void setInfo(String value) {
        this.info = value;
    }

    /**
     * Generates a String representation of the contents of this type.
     * This is an extension method, produced by the 'ts' xjc plugin
     * 
     */
    @Override   
    public synchronized String toString() {
        return ToStringBuilder.reflectionToString(this, JAXBToStringStyle.SIMPLE_STYLE);
    }

    public synchronized Locator sourceLocation() {
        return locator;
    }
    
    public synchronized void setSourceLocation(Locator newLocator) {
        locator = newLocator;
    }
    
    @Override
	public Object clone() throws CloneNotSupportedException {
		return super.clone();
	}

}
