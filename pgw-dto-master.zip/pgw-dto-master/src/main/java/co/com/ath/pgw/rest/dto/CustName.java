package co.com.ath.pgw.rest.dto;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonProperty;

public class CustName implements Serializable {

	private static final long serialVersionUID = 1465469688037523149L;
	
	@JsonProperty("LastName")
	private String lastName;
	
	@JsonProperty("FirstName")
    private String firstName;
    
	@JsonProperty("Nickname")
    private String nickname;
      
	@JsonProperty("LegalName")
    private String legalName;

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getNickname() {
		return nickname;
	}

	public void setNickname(String nickname) {
		this.nickname = nickname;
	}

	public String getLegalName() {
		return legalName;
	}

	public void setLegalName(String legalName) {
		this.legalName = legalName;
	}


}
