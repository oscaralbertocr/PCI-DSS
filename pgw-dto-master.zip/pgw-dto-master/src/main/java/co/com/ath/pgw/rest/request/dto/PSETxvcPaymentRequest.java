package co.com.ath.pgw.rest.request.dto;

import java.io.Serializable;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonProperty;

import co.com.ath.pgw.core.logging.util.XMLUtil;
import co.com.ath.pgw.rest.dto.Agreement;
import co.com.ath.pgw.rest.dto.BankInfo;
import co.com.ath.pgw.rest.dto.CustInfo;
import co.com.ath.pgw.rest.dto.Fee;
import co.com.ath.pgw.rest.dto.InvoicePmtInfo;
import co.com.ath.pgw.rest.dto.RefInfo;
import co.com.ath.pgw.rest.dto.TaxPmtInfo;
import co.com.ath.pgw.rest.dto.TrnSrcInfo;

public class PSETxvcPaymentRequest implements Serializable {

	@JsonProperty("CustInfo")
	private CustInfo custInfo;
	@JsonProperty("Agreement")
	private Agreement agreement;
	@JsonProperty("InvoicePmtInfo")
	private InvoicePmtInfo invoicePmtInfo;
	@JsonProperty("Fee")
	private Fee fee;
	@JsonProperty("TaxPmtInfo")
	private TaxPmtInfo taxPmtInfo;
	@JsonProperty("RefInfo")
	private List<RefInfo> refInfo = null;
	@JsonProperty("BankInfo")
	private BankInfo bankInfo;
	@JsonProperty("TrnSrcInfo")
	private TrnSrcInfo trnSrcInfo;
	private static final long serialVersionUID = 5757532387399046381L;

	public CustInfo getCustInfo() {
		return custInfo;
	}

	public void setCustInfo(CustInfo custInfo) {
		this.custInfo = custInfo;
	}

	public Agreement getAgreement() {
		return agreement;
	}

	public void setAgreement(Agreement agreement) {
		this.agreement = agreement;
	}

	public InvoicePmtInfo getInvoicePmtInfo() {
		return invoicePmtInfo;
	}

	public void setInvoicePmtInfo(InvoicePmtInfo invoicePmtInfo) {
		this.invoicePmtInfo = invoicePmtInfo;
	}

	public Fee getFee() {
		return fee;
	}

	public void setFee(Fee fee) {
		this.fee = fee;
	}

	public TaxPmtInfo getTaxPmtInfo() {
		return taxPmtInfo;
	}

	public void setTaxPmtInfo(TaxPmtInfo taxPmtInfo) {
		this.taxPmtInfo = taxPmtInfo;
	}

	public List<RefInfo> getRefInfo() {
		return refInfo;
	}

	public void setRefInfo(List<RefInfo> refInfo) {
		this.refInfo = refInfo;
	}

	public BankInfo getBankInfo() {
		return bankInfo;
	}

	public void setBankInfo(BankInfo bankInfo) {
		this.bankInfo = bankInfo;
	}

	public TrnSrcInfo getTrnSrcInfo() {
		return trnSrcInfo;
	}

	public void setTrnSrcInfo(TrnSrcInfo trnSrcInfo) {
		this.trnSrcInfo = trnSrcInfo;
	}
	
	@Override
	public String toString() {
		XMLUtil<PSETxvcPaymentRequest> util = new XMLUtil<PSETxvcPaymentRequest>();
		return util.convertObjectToJson(this);
	}

}