package co.com.ath.pgw.rest.dto;

import java.io.Serializable;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import org.apache.commons.lang.builder.ToStringBuilder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "ContactInfo"
})
public class CompositeContactInfo implements Serializable
{

    @JsonProperty("ContactInfo")
    private ContactInfo contactInfo;
    private final static long serialVersionUID = -7203771247983308524L;

    @JsonProperty("ContactInfo")
    public ContactInfo getContactInfo() {
        return contactInfo;
    }

    @JsonProperty("ContactInfo")
    public void setContactInfo(ContactInfo contactInfo) {
        this.contactInfo = contactInfo;
    }

    @Override
    public String toString() {
        return new ToStringBuilder(this).append("contactInfo", contactInfo).toString();
    }

}
