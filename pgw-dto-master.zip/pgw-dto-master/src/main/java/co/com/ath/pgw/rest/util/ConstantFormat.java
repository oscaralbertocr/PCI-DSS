package co.com.ath.pgw.rest.util;

public class ConstantFormat {

	public static final String FORMAT_NUMEROS_LETRAS = "\\w*";
	public static final String FORMAT_NUMEROS_LETRAS_REF_ID = "^[a-zA-Z0-9À-ÿ\\.\\&\\-\\:\\_]*$";
	public static final String FORMAT_NO_CARACTERES = "^[^\\\\\\(\\)\\\"\\!\\&\\'\\/\\<\\>\\|\\@]{1,}$";
	public static final String FORMAT_NO_CARACTERES_AMP = "^[^\\\\\\(\\)\\\"\\!\\'\\/\\<\\>\\|\\@]{1,}$";
	public static final String FORMAT_NO_CARACTERES_O_ESPACIO = "^[^\\\\\\(\\)\\\"\\!\\&\\'\\/\\<\\>\\|\\@]*$";
	public static final String FORMAT_NO_CARACTERES_CON_SLASH = "^[^\\(\\)\\\"\\!\\&\\'\\<\\>\\|\\@]{1,}$";
	public static final String FORMAT_NO_CARACTERES_TRES = "^[^\\(\\)\\\"\\!\\'\\<\\>\\|]{1,}$";
	public static final String FORMAT_NO_CARACTERES_REF_TYPE = "^[^\\(\\)\\\"\\!\\'\\<\\>\\|]*$";
	public static final String FORMAT_EMAIL_OF_FRONT = "^([a-zA-Z0-9.!#$%&'*+\\/=?^_`{|}~-]+@[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?(?:\\.[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?)*)*$";
	public static final String FORMAT_NO_CARACTERES_DESC_ADDTX = "^[^\\\\\\\"\\'\\<\\>\\|\\@]{1,}$";
	
	public static final String FORMAT_NOMBRE_FRONT = "^[\\sa-zA-ZÀ-ÿ]{0,65}$";
	public static final String FORMAT_NOMBRE_FRONT_OBLIGATORIO = "^[\\sa-zA-ZÀ-ÿ]{1,65}$";
	public static final String FORMAT_NUMEROS_LETRAS_ACENTOS = "^[0-9A-Za-zÁÉÍÓÚáéíóúñÑ.:/ ]*$";
	public static final String FORMAT_SOLO_LETRAS = "[A-z]*";
	public static final String FORMAT_SOLO_LETRAS_ACENTOS = "^[A-Za-zÁÉÍÓÚáéíóúñÑ. ]*$";
	public static final String FORMAT_SOLO_NUMEROS = "\\d*";
	public static final String FORMAT_SOLO_NUMEROS_PARENTESIS = "^[\\d\\(\\)\\-]*$";
	public static final String FORMAT_TELEFONO ="^([0-24-9]{1})([0-9]{0,29})$|^3[0-9]{9}$|\\(\\d{3}\\) \\d{3}-\\d{4}";
	public static final String FORMAT_EMAIL = "^([A-Za-z0-9+_.-]+@(.+))*$";

	public static final String FORMAT_SOLO_LETRAS_ACENTOS_BLANK = "|^[A-Za-zÁÉÍÓÚáéíóúñÑ. ]*$";
	public static final String FORMAT_NUMEROS_LETRAS_ACENTOS_BLANK = "|^[0-9A-Za-zÁÉÍÓÚáéíóúñÑ.:/ ]*$";
	public static final String FORMAT_NUMEROS_LETRAS_ACENTOS_IDENTSERIALNUM = "^[A-Za-z0-9]{0,12}$";
	// Mensaje

	public static final String MESSAGE_CARACTER_NO_VALIDOS ="tiene caracteres no validos";
	public static final String MESSAGE_CAMPOS_NO_VALIDOS ="El objeto recibido contiene campos no permitidos.";
}
