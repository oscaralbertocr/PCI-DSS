package co.com.ath.pgw.rest.request.dto;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonProperty;

import co.com.ath.pgw.core.logging.util.XMLUtil;

public class Header implements Serializable {

	@JsonProperty("X-RqUID")
	private Long rqUID;
	@JsonProperty("X-Channel")
	private String channel;
	@JsonProperty("X-CompanyId")
	private String companyId;
	@JsonProperty("X-IdentSerialNum")
	private String identSerialNum;
	@JsonProperty("X-GovIssueIdentType")
	private String govIssueIdentType;
	@JsonProperty("X-IPAddr")
	private String ipAddr;
	private static final long serialVersionUID = -4477190778751326677L;

	public Header(Long rqUID, String channel, String companyId, String identSerialNum, String govIssueIdentType, String ipAddr) {
		this.rqUID = rqUID;
		this.channel = channel;
		this.companyId = companyId;
		this.identSerialNum = identSerialNum;
		this.govIssueIdentType = govIssueIdentType;
		this.ipAddr = ipAddr;
	}

	public Long getRqUID() {
		return rqUID;
	}

	public void setRqUID(Long rqUID) {
		this.rqUID = rqUID;
	}

	public String getChannel() {
		return channel;
	}

	public void setChannel(String channel) {
		this.channel = channel;
	}

	public String getCompanyId() {
		return companyId;
	}

	public void setCompanyId(String companyId) {
		this.companyId = companyId;
	}

	public String getIdentSerialNum() {
		return identSerialNum;
	}

	public void setIdentSerialNum(String identSerialNum) {
		this.identSerialNum = identSerialNum;
	}

	public String getGovIssueIdentType() {
		return govIssueIdentType;
	}

	public void setGovIssueIdentType(String govIssueIdentType) {
		this.govIssueIdentType = govIssueIdentType;
	}

	public String getIpAddr() {
		return ipAddr;
	}

	public void setIpAddr(String ipAddr) {
		this.ipAddr = ipAddr;
	}

	@Override
	public String toString() {
		XMLUtil<Header> util = new XMLUtil<Header>();
		return util.convertObjectToJson(this);
	}

}