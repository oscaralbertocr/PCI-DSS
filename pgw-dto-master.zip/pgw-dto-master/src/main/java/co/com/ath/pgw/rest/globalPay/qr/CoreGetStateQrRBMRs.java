package co.com.ath.pgw.rest.globalPay.qr;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

import co.com.ath.pgw.core.logging.util.XMLUtil;
import co.com.ath.ws.rs.objects.InfoEstado;
import co.com.ath.ws.rs.objects.InfoGeneral;
import co.com.ath.ws.rs.objects.InfoMonto;
import co.com.ath.ws.rs.objects.InfoPago;
import co.com.ath.ws.rs.objects.InfoTerminal;

@JsonInclude(Include.NON_NULL)
public class CoreGetStateQrRBMRs implements Serializable{

	private static final long serialVersionUID = 4030757199682862049L;
	
	@JsonProperty("informacionGeneral")
	private InfoGeneral informacionGeneral;

	@JsonProperty("informacionEstado")
	private InfoEstado informacionEstado;
	
	@JsonProperty("informacionPago")
	private InfoPago informacionPago;
	
	@JsonProperty("informacionTerminal")
	private InfoTerminal informacionTerminal;
	
	@JsonProperty("informacionMonto")
	private InfoMonto informacionMonto;

	public InfoGeneral getInformacionGeneral() {
		return informacionGeneral;
	}

	public void setInformacionGeneral(InfoGeneral informacionGeneral) {
		this.informacionGeneral = informacionGeneral;
	}

	public InfoEstado getInformacionEstado() {
		return informacionEstado;
	}

	public void setInformacionEstado(InfoEstado informacionEstado) {
		this.informacionEstado = informacionEstado;
	}

	public InfoPago getInformacionPago() {
		return informacionPago;
	}

	public void setInformacionPago(InfoPago informacionPago) {
		this.informacionPago = informacionPago;
	}

	public InfoTerminal getInformacionTerminal() {
		return informacionTerminal;
	}

	public void setInformacionTerminal(InfoTerminal informacionTerminal) {
		this.informacionTerminal = informacionTerminal;
	}

	public InfoMonto getInformacionMonto() {
		return informacionMonto;
	}

	public void setInformacionMonto(InfoMonto informacionMonto) {
		this.informacionMonto = informacionMonto;
	}

	@Override
	public String toString() {
		XMLUtil<CoreGetStateQrRBMRs> util = new XMLUtil<CoreGetStateQrRBMRs>();
		return util.convertObjectToJson(this);
	}
			
}
