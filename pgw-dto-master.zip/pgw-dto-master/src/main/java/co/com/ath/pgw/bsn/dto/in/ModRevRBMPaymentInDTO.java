/*
 * ModRevRBMPaymentInDTO
 *  
 * GSI - Integración
 * Creado el: 16/10/2014
 *
 * Copyright (c) A Toda Hora S.A. Todos los derechos reservados
 * 
 * Este software es confidencial y es propietario de ATH, queda prohibido
 * su uso, reproducción y copia de manera parcial o permanente salvo autorización
 * expresa de A Toda Hora S.A o de quién represente sus derechos.
 */
package co.com.ath.pgw.bsn.dto.in;

import java.math.BigDecimal;
import java.math.BigInteger;
import java.util.Date;
import java.util.List;

/**
 * Class description goes here...
 *
 * @author Andrés Méndez Juanias <proveedor_mamendez@ath.com.co> 
 * @version 1.0 16/10/2014
 * @since 1.0
 */
public class ModRevRBMPaymentInDTO extends CommonObjectInDTO {
	
    private String channel;
    
	private String custIdType;
	
	private String custIdNum;
	
	private String custLoginId;
    
    private String pmtId;
    
    private BigInteger instalamentsNum;
    
    private String orderId;
    
    private String orderDesc;
    
    private Date orderExpDt;
    
    private Date orderEndDt;
    
    private String cardEmbossNum;
    
    private String brand;
    
    private Date cardExpDt;
    
    private String CardVrfyData;
    
    private BigDecimal amt;
    
    private String curCode;
    
    private BigDecimal curRate;
    
    private BigDecimal taxAmt;
    
    private String taxCurCode;
    
    private BigDecimal taxCurRate;
    
    private List<String> referenceList;

	/**
	 * Método encargado de recuperar el valor del atributo channel.
	 * @return El atributo channel asociado a la clase.
	 */
	public String getChannel() {
		return channel;
	}

	/**
	 * Método encargado de actualizar el atributo channel.
	 * @param channel Nuevo valor para channel.
	 */
	public void setChannel(String channel) {
		this.channel = channel;
	}

	/**
	 * Método encargado de recuperar el valor del atributo custIdType.
	 * @return El atributo custIdType asociado a la clase.
	 */
	public String getCustIdType() {
		return custIdType;
	}

	/**
	 * Método encargado de actualizar el atributo custIdType.
	 * @param custIdType Nuevo valor para custIdType.
	 */
	public void setCustIdType(String custIdType) {
		this.custIdType = custIdType;
	}

	/**
	 * Método encargado de recuperar el valor del atributo custIdNum.
	 * @return El atributo custIdNum asociado a la clase.
	 */
	public String getCustIdNum() {
		return custIdNum;
	}

	/**
	 * Método encargado de actualizar el atributo custIdNum.
	 * @param custIdNum Nuevo valor para custIdNum.
	 */
	public void setCustIdNum(String custIdNum) {
		this.custIdNum = custIdNum;
	}

	/**
	 * Método encargado de recuperar el valor del atributo custLoginId.
	 * @return El atributo custLoginId asociado a la clase.
	 */
	public String getCustLoginId() {
		return custLoginId;
	}

	/**
	 * Método encargado de actualizar el atributo custLoginId.
	 * @param custLoginId Nuevo valor para custLoginId.
	 */
	public void setCustLoginId(String custLoginId) {
		this.custLoginId = custLoginId;
	}

	/**
	 * Método encargado de recuperar el valor del atributo pmtId.
	 * @return El atributo pmtId asociado a la clase.
	 */
	public String getPmtId() {
		return pmtId;
	}

	/**
	 * Método encargado de actualizar el atributo pmtId.
	 * @param pmtId Nuevo valor para pmtId.
	 */
	public void setPmtId(String pmtId) {
		this.pmtId = pmtId;
	}

	/**
	 * Método encargado de recuperar el valor del atributo instalamentsNum.
	 * @return El atributo instalamentsNum asociado a la clase.
	 */
	public BigInteger getInstalamentsNum() {
		return instalamentsNum;
	}

	/**
	 * Método encargado de actualizar el atributo instalamentsNum.
	 * @param instalamentsNum Nuevo valor para instalamentsNum.
	 */
	public void setInstalamentsNum(BigInteger instalamentsNum) {
		this.instalamentsNum = instalamentsNum;
	}

	/**
	 * Método encargado de recuperar el valor del atributo orderId.
	 * @return El atributo orderId asociado a la clase.
	 */
	public String getOrderId() {
		return orderId;
	}

	/**
	 * Método encargado de actualizar el atributo orderId.
	 * @param orderId Nuevo valor para orderId.
	 */
	public void setOrderId(String orderId) {
		this.orderId = orderId;
	}

	/**
	 * Método encargado de recuperar el valor del atributo orderDesc.
	 * @return El atributo orderDesc asociado a la clase.
	 */
	public String getOrderDesc() {
		return orderDesc;
	}

	/**
	 * Método encargado de actualizar el atributo orderDesc.
	 * @param orderDesc Nuevo valor para orderDesc.
	 */
	public void setOrderDesc(String orderDesc) {
		this.orderDesc = orderDesc;
	}

	/**
	 * Método encargado de recuperar el valor del atributo orderExpDt.
	 * @return El atributo orderExpDt asociado a la clase.
	 */
	public Date getOrderExpDt() {
		return orderExpDt;
	}

	/**
	 * Método encargado de actualizar el atributo orderExpDt.
	 * @param orderExpDt Nuevo valor para orderExpDt.
	 */
	public void setOrderExpDt(Date orderExpDt) {
		this.orderExpDt = orderExpDt;
	}

	/**
	 * Método encargado de recuperar el valor del atributo orderEndDt.
	 * @return El atributo orderEndDt asociado a la clase.
	 */
	public Date getOrderEndDt() {
		return orderEndDt;
	}

	/**
	 * Método encargado de actualizar el atributo orderEndDt.
	 * @param orderEndDt Nuevo valor para orderEndDt.
	 */
	public void setOrderEndDt(Date orderEndDt) {
		this.orderEndDt = orderEndDt;
	}

	/**
	 * Método encargado de recuperar el valor del atributo cardEmbossNum.
	 * @return El atributo cardEmbossNum asociado a la clase.
	 */
	public String getCardEmbossNum() {
		return cardEmbossNum;
	}

	/**
	 * Método encargado de actualizar el atributo cardEmbossNum.
	 * @param cardEmbossNum Nuevo valor para cardEmbossNum.
	 */
	public void setCardEmbossNum(String cardEmbossNum) {
		this.cardEmbossNum = cardEmbossNum;
	}

	/**
	 * Método encargado de recuperar el valor del atributo brand.
	 * @return El atributo brand asociado a la clase.
	 */
	public String getBrand() {
		return brand;
	}

	/**
	 * Método encargado de actualizar el atributo brand.
	 * @param brand Nuevo valor para brand.
	 */
	public void setBrand(String brand) {
		this.brand = brand;
	}

	/**
	 * Método encargado de recuperar el valor del atributo cardExpDt.
	 * @return El atributo cardExpDt asociado a la clase.
	 */
	public Date getCardExpDt() {
		return cardExpDt;
	}

	/**
	 * Método encargado de actualizar el atributo cardExpDt.
	 * @param cardExpDt Nuevo valor para cardExpDt.
	 */
	public void setCardExpDt(Date cardExpDt) {
		this.cardExpDt = cardExpDt;
	}

	/**
	 * Método encargado de recuperar el valor del atributo cardVrfyData.
	 * @return El atributo cardVrfyData asociado a la clase.
	 */
	public String getCardVrfyData() {
		return CardVrfyData;
	}

	/**
	 * Método encargado de actualizar el atributo cardVrfyData.
	 * @param cardVrfyData Nuevo valor para cardVrfyData.
	 */
	public void setCardVrfyData(String cardVrfyData) {
		CardVrfyData = cardVrfyData;
	}

	/**
	 * Método encargado de recuperar el valor del atributo amt.
	 * @return El atributo amt asociado a la clase.
	 */
	public BigDecimal getAmt() {
		return amt;
	}

	/**
	 * Método encargado de actualizar el atributo amt.
	 * @param amt Nuevo valor para amt.
	 */
	public void setAmt(BigDecimal amt) {
		this.amt = amt;
	}

	/**
	 * Método encargado de recuperar el valor del atributo curCode.
	 * @return El atributo curCode asociado a la clase.
	 */
	public String getCurCode() {
		return curCode;
	}

	/**
	 * Método encargado de actualizar el atributo curCode.
	 * @param curCode Nuevo valor para curCode.
	 */
	public void setCurCode(String curCode) {
		this.curCode = curCode;
	}

	/**
	 * Método encargado de recuperar el valor del atributo curRate.
	 * @return El atributo curRate asociado a la clase.
	 */
	public BigDecimal getCurRate() {
		return curRate;
	}

	/**
	 * Método encargado de actualizar el atributo curRate.
	 * @param curRate Nuevo valor para curRate.
	 */
	public void setCurRate(BigDecimal curRate) {
		this.curRate = curRate;
	}

	/**
	 * Método encargado de recuperar el valor del atributo taxAmt.
	 * @return El atributo taxAmt asociado a la clase.
	 */
	public BigDecimal getTaxAmt() {
		return taxAmt;
	}

	/**
	 * Método encargado de actualizar el atributo taxAmt.
	 * @param taxAmt Nuevo valor para taxAmt.
	 */
	public void setTaxAmt(BigDecimal taxAmt) {
		this.taxAmt = taxAmt;
	}

	/**
	 * Método encargado de recuperar el valor del atributo taxCurCode.
	 * @return El atributo taxCurCode asociado a la clase.
	 */
	public String getTaxCurCode() {
		return taxCurCode;
	}

	/**
	 * Método encargado de actualizar el atributo taxCurCode.
	 * @param taxCurCode Nuevo valor para taxCurCode.
	 */
	public void setTaxCurCode(String taxCurCode) {
		this.taxCurCode = taxCurCode;
	}

	/**
	 * Método encargado de recuperar el valor del atributo taxCurRate.
	 * @return El atributo taxCurRate asociado a la clase.
	 */
	public BigDecimal getTaxCurRate() {
		return taxCurRate;
	}

	/**
	 * Método encargado de actualizar el atributo taxCurRate.
	 * @param taxCurRate Nuevo valor para taxCurRate.
	 */
	public void setTaxCurRate(BigDecimal taxCurRate) {
		this.taxCurRate = taxCurRate;
	}

	/**
	 * Método encargado de recuperar el valor del atributo referenceList.
	 * @return El atributo referenceList asociado a la clase.
	 */
	public List<String> getReferenceList() {
		return referenceList;
	}

	/**
	 * Método encargado de actualizar el atributo referenceList.
	 * @param referenceList Nuevo valor para referenceList.
	 */
	public void setReferenceList(List<String> referenceList) {
		this.referenceList = referenceList;
	}

}
