
package co.com.ath.pgw.client.tokenize.model;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Clase Java para TokenizedDataInfoRs_Type complex type.
 * 
 * <p>El siguiente fragmento de esquema especifica el contenido que se espera que haya en esta clase.
 * 
 * <pre>
 * &lt;complexType name="TokenizedDataInfoRs_Type"&gt;
 *   &lt;complexContent&gt;
 *     &lt;extension base="{urn://ath.com.co/xsd/common/}TokenizedDtInfoRs_Type"&gt;
 *       &lt;sequence&gt;
 *       &lt;/sequence&gt;
 *     &lt;/extension&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "TokenizedDataInfoRs_Type")
public class TokenizedDataInfoRsType
    extends TokenizedDtInfoRsType
{


}
