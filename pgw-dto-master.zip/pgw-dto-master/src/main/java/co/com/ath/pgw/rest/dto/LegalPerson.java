package co.com.ath.pgw.rest.dto;

import java.io.Serializable;
import com.fasterxml.jackson.annotation.JsonProperty;

public class LegalPerson implements Serializable
{

    @JsonProperty("GovIssueIdent")
    private GovIssueIdent govIssueIdent;
    @JsonProperty("PersonName")
    private PersonName personName;
    private final static long serialVersionUID = 5678527688207922973L;

  
    public GovIssueIdent getGovIssueIdent() {
        return govIssueIdent;
    }

    public void setGovIssueIdent(GovIssueIdent govIssueIdent) {
        this.govIssueIdent = govIssueIdent;
    }

    public PersonName getPersonName() {
        return personName;
    }

    public void setPersonName(PersonName personName) {
        this.personName = personName;
    }

}