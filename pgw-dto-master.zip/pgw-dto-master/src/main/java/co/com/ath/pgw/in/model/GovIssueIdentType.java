package co.com.ath.pgw.in.model;

import javax.xml.datatype.XMLGregorianCalendar;

public class GovIssueIdentType {

	protected String govIssueIdentType;

	protected String identSerialNum;

	protected String govOrg;

	protected String govOrgName;

	protected String govRank;

	protected String stateProv;

	protected String country;

	protected String desc;

	protected XMLGregorianCalendar issDt;

	protected XMLGregorianCalendar expDt;

	/**
	 * Obtiene el valor de la propiedad govIssueIdentType.
	 * 
	 * @return possible object is {@link String }
	 * 
	 */
	public String getGovIssueIdentType() {
		return govIssueIdentType;
	}

	/**
	 * Define el valor de la propiedad govIssueIdentType.
	 * 
	 * @param value allowed object is {@link String }
	 * 
	 */
	public void setGovIssueIdentType(String value) {
		this.govIssueIdentType = value;
	}

	/**
	 * Obtiene el valor de la propiedad identSerialNum.
	 * 
	 * @return possible object is {@link String }
	 * 
	 */
	public String getIdentSerialNum() {
		return identSerialNum;
	}

	/**
	 * Define el valor de la propiedad identSerialNum.
	 * 
	 * @param value allowed object is {@link String }
	 * 
	 */
	public void setIdentSerialNum(String value) {
		this.identSerialNum = value;
	}

	/**
	 * Obtiene el valor de la propiedad govOrg.
	 * 
	 * @return possible object is {@link String }
	 * 
	 */
	public String getGovOrg() {
		return govOrg;
	}

	/**
	 * Define el valor de la propiedad govOrg.
	 * 
	 * @param value allowed object is {@link String }
	 * 
	 */
	public void setGovOrg(String value) {
		this.govOrg = value;
	}

	/**
	 * Obtiene el valor de la propiedad govOrgName.
	 * 
	 * @return possible object is {@link String }
	 * 
	 */
	public String getGovOrgName() {
		return govOrgName;
	}

	/**
	 * Define el valor de la propiedad govOrgName.
	 * 
	 * @param value allowed object is {@link String }
	 * 
	 */
	public void setGovOrgName(String value) {
		this.govOrgName = value;
	}

	/**
	 * Obtiene el valor de la propiedad govRank.
	 * 
	 * @return possible object is {@link String }
	 * 
	 */
	public String getGovRank() {
		return govRank;
	}

	/**
	 * Define el valor de la propiedad govRank.
	 * 
	 * @param value allowed object is {@link String }
	 * 
	 */
	public void setGovRank(String value) {
		this.govRank = value;
	}

	/**
	 * Obtiene el valor de la propiedad stateProv.
	 * 
	 * @return possible object is {@link String }
	 * 
	 */
	public String getStateProv() {
		return stateProv;
	}

	/**
	 * Define el valor de la propiedad stateProv.
	 * 
	 * @param value allowed object is {@link String }
	 * 
	 */
	public void setStateProv(String value) {
		this.stateProv = value;
	}

	/**
	 * Obtiene el valor de la propiedad country.
	 * 
	 * @return possible object is {@link String }
	 * 
	 */
	public String getCountry() {
		return country;
	}

	/**
	 * Define el valor de la propiedad country.
	 * 
	 * @param value allowed object is {@link String }
	 * 
	 */
	public void setCountry(String value) {
		this.country = value;
	}

	/**
	 * Obtiene el valor de la propiedad desc.
	 * 
	 * @return possible object is {@link String }
	 * 
	 */
	public String getDesc() {
		return desc;
	}

	/**
	 * Define el valor de la propiedad desc.
	 * 
	 * @param value allowed object is {@link String }
	 * 
	 */
	public void setDesc(String value) {
		this.desc = value;
	}

	/**
	 * Obtiene el valor de la propiedad issDt.
	 * 
	 * @return possible object is {@link XMLGregorianCalendar }
	 * 
	 */
	public XMLGregorianCalendar getIssDt() {
		return issDt;
	}

	/**
	 * Define el valor de la propiedad issDt.
	 * 
	 * @param value allowed object is {@link XMLGregorianCalendar }
	 * 
	 */
	public void setIssDt(XMLGregorianCalendar value) {
		this.issDt = value;
	}

	/**
	 * Obtiene el valor de la propiedad expDt.
	 * 
	 * @return possible object is {@link XMLGregorianCalendar }
	 * 
	 */
	public XMLGregorianCalendar getExpDt() {
		return expDt;
	}

	/**
	 * Define el valor de la propiedad expDt.
	 * 
	 * @param value allowed object is {@link XMLGregorianCalendar }
	 * 
	 */
	public void setExpDt(XMLGregorianCalendar value) {
		this.expDt = value;
	}

}
