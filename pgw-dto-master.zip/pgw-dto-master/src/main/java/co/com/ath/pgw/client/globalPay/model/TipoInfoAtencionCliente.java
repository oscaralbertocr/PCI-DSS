
package co.com.ath.pgw.client.globalPay.model;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Clase Java para TipoInfoAtencionCliente complex type.
 * 
 * <p>El siguiente fragmento de esquema especifica el contenido que se espera que haya en esta clase.
 * 
 * <pre>
 * &lt;complexType name="TipoInfoAtencionCliente"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="direccionContacto" type="{http://www.rbm.com.co/esb/globalpay/}TipoDireccion" minOccurs="0"/&gt;
 *         &lt;element name="telefonoContacto" type="{http://www.rbm.com.co/esb/globalpay/}TipoTelefono" minOccurs="0"/&gt;
 *         &lt;element name="correoElectronicoContacto" type="{http://www.rbm.com.co/esb/globalpay/}TipoCorreoElectronico" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "TipoInfoAtencionCliente", propOrder = {
    "direccionContacto",
    "telefonoContacto",
    "correoElectronicoContacto"
})
public class TipoInfoAtencionCliente {

    protected String direccionContacto;
    protected Long telefonoContacto;
    protected String correoElectronicoContacto;

    /**
     * Obtiene el valor de la propiedad direccionContacto.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDireccionContacto() {
        return direccionContacto;
    }

    /**
     * Define el valor de la propiedad direccionContacto.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDireccionContacto(String value) {
        this.direccionContacto = value;
    }

    /**
     * Obtiene el valor de la propiedad telefonoContacto.
     * 
     * @return
     *     possible object is
     *     {@link Long }
     *     
     */
    public Long getTelefonoContacto() {
        return telefonoContacto;
    }

    /**
     * Define el valor de la propiedad telefonoContacto.
     * 
     * @param value
     *     allowed object is
     *     {@link Long }
     *     
     */
    public void setTelefonoContacto(Long value) {
        this.telefonoContacto = value;
    }

    /**
     * Obtiene el valor de la propiedad correoElectronicoContacto.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCorreoElectronicoContacto() {
        return correoElectronicoContacto;
    }

    /**
     * Define el valor de la propiedad correoElectronicoContacto.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCorreoElectronicoContacto(String value) {
        this.correoElectronicoContacto = value;
    }

}
