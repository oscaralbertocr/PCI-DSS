
package co.com.ath.pgw.rest.dto;

import java.io.Serializable;
import java.util.List;

import javax.validation.Valid;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;

import com.fasterxml.jackson.annotation.JsonProperty;

import co.com.ath.pgw.rest.util.ConstantFormat;



public class ContactInfoAddTx implements Serializable
{

    @JsonProperty("EmailAddr")
    @Pattern( regexp = ConstantFormat.FORMAT_EMAIL_OF_FRONT, message = ConstantFormat.MESSAGE_CARACTER_NO_VALIDOS)
    private String emailAddr;
    
    @JsonProperty("PhoneNum")
    @Valid
    @NotNull
    private PhoneNumAddTx phoneNum;
    
    @JsonProperty("PhoneNums")
    private List<PhoneNumAddTx> phoneNums = null;
    
    @JsonProperty("PostAddr")
    private PostAddrAddTx postAddr;
    
    private final static long serialVersionUID = -4907486557723192652L;

   
    public String getEmailAddr() {
        return emailAddr;
    }

    
    public void setEmailAddr(String emailAddr) {
        this.emailAddr = emailAddr;
    }

       
    public PostAddrAddTx getPostAddr() {
        return postAddr;
    }

    
    public void setPostAddr(PostAddrAddTx postAddr) {
        this.postAddr = postAddr;
    }


	public PhoneNumAddTx getPhoneNum() {
		return phoneNum;
	}


	public void setPhoneNum(PhoneNumAddTx phoneNum) {
		this.phoneNum = phoneNum;
	}


	public List<PhoneNumAddTx> getPhoneNums() {
		return phoneNums;
	}


	public void setPhoneNums(List<PhoneNumAddTx> phoneNums) {
		this.phoneNums = phoneNums;
	}
    
    

 

}