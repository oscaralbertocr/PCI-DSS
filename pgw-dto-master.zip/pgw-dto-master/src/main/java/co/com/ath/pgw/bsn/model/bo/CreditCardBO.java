/*
 * CreditCardVO
 *  
 * GSI - Integración
 * Creado el: 28/08/2014
 *
 * Copyright (c) A Toda Hora S.A. Todos los derechos reservados
 * 
 * Este software es confidencial y es propietario de ATH, queda prohibido
 * su uso, reproducción y copia de manera parcial o permanente salvo autorización
 * expresa de A Toda Hora S.A o de quién represente sus derechos.
 */
package co.com.ath.pgw.bsn.model.bo;


/**
 * Representa una tarjeta de crédito. Esta es una entidad del modelo de negocio.
 * 
 * @author proveedor_japiza
 * @version 1.0 29 Ago 2014
 * @since 1.0
 *
 */
public class CreditCardBO{

	/**
	 * Identificador de la tarjeta de crédito ante el sistema.
	 */
	private Long id;
	
	/**
	 * Número de la tarjeta de crédito.
	 */
	private String number;

	/**
	 * Código de seguridad de la tarjeta de crédito (CSC)
	 */
	private String securityCode;

	/**
	 * Fecha de vencimiento del plástico de la tarjeta de crédito.
	 */
	private String dueDate;

	/**
	 * Marca (o franquicia) de la tarjeta de crédito.
	 */
	private BrandBO brand;

	/**
	 * Titular de la tarjeta de crédito.
	 */
	private CardHolderBO cardHolder;

	/**
	 * Construye una tarjeta de crédito sin datos.
	 */
	public CreditCardBO(){
		super();
	}

	/**
	 * Retorna el identificador de la tarjeta de crédito ante el sistema.
	 * 
	 * @return Identificador de la tarjeta de crédito ante el sistema.
	 */
	public Long getId() {
		return id;
	}

	/**
	 * Establce el identificador de la tarjeta de crédito ante el sistema.
	 * 
	 * @param id Identificador de la tarjeta de crédito ante el sistema.
	 */
	public void setId(Long id) {
		this.id = id;
	}

	/**
	 * Retorna el número de la tarjeta de crédito.
	 * 
	 * @return Número de la tarjeta de crédito.
	 */
	public String getNumber() {
		return number;
	}

	/**
	 * Establece el número de la tarjeta de crédito.
	 * 
	 * @param number Número de la tarjeta de crédito.
	 */
	public void setNumber(String number) {
		this.number = number;
	}

	/**
	 * Retorna el código de seguridad de la tarjeta de crédito (CSC)
	 * @return Código de seguridad de la tarjeta.
	 */
	public String getSecurityCode() {
		return securityCode;
	}

	/**
	 * Establece el código de seguridad de la tarjeta de crédito (CSC)
	 * @param securityCode Código de seguridad de la tarjeta.
	 */
	public void setSecurityCode(String securityCode) {
		this.securityCode = securityCode;
	}

	/**
	 * Retorna la fecha de vencimiento del plástico de la tarjeta de crédito.
	 * @return Fecha de vencimiento de la tarjeta de crédito.
	 */
	public String getDueDate() {
		return dueDate;
	}

	/**
	 * Establece la fecha de vencimiento del plástico de la tarjeta de crédito.
	 * @param dueDate Fecha de vencimiento de la tarjeta de crédito.
	 */
	public void setDueDate(String dueDate) {
		this.dueDate = dueDate;
	}

	/**
	 * Retorna la marca (o franquicia) de la tarjeta de crédito.
	 * 
	 * @return Marca de la tarjeta de crédito.
	 */
	public BrandBO getBrand() {
		return brand;
	}

	/**
	 * Establece la marca (o franquicia) de la tarjeta de crédito.
	 * 
	 * @param brand Marca de la tarjeta de crédito.
	 */
	public void setBrand(BrandBO brand) {
		this.brand = brand;
	}

	/**
	 * Retorna el titular de la tarjeta de crédito. Nombre que aparece impreso
	 * en el plástico.
	 * 
	 * @return Titular de la tarjeta de crédito.
	 */
	public CardHolderBO getCardHolder() {
		return cardHolder;
	}

	/**
	 *  Retorna el titular de la tarjeta de crédito. Nombre que aparece impreso
	 * en el plástico.
	 * 
	 * @param cardHolder Titular de la tarjeta de crédito.
	 */
	public void setCardHolder(CardHolderBO cardHolder) {
		this.cardHolder = cardHolder;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((number == null) ? 0 : number.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		CreditCardBO other = (CreditCardBO) obj;
		if (number == null) {
			if (other.number != null)
				return false;
		} else if (!number.equals(other.number))
			return false;
		return true;
	}

	@Override
	public String toString() {
		return "CreditCardVO [number=" + number + ", brand=" + brand + "]";
	}

}