
package co.com.ath.pgw.rest.request.dto;

import java.io.Serializable;

import javax.validation.Valid;
import javax.validation.constraints.NotNull;

import com.fasterxml.jackson.annotation.JsonProperty;

import co.com.ath.pgw.core.logging.util.XMLUtil;
import co.com.ath.pgw.rest.dto.TokenInfo;

public class TransactionByTokenRequest implements Serializable {

	@JsonProperty("TokenInfo")
	@Valid
	@NotNull
	private TokenInfo tokenInfo;
	
	private static final long serialVersionUID = -1276564696794431430L;

	public TokenInfo getTokenInfo() {
		return tokenInfo;
	}

	public void setTokenInfo(TokenInfo tokenInfo) {
		this.tokenInfo = tokenInfo;
	}

	@Override
	public String toString() {
		XMLUtil<TransactionByTokenRequest> util = new XMLUtil<TransactionByTokenRequest>();
		return util.convertObjectToJson(this);
	}

}
