
package co.com.ath.pgw.client.rbm.v1;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;


/**
 * 
 * @author Jesus Octavio Avendaño <jesus.avendano@sophossolutions.com> 
 * @version 1.0 17/06/2020
 * @since 1.0
 * 
 * <p>Clase Java para anonymous complex type.
 * 
 * <p>El siguiente fragmento de esquema especifica el contenido que se espera que haya en esta clase.
 * 
 * <pre>
 * &lt;complexType>
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element ref="{urn://ath.com.co/payments/v1/}PSETransactionAddRs"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "", propOrder = {
    "pseTransactionAddRs"
})
@XmlRootElement(name = "addPSETransactionResponse")
public class AddPSETransactionResponse {

    @XmlElement(name = "PSETransactionAddRs", required = true)
    protected PSETransactionAddRsType pseTransactionAddRs;

    /**
     * Obtiene el valor de la propiedad pseTransactionAddRs.
     * 
     * @return
     *     possible object is
     *     {@link PSETransactionAddRsType }
     *     
     */
    public PSETransactionAddRsType getPSETransactionAddRs() {
        return pseTransactionAddRs;
    }

    /**
     * Define el valor de la propiedad pseTransactionAddRs.
     * 
     * @param value
     *     allowed object is
     *     {@link PSETransactionAddRsType }
     *     
     */
    public void setPSETransactionAddRs(PSETransactionAddRsType value) {
        this.pseTransactionAddRs = value;
    }

}
