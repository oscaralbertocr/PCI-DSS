package co.com.ath.pgw.in.dto;

import java.util.ArrayList;
import java.util.List;

import co.com.ath.pgw.in.model.RecordTransactionInfoType;
import co.com.ath.pgw.in.model.SvcRsType;


public class HistoricTransactionInqRsType extends SvcRsType
{

    protected List<RecordTransactionInfoType> recordTransactionInfo;

    /**
     * Gets the value of the recordTransactionInfo property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the recordTransactionInfo property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getRecordTransactionInfo().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link RecordTransactionInfoType }
     * 
     * 
     */
    public List<RecordTransactionInfoType> getRecordTransactionInfo() {
        if (recordTransactionInfo == null) {
            recordTransactionInfo = new ArrayList<RecordTransactionInfoType>();
        }
        return this.recordTransactionInfo;
    }
    
    /*
    @Override
	public String toString() {
		XMLUtil<HistoricTransactionInqRsType> requestParser = 
				new XMLUtil<HistoricTransactionInqRsType>();
		return requestParser.convertObjectToXml(this);
	}
	*/
}
