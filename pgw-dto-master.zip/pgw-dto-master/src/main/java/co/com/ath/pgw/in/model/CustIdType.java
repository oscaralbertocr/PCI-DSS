package co.com.ath.pgw.in.model;

public class CustIdType {

    
    protected String custIdType;
    
    protected String custIdNum;
   
    protected String custLoginId;
    
    protected String custPermId;
    
    protected GovIssueIdentType govIssueIdent;
    
    protected CustNameType custName;

    /**
     * Obtiene el valor de la propiedad custIdType.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCustIdType() {
        return custIdType;
    }

    /**
     * Define el valor de la propiedad custIdType.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCustIdType(String value) {
        this.custIdType = value;
    }

    /**
     * Obtiene el valor de la propiedad custIdNum.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCustIdNum() {
        return custIdNum;
    }

    /**
     * Define el valor de la propiedad custIdNum.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCustIdNum(String value) {
        this.custIdNum = value;
    }

    /**
     * Obtiene el valor de la propiedad custLoginId.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCustLoginId() {
        return custLoginId;
    }

    /**
     * Define el valor de la propiedad custLoginId.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCustLoginId(String value) {
        this.custLoginId = value;
    }

	public String getCustPermId() {
		return custPermId;
	}

	public void setCustPermId(String custPermId) {
		this.custPermId = custPermId;
	}

	public GovIssueIdentType getGovIssueIdent() {
		return govIssueIdent;
	}

	public void setGovIssueIdent(GovIssueIdentType govIssueIdent) {
		this.govIssueIdent = govIssueIdent;
	}

	public CustNameType getCustName() {
		return custName;
	}

	public void setCustName(CustNameType custName) {
		this.custName = custName;
	}

}
