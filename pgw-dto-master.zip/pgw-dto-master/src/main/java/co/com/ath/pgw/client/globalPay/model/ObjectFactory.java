
package co.com.ath.pgw.client.globalPay.model;

import javax.xml.bind.annotation.XmlRegistry;


/**
 * This object contains factory methods for each 
 * Java content interface and Java element interface 
 * generated in the co.com.rbm.esb package. 
 * <p>An ObjectFactory allows you to programatically 
 * construct new instances of the Java representation 
 * for XML content. The Java representation of XML 
 * content can consist of schema derived interfaces 
 * and classes representing the binding of schema 
 * type definitions, element declarations and model 
 * groups.  Factory methods for each of these are 
 * provided in this class.
 * 
 */
@XmlRegistry
public class ObjectFactory {


    /**
     * Create a new ObjectFactory that can be used to create new instances of schema derived classes for package: co.com.rbm.esb
     * 
     */
    public ObjectFactory() {
    }

    /**
     * Create an instance of {@link TipoInfoRespuesta }
     * 
     */
    public TipoInfoRespuesta createTipoInfoRespuesta() {
        return new TipoInfoRespuesta();
    }

    /**
     * Create an instance of {@link TipoInfoAdicional }
     * 
     */
    public TipoInfoAdicional createTipoInfoAdicional() {
        return new TipoInfoAdicional();
    }

    /**
     * Create an instance of {@link TipoInfoRefCancelacion }
     * 
     */
    public TipoInfoRefCancelacion createTipoInfoRefCancelacion() {
        return new TipoInfoRefCancelacion();
    }

    /**
     * Create an instance of {@link TipoInfoUbicacion }
     * 
     */
    public TipoInfoUbicacion createTipoInfoUbicacion() {
        return new TipoInfoUbicacion();
    }

    /**
     * Create an instance of {@link TipoIdPersona }
     * 
     */
    public TipoIdPersona createTipoIdPersona() {
        return new TipoIdPersona();
    }

    /**
     * Create an instance of {@link TipoInfoImpuestos }
     * 
     */
    public TipoInfoImpuestos createTipoInfoImpuestos() {
        return new TipoInfoImpuestos();
    }

    /**
     * Create an instance of {@link TipoMontoDetallado }
     * 
     */
    public TipoMontoDetallado createTipoMontoDetallado() {
        return new TipoMontoDetallado();
    }

    /**
     * Create an instance of {@link TipoInfoCHIP }
     * 
     */
    public TipoInfoCHIP createTipoInfoCHIP() {
        return new TipoInfoCHIP();
    }

    /**
     * Create an instance of {@link TipoIdTarjetaDebitoPrivada }
     * 
     */
    public TipoIdTarjetaDebitoPrivada createTipoIdTarjetaDebitoPrivada() {
        return new TipoIdTarjetaDebitoPrivada();
    }

    /**
     * Create an instance of {@link TipoIdCuenta }
     * 
     */
    public TipoIdCuenta createTipoIdCuenta() {
        return new TipoIdCuenta();
    }

    /**
     * Create an instance of {@link TipoIdTarjetaCreditoPrivada }
     * 
     */
    public TipoIdTarjetaCreditoPrivada createTipoIdTarjetaCreditoPrivada() {
        return new TipoIdTarjetaCreditoPrivada();
    }

    /**
     * Create an instance of {@link TipoIdTarjetaCredito }
     * 
     */
    public TipoIdTarjetaCredito createTipoIdTarjetaCredito() {
        return new TipoIdTarjetaCredito();
    }

    /**
     * Create an instance of {@link TipoIdTrack }
     * 
     */
    public TipoIdTrack createTipoIdTrack() {
        return new TipoIdTrack();
    }

    /**
     * Create an instance of {@link TipoInfoAutenticacion }
     * 
     */
    public TipoInfoAutenticacion createTipoInfoAutenticacion() {
        return new TipoInfoAutenticacion();
    }

    /**
     * Create an instance of {@link ConsultarEstadoDePagoFault }
     * 
     */
    public ConsultarEstadoDePagoFault createConsultarEstadoDePagoFault() {
        return new ConsultarEstadoDePagoFault();
    }

    /**
     * Create an instance of {@link FaultInfo }
     * 
     */
    public FaultInfo createFaultInfo() {
        return new FaultInfo();
    }

    /**
     * Create an instance of {@link TipoCabeceraSolicitud }
     * 
     */
    public TipoCabeceraSolicitud createTipoCabeceraSolicitud() {
        return new TipoCabeceraSolicitud();
    }

    /**
     * Create an instance of {@link TipoInfoPago }
     * 
     */
    public TipoInfoPago createTipoInfoPago() {
        return new TipoInfoPago();
    }

    /**
     * Create an instance of {@link TipoCredenciales }
     * 
     */
    public TipoCredenciales createTipoCredenciales() {
        return new TipoCredenciales();
    }

    /**
     * Create an instance of {@link IniciarTransaccionDeCompraFault }
     * 
     */
    public IniciarTransaccionDeCompraFault createIniciarTransaccionDeCompraFault() {
        return new IniciarTransaccionDeCompraFault();
    }

    /**
     * Create an instance of {@link TipoInfoTransaccionResp }
     * 
     */
    public TipoInfoTransaccionResp createTipoInfoTransaccionResp() {
        return new TipoInfoTransaccionResp();
    }

    /**
     * Create an instance of {@link TipoInfoPersona }
     * 
     */
    public TipoInfoPersona createTipoInfoPersona() {
        return new TipoInfoPersona();
    }

    /**
     * Create an instance of {@link TipoInfoCompra }
     * 
     */
    public TipoInfoCompra createTipoInfoCompra() {
        return new TipoInfoCompra();
    }

    /**
     * Create an instance of {@link IniciarTransaccionMultiCompraFault }
     * 
     */
    public IniciarTransaccionMultiCompraFault createIniciarTransaccionMultiCompraFault() {
        return new IniciarTransaccionMultiCompraFault();
    }

    /**
     * Create an instance of {@link TipoInformacionComercio }
     * 
     */
    public TipoInformacionComercio createTipoInformacionComercio() {
        return new TipoInformacionComercio();
    }

    /**
     * Create an instance of {@link TipoInfoDispersionCompra }
     * 
     */
    public TipoInfoDispersionCompra createTipoInfoDispersionCompra() {
        return new TipoInfoDispersionCompra();
    }

    /**
     * Create an instance of {@link ConsultarEstadoMultiCompraFault }
     * 
     */
    public ConsultarEstadoMultiCompraFault createConsultarEstadoMultiCompraFault() {
        return new ConsultarEstadoMultiCompraFault();
    }

    /**
     * Create an instance of {@link TipoInfoDispersionPago }
     * 
     */
    public TipoInfoDispersionPago createTipoInfoDispersionPago() {
        return new TipoInfoDispersionPago();
    }

    /**
     * Create an instance of {@link TipoInfoPuntoInteraccion }
     * 
     */
    public TipoInfoPuntoInteraccion createTipoInfoPuntoInteraccion() {
        return new TipoInfoPuntoInteraccion();
    }

    /**
     * Create an instance of {@link TipoInfoComercio }
     * 
     */
    public TipoInfoComercio createTipoInfoComercio() {
        return new TipoInfoComercio();
    }

    /**
     * Create an instance of {@link TipoInfoAtencionCliente }
     * 
     */
    public TipoInfoAtencionCliente createTipoInfoAtencionCliente() {
        return new TipoInfoAtencionCliente();
    }

}
