
package co.com.ath.pgw.rest.dto;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonProperty;

public class AdditionalData implements Serializable{
	
	@JsonProperty("Name")
    private String name;
	@JsonProperty("Value")
    private String value;
	private static final long serialVersionUID = 1L;

    public AdditionalData() {
    }
    
    public AdditionalData(String name, String value) {
		this.name = name;
		this.value = value;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getValue() {
		return value;
	}

	public void setValue(String value) {
		this.value = value;
	}

}
