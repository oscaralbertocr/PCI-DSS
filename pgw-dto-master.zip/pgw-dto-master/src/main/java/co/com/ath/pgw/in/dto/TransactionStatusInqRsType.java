package co.com.ath.pgw.in.dto;

import java.util.List;

import co.com.ath.pgw.in.model.PersonalDataType;
import co.com.ath.pgw.in.model.PmtWayType;
import co.com.ath.pgw.in.model.TransactionStatusType;

public class TransactionStatusInqRsType {

    
    protected long statusCode;
   
    protected String statusDesc;
    
    protected long rqUID;
    
    protected TransactionStatusType transactionStatus;
    
    protected String pmtId;
   
    protected List<PmtWayType> pmtWay;
    
    protected PersonalDataType personalData;

    /**
     * Obtiene el valor de la propiedad statusCode.
     * 
     */
    public long getStatusCode() {
        return statusCode;
    }

    /**
     * Define el valor de la propiedad statusCode.
     * 
     */
    public void setStatusCode(long value) {
        this.statusCode = value;
    }

    /**
     * Obtiene el valor de la propiedad statusDesc.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getStatusDesc() {
        return statusDesc;
    }

    /**
     * Define el valor de la propiedad statusDesc.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setStatusDesc(String value) {
        this.statusDesc = value;
    }

    /**
     * Obtiene el valor de la propiedad rqUID.
     * 
     */
    public long getRqUID() {
        return rqUID;
    }

    /**
     * Define el valor de la propiedad rqUID.
     * 
     */
    public void setRqUID(long value) {
        this.rqUID = value;
    }

    /**
     * Obtiene el valor de la propiedad transactionStatus.
     * 
     * @return
     *     possible object is
     *     {@link TransactionStatusType }
     *     
     */
    public TransactionStatusType getTransactionStatus() {
        return transactionStatus;
    }

    /**
     * Define el valor de la propiedad transactionStatus.
     * 
     * @param value
     *     allowed object is
     *     {@link TransactionStatusType }
     *     
     */
    public void setTransactionStatus(TransactionStatusType value) {
        this.transactionStatus = value;
    }

    /**
     * Obtiene el valor de la propiedad pmtId.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPmtId() {
        return pmtId;
    }

    /**
     * Define el valor de la propiedad pmtId.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPmtId(String value) {
        this.pmtId = value;
    }
    
    /**
	 * @return the pmtWay
	 */
	public List<PmtWayType> getPmtWay() {
		return pmtWay;
	}

	/**
	 * @param pmtWay the pmtWay to set
	 */
	public void setPmtWay(List<PmtWayType> pmtWay) {
		this.pmtWay = pmtWay;
	}

	/**
	 * @return the personalData
	 */
	public PersonalDataType getPersonalData() {
		return personalData;
	}

	/**
	 * @param personalData the personalData to set
	 */
	public void setPersonalData(PersonalDataType personalData) {
		this.personalData = personalData;
	}
	
	/*
	@Override
	public String toString() {
		XMLUtil<TransactionStatusInqRsType> requestParser = 
				new XMLUtil<TransactionStatusInqRsType>();
		return requestParser.convertObjectToXml(this);
	}
	*/
}
