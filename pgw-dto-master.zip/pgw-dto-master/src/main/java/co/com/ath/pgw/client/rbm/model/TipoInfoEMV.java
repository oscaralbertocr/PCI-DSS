
package co.com.ath.pgw.client.rbm.model;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Clase Java para TipoInfoEMV complex type.
 * 
 * <p>El siguiente fragmento de esquema especifica el contenido que se espera que haya en esta clase.
 * 
 * <pre>
 * &lt;complexType name="TipoInfoEMV"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="datosToken" type="{http://www.w3.org/2001/XMLSchema}string"/&gt;
 *         &lt;element name="datosDiscretos" type="{http://www.w3.org/2001/XMLSchema}string"/&gt;
 *         &lt;element name="estadoToken" type="{http://www.w3.org/2001/XMLSchema}string"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "TipoInfoEMV", propOrder = {
    "datosToken",
    "datosDiscretos",
    "estadoToken"
})
public class TipoInfoEMV {

    @XmlElement(required = true)
    protected String datosToken;
    @XmlElement(required = true)
    protected String datosDiscretos;
    @XmlElement(required = true)
    protected String estadoToken;

    /**
     * Obtiene el valor de la propiedad datosToken.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDatosToken() {
        return datosToken;
    }

    /**
     * Define el valor de la propiedad datosToken.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDatosToken(String value) {
        this.datosToken = value;
    }

    /**
     * Obtiene el valor de la propiedad datosDiscretos.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDatosDiscretos() {
        return datosDiscretos;
    }

    /**
     * Define el valor de la propiedad datosDiscretos.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDatosDiscretos(String value) {
        this.datosDiscretos = value;
    }

    /**
     * Obtiene el valor de la propiedad estadoToken.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getEstadoToken() {
        return estadoToken;
    }

    /**
     * Define el valor de la propiedad estadoToken.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setEstadoToken(String value) {
        this.estadoToken = value;
    }

}
