
package co.com.ath.pgw.in.dto;

import javax.xml.datatype.XMLGregorianCalendar;


/**
 * <p>Clase Java para PSEFinalizeTransactionModRq_Type complex type.
 * 
 * <p>El siguiente fragmento de esquema especifica el contenido que se espera que haya en esta clase.
 * 
 * <pre>
 * &lt;complexType name="PSEFinalizeTransactionModRq_Type">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element ref="{urn://ath.com.co/xsd/common/}RqUID"/>
 *         &lt;element ref="{urn://ath.com.co/xsd/common/}Channel"/>
 *         &lt;element ref="{urn://ath.com.co/xsd/common/}ClientDt"/>
 *         &lt;element ref="{urn://ath.com.co/xsd/common/}IPAddr"/>
 *         &lt;element ref="{urn://ath.com.co/xsd/common/}PmtId"/>
 *         &lt;element ref="{urn://ath.com.co/xsd/common/}ApprovalId"/>
 *         &lt;element ref="{urn://ath.com.co/xsd/common/}NIT"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
public class PSEFinalizeTransactionModRqType {

    
    protected long rqUID;
   
    protected String channel;
 
    protected XMLGregorianCalendar clientDt;
  
    protected String ipAddr;
  
    protected String pmtId;
    
    protected String approvalId;
  
    protected String nit;

    /**
     * Obtiene el valor de la propiedad rqUID.
     * 
     */
    public long getRqUID() {
        return rqUID;
    }

    /**
     * Define el valor de la propiedad rqUID.
     * 
     */
    public void setRqUID(long value) {
        this.rqUID = value;
    }

    /**
     * Obtiene el valor de la propiedad channel.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getChannel() {
        return channel;
    }

    /**
     * Define el valor de la propiedad channel.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setChannel(String value) {
        this.channel = value;
    }

    /**
     * Obtiene el valor de la propiedad clientDt.
     * 
     * @return
     *     possible object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public XMLGregorianCalendar getClientDt() {
        return clientDt;
    }

    /**
     * Define el valor de la propiedad clientDt.
     * 
     * @param value
     *     allowed object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public void setClientDt(XMLGregorianCalendar value) {
        this.clientDt = value;
    }

    /**
     * Obtiene el valor de la propiedad ipAddr.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getIPAddr() {
        return ipAddr;
    }

    /**
     * Define el valor de la propiedad ipAddr.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setIPAddr(String value) {
        this.ipAddr = value;
    }

    /**
     * Obtiene el valor de la propiedad pmtId.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPmtId() {
        return pmtId;
    }

    /**
     * Define el valor de la propiedad pmtId.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPmtId(String value) {
        this.pmtId = value;
    }

    /**
     * Obtiene el valor de la propiedad approvalId.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getApprovalId() {
        return approvalId;
    }

    /**
     * Define el valor de la propiedad approvalId.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setApprovalId(String value) {
        this.approvalId = value;
    }

    /**
     * Obtiene el valor de la propiedad nit.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getNIT() {
        return nit;
    }

    /**
     * Define el valor de la propiedad nit.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setNIT(String value) {
        this.nit = value;
    }

}
