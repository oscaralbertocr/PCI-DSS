package co.com.ath.pgw.rest.dto;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonProperty;

public class AdditionalDepAcctId implements Serializable {
	 /**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	/**
	 * 
	 */
		@JsonProperty("DepAcctId")
	    private DepAcctId depAcctId;
		@JsonProperty("BankInfo")
	    private BankInfo bankInfo;
		@JsonProperty("RefInfo")
	    private RefInfo refInfo;
		public DepAcctId getDepAcctId() {
			return depAcctId;
		}
		public void setDepAcctId(DepAcctId depAcctId) {
			this.depAcctId = depAcctId;
		}
		public BankInfo getBankInfo() {
			return bankInfo;
		}
		public void setBankInfo(BankInfo bankInfo) {
			this.bankInfo = bankInfo;
		}
		public RefInfo getRefInfo() {
			return refInfo;
		}
		public void setRefInfo(RefInfo refInfo) {
			this.refInfo = refInfo;
		}
	   


}
