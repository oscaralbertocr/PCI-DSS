
package co.com.ath.pgw.in.model;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;

/**
*
* @author camilo.bustamante@sophossolutions.com
* @version 1.0 03 Enero 2019
* @RQ31686 RBM_Integracion_Boton_TC_GlobalPay
* 
*/

/**
 * <p>Clase Java para CabeceraSolicitud_Type complex type.
 * 
 * <p>El siguiente fragmento de esquema especifica el contenido que se espera que haya en esta clase.
 * 
 * <pre>
 * &lt;complexType name="CabeceraSolicitud_Type">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element ref="{urn://ath.com.co/xsd/common/}InfoPuntoInteraccion" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
public class CabeceraSolicitudType {
    
    protected InfoPuntoInteraccionType infoPuntoInteraccion;

	public InfoPuntoInteraccionType getInfoPuntoInteraccion() {
		return infoPuntoInteraccion;
	}

	public void setInfoPuntoInteraccion(InfoPuntoInteraccionType infoPuntoInteraccion) {
		this.infoPuntoInteraccion = infoPuntoInteraccion;
	}

    
}
