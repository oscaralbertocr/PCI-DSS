package co.com.ath.pgw.in.model;



public class InvoiceReferenceType {

   
    protected String invoiceType;
    
    protected String invoiceId;
   
    protected String pmtCodNIE;

    /**
     * Obtiene el valor de la propiedad invoiceType.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getInvoiceType() {
        return invoiceType;
    }

    /**
     * Define el valor de la propiedad invoiceType.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setInvoiceType(String value) {
        this.invoiceType = value;
    }

    /**
     * Obtiene el valor de la propiedad invoiceId.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getInvoiceId() {
        return invoiceId;
    }

    /**
     * Define el valor de la propiedad invoiceId.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setInvoiceId(String value) {
        this.invoiceId = value;
    }

    /**
     * Obtiene el valor de la propiedad pmtCodNIE.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPmtCodNIE() {
        return pmtCodNIE;
    }

    /**
     * Define el valor de la propiedad pmtCodNIE.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPmtCodNIE(String value) {
        this.pmtCodNIE = value;
    }

}
