package co.com.ath.pgw.in.dto;

import java.math.BigInteger;
import java.util.ArrayList;
import java.util.List;

import co.com.ath.pgw.in.model.AgreementInfoType;
import co.com.ath.pgw.in.model.BankInfoType;
import co.com.ath.pgw.in.model.CompanyDetailType;
import co.com.ath.pgw.in.model.CompanyType;
import co.com.ath.pgw.in.model.IdRequiredType;
import co.com.ath.pgw.in.model.IndicatorType;
import co.com.ath.pgw.in.model.LabelRefType;
import co.com.ath.pgw.in.model.MeansFieldPmtType;
import co.com.ath.pgw.in.model.MeansRequiredType;
import co.com.ath.pgw.in.model.PersonalDataType;
import co.com.ath.pgw.in.model.ProductInfoType;
import co.com.ath.pgw.in.model.ReferenceType;
import co.com.ath.pgw.in.model.SvcRqType;
import co.com.ath.pgw.in.model.TransactionInfoType;
import co.com.ath.pgw.in.model.WordListType;

public class AgreementSynchronizationRqType extends SvcRqType
{

    
    protected String admType;    
    protected String trnChannel;    
    protected CompanyType company;    
    protected CompanyDetailType companyDetail;    
    protected IndicatorType indicator;
  
    protected List<TransactionInfoType> transactionInfo;
   
    protected List<LabelRefType> labelRef;
   
    protected String pmtId;
 
    protected String categoryId;
   
    protected BigInteger instalamentsNum;
   
    protected String modelType;
   
    protected String userType;
  
    protected MeansRequiredType meansRequired;
   
    protected MeansFieldPmtType meansFieldPay;
   
    protected List<WordListType> wordList;
   
    protected ProductInfoType productInfo; 
    
    protected IdRequiredType idRequired;
    
    protected PersonalDataType personalData;
   
    protected AgreementInfoType agreementInfo;
    
    protected BankInfoType bankInfo;
    
    protected List<ReferenceType> reference;

    /**
     * Obtiene el valor de la propiedad admType.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getAdmType() {
        return admType;
    }

    /**
     * Define el valor de la propiedad admType.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setAdmType(String value) {
        this.admType = value;
    }

    /**
     * Obtiene el valor de la propiedad trnChannel.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getTrnChannel() {
        return trnChannel;
    }

    /**
     * Define el valor de la propiedad trnChannel.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setTrnChannel(String value) {
        this.trnChannel = value;
    }

    /**
     * Obtiene el valor de la propiedad company.
     * 
     * @return
     *     possible object is
     *     {@link CompanyType }
     *     
     */
    public CompanyType getCompany() {
        return company;
    }

    /**
     * Define el valor de la propiedad company.
     * 
     * @param value
     *     allowed object is
     *     {@link CompanyType }
     *     
     */
    public void setCompany(CompanyType value) {
        this.company = value;
    }

    /**
     * Obtiene el valor de la propiedad companyDetail.
     * 
     * @return
     *     possible object is
     *     {@link CompanyDetailType }
     *     
     */
    public CompanyDetailType getCompanyDetail() {
        return companyDetail;
    }

    /**
     * Define el valor de la propiedad companyDetail.
     * 
     * @param value
     *     allowed object is
     *     {@link CompanyDetailType }
     *     
     */
    public void setCompanyDetail(CompanyDetailType value) {
        this.companyDetail = value;
    }

    /**
     * Obtiene el valor de la propiedad indicator.
     * 
     * @return
     *     possible object is
     *     {@link IndicatorType }
     *     
     */
    public IndicatorType getIndicator() {
        return indicator;
    }

    /**
     * Define el valor de la propiedad indicator.
     * 
     * @param value
     *     allowed object is
     *     {@link IndicatorType }
     *     
     */
    public void setIndicator(IndicatorType value) {
        this.indicator = value;
    }

    /**
     * Gets the value of the transactionInfo property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the transactionInfo property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getTransactionInfo().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link TransactionInfoType }
     * 
     * 
     */
    public List<TransactionInfoType> getTransactionInfo() {
        if (transactionInfo == null) {
            transactionInfo = new ArrayList<TransactionInfoType>();
        }
        return this.transactionInfo;
    }

    /**
     * Gets the value of the labelRef property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the labelRef property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getLabelRef().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link LabelRefType }
     * 
     * 
     */
    public List<LabelRefType> getLabelRef() {
        if (labelRef == null) {
            labelRef = new ArrayList<LabelRefType>();
        }
        return this.labelRef;
    }

    /**
     * Obtiene el valor de la propiedad pmtId.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPmtId() {
        return pmtId;
    }

    /**
     * Define el valor de la propiedad pmtId.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPmtId(String value) {
        this.pmtId = value;
    }

    /**
     * Obtiene el valor de la propiedad categoryId.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCategoryId() {
        return categoryId;
    }

    /**
     * Define el valor de la propiedad categoryId.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCategoryId(String value) {
        this.categoryId = value;
    }

    /**
     * Obtiene el valor de la propiedad instalamentsNum.
     * 
     * @return
     *     possible object is
     *     {@link BigInteger }
     *     
     */
    public BigInteger getInstalamentsNum() {
        return instalamentsNum;
    }

    /**
     * Define el valor de la propiedad instalamentsNum.
     * 
     * @param value
     *     allowed object is
     *     {@link BigInteger }
     *     
     */
    public void setInstalamentsNum(BigInteger value) {
        this.instalamentsNum = value;
    }

    /**
     * Obtiene el valor de la propiedad modelType.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getModelType() {
        return modelType;
    }

    /**
     * Define el valor de la propiedad modelType.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setModelType(String value) {
        this.modelType = value;
    }

    /**
     * Obtiene el valor de la propiedad userType.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getUserType() {
        return userType;
    }

    /**
     * Define el valor de la propiedad userType.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setUserType(String value) {
        this.userType = value;
    }

    /**
     * Obtiene el valor de la propiedad meansRequired.
     * 
     * @return
     *     possible object is
     *     {@link MeansRequiredType }
     *     
     */
    public MeansRequiredType getMeansRequired() {
        return meansRequired;
    }

    /**
     * Define el valor de la propiedad meansRequired.
     * 
     * @param value
     *     allowed object is
     *     {@link MeansRequiredType }
     *     
     */
    public void setMeansRequired(MeansRequiredType value) {
        this.meansRequired = value;
    }

    /**
     * Obtiene el valor de la propiedad meansFieldPay.
     * 
     * @return
     *     possible object is
     *     {@link MeansFieldPmtType }
     *     
     */
    public MeansFieldPmtType getMeansFieldPay() {
        return meansFieldPay;
    }

    /**
     * Define el valor de la propiedad meansFieldPay.
     * 
     * @param value
     *     allowed object is
     *     {@link MeansFieldPmtType }
     *     
     */
    public void setMeansFieldPay(MeansFieldPmtType value) {
        this.meansFieldPay = value;
    }

    /**
     * Gets the value of the wordList property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the wordList property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getWordList().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link WordListType }
     * 
     * 
     */
    public List<WordListType> getWordList() {
        if (wordList == null) {
            wordList = new ArrayList<WordListType>();
        }
        return this.wordList;
    }

    /**
     * Obtiene el valor de la propiedad productInfo.
     * 
     * @return
     *     possible object is
     *     {@link ProductInfoType }
     *     
     */
    public ProductInfoType getProductInfo() {
        return productInfo;
    }

    /**
     * Define el valor de la propiedad productInfo.
     * 
     * @param value
     *     allowed object is
     *     {@link ProductInfoType }
     *     
     */
    public void setProductInfo(ProductInfoType value) {
        this.productInfo = value;
    }

    /**
     * Obtiene el valor de la propiedad idRequired.
     * 
     * @return
     *     possible object is
     *     {@link IdRequiredType }
     *     
     */
    public IdRequiredType getIdRequired() {
        return idRequired;
    }

    /**
     * Define el valor de la propiedad idRequired.
     * 
     * @param value
     *     allowed object is
     *     {@link IdRequiredType }
     *     
     */
    public void setIdRequired(IdRequiredType value) {
        this.idRequired = value;
    }

    /**
     * Obtiene el valor de la propiedad personalData.
     * 
     * @return
     *     possible object is
     *     {@link PersonalDataType }
     *     
     */
    public PersonalDataType getPersonalData() {
        return personalData;
    }

    /**
     * Define el valor de la propiedad personalData.
     * 
     * @param value
     *     allowed object is
     *     {@link PersonalDataType }
     *     
     */
    public void setPersonalData(PersonalDataType value) {
        this.personalData = value;
    }

    /**
     * Obtiene el valor de la propiedad agreementInfo.
     * 
     * @return
     *     possible object is
     *     {@link AgreementInfoType }
     *     
     */
    public AgreementInfoType getAgreementInfo() {
        return agreementInfo;
    }

    /**
     * Define el valor de la propiedad agreementInfo.
     * 
     * @param value
     *     allowed object is
     *     {@link AgreementInfoType }
     *     
     */
    public void setAgreementInfo(AgreementInfoType value) {
        this.agreementInfo = value;
    }

    /**
     * Obtiene el valor de la propiedad bankInfo.
     * 
     * @return
     *     possible object is
     *     {@link BankInfoType }
     *     
     */
    public BankInfoType getBankInfo() {
        return bankInfo;
    }

    /**
     * Define el valor de la propiedad bankInfo.
     * 
     * @param value
     *     allowed object is
     *     {@link BankInfoType }
     *     
     */
    public void setBankInfo(BankInfoType value) {
        this.bankInfo = value;
    }

    /**
     * Gets the value of the reference property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the reference property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getReference().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link ReferenceType }
     * 
     * 
     */
    public List<ReferenceType> getReference() {
        if (reference == null) {
            reference = new ArrayList<ReferenceType>();
        }
        return this.reference;
    }
    
    /*
    @Override
    public String toString() {
    	XMLUtil<AgreementSynchronizationRqType> requestParser = 
    							new XMLUtil<AgreementSynchronizationRqType>();
		return requestParser.convertObjectToXml(this);
    }
	*/

}
