/*
 * CommerceContactVO
 *  
 * GSI - Integración
 * Creado el: 29/08/2014
 *
 * Copyright (c) A Toda Hora S.A. Todos los derechos reservados
 * 
 * Este software es confidencial y es propietario de ATH, queda prohibido
 * su uso, reproducción y copia de manera parcial o permanente salvo autorización
 * expresa de A Toda Hora S.A o de quién represente sus derechos.
 */
package co.com.ath.pgw.bsn.model.bo;


/**
 * Contacto de un comercio.
 * 
 * @author proveedor_japiza
 * @version 1.0 29 Ago 2014
 * @since 1.0
 */
public class CommerceContactBO{

	/**
	 * Comercio al que pertenece el contacto.
	 */
	private CommerceBO commerce;

	/**
	 * Rol del contacto en la pasarela para el comercio.
	 */
	private CommerceRoleContactBO role;

	/**
	 * Nombre del contacto.
	 */
	private String name;

	/**
	 * Número celualar del contacto.
	 */
	private String mobilePhone;

	/**
	 * Correo electrónico del contacto.
	 */
	private String email;

	/**
	 * Construye un contacto de un comercio.
	 */
	public CommerceContactBO(){
		super();
	}

	/**
	 * Retorna el comercio al que pertenece el contacto.
	 * 
	 * @return Comercio al que pertenece el contacto.
	 */
	public CommerceBO getCommerce() {
		return commerce;
	}

	/**
	 * Establece le comercio al que pertenece el contacto.
	 * 
	 * @param commerce Comercio al que pertenece el contacto.
	 */
	public void setCommerce(CommerceBO commerce) {
		this.commerce = commerce;
	}

	/**
	 * Retorna el rol del contacto para el comercio.
	 * 
	 * @return Rol del contacto para el comercio.
	 */
	public CommerceRoleContactBO getRole() {
		return role;
	}

	/**
	 * Establece el rol del contacto para el comercio.
	 * 
	 * @param role Rol del contacto para el comercio.
	 */
	public void setRole(CommerceRoleContactBO role) {
		this.role = role;
	}
	
	/**
	 * Retorna el nombre del contacto.
	 * 
	 * @return Nombre del contacto.
	 */
	public String getName(){
		return name;
	}

	/**
	 * Establece el nombre del contacto.
	 * 
	 * @param name Nombre del contacto.
	 */
	public void setName(String name){
		this.name = name;
	}

	/**
	 * Retorna el número celular del contacto.
	 * 
	 * @return Número celular del contacto.
	 */
	public String getMobilePhone(){
		return mobilePhone;
	}

	/**
	 * Establece el número celular del contacto.
	 * 
	 * @param mobilePhone Número celular del contacto.
	 */
	public void setMobilePhone(String mobilePhone){
		this.mobilePhone = mobilePhone;
	}

	/**
	 * Retorna el correo electrónico del contacto.
	 * 
	 * @return Correo electrónico del contacto.
	 */
	public String getEmail(){
		return email;
	}

	/**
	 * Establece el correo electrónico del contacto.
	 * 
	 * @param email Correo electrónico del contacto.
	 */
	public void setEmail(String email){
		this.email = email;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result
				+ ((commerce == null) ? 0 : commerce.hashCode());
		result = prime * result + ((role == null) ? 0 : role.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		CommerceContactBO other = (CommerceContactBO) obj;
		if (commerce == null) {
			if (other.commerce != null)
				return false;
		} else if (!commerce.equals(other.commerce))
			return false;
		if (role == null) {
			if (other.role != null)
				return false;
		} else if (!role.equals(other.role))
			return false;
		return true;
	}

	@Override
	public String toString() {
		return "CommerceContactVO [commerce=" + commerce + ", role=" + role
				+ ", name=" + name + "]";
	}
	
}