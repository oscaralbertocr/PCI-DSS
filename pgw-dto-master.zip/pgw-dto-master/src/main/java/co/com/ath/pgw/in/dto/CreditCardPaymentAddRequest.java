package co.com.ath.pgw.in.dto;

import co.com.ath.pgw.core.logging.util.XMLUtil;

/**
 * <p>Clase Java para anonymous complex type.
 * 
 * <p>El siguiente fragmento de esquema especifica el contenido que se espera que haya en esta clase.
 * 
 * <pre>
 * &lt;complexType&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element ref="{urn://grupoaval.com/payments/v1/}CreditCardPaymentAddRq"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
public class CreditCardPaymentAddRequest {

    protected CreditCardPaymentAddRqType creditCardPaymentAddRq = new CreditCardPaymentAddRqType();

    /**
     * Obtiene el valor de la propiedad creditCardPaymentAddRq.
     * 
     * @return
     *     possible object is
     *     {@link CreditCardPaymentAddRqType }
     *     
     */
    public CreditCardPaymentAddRqType getCreditCardPaymentAddRq() {
        return creditCardPaymentAddRq;
    }

    /**
     * Define el valor de la propiedad creditCardPaymentAddRq.
     * 
     * @param value
     *     allowed object is
     *     {@link CreditCardPaymentAddRqType }
     *     
     */
    public void setCreditCardPaymentAddRq(CreditCardPaymentAddRqType value) {
        this.creditCardPaymentAddRq = value;
    }
    
    @Override
   	public String toString() {
   		XMLUtil<CreditCardPaymentAddRequest> requestParser = 
   				new XMLUtil<CreditCardPaymentAddRequest>();
   		return requestParser.convertObjectToXml(this);
   	}

}