/**
 * Objetos de negocio.
 * 
 * @author proveedor_zagarcia
 * @author proveedor_mamendez
 * @version 1.0 17 Sep 2014
 * @since 1.0
 *
 */
package co.com.ath.pgw.bsn.model.bo;