package co.com.ath.pgw.rest.response.dto;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonProperty;

import co.com.ath.pgw.core.logging.util.XMLUtil;
import co.com.ath.pgw.rest.dto.InvoicePmtInfo;
import co.com.ath.pgw.rest.dto.RefInfo;
import co.com.ath.pgw.rest.dto.TokenInfo;
import co.com.ath.pgw.rest.dto.TransactionStatus;

public class PSETxvcPaymentResponse implements Serializable {

	@JsonProperty("InvoicePmtInfo")
	private InvoicePmtInfo invoicePmtInfo;
	@JsonProperty("TransactionStatus")
	private TransactionStatus transactionStatus;
	@JsonProperty("TokenInfo")
	private TokenInfo tokenInfo;
	@JsonProperty("RefInfo")
	private List<RefInfo> refInfo = null;
	private static final long serialVersionUID = -6365228082330220442L;

	public InvoicePmtInfo getInvoicePmtInfo() {
		return invoicePmtInfo;
	}

	public void setInvoicePmtInfo(InvoicePmtInfo invoicePmtInfo) {
		this.invoicePmtInfo = invoicePmtInfo;
	}

	public TokenInfo getTokenInfo() {
		return tokenInfo;
	}

	public void setTokenInfo(TokenInfo tokenInfo) {
		this.tokenInfo = tokenInfo;
	}

	public List<RefInfo> getRefInfo() {
		if (refInfo == null) {
			refInfo = new ArrayList<RefInfo>();
        }
		return refInfo;
	}

	public void setRefInfo(List<RefInfo> refInfo) {
		this.refInfo = refInfo;
	}

	@Override
	public String toString() {
		XMLUtil<PSETxvcPaymentResponse> util = new XMLUtil<PSETxvcPaymentResponse>();
		return util.convertObjectToJson(this);
	}

	public TransactionStatus getTransactionStatus() {
		return transactionStatus;
	}

	public void setTransactionStatus(TransactionStatus transactionStatus) {
		this.transactionStatus = transactionStatus;
	}
	
	

}