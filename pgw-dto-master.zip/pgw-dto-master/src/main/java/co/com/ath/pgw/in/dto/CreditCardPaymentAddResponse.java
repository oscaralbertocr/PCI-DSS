package co.com.ath.pgw.in.dto;

import co.com.ath.pgw.core.logging.util.XMLUtil;

/**
 * <p>Clase Java para anonymous complex type.
 * 
 * <p>El siguiente fragmento de esquema especifica el contenido que se espera que haya en esta clase.
 * 
 * <pre>
 * &lt;complexType&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element ref="{urn://grupoaval.com/payments/v1/}CreditCardPaymentAddRs"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
public class CreditCardPaymentAddResponse {
	
    protected CreditCardPaymentAddRsType creditCardPaymentAddRs = new CreditCardPaymentAddRsType();

    /**
     * Obtiene el valor de la propiedad creditCardPaymentAddRs.
     * 
     * @return
     *     possible object is
     *     {@link CreditCardPaymentAddRsType }
     *     
     */
    public CreditCardPaymentAddRsType getCreditCardPaymentAddRs() {
        return creditCardPaymentAddRs;
    }

    /**
     * Define el valor de la propiedad creditCardPaymentAddRs.
     * 
     * @param value
     *     allowed object is
     *     {@link CreditCardPaymentAddRsType }
     *     
     */
    public void setCreditCardPaymentAddRs(CreditCardPaymentAddRsType value) {
        this.creditCardPaymentAddRs = value;
    }
    
    @Override
   	public String toString() {
   		XMLUtil<CreditCardPaymentAddResponse> requestParser = 
   				new XMLUtil<CreditCardPaymentAddResponse>();
   		return requestParser.convertObjectToXml(this);
   	}

}