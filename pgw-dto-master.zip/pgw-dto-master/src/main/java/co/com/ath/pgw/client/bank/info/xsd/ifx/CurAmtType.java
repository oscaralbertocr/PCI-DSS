
package co.com.ath.pgw.client.bank.info.xsd.ifx;

import java.math.BigDecimal;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;

import co.com.ath.pgw.core.logging.util.XMLUtil;


/**
 * <p>Clase Java para CurAmt_Type complex type.
 * 
 * <p>El siguiente fragmento de esquema especifica el contenido que se espera que haya en esta clase.
 * 
 * <pre>
 * &lt;complexType name="CurAmt_Type">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element ref="{urn://grupoaval.com/xsd/ifx/}Amt"/>
 *         &lt;element ref="{urn://grupoaval.com/xsd/ifx/}CurCode" minOccurs="0"/>
 *         &lt;sequence minOccurs="0">
 *           &lt;element ref="{urn://grupoaval.com/xsd/ifx/}CurRate" minOccurs="0"/>
 *           &lt;element ref="{urn://grupoaval.com/xsd/ifx/}CurConvertRule" minOccurs="0"/>
 *         &lt;/sequence>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "CurAmt_Type", propOrder = {
    "amt",
    "curCode",
    "curRate",
    "curConvertRule"
})
public class CurAmtType {

    @XmlElement(name = "Amt", required = true)
    protected BigDecimal amt;
    @XmlElement(name = "CurCode")
    protected String curCode;
    @XmlElement(name = "CurRate")
    protected BigDecimal curRate;
    @XmlElement(name = "CurConvertRule")
    protected CurConvertRuleType curConvertRule;

    /**
     * Obtiene el valor de la propiedad amt.
     * 
     * @return
     *     possible object is
     *     {@link BigDecimal }
     *     
     */
    public BigDecimal getAmt() {
        return amt;
    }

    /**
     * Define el valor de la propiedad amt.
     * 
     * @param value
     *     allowed object is
     *     {@link BigDecimal }
     *     
     */
    public void setAmt(BigDecimal value) {
        this.amt = value;
    }

    /**
     * Obtiene el valor de la propiedad curCode.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCurCode() {
        return curCode;
    }

    /**
     * Define el valor de la propiedad curCode.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCurCode(String value) {
        this.curCode = value;
    }

    /**
     * Obtiene el valor de la propiedad curRate.
     * 
     * @return
     *     possible object is
     *     {@link BigDecimal }
     *     
     */
    public BigDecimal getCurRate() {
        return curRate;
    }

    /**
     * Define el valor de la propiedad curRate.
     * 
     * @param value
     *     allowed object is
     *     {@link BigDecimal }
     *     
     */
    public void setCurRate(BigDecimal value) {
        this.curRate = value;
    }

    /**
     * Obtiene el valor de la propiedad curConvertRule.
     * 
     * @return
     *     possible object is
     *     {@link CurConvertRuleType }
     *     
     */
    public CurConvertRuleType getCurConvertRule() {
        return curConvertRule;
    }

    /**
     * Define el valor de la propiedad curConvertRule.
     * 
     * @param value
     *     allowed object is
     *     {@link CurConvertRuleType }
     *     
     */
    public void setCurConvertRule(CurConvertRuleType value) {
        this.curConvertRule = value;
    }
    
    public String toString() {
    	XMLUtil<CurAmtType> requestParser = 
    							new XMLUtil<CurAmtType>();
		return requestParser.convertObjectToXml(this);
    }

}
