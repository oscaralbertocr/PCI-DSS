package co.com.ath.pgw.rest.dto;

import com.fasterxml.jackson.annotation.JsonProperty;

public class RoleInfo {

	@JsonProperty(value = "RoleInfoId")
	private Long roleInfoId;
	@JsonProperty(value = "RoleInfoType")
	private String roleInfoType;
	@JsonProperty(value = "RoleInfoDesc")
	private String roleInfoDesc;
	@JsonProperty(value = "Name")
	private String name;

	public Long getRoleInfoId() {
		return roleInfoId;
	}

	public void setRoleInfoId(Long roleInfoId) {
		this.roleInfoId = roleInfoId;
	}

	public String getRoleInfoType() {
		return roleInfoType;
	}

	public void setRoleInfoType(String roleInfoType) {
		this.roleInfoType = roleInfoType;
	}

	public String getRoleInfoDesc() {
		return roleInfoDesc;
	}

	public void setRoleInfoDesc(String roleInfoDesc) {
		this.roleInfoDesc = roleInfoDesc;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

}
