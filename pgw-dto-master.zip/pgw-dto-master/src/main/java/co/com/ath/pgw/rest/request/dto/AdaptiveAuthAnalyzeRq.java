package co.com.ath.pgw.rest.request.dto;

import java.io.Serializable;

import co.com.ath.pgw.bsn.model.bo.TransactionBO;

public class AdaptiveAuthAnalyzeRq implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 2006702434855872981L;
	String runRiskType;
	TransactionBO transactionBO;
	
	public AdaptiveAuthAnalyzeRq(String runRiskType, TransactionBO transactionBO) {
		super();
		this.runRiskType = runRiskType;
		this.transactionBO = transactionBO;
	}
	public String getRunRiskType() {
		return runRiskType;
	}
	public void setRunRiskType(String runRiskType) {
		this.runRiskType = runRiskType;
	}
	public TransactionBO getTransactionBO() {
		return transactionBO;
	}
	public void setTransactionBO(TransactionBO transactionBO) {
		this.transactionBO = transactionBO;
	}
	
}
