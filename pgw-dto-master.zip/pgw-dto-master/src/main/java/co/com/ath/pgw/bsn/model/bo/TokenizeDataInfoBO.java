/*
 * BankVO
 *  
 * GSI - Integración
 * Creado el: 28/08/2014
 *
 * Copyright (c) A Toda Hora S.A. Todos los derechos reservados
 * 
 * Este software es confidencial y es propietario de ATH, queda prohibido
 * su uso, reproducción y copia de manera parcial o permanente salvo autorización
 * expresa de A Toda Hora S.A o de quién represente sus derechos.
 */
package co.com.ath.pgw.bsn.model.bo;

/**
 * Clase que representa un Banco del sistema financiero colombiano, esta entidad
 * pertenece al modelo de negocio.
 *
 * @author proveedor_lbonilla
 * @version 1.0 
 */
public class TokenizeDataInfoBO{

	/**
	 * 
	 */
	private String idSecKey;
	
	/**
	 * 
	 */
	private ProtectBO protect;
	
	/**
	 * 
	 */
	private AuthBO auth;
	
	

	public String getIdSecKey() {
		return idSecKey;
	}


	public void setIdSecKey(String idSecKey) {
		this.idSecKey = idSecKey;
	}


	public ProtectBO getProtect() {
		return protect;
	}


	public void setProtect(ProtectBO protect) {
		this.protect = protect;
	}


	public AuthBO getAuth() {
		return auth;
	}


	public void setAuth(AuthBO auth) {
		this.auth = auth;
	}

}