
package co.com.ath.pgw.in.model;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;

/**
*
* @author camilo.bustamante@sophossolutions.com
* @version 1.0 03 Enero 2019
* @RQ31686 RBM_Integracion_Boton_TC_GlobalPay
* 
*/

/**
 * <p>Clase Java para InfoPuntoInteraccion_Type complex type.
 * 
 * <p>El siguiente fragmento de esquema especifica el contenido que se espera que haya en esta clase.
 * 
 * <pre>
 * &lt;complexType name="InfoPuntoInteraccion_Type">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element ref="{urn://ath.com.co/xsd/common/}TipoTerminal" minOccurs="0"/>
 *         &lt;element ref="{urn://ath.com.co/xsd/common/}IdTerminal" minOccurs="0"/>
 *         &lt;element ref="{urn://ath.com.co/xsd/common/}IdAdquiriente" minOccurs="0"/>
 *         &lt;element ref="{urn://ath.com.co/xsd/common/}IdTransaccionTerminal" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
public class InfoPuntoInteraccionType {
    
    protected String tipoTerminal;
    
    protected String idTerminal;
    
    protected String idAdquiriente;
    
    
    protected String idTransaccionTerminal;
	
    
	public String getTipoTerminal() {
		return tipoTerminal;
	}

	public void setTipoTerminal(String tipoTerminal) {
		this.tipoTerminal = tipoTerminal;
	}

	public String getIdTerminal() {
		return idTerminal;
	}

	public void setIdTerminal(String idTerminal) {
		this.idTerminal = idTerminal;
	}

	public String getIdAdquiriente() {
		return idAdquiriente;
	}

	public void setIdAdquiriente(String idAdquiriente) {
		this.idAdquiriente = idAdquiriente;
	}

	public String getIdTransaccionTerminal() {
		return idTransaccionTerminal;
	}

	public void setIdTransaccionTerminal(String idTransaccionTerminal) {
		this.idTransaccionTerminal = idTransaccionTerminal;
	}

}
