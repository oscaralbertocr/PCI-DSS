package co.com.ath.ws.rs.objects;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonProperty;

import co.com.ath.pgw.core.logging.util.XMLUtil;

public class CommonStatus implements Serializable {

	private static final long serialVersionUID = 1L;

	@JsonProperty("StatusCode")
	private String statusCode;

	@JsonProperty("ServerStatusCode")
	private String serverStatusCode;

	@JsonProperty("Severity")
	private String severity;

	@JsonProperty("StatusDesc")
	private String statusDesc;

	
	public String getStatusCode() {
		return statusCode;
	}

	public void setStatusCode(String statusCode) {
		this.statusCode = statusCode;
	}

	public String getServerStatusCode() {
		return serverStatusCode;
	}

	public void setServerStatusCode(String serverStatusCode) {
		this.serverStatusCode = serverStatusCode;
	}

	public String getSeverity() {
		return severity;
	}

	public void setSeverity(String severity) {
		this.severity = severity;
	}

	public String getStatusDesc() {
		return statusDesc;
	}

	public void setStatusDesc(String statusDesc) {
		this.statusDesc = statusDesc;
	}

	@Override
	public String toString() {
		XMLUtil<CommonStatus> util = new XMLUtil<CommonStatus>();
		return util.convertObjectToJson(this);
	}

}
