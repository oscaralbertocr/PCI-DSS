package co.com.ath.ws.rs.objects;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonProperty;

public class TaxFee implements Serializable {

	private static final long serialVersionUID = 1L;
	
	@JsonProperty("amt")
	private String amt;

	public String getAmt() {
		return amt;
	}

	public void setAmt(String amt) {
		this.amt = amt;
	}

	
}
