package co.com.ath.pgw.in.model;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlSeeAlso;
import javax.xml.bind.annotation.XmlType;

import co.com.ath.pgw.client.bank.info.MsgRqHdrType;
import co.com.ath.pgw.client.bank.info.MsgRsHdrType;
import co.com.ath.pgw.in.dto.HistoricTransactionInqRsType;

@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "SvcRs_Type", propOrder = {
    "status",
    "rqUID",
    "approvalId",
    "msgRqHdr",
    "msgRsHdr",
    "custId"
})
@XmlSeeAlso({
    HistoricTransactionInqRsType.class
})
public class SvcRsType {

    @XmlElement(name = "Status",namespace = "urn://grupoaval.com/xsd/ifx/",required = true)
    protected StatusType status;
    @XmlElement(name = "RqUID",namespace = "urn://grupoaval.com/xsd/ifx/", required = true)
    protected long rqUID;
    @XmlElement(name = "ApprovalId")
    protected String approvalId;
    @XmlElement(name = "MsgRqHdr")
	protected MsgRqHdrType msgRqHdr;
    @XmlElement(name = "MsgRsHdr")

	protected MsgRsHdrType msgRsHdr;
    @XmlElement(name = "CustId")

	protected CustIdType custId;

	/**
	 * Obtiene el valor de la propiedad status.
	 * 
	 * @return possible object is {@link StatusType }
	 * 
	 */
	public StatusType getStatus() {
		return status;
	}

	/**
	 * Define el valor de la propiedad status.
	 * 
	 * @param value allowed object is {@link StatusType }
	 * 
	 */
	public void setStatus(StatusType value) {
		this.status = value;
	}

	/**
	 * Obtiene el valor de la propiedad rqUID.
	 * 
	 */
	public long getRqUID() {
		return rqUID;
	}

	/**
	 * Define el valor de la propiedad rqUID.
	 * 
	 */
	public void setRqUID(long value) {
		this.rqUID = value;
	}

	/**
	 * Obtiene el valor de la propiedad approvalId.
	 * 
	 * @return possible object is {@link String }
	 * 
	 */
	public String getApprovalId() {
		return approvalId;
	}

	/**
	 * Define el valor de la propiedad approvalId.
	 * 
	 * @param value allowed object is {@link String }
	 * 
	 */
	public void setApprovalId(String value) {
		this.approvalId = value;
	}

	public MsgRqHdrType getMsgRqHdr() {
		return msgRqHdr;
	}

	public void setMsgRqHdr(MsgRqHdrType msgRqHdr) {
		this.msgRqHdr = msgRqHdr;
	}

	public MsgRsHdrType getMsgRsHdr() {
		return msgRsHdr;
	}

	public void setMsgRsHdr(MsgRsHdrType msgRsHdr) {
		this.msgRsHdr = msgRsHdr;
	}

	public CustIdType getCustId() {
		return custId;
	}

	public void setCustId(CustIdType custId) {
		this.custId = custId;
	}

}
