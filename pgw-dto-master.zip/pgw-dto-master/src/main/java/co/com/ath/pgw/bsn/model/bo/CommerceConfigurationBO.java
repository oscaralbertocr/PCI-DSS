/*
 * CommerceConfigurationVO
 *  
 * GSI - Integración
 * Creado el: 28/08/2014
 *
 * Copyright (c) A Toda Hora S.A. Todos los derechos reservados
 * 
 * Este software es confidencial y es propietario de ATH, queda prohibido
 * su uso, reproducción y copia de manera parcial o permanente salvo autorización
 * expresa de A Toda Hora S.A o de quién represente sus derechos.
 */
package co.com.ath.pgw.bsn.model.bo;


/**
 * Configuración técnica de un comercio, incluye entre otras la configuración
 * gráfica, certificados, URL's de redirección.
 * 
 * @author proveedor_piza
 * @version 1.0 29 Ago 2014
 * @since 1.0
 */
public class CommerceConfigurationBO {

	/**
	 * Identificador del comercio.
	 */
	private Long commerceId;
	
	/**
     * Comercio asociado a la configuración.
     */
	private CommerceBO commerce;

	/**
	 * Plantilla gráfica que usa el comercio.
	 */
	private TemplateBO template;

	/**
	 * Tema gráfico que usa el comercio.
	 */
	private ThemeBO theme;
	
	/**
	 * Logo del comercio.
	 */
	private String logo;

	/**
	 * Usuario de autenticación técnica (Quién puede crear transacciones).
	 */
	private String user;

	/**
	 * Frase oculta del usuario de autenticación técnica.
	 */
	private String phrase;

	/**
	 * Ruta del certificado del comercio.
	 */
	private String certificatePath;

	/**
	 * URL de respuesta del comercio
	 */
	private String responseURL;

	/**
	 * Url de confirmaión del comercio.
	 */
	private String confirmationURL;

	/**
	 * Construye la configuración de un comercio.
	 */
	public CommerceConfigurationBO(){
		super();
	}
	
	/**
	 * Constructor con parametros
	 * @param userCommerce
	 */
	public CommerceConfigurationBO(String userCommerce){
		super();
		this.user = userCommerce;
	}
	
	/**
	 * Retorna el identificador del comercio.
	 * @return Identificador del comercio.
	 */
	public Long getCommerceId(){
		return commerceId;
	}

	/**
	 * Establece la identificación del comercio.
	 * 
	 * @param commerceId Id del comercio.
	 */
	public void setCommerceId(Long commerceId){
		this.commerceId = commerceId;
	}

	/**
	 * Retorna el comercio asociado a la configuración.
	 * 
	 * @return Comercio asociado.
	 */
	public CommerceBO getCommerce(){
		return commerce;
	}

	/**
	 * Establece el comercio asociado a la configuración.
	 * 
	 * @param commerce Comercio asociado.
	 */
	public void setCommerce(CommerceBO commerce){
		this.commerce = commerce;
	}

	/**
	 * Retorna la plantilla de configuración gráfica que usa el comercio.
	 * 
	 * @return Plantilla gráfica.
	 */
	public TemplateBO getTemplate(){
		return template;
	}

	/**
	 * Establece la plantilla de configuración gráfica que usará el comercio.
	 * 
	 * @param template Plantilla Gráfica.
	 */
	public void setTemplate(TemplateBO template){
		this.template = template;
	}

	/**
	 * Retorna el tema de configuración gráfica que usa el comercio.
	 * 
	 * @return Tema gráfico.
	 */
	public ThemeBO getTheme(){
		return theme;
	}

	/**
	 * Establece el tema de configuración gráfica que usará el comercio.
	 * 
	 * @param theme Tema gráfico.
	 */
	public void setTheme(ThemeBO theme){
		this.theme = theme;
	}
	
	/**
	 * Retorna la ubicación del logo del comercio.
	 * 
	 * @return Ubicación logo.
	 */
	public String getLogo(){
		return logo;
	}

	/**
	 * Establece la ubicación del logo del comercio.
	 * 
	 * @param logo Ubicación logo.
	 */
	public void setLogo(String logo){
		this.logo = logo;
	}
	
	/**
	 * Retorna el nombre de usuario de autenticación técnica (Quién puede crear
	 * transacciones).
	 * 
	 * @return Nombre de usuario Web Services.
	 */
	public String getUser(){
		return user;
	}

	/**
	 * Retorna el nombre de usuario de autenticación técnica (Quién puede crear
	 * transacciones).
	 * 
	 * @param user Nombre de usuario Web Services.
	 */
	public void setUser(String user){
		this.user = user;
	}
	
	/**
	 * Retorna la frase oculta del usuario de autenticación técnica.
	 * 
	 * @return Contraseña del usuario.
	 */
	public String getPhrase(){
		return phrase;
	}

	/**
	 * Establece la frase oculta del usuario de autenticación técnica.
	 * 
	 * @param phrase Frase oculta de autenticación.
	 */
	public void setPhrase(String phrase){
		this.phrase = phrase;
	}
	
	/**
	 * Retorna la ruta del certificado del comercio.
	 * 
	 * @return Ruta del certificado.
	 */
	public String getCertificatePath(){
		return certificatePath;
	}

	/**
	 * Establece la ruta del certificado del comercio.
	 * 
	 * @param certificatePath Ruta del certificado.
	 */
	public void setCertificatePath(String certificatePath){
		this.certificatePath = certificatePath;
	}
	
	/**
	 * Retorna la URL de respuesta del comercio.
	 * 
	 * @return URL de respuesta del comercio.
	 */
	public String getResponseURL(){
		return responseURL;
	}

	/**
	 * Establece la URL de respuesta del comercio.
	 * @param responseURL URL de respuesta del comercio.
	 */
	public void setResponseURL(String responseURL){
		this.responseURL = responseURL;
	}
	
	/**
	 * Retorna la URL de confirmaión del comercio.
	 * 
	 * @return URL de confirmaión del comercio.
	 */
	public String getConfirmationURL(){
		return confirmationURL;
	}

	/**
	 * Establece la URL de confirmaión del comercio.
	 * 
	 * @param confirmationURL URL de confirmaión del comercio.
	 */
	public void setConfirmationURL(String confirmationURL){
		this.confirmationURL = confirmationURL;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result
				+ ((commerceId == null) ? 0 : commerceId.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		CommerceConfigurationBO other = (CommerceConfigurationBO) obj;
		if (commerceId == null) {
			if (other.commerceId != null)
				return false;
		} else if (!commerceId.equals(other.commerceId))
			return false;
		return true;
	}

	@Override
	public String toString() {
		return "CommerceConfigurationVO [commerceId=" + commerceId
				+ ", commerce=" + commerce + "]";
	}
	
}