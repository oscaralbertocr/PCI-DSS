/*
 * BrandVO
 *  
 * GSI - Integración
 * Creado el: 28/08/2014
 *
 * Copyright (c) A Toda Hora S.A. Todos los derechos reservados
 * 
 * Este software es confidencial y es propietario de ATH, queda prohibido
 * su uso, reproducción y copia de manera parcial o permanente salvo autorización
 * expresa de A Toda Hora S.A o de quién represente sus derechos.
 */

package co.com.ath.pgw.bsn.model.bo;



/**
 * Clase vista de la entidad Brand
 * 
 */

public class BrandBO{

	/**
	 * Identificador de la marca en el sistema.
	 */
	private String id;

	/**
	 * Nombre de la marca.
	 */
	private String name;

	/**
	 * Estado de la franquicia.
	 */
	private String status;

	/**
	 * Construye una marca de tarjeta.
	 */
	public BrandBO(){
		super();
	}

    public BrandBO(String id) {
        this.id = id;
    }

	/**
	 * Retorna el identificador de la marca en el sistema.
	 * 
	 * @return Identificador de la marca en el sistema.
	 */
	public String getId(){
		return id;
	}

	/**
	 * Establece el identificador de la marca en el sistema.
	 * 
	 * @param id identificador de la marca en el sistema.
	 */
	public void setId(String id){
		this.id = id;
	}

	/**
	 * Retorna el nombre de la marca.
	 * 
	 * @return Nombre de la marca.
	 */
	public String getName(){
		return name;
	}

	/**
	 * Establece el Nombre de la marca.
	 * 
	 * @param name Método encargado de actualizar el atributo name.
	 */
	public void setName(String name){
		this.name = name;
	}

	/**
	 * Retorna el estado de la marca en el sistema.
	 * 
	 * @return Estado de la marca.
	 */
	public String getStatus(){
		return status;
	}

	/**
	 * Establece el estado de la marca en el sistema.
	 * 
	 * @param status Estado de la marca.
	 */
	public void setStatus(String status){
		this.status = status;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((id == null) ? 0 : id.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		BrandBO other = (BrandBO) obj;
		if (id == null) {
			if (other.id != null)
				return false;
		} else if (!id.equals(other.id))
			return false;
		return true;
	}

	@Override
	public String toString() {
		return "BrandVO [id=" + id + ", name=" + name + ", status=" + status
				+ "]";
	}
	
}