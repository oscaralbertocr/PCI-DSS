
package co.com.ath.pgw.rest.response.dto;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonProperty;

import co.com.ath.pgw.core.logging.util.XMLUtil;
import co.com.ath.pgw.rest.dto.PmtStatus;

public class GetTransactionResponse implements Serializable {

	@JsonProperty("PmtStatus")
	private PmtStatus pmtStatus;
	private static final long serialVersionUID = 1921062824992292268L;

	public PmtStatus getPmtStatus() {
		return pmtStatus;
	}

	public void setPmtStatus(PmtStatus pmtStatus) {
		this.pmtStatus = pmtStatus;
	}

	@Override
	public String toString() {
		XMLUtil<GetTransactionResponse> util = new XMLUtil<GetTransactionResponse>();
		return util.convertObjectToJson(this);
	}

}
