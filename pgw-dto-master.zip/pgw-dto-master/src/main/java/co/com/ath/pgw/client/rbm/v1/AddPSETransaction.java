
package co.com.ath.pgw.client.rbm.v1;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;


/**
 * 
 * @author Jesus Octavio Avendaño <jesus.avendano@sophossolutions.com> 
 * @version 1.0 17/06/2020
 * @since 1.0
 * 
 * <p>Clase Java para anonymous complex type.
 * 
 * <p>El siguiente fragmento de esquema especifica el contenido que se espera que haya en esta clase.
 * 
 * <pre>
 * &lt;complexType>
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element ref="{urn://ath.com.co/payments/v1/}PSETransactionAddRq"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "", propOrder = {
    "pseTransactionAddRq"
})
@XmlRootElement(name = "addPSETransaction")
public class AddPSETransaction {

    @XmlElement(name = "PSETransactionAddRq", required = true)
    protected PSETransactionAddRqType pseTransactionAddRq;

    /**
     * Obtiene el valor de la propiedad pseTransactionAddRq.
     * 
     * @return
     *     possible object is
     *     {@link PSETransactionAddRqType }
     *     
     */
    public PSETransactionAddRqType getPSETransactionAddRq() {
        return pseTransactionAddRq;
    }

    /**
     * Define el valor de la propiedad pseTransactionAddRq.
     * 
     * @param value
     *     allowed object is
     *     {@link PSETransactionAddRqType }
     *     
     */
    public void setPSETransactionAddRq(PSETransactionAddRqType value) {
        this.pseTransactionAddRq = value;
    }

}
