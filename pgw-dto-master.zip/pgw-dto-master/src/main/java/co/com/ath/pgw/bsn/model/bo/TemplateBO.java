/*
 * TemplateVO
 *  
 * GSI - Integración
 * Creado el: 28/08/2014
 *
 * Copyright (c) A Toda Hora S.A. Todos los derechos reservados
 * 
 * Este software es confidencial y es propietario de ATH, queda prohibido
 * su uso, reproducción y copia de manera parcial o permanente salvo autorización
 * expresa de A Toda Hora S.A o de quién represente sus derechos.
 */
package co.com.ath.pgw.bsn.model.bo;


/**
 * Representa una plantilla para el esquema gráfico de un comercio. Esta es una
 * entidad del modelo de negocio.
 * 
 * @author proveedor_japiza
 * @version 1.0 29 Ago 2014
 * @since 1.0
 *
 */
public class TemplateBO {

	/**
	 * Identificador único de la plantilla.
	 */
	private Long id;

	/**
	 * Nombre de la plantilla.
	 */
	private String name;

	/**
	 * Construye una plantilla vacía.
	 */
	public TemplateBO(){
		super();
	}

	/**
	 * Retorna el identificador único de la plantilla.
	 * 
	 * @return Identificador único de la plantilla.
	 */
	public Long getId() {
		return id;
	}

	/**
	 * Establece el identificador único de la plantilla.
	 * @param id Identificador plantilla.
	 */
	public void setId(Long id) {
		this.id = id;
	}

	/**
	 * Retorna el nombre de la plantilla.
	 * @return Nombre de la plantilla.
	 */
	public String getName() {
		return name;
	}

	/**
	 * Establece el nombre de la plantilla.
	 * @param name Nombre de plantilla.
	 */
	public void setName(String name) {
		this.name = name;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((id == null) ? 0 : id.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		TemplateBO other = (TemplateBO) obj;
		if (id == null) {
			if (other.id != null)
				return false;
		} else if (!id.equals(other.id))
			return false;
		return true;
	}

	@Override
	public String toString() {
		return "TemplateVO [id=" + id + ", name=" + name + "]";
	}

}