
package co.com.ath.pgw.in.dto;

import javax.xml.bind.annotation.XmlElement;
import co.com.ath.pgw.core.logging.util.XMLUtil;
import co.com.ath.pgw.in.model.FeeType;
import co.com.ath.pgw.in.model.TransactionStatusType;


/**
 * <p>Clase Java para PSETransactionInformationInqRs_Type complex type.
 * 
 * <p>El siguiente fragmento de esquema especifica el contenido que se espera que haya en esta clase.
 * 
 * <pre>
 * &lt;complexType name="PSETransactionInformationInqRs_Type">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element ref="{urn://ath.com.co/xsd/common/}StatusCode"/>
 *         &lt;element ref="{urn://ath.com.co/xsd/common/}StatusDesc"/>
 *         &lt;element ref="{urn://ath.com.co/xsd/common/}RqUID"/>
 *         &lt;element ref="{urn://ath.com.co/xsd/common/}TransactionStatus" minOccurs="0"/>
 *         &lt;element ref="{urn://ath.com.co/xsd/common/}PmtId" minOccurs="0"/>
 *         &lt;element ref="{urn://ath.com.co/xsd/common/}TrazabilityCode" minOccurs="0"/>
 *         &lt;element ref="{urn://ath.com.co/xsd/common/}Fee" minOccurs="0"/>
 *         &lt;element ref="{urn://ath.com.co/xsd/common/}TrnCycle" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
public class PSETransactionInformationInqRsType {

    @XmlElement(name = "StatusCode", namespace = "urn://ath.com.co/xsd/common/")
    protected long statusCode;
    @XmlElement(name = "StatusDesc", namespace = "urn://ath.com.co/xsd/common/", required = true)
    protected String statusDesc;
    @XmlElement(name = "RqUID", namespace = "urn://ath.com.co/xsd/common/")
    protected long rqUID;
    @XmlElement(name = "TransactionStatus", namespace = "urn://ath.com.co/xsd/common/")
    protected TransactionStatusType transactionStatus;
    @XmlElement(name = "PmtId", namespace = "urn://ath.com.co/xsd/common/")
    protected String pmtId;
    @XmlElement(name = "TrazabilityCode", namespace = "urn://ath.com.co/xsd/common/")
    protected String trazabilityCode;
    @XmlElement(name = "Fee", namespace = "urn://ath.com.co/xsd/common/")
    protected FeeType fee;
    @XmlElement(name = "TrnCycle", namespace = "urn://ath.com.co/xsd/common/")
    protected String trnCycle;

    /**
     * Obtiene el valor de la propiedad statusCode.
     * 
     */
    public long getStatusCode() {
        return statusCode;
    }

    /**
     * Define el valor de la propiedad statusCode.
     * 
     */
    public void setStatusCode(long value) {
        this.statusCode = value;
    }

    /**
     * Obtiene el valor de la propiedad statusDesc.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getStatusDesc() {
        return statusDesc;
    }

    /**
     * Define el valor de la propiedad statusDesc.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setStatusDesc(String value) {
        this.statusDesc = value;
    }

    /**
     * Obtiene el valor de la propiedad rqUID.
     * 
     */
    public long getRqUID() {
        return rqUID;
    }

    /**
     * Define el valor de la propiedad rqUID.
     * 
     */
    public void setRqUID(long value) {
        this.rqUID = value;
    }

    /**
     * Obtiene el valor de la propiedad transactionStatus.
     * 
     * @return
     *     possible object is
     *     {@link TransactionStatusType }
     *     
     */
    public TransactionStatusType getTransactionStatus() {
        return transactionStatus;
    }

    /**
     * Define el valor de la propiedad transactionStatus.
     * 
     * @param value
     *     allowed object is
     *     {@link TransactionStatusType }
     *     
     */
    public void setTransactionStatus(TransactionStatusType value) {
        this.transactionStatus = value;
    }

    /**
     * Obtiene el valor de la propiedad pmtId.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPmtId() {
        return pmtId;
    }

    /**
     * Define el valor de la propiedad pmtId.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPmtId(String value) {
        this.pmtId = value;
    }

    /**
     * Obtiene el valor de la propiedad trazabilityCode.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getTrazabilityCode() {
        return trazabilityCode;
    }

    /**
     * Define el valor de la propiedad trazabilityCode.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setTrazabilityCode(String value) {
        this.trazabilityCode = value;
    }

    /**
     * Obtiene el valor de la propiedad fee.
     * 
     * @return
     *     possible object is
     *     {@link FeeType }
     *     
     */
    public FeeType getFee() {
        return fee;
    }

    /**
     * Define el valor de la propiedad fee.
     * 
     * @param value
     *     allowed object is
     *     {@link FeeType }
     *     
     */
    public void setFee(FeeType value) {
        this.fee = value;
    }

    /**
     * Obtiene el valor de la propiedad trnCycle.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getTrnCycle() {
        return trnCycle;
    }

    /**
     * Define el valor de la propiedad trnCycle.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setTrnCycle(String value) {
        this.trnCycle = value;
    }

	@Override
	public String toString() {
		XMLUtil<PSETransactionInformationInqRsType> requestParser = 
				new XMLUtil<PSETransactionInformationInqRsType>();
		return requestParser.convertObjectToXml(this);
	}

}
