package co.com.ath.ws.rs.objects;

import co.com.ath.pgw.core.logging.util.XMLUtil;

public class AdditionalStatus extends CommonStatus {

	private static final long serialVersionUID = 1L;
	
	@Override
	public String toString() {
		XMLUtil<AdditionalStatus> util = new XMLUtil<AdditionalStatus>();
		return util.convertObjectToJson(this);
	}

}
