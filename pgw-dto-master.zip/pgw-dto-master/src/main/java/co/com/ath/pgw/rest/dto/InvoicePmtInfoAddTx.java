
package co.com.ath.pgw.rest.dto;

import java.io.Serializable;

import javax.validation.Valid;
import javax.validation.constraints.NotNull;

import com.fasterxml.jackson.annotation.JsonProperty;

public class InvoicePmtInfoAddTx implements Serializable {
	@JsonProperty("InvoiceInfo")
	@Valid
	@NotNull
	private InvoiceInfoAddTx invoiceInfo;
	
	@JsonProperty("PmtStatus")
	private PmtStatusAddTx pmtStatus;
	
	@JsonProperty("CCAcctStmtRec")
    private CCAcctStmtRecAddTx ccAcctStmtRec;
	
	private final static long serialVersionUID = 6071337479327711051L;

	public InvoiceInfoAddTx getInvoiceInfo() {
		return invoiceInfo;
	}

	public void setInvoiceInfo(InvoiceInfoAddTx invoiceInfo) {
		this.invoiceInfo = invoiceInfo;
	}

	public PmtStatusAddTx getPmtStatus() {
		return pmtStatus;
	}

	public void setPmtStatus(PmtStatusAddTx pmtStatus) {
		this.pmtStatus = pmtStatus;
	}
	
	public CCAcctStmtRecAddTx getCcAcctStmtRec() {
		return ccAcctStmtRec;
	}

	public void setCcAcctStmtRec(CCAcctStmtRecAddTx ccAcctStmtRec) {
		this.ccAcctStmtRec = ccAcctStmtRec;
	}

}
