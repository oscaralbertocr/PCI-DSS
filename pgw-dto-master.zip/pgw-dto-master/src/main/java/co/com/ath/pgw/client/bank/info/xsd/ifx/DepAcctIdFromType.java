
package co.com.ath.pgw.client.bank.info.xsd.ifx;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlType;

import co.com.ath.pgw.core.logging.util.XMLUtil;


/**
 * <p>Clase Java para DepAcctIdFrom_Type complex type.
 * 
 * <p>El siguiente fragmento de esquema especifica el contenido que se espera que haya en esta clase.
 * 
 * <pre>
 * &lt;complexType name="DepAcctIdFrom_Type">
 *   &lt;complexContent>
 *     &lt;extension base="{urn://grupoaval.com/xsd/ifx/}DepAcctId_Type">
 *     &lt;/extension>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "DepAcctIdFrom_Type")
public class DepAcctIdFromType
    extends DepAcctIdType
{

	public String toString() {
    	XMLUtil<DepAcctIdFromType> requestParser = 
    							new XMLUtil<DepAcctIdFromType>();
		return requestParser.convertObjectToXml(this);
    }

}
