package co.com.ath.pgw.rest.globalPay.qr;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.fasterxml.jackson.annotation.JsonProperty;

import co.com.ath.pgw.core.logging.util.XMLUtil;

@JsonInclude(Include.NON_NULL)
public class CoreUpdateQrRBMRq implements Serializable{

	private static final long serialVersionUID = 8918868994922641954L;
	
	@JsonProperty("codigoUnico")
	private String codigoUnico;
	
	@JsonProperty("terminalId")
	private String terminalId;
	
	@JsonProperty("idTransaccion")
	private String idTransaccion;
	
	@JsonProperty("fechaQR")
	private String fechaQR;
	
	@JsonProperty("estado")
	private String estado;

	public String getCodigoUnico() {
		return codigoUnico;
	}

	public void setCodigoUnico(String codigoUnico) {
		this.codigoUnico = codigoUnico;
	}

	public String getTerminalId() {
		return terminalId;
	}

	public void setTerminalId(String terminalId) {
		this.terminalId = terminalId;
	}

	public String getIdTransaccion() {
		return idTransaccion;
	}

	public void setIdTransaccion(String idTransaccion) {
		this.idTransaccion = idTransaccion;
	}

	public String getFechaQR() {
		return fechaQR;
	}

	public void setFechaQR(String fechaQR) {
		this.fechaQR = fechaQR;
	}

	public String getEstado() {
		return estado;
	}

	public void setEstado(String estado) {
		this.estado = estado;
	}
	
	@Override
	public String toString() {
		XMLUtil<CoreUpdateQrRBMRq> util = new XMLUtil<CoreUpdateQrRBMRq>();
		return util.convertObjectToJson(this);
	}

}
