/*
 * AddTransactionInDTO
 *  
 * GSI - Integración
 * Creado el: 20/09/2014
 *
 * Copyright (c) A Toda Hora S.A. Todos los derechos reservados
 * 
 * Este software es confidencial y es propietario de ATH, queda prohibido
 * su uso, reproducción y copia de manera parcial o permanente salvo autorización
 * expresa de A Toda Hora S.A o de quién represente sus derechos.
 */
package co.com.ath.pgw.bsn.globalPay.dto;

import java.util.ArrayList;
import java.util.List;

import co.com.ath.pgw.bsn.dto.in.CommonObjectInDTO;
import co.com.ath.pgw.bsn.globalPay.model.ReferenceType;
import co.com.ath.pgw.bsn.model.bo.TransactionBO;


/**
 * DTO de entrada con la información para la operación
 * IniciarTransaccionDeCompra
 * 
 * @author camilo.bustamante@sophossolutions.com
 * @version 1.0 03 Enero 2019
 * @RQ31686 RBM_Integracion_Boton_TC_GlobalPay
 * 
 */
public class IniciarTransaccionInDTO extends CommonObjectInDTO {

	private TransactionBO transactionBO;
	private List<ReferenceType> references = new ArrayList<ReferenceType>();

	public TransactionBO getTransactionBO() {
		return transactionBO;
	}

	public void setTransactionBO(TransactionBO transactionBO) {
		this.transactionBO = transactionBO;
	}

	public List<ReferenceType> getReferences() {
		return references;
	}

	public void setReferences(List<ReferenceType> references) {
		this.references = references;
	}

}
