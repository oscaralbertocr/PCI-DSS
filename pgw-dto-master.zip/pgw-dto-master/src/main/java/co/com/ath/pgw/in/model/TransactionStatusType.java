package co.com.ath.pgw.in.model;

import javax.xml.datatype.XMLGregorianCalendar;

public class TransactionStatusType {

	protected Long trnStatusCode;

	protected String trnStatusDesc;

	protected String trnServerStatusCode;

	protected String trnServerStatusDesc;

	protected XMLGregorianCalendar effDt;

	protected XMLGregorianCalendar compensationDt;

	protected String approvalId;

	protected TrnStatusType trnStatus = new TrnStatusType();

	/**
	 * Obtiene el valor de la propiedad trnStatusCode.
	 * 
	 * @return possible object is {@link Long }
	 * 
	 */
	public Long getTrnStatusCode() {
		return trnStatusCode;
	}

	/**
	 * Define el valor de la propiedad trnStatusCode.
	 * 
	 * @param value allowed object is {@link Long }
	 * 
	 */
	public void setTrnStatusCode(Long value) {
		this.trnStatusCode = value;
	}

	/**
	 * Obtiene el valor de la propiedad trnStatusDesc.
	 * 
	 * @return possible object is {@link String }
	 * 
	 */
	public String getTrnStatusDesc() {
		return trnStatusDesc;
	}

	/**
	 * Define el valor de la propiedad trnStatusDesc.
	 * 
	 * @param value allowed object is {@link String }
	 * 
	 */
	public void setTrnStatusDesc(String value) {
		this.trnStatusDesc = value;
	}

	/**
	 * Obtiene el valor de la propiedad trnServerStatusCode.
	 * 
	 * @return possible object is {@link String }
	 * 
	 */
	public String getTrnServerStatusCode() {
		return trnServerStatusCode;
	}

	/**
	 * Define el valor de la propiedad trnServerStatusCode.
	 * 
	 * @param value allowed object is {@link String }
	 * 
	 */
	public void setTrnServerStatusCode(String value) {
		this.trnServerStatusCode = value;
	}

	/**
	 * Obtiene el valor de la propiedad trnServerStatusDesc.
	 * 
	 * @return possible object is {@link String }
	 * 
	 */
	public String getTrnServerStatusDesc() {
		return trnServerStatusDesc;
	}

	/**
	 * Define el valor de la propiedad trnServerStatusDesc.
	 * 
	 * @param value allowed object is {@link String }
	 * 
	 */
	public void setTrnServerStatusDesc(String value) {
		this.trnServerStatusDesc = value;
	}

	/**
	 * Obtiene el valor de la propiedad effDt.
	 * 
	 * @return possible object is {@link XMLGregorianCalendar }
	 * 
	 */
	public XMLGregorianCalendar getEffDt() {
		return effDt;
	}

	/**
	 * Define el valor de la propiedad effDt.
	 * 
	 * @param value allowed object is {@link XMLGregorianCalendar }
	 * 
	 */
	public void setEffDt(XMLGregorianCalendar value) {
		this.effDt = value;
	}

	/**
	 * Obtiene el valor de la propiedad compensationDt.
	 * 
	 * @return possible object is {@link XMLGregorianCalendar }
	 * 
	 */
	public XMLGregorianCalendar getCompensationDt() {
		return compensationDt;
	}

	/**
	 * Define el valor de la propiedad compensationDt.
	 * 
	 * @param value allowed object is {@link XMLGregorianCalendar }
	 * 
	 */
	public void setCompensationDt(XMLGregorianCalendar value) {
		this.compensationDt = value;
	}

	/**
	 * Obtiene el valor de la propiedad approvalId.
	 * 
	 * @return possible object is {@link String }
	 * 
	 */
	public String getApprovalId() {
		return approvalId;
	}

	/**
	 * Define el valor de la propiedad approvalId.
	 * 
	 * @param value allowed object is {@link String }
	 * 
	 */
	public void setApprovalId(String value) {
		this.approvalId = value;
	}

	public TrnStatusType getTrnStatus() {
		return trnStatus;
	}

	public void setTrnStatus(TrnStatusType trnStatus) {
		this.trnStatus = trnStatus;
	}

}
