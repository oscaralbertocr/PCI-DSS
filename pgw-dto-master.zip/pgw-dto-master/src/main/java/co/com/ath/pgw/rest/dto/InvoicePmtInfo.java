
package co.com.ath.pgw.rest.dto;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonProperty;

public class InvoicePmtInfo implements Serializable {
	@JsonProperty("InvoiceInfo")
	private InvoiceInfo invoiceInfo;
	
	@JsonProperty("PmtStatus")
	private PmtStatus pmtStatus;
	
	@JsonProperty("CCAcctStmtRec")
    private CCAcctStmtRec ccAcctStmtRec;
	
	private final static long serialVersionUID = 6071337479327711051L;

	public InvoiceInfo getInvoiceInfo() {
		return invoiceInfo;
	}

	public void setInvoiceInfo(InvoiceInfo invoiceInfo) {
		this.invoiceInfo = invoiceInfo;
	}

	public PmtStatus getPmtStatus() {
		return pmtStatus;
	}

	public void setPmtStatus(PmtStatus pmtStatus) {
		this.pmtStatus = pmtStatus;
	}
	
	public CCAcctStmtRec getCcAcctStmtRec() {
		return ccAcctStmtRec;
	}

	public void setCcAcctStmtRec(CCAcctStmtRec ccAcctStmtRec) {
		this.ccAcctStmtRec = ccAcctStmtRec;
	}

}
