package co.com.ath.pgw.rest.request.dto;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonProperty;

import co.com.ath.pgw.core.logging.util.XMLUtil;
import co.com.ath.pgw.rest.dto.GlobalPayCard;
import co.com.ath.pgw.rest.dto.GlobalPayTransaction;
import co.com.ath.pgw.rest.dto.GlobalPayUser;

public class GlobalPayCheckOutRequest implements Serializable {

	private static final long serialVersionUID = 3485903332142336071L;

	
	@JsonProperty("transaction")
	private GlobalPayTransaction transaction;

	@JsonProperty("user")
	private GlobalPayUser user;

	@JsonProperty("card")
	private GlobalPayCard card;	

	
	public GlobalPayTransaction getTransaction() {
		return transaction;
	}

	public void setTransaction(GlobalPayTransaction transaction) {
		this.transaction = transaction;
	}

	public GlobalPayUser getUser() {
		return user;
	}

	public void setUser(GlobalPayUser user) {
		this.user = user;
	}

	public GlobalPayCard getCard() {
		return card;
	}

	public void setCard(GlobalPayCard card) {
		this.card = card;
	}

	
	@Override
	public String toString() {
		XMLUtil<GlobalPayCheckOutRequest> util = new XMLUtil<GlobalPayCheckOutRequest>();
		return util.convertObjectToJson(this);
	}

}