/**
 * 
 * @author Jesus Octavio Avendaño <jesus.avendano@sophossolutions.com> 
 * @version 1.0 17/06/2020
 * @since 1.0
 * 
 */

@javax.xml.bind.annotation.XmlSchema(namespace = "urn://ath.com.co/xsd/common/", elementFormDefault = javax.xml.bind.annotation.XmlNsForm.QUALIFIED)
package co.com.ath.pgw.client.rbm.common;
