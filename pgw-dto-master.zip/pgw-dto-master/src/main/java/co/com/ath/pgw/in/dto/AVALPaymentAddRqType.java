package co.com.ath.pgw.in.dto;

import java.util.ArrayList;
import java.util.List;

import co.com.ath.pgw.in.model.AgreementInfoType;
import co.com.ath.pgw.in.model.BankInfoType;
import co.com.ath.pgw.in.model.FeeType;
import co.com.ath.pgw.in.model.OrderInfoType;
import co.com.ath.pgw.in.model.PersonalDataType;
import co.com.ath.pgw.in.model.ReferenceType;
import co.com.ath.pgw.in.model.SvcRqType;
import co.com.ath.pgw.in.model.TaxFeeType;


public class AVALPaymentAddRqType extends SvcRqType{

	protected String pmtId;
	
	protected List<PersonalDataType> personalData;
	
	protected AgreementInfoType agreementInfo;
	
	protected BankInfoType bankInfo;
	
	protected OrderInfoType orderInfo;
	
	protected FeeType fee;
	
	protected TaxFeeType taxFee;
	
	protected List<ReferenceType> reference;
	
	/**
	 * Obtiene el valor de la propiedad pmtId.
	 * 
	 * @return
	 *     possible object is
	 *     {@link String }
	 *     
	 */
	public String getPmtId() {
	    return pmtId;
	}
	
	/**
	 * Define el valor de la propiedad pmtId.
	 * 
	 * @param value
	 *     allowed object is
	 *     {@link String }
	 *     
	 */
	public void setPmtId(String value) {
	    this.pmtId = value;
	}
	
	/**
	 * Obtiene el valor de la propiedad personalData.
	 * 
	 * @return
	 *     possible object is
	 *     {@link PersonalDataType }
	 *     
	 */
	public List<PersonalDataType> getPersonalData() {
	    if (personalData == null) {
	        personalData = new ArrayList<PersonalDataType>();
	    }
	    return this.personalData;
	}
	
	/**
	 * Obtiene el valor de la propiedad agreementInfo.
	 * 
	 * @return
	 *     possible object is
	 *     {@link AgreementInfoType }
	 *     
	 */
	public AgreementInfoType getAgreementInfo() {
	    return agreementInfo;
	}
	
	/**
	 * Define el valor de la propiedad agreementInfo.
	 * 
	 * @param value
	 *     allowed object is
	 *     {@link AgreementInfoType }
	 *     
	 */
	public void setAgreementInfo(AgreementInfoType value) {
	    this.agreementInfo = value;
	}
	
	/**
	 * Obtiene el valor de la propiedad bankInfo.
	 * 
	 * @return
	 *     possible object is
	 *     {@link BankInfoType }
	 *     
	 */
	public BankInfoType getBankInfo() {
	    return bankInfo;
	}
	
	/**
	 * Define el valor de la propiedad bankInfo.
	 * 
	 * @param value
	 *     allowed object is
	 *     {@link BankInfoType }
	 *     
	 */
	public void setBankInfo(BankInfoType value) {
	    this.bankInfo = value;
	}
	
	/**
	 * Obtiene el valor de la propiedad orderInfo.
	 * 
	 * @return
	 *     possible object is
	 *     {@link OrderInfoType }
	 *     
	 */
	public OrderInfoType getOrderInfo() {
	    return orderInfo;
	}
	
	/**
	 * Define el valor de la propiedad orderInfo.
	 * 
	 * @param value
	 *     allowed object is
	 *     {@link OrderInfoType }
	 *     
	 */
	public void setOrderInfo(OrderInfoType value) {
	    this.orderInfo = value;
	}
	
	/**
	 * Obtiene el valor de la propiedad fee.
	 * 
	 * @return
	 *     possible object is
	 *     {@link FeeType }
	 *     
	 */
	public FeeType getFee() {
	    return fee;
	}
	
	/**
	 * Define el valor de la propiedad fee.
	 * 
	 * @param value
	 *     allowed object is
	 *     {@link FeeType }
	 *     
	 */
	public void setFee(FeeType value) {
	    this.fee = value;
	}
	
	/**
	 * Obtiene el valor de la propiedad taxFee.
	 * 
	 * @return
	 *     possible object is
	 *     {@link TaxFeeType }
	 *     
	 */
	public TaxFeeType getTaxFee() {
	    return taxFee;
	}
	
	/**
	 * Define el valor de la propiedad taxFee.
	 * 
	 * @param value
	 *     allowed object is
	 *     {@link TaxFeeType }
	 *     
	 */
	public void setTaxFee(TaxFeeType value) {
	    this.taxFee = value;
	}
	
	/**
	 * Gets the value of the reference property.
	 * 
	 * <p>
	 * This accessor method returns a reference to the live list,
	 * not a snapshot. Therefore any modification you make to the
	 * returned list will be present inside the JAXB object.
	 * This is why there is not a <CODE>set</CODE> method for the reference property.
	 * 
	 * <p>
	 * For example, to add a new item, do as follows:
	 * <pre>
	 *    getReference().add(newItem);
	 * </pre>
	 * 
	 * 
	 * <p>
	 * Objects of the following type(s) are allowed in the list
	 * {@link ReferenceType }
	 * 
	 * 
	 */
	public List<ReferenceType> getReference() {
	    if (reference == null) {
	        reference = new ArrayList<ReferenceType>();
	    }
	    return this.reference;
	}
	
	/*
	@Override
		public String toString() {
			XMLUtil<AVALPaymentAddRqType> requestParser = new XMLUtil<AVALPaymentAddRqType>();
			return requestParser.convertObjectToXml(this);
		}
	*/

}

