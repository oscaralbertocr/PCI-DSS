package co.com.ath.pgw.in.model;


public class PmtWayType {

   
    protected String pmtWayId;
   
    protected String pmtWayType;

    /**
     * Obtiene el valor de la propiedad pmtWayId.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPmtWayId() {
        return pmtWayId;
    }

    /**
     * Define el valor de la propiedad pmtWayId.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPmtWayId(String value) {
        this.pmtWayId = value;
    }

    /**
     * Obtiene el valor de la propiedad pmtWayType.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPmtWayType() {
        return pmtWayType;
    }

    /**
     * Define el valor de la propiedad pmtWayType.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPmtWayType(String value) {
        this.pmtWayType = value;
    }

}
