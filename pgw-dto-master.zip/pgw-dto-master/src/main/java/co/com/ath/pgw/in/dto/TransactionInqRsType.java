package co.com.ath.pgw.in.dto;

import java.util.ArrayList;
import java.util.List;

import co.com.ath.pgw.core.logging.util.XMLUtil;
import co.com.ath.pgw.in.model.AgreementInfoType;
import co.com.ath.pgw.in.model.CommerceSettingType;
import co.com.ath.pgw.in.model.FeeType;
import co.com.ath.pgw.in.model.InvoiceReferenceType;
import co.com.ath.pgw.in.model.OrderInfoType;
import co.com.ath.pgw.in.model.PersonalDataType;
import co.com.ath.pgw.in.model.PmtWayType;
import co.com.ath.pgw.in.model.ReferenceType;
import co.com.ath.pgw.in.model.TaxFeeType;
import co.com.ath.pgw.in.model.TransactionStatusType;
import co.com.ath.pgw.in.model.TrmType;
import co.com.ath.pgw.in.model.UserIdType;


public class TransactionInqRsType {

   
    protected long statusCode;
    
    protected String statusDesc;
    
    protected long rqUID;
    
    protected String ipAddress;
    
    protected String Source;
    
    protected TransactionStatusType transactionStatus;
    
    protected UserIdType userId;
    
    protected List<PersonalDataType> personalData;
    
    protected AgreementInfoType agreementInfo;
   
    protected String pmtId;
   
    protected OrderInfoType orderInfo;
    
    protected FeeType fee;
   
    protected TaxFeeType taxFee;
    
    protected List<ReferenceType> reference;
    
    protected List<PmtWayType> pmtWay;
    
    protected String trnType;
    
    protected List<InvoiceReferenceType> invoiceReference;
    
    protected CommerceSettingType commerceSetting;
    
    protected String portalURL;
    
    protected String categoryId;
    
    protected String pmtType;
    
    protected String trnChannel;
    
    protected TrmType trm;

    /**
     * Obtiene el valor de la propiedad statusCode.
     * 
     */
    public long getStatusCode() {
        return statusCode;
    }

    /**
     * Define el valor de la propiedad statusCode.
     * 
     */
    public void setStatusCode(long value) {
        this.statusCode = value;
    }

    /**
     * Obtiene el valor de la propiedad statusDesc.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getStatusDesc() {
        return statusDesc;
    }

    /**
     * Define el valor de la propiedad statusDesc.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setStatusDesc(String value) {
        this.statusDesc = value;
    }

    /**
     * Obtiene el valor de la propiedad rqUID.
     * 
     */
    public long getRqUID() {
        return rqUID;
    }

    /**
     * Define el valor de la propiedad rqUID.
     * 
     */
    public void setRqUID(long value) {
        this.rqUID = value;
    }
    
    /**
     * Obtiene el valor de la propiedad ipAddress.
     * 
     * @return ipAddress
     *     
     */
    public String getIpAddress() {
		return ipAddress;
	}
    
    /**
     * Define el valor de la propiedad ipAddress.
     * 
     */
	public void setIpAddress(String ipAddress) {
		this.ipAddress = ipAddress;
	}

	/**
     * Obtiene el valor de la propiedad transactionStatus.
     * 
     * @return
     *     possible object is
     *     {@link TransactionStatusType }
     *     
     */
    public TransactionStatusType getTransactionStatus() {
        return transactionStatus;
    }

    /**
     * Define el valor de la propiedad transactionStatus.
     * 
     * @param value
     *     allowed object is
     *     {@link TransactionStatusType }
     *     
     */
    public void setTransactionStatus(TransactionStatusType value) {
        this.transactionStatus = value;
    }

    /**
     * Obtiene el valor de la propiedad userId.
     * 
     * @return
     *     possible object is
     *     {@link UserIdType }
     *     
     */
    public UserIdType getUserId() {
        return userId;
    }

    /**
     * Define el valor de la propiedad userId.
     * 
     * @param value
     *     allowed object is
     *     {@link UserIdType }
     *     
     */
    public void setUserId(UserIdType value) {
        this.userId = value;
    }

    /**
     * Gets the value of the personalData property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the personalData property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getPersonalData().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link PersonalDataType }
     * 
     * 
     */
    public List<PersonalDataType> getPersonalData() {
        if (personalData == null) {
            personalData = new ArrayList<PersonalDataType>();
        }
        return this.personalData;
    }
    
    public void setPersonalData(List<PersonalDataType> personalData) {
        this.personalData = personalData;
    }

    /**
     * Obtiene el valor de la propiedad agreementInfo.
     * 
     * @return
     *     possible object is
     *     {@link AgreementInfoType }
     *     
     */
    public AgreementInfoType getAgreementInfo() {
        return agreementInfo;
    }

    /**
     * Define el valor de la propiedad agreementInfo.
     * 
     * @param value
     *     allowed object is
     *     {@link AgreementInfoType }
     *     
     */
    public void setAgreementInfo(AgreementInfoType value) {
        this.agreementInfo = value;
    }

    /**
     * Obtiene el valor de la propiedad pmtId.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPmtId() {
        return pmtId;
    }

    /**
     * Define el valor de la propiedad pmtId.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPmtId(String value) {
        this.pmtId = value;
    }

    /**
     * Obtiene el valor de la propiedad orderInfo.
     * 
     * @return
     *     possible object is
     *     {@link OrderInfoType }
     *     
     */
    public OrderInfoType getOrderInfo() {
        return orderInfo;
    }

    /**
     * Define el valor de la propiedad orderInfo.
     * 
     * @param value
     *     allowed object is
     *     {@link OrderInfoType }
     *     
     */
    public void setOrderInfo(OrderInfoType value) {
        this.orderInfo = value;
    }

    /**
     * Obtiene el valor de la propiedad fee.
     * 
     * @return
     *     possible object is
     *     {@link FeeType }
     *     
     */
    public FeeType getFee() {
        return fee;
    }

    /**
     * Define el valor de la propiedad fee.
     * 
     * @param value
     *     allowed object is
     *     {@link FeeType }
     *     
     */
    public void setFee(FeeType value) {
        this.fee = value;
    }

    /**
     * Obtiene el valor de la propiedad taxFee.
     * 
     * @return
     *     possible object is
     *     {@link TaxFeeType }
     *     
     */
    public TaxFeeType getTaxFee() {
        return taxFee;
    }

    /**
     * Define el valor de la propiedad taxFee.
     * 
     * @param value
     *     allowed object is
     *     {@link TaxFeeType }
     *     
     */
    public void setTaxFee(TaxFeeType value) {
        this.taxFee = value;
    }

    /**
     * Gets the value of the reference property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the reference property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getReference().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link ReferenceType }
     * 
     * 
     */
    public List<ReferenceType> getReference() {
        if (reference == null) {
            reference = new ArrayList<ReferenceType>();
        }
        return this.reference;
    }

    public void setReference(List<ReferenceType> reference) {
        this.reference = reference;
    }

    /**
     * Gets the value of the pmtWay property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the pmtWay property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getPmtWay().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link PmtWayType }
     * 
     * 
     */
    public List<PmtWayType> getPmtWay() {
        if (pmtWay == null) {
            pmtWay = new ArrayList<PmtWayType>();
        }
        return this.pmtWay;
    }

    public void setPmtWay(List<PmtWayType> pmtWay) {
        this.pmtWay = pmtWay;
    }

    /**
     * Gets the value of the invoiceReference property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the invoiceReference property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getInvoiceReference().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link InvoiceReferenceType }
     * 
     * 
     */
    public List<InvoiceReferenceType> getInvoiceReference() {
        if (invoiceReference == null) {
            invoiceReference = new ArrayList<InvoiceReferenceType>();
        }
        return this.invoiceReference;
    }
    
    public void setInvoiceReference(List<InvoiceReferenceType> invoiceReference) {
        this.invoiceReference = invoiceReference;
    }
    
    /**
     * Obtiene el valor de la propiedad commerceSetting.
     * 
     * @return
     *     possible object is
     *     {@link CommerceSettingType }
     *     
     */
    public CommerceSettingType getCommerceSetting() { 
        return commerceSetting;
    }

    /**
     * Define el valor de la propiedad commerceSetting.
     * 
     * @param value
     *     allowed object is
     *     {@link CommerceSettingType }
     *     
     */
    public void setCommerceSetting(CommerceSettingType value) {
        this.commerceSetting = value;
    }

    /**
     * Obtiene el valor de la propiedad portalURL.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPortalURL() {
        return portalURL;
    }

    /**
     * Define el valor de la propiedad portalURL.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPortalURL(String value) {
        this.portalURL = value;
    }
    
    /**
     * Obtiene el valor de la propiedad trnType.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getTrnType() {
        return trnType;
    }

    /**
     * Define el valor de la propiedad trnType.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setTrnType(String value) {
        this.trnType = value;
    }
    
    /**
     * Obtiene el valor de la propiedad categoryId.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCategoryId() {
        return categoryId;
    }

    /**
     * Define el valor de la propiedad categoryId.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCategoryId(String value) {
        this.categoryId = value;
    }
    
    /**
     * Obtiene el valor de la propiedad pmtType.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPmtType() {
        return pmtType;
    }

    /**
     * Define el valor de la propiedad pmtType.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPmtType(String value) {
        this.pmtType = value;
    }
    
    
    /**
     * Obtiene el valor de la propiedad trnChannel.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getTrnChannel() {
        return trnChannel;
    }

    /**
     * Define el valor de la propiedad trnChannel.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setTrnChannel(String value) {
        this.trnChannel = value;
    }

    /**
     * Obtiene el valor de la propiedad trm.
     * 
     * @return
     *     possible object is
     *     {@link TrmType }
     *     
     */
    public TrmType getTRM() {
        return trm;
    }

    /**
     * Define el valor de la propiedad trm.
     * 
     * @param value
     *     allowed object is
     *     {@link TrmType }
     *     
     */
    public void setTRM(TrmType value) {
        this.trm = value;
    }
    
    
    
    public String getSource() {
		return Source;
	}

	public void setSource(String source) {
		Source = source;
	}

	@Override
    public String toString() {
    	XMLUtil<TransactionInqRsType> requestParser = new XMLUtil<TransactionInqRsType>();
		return requestParser.convertObjectToXml(this);			
    }

}
