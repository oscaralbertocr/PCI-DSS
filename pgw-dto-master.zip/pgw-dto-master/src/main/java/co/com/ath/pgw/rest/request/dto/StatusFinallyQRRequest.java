package co.com.ath.pgw.rest.request.dto;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonProperty;

import co.com.ath.pgw.core.logging.util.XMLUtil;
import co.com.ath.pgw.rest.dto.StatusQrDetail;

public class StatusFinallyQRRequest implements Serializable {

	private static final long serialVersionUID = 7353679876935584543L;
	
	@JsonProperty("PmtStatus")
	private StatusQrDetail pmtStatus;

	public StatusQrDetail getPmtStatus() {
		return pmtStatus;
	}

	public void setPmtStatus(StatusQrDetail pmtStatus) {
		this.pmtStatus = pmtStatus;
	}

	@Override
	public String toString() {
		XMLUtil<StatusFinallyQRRequest> util = new XMLUtil<>();
		return util.convertObjectToJson(this);
	}
}
