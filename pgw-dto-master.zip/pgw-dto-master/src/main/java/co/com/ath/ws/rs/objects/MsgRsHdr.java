package co.com.ath.ws.rs.objects;

import java.io.Serializable;
import java.util.Date;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.fasterxml.jackson.annotation.JsonProperty;

import co.com.ath.pgw.core.logging.util.XMLUtil;

@JsonInclude(Include.NON_NULL)
public class MsgRsHdr implements Serializable {

	private static final long serialVersionUID = 1L;

	@JsonProperty("Status")
	private Status status;

	@JsonProperty("EndDt")
	private Date endDt;

	public Status getStatus() {
		return status;
	}

	public void setStatus(Status status) {
		this.status = status;
	}

	public Date getEndDt() {
		return endDt;
	}

	public void setEndDt(Date endDt) {
		this.endDt = endDt;
	}
	
	@Override
	public String toString() {
		XMLUtil<MsgRsHdr> util = new XMLUtil<MsgRsHdr>();
		return util.convertObjectToJson(this);
	}
	
}
