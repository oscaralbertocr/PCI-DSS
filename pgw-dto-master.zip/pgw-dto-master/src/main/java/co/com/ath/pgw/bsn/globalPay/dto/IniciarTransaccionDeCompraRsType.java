
package co.com.ath.pgw.bsn.globalPay.dto;

import java.util.Date;
import java.util.List;
import java.util.Date;

import co.com.ath.pgw.core.logging.util.XMLUtil;
import co.com.ath.pgw.in.model.CabeceraRespuestaType;
import co.com.ath.pgw.in.model.InfoRespuestaType;
import co.com.ath.pgw.in.model.InfoTransaccionRespType;
import co.com.ath.pgw.in.model.ReferenceType;

/**
*
* @author camilo.bustamante@sophossolutions.com
* @version 1.0 03 Enero 2019
* @RQ31686 RBM_Integracion_Boton_TC_GlobalPay
* 
*/

/**
 * <p>Clase Java para IniciarTransaccionDeCompraRs_Type complex type.
 * 
 * <p>El siguiente fragmento de esquema especifica el contenido que se espera que haya en esta clase.
 * 
 * <pre>
 * &lt;complexType name="IniciarTransaccionDeCompraRs_Type">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element ref="{urn://ath.com.co/xsd/common/}CabeceraRespuesta"/>
 *         &lt;element ref="{urn://ath.com.co/xsd/common/}InfoRespuesta"/>
 *         &lt;element ref="{urn://ath.com.co/xsd/common/}InfoTransaccionResp"/>
 *         &lt;element ref="{urn://ath.com.co/xsd/common/}IdTransaccion"/>
 *         &lt;element ref="{urn://ath.com.co/xsd/common/}Pmtid"/>
 *         &lt;element ref="{urn://ath.com.co/xsd/common/}Reference" maxOccurs="50" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 */
public class IniciarTransaccionDeCompraRsType {

    protected CabeceraRespuestaType cabeceraRespuesta;
    
    protected InfoRespuestaType infoRespuesta;
   
    protected InfoTransaccionRespType infoTransaccionResp;
   
    protected Date compensationDate;
    
    public Date getCompensationDate() {
		return compensationDate;
	}

	public void setCompensationDate(Date compensationDate) {
		this.compensationDate = compensationDate;
	}

	public Date getEffDt() {
		return effDt;
	}

	public void setEffDt(Date effDt) {
		this.effDt = effDt;
	}

	protected Date effDt;
   
    protected String idTransaccion;
    
   
    protected String pmtid;
    
    
    protected List<ReferenceType> reference;

    
	public CabeceraRespuestaType getCabeceraRespuesta() {
		return cabeceraRespuesta;
	}

	public void setCabeceraRespuesta(CabeceraRespuestaType cabeceraRespuesta) {
		this.cabeceraRespuesta = cabeceraRespuesta;
	}

	public InfoRespuestaType getInfoRespuesta() {
		return infoRespuesta;
	}

	public void setInfoRespuesta(InfoRespuestaType infoRespuesta) {
		this.infoRespuesta = infoRespuesta;
	}

	public InfoTransaccionRespType getInfoTransaccionResp() {
		return infoTransaccionResp;
	}

	public void setInfoTransaccionResp(InfoTransaccionRespType infoTransaccionResp) {
		this.infoTransaccionResp = infoTransaccionResp;
	}

	public String getIdTransaccion() {
		return idTransaccion;
	}

	public void setIdTransaccion(String idTransaccion) {
		this.idTransaccion = idTransaccion;
	}

	public String getPmtid() {
		return pmtid;
	}

	public void setPmtid(String pmtid) {
		this.pmtid = pmtid;
	}
	
	public List<ReferenceType> getReference() {
		return reference;
	}

	public void setReference(List<ReferenceType> reference) {
		this.reference = reference;
	}

	@Override
	public String toString() {
		XMLUtil<IniciarTransaccionDeCompraRsType> requestParser = 
				new XMLUtil<IniciarTransaccionDeCompraRsType>();
		return requestParser.convertObjectToXml(this);
	}

}