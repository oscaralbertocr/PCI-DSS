/*
 * ACHCreateTransactionInDTO
 *  
 * GSI - Integración
 * Creado el: 8/10/2014
 *
 * Copyright (c) A Toda Hora S.A. Todos los derechos reservados
 * 
 * Este software es confidencial y es propietario de ATH, queda prohibido
 * su uso, reproducción y copia de manera parcial o permanente salvo autorización
 * expresa de A Toda Hora S.A o de quién represente sus derechos.
 */
package co.com.ath.pgw.bsn.dto.in;

import java.math.BigDecimal;
import java.math.BigInteger;
import java.util.Date;

import co.com.ath.pgw.core.logging.util.XMLUtil;

/**
 * DTO con la información que se le envia al servicio createTransactionPayment
 * de ACH.  
 *
 * @author Andrés Méndez Juanias <proveedor_mamendez@ath.com.co> 
 * @version 1.0 8/10/2014
 * @since 1.0
 */

public class ACHCreateTransactionInDTO {

    /** Código ach del banco */
    private String bankACHCode;
    
    /** NIT del comercio */
    private String commerceNIT;
    
    /** código ACH del comercio */
    private String commerceACHCode;
    
    /** valor total de la transacción */
    private BigDecimal transactionValue;
    
    /** valor del impuesto de la transacción */
    private BigDecimal taxValue;
    
    /** Identificador único de la petición */
    private Long rqid;
    
    /** Identificador de orden*/
    private BigInteger orderId;
    
    /** URL de retorno de a la pasarela */
    private String returnURL;
    
    /** Tipo de cliente 0=Natural - 1=Juridico */
    private String userType;
    
    /** Fecha de creación de la transacción en ACH */
    private Date creationDate;
    
    /** Descripción de la transacción */
    private String description;
    
    /** referencia 1 (sugerido IP) */
    private String reference1;
    
    /** referencia 2 (sugerido Tipo de documento cliente) */
    private String reference2;
    
    /** referencia 3 (sugerido Número de documento cliente) */
    private String reference3;
    
    /** referencia 4 (sugerido valor 0 ó 1 que indica que la ref1 es un token) */
    private String reference4;

	public String getReference4() {
		return reference4;
	}

	public void setReference4(String reference4) {
		this.reference4 = reference4;
	}

	/**
	 * Método encargado de recuperar el valor del atributo bankACHCode.
	 * @return El atributo bankACHCode asociado a la clase.
	 */
	public String getBankACHCode() {
		return bankACHCode;
	}

	/**
	 * Método encargado de actualizar el atributo bankACHCode.
	 * @param bankACHCode Nuevo valor para bankACHCode.
	 */
	public void setBankACHCode(String bankACHCode) {
		this.bankACHCode = bankACHCode;
	}

	/**
	 * Método encargado de recuperar el valor del atributo commerceNIT.
	 * @return El atributo commerceNIT asociado a la clase.
	 */
	public String getCommerceNIT() {
		return commerceNIT;
	}

	/**
	 * Método encargado de actualizar el atributo commerceNIT.
	 * @param commerceNIT Nuevo valor para commerceNIT.
	 */
	public void setCommerceNIT(String commerceNIT) {
		this.commerceNIT = commerceNIT;
	}

	/**
	 * Método encargado de recuperar el valor del atributo commerceACHCode.
	 * @return El atributo commerceACHCode asociado a la clase.
	 */
	public String getCommerceACHCode() {
		return commerceACHCode;
	}

	/**
	 * Método encargado de actualizar el atributo commerceACHCode.
	 * @param commerceACHCode Nuevo valor para commerceACHCode.
	 */
	public void setCommerceACHCode(String commerceACHCode) {
		this.commerceACHCode = commerceACHCode;
	}

	/**
	 * Método encargado de recuperar el valor del atributo transactionValue.
	 * @return El atributo transactionValue asociado a la clase.
	 */
	public BigDecimal getTransactionValue() {
		return transactionValue;
	}

	/**
	 * Método encargado de actualizar el atributo transactionValue.
	 * @param transactionValue Nuevo valor para transactionValue.
	 */
	public void setTransactionValue(BigDecimal transactionValue) {
		this.transactionValue = transactionValue;
	}

	/**
	 * Método encargado de recuperar el valor del atributo taxValue.
	 * @return El atributo taxValue asociado a la clase.
	 */
	public BigDecimal getTaxValue() {
		return taxValue;
	}

	/**
	 * Método encargado de actualizar el atributo taxValue.
	 * @param taxValue Nuevo valor para taxValue.
	 */
	public void setTaxValue(BigDecimal taxValue) {
		this.taxValue = taxValue;
	}

	/**
	 * Método encargado de recuperar el valor del atributo rqid.
	 * @return El atributo rqid asociado a la clase.
	 */
	public Long getRqid() {
		return rqid;
	}

	/**
	 * Método encargado de actualizar el atributo rqid.
	 * @param rqid Nuevo valor para rqid.
	 */
	public void setRqid(Long rqid) {
		this.rqid = rqid;
	}

	/**
	 * @return the orderId
	 */
	public BigInteger getOrderId() {
		return orderId;
	}

	/**
	 * @param orderId the orderId to set
	 */
	public void setOrderId(BigInteger orderId) {
		this.orderId = orderId;
	}

	/**
	 * Método encargado de recuperar el valor del atributo returnURL.
	 * @return El atributo returnURL asociado a la clase.
	 */
	public String getReturnURL() {
		return returnURL;
	}

	/**
	 * Método encargado de actualizar el atributo returnURL.
	 * @param returnURL Nuevo valor para returnURL.
	 */
	public void setReturnURL(String returnURL) {
		this.returnURL = returnURL;
	}

	/**
	 * Método encargado de recuperar el valor del atributo userType.
	 * @return El atributo userType asociado a la clase.
	 */
	public String getUserType() {
		return userType;
	}

	/**
	 * Método encargado de actualizar el atributo userType.
	 * @param userType Nuevo valor para userType.
	 */
	public void setUserType(String userType) {
		this.userType = userType;
	}

	/**
	 * Método encargado de recuperar el valor del atributo creationDate.
	 * @return El atributo creationDate asociado a la clase.
	 */
	public Date getCreationDate() {
		return creationDate;
	}

	/**
	 * Método encargado de actualizar el atributo creationDate.
	 * @param creationDate Nuevo valor para creationDate.
	 */
	public void setCreationDate(Date creationDate) {
		this.creationDate = creationDate;
	}

	/**
	 * Método encargado de recuperar el valor del atributo description.
	 * @return El atributo description asociado a la clase.
	 */
	public String getDescription() {
		return description;
	}

	/**
	 * Método encargado de actualizar el atributo description.
	 * @param description Nuevo valor para description.
	 */
	public void setDescription(String description) {
		this.description = description;
	}

	/**
	 * Método encargado de recuperar el valor del atributo reference1.
	 * @return El atributo reference1 asociado a la clase.
	 */
	public String getReference1() {
		return reference1;
	}

	/**
	 * Método encargado de actualizar el atributo reference1.
	 * @param reference1 Nuevo valor para reference1.
	 */
	public void setReference1(String reference1) {
		this.reference1 = reference1;
	}

	/**
	 * Método encargado de recuperar el valor del atributo reference2.
	 * @return El atributo reference2 asociado a la clase.
	 */
	public String getReference2() {
		return reference2;
	}

	/**
	 * Método encargado de actualizar el atributo reference2.
	 * @param reference2 Nuevo valor para reference2.
	 */
	public void setReference2(String reference2) {
		this.reference2 = reference2;
	}

	/**
	 * Método encargado de recuperar el valor del atributo reference3.
	 * @return El atributo reference3 asociado a la clase.
	 */
	public String getReference3() {
		return reference3;
	}

	/**
	 * Método encargado de actualizar el atributo reference3.
	 * @param reference3 Nuevo valor para reference3.
	 */
	public void setReference3(String reference3) {
		this.reference3 = reference3;
	}
    	
	@Override
	public String toString() {
		XMLUtil<ACHCreateTransactionInDTO> requestParser = new XMLUtil<ACHCreateTransactionInDTO>();
		return requestParser.convertObjectToXml(this);
	}
}
