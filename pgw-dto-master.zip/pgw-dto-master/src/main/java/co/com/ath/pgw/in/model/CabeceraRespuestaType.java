
package co.com.ath.pgw.in.model;


/**
*
* @author camilo.bustamante@sophossolutions.com
* @version 1.0 03 Enero 2019
* @RQ31686 RBM_Integracion_Boton_TC_GlobalPay
* 
*/

/**
 * <p>Clase Java para CabeceraRespuesta_Type complex type.
 * 
 * <p>El siguiente fragmento de esquema especifica el contenido que se espera que haya en esta clase.
 * 
 * <pre>
 * &lt;complexType name="CabeceraRespuesta_Type">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element ref="{urn://ath.com.co/xsd/common/}InfoPuntoInteraccion" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
public class CabeceraRespuestaType {

    protected InfoPuntoInteraccionType infoPuntoInteraccion;

	public InfoPuntoInteraccionType getInfoPuntoInteraccion() {
		return infoPuntoInteraccion;
	}

	public void setInfoPuntoInteraccion(InfoPuntoInteraccionType infoPuntoInteraccion) {
		this.infoPuntoInteraccion = infoPuntoInteraccion;
	}

    
}
