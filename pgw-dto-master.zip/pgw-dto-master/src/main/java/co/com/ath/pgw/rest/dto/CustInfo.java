package co.com.ath.pgw.rest.dto;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonProperty;

public class CustInfo implements Serializable {
	
	@JsonProperty("PersonInfo")
	private PersonInfo personInfo;
	
	@JsonProperty("CustName")
	private CustName custName;

	@JsonProperty("CustType")
	private String custType;
	
	private final static long serialVersionUID = 1042615171471496392L;

	public PersonInfo getPersonInfo() {
		return personInfo;
	}

	public void setPersonInfo(PersonInfo personInfo) {
		this.personInfo = personInfo;
	}

	public String getCustType() {
		return custType;
	}

	public void setCustType(String custType) {
		this.custType = custType;
	}

	public CustName getCustName() {
		return custName;
	}
	
	public void setCustName(CustName custName) {
		this.custName = custName;
	}
	
}