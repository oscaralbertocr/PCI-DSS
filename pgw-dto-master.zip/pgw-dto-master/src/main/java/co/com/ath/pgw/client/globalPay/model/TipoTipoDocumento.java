
package co.com.ath.pgw.client.globalPay.model;

import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Clase Java para TipoTipoDocumento.
 * 
 * <p>El siguiente fragmento de esquema especifica el contenido que se espera que haya en esta clase.
 * <p>
 * <pre>
 * &lt;simpleType name="TipoTipoDocumento"&gt;
 *   &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string"&gt;
 *     &lt;enumeration value="CC"/&gt;
 *     &lt;enumeration value="TI"/&gt;
 *     &lt;enumeration value="CE"/&gt;
 *     &lt;enumeration value="NI"/&gt;
 *   &lt;/restriction&gt;
 * &lt;/simpleType&gt;
 * </pre>
 * 
 */
@XmlType(name = "TipoTipoDocumento")
@XmlEnum
public enum TipoTipoDocumento {

    CC,
    TI,
    CE,
	NI;

    public String value() {
        return name();
    }

    public static TipoTipoDocumento fromValue(String v) {
        return valueOf(v);
    }

}
