
package co.com.ath.pgw.client.globalPay.model;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Clase Java para TipoInfoDispersionCompra complex type.
 * 
 * <p>El siguiente fragmento de esquema especifica el contenido que se espera que haya en esta clase.
 * 
 * <pre>
 * &lt;complexType name="TipoInfoDispersionCompra"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="idTerminal"&gt;
 *           &lt;simpleType&gt;
 *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string"&gt;
 *               &lt;maxLength value="8"/&gt;
 *             &lt;/restriction&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="idAdquiriente"&gt;
 *           &lt;simpleType&gt;
 *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string"&gt;
 *               &lt;maxLength value="19"/&gt;
 *             &lt;/restriction&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="infoCompra" type="{http://www.rbm.com.co/esb/globalpay/}TipoInfoCompra"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "TipoInfoDispersionCompra", propOrder = {
    "idTerminal",
    "idAdquiriente",
    "infoCompra"
})
public class TipoInfoDispersionCompra {

    @XmlElement(required = true)
    protected String idTerminal;
    @XmlElement(required = true)
    protected String idAdquiriente;
    @XmlElement(required = true)
    protected TipoInfoCompra infoCompra;

    /**
     * Obtiene el valor de la propiedad idTerminal.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getIdTerminal() {
        return idTerminal;
    }

    /**
     * Define el valor de la propiedad idTerminal.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setIdTerminal(String value) {
        this.idTerminal = value;
    }

    /**
     * Obtiene el valor de la propiedad idAdquiriente.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getIdAdquiriente() {
        return idAdquiriente;
    }

    /**
     * Define el valor de la propiedad idAdquiriente.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setIdAdquiriente(String value) {
        this.idAdquiriente = value;
    }

    /**
     * Obtiene el valor de la propiedad infoCompra.
     * 
     * @return
     *     possible object is
     *     {@link TipoInfoCompra }
     *     
     */
    public TipoInfoCompra getInfoCompra() {
        return infoCompra;
    }

    /**
     * Define el valor de la propiedad infoCompra.
     * 
     * @param value
     *     allowed object is
     *     {@link TipoInfoCompra }
     *     
     */
    public void setInfoCompra(TipoInfoCompra value) {
        this.infoCompra = value;
    }

}
