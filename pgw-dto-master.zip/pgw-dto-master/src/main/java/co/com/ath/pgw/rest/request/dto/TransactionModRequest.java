
package co.com.ath.pgw.rest.request.dto;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonProperty;

import co.com.ath.pgw.core.logging.util.XMLUtil;
import co.com.ath.pgw.rest.dto.CardAcctId;
import co.com.ath.pgw.rest.dto.CustInfo;
import co.com.ath.pgw.rest.dto.PmtStatus;
import co.com.ath.pgw.rest.dto.Status;

public class TransactionModRequest implements Serializable {

	@JsonProperty("PmtStatus")
	private PmtStatus pmtStatus;
	
	@JsonProperty("CustInfo")
	private CustInfo custInfo;
	
	@JsonProperty("CardAcctId")
	private CardAcctId cardAcctId;
	
	@JsonProperty("Status")
	private Status status;
	
	private static final long serialVersionUID = -4118703144143500927L;

	public PmtStatus getPmtStatus() {
		return pmtStatus;
	}

	public void setPmtStatus(PmtStatus pmtStatus) {
		this.pmtStatus = pmtStatus;
	}

	public CustInfo getCustInfo() {
		return custInfo;
	}

	public void setCustInfo(CustInfo custInfo) {
		this.custInfo = custInfo;
	}

	public CardAcctId getCardAcctId() {
		return cardAcctId;
	}

	public void setCardAcctId(CardAcctId cardAcctId) {
		this.cardAcctId = cardAcctId;
	}

	public Status getStatus() {
		return status;
	}

	public void setStatus(Status status) {
		this.status = status;
	}

	@Override
	public String toString() {
		XMLUtil<TransactionModRequest> util = new XMLUtil<TransactionModRequest>();
		return util.convertObjectToJson(this);
	}

}
