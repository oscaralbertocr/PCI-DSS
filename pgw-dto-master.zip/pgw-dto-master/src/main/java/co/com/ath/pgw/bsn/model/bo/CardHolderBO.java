/*
 * CardHolderVO
 *  
 * GSI - Integración
 * Creado el: 28/08/2014
 *
 * Copyright (c) A Toda Hora S.A. Todos los derechos reservados
 * 
 * Este software es confidencial y es propietario de ATH, queda prohibido
 * su uso, reproducción y copia de manera parcial o permanente salvo autorización
 * expresa de A Toda Hora S.A o de quién represente sus derechos.
 */
package co.com.ath.pgw.bsn.model.bo;


/**
 * Representa un tarjetahabiente en el modelo de dominio.
 * 
 * @author proveedor_japiza
 * @version 1.0 29 Ago 2014
 * @since 1.0
 */
public class CardHolderBO {	

	/**
	 * Identificador único del tarjetahabiente.
	 */
	private Long id;

	/**
	 * Número de identificación del tarjetahabiente.
	 */
	private String identificationNumber;

	/**
	 * Nombre del tarjetahabiente.
	 */
	private String name;

	/**
	 * Apellido(s) del tarjetahabiente.
	 */
	private String lastName;

	/**
	 * Correo electrónico del tarjetahabiente.
	 */
	private String email;

	/**
	 * Número de celular del tarjetahabiente.
	 */
	private String mobileNumber;

	/**
	 * Dirección del tarjetahabiente.
	 */
	private String address;

	/**
	 * Construye un tarjetahabiente sin datos
	 */
	public CardHolderBO(){
		super();
	}

	/**
	 * Retorna el identificador único del tarjetahabiente.
	 * 
	 * @return Identificador único del tarjetahabiente.
	 */
	public Long getId() {
		return id;
	}

	/**
	 * Establece el identificador único del tarjetahabiente.
	 * 
	 * @param id Identificador único del tarjetahabiente.
	 */
	public void setId(Long id) {
		this.id = id;
	}

	/**
	 * Retorna el número de identificación del tarjetahabiente.
	 * 
	 * @return Número de identificación del tarjetahabiente.
	 */
	public String getIdentificationNumber() {
		return identificationNumber;
	}

	/**
	 * Establece el número de identificación del tarjetahabiente.
	 * 
	 * @param identificationNumber Número de identificación del tarjetahabiente.
	 */
	public void setIdentificationNumber(String identificationNumber) {
		this.identificationNumber = identificationNumber;
	}

	/**
	 * Retorna el nombre del tarjetahabiente.
	 * 
	 * @return Nombre del tarjetahabiente.
	 */
	public String getName() {
		return name;
	}

	/**
	 * Establece el nombre del tarjetahabiente.
	 * @param name Nombre del tarjetahabiente.
	 */
	public void setName(String name) {
		this.name = name;
	}

	/**
	 * Retorna el(los) apellido(s) del tarjetahabiente.
	 * 
	 * @return Apellido del tarjetahabiente.
	 */
	public String getLastName() {
		return lastName;
	}

	/**
	 * Establece el(los) apellido(s) del tarjetahabiente.
	 * 
	 * @param lastName Apellido(s) del tarjetahabiente.
	 */
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	/**
	 * Retorna el correo electrónico del tarjetahabiente.
	 * 
	 * @return Correo electrónico del tarjetahabiente.
	 */
	public String getEmail() {
		return email;
	}

	/**
	 * Establece el correo electrónico del tarjetahabiente.
	 * 
	 * @param email Correo electrónico del tarjetahabiente.
	 */
	public void setEmail(String email) {
		this.email = email;
	}

	/**
	 * Retorna el número de celular del tarjetahabiente.
	 * 
	 * @return Número de celular del tarjetahabiente.
	 */
	public String getMobileNumber() {
		return mobileNumber;
	}

	/**
	 * Establece el número de celular del tarjetahabiente.
	 * 
	 * @param mobileNumber Número celular del tarjetahabiente.
	 */
	public void setMobileNumber(String mobileNumber) {
		this.mobileNumber = mobileNumber;
	}

	/**
	 * Retorna la dirección del tarjetahabiente.
	 * @return Dirección del tarjetahabiente.
	 */
	public String getAddress() {
		return address;
	}

	/**
	 * Establece la dirección del tarjetahabiente.
	 * 
	 * @param address Dirección del tarjetahabiente.
	 */
	public void setAddress(String address) {
		this.address = address;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime
				* result
				+ ((identificationNumber == null) ? 0 : identificationNumber
						.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		CardHolderBO other = (CardHolderBO) obj;
		if (identificationNumber == null) {
			if (other.identificationNumber != null)
				return false;
		} else if (!identificationNumber.equals(other.identificationNumber))
			return false;
		return true;
	}

	@Override
	public String toString() {
		return "CardHolderVO [identificationNumber=" + identificationNumber
				+ ", name=" + name + ", lastName=" + lastName + "]";
	}
	
}