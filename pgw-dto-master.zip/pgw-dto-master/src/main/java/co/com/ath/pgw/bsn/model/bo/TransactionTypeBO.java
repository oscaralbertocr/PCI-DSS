/*
 * TransactionTypesVO
 *  
 * GSI - Integración
 * Creado el: 29/08/2014
 *
 * Copyright (c) A Toda Hora S.A. Todos los derechos reservados
 * 
 * Este software es confidencial y es propietario de ATH, queda prohibido
 * su uso, reproducción y copia de manera parcial o permanente salvo autorización
 * expresa de A Toda Hora S.A o de quién represente sus derechos.
 */
package co.com.ath.pgw.bsn.model.bo;

/**
 * Representa un tipo de transacción. Esta entidad pertenece al modelo
 * de negocio.
 *  
 * @author proveedor_japiza
 * @version 1.0 19 Ago 2014
 * @since 1.0
 */
public class TransactionTypeBO {

	/** id Atributo de la clase. */
	private String id;
	
	/** transactionType Atributo de la clase. */
	private String description;
	
	/**
	 * Construye un tipo de transacción.
	 */
	public TransactionTypeBO(){
		super();
	}

	/**
	 * Construye un tipo de transacción especificando su id.
	 * 
	 * @param id Identificador del tipo de transacción.
	 */
	public TransactionTypeBO(String id) {
		this.id = id;
	}

	/**
	 * Retorna el identificador del tipo de transacción.
	 * 
	 * @return Identificador del tipo de transacción.
	 */
	public String getId() {
		return id;
	}

	/**
	 * Establece el identificador del tipo de transacción.
	 * 
	 * @param id Identificador del tipo de transacción.
	 */
	public void setId(String id) {
		this.id = id;
	}

	/**
	 * Retorna la descripción del tipo de transacción.
	 * 
	 * @return Descripción del tipo de transacción.
	 */
	public String getDescription() {
		return description;
	}

	/**
	 * Establece la descripción del tipo de transacción.
	 * @param description Descripción del tipo de transacción.
	 */
	public void setDescription(String description) {
		this.description = description;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((id == null) ? 0 : id.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		TransactionTypeBO other = (TransactionTypeBO) obj;
		if (id == null) {
			if (other.id != null)
				return false;
		} else if (!id.equals(other.id))
			return false;
		return true;
	}

	@Override
	public String toString() {
		return "TransactionTypeVO [id=" + id + ", description=" + description
				+ "]";
	}

}