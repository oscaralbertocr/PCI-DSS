
package co.com.ath.pgw.client.tokenize.model;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlSchemaType;
import javax.xml.bind.annotation.XmlSeeAlso;
import javax.xml.bind.annotation.XmlType;
import javax.xml.datatype.XMLGregorianCalendar;

import co.com.ath.pgw.client.tokenize.dto.TokenizedDataRqType;


/**
 * <p>Clase Java para SvcRq_Type complex type.
 * 
 * <p>El siguiente fragmento de esquema especifica el contenido que se espera que haya en esta clase.
 * 
 * <pre>
 * &lt;complexType name="SvcRq_Type"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element ref="{urn://ath.com.co/xsd/common/}RqUID"/&gt;
 *         &lt;element ref="{urn://ath.com.co/xsd/common/}Channel"/&gt;
 *         &lt;element ref="{urn://ath.com.co/xsd/common/}ClientDt"/&gt;
 *         &lt;element ref="{urn://ath.com.co/xsd/common/}IPAddr"/&gt;
 *         &lt;element ref="{urn://ath.com.co/xsd/common/}UserId"/&gt;
 *         &lt;element ref="{urn://ath.com.co/xsd/common/}BankInfo"/&gt;
 *         &lt;element ref="{urn://ath.com.co/xsd/common/}TokenizedDataInfoRq"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "SvcRq_Type", propOrder = {
    "rqUID",
    "channel",
    "clientDt",
    "ipAddr",
    "userId",
    "bankInfo",
    "tokenizedDataInfoRq"
})
@XmlSeeAlso({
    TokenizedDataRqType.class
})
public class SvcRqType {

    @XmlElement(name = "RqUID", namespace = "urn://ath.com.co/xsd/common/")
    protected long rqUID;
    @XmlElement(name = "Channel", required = true, namespace = "urn://ath.com.co/xsd/common/")
    protected String channel;
    @XmlElement(name = "ClientDt", required = true, namespace = "urn://ath.com.co/xsd/common/")
    @XmlSchemaType(name = "dateTime")
    protected XMLGregorianCalendar clientDt;
    @XmlElement(name = "IPAddr", required = true, namespace = "urn://ath.com.co/xsd/common/")
    protected String ipAddr;
    @XmlElement(name = "UserId", required = true, namespace = "urn://ath.com.co/xsd/common/")
    protected UserIdType userId;
    @XmlElement(name = "BankInfo", namespace = "urn://ath.com.co/xsd/common/", required = true)
    protected BankInfoType bankInfo;
    @XmlElement(name = "TokenizedDataInfoRq", required = true, namespace = "urn://ath.com.co/xsd/common/")
    protected TokenizedDataInfoRqType tokenizedDataInfoRq;

    /**
     * Obtiene el valor de la propiedad rqUID.
     * 
     */
    public long getRqUID() {
        return rqUID;
    }

    /**
     * Define el valor de la propiedad rqUID.
     * 
     */
    public void setRqUID(long value) {
        this.rqUID = value;
    }

    /**
     * Obtiene el valor de la propiedad channel.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getChannel() {
        return channel;
    }

    /**
     * Define el valor de la propiedad channel.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setChannel(String value) {
        this.channel = value;
    }

    /**
     * Obtiene el valor de la propiedad clientDt.
     * 
     * @return
     *     possible object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public XMLGregorianCalendar getClientDt() {
        return clientDt;
    }

    /**
     * Define el valor de la propiedad clientDt.
     * 
     * @param value
     *     allowed object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public void setClientDt(XMLGregorianCalendar value) {
        this.clientDt = value;
    }

    /**
     * Obtiene el valor de la propiedad ipAddr.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getIPAddr() {
        return ipAddr;
    }

    /**
     * Define el valor de la propiedad ipAddr.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setIPAddr(String value) {
        this.ipAddr = value;
    }

    /**
     * Obtiene el valor de la propiedad userId.
     * 
     * @return
     *     possible object is
     *     {@link UserIdType }
     *     
     */
    public UserIdType getUserId() {
        return userId;
    }

    /**
     * Define el valor de la propiedad userId.
     * 
     * @param value
     *     allowed object is
     *     {@link UserIdType }
     *     
     */
    public void setUserId(UserIdType value) {
        this.userId = value;
    }
    
    /**
     * Obtiene el valor de la propiedad bankInfo.
     * 
     * @return
     *     possible object is
     *     {@link BankInfoType }
     *     
     */
    public BankInfoType getBankInfo() {
        return bankInfo;
    }

    /**
     * Define el valor de la propiedad bankInfo.
     * 
     * @param value
     *     allowed object is
     *     {@link BankInfoType }
     *     
     */
    public void setBankInfo(BankInfoType value) {
        this.bankInfo = value;
    }

    /**
     * Obtiene el valor de la propiedad tokenizedDataInfoRq.
     * 
     * @return
     *     possible object is
     *     {@link TokenizedDataInfoRqType }
     *     
     */
    public TokenizedDataInfoRqType getTokenizedDataInfoRq() {
        return tokenizedDataInfoRq;
    }

    /**
     * Define el valor de la propiedad tokenizedDataInfoRq.
     * 
     * @param value
     *     allowed object is
     *     {@link TokenizedDataInfoRqType }
     *     
     */
    public void setTokenizedDataInfoRq(TokenizedDataInfoRqType value) {
        this.tokenizedDataInfoRq = value;
    }

}
