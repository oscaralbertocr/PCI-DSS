
package co.com.ath.pgw.in.model;

import java.math.BigDecimal;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;

/**
*
* @author camilo.bustamante@sophossolutions.com
* @version 1.0 03 Enero 2019
* @RQ31686 RBM_Integracion_Boton_TC_GlobalPay
* 
*/

/**
 * <p>Clase Java para MontoDetallado_Type complex type.
 * 
 * <p>El siguiente fragmento de esquema especifica el contenido que se espera que haya en esta clase.
 * 
 * <pre>
 * &lt;complexType name="MontoDetallado_Type">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element ref="{urn://ath.com.co/xsd/common/}TipoMontoDetallado" minOccurs="0"/>
 *         &lt;element ref="{urn://ath.com.co/xsd/common/}Monto" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "MontoDetallado_Type", propOrder = {
    "tipoMontoDetallado",
    "monto"
})
public class MontoDetalladoType {

    @XmlElement(name = "TipoMontoDetallado")
    protected String tipoMontoDetallado;
    
    @XmlElement(name = "Monto")
    protected BigDecimal monto;

    
	public String getTipoMontoDetallado() {
		return tipoMontoDetallado;
	}

	public void setTipoMontoDetallado(String tipoMontoDetallado) {
		this.tipoMontoDetallado = tipoMontoDetallado;
	}

	public BigDecimal getMonto() {
		return monto;
	}

	public void setMonto(BigDecimal monto) {
		this.monto = monto;
	}

}
