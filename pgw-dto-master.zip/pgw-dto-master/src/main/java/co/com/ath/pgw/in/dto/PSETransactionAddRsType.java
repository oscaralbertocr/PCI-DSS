package co.com.ath.pgw.in.dto;

import co.com.ath.pgw.core.logging.util.XMLUtil;
import co.com.ath.pgw.in.model.OrderInfoType;
import co.com.ath.pgw.in.model.SvcRsType;
import co.com.ath.pgw.in.model.TransactionStatusType;

public class PSETransactionAddRsType extends SvcRsType {

	protected long statusCode;

	protected String statusDesc;

	protected String pmtId;

	protected TransactionStatusType transactionStatus;

	protected String trazabilityCode;

	protected String portalURL;

	protected String token;

	protected String state;

	protected OrderInfoType orderInfo = new OrderInfoType();

	/**
	 * Obtiene el valor de la propiedad statusCode.
	 * 
	 */
	public long getStatusCode() {
		return statusCode;
	}

	/**
	 * Define el valor de la propiedad statusCode.
	 * 
	 */
	public void setStatusCode(long value) {
		this.statusCode = value;
	}

	/**
	 * Obtiene el valor de la propiedad statusDesc.
	 * 
	 * @return possible object is {@link String }
	 * 
	 */
	public String getStatusDesc() {
		return statusDesc;
	}

	/**
	 * Define el valor de la propiedad statusDesc.
	 * 
	 * @param value allowed object is {@link String }
	 * 
	 */
	public void setStatusDesc(String value) {
		this.statusDesc = value;
	}

	/**
	 * Obtiene el valor de la propiedad pmtId.
	 * 
	 * @return possible object is {@link String }
	 * 
	 */
	public String getPmtId() {
		return pmtId;
	}

	/**
	 * Define el valor de la propiedad pmtId.
	 * 
	 * @param value allowed object is {@link String }
	 * 
	 */
	public void setPmtId(String value) {
		this.pmtId = value;
	}

	/**
	 * Obtiene el valor de la propiedad transactionStatus.
	 * 
	 * @return possible object is {@link TransactionStatusType }
	 * 
	 */
	public TransactionStatusType getTransactionStatus() {
		return transactionStatus;
	}

	/**
	 * Define el valor de la propiedad transactionStatus.
	 * 
	 * @param value allowed object is {@link TransactionStatusType }
	 * 
	 */
	public void setTransactionStatus(TransactionStatusType value) {
		this.transactionStatus = value;
	}

	/**
	 * Obtiene el valor de la propiedad trazabilityCode.
	 * 
	 * @return possible object is {@link String }
	 * 
	 */
	public String getTrazabilityCode() {
		return trazabilityCode;
	}

	/**
	 * Define el valor de la propiedad trazabilityCode.
	 * 
	 * @param value allowed object is {@link String }
	 * 
	 */
	public void setTrazabilityCode(String value) {
		this.trazabilityCode = value;
	}

	/**
	 * Obtiene el valor de la propiedad portalURL.
	 * 
	 * @return possible object is {@link String }
	 * 
	 */
	public String getPortalURL() {
		return portalURL;
	}

	/**
	 * Define el valor de la propiedad portalURL.
	 * 
	 * @param value allowed object is {@link String }
	 * 
	 */
	public void setPortalURL(String value) {
		this.portalURL = value;
	}

	/** INICIO-C01 */
	/**
	 * Define el valor de la propiedad token.
	 * 
	 * @param value allowed object is {@link String }
	 * 
	 */
	public void setToken(String token) {
		this.token = token;
	}

	/**
	 * Obtiene el valor de la propiedad token.
	 * 
	 * @return possible object is {@link String }
	 * 
	 */
	public String getToken() {
		return token;
	}

	/** FIN-C01 */

	public String getState() {
		return state;
	}

	public void setState(String state) {
		this.state = state;
	}

	public OrderInfoType getOrderInfo() {
		return orderInfo;
	}

	public void setOrderInfo(OrderInfoType orderInfo) {
		this.orderInfo = orderInfo;
	}
	
	@Override
    public String toString() {
    	XMLUtil<PSETransactionAddRsType> requestParser = new XMLUtil<PSETransactionAddRsType>();
		return requestParser.convertObjectToXml(this);			
    }

}
