
package co.com.ath.pgw.client.rbm.common;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlSchemaType;
import javax.xml.bind.annotation.XmlType;
import javax.xml.datatype.XMLGregorianCalendar;


/**
 * 
 * @author Jesus Octavio Avendaño <jesus.avendano@sophossolutions.com> 
 * @version 1.0 17/06/2020
 * @since 1.0
 * 
 * <p>Clase Java para TransactionStatus_Type complex type.
 * 
 * <p>El siguiente fragmento de esquema especifica el contenido que se espera que haya en esta clase.
 * 
 * <pre>
 * &lt;complexType name="TransactionStatus_Type">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element ref="{urn://ath.com.co/xsd/common/}TrnStatusCode" minOccurs="0"/>
 *         &lt;element ref="{urn://ath.com.co/xsd/common/}TrnStatusDesc" minOccurs="0"/>
 *         &lt;element ref="{urn://ath.com.co/xsd/common/}TrnServerStatusCode" minOccurs="0"/>
 *         &lt;element ref="{urn://ath.com.co/xsd/common/}TrnServerStatusDesc" minOccurs="0"/>
 *         &lt;element ref="{urn://ath.com.co/xsd/common/}EffDt" minOccurs="0"/>
 *         &lt;element ref="{urn://ath.com.co/xsd/common/}CompensationDt" minOccurs="0"/>
 *         &lt;element ref="{urn://ath.com.co/xsd/common/}ApprovalId" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "TransactionStatus_Type", propOrder = {
    "trnStatusCode",
    "trnStatusDesc",
    "trnServerStatusCode",
    "trnServerStatusDesc",
    "effDt",
    "compensationDt",
    "approvalId"
})
public class TransactionStatusType {

    @XmlElement(name = "TrnStatusCode")
    protected Long trnStatusCode;
    @XmlElement(name = "TrnStatusDesc")
    protected String trnStatusDesc;
    @XmlElement(name = "TrnServerStatusCode")
    protected String trnServerStatusCode;
    @XmlElement(name = "TrnServerStatusDesc")
    protected String trnServerStatusDesc;
    @XmlElement(name = "EffDt")
    @XmlSchemaType(name = "dateTime")
    protected XMLGregorianCalendar effDt;
    @XmlElement(name = "CompensationDt")
    @XmlSchemaType(name = "dateTime")
    protected XMLGregorianCalendar compensationDt;
    @XmlElement(name = "ApprovalId")
    protected String approvalId;

    /**
     * Obtiene el valor de la propiedad trnStatusCode.
     * 
     * @return
     *     possible object is
     *     {@link Long }
     *     
     */
    public Long getTrnStatusCode() {
        return trnStatusCode;
    }

    /**
     * Define el valor de la propiedad trnStatusCode.
     * 
     * @param value
     *     allowed object is
     *     {@link Long }
     *     
     */
    public void setTrnStatusCode(Long value) {
        this.trnStatusCode = value;
    }

    /**
     * Obtiene el valor de la propiedad trnStatusDesc.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getTrnStatusDesc() {
        return trnStatusDesc;
    }

    /**
     * Define el valor de la propiedad trnStatusDesc.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setTrnStatusDesc(String value) {
        this.trnStatusDesc = value;
    }

    /**
     * Obtiene el valor de la propiedad trnServerStatusCode.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getTrnServerStatusCode() {
        return trnServerStatusCode;
    }

    /**
     * Define el valor de la propiedad trnServerStatusCode.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setTrnServerStatusCode(String value) {
        this.trnServerStatusCode = value;
    }

    /**
     * Obtiene el valor de la propiedad trnServerStatusDesc.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getTrnServerStatusDesc() {
        return trnServerStatusDesc;
    }

    /**
     * Define el valor de la propiedad trnServerStatusDesc.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setTrnServerStatusDesc(String value) {
        this.trnServerStatusDesc = value;
    }

    /**
     * Obtiene el valor de la propiedad effDt.
     * 
     * @return
     *     possible object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public XMLGregorianCalendar getEffDt() {
        return effDt;
    }

    /**
     * Define el valor de la propiedad effDt.
     * 
     * @param value
     *     allowed object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public void setEffDt(XMLGregorianCalendar value) {
        this.effDt = value;
    }

    /**
     * Obtiene el valor de la propiedad compensationDt.
     * 
     * @return
     *     possible object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public XMLGregorianCalendar getCompensationDt() {
        return compensationDt;
    }

    /**
     * Define el valor de la propiedad compensationDt.
     * 
     * @param value
     *     allowed object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public void setCompensationDt(XMLGregorianCalendar value) {
        this.compensationDt = value;
    }

    /**
     * Obtiene el valor de la propiedad approvalId.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getApprovalId() {
        return approvalId;
    }

    /**
     * Define el valor de la propiedad approvalId.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setApprovalId(String value) {
        this.approvalId = value;
    }

}
