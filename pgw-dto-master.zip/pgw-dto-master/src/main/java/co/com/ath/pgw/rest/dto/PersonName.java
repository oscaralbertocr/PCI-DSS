
package co.com.ath.pgw.rest.dto;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonProperty;

public class PersonName implements Serializable
{
	@JsonProperty("LastName")
    private String lastName;
	
	@JsonProperty("FirstName")
    private String firstName;
	
	@JsonProperty("MiddleName")
    private String middleName;
	
	@JsonProperty("SecondLastName")
    private String secondLastName;
	
	@JsonProperty("LegalName")
    private String legalName;
	
	@JsonProperty("Nickname")
    private String nickname;
	
	@JsonProperty("FullName")
    private String fullName;
	
    private final static long serialVersionUID = 1418169688037523149L;

    public String getLastName() {
        return lastName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    public String getFirstName() {
        return firstName;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public String getMiddleName() {
        return middleName;
    }

    public void setMiddleName(String middleName) {
        this.middleName = middleName;
    }

    public String getSecondLastName() {
        return secondLastName;
    }

    public void setSecondLastName(String secondLastName) {
        this.secondLastName = secondLastName;
    }

    public String getLegalName() {
        return legalName;
    }

    public void setLegalName(String legalName) {
        this.legalName = legalName;
    }
    
    public String getNickname() {
        return nickname;
    }
    
    public void setNickname(String nickname) {
        this.nickname = nickname;
    }

	public String getFullName() {
		return fullName;
	}

	public void setFullName(String fullName) {
		this.fullName = fullName;
	}
    
}
