/*
 * UserBO
 *  
 * GSI - Integración
 * Creado el: 28/08/2014
 *
 * Copyright (c) A Toda Hora S.A. Todos los derechos reservados
 * 
 * Este software es confidencial y es propietario de ATH, queda prohibido
 * su uso, reproducción y copia de manera parcial o permanente salvo autorización
 * expresa de A Toda Hora S.A o de quién represente sus derechos.
 */
package co.com.ath.pgw.bsn.model.bo;

/**
 * 
 * @author proveedor_lbonilla
 * @version 1.0
 *
 */
public class UserBO{

	/**
	 * Tipo de identificacion del usuario
	 */
	private String custIdType;

	/**
	 * Numero de identificacion del usuario
	 */
	private String custIdNum;
	
	/**
	 * 
	 */
	private String custLoginId;

	public String getCustIdType() {
		return custIdType;
	}

	public void setCustIdType(String custIdType) {
		this.custIdType = custIdType;
	}

	public String getCustIdNum() {
		return custIdNum;
	}

	public void setCustIdNum(String custIdNum) {
		this.custIdNum = custIdNum;
	}

	public String getCustLoginId() {
		return custLoginId;
	}

	public void setCustLoginId(String custLoginId) {
		this.custLoginId = custLoginId;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((custIdNum == null) ? 0 : custIdNum.hashCode());
		result = prime * result + ((custIdType == null) ? 0 : custIdType.hashCode());
		result = prime * result + ((custLoginId == null) ? 0 : custLoginId.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		UserBO other = (UserBO) obj;
		if (custIdNum == null) {
			if (other.custIdNum != null)
				return false;
		} else if (!custIdNum.equals(other.custIdNum))
			return false;
		if (custIdType == null) {
			if (other.custIdType != null)
				return false;
		} else if (!custIdType.equals(other.custIdType))
			return false;
		if (custLoginId == null) {
			if (other.custLoginId != null)
				return false;
		} else if (!custLoginId.equals(other.custLoginId))
			return false;
		return true;
	}

	@Override
	public String toString() {
		return "UserBO [custIdType=" + custIdType + ", custIdNum=" + custIdNum + ", custLoginId=" + custLoginId + "]";
	}

}