
package co.com.ath.pgw.rest.dto;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonProperty;

public class GlobalPayCard implements Serializable {

	private static final long serialVersionUID = 6936168815958038602L;

	@JsonProperty("bin")
	private String bin;

	@JsonProperty("holder_name")
	private String holderName;

	@JsonProperty("type")
	private String type;

	@JsonProperty("number")
	private String number;

	@JsonProperty("origin")
	private String origin;

	public String getBin() {
		return bin;
	}

	public void setBin(String bin) {
		this.bin = bin;
	}

	public String getHolderName() {
		return holderName;
	}

	public void setHolderName(String holderName) {
		this.holderName = holderName;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public String getNumber() {
		return number;
	}

	public void setNumber(String number) {
		this.number = number;
	}

	public String getOrigin() {
		return origin;
	}

	public void setOrigin(String origin) {
		this.origin = origin;
	}

}
