
package co.com.ath.pgw.bsn.globalPay.model;

import java.math.BigDecimal;
import java.math.BigInteger;
import javax.xml.bind.JAXBElement;
import javax.xml.bind.annotation.XmlElementDecl;
import javax.xml.bind.annotation.XmlRegistry;
import javax.xml.datatype.XMLGregorianCalendar;
import javax.xml.namespace.QName;


/**
 * This object contains factory methods for each 
 * Java content interface and Java element interface 
 * generated in the co.com.ath.pgw.ws.client.rbm.globalPay package. 
 * <p>An ObjectFactory allows you to programatically 
 * construct new instances of the Java representation 
 * for XML content. The Java representation of XML 
 * content can consist of schema derived interfaces 
 * and classes representing the binding of schema 
 * type definitions, element declarations and model 
 * groups.  Factory methods for each of these are 
 * provided in this class.
 * 
 */
@XmlRegistry
public class ObjectFactory {

    private final static QName _AccountType_QNAME = new QName("urn://ath.com.co/xsd/common/", "AccountType");
    private final static QName _MiddleName_QNAME = new QName("urn://ath.com.co/xsd/common/", "MiddleName");
    private final static QName _SecondLastName_QNAME = new QName("urn://ath.com.co/xsd/common/", "SecondLastName");
    private final static QName _ExpDt_QNAME = new QName("urn://ath.com.co/xsd/common/", "ExpDt");
    private final static QName _ApprovalId_QNAME = new QName("urn://ath.com.co/xsd/common/", "ApprovalId");
    private final static QName _PmtId_QNAME = new QName("urn://ath.com.co/xsd/common/", "PmtId");
    private final static QName _CardEmbossNum_QNAME = new QName("urn://ath.com.co/xsd/common/", "CardEmbossNum");
    private final static QName _OrderInfo_QNAME = new QName("urn://ath.com.co/xsd/common/", "OrderInfo");
    private final static QName _CompensationDt_QNAME = new QName("urn://ath.com.co/xsd/common/", "CompensationDt");
    private final static QName _Severity_QNAME = new QName("urn://ath.com.co/xsd/common/", "Severity");
    private final static QName _Fee_QNAME = new QName("urn://ath.com.co/xsd/common/", "Fee");
    private final static QName _Reference_QNAME = new QName("urn://ath.com.co/xsd/common/", "Reference");
    private final static QName _FirstName_QNAME = new QName("urn://ath.com.co/xsd/common/", "FirstName");
    private final static QName _IssDt_QNAME = new QName("urn://ath.com.co/xsd/common/", "IssDt");
    private final static QName _ServerStatusDesc_QNAME = new QName("urn://ath.com.co/xsd/common/", "ServerStatusDesc");
    private final static QName _CurCode_QNAME = new QName("urn://ath.com.co/xsd/common/", "CurCode");
    private final static QName _CustIdType_QNAME = new QName("urn://ath.com.co/xsd/common/", "CustIdType");
    private final static QName _StateProvName_QNAME = new QName("urn://ath.com.co/xsd/common/", "StateProvName");
    private final static QName _NIT_QNAME = new QName("urn://ath.com.co/xsd/common/", "NIT");
    private final static QName _CurRate_QNAME = new QName("urn://ath.com.co/xsd/common/", "CurRate");
    private final static QName _CardLogicalData_QNAME = new QName("urn://ath.com.co/xsd/common/", "CardLogicalData");
    private final static QName _DeliveryCity_QNAME = new QName("urn://ath.com.co/xsd/common/", "DeliveryCity");
    private final static QName _UserId_QNAME = new QName("urn://ath.com.co/xsd/common/", "UserId");
    private final static QName _PersonalData_QNAME = new QName("urn://ath.com.co/xsd/common/", "PersonalData");
    private final static QName _CustName_QNAME = new QName("urn://ath.com.co/xsd/common/", "CustName");
    private final static QName _RqUID_QNAME = new QName("urn://ath.com.co/xsd/common/", "RqUID");
    private final static QName _EffDt_QNAME = new QName("urn://ath.com.co/xsd/common/", "EffDt");
    private final static QName _CellPhone_QNAME = new QName("urn://ath.com.co/xsd/common/", "CellPhone");
    private final static QName _DeliveryAddress_QNAME = new QName("urn://ath.com.co/xsd/common/", "DeliveryAddress");
    private final static QName _CountryName_QNAME = new QName("urn://ath.com.co/xsd/common/", "CountryName");
    private final static QName _PortalURL_QNAME = new QName("urn://ath.com.co/xsd/common/", "PortalURL");
    private final static QName _AgreementInfo_QNAME = new QName("urn://ath.com.co/xsd/common/", "AgreementInfo");
    private final static QName _ServerStatusCode_QNAME = new QName("urn://ath.com.co/xsd/common/", "ServerStatusCode");
    private final static QName _EmailAddr_QNAME = new QName("urn://ath.com.co/xsd/common/", "EmailAddr");
    private final static QName _RefId_QNAME = new QName("urn://ath.com.co/xsd/common/", "RefId");
    private final static QName _CustIdNum_QNAME = new QName("urn://ath.com.co/xsd/common/", "CustIdNum");
    private final static QName _TrnStatusCode_QNAME = new QName("urn://ath.com.co/xsd/common/", "TrnStatusCode");
    private final static QName _EndDt_QNAME = new QName("urn://ath.com.co/xsd/common/", "EndDt");
    private final static QName _CityId_QNAME = new QName("urn://ath.com.co/xsd/common/", "CityId");
    private final static QName _Phone_QNAME = new QName("urn://ath.com.co/xsd/common/", "Phone");
    private final static QName _AccountNum_QNAME = new QName("urn://ath.com.co/xsd/common/", "AccountNum");
    private final static QName _StatusDesc_QNAME = new QName("urn://ath.com.co/xsd/common/", "StatusDesc");
    private final static QName _IssuerName_QNAME = new QName("urn://ath.com.co/xsd/common/", "IssuerName");
    private final static QName _InstalamentsNum_QNAME = new QName("urn://ath.com.co/xsd/common/", "InstalamentsNum");
    private final static QName _NickName_QNAME = new QName("urn://ath.com.co/xsd/common/", "NickName");
    private final static QName _OrderId_QNAME = new QName("urn://ath.com.co/xsd/common/", "OrderId");
    private final static QName _BankInfo_QNAME = new QName("urn://ath.com.co/xsd/common/", "BankInfo");
    private final static QName _Amt_QNAME = new QName("urn://ath.com.co/xsd/common/", "Amt");
    private final static QName _BranchId_QNAME = new QName("urn://ath.com.co/xsd/common/", "BranchId");
    private final static QName _CityName_QNAME = new QName("urn://ath.com.co/xsd/common/", "CityName");
    private final static QName _ClientDt_QNAME = new QName("urn://ath.com.co/xsd/common/", "ClientDt");
    private final static QName _Channel_QNAME = new QName("urn://ath.com.co/xsd/common/", "Channel");
    private final static QName _CoreGetStateRBMPaymentRs_QNAME = new QName("urn://ath.com.co/payments/v1/", "CoreGetStateRBMPaymentRs");
    private final static QName _CountryId_QNAME = new QName("urn://ath.com.co/xsd/common/", "CountryId");
    private final static QName _IPAddr_QNAME = new QName("urn://ath.com.co/xsd/common/", "IPAddr");
    private final static QName _Status_QNAME = new QName("urn://ath.com.co/xsd/common/", "Status");
    private final static QName _CoreGetStateRBMPaymentRq_QNAME = new QName("urn://ath.com.co/payments/v1/", "CoreGetStateRBMPaymentRq");
    private final static QName _CustLoginId_QNAME = new QName("urn://ath.com.co/xsd/common/", "CustLoginId");
    private final static QName _AgreementId_QNAME = new QName("urn://ath.com.co/xsd/common/", "AgreementId");
    private final static QName _LegalName_QNAME = new QName("urn://ath.com.co/xsd/common/", "LegalName");
    private final static QName _TrnStatusDesc_QNAME = new QName("urn://ath.com.co/xsd/common/", "TrnStatusDesc");
    private final static QName _BankId_QNAME = new QName("urn://ath.com.co/xsd/common/", "BankId");
    private final static QName _UserType_QNAME = new QName("urn://ath.com.co/xsd/common/", "UserType");
    private final static QName _PaymentMethod_QNAME = new QName("urn://ath.com.co/xsd/common/", "PaymentMethod");
    private final static QName _LastName_QNAME = new QName("urn://ath.com.co/xsd/common/", "LastName");
    private final static QName _CurrencyAmt_QNAME = new QName("urn://ath.com.co/xsd/common/", "CurrencyAmt");
    private final static QName _CardSeqNum_QNAME = new QName("urn://ath.com.co/xsd/common/", "CardSeqNum");
    private final static QName _MaritalStatus_QNAME = new QName("urn://ath.com.co/xsd/common/", "MaritalStatus");
    private final static QName _Brand_QNAME = new QName("urn://ath.com.co/xsd/common/", "Brand");
    private final static QName _CardVrfyData_QNAME = new QName("urn://ath.com.co/xsd/common/", "CardVrfyData");
    private final static QName _TrnServerStatusCode_QNAME = new QName("urn://ath.com.co/xsd/common/", "TrnServerStatusCode");
    private final static QName _StatusCode_QNAME = new QName("urn://ath.com.co/xsd/common/", "StatusCode");
    private final static QName _Name_QNAME = new QName("urn://ath.com.co/xsd/common/", "Name");
    private final static QName _TransactionStatus_QNAME = new QName("urn://ath.com.co/xsd/common/", "TransactionStatus");
    private final static QName _BirthDt_QNAME = new QName("urn://ath.com.co/xsd/common/", "BirthDt");
    private final static QName _Gender_QNAME = new QName("urn://ath.com.co/xsd/common/", "Gender");
    private final static QName _Token_QNAME = new QName("urn://ath.com.co/xsd/common/", "Token");
    private final static QName _Address_QNAME = new QName("urn://ath.com.co/xsd/common/", "Address");
    private final static QName _TaxFee_QNAME = new QName("urn://ath.com.co/xsd/common/", "TaxFee");
    private final static QName _CoreInitTransactionRbmRs_QNAME = new QName("urn://ath.com.co/payments/v1/", "CoreInitTransactionRbmRs");
    private final static QName _CoreInitTransactionRbmRq_QNAME = new QName("urn://ath.com.co/payments/v1/", "CoreInitTransactionRbmRq");
    private final static QName _CustId_QNAME = new QName("urn://ath.com.co/xsd/common/", "CustId");
    private final static QName _TrnServerStatusDesc_QNAME = new QName("urn://ath.com.co/xsd/common/", "TrnServerStatusDesc");
    private final static QName _Desc_QNAME = new QName("urn://ath.com.co/xsd/common/", "Desc");
    private final static QName _RefType_QNAME = new QName("urn://ath.com.co/xsd/common/", "RefType");
    private final static QName _TrazabilityCode_QNAME = new QName("urn://ath.com.co/xsd/common/", "TrazabilityCode");

    /**
     * Create a new ObjectFactory that can be used to create new instances of schema derived classes for package: co.com.ath.pgw.ws.client.rbm.globalPay
     * 
     */
    public ObjectFactory() {
    }

    /**
     * Create an instance of {@link TransactionStatusType }
     * 
     */
    public TransactionStatusType createTransactionStatusType() {
        return new TransactionStatusType();
    }

    /**
     * Create an instance of {@link CustIdType }
     * 
     */
    public CustIdType createCustIdType() {
        return new CustIdType();
    }

    /**
     * Create an instance of {@link TaxFeeType }
     * 
     */
    public TaxFeeType createTaxFeeType() {
        return new TaxFeeType();
    }

    /**
     * Create an instance of {@link StatusType }
     * 
     */
    public StatusType createStatusType() {
        return new StatusType();
    }

    /**
     * Create an instance of {@link BankInfoType }
     * 
     */
    public BankInfoType createBankInfoType() {
        return new BankInfoType();
    }

    /**
     * Create an instance of {@link CurrencyAmtType }
     * 
     */
    public CurrencyAmtType createCurrencyAmtType() {
        return new CurrencyAmtType();
    }

    /**
     * Create an instance of {@link AgreementInfoType }
     * 
     */
    public AgreementInfoType createAgreementInfoType() {
        return new AgreementInfoType();
    }

    /**
     * Create an instance of {@link ReferenceType }
     * 
     */
    public ReferenceType createReferenceType() {
        return new ReferenceType();
    }

    /**
     * Create an instance of {@link FeeType }
     * 
     */
    public FeeType createFeeType() {
        return new FeeType();
    }

    /**
     * Create an instance of {@link OrderInfoType }
     * 
     */
    public OrderInfoType createOrderInfoType() {
        return new OrderInfoType();
    }

    /**
     * Create an instance of {@link PersonalDataType }
     * 
     */
    public PersonalDataType createPersonalDataType() {
        return new PersonalDataType();
    }

    /**
     * Create an instance of {@link CustNameType }
     * 
     */
    public CustNameType createCustNameType() {
        return new CustNameType();
    }

    /**
     * Create an instance of {@link CardLogicalDataType }
     * 
     */
    public CardLogicalDataType createCardLogicalDataType() {
        return new CardLogicalDataType();
    }

    /**
     * Create an instance of {@link UserIdType }
     * 
     */
    public UserIdType createUserIdType() {
        return new UserIdType();
    }

    /**
     * Create an instance of {@link AccountType }
     * 
     */
    public AccountType createAccountType() {
        return new AccountType();
    }

    /**
     * Create an instance of {@link SvcRqType }
     * 
     */
    public SvcRqType createSvcRqType() {
        return new SvcRqType();
    }

    /**
     * Create an instance of {@link CoreGetStateRBMPaymentRqType }
     * 
     */
    public CoreGetStateRBMPaymentRqType createCoreGetStateRBMPaymentRqType() {
        return new CoreGetStateRBMPaymentRqType();
    }

    /**
     * Create an instance of {@link CoreGetStateRBMPayment }
     * 
     */
    public CoreGetStateRBMPayment createCoreGetStateRBMPayment() {
        return new CoreGetStateRBMPayment();
    }

    /**
     * Create an instance of {@link CoreInitTransactionRbm }
     * 
     */
    public CoreInitTransactionRbm createCoreInitTransactionRbm() {
        return new CoreInitTransactionRbm();
    }

    /**
     * Create an instance of {@link CoreInitTransactionRbmRqType }
     * 
     */
    public CoreInitTransactionRbmRqType createCoreInitTransactionRbmRqType() {
        return new CoreInitTransactionRbmRqType();
    }

    /**
     * Create an instance of {@link CoreGetStateRBMPaymentResponse }
     * 
     */
    public CoreGetStateRBMPaymentResponse createCoreGetStateRBMPaymentResponse() {
        return new CoreGetStateRBMPaymentResponse();
    }

    /**
     * Create an instance of {@link CoreGetStateRBMPaymentRsType }
     * 
     */
    public CoreGetStateRBMPaymentRsType createCoreGetStateRBMPaymentRsType() {
        return new CoreGetStateRBMPaymentRsType();
    }

    /**
     * Create an instance of {@link CoreInitTransactionRbmRsType }
     * 
     */
    public CoreInitTransactionRbmRsType createCoreInitTransactionRbmRsType() {
        return new CoreInitTransactionRbmRsType();
    }

    /**
     * Create an instance of {@link CoreInitTransactionRbmResponse }
     * 
     */
    public CoreInitTransactionRbmResponse createCoreInitTransactionRbmResponse() {
        return new CoreInitTransactionRbmResponse();
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "urn://ath.com.co/xsd/common/", name = "AccountType")
    public JAXBElement<String> createAccountType(String value) {
        return new JAXBElement<String>(_AccountType_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "urn://ath.com.co/xsd/common/", name = "MiddleName")
    public JAXBElement<String> createMiddleName(String value) {
        return new JAXBElement<String>(_MiddleName_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "urn://ath.com.co/xsd/common/", name = "SecondLastName")
    public JAXBElement<String> createSecondLastName(String value) {
        return new JAXBElement<String>(_SecondLastName_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link XMLGregorianCalendar }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "urn://ath.com.co/xsd/common/", name = "ExpDt")
    public JAXBElement<XMLGregorianCalendar> createExpDt(XMLGregorianCalendar value) {
        return new JAXBElement<XMLGregorianCalendar>(_ExpDt_QNAME, XMLGregorianCalendar.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "urn://ath.com.co/xsd/common/", name = "ApprovalId")
    public JAXBElement<String> createApprovalId(String value) {
        return new JAXBElement<String>(_ApprovalId_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "urn://ath.com.co/xsd/common/", name = "PmtId")
    public JAXBElement<String> createPmtId(String value) {
        return new JAXBElement<String>(_PmtId_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "urn://ath.com.co/xsd/common/", name = "CardEmbossNum")
    public JAXBElement<String> createCardEmbossNum(String value) {
        return new JAXBElement<String>(_CardEmbossNum_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link OrderInfoType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "urn://ath.com.co/xsd/common/", name = "OrderInfo")
    public JAXBElement<OrderInfoType> createOrderInfo(OrderInfoType value) {
        return new JAXBElement<OrderInfoType>(_OrderInfo_QNAME, OrderInfoType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link XMLGregorianCalendar }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "urn://ath.com.co/xsd/common/", name = "CompensationDt")
    public JAXBElement<XMLGregorianCalendar> createCompensationDt(XMLGregorianCalendar value) {
        return new JAXBElement<XMLGregorianCalendar>(_CompensationDt_QNAME, XMLGregorianCalendar.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "urn://ath.com.co/xsd/common/", name = "Severity")
    public JAXBElement<String> createSeverity(String value) {
        return new JAXBElement<String>(_Severity_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link FeeType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "urn://ath.com.co/xsd/common/", name = "Fee")
    public JAXBElement<FeeType> createFee(FeeType value) {
        return new JAXBElement<FeeType>(_Fee_QNAME, FeeType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link ReferenceType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "urn://ath.com.co/xsd/common/", name = "Reference")
    public JAXBElement<ReferenceType> createReference(ReferenceType value) {
        return new JAXBElement<ReferenceType>(_Reference_QNAME, ReferenceType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "urn://ath.com.co/xsd/common/", name = "FirstName")
    public JAXBElement<String> createFirstName(String value) {
        return new JAXBElement<String>(_FirstName_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link XMLGregorianCalendar }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "urn://ath.com.co/xsd/common/", name = "IssDt")
    public JAXBElement<XMLGregorianCalendar> createIssDt(XMLGregorianCalendar value) {
        return new JAXBElement<XMLGregorianCalendar>(_IssDt_QNAME, XMLGregorianCalendar.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "urn://ath.com.co/xsd/common/", name = "ServerStatusDesc")
    public JAXBElement<String> createServerStatusDesc(String value) {
        return new JAXBElement<String>(_ServerStatusDesc_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "urn://ath.com.co/xsd/common/", name = "CurCode")
    public JAXBElement<String> createCurCode(String value) {
        return new JAXBElement<String>(_CurCode_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "urn://ath.com.co/xsd/common/", name = "CustIdType")
    public JAXBElement<String> createCustIdType(String value) {
        return new JAXBElement<String>(_CustIdType_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "urn://ath.com.co/xsd/common/", name = "StateProvName")
    public JAXBElement<String> createStateProvName(String value) {
        return new JAXBElement<String>(_StateProvName_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "urn://ath.com.co/xsd/common/", name = "NIT")
    public JAXBElement<String> createNIT(String value) {
        return new JAXBElement<String>(_NIT_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link BigDecimal }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "urn://ath.com.co/xsd/common/", name = "CurRate")
    public JAXBElement<BigDecimal> createCurRate(BigDecimal value) {
        return new JAXBElement<BigDecimal>(_CurRate_QNAME, BigDecimal.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link CardLogicalDataType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "urn://ath.com.co/xsd/common/", name = "CardLogicalData")
    public JAXBElement<CardLogicalDataType> createCardLogicalData(CardLogicalDataType value) {
        return new JAXBElement<CardLogicalDataType>(_CardLogicalData_QNAME, CardLogicalDataType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "urn://ath.com.co/xsd/common/", name = "DeliveryCity")
    public JAXBElement<String> createDeliveryCity(String value) {
        return new JAXBElement<String>(_DeliveryCity_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link UserIdType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "urn://ath.com.co/xsd/common/", name = "UserId")
    public JAXBElement<UserIdType> createUserId(UserIdType value) {
        return new JAXBElement<UserIdType>(_UserId_QNAME, UserIdType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link PersonalDataType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "urn://ath.com.co/xsd/common/", name = "PersonalData")
    public JAXBElement<PersonalDataType> createPersonalData(PersonalDataType value) {
        return new JAXBElement<PersonalDataType>(_PersonalData_QNAME, PersonalDataType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link CustNameType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "urn://ath.com.co/xsd/common/", name = "CustName")
    public JAXBElement<CustNameType> createCustName(CustNameType value) {
        return new JAXBElement<CustNameType>(_CustName_QNAME, CustNameType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Long }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "urn://ath.com.co/xsd/common/", name = "RqUID")
    public JAXBElement<Long> createRqUID(Long value) {
        return new JAXBElement<Long>(_RqUID_QNAME, Long.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link XMLGregorianCalendar }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "urn://ath.com.co/xsd/common/", name = "EffDt")
    public JAXBElement<XMLGregorianCalendar> createEffDt(XMLGregorianCalendar value) {
        return new JAXBElement<XMLGregorianCalendar>(_EffDt_QNAME, XMLGregorianCalendar.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "urn://ath.com.co/xsd/common/", name = "CellPhone")
    public JAXBElement<String> createCellPhone(String value) {
        return new JAXBElement<String>(_CellPhone_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "urn://ath.com.co/xsd/common/", name = "DeliveryAddress")
    public JAXBElement<String> createDeliveryAddress(String value) {
        return new JAXBElement<String>(_DeliveryAddress_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "urn://ath.com.co/xsd/common/", name = "CountryName")
    public JAXBElement<String> createCountryName(String value) {
        return new JAXBElement<String>(_CountryName_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "urn://ath.com.co/xsd/common/", name = "PortalURL")
    public JAXBElement<String> createPortalURL(String value) {
        return new JAXBElement<String>(_PortalURL_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link AgreementInfoType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "urn://ath.com.co/xsd/common/", name = "AgreementInfo")
    public JAXBElement<AgreementInfoType> createAgreementInfo(AgreementInfoType value) {
        return new JAXBElement<AgreementInfoType>(_AgreementInfo_QNAME, AgreementInfoType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "urn://ath.com.co/xsd/common/", name = "ServerStatusCode")
    public JAXBElement<String> createServerStatusCode(String value) {
        return new JAXBElement<String>(_ServerStatusCode_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "urn://ath.com.co/xsd/common/", name = "EmailAddr")
    public JAXBElement<String> createEmailAddr(String value) {
        return new JAXBElement<String>(_EmailAddr_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "urn://ath.com.co/xsd/common/", name = "RefId")
    public JAXBElement<String> createRefId(String value) {
        return new JAXBElement<String>(_RefId_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "urn://ath.com.co/xsd/common/", name = "CustIdNum")
    public JAXBElement<String> createCustIdNum(String value) {
        return new JAXBElement<String>(_CustIdNum_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Long }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "urn://ath.com.co/xsd/common/", name = "TrnStatusCode")
    public JAXBElement<Long> createTrnStatusCode(Long value) {
        return new JAXBElement<Long>(_TrnStatusCode_QNAME, Long.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link XMLGregorianCalendar }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "urn://ath.com.co/xsd/common/", name = "EndDt")
    public JAXBElement<XMLGregorianCalendar> createEndDt(XMLGregorianCalendar value) {
        return new JAXBElement<XMLGregorianCalendar>(_EndDt_QNAME, XMLGregorianCalendar.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "urn://ath.com.co/xsd/common/", name = "CityId")
    public JAXBElement<String> createCityId(String value) {
        return new JAXBElement<String>(_CityId_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "urn://ath.com.co/xsd/common/", name = "Phone")
    public JAXBElement<String> createPhone(String value) {
        return new JAXBElement<String>(_Phone_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "urn://ath.com.co/xsd/common/", name = "AccountNum")
    public JAXBElement<String> createAccountNum(String value) {
        return new JAXBElement<String>(_AccountNum_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "urn://ath.com.co/xsd/common/", name = "StatusDesc")
    public JAXBElement<String> createStatusDesc(String value) {
        return new JAXBElement<String>(_StatusDesc_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "urn://ath.com.co/xsd/common/", name = "IssuerName")
    public JAXBElement<String> createIssuerName(String value) {
        return new JAXBElement<String>(_IssuerName_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link BigInteger }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "urn://ath.com.co/xsd/common/", name = "InstalamentsNum")
    public JAXBElement<BigInteger> createInstalamentsNum(BigInteger value) {
        return new JAXBElement<BigInteger>(_InstalamentsNum_QNAME, BigInteger.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "urn://ath.com.co/xsd/common/", name = "NickName")
    public JAXBElement<String> createNickName(String value) {
        return new JAXBElement<String>(_NickName_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Long }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "urn://ath.com.co/xsd/common/", name = "OrderId")
    public JAXBElement<Long> createOrderId(Long value) {
        return new JAXBElement<Long>(_OrderId_QNAME, Long.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link BankInfoType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "urn://ath.com.co/xsd/common/", name = "BankInfo")
    public JAXBElement<BankInfoType> createBankInfo(BankInfoType value) {
        return new JAXBElement<BankInfoType>(_BankInfo_QNAME, BankInfoType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link BigDecimal }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "urn://ath.com.co/xsd/common/", name = "Amt")
    public JAXBElement<BigDecimal> createAmt(BigDecimal value) {
        return new JAXBElement<BigDecimal>(_Amt_QNAME, BigDecimal.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "urn://ath.com.co/xsd/common/", name = "BranchId")
    public JAXBElement<String> createBranchId(String value) {
        return new JAXBElement<String>(_BranchId_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "urn://ath.com.co/xsd/common/", name = "CityName")
    public JAXBElement<String> createCityName(String value) {
        return new JAXBElement<String>(_CityName_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link XMLGregorianCalendar }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "urn://ath.com.co/xsd/common/", name = "ClientDt")
    public JAXBElement<XMLGregorianCalendar> createClientDt(XMLGregorianCalendar value) {
        return new JAXBElement<XMLGregorianCalendar>(_ClientDt_QNAME, XMLGregorianCalendar.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "urn://ath.com.co/xsd/common/", name = "Channel")
    public JAXBElement<String> createChannel(String value) {
        return new JAXBElement<String>(_Channel_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link CoreGetStateRBMPaymentRsType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "urn://ath.com.co/payments/v1/", name = "CoreGetStateRBMPaymentRs")
    public JAXBElement<CoreGetStateRBMPaymentRsType> createCoreGetStateRBMPaymentRs(CoreGetStateRBMPaymentRsType value) {
        return new JAXBElement<CoreGetStateRBMPaymentRsType>(_CoreGetStateRBMPaymentRs_QNAME, CoreGetStateRBMPaymentRsType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "urn://ath.com.co/xsd/common/", name = "CountryId")
    public JAXBElement<String> createCountryId(String value) {
        return new JAXBElement<String>(_CountryId_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "urn://ath.com.co/xsd/common/", name = "IPAddr")
    public JAXBElement<String> createIPAddr(String value) {
        return new JAXBElement<String>(_IPAddr_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link StatusType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "urn://ath.com.co/xsd/common/", name = "Status")
    public JAXBElement<StatusType> createStatus(StatusType value) {
        return new JAXBElement<StatusType>(_Status_QNAME, StatusType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link CoreGetStateRBMPaymentRqType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "urn://ath.com.co/payments/v1/", name = "CoreGetStateRBMPaymentRq")
    public JAXBElement<CoreGetStateRBMPaymentRqType> createCoreGetStateRBMPaymentRq(CoreGetStateRBMPaymentRqType value) {
        return new JAXBElement<CoreGetStateRBMPaymentRqType>(_CoreGetStateRBMPaymentRq_QNAME, CoreGetStateRBMPaymentRqType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "urn://ath.com.co/xsd/common/", name = "CustLoginId")
    public JAXBElement<String> createCustLoginId(String value) {
        return new JAXBElement<String>(_CustLoginId_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "urn://ath.com.co/xsd/common/", name = "AgreementId")
    public JAXBElement<String> createAgreementId(String value) {
        return new JAXBElement<String>(_AgreementId_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "urn://ath.com.co/xsd/common/", name = "LegalName")
    public JAXBElement<String> createLegalName(String value) {
        return new JAXBElement<String>(_LegalName_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "urn://ath.com.co/xsd/common/", name = "TrnStatusDesc")
    public JAXBElement<String> createTrnStatusDesc(String value) {
        return new JAXBElement<String>(_TrnStatusDesc_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "urn://ath.com.co/xsd/common/", name = "BankId")
    public JAXBElement<String> createBankId(String value) {
        return new JAXBElement<String>(_BankId_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "urn://ath.com.co/xsd/common/", name = "UserType")
    public JAXBElement<String> createUserType(String value) {
        return new JAXBElement<String>(_UserType_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "urn://ath.com.co/xsd/common/", name = "PaymentMethod")
    public JAXBElement<String> createPaymentMethod(String value) {
        return new JAXBElement<String>(_PaymentMethod_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "urn://ath.com.co/xsd/common/", name = "LastName")
    public JAXBElement<String> createLastName(String value) {
        return new JAXBElement<String>(_LastName_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link CurrencyAmtType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "urn://ath.com.co/xsd/common/", name = "CurrencyAmt")
    public JAXBElement<CurrencyAmtType> createCurrencyAmt(CurrencyAmtType value) {
        return new JAXBElement<CurrencyAmtType>(_CurrencyAmt_QNAME, CurrencyAmtType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "urn://ath.com.co/xsd/common/", name = "CardSeqNum")
    public JAXBElement<String> createCardSeqNum(String value) {
        return new JAXBElement<String>(_CardSeqNum_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "urn://ath.com.co/xsd/common/", name = "MaritalStatus")
    public JAXBElement<String> createMaritalStatus(String value) {
        return new JAXBElement<String>(_MaritalStatus_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "urn://ath.com.co/xsd/common/", name = "Brand")
    public JAXBElement<String> createBrand(String value) {
        return new JAXBElement<String>(_Brand_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "urn://ath.com.co/xsd/common/", name = "CardVrfyData")
    public JAXBElement<String> createCardVrfyData(String value) {
        return new JAXBElement<String>(_CardVrfyData_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "urn://ath.com.co/xsd/common/", name = "TrnServerStatusCode")
    public JAXBElement<String> createTrnServerStatusCode(String value) {
        return new JAXBElement<String>(_TrnServerStatusCode_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Long }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "urn://ath.com.co/xsd/common/", name = "StatusCode")
    public JAXBElement<Long> createStatusCode(Long value) {
        return new JAXBElement<Long>(_StatusCode_QNAME, Long.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "urn://ath.com.co/xsd/common/", name = "Name")
    public JAXBElement<String> createName(String value) {
        return new JAXBElement<String>(_Name_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link TransactionStatusType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "urn://ath.com.co/xsd/common/", name = "TransactionStatus")
    public JAXBElement<TransactionStatusType> createTransactionStatus(TransactionStatusType value) {
        return new JAXBElement<TransactionStatusType>(_TransactionStatus_QNAME, TransactionStatusType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link XMLGregorianCalendar }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "urn://ath.com.co/xsd/common/", name = "BirthDt")
    public JAXBElement<XMLGregorianCalendar> createBirthDt(XMLGregorianCalendar value) {
        return new JAXBElement<XMLGregorianCalendar>(_BirthDt_QNAME, XMLGregorianCalendar.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "urn://ath.com.co/xsd/common/", name = "Gender")
    public JAXBElement<String> createGender(String value) {
        return new JAXBElement<String>(_Gender_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "urn://ath.com.co/xsd/common/", name = "Token")
    public JAXBElement<String> createToken(String value) {
        return new JAXBElement<String>(_Token_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "urn://ath.com.co/xsd/common/", name = "Address")
    public JAXBElement<String> createAddress(String value) {
        return new JAXBElement<String>(_Address_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link TaxFeeType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "urn://ath.com.co/xsd/common/", name = "TaxFee")
    public JAXBElement<TaxFeeType> createTaxFee(TaxFeeType value) {
        return new JAXBElement<TaxFeeType>(_TaxFee_QNAME, TaxFeeType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link CoreInitTransactionRbmRsType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "urn://ath.com.co/payments/v1/", name = "CoreInitTransactionRbmRs")
    public JAXBElement<CoreInitTransactionRbmRsType> createCoreInitTransactionRbmRs(CoreInitTransactionRbmRsType value) {
        return new JAXBElement<CoreInitTransactionRbmRsType>(_CoreInitTransactionRbmRs_QNAME, CoreInitTransactionRbmRsType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link CoreInitTransactionRbmRqType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "urn://ath.com.co/payments/v1/", name = "CoreInitTransactionRbmRq")
    public JAXBElement<CoreInitTransactionRbmRqType> createCoreInitTransactionRbmRq(CoreInitTransactionRbmRqType value) {
        return new JAXBElement<CoreInitTransactionRbmRqType>(_CoreInitTransactionRbmRq_QNAME, CoreInitTransactionRbmRqType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link CustIdType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "urn://ath.com.co/xsd/common/", name = "CustId")
    public JAXBElement<CustIdType> createCustId(CustIdType value) {
        return new JAXBElement<CustIdType>(_CustId_QNAME, CustIdType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "urn://ath.com.co/xsd/common/", name = "TrnServerStatusDesc")
    public JAXBElement<String> createTrnServerStatusDesc(String value) {
        return new JAXBElement<String>(_TrnServerStatusDesc_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "urn://ath.com.co/xsd/common/", name = "Desc")
    public JAXBElement<String> createDesc(String value) {
        return new JAXBElement<String>(_Desc_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "urn://ath.com.co/xsd/common/", name = "RefType")
    public JAXBElement<String> createRefType(String value) {
        return new JAXBElement<String>(_RefType_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "urn://ath.com.co/xsd/common/", name = "TrazabilityCode")
    public JAXBElement<String> createTrazabilityCode(String value) {
        return new JAXBElement<String>(_TrazabilityCode_QNAME, String.class, null, value);
    }

}
