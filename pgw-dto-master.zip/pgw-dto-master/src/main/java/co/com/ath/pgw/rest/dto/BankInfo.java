package co.com.ath.pgw.rest.dto;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonProperty;

public class BankInfo implements Serializable {

	@JsonProperty("BankId")
	private String bankId;
	@JsonProperty("Name")
	private String name;
	@JsonProperty("BranchId")
	private String branchId;
	private final static long serialVersionUID = -5222359226820372385L;

	public String getBankId() {
		return bankId;
	}

	public void setBankId(String bankId) {
		this.bankId = bankId;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getBranchId() {
		return branchId;
	}

	public void setBranchId(String branchId) {
		this.branchId = branchId;
	}

}