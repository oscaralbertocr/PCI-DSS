
package co.com.ath.pgw.client.bank.info.xsd.ifx;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlType;

import co.com.ath.pgw.core.logging.util.XMLUtil;


/**
 * <p>Clase Java para LoanAcctId_Type complex type.
 * 
 * <p>El siguiente fragmento de esquema especifica el contenido que se espera que haya en esta clase.
 * 
 * <pre>
 * &lt;complexType name="LoanAcctId_Type">
 *   &lt;complexContent>
 *     &lt;extension base="{urn://grupoaval.com/xsd/ifx/}GenericAcctId_Type">
 *       &lt;sequence>
 *       &lt;/sequence>
 *     &lt;/extension>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "LoanAcctId_Type")
public class LoanAcctIdType
    extends GenericAcctIdType
{

	public String toString() {
    	XMLUtil<LoanAcctIdType> requestParser = 
    							new XMLUtil<LoanAcctIdType>();
		return requestParser.convertObjectToXml(this);
    }

}
