
package co.com.ath.pgw.client.ach.dto;

import java.math.BigDecimal;
import java.math.BigInteger;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlSchemaType;
import javax.xml.bind.annotation.XmlType;
import javax.xml.datatype.XMLGregorianCalendar;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import co.com.ath.pgw.core.logging.util.XMLUtil;


/**
 * <p>Clase Java para TransactionPaymentInp complex type.
 * 
 * <p>El siguiente fragmento de esquema especifica el contenido que se espera que haya en esta clase.
 * 
 * <pre>
 * &lt;complexType name="TransactionPaymentInp">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="finantialInstitutionCode" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="entityCode" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="serviceCode" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="transactionValue" type="{http://www.w3.org/2001/XMLSchema}decimal" minOccurs="0"/>
 *         &lt;element name="vatValue" type="{http://www.w3.org/2001/XMLSchema}decimal" minOccurs="0"/>
 *         &lt;element name="ticketId" type="{http://www.w3.org/2001/XMLSchema}nonNegativeInteger" minOccurs="0"/>
 *         &lt;element name="entityUrl" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="userType" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="soliciteDate" type="{http://www.w3.org/2001/XMLSchema}dateTime" minOccurs="0"/>
 *         &lt;element name="paymentDescription" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="referenceNumber1" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="referenceNumber2" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="referenceNumber3" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="referenceNumber4" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "TransactionPaymentInp", propOrder = {
    "finantialInstitutionCode",
    "entityCode",
    "serviceCode",
    "transactionValue",
    "vatValue",
    "ticketId",
    "entityUrl",
    "userType",
    "soliciteDate",
    "paymentDescription",
    "referenceNumber1",
    "referenceNumber2",
    "referenceNumber3",
    "referenceNumber4"
})
@XmlRootElement
public class TransactionPaymentInp implements Cloneable{
	
	static Logger LOGGER = LoggerFactory.getLogger(TransactionPaymentInp.class);

    protected String finantialInstitutionCode;
    protected String entityCode;
    protected String serviceCode;
    protected BigDecimal transactionValue;
    protected BigDecimal vatValue;
    @XmlSchemaType(name = "nonNegativeInteger")
    protected BigInteger ticketId;
    protected String entityUrl;
    protected String userType;
    @XmlSchemaType(name = "dateTime")
    protected XMLGregorianCalendar soliciteDate;
    protected String paymentDescription;
    protected String referenceNumber1;
    protected String referenceNumber2;
    protected String referenceNumber3;
    protected String referenceNumber4;

	/**
     * Obtiene el valor de la propiedad finantialInstitutionCode.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getFinantialInstitutionCode() {
        return finantialInstitutionCode;
    }

    /**
     * Define el valor de la propiedad finantialInstitutionCode.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setFinantialInstitutionCode(String value) {
        this.finantialInstitutionCode = value;
    }

    /**
     * Obtiene el valor de la propiedad entityCode.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getEntityCode() {
        return entityCode;
    }

    /**
     * Define el valor de la propiedad entityCode.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setEntityCode(String value) {
        this.entityCode = value;
    }

    /**
     * Obtiene el valor de la propiedad serviceCode.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getServiceCode() {
        return serviceCode;
    }

    /**
     * Define el valor de la propiedad serviceCode.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setServiceCode(String value) {
        this.serviceCode = value;
    }

    /**
     * Obtiene el valor de la propiedad transactionValue.
     * 
     * @return
     *     possible object is
     *     {@link BigDecimal }
     *     
     */
    public BigDecimal getTransactionValue() {
        return transactionValue;
    }

    /**
     * Define el valor de la propiedad transactionValue.
     * 
     * @param value
     *     allowed object is
     *     {@link BigDecimal }
     *     
     */
    public void setTransactionValue(BigDecimal value) {
        this.transactionValue = value;
    }

    /**
     * Obtiene el valor de la propiedad vatValue.
     * 
     * @return
     *     possible object is
     *     {@link BigDecimal }
     *     
     */
    public BigDecimal getVatValue() {
        return vatValue;
    }

    /**
     * Define el valor de la propiedad vatValue.
     * 
     * @param value
     *     allowed object is
     *     {@link BigDecimal }
     *     
     */
    public void setVatValue(BigDecimal value) {
        this.vatValue = value;
    }

    /**
     * Obtiene el valor de la propiedad ticketId.
     * 
     * @return
     *     possible object is
     *     {@link BigInteger }
     *     
     */
    public BigInteger getTicketId() {
        return ticketId;
    }

    /**
     * Define el valor de la propiedad ticketId.
     * 
     * @param value
     *     allowed object is
     *     {@link BigInteger }
     *     
     */
    public void setTicketId(BigInteger value) {
        this.ticketId = value;
    }

    /**
     * Obtiene el valor de la propiedad entityUrl.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getEntityUrl() {
        return entityUrl;
    }

    /**
     * Define el valor de la propiedad entityUrl.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setEntityUrl(String value) {
        this.entityUrl = value;
    }

    /**
     * Obtiene el valor de la propiedad userType.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getUserType() {
        return userType;
    }

    /**
     * Define el valor de la propiedad userType.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setUserType(String value) {
        this.userType = value;
    }

    /**
     * Obtiene el valor de la propiedad soliciteDate.
     * 
     * @return
     *     possible object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public XMLGregorianCalendar getSoliciteDate() {
        return soliciteDate;
    }

    /**
     * Define el valor de la propiedad soliciteDate.
     * 
     * @param value
     *     allowed object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public void setSoliciteDate(XMLGregorianCalendar value) {
        this.soliciteDate = value;
    }

    /**
     * Obtiene el valor de la propiedad paymentDescription.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPaymentDescription() {
        return paymentDescription;
    }

    /**
     * Define el valor de la propiedad paymentDescription.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPaymentDescription(String value) {
        this.paymentDescription = value;
    }

    /**
     * Obtiene el valor de la propiedad referenceNumber1.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getReferenceNumber1() {
        return referenceNumber1;
    }

    /**
     * Define el valor de la propiedad referenceNumber1.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setReferenceNumber1(String value) {
        this.referenceNumber1 = value;
    }

    /**
     * Obtiene el valor de la propiedad referenceNumber2.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getReferenceNumber2() {
        return referenceNumber2;
    }

    /**
     * Define el valor de la propiedad referenceNumber2.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setReferenceNumber2(String value) {
        this.referenceNumber2 = value;
    }

    /**
     * Obtiene el valor de la propiedad referenceNumber3.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getReferenceNumber3() {
        return referenceNumber3;
    }

    /**
     * Define el valor de la propiedad referenceNumber3.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setReferenceNumber3(String value) {
        this.referenceNumber3 = value;
    }
    
    public String getReferenceNumber4() {
		return referenceNumber4;
	}

	public void setReferenceNumber4(String referenceNumber4) {
		this.referenceNumber4 = referenceNumber4;
	}
    
	@Override
	public String toString() {
		XMLUtil<TransactionPaymentInp> requestParser = new XMLUtil<TransactionPaymentInp>();
		return requestParser.convertObjectToXml(this);
	}
}