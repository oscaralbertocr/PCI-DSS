package co.com.ath.pgw.rest.response.dto;

import co.com.ath.pgw.core.logging.util.XMLUtil;

public class StatusFinallyQRResponse {

	private String status;
	private Long idStatus;
	
	public StatusFinallyQRResponse(Long idStatus, String status) {
		this.status = status;
		this.idStatus = idStatus;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public Long getIdStatus() {
		return idStatus;
	}

	public void setIdStatus(Long idStatus) {
		this.idStatus = idStatus;
	}

	@Override
	public String toString() {
		XMLUtil<StatusFinallyQRResponse> util = new XMLUtil<>();
		return util.convertObjectToJson(this);
	}
	
}
