package co.com.ath.pgw.in.dto;

import co.com.ath.pgw.core.logging.util.XMLUtil;
import co.com.ath.pgw.in.model.SvcRsType;

public class AgreementRsType extends SvcRsType {
	
	
	@Override
	public String toString() {
		XMLUtil<AgreementRsType> requestParser = 
				new XMLUtil<AgreementRsType>();
		return requestParser.convertObjectToXml(this);
	}
	
	
}
