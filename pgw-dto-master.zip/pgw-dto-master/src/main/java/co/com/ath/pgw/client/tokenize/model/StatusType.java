
package co.com.ath.pgw.client.tokenize.model;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlSchemaType;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Clase Java para Status_Type complex type.
 * 
 * <p>El siguiente fragmento de esquema especifica el contenido que se espera que haya en esta clase.
 * 
 * <pre>
 * &lt;complexType name="Status_Type"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element ref="{urn://ath.com.co/xsd/common/}StatusCode"/&gt;
 *         &lt;element ref="{urn://ath.com.co/xsd/common/}ServerStatusCode" minOccurs="0"/&gt;
 *         &lt;element ref="{urn://ath.com.co/xsd/common/}Severity"/&gt;
 *         &lt;element ref="{urn://ath.com.co/xsd/common/}StatusDesc" minOccurs="0"/&gt;
 *         &lt;element ref="{urn://ath.com.co/xsd/common/}ServerStatusDesc" minOccurs="0"/&gt;
 *         &lt;element ref="{urn://ath.com.co/xsd/common/}AdditionalStatus" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "Status_Type", propOrder = {
    "statusCode",
    "serverStatusCode",
    "severity",
    "statusDesc",
    "serverStatusDesc",
    "additionalStatus"
})
public class StatusType {

    @XmlElement(name = "StatusCode", namespace = "urn://ath.com.co/xsd/common/")
    protected long statusCode;
    @XmlElement(name = "ServerStatusCode", namespace = "urn://ath.com.co/xsd/common/")
    protected String serverStatusCode;
    @XmlElement(name = "Severity", required = true, namespace = "urn://ath.com.co/xsd/common/")
    @XmlSchemaType(name = "string")
    protected SeverityType severity;
    @XmlElement(name = "StatusDesc", namespace = "urn://ath.com.co/xsd/common/")
    protected String statusDesc;
    @XmlElement(name = "ServerStatusDesc", namespace = "urn://ath.com.co/xsd/common/")
    protected String serverStatusDesc;
    @XmlElement(name = "AdditionalStatus", namespace = "urn://ath.com.co/xsd/common/")
    protected AdditionalStatusType additionalStatus;

    /**
     * Obtiene el valor de la propiedad statusCode.
     * 
     */
    public long getStatusCode() {
        return statusCode;
    }

    /**
     * Define el valor de la propiedad statusCode.
     * 
     */
    public void setStatusCode(long value) {
        this.statusCode = value;
    }

    /**
     * Obtiene el valor de la propiedad serverStatusCode.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getServerStatusCode() {
        return serverStatusCode;
    }

    /**
     * Define el valor de la propiedad serverStatusCode.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setServerStatusCode(String value) {
        this.serverStatusCode = value;
    }

    /**
     * Obtiene el valor de la propiedad severity.
     * 
     * @return
     *     possible object is
     *     {@link SeverityType }
     *     
     */
    public SeverityType getSeverity() {
        return severity;
    }

    /**
     * Define el valor de la propiedad severity.
     * 
     * @param value
     *     allowed object is
     *     {@link SeverityType }
     *     
     */
    public void setSeverity(SeverityType value) {
        this.severity = value;
    }

    /**
     * Obtiene el valor de la propiedad statusDesc.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getStatusDesc() {
        return statusDesc;
    }

    /**
     * Define el valor de la propiedad statusDesc.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setStatusDesc(String value) {
        this.statusDesc = value;
    }

    /**
     * Obtiene el valor de la propiedad serverStatusDesc.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getServerStatusDesc() {
        return serverStatusDesc;
    }

    /**
     * Define el valor de la propiedad serverStatusDesc.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setServerStatusDesc(String value) {
        this.serverStatusDesc = value;
    }

    /**
     * Obtiene el valor de la propiedad additionalStatus.
     * 
     * @return
     *     possible object is
     *     {@link AdditionalStatusType }
     *     
     */
    public AdditionalStatusType getAdditionalStatus() {
        return additionalStatus;
    }

    /**
     * Define el valor de la propiedad additionalStatus.
     * 
     * @param value
     *     allowed object is
     *     {@link AdditionalStatusType }
     *     
     */
    public void setAdditionalStatus(AdditionalStatusType value) {
        this.additionalStatus = value;
    }

}
