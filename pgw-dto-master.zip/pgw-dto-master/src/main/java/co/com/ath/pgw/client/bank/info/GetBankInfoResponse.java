
package co.com.ath.pgw.client.bank.info;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;

import co.com.ath.pgw.client.bank.info.xsd.ifx.BankInfoInqRsType;
import co.com.ath.pgw.core.logging.util.XMLUtil;


/**
 * <p>Clase Java para anonymous complex type.
 * 
 * <p>El siguiente fragmento de esquema especifica el contenido que se espera que haya en esta clase.
 * 
 * <pre>
 * &lt;complexType>
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element ref="{urn://grupoaval.com/inquiry/v1/}BankInfoInqRs"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "", propOrder = {
    "bankInfoInqRs"
})
@XmlRootElement(name = "getBankInfoResponse",namespace = "urn://grupoaval.com/inquiry/v1/")
public class GetBankInfoResponse {

    @XmlElement(name = "BankInfoInqRs", namespace = "urn://grupoaval.com/inquiry/v1/", required = true)
    protected BankInfoInqRsType bankInfoInqRs;

    /**
     * Obtiene el valor de la propiedad bankInfoInqRs.
     * 
     * @return
     *     possible object is
     *     {@link BankInfoInqRsType }
     *     
     */
    public BankInfoInqRsType getBankInfoInqRs() {
        return bankInfoInqRs;
    }

    /**
     * Define el valor de la propiedad bankInfoInqRs.
     * 
     * @param value
     *     allowed object is
     *     {@link BankInfoInqRsType }
     *     
     */
    public void setBankInfoInqRs(BankInfoInqRsType value) {
        this.bankInfoInqRs = value;
    }
    
    public String toString() {
    	XMLUtil<GetBankInfoResponse> requestParser = 
    							new XMLUtil<GetBankInfoResponse>();
		return requestParser.convertObjectToXml(this);
    }

}
