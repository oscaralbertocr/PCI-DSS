
package co.com.ath.pgw.rest.dto;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonProperty;

public class TotalCurAmtAddTx implements Serializable {

	@JsonProperty("Amt")
	private String amt;
	private static final long serialVersionUID = -3286594957567697848L;

	public String getAmt() {
		return amt;
	}

	public void setAmt(String amt) {
		this.amt = amt;
	}

}
