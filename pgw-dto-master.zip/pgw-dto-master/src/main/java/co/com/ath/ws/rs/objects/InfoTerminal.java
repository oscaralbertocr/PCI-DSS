package co.com.ath.ws.rs.objects;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonProperty;

public class InfoTerminal implements Serializable {

	private static final long serialVersionUID = 6935846550989893546L;

	@JsonProperty("idTerminal")
    private String idTerminal; 
    
	@JsonProperty("idComercio")
	private String idComercio;

	public String getIdTerminal() {
		return idTerminal;
	}

	public void setIdTerminal(String idTerminal) {
		this.idTerminal = idTerminal;
	}

	public String getIdComercio() {
		return idComercio;
	}

	public void setIdComercio(String idComercio) {
		this.idComercio = idComercio;
	}
	
	
}
