package co.com.ath.pgw.client.bank.info;

import javax.xml.datatype.XMLGregorianCalendar;

import co.com.ath.pgw.in.model.TxCostAmtType;

public class MsgRsHdrType {

	protected TxCostAmtType txCostAmt;

	protected XMLGregorianCalendar effDt;

	protected Boolean remainRec;

	/**
	 * Obtiene el valor de la propiedad txCostAmt.
	 * 
	 * @return possible object is {@link TxCostAmtType }
	 * 
	 */
	public TxCostAmtType getTxCostAmt() {
		return txCostAmt;
	}

	/**
	 * Define el valor de la propiedad txCostAmt.
	 * 
	 * @param value allowed object is {@link TxCostAmtType }
	 * 
	 */
	public void setTxCostAmt(TxCostAmtType value) {
		this.txCostAmt = value;
	}

	/**
	 * Obtiene el valor de la propiedad effDt.
	 * 
	 * @return possible object is {@link XMLGregorianCalendar }
	 * 
	 */
	public XMLGregorianCalendar getEffDt() {
		return effDt;
	}

	/**
	 * Define el valor de la propiedad effDt.
	 * 
	 * @param value allowed object is {@link XMLGregorianCalendar }
	 * 
	 */
	public void setEffDt(XMLGregorianCalendar value) {
		this.effDt = value;
	}

	/**
	 * Obtiene el valor de la propiedad remainRec.
	 * 
	 * @return possible object is {@link Boolean }
	 * 
	 */
	public Boolean isRemainRec() {
		return remainRec;
	}

	/**
	 * Define el valor de la propiedad remainRec.
	 * 
	 * @param value allowed object is {@link Boolean }
	 * 
	 */
	public void setRemainRec(Boolean value) {
		this.remainRec = value;
	}

}
