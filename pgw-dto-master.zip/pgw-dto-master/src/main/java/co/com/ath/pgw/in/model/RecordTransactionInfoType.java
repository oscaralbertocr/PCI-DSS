package co.com.ath.pgw.in.model;

import java.math.BigDecimal;

import javax.xml.datatype.XMLGregorianCalendar;

public class RecordTransactionInfoType {

    
    protected XMLGregorianCalendar effDt;
    
    protected String refId;
    
    protected BigDecimal amt;
   
    protected String trazabilityCode;
   
    protected String state;
  
    protected String pmtId;
   
    protected String pmtWayId;
   
    protected String aprovalId;

    /**
     * Obtiene el valor de la propiedad effDt.
     * 
     * @return
     *     possible object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public XMLGregorianCalendar getEffDt() {
        return effDt;
    }

    /**
     * Define el valor de la propiedad effDt.
     * 
     * @param value
     *     allowed object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public void setEffDt(XMLGregorianCalendar value) {
        this.effDt = value;
    }

    /**
     * Obtiene el valor de la propiedad refId.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getRefId() {
        return refId;
    }

    /**
     * Define el valor de la propiedad refId.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setRefId(String value) {
        this.refId = value;
    }

    /**
     * Obtiene el valor de la propiedad amt.
     * 
     * @return
     *     possible object is
     *     {@link BigDecimal }
     *     
     */
    public BigDecimal getAmt() {
        return amt;
    }

    /**
     * Define el valor de la propiedad amt.
     * 
     * @param value
     *     allowed object is
     *     {@link BigDecimal }
     *     
     */
    public void setAmt(BigDecimal value) {
        this.amt = value;
    }

    /**
     * Obtiene el valor de la propiedad trazabilityCode.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getTrazabilityCode() {
        return trazabilityCode;
    }

    /**
     * Define el valor de la propiedad trazabilityCode.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setTrazabilityCode(String value) {
        this.trazabilityCode = value;
    }

    /**
     * Obtiene el valor de la propiedad state.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getState() {
        return state;
    }

    /**
     * Define el valor de la propiedad state.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setState(String value) {
        this.state = value;
    }

    /**
     * Obtiene el valor de la propiedad pmtId.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPmtId() {
        return pmtId;
    }

    /**
     * Define el valor de la propiedad pmtId.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPmtId(String value) {
        this.pmtId = value;
    }

    /**
     * Obtiene el valor de la propiedad pmtWayId.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPmtWayId() {
        return pmtWayId;
    }

    /**
     * Define el valor de la propiedad pmtWayId.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPmtWayId(String value) {
        this.pmtWayId = value;
    }

    /**
     * Obtiene el valor de la propiedad aprovalId.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getAprovalId() {
        return aprovalId;
    }

    /**
     * Define el valor de la propiedad aprovalId.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setAprovalId(String value) {
        this.aprovalId = value;
    }

}
