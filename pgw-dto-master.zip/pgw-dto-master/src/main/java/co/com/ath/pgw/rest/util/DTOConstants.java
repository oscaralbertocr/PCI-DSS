package co.com.ath.pgw.rest.util;

public interface DTOConstants {

	public static final String TIMEZONE = "America/Bogota";

}