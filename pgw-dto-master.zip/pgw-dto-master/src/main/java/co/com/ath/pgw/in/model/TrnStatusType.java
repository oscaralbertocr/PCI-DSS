package co.com.ath.pgw.in.model;

public class TrnStatusType {

	protected String trnStatusCode;

	/**
	 * Obtiene el valor de la propiedad trnStatusCode.
	 * 
	 * @return possible object is {@link String }
	 * 
	 */
	public String getTrnStatusCode() {
		return trnStatusCode;
	}

	/**
	 * Define el valor de la propiedad trnStatusCode.
	 * 
	 * @param value allowed object is {@link String }
	 * 
	 */
	public void setTrnStatusCode(String value) {
		this.trnStatusCode = value;
	}

}
