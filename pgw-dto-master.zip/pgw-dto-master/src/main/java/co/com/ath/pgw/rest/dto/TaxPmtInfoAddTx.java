
package co.com.ath.pgw.rest.dto;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonProperty;

public class TaxPmtInfoAddTx implements Serializable
{

	@JsonProperty("CurAmt")
    private CurAmtAddTx curAmt;
	
    private final static long serialVersionUID = -8718986820341574650L;

    public CurAmtAddTx getCurAmt() {
        return curAmt;
    }

    public void setCurAmt(CurAmtAddTx curAmt) {
        this.curAmt = curAmt;
    }

}
