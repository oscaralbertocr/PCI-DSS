package co.com.ath.pgw;

public class Greeting2 {

    private final String id;
    private final String content;
    private final String cardEmbossNumss;
    private final int[] intArray;

    public Greeting2() {
        this.id = "2";
        this.content = "asdf";
        this.cardEmbossNumss = "asdf";
        intArray = new int[]{ 1,2,3,4,5,6,7,8,9,10 };
    }

    public String getId() {
        return id;
    }

    public String getContent() {
        return content;
    }
    
    public String getCardEmbossNumss() {
        return cardEmbossNumss;
    }
    
    public int[] getIntArray() {
		return intArray;
	}

	@Override
	public String toString() {
    	return "";
	}
    
}
