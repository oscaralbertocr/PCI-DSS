package co.com.ath.ws.rs.objects;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonProperty;

public class AdditionalStatusNotification implements Serializable {

	private static final long serialVersionUID = 1L;
	
	@JsonProperty("statusCode")
	private String statusCode;
	
	@JsonProperty("serverStatusCode")
	private String serverStatusCode;
	
	@JsonProperty("severity")
	private String severity;
	
	@JsonProperty("statusDesc")
	private String statusDesc;

	public String getStatusCode() {
		return statusCode;
	}

	public void setStatusCode(String statusCode) {
		this.statusCode = statusCode;
	}

	public String getServerStatusCode() {
		return serverStatusCode;
	}

	public void setServerStatusCode(String serverStatusCode) {
		this.serverStatusCode = serverStatusCode;
	}

	public String getSeverity() {
		return severity;
	}

	public void setSeverity(String severity) {
		this.severity = severity;
	}

	public String getStatusDesc() {
		return statusDesc;
	}

	public void setStatusDesc(String statusDesc) {
		this.statusDesc = statusDesc;
	}
	
	
}
