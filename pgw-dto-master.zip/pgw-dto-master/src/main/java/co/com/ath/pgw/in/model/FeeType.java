package co.com.ath.pgw.in.model;

import java.math.BigDecimal;

import co.com.ath.pgw.client.bank.info.CurrencyAmountType;

public class FeeType extends CurrencyAmtType {

	protected String feeType;

	protected CurrencyAmountType curAmt;

	protected BigDecimal rate;

	protected CurrencyAmountType minCurAmt;

	protected CurrencyAmountType maxCurAmt;

	public String getFeeType() {
		return feeType;
	}

	public void setFeeType(String feeType) {
		this.feeType = feeType;
	}

	public CurrencyAmountType getCurAmt() {
		return curAmt;
	}

	public void setCurAmt(CurrencyAmountType curAmt) {
		this.curAmt = curAmt;
	}

	public BigDecimal getRate() {
		return rate;
	}

	public void setRate(BigDecimal rate) {
		this.rate = rate;
	}

	public CurrencyAmountType getMinCurAmt() {
		return minCurAmt;
	}

	public void setMinCurAmt(CurrencyAmountType minCurAmt) {
		this.minCurAmt = minCurAmt;
	}

	public CurrencyAmountType getMaxCurAmt() {
		return maxCurAmt;
	}

	public void setMaxCurAmt(CurrencyAmountType maxCurAmt) {
		this.maxCurAmt = maxCurAmt;
	}

}