package co.com.ath.pgw.rest.response.dto;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonProperty;

import co.com.ath.pgw.core.logging.util.XMLUtil;
import co.com.ath.pgw.rest.dto.PmtStatus;

public class TransactionModResponse implements Serializable {

	@JsonProperty("PmtStatus")
	private PmtStatus pmtStatus;
	private static final long serialVersionUID = 1005150119438749190L;

	public PmtStatus getPmtStatus() {
		return pmtStatus;
	}

	public void setPmtStatus(PmtStatus pmtStatus) {
		this.pmtStatus = pmtStatus;
	}

	@Override
	public String toString() {
		XMLUtil<TransactionModResponse> util = new XMLUtil<TransactionModResponse>();
		return util.convertObjectToJson(this);
	}

}