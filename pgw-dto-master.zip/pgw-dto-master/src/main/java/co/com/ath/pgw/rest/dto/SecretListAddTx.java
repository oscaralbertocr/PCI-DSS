
package co.com.ath.pgw.rest.dto;

import java.io.Serializable;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.Pattern;

import com.fasterxml.jackson.annotation.JsonProperty;

import co.com.ath.pgw.rest.util.ConstantFormat;

public class SecretListAddTx implements Serializable
{

	@JsonProperty("SecretId")
	@NotBlank
	@Pattern( regexp = ConstantFormat.FORMAT_NUMEROS_LETRAS, message = ConstantFormat.MESSAGE_CARACTER_NO_VALIDOS)
    private String secretId;
	
	@JsonProperty("Secret")
	@NotBlank
	@Pattern( regexp = ConstantFormat.FORMAT_NUMEROS_LETRAS, message = ConstantFormat.MESSAGE_CARACTER_NO_VALIDOS)
    private String secret;
	
    private final static long serialVersionUID = 1029438724602038862L;

    public String getSecretId() {
        return secretId;
    }

    public void setSecretId(String secretId) {
        this.secretId = secretId;
    }

    public String getSecret() {
        return secret;
    }

    public void setSecret(String secret) {
        this.secret = secret;
    }

}
