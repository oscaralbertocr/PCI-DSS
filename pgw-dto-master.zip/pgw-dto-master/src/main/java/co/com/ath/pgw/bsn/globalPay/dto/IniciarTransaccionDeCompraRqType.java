
package co.com.ath.pgw.bsn.globalPay.dto;

import java.util.ArrayList;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import co.com.ath.pgw.core.logging.util.XMLUtil;
import co.com.ath.pgw.in.model.CabeceraSolicitudType;
import co.com.ath.pgw.in.model.CredencialesType;
import co.com.ath.pgw.in.model.InfoComercioType;
import co.com.ath.pgw.in.model.InfoCompraType;
import co.com.ath.pgw.in.model.InfoPersonaType;
import co.com.ath.pgw.in.model.ReferenceType;
import co.com.ath.pgw.in.model.SvcRqType;

/**
*
* @author camilo.bustamante@sophossolutions.com
* @version 1.0 03 Enero 2019
* @RQ31686 RBM_Integracion_Boton_TC_GlobalPay
* 
*/

/**
 * <p>Clase Java para IniciarTransaccionDeCompraRq_Type complex type.
 * 
 * <p>El siguiente fragmento de esquema especifica el contenido que se espera que haya en esta clase.
 * 
 * <pre>
 * &lt;complexType name="IniciarTransaccionDeCompraRq_Type">
 *   &lt;complexContent>
 *     &lt;extension base="{urn://ath.com.co/xsd/common/}SvcRq_Type">
 *       &lt;sequence>
 *         &lt;element ref="{urn://ath.com.co/xsd/common/}Credenciales"/>
 *         &lt;element ref="{urn://ath.com.co/xsd/common/}CabeceraSolicitud" minOccurs="0"/>
 *         &lt;element ref="{urn://ath.com.co/xsd/common/}InfoPersona"/>
 *         &lt;element ref="{urn://ath.com.co/xsd/common/}InfoPersonaBeneficiario"/>
 *         &lt;element ref="{urn://ath.com.co/xsd/common/}InfoCompra"/>
 *         &lt;element ref="{urn://ath.com.co/xsd/common/}InfoComercio"/>
 *         &lt;element ref="{urn://ath.com.co/xsd/common/}Pmtid"/>
 *         &lt;element ref="{urn://ath.com.co/xsd/common/}Reference" maxOccurs="50" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/extension>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 */
public class IniciarTransaccionDeCompraRqType
    extends SvcRqType {

	public static Logger LOGGER = LoggerFactory.getLogger(IniciarTransaccionDeCompraRqType.class);
			 
    protected CredencialesType credenciales;
    
    protected CabeceraSolicitudType cabeceraSolicitud;
        
    protected InfoPersonaType infoPersona;
    
    protected InfoPersonaType infoPersonaBeneficiario;
        
    protected InfoCompraType infoCompra;
        
    protected InfoComercioType infoComercio;
    
    protected String pmtid;
    
    protected List<ReferenceType> reference;
    
	public CredencialesType getCredenciales() {
		return credenciales;
	}

	public void setCredenciales(CredencialesType credenciales) {
		this.credenciales = credenciales;
	}

	public CabeceraSolicitudType getCabeceraSolicitud() {
		return cabeceraSolicitud;
	}

	public void setCabeceraSolicitud(CabeceraSolicitudType cabeceraSolicitud) {
		this.cabeceraSolicitud = cabeceraSolicitud;
	}

	public InfoPersonaType getInfoPersona() {
		return infoPersona;
	}

	public void setInfoPersona(InfoPersonaType infoPersona) {
		this.infoPersona = infoPersona;
	}

	public InfoCompraType getInfoCompra() {
		return infoCompra;
	}

	public void setInfoCompra(InfoCompraType infoCompra) {
		this.infoCompra = infoCompra;
	}

	public InfoComercioType getInfoComercio() {
		return infoComercio;
	}

	public void setInfoComercio(InfoComercioType infoComercio) {
		this.infoComercio = infoComercio;
	}
	
    public String getPmtid() {
		return pmtid;
	}

	public void setPmtid(String pmtid) {
		this.pmtid = pmtid;
	}
	
	public List<ReferenceType> getReference() {
		if (reference == null) {
			reference = new ArrayList<ReferenceType>();
		}
		return reference;
	}

	public void setReference(List<ReferenceType> reference) {
		this.reference = reference;
	}

	public InfoPersonaType getInfoPersonaBeneficiario() {
		return infoPersonaBeneficiario;
	}

	public void setInfoPersonaBeneficiario(InfoPersonaType infoPersonaBeneficiario) {
		this.infoPersonaBeneficiario = infoPersonaBeneficiario;
	}

	@Override
	public String toString() {
		XMLUtil<IniciarTransaccionDeCompraRqType> requestParser = 
				new XMLUtil<IniciarTransaccionDeCompraRqType>();
		return requestParser.convertObjectToXml(this);
	}

}
