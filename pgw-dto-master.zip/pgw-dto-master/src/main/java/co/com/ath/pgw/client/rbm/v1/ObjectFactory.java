
package co.com.ath.pgw.client.rbm.v1;

import javax.xml.bind.JAXBElement;
import javax.xml.bind.annotation.XmlElementDecl;
import javax.xml.bind.annotation.XmlRegistry;
import javax.xml.namespace.QName;


/**
 * 
 * @author Jesus Octavio Avendaño <jesus.avendano@sophossolutions.com> 
 * @version 1.0 17/06/2020
 * @since 1.0
 * 
 * This object contains factory methods for each 
 * Java content interface and Java element interface 
 * generated in the co.com.ath.payments.v1 package. 
 * <p>An ObjectFactory allows you to programatically 
 * construct new instances of the Java representation 
 * for XML content. The Java representation of XML 
 * content can consist of schema derived interfaces 
 * and classes representing the binding of schema 
 * type definitions, element declarations and model 
 * groups.  Factory methods for each of these are 
 * provided in this class.
 * 
 */
@XmlRegistry
public class ObjectFactory {

    private final static QName _PSETransactionAddRq_QNAME = new QName("urn://ath.com.co/payments/v1/", "PSETransactionAddRq");
    private final static QName _PSETransactionAddRs_QNAME = new QName("urn://ath.com.co/payments/v1/", "PSETransactionAddRs");
    private final static QName _RBMPaymentAddRq_QNAME = new QName("urn://ath.com.co/payments/v1/", "RBMPaymentAddRq");
    private final static QName _RBMPaymentAddRs_QNAME = new QName("urn://ath.com.co/payments/v1/", "RBMPaymentAddRs");
    private final static QName _AVALPaymentAddRs_QNAME = new QName("urn://ath.com.co/payments/v1/", "AVALPaymentAddRs");
    private final static QName _AVALPaymentAddRq_QNAME = new QName("urn://ath.com.co/payments/v1/", "AVALPaymentAddRq");

    /**
     * Create a new ObjectFactory that can be used to create new instances of schema derived classes for package: co.com.ath.payments.v1
     * 
     */
    public ObjectFactory() {
    }

    /**
     * Create an instance of {@link AddRBMPayment }
     * 
     */
    public AddRBMPayment createAddRBMPayment() {
        return new AddRBMPayment();
    }

    /**
     * Create an instance of {@link RBMPaymentAddRqType }
     * 
     */
    public RBMPaymentAddRqType createRBMPaymentAddRqType() {
        return new RBMPaymentAddRqType();
    }

    /**
     * Create an instance of {@link AddRBMPaymentResponse }
     * 
     */
    public AddRBMPaymentResponse createAddRBMPaymentResponse() {
        return new AddRBMPaymentResponse();
    }

    /**
     * Create an instance of {@link RBMPaymentAddRsType }
     * 
     */
    public RBMPaymentAddRsType createRBMPaymentAddRsType() {
        return new RBMPaymentAddRsType();
    }

    /**
     * Create an instance of {@link PSETransactionAddRqType }
     * 
     */
    public PSETransactionAddRqType createPSETransactionAddRqType() {
        return new PSETransactionAddRqType();
    }

    /**
     * Create an instance of {@link AddAVALPaymentResponse }
     * 
     */
    public AddAVALPaymentResponse createAddAVALPaymentResponse() {
        return new AddAVALPaymentResponse();
    }

    /**
     * Create an instance of {@link AVALPaymentAddRsType }
     * 
     */
    public AVALPaymentAddRsType createAVALPaymentAddRsType() {
        return new AVALPaymentAddRsType();
    }

    /**
     * Create an instance of {@link PSETransactionAddRsType }
     * 
     */
    public PSETransactionAddRsType createPSETransactionAddRsType() {
        return new PSETransactionAddRsType();
    }

    /**
     * Create an instance of {@link AVALPaymentAddRqType }
     * 
     */
    public AVALPaymentAddRqType createAVALPaymentAddRqType() {
        return new AVALPaymentAddRqType();
    }

    /**
     * Create an instance of {@link AddPSETransactionResponse }
     * 
     */
    public AddPSETransactionResponse createAddPSETransactionResponse() {
        return new AddPSETransactionResponse();
    }

    /**
     * Create an instance of {@link AddAVALPayment }
     * 
     */
    public AddAVALPayment createAddAVALPayment() {
        return new AddAVALPayment();
    }

    /**
     * Create an instance of {@link AddPSETransaction }
     * 
     */
    public AddPSETransaction createAddPSETransaction() {
        return new AddPSETransaction();
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link PSETransactionAddRqType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "urn://ath.com.co/payments/v1/", name = "PSETransactionAddRq")
    public JAXBElement<PSETransactionAddRqType> createPSETransactionAddRq(PSETransactionAddRqType value) {
        return new JAXBElement<PSETransactionAddRqType>(_PSETransactionAddRq_QNAME, PSETransactionAddRqType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link PSETransactionAddRsType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "urn://ath.com.co/payments/v1/", name = "PSETransactionAddRs")
    public JAXBElement<PSETransactionAddRsType> createPSETransactionAddRs(PSETransactionAddRsType value) {
        return new JAXBElement<PSETransactionAddRsType>(_PSETransactionAddRs_QNAME, PSETransactionAddRsType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link RBMPaymentAddRqType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "urn://ath.com.co/payments/v1/", name = "RBMPaymentAddRq")
    public JAXBElement<RBMPaymentAddRqType> createRBMPaymentAddRq(RBMPaymentAddRqType value) {
        return new JAXBElement<RBMPaymentAddRqType>(_RBMPaymentAddRq_QNAME, RBMPaymentAddRqType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link RBMPaymentAddRsType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "urn://ath.com.co/payments/v1/", name = "RBMPaymentAddRs")
    public JAXBElement<RBMPaymentAddRsType> createRBMPaymentAddRs(RBMPaymentAddRsType value) {
        return new JAXBElement<RBMPaymentAddRsType>(_RBMPaymentAddRs_QNAME, RBMPaymentAddRsType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link AVALPaymentAddRsType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "urn://ath.com.co/payments/v1/", name = "AVALPaymentAddRs")
    public JAXBElement<AVALPaymentAddRsType> createAVALPaymentAddRs(AVALPaymentAddRsType value) {
        return new JAXBElement<AVALPaymentAddRsType>(_AVALPaymentAddRs_QNAME, AVALPaymentAddRsType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link AVALPaymentAddRqType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "urn://ath.com.co/payments/v1/", name = "AVALPaymentAddRq")
    public JAXBElement<AVALPaymentAddRqType> createAVALPaymentAddRq(AVALPaymentAddRqType value) {
        return new JAXBElement<AVALPaymentAddRqType>(_AVALPaymentAddRq_QNAME, AVALPaymentAddRqType.class, null, value);
    }

}
