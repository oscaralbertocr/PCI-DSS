
package co.com.ath.pgw.rest.request.dto;

import java.io.Serializable;
import java.util.List;

import javax.validation.Valid;
import javax.validation.constraints.NotNull;

import com.fasterxml.jackson.annotation.JsonProperty;

import co.com.ath.pgw.core.logging.util.XMLUtil;
import co.com.ath.pgw.rest.dto.AgreementAddTx;
import co.com.ath.pgw.rest.dto.CustInfoAddTx;
import co.com.ath.pgw.rest.dto.FeeAddTx;
import co.com.ath.pgw.rest.dto.InvoicePmtInfoAddTx;
import co.com.ath.pgw.rest.dto.RefInfoAddTx;
import co.com.ath.pgw.rest.dto.SecretListAddTx;
import co.com.ath.pgw.rest.dto.TaxPmtInfoAddTx;
import co.com.ath.pgw.rest.dto.TrnSrcInfoAddTx;

public class TransactionCreateRequest implements Serializable{

	@JsonProperty("Agreement")
	@Valid
	@NotNull
    private AgreementAddTx agreement;
	
	@JsonProperty("SecretList")
	@NotNull
    private List<@Valid SecretListAddTx> secretList = null;
	
	@JsonProperty("Fee")
	@Valid
	@NotNull
    private FeeAddTx fee;
	
	@JsonProperty("TaxPmtInfo")
	@Valid
    private TaxPmtInfoAddTx taxPmtInfo;
	
	@JsonProperty("InvoicePmtInfo")
	@Valid
	@NotNull
    private InvoicePmtInfoAddTx invoicePmtInfo;
	
	@JsonProperty("RefInfo")
	@NotNull
    private List<@Valid RefInfoAddTx> refInfo = null;
	
	@JsonProperty("TrnSrcInfo")
	@Valid
    private TrnSrcInfoAddTx trnSrcInfo;
	
	
	@JsonProperty("CustInfo")
	@Valid
	@NotNull
    private CustInfoAddTx custInfo;
	
    private final static long serialVersionUID = -8955328482127497279L;

	public AgreementAddTx getAgreement() {
        return agreement;
    }

    public void setAgreement(AgreementAddTx agreement) {
        this.agreement = agreement;
    }

    public List<SecretListAddTx> getSecretList() {
        return secretList;
    }

    public void setSecretList(List<SecretListAddTx> secretList) {
        this.secretList = secretList;
    }

    public FeeAddTx getFee() {
        return fee;
    }

    public void setFee(FeeAddTx fee) {
        this.fee = fee;
    }

    public TaxPmtInfoAddTx getTaxPmtInfo() {
        return taxPmtInfo;
    }

    public void setTaxPmtInfo(TaxPmtInfoAddTx taxPmtInfo) {
        this.taxPmtInfo = taxPmtInfo;
    }

    public InvoicePmtInfoAddTx getInvoicePmtInfo() {
        return invoicePmtInfo;
    }

    public void setInvoicePmtInfo(InvoicePmtInfoAddTx invoicePmtInfo) {
        this.invoicePmtInfo = invoicePmtInfo;
    }

    public List<RefInfoAddTx> getRefInfo() {
        return refInfo;
    }

    public void setRefInfo(List<RefInfoAddTx> refInfo) {
        this.refInfo = refInfo;
    }

    public TrnSrcInfoAddTx getTrnSrcInfo() {
        return trnSrcInfo;
    }

    public void setTrnSrcInfo(TrnSrcInfoAddTx trnSrcInfo) {
        this.trnSrcInfo = trnSrcInfo;
    }

    public CustInfoAddTx getCustInfo() {
        return custInfo;
    }

    public void setCustInfo(CustInfoAddTx custInfo) {
        this.custInfo = custInfo;
    }

	@Override
	public String toString() {
		XMLUtil<TransactionCreateRequest> util = new XMLUtil<TransactionCreateRequest>();
		return util.convertObjectToJson(this);
	}
    
}
