
package co.com.ath.pgw.in.model;

/**
 * <p>
 * Clase Java para PayingCustomer_Type complex type.
 * 
 * <p>
 * El siguiente fragmento de esquema especifica el contenido que se espera que
 * haya en esta clase.
 * 
 * <pre>
 * &lt;complexType name="PayingCustomer_Type"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element ref="{urn://grupoaval.com/xsd/ifx/}CustName" minOccurs="0"/&gt;
 *         &lt;element ref="{urn://grupoaval.com/xsd/ifx/}CustId" minOccurs="0"/&gt;
 *         &lt;element ref="{urn://grupoaval.com/xsd/ifx/}EmailAddr" minOccurs="0"/&gt;
 *         &lt;element ref="{urn://grupoaval.com/xsd/ifx/}Phone" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
public class PayingCustomerType {

	protected CustNameType custName;

	protected CustIdType custId;

	protected String emailAddr;

	protected String phone;

	/**
	 * Obtiene el valor de la propiedad custName.
	 * 
	 * @return possible object is {@link CustNameType }
	 * 
	 */
	public CustNameType getCustName() {
		return custName;
	}

	/**
	 * Define el valor de la propiedad custName.
	 * 
	 * @param value allowed object is {@link CustNameType }
	 * 
	 */
	public void setCustName(CustNameType value) {
		this.custName = value;
	}

	/**
	 * Obtiene el valor de la propiedad custId.
	 * 
	 * @return possible object is {@link CustIdType }
	 * 
	 */
	public CustIdType getCustId() {
		return custId;
	}

	/**
	 * Define el valor de la propiedad custId.
	 * 
	 * @param value allowed object is {@link CustIdType }
	 * 
	 */
	public void setCustId(CustIdType value) {
		this.custId = value;
	}

	/**
	 * Obtiene el valor de la propiedad emailAddr.
	 * 
	 * @return possible object is {@link String }
	 * 
	 */
	public String getEmailAddr() {
		return emailAddr;
	}

	/**
	 * Define el valor de la propiedad emailAddr.
	 * 
	 * @param value allowed object is {@link String }
	 * 
	 */
	public void setEmailAddr(String value) {
		this.emailAddr = value;
	}

	/**
	 * Obtiene el valor de la propiedad phone.
	 * 
	 * @return possible object is {@link String }
	 * 
	 */
	public String getPhone() {
		return phone;
	}

	/**
	 * Define el valor de la propiedad phone.
	 * 
	 * @param value allowed object is {@link String }
	 * 
	 */
	public void setPhone(String value) {
		this.phone = value;
	}

}
