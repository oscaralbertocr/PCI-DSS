package co.com.ath.pgw.rest.dto;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonProperty;

public class StatusQrDetail implements Serializable{

	private static final long serialVersionUID = 8656956324558294325L;
	
	@JsonProperty("PmtAuthId")
    private String pmtAuthId;

	public String getPmtAuthId() {
		return pmtAuthId;
	}

	public void setPmtAuthId(String pmtAuthId) {
		this.pmtAuthId = pmtAuthId;
	}
	
	

	
}
