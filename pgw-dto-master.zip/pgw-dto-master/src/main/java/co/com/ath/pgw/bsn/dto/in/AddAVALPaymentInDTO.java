/*
 * AddAVALPaymentInDTO
 *  
 * GSI - Integración
 * Creado el: 20/09/2014
 *
 * Copyright (c) A Toda Hora S.A. Todos los derechos reservados
 * 
 * Este software es confidencial y es propietario de ATH, queda prohibido
 * su uso, reproducción y copia de manera parcial o permanente salvo autorización
 * expresa de A Toda Hora S.A o de quién represente sus derechos.
 */
package co.com.ath.pgw.bsn.dto.in;


import co.com.ath.pgw.bsn.model.bo.TransactionBO;
import co.com.ath.pgw.core.logging.util.XMLUtil;



/**
 * DTO de entrada con la información para la operación AddAVALPayment.
 *
 * @version 0.0.0 22/09/2014
 * @author Andrés Méndez Juanias <proveedor_mamendez@ath.com.co>
 */

public class AddAVALPaymentInDTO extends CommonObjectInDTO {

    private TransactionBO transactionBO;
    
	public AddAVALPaymentInDTO(){

	}

	@Override
	public String toString() {
		XMLUtil<AddAVALPaymentInDTO> requestParser = new XMLUtil<AddAVALPaymentInDTO>();
		return requestParser.convertObjectToXml(this);
	}
	
    public TransactionBO getTransactionBO() {
        return transactionBO;
    }

    public void setTransactionBO(TransactionBO transactionBO) {
        this.transactionBO = transactionBO;
    }
    
}