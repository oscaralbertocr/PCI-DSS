package co.com.ath.pgw.in.model;

public class UserIdType
extends CustIdType
{


}