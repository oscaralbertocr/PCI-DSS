package co.com.ath.pgw.in.dto;

import javax.xml.datatype.XMLGregorianCalendar;

import co.com.ath.pgw.in.model.SvcRqType;

public class HistoricTransactionInqRqType extends SvcRqType
{

    
    protected String bankId;
   
    protected XMLGregorianCalendar startDt;
  
    protected XMLGregorianCalendar endDt;
   
    protected String state;
   
    protected String pmtWayId;

    /**
     * Obtiene el valor de la propiedad bankId.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getBankId() {
        return bankId;
    }

    /**
     * Define el valor de la propiedad bankId.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setBankId(String value) {
        this.bankId = value;
    }

    /**
     * Obtiene el valor de la propiedad startDt.
     * 
     * @return
     *     possible object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public XMLGregorianCalendar getStartDt() {
        return startDt;
    }

    /**
     * Define el valor de la propiedad startDt.
     * 
     * @param value
     *     allowed object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public void setStartDt(XMLGregorianCalendar value) {
        this.startDt = value;
    }

    /**
     * Obtiene el valor de la propiedad endDt.
     * 
     * @return
     *     possible object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public XMLGregorianCalendar getEndDt() {
        return endDt;
    }

    /**
     * Define el valor de la propiedad endDt.
     * 
     * @param value
     *     allowed object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public void setEndDt(XMLGregorianCalendar value) {
        this.endDt = value;
    }

    /**
     * Obtiene el valor de la propiedad state.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getState() {
        return state;
    }

    /**
     * Define el valor de la propiedad state.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setState(String value) {
        this.state = value;
    }

    /**
     * Obtiene el valor de la propiedad pmtWayId.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPmtWayId() {
        return pmtWayId;
	}

    /**
     * Define el valor de la propiedad pmtWayId.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPmtWayId(String value) {
        this.pmtWayId = value;
    }
    
    /*
    @Override
	public String toString() {
		XMLUtil<HistoricTransactionInqRqType> requestParser = 
				new XMLUtil<HistoricTransactionInqRqType>();
		return requestParser.convertObjectToXml(this);
	}
	*/

}
