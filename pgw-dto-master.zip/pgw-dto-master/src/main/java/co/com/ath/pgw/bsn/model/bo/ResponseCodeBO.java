/*
 * ResponseCodesVO
 *  
 * GSI - Integración
 * Creado el: 28/08/2014
 *
 * Copyright (c) A Toda Hora S.A. Todos los derechos reservados
 * 
 * Este software es confidencial y es propietario de ATH, queda prohibido
 * su uso, reproducción y copia de manera parcial o permanente salvo autorización
 * expresa de A Toda Hora S.A o de quién represente sus derechos.
 */
package co.com.ath.pgw.bsn.model.bo;


/**
 * Representa los códigos de respuesta de los servicios de pago. Esta entidad
 * pertenece al modelo de negocio.
 * 
 * @author proveedor_japiza
 * @version 1.0 29 Ago 2014
 * @since
 */
public class ResponseCodeBO {

	/**
	 * Código de respuesta
	 */
	private String code;

	/**
	 * Descripción del código de respuesta
	 */
	private String description;

	/**
	 * Construye un código de error.
	 */
	public ResponseCodeBO(){
		super();
	}

	/**
	 * Retorna el código de respuesta.
	 * 
	 * @return Código de respuesta.
	 */
	public String getCode() {
		return code;
	}

	/**
	 * Establece el código de respuesta.
	 * 
	 * @param code Código de respuesta.
	 */
	public void setCode(String code) {
		this.code = code;
	}

	/**
	 * Retorna la descripción del código de respuesta.
	 * 
	 * @return Descripción del código de respuesta.
	 */
	public String getDescription() {
		return description;
	}

	/**
	 * Establece la descripción del código de respuesta.
	 * 
	 * @param description Descripción.
	 */
	public void setDescription(String description) {
		this.description = description;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((code == null) ? 0 : code.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		ResponseCodeBO other = (ResponseCodeBO) obj;
		if (code == null) {
			if (other.code != null)
				return false;
		} else if (!code.equals(other.code))
			return false;
		return true;
	}

	@Override
	public String toString() {
		return "ResponseCodeVO [code=" + code + ", description=" + description
				+ "]";
	}

}