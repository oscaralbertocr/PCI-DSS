/*
 * ACHgetTransactionInformationInDTO
 *  
 * GSI - Integración
 * Creado el: 14/10/2014
 *
 * Copyright (c) A Toda Hora S.A. Todos los derechos reservados
 * 
 * Este software es confidencial y es propietario de ATH, queda prohibido
 * su uso, reproducción y copia de manera parcial o permanente salvo autorización
 * expresa de A Toda Hora S.A o de quién represente sus derechos.
 */
package co.com.ath.pgw.bsn.dto.in;

/**
 * Class description goes here...
 *
 * @author Andrés Méndez Juanias <proveedor_mamendez@ath.com.co> 
 * @version 1.0 14/10/2014
 * @since 1.0
 */
public class ACHgetTransactionInformationInDTO {
	
	private String entityCode;
	
    private String trazabilityCode;

	/**
	 * Método encargado de recuperar el valor del atributo entityCode.
	 * @return El atributo entityCode asociado a la clase.
	 */
	public String getEntityCode() {
		return entityCode;
	}

	/**
	 * Método encargado de actualizar el atributo entityCode.
	 * @param entityCode Nuevo valor para entityCode.
	 */
	public void setEntityCode(String entityCode) {
		this.entityCode = entityCode;
	}

	/**
	 * Método encargado de recuperar el valor del atributo trazabilityCode.
	 * @return El atributo trazabilityCode asociado a la clase.
	 */
	public String getTrazabilityCode() {
		return trazabilityCode;
	}

	/**
	 * Método encargado de actualizar el atributo trazabilityCode.
	 * @param trazabilityCode Nuevo valor para trazabilityCode.
	 */
	public void setTrazabilityCode(String trazabilityCode) {
		this.trazabilityCode = trazabilityCode;
	}

}
