
package co.com.ath.pgw.client.globalPay.model;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;

import co.com.ath.pgw.client.globalPay.model.TipoInfoRespuesta;


/**
 * <p>Clase Java para TipoInfoDispersionPago complex type.
 * 
 * <p>El siguiente fragmento de esquema especifica el contenido que se espera que haya en esta clase.
 * 
 * <pre>
 * &lt;complexType name="TipoInfoDispersionPago"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="infoPago" type="{http://www.rbm.com.co/esb/globalpay/}TipoInfoPago" minOccurs="0"/&gt;
 *         &lt;element name="infoRespuesta" type="{http://www.rbm.com.co/esb/}TipoInfoRespuesta"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "TipoInfoDispersionPago", propOrder = {
    "infoPago",
    "infoRespuesta"
})
public class TipoInfoDispersionPago {

    protected TipoInfoPago infoPago;
    @XmlElement(required = true)
    protected TipoInfoRespuesta infoRespuesta;

    /**
     * Obtiene el valor de la propiedad infoPago.
     * 
     * @return
     *     possible object is
     *     {@link TipoInfoPago }
     *     
     */
    public TipoInfoPago getInfoPago() {
        return infoPago;
    }

    /**
     * Define el valor de la propiedad infoPago.
     * 
     * @param value
     *     allowed object is
     *     {@link TipoInfoPago }
     *     
     */
    public void setInfoPago(TipoInfoPago value) {
        this.infoPago = value;
    }

    /**
     * Obtiene el valor de la propiedad infoRespuesta.
     * 
     * @return
     *     possible object is
     *     {@link TipoInfoRespuesta }
     *     
     */
    public TipoInfoRespuesta getInfoRespuesta() {
        return infoRespuesta;
    }

    /**
     * Define el valor de la propiedad infoRespuesta.
     * 
     * @param value
     *     allowed object is
     *     {@link TipoInfoRespuesta }
     *     
     */
    public void setInfoRespuesta(TipoInfoRespuesta value) {
        this.infoRespuesta = value;
    }

}
