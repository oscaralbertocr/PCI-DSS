package co.com.ath.pgw.rest.dto;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonProperty;

public class TransactionStatus implements Serializable {
	
	@JsonProperty("ApprovalId")
	private String approvalId;
	@JsonProperty("TrnServerStatusCode")
	private String trnServerStatusCode;
	@JsonProperty("TrnStatusCode")
	private String trnStatusCode;
	@JsonProperty("TrnStatusDesc")
	private String trnStatusDesc;
	private static final long serialVersionUID = -8949993428231959780L;
	
	public String getApprovalId() {
		return approvalId;
	}
	public void setApprovalId(String approvalId) {
		this.approvalId = approvalId;
	}
	public String getTrnServerStatusCode() {
		return trnServerStatusCode;
	}
	public void setTrnServerStatusCode(String trnServerStatusCode) {
		this.trnServerStatusCode = trnServerStatusCode;
	}	
	public String getTrnStatusCode() {
		return trnStatusCode;
	}
	public void setTrnStatusCode(String trnStatusCode) {
		this.trnStatusCode = trnStatusCode;
	}
	public String getTrnStatusDesc() {
		return trnStatusDesc;
	}
	public void setTrnStatusDesc(String trnStatusDesc) {
		this.trnStatusDesc = trnStatusDesc;
	}
}
