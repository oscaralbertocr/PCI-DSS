
package co.com.ath.pgw.rest.dto;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonProperty;

public class TaxPmtInfo implements Serializable
{

	@JsonProperty("CurAmt")
    private CurAmt curAmt;
	
    private final static long serialVersionUID = -8718986820341574650L;

    public CurAmt getCurAmt() {
        return curAmt;
    }

    public void setCurAmt(CurAmt curAmt) {
        this.curAmt = curAmt;
    }

}
