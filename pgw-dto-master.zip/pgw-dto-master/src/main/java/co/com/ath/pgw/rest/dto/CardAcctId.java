package co.com.ath.pgw.rest.dto;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonProperty;

public class CardAcctId implements Serializable {

	@JsonProperty("AcctId")
	private String acctId;
	
	@JsonProperty("CCMotoAcct")
	private CCMotoAcct ccMotoAcct;
	
	@JsonProperty("CardMagData")
	private CardMagData cardMagData;
	
	private static final long serialVersionUID = -1485465686028397362L;

	public String getAcctId() {
		return acctId;
	}

	public void setAcctId(String acctId) {
		this.acctId = acctId;
	}

	public CCMotoAcct getCcMotoAcct() {
		return ccMotoAcct;
	}

	public void setCcMotoAcct(CCMotoAcct ccMotoAcct) {
		this.ccMotoAcct = ccMotoAcct;
	}

	public CardMagData getCardMagData() {
		return cardMagData;
	}

	public void setCardMagData(CardMagData cardMagData) {
		this.cardMagData = cardMagData;
	}

}