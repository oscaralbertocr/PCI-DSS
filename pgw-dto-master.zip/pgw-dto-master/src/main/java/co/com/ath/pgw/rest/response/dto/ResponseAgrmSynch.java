package co.com.ath.pgw.rest.response.dto;

import java.io.Serializable;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonProperty;

import co.com.ath.pgw.bsn.dto.out.AgreementOutDTO;
import co.com.ath.pgw.core.logging.util.XMLUtil;
import co.com.ath.pgw.in.dto.AgreementRsType;
import co.com.ath.pgw.in.model.SvcRsType;
import co.com.ath.pgw.rest.dto.AdditionalDepAcctId;
import co.com.ath.pgw.rest.dto.Agreement;
import co.com.ath.pgw.rest.dto.AssociateInfo;
import co.com.ath.pgw.rest.dto.BankInfo;
import co.com.ath.pgw.rest.dto.LegalPerson;
import co.com.ath.pgw.rest.dto.PartnerInfo;
import co.com.ath.pgw.rest.dto.PmtInfo;
import co.com.ath.pgw.rest.dto.PmtMethod;
import co.com.ath.pgw.rest.dto.RefInfo;
import co.com.ath.pgw.rest.dto.SecretList;
import co.com.ath.pgw.rest.dto.TrnSrcInfo;

public class ResponseAgrmSynch extends AgreementOutDTO implements Serializable
{

    @JsonProperty("RefInfo")
    private List<RefInfo> refInfo = null;
    @JsonProperty("BankInfo")
    private BankInfo bankInfo;
    @JsonProperty("Agreement")
    private Agreement agreement;
    @JsonProperty("LegalPerson")
    private LegalPerson legalPerson;
    @JsonProperty("PartnerInfo")
    private List<PartnerInfo> partnerInfo = null;
    @JsonProperty("PmtInfo")
    private List<PmtInfo> pmtInfo = null;
    @JsonProperty("TrnSrcInfo")
    private TrnSrcInfo trnSrcInfo;
    @JsonProperty("SecretList")
    private List<SecretList> secretList = null;
    @JsonProperty("AdditionalDepAcctId")
    private List<AdditionalDepAcctId> additionalDepAcctId = null;
    
    private final static long serialVersionUID = 5249561885558219093L;


    public List<AdditionalDepAcctId> getAdditionalDepAcctId() {
		return additionalDepAcctId;
	}

	public void setAdditionalDepAcctId(List<AdditionalDepAcctId> additionalDepAcctId) {
		this.additionalDepAcctId = additionalDepAcctId;
	}

    public List<RefInfo> getRefInfo() {
        return refInfo;
    }

    public void setRefInfo(List<RefInfo> refInfo) {
        this.refInfo = refInfo;
    }

    public BankInfo getBankInfo() {
        return bankInfo;
    }

    public void setBankInfo(BankInfo bankInfo) {
        this.bankInfo = bankInfo;
    }

    public Agreement getAgreement() {
        return agreement;
    }

    public void setAgreement(Agreement agreement) {
        this.agreement = agreement;
    }

    public LegalPerson getLegalPerson() {
        return legalPerson;
    }

    public void setLegalPerson(LegalPerson legalPerson) {
        this.legalPerson = legalPerson;
    }

    public TrnSrcInfo getTrnSrcInfo() {
        return trnSrcInfo;
    }

    public void setTrnSrcInfo(TrnSrcInfo trnSrcInfo) {
        this.trnSrcInfo = trnSrcInfo;
    }

	public List<SecretList> getSecretList() {
		return secretList;
	}

	public void setSecretList(List<SecretList> secretList) {
		this.secretList = secretList;
	}
    
	public List<PmtInfo> getPmtInfo() {
		return pmtInfo;
	}

	public void setPmtInfo(List<PmtInfo> pmtInfo) {
		this.pmtInfo = pmtInfo;
	}

	
	public List<PartnerInfo> getPartnerInfo() {
		return partnerInfo;
	}

	public void setPartnerInfo(List<PartnerInfo> partnerInfo) {
		this.partnerInfo = partnerInfo;
	}

	@Override
	public String toString() {
		XMLUtil<ResponseAgrmSynch> requestParser = 
				new XMLUtil<ResponseAgrmSynch>();
		return requestParser.convertObjectToJson(this);
	}
	

}
