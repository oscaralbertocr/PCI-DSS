/*
 * UpdatePSEInformationOutDTO
 *  
 * GSI - Integración
 * Creado el: 13/04/2015
 *
 * Copyright (c) A Toda Hora S.A. Todos los derechos reservados
 * 
 * Este software es confidencial y es propietario de ATH, queda prohibido
 * su uso, reproducción y copia de manera parcial o permanente salvo autorización
 * expresa de A Toda Hora S.A o de quién represente sus derechos.
 */
package co.com.ath.pgw.bsn.pse.dto;

/**
 * Class description goes here...
 *
 * @author Andrés Méndez Juanias <proveedor_mamendez@ath.com.co> 
 * @version 1.0 13/04/2015
 * @since 1.0
 */
public class UpdatePSEInformationOutDTO {
	
	private String returnCode;

	/**
	 * Método encargado de recuperar el valor del atributo returnCode.
	 * @return El atributo returnCode asociado a la clase.
	 */
	public String getReturnCode() {
		return returnCode;
	}

	/**
	 * Método encargado de actualizar el atributo returnCode.
	 * @param returnCode Nuevo valor para returnCode.
	 */
	public void setReturnCode(String returnCode) {
		this.returnCode = returnCode;
	}
	
	

}
