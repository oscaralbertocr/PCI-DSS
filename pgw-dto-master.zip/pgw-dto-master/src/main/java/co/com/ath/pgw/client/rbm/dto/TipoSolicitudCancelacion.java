
package co.com.ath.pgw.client.rbm.dto;

import java.util.ArrayList;
import java.util.List;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;

import co.com.ath.pgw.client.rbm.model.TipoCabeceraSolicitud;
import co.com.ath.pgw.client.rbm.model.TipoIdPersona;
import co.com.ath.pgw.client.rbm.model.TipoInfoCompra;
import co.com.ath.pgw.client.rbm.model.TipoInfoMedioPago;
import co.com.ath.pgw.client.rbm.model.TipoInfoPersona;
import co.com.ath.pgw.client.rbm.model.TipoInfoRefCancelacion;

/**
 * <p>
 * Clase Java para TipoSolicitudCancelacion complex type.
 * 
 * <p>
 * El siguiente fragmento de esquema especifica el contenido que se espera que
 * haya en esta clase.
 * 
 * <pre>
 * &lt;complexType name="TipoSolicitudCancelacion"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="cabeceraSolicitud" type="{http://www.rbm.com.co/esb/comercio/compra/}TipoCabeceraSolicitud"/&gt;
 *         &lt;element name="idPersona" type="{http://www.rbm.com.co/esb/}TipoIdPersona" minOccurs="0"/&gt;
 *         &lt;element name="infoMedioPago" type="{http://www.rbm.com.co/esb/comercio/compra/}TipoInfoMedioPago"/&gt;
 *         &lt;element name="infoCompra" type="{http://www.rbm.com.co/esb/comercio/compra/}TipoInfoCompra"/&gt;
 *         &lt;element name="infoRefCancelacion" type="{http://www.rbm.com.co/esb/}TipoInfoRefCancelacion"/&gt;
 *         &lt;element name="infoPersona" type="{http://www.rbm.com.co/esb/}TipoInfoPersona" maxOccurs="unbounded" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "TipoSolicitudCancelacion", propOrder = { "cabeceraSolicitud", "idPersona", "infoMedioPago",
		"infoCompra", "infoRefCancelacion", "infoPersona" })
public class TipoSolicitudCancelacion {

	@XmlElement(required = true)
	protected TipoCabeceraSolicitud cabeceraSolicitud;
	protected TipoIdPersona idPersona;
	@XmlElement(required = true)
	protected TipoInfoMedioPago infoMedioPago;
	@XmlElement(required = true)
	protected TipoInfoCompra infoCompra;
	@XmlElement(required = true)
	protected TipoInfoRefCancelacion infoRefCancelacion;
	protected List<TipoInfoPersona> infoPersona;

	/**
	 * Obtiene el valor de la propiedad cabeceraSolicitud.
	 * 
	 * @return possible object is {@link TipoCabeceraSolicitud }
	 * 
	 */
	public TipoCabeceraSolicitud getCabeceraSolicitud() {
		return cabeceraSolicitud;
	}

	/**
	 * Define el valor de la propiedad cabeceraSolicitud.
	 * 
	 * @param value allowed object is {@link TipoCabeceraSolicitud }
	 * 
	 */
	public void setCabeceraSolicitud(TipoCabeceraSolicitud value) {
		this.cabeceraSolicitud = value;
	}

	/**
	 * Obtiene el valor de la propiedad idPersona.
	 * 
	 * @return possible object is {@link TipoIdPersona }
	 * 
	 */
	public TipoIdPersona getIdPersona() {
		return idPersona;
	}

	/**
	 * Define el valor de la propiedad idPersona.
	 * 
	 * @param value allowed object is {@link TipoIdPersona }
	 * 
	 */
	public void setIdPersona(TipoIdPersona value) {
		this.idPersona = value;
	}

	/**
	 * Obtiene el valor de la propiedad infoMedioPago.
	 * 
	 * @return possible object is {@link TipoInfoMedioPago }
	 * 
	 */
	public TipoInfoMedioPago getInfoMedioPago() {
		return infoMedioPago;
	}

	/**
	 * Define el valor de la propiedad infoMedioPago.
	 * 
	 * @param value allowed object is {@link TipoInfoMedioPago }
	 * 
	 */
	public void setInfoMedioPago(TipoInfoMedioPago value) {
		this.infoMedioPago = value;
	}

	/**
	 * Obtiene el valor de la propiedad infoCompra.
	 * 
	 * @return possible object is {@link TipoInfoCompra }
	 * 
	 */
	public TipoInfoCompra getInfoCompra() {
		return infoCompra;
	}

	/**
	 * Define el valor de la propiedad infoCompra.
	 * 
	 * @param value allowed object is {@link TipoInfoCompra }
	 * 
	 */
	public void setInfoCompra(TipoInfoCompra value) {
		this.infoCompra = value;
	}

	/**
	 * Obtiene el valor de la propiedad infoRefCancelacion.
	 * 
	 * @return possible object is {@link TipoInfoRefCancelacion }
	 * 
	 */
	public TipoInfoRefCancelacion getInfoRefCancelacion() {
		return infoRefCancelacion;
	}

	/**
	 * Define el valor de la propiedad infoRefCancelacion.
	 * 
	 * @param value allowed object is {@link TipoInfoRefCancelacion }
	 * 
	 */
	public void setInfoRefCancelacion(TipoInfoRefCancelacion value) {
		this.infoRefCancelacion = value;
	}

	/**
	 * Gets the value of the infoPersona property.
	 * 
	 * <p>
	 * This accessor method returns a reference to the live list, not a snapshot.
	 * Therefore any modification you make to the returned list will be present
	 * inside the JAXB object. This is why there is not a <CODE>set</CODE> method
	 * for the infoPersona property.
	 * 
	 * <p>
	 * For example, to add a new item, do as follows:
	 * 
	 * <pre>
	 * getInfoPersona().add(newItem);
	 * </pre>
	 * 
	 * 
	 * <p>
	 * Objects of the following type(s) are allowed in the list
	 * {@link TipoInfoPersona }
	 * 
	 * 
	 */
	public List<TipoInfoPersona> getInfoPersona() {
		if (infoPersona == null) {
			infoPersona = new ArrayList<TipoInfoPersona>();
		}
		return this.infoPersona;
	}

}
