
package co.com.ath.pgw.client.globalPay.dto;

import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;

import co.com.ath.pgw.client.globalPay.model.TipoCabeceraSolicitud;
import co.com.ath.pgw.client.globalPay.model.TipoCredenciales;
import co.com.ath.pgw.client.globalPay.model.TipoInfoDispersionCompra;
import co.com.ath.pgw.client.globalPay.model.TipoInfoPersona;
import co.com.ath.pgw.client.globalPay.model.TipoInformacionComercio;
import co.com.ath.pgw.core.logging.util.XMLUtil;


/**
 * <p>Clase Java para anonymous complex type.
 * 
 * <p>El siguiente fragmento de esquema especifica el contenido que se espera que haya en esta clase.
 * 
 * <pre>
 * &lt;complexType&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="credenciales" type="{http://www.rbm.com.co/esb/globalpay/}TipoCredenciales" minOccurs="0"/&gt;
 *         &lt;element name="cabeceraSolicitud" type="{http://www.rbm.com.co/esb/globalpay/}TipoCabeceraSolicitud"/&gt;
 *         &lt;element name="infoPersona" type="{http://www.rbm.com.co/esb/globalpay/}TipoInfoPersona" minOccurs="0"/&gt;
 *         &lt;element name="infoComercio" type="{http://www.rbm.com.co/esb/globalpay/}TipoInformacionComercio" minOccurs="0"/&gt;
 *         &lt;element name="infoDispersion" type="{http://www.rbm.com.co/esb/globalpay/}TipoInfoDispersionCompra" maxOccurs="unbounded"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "", propOrder = {
    "credenciales",
    "cabeceraSolicitud",
    "infoPersona",
    "infoComercio",
    "infoDispersion"
})
@XmlRootElement(name = "IniciarTransaccionMultiCompraSolicitud")
public class IniciarTransaccionMultiCompraSolicitudRequest {

    protected TipoCredenciales credenciales;
    @XmlElement(required = true)
    protected TipoCabeceraSolicitud cabeceraSolicitud;
    protected TipoInfoPersona infoPersona;
    protected TipoInformacionComercio infoComercio;
    @XmlElement(required = true)
    protected List<TipoInfoDispersionCompra> infoDispersion;

    /**
     * Obtiene el valor de la propiedad credenciales.
     * 
     * @return
     *     possible object is
     *     {@link TipoCredenciales }
     *     
     */
    public TipoCredenciales getCredenciales() {
        return credenciales;
    }

    /**
     * Define el valor de la propiedad credenciales.
     * 
     * @param value
     *     allowed object is
     *     {@link TipoCredenciales }
     *     
     */
    public void setCredenciales(TipoCredenciales value) {
        this.credenciales = value;
    }

    /**
     * Obtiene el valor de la propiedad cabeceraSolicitud.
     * 
     * @return
     *     possible object is
     *     {@link TipoCabeceraSolicitud }
     *     
     */
    public TipoCabeceraSolicitud getCabeceraSolicitud() {
        return cabeceraSolicitud;
    }

    /**
     * Define el valor de la propiedad cabeceraSolicitud.
     * 
     * @param value
     *     allowed object is
     *     {@link TipoCabeceraSolicitud }
     *     
     */
    public void setCabeceraSolicitud(TipoCabeceraSolicitud value) {
        this.cabeceraSolicitud = value;
    }

    /**
     * Obtiene el valor de la propiedad infoPersona.
     * 
     * @return
     *     possible object is
     *     {@link TipoInfoPersona }
     *     
     */
    public TipoInfoPersona getInfoPersona() {
        return infoPersona;
    }

    /**
     * Define el valor de la propiedad infoPersona.
     * 
     * @param value
     *     allowed object is
     *     {@link TipoInfoPersona }
     *     
     */
    public void setInfoPersona(TipoInfoPersona value) {
        this.infoPersona = value;
    }

    /**
     * Obtiene el valor de la propiedad infoComercio.
     * 
     * @return
     *     possible object is
     *     {@link TipoInformacionComercio }
     *     
     */
    public TipoInformacionComercio getInfoComercio() {
        return infoComercio;
    }

    /**
     * Define el valor de la propiedad infoComercio.
     * 
     * @param value
     *     allowed object is
     *     {@link TipoInformacionComercio }
     *     
     */
    public void setInfoComercio(TipoInformacionComercio value) {
        this.infoComercio = value;
    }

    /**
     * Gets the value of the infoDispersion property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the infoDispersion property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getInfoDispersion().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link TipoInfoDispersionCompra }
     * 
     * 
     */
    public List<TipoInfoDispersionCompra> getInfoDispersion() {
        if (infoDispersion == null) {
            infoDispersion = new ArrayList<TipoInfoDispersionCompra>();
        }
        return this.infoDispersion;
    }
    
    @Override
	public String toString() {
		XMLUtil<IniciarTransaccionMultiCompraSolicitudRequest> requestParser = new XMLUtil<IniciarTransaccionMultiCompraSolicitudRequest>();
		return requestParser.convertObjectToXml(this);
	}

}
