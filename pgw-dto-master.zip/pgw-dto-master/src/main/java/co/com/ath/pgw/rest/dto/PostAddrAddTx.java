package co.com.ath.pgw.rest.dto;

import java.io.Serializable;
import com.fasterxml.jackson.annotation.JsonProperty;


public class PostAddrAddTx implements Serializable {

	private static final long serialVersionUID = 3132135003370458957L;
	@JsonProperty("City")
    private String city;
    @JsonProperty("StateProv")
    private String stateProv;
    @JsonProperty("Country")
    private String country;
    @JsonProperty("Addr1")
    private String addr1;  

    public String getCity() {
        return city;
    }

    public void setCity(String city) {
        this.city = city;
    }

    public String getStateProv() {
        return stateProv;
    }

    public void setStateProv(String stateProv) {
        this.stateProv = stateProv;
    }

    public String getCountry() {
        return country;
    }

    public void setCountry(String country) {
        this.country = country;
    }

    public String getAddr1() {
        return addr1;
    }
    
    public void setAddr1(String addr1) {
        this.addr1 = addr1;
    }

}
