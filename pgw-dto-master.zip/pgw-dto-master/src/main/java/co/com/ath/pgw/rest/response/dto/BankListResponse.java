package co.com.ath.pgw.rest.response.dto;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonProperty;

import co.com.ath.pgw.core.logging.util.XMLUtil;
import co.com.ath.pgw.rest.dto.BankInfo;

public class BankListResponse implements Serializable {
	
	@JsonProperty("BankInfo")
	private List<BankInfo> bankInfo = null;
	private static final long serialVersionUID = 3414418355318586398L;

	public List<BankInfo> getBankInfo() {
		if(bankInfo == null) {
			bankInfo = new ArrayList<BankInfo>();
		}
		return bankInfo;
	}

	public void setBankInfo(List<BankInfo> bankInfo) {
		this.bankInfo = bankInfo;
	}

	@Override
	public String toString() {
		XMLUtil<BankListResponse> util = new XMLUtil<BankListResponse>();
		return util.convertObjectToJson(this);
	}

}