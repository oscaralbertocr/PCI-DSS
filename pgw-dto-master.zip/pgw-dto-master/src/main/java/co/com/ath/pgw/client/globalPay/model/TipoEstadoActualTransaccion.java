
package co.com.ath.pgw.client.globalPay.model;

import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlEnumValue;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Clase Java para TipoEstadoActualTransaccion.
 * 
 * <p>El siguiente fragmento de esquema especifica el contenido que se espera que haya en esta clase.
 * <p>
 * <pre>
 * &lt;simpleType name="TipoEstadoActualTransaccion"&gt;
 *   &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string"&gt;
 *     &lt;enumeration value="Iniciado"/&gt;
 *     &lt;enumeration value="Aprobado"/&gt;
 *     &lt;enumeration value="Rechazado"/&gt;
 *     &lt;enumeration value="Procesando"/&gt;
 *     &lt;enumeration value="Error"/&gt;
 *   &lt;/restriction&gt;
 * &lt;/simpleType&gt;
 * </pre>
 * 
 */
@XmlType(name = "TipoEstadoActualTransaccion")
@XmlEnum
public enum TipoEstadoActualTransaccion {

	@XmlEnumValue("Iniciado")
    INICIADO("Iniciado"),
    @XmlEnumValue("Aprobado")
    APROBADO("Aprobado"),
    @XmlEnumValue("Rechazado")
    RECHAZADO("Rechazado"),
	@XmlEnumValue("Iniciada")
    INICIADA("Iniciada"),
    @XmlEnumValue("Aprobado")
    APROBADA("Aprobada"),
    @XmlEnumValue("Rechazada")
    RECHAZADA("Rechazada"),
    @XmlEnumValue("Procesando")
    PROCESANDO("Procesando"),
    @XmlEnumValue("Error")
    ERROR("Error");
    private final String value;

    TipoEstadoActualTransaccion(String v) {
        value = v;
    }

    public String value() {
        return value;
    }

    public static TipoEstadoActualTransaccion fromValue(String v) {
        for (TipoEstadoActualTransaccion c: TipoEstadoActualTransaccion.values()) {
            if (c.value.equalsIgnoreCase(v)) {
                return c;
            }
        }
        return TipoEstadoActualTransaccion.ERROR;
    }

}
