/*
 * GetHistoricTransactionInDTO
 *  
 * GSI - Integración
 * Creado el: 21/04/2015
 *
 * Copyright (c) A Toda Hora S.A. Todos los derechos reservados
 * 
 * Este software es confidencial y es propietario de ATH, queda prohibido
 * su uso, reproducción y copia de manera parcial o permanente salvo autorización
 * expresa de A Toda Hora S.A o de quién represente sus derechos.
 */
package co.com.ath.pgw.bsn.dto.in;

import java.util.Date;

/**
 * Class description goes here...
 *
 * @author Andrés Méndez Juanias <proveedor_mamendez@ath.com.co> 
 * @version 1.0 21/04/2015
 * @since 1.0
 */
public class GetHistoricTransactionInDTO extends CommonObjectInDTO{

	private String channelSource;
	private String docType;
	private String docNumber;
	private String bankId;
	private Date startDate;
	private Date endDate;
	private String state;
	private String paymentWayId;
	
	
	public GetHistoricTransactionInDTO() {
		super();
	}
	
	
	/**
	 * Método encargado de recuperar el valor del atributo channelSource.
	 * @return El atributo channelSource asociado a la clase.
	 */
	public String getChannelSource() {
		return channelSource;
	}


	/**
	 * Método encargado de actualizar el atributo channelSource.
	 * @param channelSource Nuevo valor para channelSource.
	 */
	public void setChannelSource(String channelSource) {
		this.channelSource = channelSource;
	}

	/**
	 * Método encargado de recuperar el valor del atributo bankId.
	 * @return El atributo bankId asociado a la clase.
	 */
	public String getBankId() {
		return bankId;
	}
	/**
	 * Método encargado de actualizar el atributo bankId.
	 * @param bankId Nuevo valor para bankId.
	 */
	public void setBankId(String bankId) {
		this.bankId = bankId;
	}
	/**
	 * Método encargado de recuperar el valor del atributo startDate.
	 * @return El atributo startDate asociado a la clase.
	 */
	public Date getStartDate() {
		return startDate;
	}
	/**
	 * Método encargado de actualizar el atributo startDate.
	 * @param startDate Nuevo valor para startDate.
	 */
	public void setStartDate(Date startDate) {
		this.startDate = startDate;
	}
	/**
	 * Método encargado de recuperar el valor del atributo endDate.
	 * @return El atributo endDate asociado a la clase.
	 */
	public Date getEndDate() {
		return endDate;
	}
	/**
	 * Método encargado de actualizar el atributo endDate.
	 * @param endDate Nuevo valor para endDate.
	 */
	public void setEndDate(Date endDate) {
		this.endDate = endDate;
	}
	/**
	 * Método encargado de recuperar el valor del atributo state.
	 * @return El atributo state asociado a la clase.
	 */
	public String getState() {
		return state;
	}
	
	/**
	 * Método encargado de actualizar el atributo state.
	 * @param state Nuevo valor para state.
	 */
	public void setState(String state) {
		this.state = state;
	}


	/**
	 * Método encargado de recuperar el valor del atributo docType.
	 * @return El atributo docType asociado a la clase.
	 */
	public String getDocType() {
		return docType;
	}


	/**
	 * Método encargado de actualizar el atributo docType.
	 * @param docType Nuevo valor para docType.
	 */
	public void setDocType(String docType) {
		this.docType = docType;
	}


	/**
	 * Método encargado de recuperar el valor del atributo docNumber.
	 * @return El atributo docNumber asociado a la clase.
	 */
	public String getDocNumber() {
		return docNumber;
	}


	/**
	 * Método encargado de actualizar el atributo docNumber.
	 * @param docNumber Nuevo valor para docNumber.
	 */
	public void setDocNumber(String docNumber) {
		this.docNumber = docNumber;
	}

	/**
	 * Método encargado de recuperar el valor del atributo paymentWayId.
	 * @return El atributo paymentWayId asociado a la clase.
	 */
	public String getPaymentWayId() {
		return paymentWayId;
	}

	/**
	 * Método encargado de actualizar el atributo paymentWayId.
	 * @param paymentWayId Nuevo valor para paymentWayId.
	 */
	public void setPaymentWayId(String paymentWayId) {
		this.paymentWayId = paymentWayId;
	}
	
}
