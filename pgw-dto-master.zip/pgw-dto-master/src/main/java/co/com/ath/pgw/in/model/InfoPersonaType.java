
package co.com.ath.pgw.in.model;


/**
*
* @author camilo.bustamante@sophossolutions.com
* @version 1.0 03 Enero 2019
* @RQ31686 RBM_Integracion_Boton_TC_GlobalPay
* 
*/

/**
 * <p>Clase Java para InfoPersona_Type complex type.
 * 
 * <p>El siguiente fragmento de esquema especifica el contenido que se espera que haya en esta clase.
 * 
 * <pre>
 * &lt;complexType name="InfoPersona_Type">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element ref="{urn://ath.com.co/xsd/common/}Nombres" minOccurs="0"/>
 *         &lt;element ref="{urn://ath.com.co/xsd/common/}Apellidos" minOccurs="0"/>
 *         &lt;element ref="{urn://ath.com.co/xsd/common/}IdPersona" minOccurs="0"/>
 *         &lt;element ref="{urn://ath.com.co/xsd/common/}Telefono" minOccurs="0"/>
 *         &lt;element ref="{urn://ath.com.co/xsd/common/}Correo" minOccurs="0"/>
 *         &lt;element ref="{urn://ath.com.co/xsd/common/}NumeroTelefonoCelular" minOccurs="0"/>
 *         &lt;element ref="{urn://ath.com.co/xsd/common/}Direccion" minOccurs="0"/>
 *         &lt;element ref="{urn://ath.com.co/xsd/common/}Ciudad" minOccurs="0"/>
 *         &lt;element ref="{urn://ath.com.co/xsd/common/}DireccionEntrega" minOccurs="0"/>
 *         &lt;element ref="{urn://ath.com.co/xsd/common/}CiudadEntrega" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
public class InfoPersonaType {

    
    protected String nombres;
    
    
    protected String apellidos;
    
    
    protected IdPersonaType idPersona;
    
    
    protected String telefono;
    
    
    protected String correo;
    
    
    protected String numeroTelefonoCelular;
    
    
    protected String direccion;
    
    
    protected String ciudad;
    
    
    protected String direccionEntrega;
    
    
    protected String ciudadEntrega;

    
	public String getNombres() {
		return nombres;
	}

	public void setNombres(String nombres) {
		this.nombres = nombres;
	}

	public String getApellidos() {
		return apellidos;
	}

	public void setApellidos(String apellidos) {
		this.apellidos = apellidos;
	}

	public IdPersonaType getIdPersona() {
		return idPersona;
	}

	public void setIdPersona(IdPersonaType idPersona) {
		this.idPersona = idPersona;
	}

	public String getTelefono() {
		return telefono;
	}

	public void setTelefono(String telefono) {
		this.telefono = telefono;
	}

	public String getCorreo() {
		return correo;
	}

	public void setCorreo(String correo) {
		this.correo = correo;
	}

	public String getNumeroTelefonoCelular() {
		return numeroTelefonoCelular;
	}

	public void setNumeroTelefonoCelular(String numeroTelefonoCelular) {
		this.numeroTelefonoCelular = numeroTelefonoCelular;
	}

	public String getDireccion() {
		return direccion;
	}

	public void setDireccion(String direccion) {
		this.direccion = direccion;
	}

	public String getCiudad() {
		return ciudad;
	}

	public void setCiudad(String ciudad) {
		this.ciudad = ciudad;
	}

	public String getDireccionEntrega() {
		return direccionEntrega;
	}

	public void setDireccionEntrega(String direccionEntrega) {
		this.direccionEntrega = direccionEntrega;
	}

	public String getCiudadEntrega() {
		return ciudadEntrega;
	}

	public void setCiudadEntrega(String ciudadEntrega) {
		this.ciudadEntrega = ciudadEntrega;
	}

    
}
