
package co.com.ath.pgw.client.rbm.v1;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;


/**
 * 
 * @author Jesus Octavio Avendaño <jesus.avendano@sophossolutions.com> 
 * @version 1.0 17/06/2020
 * @since 1.0
 * 
 * <p>Clase Java para anonymous complex type.
 * 
 * <p>El siguiente fragmento de esquema especifica el contenido que se espera que haya en esta clase.
 * 
 * <pre>
 * &lt;complexType>
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element ref="{urn://ath.com.co/payments/v1/}RBMPaymentAddRq"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "", propOrder = {
    "rbmPaymentAddRq"
})
@XmlRootElement(name = "addRBMPayment")
public class AddRBMPayment {

    @XmlElement(name = "RBMPaymentAddRq", required = true)
    protected RBMPaymentAddRqType rbmPaymentAddRq;

    /**
     * Obtiene el valor de la propiedad rbmPaymentAddRq.
     * 
     * @return
     *     possible object is
     *     {@link RBMPaymentAddRqType }
     *     
     */
    public RBMPaymentAddRqType getRBMPaymentAddRq() {
        return rbmPaymentAddRq;
    }

    /**
     * Define el valor de la propiedad rbmPaymentAddRq.
     * 
     * @param value
     *     allowed object is
     *     {@link RBMPaymentAddRqType }
     *     
     */
    public void setRBMPaymentAddRq(RBMPaymentAddRqType value) {
        this.rbmPaymentAddRq = value;
    }

}
