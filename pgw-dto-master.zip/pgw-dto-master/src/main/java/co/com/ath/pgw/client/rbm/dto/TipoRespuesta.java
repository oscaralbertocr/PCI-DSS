
package co.com.ath.pgw.client.rbm.dto;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;

import com.sun.xml.txw2.annotation.XmlNamespace;

import co.com.ath.pgw.client.rbm.model.TipoCabeceraSolicitud;
import co.com.ath.pgw.client.rbm.model.TipoInfoCompraResp;
import co.com.ath.pgw.client.rbm.model.TipoInfoRespuesta;
import co.com.ath.pgw.client.rbm.model.TipoInfoTerminal;
import co.com.ath.pgw.core.logging.util.XMLUtil;

/**
 * <p>
 * Clase Java para TipoRespuesta complex type.
 * 
 * <p>
 * El siguiente fragmento de esquema especifica el contenido que se espera que
 * haya en esta clase.
 * 
 * <pre>
 * &lt;complexType name="TipoRespuesta"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="cabeceraRespuesta" type="{http://www.rbm.com.co/esb/comercio/compra/}TipoCabeceraSolicitud"/&gt;
 *         &lt;element name="infoRespuesta" type="{http://www.rbm.com.co/esb/}TipoInfoRespuesta"/&gt;
 *         &lt;element name="infoCompraResp" type="{http://www.rbm.com.co/esb/comercio/compra/}TipoInfoCompraResp" minOccurs="0"/&gt;
 *         &lt;element name="idTransaccionAutorizador" type="{http://www.rbm.com.co/esb/}TipoIdTransaccionAutorizador" minOccurs="0"/&gt;
 *         &lt;element name="infoTerminal" type="{http://www.rbm.com.co/esb/comercio/}TipoInfoTerminal" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "compraProcesarRespuesta", propOrder = { "cabeceraRespuesta", "infoRespuesta", "infoCompraResp",
		"idTransaccionAutorizador", "infoTerminal" }, namespace= "http://www.rbm.com.co/esb/comercio/compra/")
public class TipoRespuesta {

	@XmlElement(name="cabeceraRespuesta", namespace= "http://www.rbm.com.co/esb/comercio/compra/")
	protected TipoCabeceraSolicitud cabeceraRespuesta;
	@XmlElement(name = "infoRespuesta", namespace = "http://www.rbm.com.co/esb/comercio/compra/")
	protected TipoInfoRespuesta infoRespuesta;
	@XmlElement(name = "infoCompraResp", namespace = "http://www.rbm.com.co/esb/comercio/compra/")
	protected TipoInfoCompraResp infoCompraResp;
	@XmlElement(name = "idTransaccionAutorizador", namespace = "http://www.rbm.com.co/esb/comercio/compra/")
	protected Long idTransaccionAutorizador;
	@XmlElement(name = "infoTerminal",namespace = "http://www.rbm.com.co/esb/comercio/compra/")
	protected TipoInfoTerminal infoTerminal;

	/**
	 * Obtiene el valor de la propiedad cabeceraRespuesta.
	 * 
	 * @return possible object is {@link TipoCabeceraSolicitud }
	 * 
	 */
	public TipoCabeceraSolicitud getCabeceraRespuesta() {
		return cabeceraRespuesta;
	}

	/**
	 * Define el valor de la propiedad cabeceraRespuesta.
	 * 
	 * @param value allowed object is {@link TipoCabeceraSolicitud }
	 * 
	 */
	public void setCabeceraRespuesta(TipoCabeceraSolicitud value) {
		this.cabeceraRespuesta = value;
	}

	/**
	 * Obtiene el valor de la propiedad infoRespuesta.
	 * 
	 * @return possible object is {@link TipoInfoRespuesta }
	 * 
	 */
	public TipoInfoRespuesta getInfoRespuesta() {
		return infoRespuesta;
	}

	/**
	 * Define el valor de la propiedad infoRespuesta.
	 * 
	 * @param value allowed object is {@link TipoInfoRespuesta }
	 * 
	 */
	public void setInfoRespuesta(TipoInfoRespuesta value) {
		this.infoRespuesta = value;
	}

	/**
	 * Obtiene el valor de la propiedad infoCompraResp.
	 * 
	 * @return possible object is {@link TipoInfoCompraResp }
	 * 
	 */
	public TipoInfoCompraResp getInfoCompraResp() {
		return infoCompraResp;
	}

	/**
	 * Define el valor de la propiedad infoCompraResp.
	 * 
	 * @param value allowed object is {@link TipoInfoCompraResp }
	 * 
	 */
	public void setInfoCompraResp(TipoInfoCompraResp value) {
		this.infoCompraResp = value;
	}

	/**
	 * Obtiene el valor de la propiedad idTransaccionAutorizador.
	 * 
	 * @return possible object is {@link Long }
	 * 
	 */
	public Long getIdTransaccionAutorizador() {
		return idTransaccionAutorizador;
	}

	/**
	 * Define el valor de la propiedad idTransaccionAutorizador.
	 * 
	 * @param value allowed object is {@link Long }
	 * 
	 */
	public void setIdTransaccionAutorizador(Long value) {
		this.idTransaccionAutorizador = value;
	}

	/**
	 * Obtiene el valor de la propiedad infoTerminal.
	 * 
	 * @return possible object is {@link TipoInfoTerminal }
	 * 
	 */
	public TipoInfoTerminal getInfoTerminal() {
		return infoTerminal;
	}

	/**
	 * Define el valor de la propiedad infoTerminal.
	 * 
	 * @param value allowed object is {@link TipoInfoTerminal }
	 * 
	 */
	public void setInfoTerminal(TipoInfoTerminal value) {
		this.infoTerminal = value;
	}
	
	@Override
	public String toString() {
		XMLUtil<TipoRespuesta> requestParser = new XMLUtil<TipoRespuesta>();
		return requestParser.convertObjectToXml(this);
	}

}
