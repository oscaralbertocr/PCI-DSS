
package co.com.ath.pgw.client.globalPay.dto;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;

import co.com.ath.pgw.client.globalPay.model.TipoCabeceraSolicitud;
import co.com.ath.pgw.client.globalPay.model.TipoCredenciales;
import co.com.ath.pgw.client.globalPay.model.TipoInfoCompra;
import co.com.ath.pgw.client.globalPay.model.TipoInfoPersona;
import co.com.ath.pgw.core.logging.util.XMLUtil;


/**
 * <p>Clase Java para anonymous complex type.
 * 
 * <p>El siguiente fragmento de esquema especifica el contenido que se espera que haya en esta clase.
 * 
 * <pre>
 * &lt;complexType&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="credenciales" type="{http://www.rbm.com.co/esb/globalpay/}TipoCredenciales" minOccurs="0"/&gt;
 *         &lt;element name="cabeceraSolicitud" type="{http://www.rbm.com.co/esb/globalpay/}TipoCabeceraSolicitud"/&gt;
 *         &lt;element name="infoPersona" type="{http://www.rbm.com.co/esb/globalpay/}TipoInfoPersona" minOccurs="0"/&gt;
 *         &lt;element name="infoCompra" type="{http://www.rbm.com.co/esb/globalpay/}TipoInfoCompra"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "", propOrder = {
    "credenciales",
    "cabeceraSolicitud",
    "infoPersona",
    "infoCompra"
})
@XmlRootElement(name = "IniciarTransaccionDeCompraSolicitud", namespace="http://www.rbm.com.co/esb/globalpay/")
public class IniciarTransaccionDeCompraSolicitudRequest {

    protected TipoCredenciales credenciales;
    @XmlElement(required = true)
    protected TipoCabeceraSolicitud cabeceraSolicitud;
    protected TipoInfoPersona infoPersona;
    @XmlElement(required = true)
    protected TipoInfoCompra infoCompra;

    /**
     * Obtiene el valor de la propiedad credenciales.
     * 
     * @return
     *     possible object is
     *     {@link TipoCredenciales }
     *     
     */
    public TipoCredenciales getCredenciales() {
        return credenciales;
    }

    /**
     * Define el valor de la propiedad credenciales.
     * 
     * @param value
     *     allowed object is
     *     {@link TipoCredenciales }
     *     
     */
    public void setCredenciales(TipoCredenciales value) {
        this.credenciales = value;
    }

    /**
     * Obtiene el valor de la propiedad cabeceraSolicitud.
     * 
     * @return
     *     possible object is
     *     {@link TipoCabeceraSolicitud }
     *     
     */
    public TipoCabeceraSolicitud getCabeceraSolicitud() {
        return cabeceraSolicitud;
    }

    /**
     * Define el valor de la propiedad cabeceraSolicitud.
     * 
     * @param value
     *     allowed object is
     *     {@link TipoCabeceraSolicitud }
     *     
     */
    public void setCabeceraSolicitud(TipoCabeceraSolicitud value) {
        this.cabeceraSolicitud = value;
    }

    /**
     * Obtiene el valor de la propiedad infoPersona.
     * 
     * @return
     *     possible object is
     *     {@link TipoInfoPersona }
     *     
     */
    public TipoInfoPersona getInfoPersona() {
        return infoPersona;
    }

    /**
     * Define el valor de la propiedad infoPersona.
     * 
     * @param value
     *     allowed object is
     *     {@link TipoInfoPersona }
     *     
     */
    public void setInfoPersona(TipoInfoPersona value) {
        this.infoPersona = value;
    }

    /**
     * Obtiene el valor de la propiedad infoCompra.
     * 
     * @return
     *     possible object is
     *     {@link TipoInfoCompra }
     *     
     */
    public TipoInfoCompra getInfoCompra() {
        return infoCompra;
    }

    /**
     * Define el valor de la propiedad infoCompra.
     * 
     * @param value
     *     allowed object is
     *     {@link TipoInfoCompra }
     *     
     */
    public void setInfoCompra(TipoInfoCompra value) {
        this.infoCompra = value;
    }
    
    @Override
	public String toString() {
		XMLUtil<IniciarTransaccionDeCompraSolicitudRequest> requestParser = new XMLUtil<IniciarTransaccionDeCompraSolicitudRequest>();
		return requestParser.convertObjectToXml(this);
	}

}
