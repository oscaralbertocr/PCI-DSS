
package co.com.ath.pgw.client.globalPay.model;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Clase Java para FaultInfo complex type.
 * 
 * <p>El siguiente fragmento de esquema especifica el contenido que se espera que haya en esta clase.
 * 
 * <pre>
 * &lt;complexType name="FaultInfo"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="faultCode" type="{http://www.w3.org/2001/XMLSchema}int"/&gt;
 *         &lt;element name="faultString" type="{http://www.w3.org/2001/XMLSchema}short"/&gt;
 *         &lt;element name="text" type="{http://www.w3.org/2001/XMLSchema}string"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "FaultInfo", propOrder = {
    "faultCode",
    "faultString",
    "text"
})
public class FaultInfo {

    @XmlElement(required = true, type = Integer.class, nillable = true)
    protected Integer faultCode;
    @XmlElement(required = true, type = Short.class, nillable = true)
    protected Short faultString;
    @XmlElement(required = true, nillable = true)
    protected String text;

    /**
     * Obtiene el valor de la propiedad faultCode.
     * 
     * @return
     *     possible object is
     *     {@link Integer }
     *     
     */
    public Integer getFaultCode() {
        return faultCode;
    }

    /**
     * Define el valor de la propiedad faultCode.
     * 
     * @param value
     *     allowed object is
     *     {@link Integer }
     *     
     */
    public void setFaultCode(Integer value) {
        this.faultCode = value;
    }

    /**
     * Obtiene el valor de la propiedad faultString.
     * 
     * @return
     *     possible object is
     *     {@link Short }
     *     
     */
    public Short getFaultString() {
        return faultString;
    }

    /**
     * Define el valor de la propiedad faultString.
     * 
     * @param value
     *     allowed object is
     *     {@link Short }
     *     
     */
    public void setFaultString(Short value) {
        this.faultString = value;
    }

    /**
     * Obtiene el valor de la propiedad text.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getText() {
        return text;
    }

    /**
     * Define el valor de la propiedad text.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setText(String value) {
        this.text = value;
    }

}
