
package co.com.ath.pgw.bsn.globalPay.model;

import java.util.ArrayList;
import java.util.List;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;

import co.com.ath.pgw.core.logging.util.XMLUtil;


/**
 * <p>Clase Java para CoreInitTransactionRbmRs_Type complex type.
 * 
 * <p>El siguiente fragmento de esquema especifica el contenido que se espera que haya en esta clase.
 * 
 * <pre>
 * &lt;complexType name="CoreInitTransactionRbmRs_Type">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element ref="{urn://ath.com.co/xsd/common/}Status"/>
 *         &lt;element ref="{urn://ath.com.co/xsd/common/}RqUID"/>
 *         &lt;element ref="{urn://ath.com.co/xsd/common/}PmtId" minOccurs="0"/>
 *         &lt;element ref="{urn://ath.com.co/xsd/common/}TransactionStatus" minOccurs="0"/>
 *         &lt;element ref="{urn://ath.com.co/xsd/common/}TrazabilityCode" minOccurs="0"/>
 *         &lt;element ref="{urn://ath.com.co/xsd/common/}Token" minOccurs="0"/>
 *         &lt;element ref="{urn://ath.com.co/xsd/common/}Reference" maxOccurs="unbounded" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "CoreInitTransactionRbmRs_Type", namespace = "urn://ath.com.co/payments/v1/", propOrder = {
    "status",
    "rqUID",
    "pmtId",
    "transactionStatus",
    "trazabilityCode",
    "token",
    "reference"
})
@XmlRootElement
public class CoreInitTransactionRbmRsType  implements Cloneable {

    @XmlElement(name = "Status", namespace = "urn://ath.com.co/xsd/common/", required = true)
    protected StatusType status;
    @XmlElement(name = "RqUID", namespace = "urn://ath.com.co/xsd/common/")
    protected long rqUID;
    @XmlElement(name = "PmtId", namespace = "urn://ath.com.co/xsd/common/")
    protected String pmtId;
    @XmlElement(name = "TransactionStatus", namespace = "urn://ath.com.co/xsd/common/")
    protected TransactionStatusType transactionStatus;
    @XmlElement(name = "TrazabilityCode", namespace = "urn://ath.com.co/xsd/common/")
    protected String trazabilityCode;
    @XmlElement(name = "Token", namespace = "urn://ath.com.co/xsd/common/")
    protected String token;
    @XmlElement(name = "Reference", namespace = "urn://ath.com.co/xsd/common/")
    protected List<ReferenceType> reference;

    /**
     * Obtiene el valor de la propiedad status.
     * 
     * @return
     *     possible object is
     *     {@link StatusType }
     *     
     */
    public StatusType getStatus() {
        return status;
    }

    /**
     * Define el valor de la propiedad status.
     * 
     * @param value
     *     allowed object is
     *     {@link StatusType }
     *     
     */
    public void setStatus(StatusType value) {
        this.status = value;
    }

    /**
     * Obtiene el valor de la propiedad rqUID.
     * 
     */
    public long getRqUID() {
        return rqUID;
    }

    /**
     * Define el valor de la propiedad rqUID.
     * 
     */
    public void setRqUID(long value) {
        this.rqUID = value;
    }

    /**
     * Obtiene el valor de la propiedad pmtId.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPmtId() {
        return pmtId;
    }

    /**
     * Define el valor de la propiedad pmtId.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPmtId(String value) {
        this.pmtId = value;
    }

    /**
     * Obtiene el valor de la propiedad transactionStatus.
     * 
     * @return
     *     possible object is
     *     {@link TransactionStatusType }
     *     
     */
    public TransactionStatusType getTransactionStatus() {
        return transactionStatus;
    }

    /**
     * Define el valor de la propiedad transactionStatus.
     * 
     * @param value
     *     allowed object is
     *     {@link TransactionStatusType }
     *     
     */
    public void setTransactionStatus(TransactionStatusType value) {
        this.transactionStatus = value;
    }

    /**
     * Obtiene el valor de la propiedad trazabilityCode.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getTrazabilityCode() {
        return trazabilityCode;
    }

    /**
     * Define el valor de la propiedad trazabilityCode.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setTrazabilityCode(String value) {
        this.trazabilityCode = value;
    }

    /**
     * Obtiene el valor de la propiedad token.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getToken() {
        return token;
    }

    /**
     * Define el valor de la propiedad token.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setToken(String value) {
        this.token = value;
    }

    /**
     * Gets the value of the reference property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the reference property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getReference().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link ReferenceType }
     * 
     * 
     */
    public List<ReferenceType> getReference() {
        if (reference == null) {
            reference = new ArrayList<ReferenceType>();
        }
        return this.reference;
    }
    
	@Override
	public String toString() {
		XMLUtil<CoreInitTransactionRbmRsType> requestParser = new XMLUtil<CoreInitTransactionRbmRsType>();
		return requestParser.convertObjectToXml(this);
	}

}
