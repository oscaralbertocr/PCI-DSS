package co.com.ath.pgw.client.bank.info;

import javax.xml.datatype.XMLGregorianCalendar;

import co.com.ath.pgw.in.model.BankInfoType;
import co.com.ath.pgw.in.model.UserIdType;

public class MsgRqHdrType {

	protected ClientAppType clientApp;

	protected String channel;

	protected BankInfoType bankInfo;

	protected XMLGregorianCalendar clientDt;

	protected String ipAddr;

	protected String sessKey;

	protected UserIdType userId;

	protected String keyAcctId;

	protected boolean reverse;

	protected String language;

	protected XMLGregorianCalendar nextDay;

	/**
	 * Obtiene el valor de la propiedad clientApp.
	 * 
	 * @return possible object is {@link ClientAppType }
	 * 
	 */
	public ClientAppType getClientApp() {
		return clientApp;
	}

	/**
	 * Define el valor de la propiedad clientApp.
	 * 
	 * @param value allowed object is {@link ClientAppType }
	 * 
	 */
	public void setClientApp(ClientAppType value) {
		this.clientApp = value;
	}

	/**
	 * Obtiene el valor de la propiedad channel.
	 * 
	 * @return possible object is {@link String }
	 * 
	 */
	public String getChannel() {
		return channel;
	}

	/**
	 * Define el valor de la propiedad channel.
	 * 
	 * @param value allowed object is {@link String }
	 * 
	 */
	public void setChannel(String value) {
		this.channel = value;
	}

	/**
	 * Obtiene el valor de la propiedad bankInfo.
	 * 
	 * @return possible object is {@link BankInfoType }
	 * 
	 */
	public BankInfoType getBankInfo() {
		return bankInfo;
	}

	/**
	 * Define el valor de la propiedad bankInfo.
	 * 
	 * @param value allowed object is {@link BankInfoType }
	 * 
	 */
	public void setBankInfo(BankInfoType value) {
		this.bankInfo = value;
	}

	/**
	 * Obtiene el valor de la propiedad clientDt.
	 * 
	 * @return possible object is {@link XMLGregorianCalendar }
	 * 
	 */
	public XMLGregorianCalendar getClientDt() {
		return clientDt;
	}

	/**
	 * Define el valor de la propiedad clientDt.
	 * 
	 * @param value allowed object is {@link XMLGregorianCalendar }
	 * 
	 */
	public void setClientDt(XMLGregorianCalendar value) {
		this.clientDt = value;
	}

	/**
	 * Obtiene el valor de la propiedad ipAddr.
	 * 
	 * @return possible object is {@link String }
	 * 
	 */
	public String getIPAddr() {
		return ipAddr;
	}

	/**
	 * Define el valor de la propiedad ipAddr.
	 * 
	 * @param value allowed object is {@link String }
	 * 
	 */
	public void setIPAddr(String value) {
		this.ipAddr = value;
	}

	/**
	 * Obtiene el valor de la propiedad sessKey.
	 * 
	 * @return possible object is {@link String }
	 * 
	 */
	public String getSessKey() {
		return sessKey;
	}

	/**
	 * Define el valor de la propiedad sessKey.
	 * 
	 * @param value allowed object is {@link String }
	 * 
	 */
	public void setSessKey(String value) {
		this.sessKey = value;
	}

	/**
	 * Obtiene el valor de la propiedad userId.
	 * 
	 * @return possible object is {@link UserIdType }
	 * 
	 */
	public UserIdType getUserId() {
		return userId;
	}

	/**
	 * Define el valor de la propiedad userId.
	 * 
	 * @param value allowed object is {@link UserIdType }
	 * 
	 */
	public void setUserId(UserIdType value) {
		this.userId = value;
	}

	/**
	 * Obtiene el valor de la propiedad keyAcctId.
	 * 
	 * @return possible object is {@link String }
	 * 
	 */
	public String getKeyAcctId() {
		return keyAcctId;
	}

	/**
	 * Define el valor de la propiedad keyAcctId.
	 * 
	 * @param value allowed object is {@link String }
	 * 
	 */
	public void setKeyAcctId(String value) {
		this.keyAcctId = value;
	}

	/**
	 * Obtiene el valor de la propiedad reverse.
	 * 
	 */
	public boolean isReverse() {
		return reverse;
	}

	/**
	 * Define el valor de la propiedad reverse.
	 * 
	 */
	public void setReverse(boolean value) {
		this.reverse = value;
	}

	/**
	 * Obtiene el valor de la propiedad language.
	 * 
	 * @return possible object is {@link String }
	 * 
	 */
	public String getLanguage() {
		return language;
	}

	/**
	 * Define el valor de la propiedad language.
	 * 
	 * @param value allowed object is {@link String }
	 * 
	 */
	public void setLanguage(String value) {
		this.language = value;
	}

	/**
	 * Obtiene el valor de la propiedad nextDay.
	 * 
	 * @return possible object is {@link XMLGregorianCalendar }
	 * 
	 */
	public XMLGregorianCalendar getNextDay() {
		return nextDay;
	}

	/**
	 * Define el valor de la propiedad nextDay.
	 * 
	 * @param value allowed object is {@link XMLGregorianCalendar }
	 * 
	 */
	public void setNextDay(XMLGregorianCalendar value) {
		this.nextDay = value;
	}

}