
package co.com.ath.pgw.rest.dto;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonProperty;

public class GovIssueIdent implements Serializable
{
	@JsonProperty("GovIssueIdentType")
    private String govIssueIdentType;
	
	@JsonProperty("IdentSerialNum")
    private String identSerialNum;
	
    private final static long serialVersionUID = 4124988563701526371L;

    public String getGovIssueIdentType() {
        return govIssueIdentType;
    }

    public void setGovIssueIdentType(String govIssueIdentType) {
        this.govIssueIdentType = govIssueIdentType;
    }

    public String getIdentSerialNum() {
        return identSerialNum;
    }

    public void setIdentSerialNum(String identSerialNum) {
        this.identSerialNum = identSerialNum;
    }

}
