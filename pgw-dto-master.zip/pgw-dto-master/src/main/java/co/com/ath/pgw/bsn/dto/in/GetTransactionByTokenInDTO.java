/*
 * GetTransactionByTokenInDTO
 *  
 * GSI - Integración
 * Creado el: 20/09/2014
 *
 * Copyright (c) A Toda Hora S.A. Todos los derechos reservados
 * 
 * Este software es confidencial y es propietario de ATH, queda prohibido
 * su uso, reproducción y copia de manera parcial o permanente salvo autorización
 * expresa de A Toda Hora S.A o de quién represente sus derechos.
 */
package co.com.ath.pgw.bsn.dto.in;

import co.com.ath.pgw.bsn.model.bo.TokenBO;
import co.com.ath.pgw.core.logging.util.XMLUtil;



/**
 * DTO de entrada con la información para la operación GetTransactionByToken.
 *
 * @version 0.0.0 22/09/2014
 * @author Andrés Méndez Juanias <proveedor_mamendez@ath.com.co>
 */

public class GetTransactionByTokenInDTO extends CommonObjectInDTO {

    private TokenBO tokenBO;
    
    private String queryType;
    
	public GetTransactionByTokenInDTO(){
	}

	@Override
	public String toString() {
		XMLUtil<GetTransactionByTokenInDTO> requestParser = new XMLUtil<GetTransactionByTokenInDTO>();
		return requestParser.convertObjectToXml(this);
	}

    public TokenBO getTokenBO() {
        return tokenBO;
    }

    public void setTokenBO(TokenBO tokenBO) {
        this.tokenBO = tokenBO;
    }

	/**
	 * Método encargado de recuperar el valor del atributo queryType.
	 * @return El atributo queryType asociado a la clase.
	 */
	public String getQueryType() {
		return queryType;
	}

	/**
	 * Método encargado de actualizar el atributo queryType.
	 * @param queryType Nuevo valor para queryType.
	 */
	public void setQueryType(String queryType) {
		this.queryType = queryType;
	}

}