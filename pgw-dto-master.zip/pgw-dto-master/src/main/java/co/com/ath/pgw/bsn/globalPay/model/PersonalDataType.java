
package co.com.ath.pgw.bsn.globalPay.model;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlSchemaType;
import javax.xml.bind.annotation.XmlType;
import javax.xml.datatype.XMLGregorianCalendar;


/**
 * <p>Clase Java para PersonalData_Type complex type.
 * 
 * <p>El siguiente fragmento de esquema especifica el contenido que se espera que haya en esta clase.
 * 
 * <pre>
 * &lt;complexType name="PersonalData_Type">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element ref="{urn://ath.com.co/xsd/common/}CustName"/>
 *         &lt;element ref="{urn://ath.com.co/xsd/common/}CustIdType" minOccurs="0"/>
 *         &lt;element ref="{urn://ath.com.co/xsd/common/}CustIdNum" minOccurs="0"/>
 *         &lt;element ref="{urn://ath.com.co/xsd/common/}Gender" minOccurs="0"/>
 *         &lt;element ref="{urn://ath.com.co/xsd/common/}BirthDt" minOccurs="0"/>
 *         &lt;element ref="{urn://ath.com.co/xsd/common/}StateProvName" minOccurs="0"/>
 *         &lt;element ref="{urn://ath.com.co/xsd/common/}CountryId" minOccurs="0"/>
 *         &lt;element ref="{urn://ath.com.co/xsd/common/}CountryName" minOccurs="0"/>
 *         &lt;element ref="{urn://ath.com.co/xsd/common/}Address" minOccurs="0"/>
 *         &lt;element ref="{urn://ath.com.co/xsd/common/}CityId" minOccurs="0"/>
 *         &lt;element ref="{urn://ath.com.co/xsd/common/}DeliveryAddress" minOccurs="0"/>
 *         &lt;element ref="{urn://ath.com.co/xsd/common/}DeliveryCity" minOccurs="0"/>
 *         &lt;element ref="{urn://ath.com.co/xsd/common/}EmailAddr" minOccurs="0"/>
 *         &lt;element ref="{urn://ath.com.co/xsd/common/}Phone" minOccurs="0"/>
 *         &lt;element ref="{urn://ath.com.co/xsd/common/}CellPhone" minOccurs="0"/>
 *         &lt;element ref="{urn://ath.com.co/xsd/common/}MaritalStatus" minOccurs="0"/>
 *         &lt;element ref="{urn://ath.com.co/xsd/common/}IssDt" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "PersonalData_Type", propOrder = {
    "custName",
    "custIdType",
    "custIdNum",
    "gender",
    "birthDt",
    "stateProvName",
    "countryId",
    "countryName",
    "address",
    "cityId",
    "deliveryAddress",
    "deliveryCity",
    "emailAddr",
    "phone",
    "cellPhone",
    "maritalStatus",
    "issDt"
})
public class PersonalDataType {

    @XmlElement(name = "CustName", required = true)
    protected CustNameType custName;
    @XmlElement(name = "CustIdType")
    protected String custIdType;
    @XmlElement(name = "CustIdNum")
    protected String custIdNum;
    @XmlElement(name = "Gender")
    protected String gender;
    @XmlElement(name = "BirthDt")
    @XmlSchemaType(name = "dateTime")
    protected XMLGregorianCalendar birthDt;
    @XmlElement(name = "StateProvName")
    protected String stateProvName;
    @XmlElement(name = "CountryId")
    protected String countryId;
    @XmlElement(name = "CountryName")
    protected String countryName;
    @XmlElement(name = "Address")
    protected String address;
    @XmlElement(name = "CityId")
    protected String cityId;
    @XmlElement(name = "DeliveryAddress")
    protected String deliveryAddress;
    @XmlElement(name = "DeliveryCity")
    protected String deliveryCity;
    @XmlElement(name = "EmailAddr")
    protected String emailAddr;
    @XmlElement(name = "Phone")
    protected String phone;
    @XmlElement(name = "CellPhone")
    protected String cellPhone;
    @XmlElement(name = "MaritalStatus")
    protected String maritalStatus;
    @XmlElement(name = "IssDt")
    @XmlSchemaType(name = "dateTime")
    protected XMLGregorianCalendar issDt;

    /**
     * Obtiene el valor de la propiedad custName.
     * 
     * @return
     *     possible object is
     *     {@link CustNameType }
     *     
     */
    public CustNameType getCustName() {
        return custName;
    }

    /**
     * Define el valor de la propiedad custName.
     * 
     * @param value
     *     allowed object is
     *     {@link CustNameType }
     *     
     */
    public void setCustName(CustNameType value) {
        this.custName = value;
    }

    /**
     * Obtiene el valor de la propiedad custIdType.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCustIdType() {
        return custIdType;
    }

    /**
     * Define el valor de la propiedad custIdType.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCustIdType(String value) {
        this.custIdType = value;
    }

    /**
     * Obtiene el valor de la propiedad custIdNum.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCustIdNum() {
        return custIdNum;
    }

    /**
     * Define el valor de la propiedad custIdNum.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCustIdNum(String value) {
        this.custIdNum = value;
    }

    /**
     * Obtiene el valor de la propiedad gender.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getGender() {
        return gender;
    }

    /**
     * Define el valor de la propiedad gender.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setGender(String value) {
        this.gender = value;
    }

    /**
     * Obtiene el valor de la propiedad birthDt.
     * 
     * @return
     *     possible object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public XMLGregorianCalendar getBirthDt() {
        return birthDt;
    }

    /**
     * Define el valor de la propiedad birthDt.
     * 
     * @param value
     *     allowed object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public void setBirthDt(XMLGregorianCalendar value) {
        this.birthDt = value;
    }

    /**
     * Obtiene el valor de la propiedad stateProvName.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getStateProvName() {
        return stateProvName;
    }

    /**
     * Define el valor de la propiedad stateProvName.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setStateProvName(String value) {
        this.stateProvName = value;
    }

    /**
     * Obtiene el valor de la propiedad countryId.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCountryId() {
        return countryId;
    }

    /**
     * Define el valor de la propiedad countryId.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCountryId(String value) {
        this.countryId = value;
    }

    /**
     * Obtiene el valor de la propiedad countryName.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCountryName() {
        return countryName;
    }

    /**
     * Define el valor de la propiedad countryName.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCountryName(String value) {
        this.countryName = value;
    }

    /**
     * Obtiene el valor de la propiedad address.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getAddress() {
        return address;
    }

    /**
     * Define el valor de la propiedad address.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setAddress(String value) {
        this.address = value;
    }

    /**
     * Obtiene el valor de la propiedad cityId.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCityId() {
        return cityId;
    }

    /**
     * Define el valor de la propiedad cityId.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCityId(String value) {
        this.cityId = value;
    }

    /**
     * Obtiene el valor de la propiedad deliveryAddress.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDeliveryAddress() {
        return deliveryAddress;
    }

    /**
     * Define el valor de la propiedad deliveryAddress.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDeliveryAddress(String value) {
        this.deliveryAddress = value;
    }

    /**
     * Obtiene el valor de la propiedad deliveryCity.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDeliveryCity() {
        return deliveryCity;
    }

    /**
     * Define el valor de la propiedad deliveryCity.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDeliveryCity(String value) {
        this.deliveryCity = value;
    }

    /**
     * Obtiene el valor de la propiedad emailAddr.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getEmailAddr() {
        return emailAddr;
    }

    /**
     * Define el valor de la propiedad emailAddr.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setEmailAddr(String value) {
        this.emailAddr = value;
    }

    /**
     * Obtiene el valor de la propiedad phone.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPhone() {
        return phone;
    }

    /**
     * Define el valor de la propiedad phone.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPhone(String value) {
        this.phone = value;
    }

    /**
     * Obtiene el valor de la propiedad cellPhone.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCellPhone() {
        return cellPhone;
    }

    /**
     * Define el valor de la propiedad cellPhone.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCellPhone(String value) {
        this.cellPhone = value;
    }

    /**
     * Obtiene el valor de la propiedad maritalStatus.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getMaritalStatus() {
        return maritalStatus;
    }

    /**
     * Define el valor de la propiedad maritalStatus.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setMaritalStatus(String value) {
        this.maritalStatus = value;
    }

    /**
     * Obtiene el valor de la propiedad issDt.
     * 
     * @return
     *     possible object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public XMLGregorianCalendar getIssDt() {
        return issDt;
    }

    /**
     * Define el valor de la propiedad issDt.
     * 
     * @param value
     *     allowed object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public void setIssDt(XMLGregorianCalendar value) {
        this.issDt = value;
    }

}
