
package co.com.ath.pgw.rest.dto;

import java.io.Serializable;

import javax.xml.datatype.XMLGregorianCalendar;

import com.fasterxml.jackson.annotation.JsonProperty;

public class PersonInfo implements Serializable
{

    @JsonProperty("PersonName")
    private PersonName personName;
    
    @JsonProperty("ContactInfo")
    private ContactInfo contactInfo;
    
    @JsonProperty("GovIssueIdent")
    private GovIssueIdent govIssueIdent;
    
    @JsonProperty("BirthDt")
    private XMLGregorianCalendar birthDt;
    
    @JsonProperty("Gender")
    private String gender;
    
    private final static long serialVersionUID = -3627699914877345394L;

    
    public PersonName getPersonName() {
        return personName;
    }

    public void setPersonName(PersonName personName) {
        this.personName = personName;
    }

    public ContactInfo getContactInfo() {
        return contactInfo;
    }
    
    public void setContactInfo(ContactInfo contactInfo) {
        this.contactInfo = contactInfo;
    }
    public GovIssueIdent getGovIssueIdent() {
        return govIssueIdent;
    }

    public void setGovIssueIdent(GovIssueIdent govIssueIdent) {
        this.govIssueIdent = govIssueIdent;
    }

    public XMLGregorianCalendar getBirthDt() {
        return birthDt;
    }

    public void setBirthDt(XMLGregorianCalendar birthDt) {
        this.birthDt = birthDt;
    }
        
    public String getGender() {
        return gender;
    }
    
    public void setGender(String gender) {
        this.gender = gender;
    }
}