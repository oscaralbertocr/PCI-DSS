/*
 * ReconciledTransactionBO
 *  
 * GSI - Integración
 * Creado el: 28/08/2014
 *
 * Copyright (c) A Toda Hora S.A. Todos los derechos reservados
 * 
 * Este software es confidencial y es propietario de ATH, queda prohibido
 * su uso, reproducción y copia de manera parcial o permanente salvo autorización
 * expresa de A Toda Hora S.A o de quién represente sus derechos.
 */
package co.com.ath.pgw.bsn.model.bo;

import java.sql.Timestamp;
import java.util.Date;

/**
 * Representa una transacción conciliada en la Pasarela de Pagos.
 * Esta entidad pertenece al modelo persistente.
 * 
 * @author proveedor_japiza
 * @version 1.0 29 Ago 2014
 * @since 1.0
 * 
 */
public class ReconciledTransactionBO {

	/** id Atributo de la clase. */
	private long id;

	//uni-directional many-to-one association to Transactions
	/** transaccione Atributo de la clase. */
	private TransactionBO transactionId;
	
	/** status Atributo de la clase. */
	private String status;
	
	/** red Atributo de la clase. */
	private String red;

	/** reconciledDate Atributo de la clase. */
	private Timestamp reconciledDate;	

	/** rowCreationDate Atributo de la clase. */
	private Date rowCreationDate;

	/** rowLastUpdate Atributo de la clase. */
	private Date rowLastUpdate;
	
	/** rowDeleted Atributo de la clase. */
	private boolean rowDeleted;	

	public ReconciledTransactionBO() {}

	/**
	 * Método encargado de recuperar el valor del atributo id.
	 * @return El atributo id asociado a la clase.
	 */
	public long getId() {
		return id;
	}

	/**
	 * Método encargado de actualizar el atributo ReconciledTransactions.java.
	 * @param id Nuevo valor para id.
	 */
	public void setId(long id) {
		this.id = id;
	}

	/**
	 * Método encargado de recuperar el valor del atributo transactionId.
	 * @return El atributo transactionId asociado a la clase.
	 */
	public TransactionBO getTransactionId() {
		return transactionId;
	}

	/**
	 * Método encargado de actualizar el atributo ReconciledTransactions.java.
	 * @param transactionId Nuevo valor para transactionId.
	 */
	public void setTransactionId(TransactionBO transactionId) {
		this.transactionId = transactionId;
	}

	/**
	 * Método encargado de recuperar el valor del atributo status.
	 * @return El atributo status asociado a la clase.
	 */
	public String getStatus() {
		return status;
	}

	/**
	 * Método encargado de actualizar el atributo ReconciledTransactions.java.
	 * @param status Nuevo valor para status.
	 */
	public void setStatus(String status) {
		this.status = status;
	}

	/**
	 * Método encargado de recuperar el valor del atributo red.
	 * @return El atributo red asociado a la clase.
	 */
	public String getRed() {
		return red;
	}

	/**
	 * Método encargado de actualizar el atributo ReconciledTransactions.java.
	 * @param red Nuevo valor para red.
	 */
	public void setRed(String red) {
		this.red = red;
	}

	/**
	 * Método encargado de recuperar el valor del atributo reconciledDate.
	 * @return El atributo reconciledDate asociado a la clase.
	 */
	public Timestamp getReconciledDate() {
		return reconciledDate;
	}

	/**
	 * Método encargado de actualizar el atributo ReconciledTransactions.java.
	 * @param reconciledDate Nuevo valor para reconciledDate.
	 */
	public void setReconciledDate(Timestamp reconciledDate) {
		this.reconciledDate = reconciledDate;
	}

	/**
	 * Método encargado de recuperar el valor del atributo rowCreationDate.
	 * @return El atributo rowCreationDate asociado a la clase.
	 */
	public Date getRowCreationDate() {
		return rowCreationDate;
	}

	/**
	 * Método encargado de actualizar el atributo ReconciledTransactions.java.
	 * @param rowCreationDate Nuevo valor para rowCreationDate.
	 */
	public void setRowCreationDate(Date rowCreationDate) {
		this.rowCreationDate = rowCreationDate;
	}

	/**
	 * Método encargado de recuperar el valor del atributo rowLastUpdate.
	 * @return El atributo rowLastUpdate asociado a la clase.
	 */
	public Date getRowLastUpdate() {
		return rowLastUpdate;
	}

	/**
	 * Método encargado de actualizar el atributo ReconciledTransactions.java.
	 * @param rowLastUpdate Nuevo valor para rowLastUpdate.
	 */
	public void setRowLastUpdate(Date rowLastUpdate) {
		this.rowLastUpdate = rowLastUpdate;
	}

	/**
	 * Método encargado de recuperar el valor del atributo rowDeleted.
	 * @return El atributo rowDeleted asociado a la clase.
	 */
	public boolean isRowDeleted() {
		return rowDeleted;
	}

	/**
	 * Método encargado de actualizar el atributo ReconciledTransactions.java.
	 * @param rowDeleted Nuevo valor para rowDeleted.
	 */
	public void setRowDeleted(boolean rowDeleted) {
		this.rowDeleted = rowDeleted;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + (int) (id ^ (id >>> 32));
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		ReconciledTransactionBO other = (ReconciledTransactionBO) obj;
		if (id != other.id)
			return false;
		return true;
	}

}