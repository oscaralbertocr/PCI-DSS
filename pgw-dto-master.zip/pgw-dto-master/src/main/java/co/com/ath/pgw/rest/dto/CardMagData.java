package co.com.ath.pgw.rest.dto;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonProperty;

public class CardMagData implements Serializable {

	@JsonProperty("MagData1")
	private String magData1;
	
	@JsonProperty("MagData2")
	private String magData2;
	
	@JsonProperty("MagData3")
	private String magData3;
	
	private static final long serialVersionUID = -7237659973436812514L;

	public String getMagData1() {
		return magData1;
	}

	public void setMagData1(String magData1) {
		this.magData1 = magData1;
	}

	public String getMagData2() {
		return magData2;
	}

	public void setMagData2(String magData2) {
		this.magData2 = magData2;
	}

	public String getMagData3() {
		return magData3;
	}

	public void setMagData3(String magData3) {
		this.magData3 = magData3;
	}
	
}