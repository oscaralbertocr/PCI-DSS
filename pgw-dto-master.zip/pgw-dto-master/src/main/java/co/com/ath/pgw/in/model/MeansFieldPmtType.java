package co.com.ath.pgw.in.model;

import java.util.ArrayList;
import java.util.List;


public class MeansFieldPmtType {

   
    protected List<MeansPmtType> meansPmt;

    /**
     * Gets the value of the meansPmt property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the meansPmt property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getMeansPmt().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link MeansPmtType }
     * 
     * 
     */
    public List<MeansPmtType> getMeansPmt() {
        if (meansPmt == null) {
            meansPmt = new ArrayList<MeansPmtType>();
        }
        return this.meansPmt;
    }

}
