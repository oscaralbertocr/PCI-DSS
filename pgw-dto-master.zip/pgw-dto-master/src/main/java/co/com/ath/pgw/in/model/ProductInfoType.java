package co.com.ath.pgw.in.model;

import java.util.ArrayList;
import java.util.List;


public class ProductInfoType {

    
    protected ProductIdType productId;
   
    protected String type;
    
    protected List<CurrencyAmtType> currencyAmt;

    /**
     * Obtiene el valor de la propiedad productId.
     * 
     * @return
     *     possible object is
     *     {@link ProductIdType }
     *     
     */
    public ProductIdType getProductId() {
        return productId;
    }

    /**
     * Define el valor de la propiedad productId.
     * 
     * @param value
     *     allowed object is
     *     {@link ProductIdType }
     *     
     */
    public void setProductId(ProductIdType value) {
        this.productId = value;
    }

    /**
     * Obtiene el valor de la propiedad type.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getType() {
        return type;
    }

    /**
     * Define el valor de la propiedad type.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setType(String value) {
        this.type = value;
    }

    /**
     * Gets the value of the currencyAmt property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the currencyAmt property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getCurrencyAmt().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link CurrencyAmtType }
     * 
     * 
     */
    public List<CurrencyAmtType> getCurrencyAmt() {
        if (currencyAmt == null) {
            currencyAmt = new ArrayList<CurrencyAmtType>();
        }
        return this.currencyAmt;
    }

}
