/*
 * AgreementSynchronizationInDTO
 *  
 * GSI - Recaudos
 * Creado el: 05/11/2015
 *
 * Copyright (c) A Toda Hora S.A. Todos los derechos reservados
 * 
 * Este software es confidencial y es propietario de ATH, queda prohibido
 * su uso, reproducción y copia de manera parcial o permanente salvo autorización
 * expresa de A Toda Hora S.A o de quién represente sus derechos.
 */
package co.com.ath.pgw.bsn.dto.in;

import co.com.ath.pgw.core.logging.util.XMLUtil;
import co.com.ath.pgw.in.dto.AgreementSynchronizationRqType;

/**
 * DTO de entrada con la información para la operación AgreementSynchronization.
 *
 * @version 0.0.0 05/11/2015
 * @author <proveedor_edrobles@ath.com.co>
 */
public class AgreementSynchronizationInDTO extends CommonObjectInDTO {
	
	
	private AgreementSynchronizationRqType agreementSynchronizationRqType;
	
	public AgreementSynchronizationInDTO() {
	}
	
	public AgreementSynchronizationRqType getAgreementSynchronizationRqType() {
		return agreementSynchronizationRqType;
	}
	
	public void setAgreementSynchronizationRqType(AgreementSynchronizationRqType agreementSynchronizationRqType) {
		this.agreementSynchronizationRqType = agreementSynchronizationRqType;
	}
	
	@Override
	public String toString() {
		XMLUtil<AgreementSynchronizationInDTO> requestParser = new XMLUtil<AgreementSynchronizationInDTO>();
		return requestParser.convertObjectToXml(this);
	}
    
}
