
package co.com.ath.pgw.rest.response.dto;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonProperty;

import co.com.ath.pgw.core.logging.util.XMLUtil;
import co.com.ath.pgw.rest.dto.CustPayeeInfo;
import co.com.ath.pgw.rest.dto.PmtStatus;
import co.com.ath.pgw.rest.dto.Status;

public class TransactionStatusResponse implements Serializable {

	@JsonProperty("PmtStatus")
	private PmtStatus pmtStatus;
	@JsonProperty("CustPayeeInfo")
	private CustPayeeInfo custPayeeInfo;
	private static final long serialVersionUID = -1612180105798362668L;

	public PmtStatus getPmtStatus() {
		return pmtStatus;
	}

	public void setPmtStatus(PmtStatus pmtStatus) {
		this.pmtStatus = pmtStatus;
	}

	public CustPayeeInfo getCustPayeeInfo() {
		return custPayeeInfo;
	}

	public void setCustPayeeInfo(CustPayeeInfo custPayeeInfo) {
		this.custPayeeInfo = custPayeeInfo;
	}

	@Override
	public String toString() {
		XMLUtil<TransactionStatusResponse> util = new XMLUtil<TransactionStatusResponse>();
		return util.convertObjectToJson(this);
	}

}
