package co.com.ath.pgw.rest.response.dto;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonProperty;

import co.com.ath.pgw.core.logging.util.XMLUtil;
import co.com.ath.pgw.rest.dto.PmtStatus;
import co.com.ath.pgw.rest.dto.RefInfo;

public class PSETransactionResponse implements Serializable {

	@JsonProperty("PmtStatus")
	private PmtStatus pmtStatus;
	@JsonProperty("RefInfo")
	private List<RefInfo> refInfo = null;
	private static final long serialVersionUID = 4329154959520459372L;

	public PmtStatus getPmtStatus() {
		return pmtStatus;
	}

	public void setPmtStatus(PmtStatus pmtStatus) {
		this.pmtStatus = pmtStatus;
	}

	public List<RefInfo> getRefInfo() {
		if (refInfo == null) {
			refInfo = new ArrayList<RefInfo>();
        }
		return refInfo;
	}

	public void setRefInfo(List<RefInfo> refInfo) {
		this.refInfo = refInfo;
	}

	@Override
	public String toString() {
		XMLUtil<PSETransactionResponse> util = new XMLUtil<PSETransactionResponse>();
		return util.convertObjectToJson(this);
	}

}