
package co.com.ath.pgw.client.bank.info.xsd.ifx;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlSeeAlso;
import javax.xml.bind.annotation.XmlType;

import co.com.ath.pgw.core.logging.util.XMLUtil;


/**
 * <p>Clase Java para DepAcctId_Type complex type.
 * 
 * <p>El siguiente fragmento de esquema especifica el contenido que se espera que haya en esta clase.
 * 
 * <pre>
 * &lt;complexType name="DepAcctId_Type">
 *   &lt;complexContent>
 *     &lt;extension base="{urn://grupoaval.com/xsd/ifx/}GenericAcctId_Type">
 *       &lt;sequence>
 *       &lt;/sequence>
 *     &lt;/extension>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "DepAcctId_Type")
@XmlSeeAlso({
    DepAcctIdFromType.class
})
public class DepAcctIdType
    extends GenericAcctIdType
{

	public String toString() {
    	XMLUtil<DepAcctIdType> requestParser = 
    							new XMLUtil<DepAcctIdType>();
		return requestParser.convertObjectToXml(this);
    }

}
