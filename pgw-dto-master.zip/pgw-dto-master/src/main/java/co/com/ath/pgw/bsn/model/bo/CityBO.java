/*
 * CityVO
 *  
 * GSI - Integración
 * Creado el: 28/08/2014
 *
 * Copyright (c) A Toda Hora S.A. Todos los derechos reservados
 * 
 * Este software es confidencial y es propietario de ATH, queda prohibido
 * su uso, reproducción y copia de manera parcial o permanente salvo autorización
 * expresa de A Toda Hora S.A o de quién represente sus derechos.
 */
package co.com.ath.pgw.bsn.model.bo;

/**
 * Representa una ciudad o municipios en el modelo de negocio de acuerdo a la 
 * codificación DANE
 * 
 * @author proveedor_japiza
 * @version 1.0 29 Ago 2014
 * @since 1.0
 */
public class CityBO {

	/**
	 * Identificador único de la ciudad en el Core de la Pasarela de Pagos.
	 */
	private Long id;
	
	/**
	 * Código DANE de la ciudad o municipio. 
	 */
	private String code;

	/**
	 * Nombre de ciudad o municipio.
	 */
	private String name;

	/**
	 * Departamento al que pertenece la cuidad o municipio.
	 */
	private DepartmentBO departament;

	public CityBO(){
		super();
	}

	/**
	 * Retorna el identificador único de la ciudad en el Core de la Pasarela de
	 * Pagos.
	 * 
	 * @return Identificador de la ciudad o municipio.
	 */
	public Long getId() {
		return id;
	}

	/**
	 * Establece el identificador único de la ciudad en el Core de la Pasarela
	 * de Pagos.
	 * 
	 * @param id Identificador de la ciudad o municipio.
	 */
	public void setId(Long id) {
		this.id = id;
	}

	/**
	 * Retorna el código DANE de la ciudad o municipio.
	 *  
	 * 
	 * @return Código DANE.
	 */
	public String getCode() {
		return code;
	}

	/**
	 * Establece el código DANE de la ciudad o municipio.
	 * 
	 * @param code Código DANE
	 */
	public void setCodeDane(String code) {
		this.code = code;
	}

	/**
	 * Retorna el nombre de la ciudad o municipio.
	 * 
	 * @return Nombre de la ciudad.
	 */
	public String getName() {
		return name;
	}

	/**
	 * Establece el nombre de la ciudad o municipio.
	 * 
	 * @param name Nombre de la ciudad o municipio.
	 */
	public void setName(String name) {
		this.name = name;
	}

	/**
	 * Retorna el departamento al que pertenece la cuidad o municipio.
	 * 
	 * @return Departamento al que pertenece la ciudad o municipio.
	 */
	public DepartmentBO getDepartament() {
		return departament;
	}

	/**
	 * Establece el departamento al que pertenece la ciudad o municipio.
	 * 
	 * @param departament Departamento al que pertenece la ciudad o municipio.
	 */
	public void setDepartamento(DepartmentBO departament) {
		this.departament = departament;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((code == null) ? 0 : code.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		CityBO other = (CityBO) obj;
		if (code == null) {
			if (other.code != null)
				return false;
		} else if (!code.equals(other.code))
			return false;
		return true;
	}

	@Override
	public String toString() {
		return "CityVO [id=" + id + ", code=" + code + ", name=" + name + "]";
	}
	
}