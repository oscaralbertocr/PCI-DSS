
package co.com.ath.pgw.rest.dto;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonProperty;

public class GlobalPayUser implements Serializable {

	
	private static final long serialVersionUID = -8773278417198297359L;

	@JsonProperty("id")
	private String id;
	
	@JsonProperty("email")
	private String email;

	
	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}


}
