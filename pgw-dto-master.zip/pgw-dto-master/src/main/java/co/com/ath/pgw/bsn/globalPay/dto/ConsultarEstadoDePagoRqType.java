
package co.com.ath.pgw.bsn.globalPay.dto;

import java.util.List;


import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import co.com.ath.pgw.core.logging.util.XMLUtil;
import co.com.ath.pgw.in.model.CabeceraSolicitudType;
import co.com.ath.pgw.in.model.CredencialesType;
import co.com.ath.pgw.in.model.ReferenceType;
import co.com.ath.pgw.in.model.SvcRqType;

/**
*
* @author camilo.bustamante@sophossolutions.com
* @version 1.0 03 Enero 2019
* @RQ31686 RBM_Integracion_Boton_TC_GlobalPay
* 
*/

/**
 * <p>Clase Java para ConsultarEstadoDePagoRq_Type complex type.
 * 
 * <p>El siguiente fragmento de esquema especifica el contenido que se espera que haya en esta clase.
 * 
 * <pre>
 * &lt;complexType name="ConsultarEstadoDePagoRq_Type">
 *   &lt;complexContent>
 *     &lt;extension base="{urn://ath.com.co/xsd/common/}SvcRq_Type">
 *       &lt;sequence>
 *         &lt;element ref="{urn://ath.com.co/xsd/common/}Credenciales"/>
 *         &lt;element ref="{urn://ath.com.co/xsd/common/}CabeceraSolicitud" minOccurs="0"/>
 *         &lt;element ref="{urn://ath.com.co/xsd/common/}IdTransaccion"/>
 *         &lt;element ref="{urn://ath.com.co/xsd/common/}Pmtid"/>
 *         &lt;element ref="{urn://ath.com.co/xsd/common/}Reference" maxOccurs="50" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/extension>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 */
public class ConsultarEstadoDePagoRqType
    extends SvcRqType {

	public static Logger LOGGER = LoggerFactory.getLogger(ConsultarEstadoDePagoRqType.class);
			
    protected CredencialesType credenciales;
    
    
    protected CabeceraSolicitudType cabeceraSolicitud;
    
    
    protected String idTransaccion;
    
    
    protected String pmtid;
    
    
    protected List<ReferenceType> reference;
    
    
	public CredencialesType getCredenciales() {
		return credenciales;
	}

	public void setCredenciales(CredencialesType credenciales) {
		this.credenciales = credenciales;
	}

	public CabeceraSolicitudType getCabeceraSolicitud() {
		return cabeceraSolicitud;
	}

	public void setCabeceraSolicitud(CabeceraSolicitudType cabeceraSolicitud) {
		this.cabeceraSolicitud = cabeceraSolicitud;
	}

    public String getIdTransaccion() {
		return idTransaccion;
	}

	public void setIdTransaccion(String idTransaccion) {
		this.idTransaccion = idTransaccion;
	}

	public String getPmtid() {
		return pmtid;
	}

	public void setPmtid(String pmtid) {
		this.pmtid = pmtid;
	}
	
	public List<ReferenceType> getReference() {
		return reference;
	}

	public void setReference(List<ReferenceType> reference) {
		this.reference = reference;
	}

	@Override
	public String toString() {
		XMLUtil<ConsultarEstadoDePagoRqType> requestParser = 
				new XMLUtil<ConsultarEstadoDePagoRqType>();
		return requestParser.convertObjectToXml(this);
	}

}
