
package co.com.ath.pgw.client.bank.info.xsd.ifx;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;

import co.com.ath.pgw.core.logging.util.XMLUtil;


/**
 * <p>Clase Java para CurConvertRule_Type complex type.
 * 
 * <p>El siguiente fragmento de esquema especifica el contenido que se espera que haya en esta clase.
 * 
 * <pre>
 * &lt;complexType name="CurConvertRule_Type">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element ref="{urn://grupoaval.com/xsd/ifx/}OpenEnum" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "CurConvertRule_Type", propOrder = {
    "openEnum"
})
public class CurConvertRuleType {

    @XmlElement(name = "OpenEnum")
    protected String openEnum;

    /**
     * Obtiene el valor de la propiedad openEnum.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getOpenEnum() {
        return openEnum;
    }

    /**
     * Define el valor de la propiedad openEnum.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setOpenEnum(String value) {
        this.openEnum = value;
    }
    
    public String toString() {
    	XMLUtil<CurConvertRuleType> requestParser = 
    							new XMLUtil<CurConvertRuleType>();
		return requestParser.convertObjectToXml(this);
    }

}
