package co.com.ath.pgw.rest.globalPay.qr;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.fasterxml.jackson.annotation.JsonProperty;

import co.com.ath.pgw.core.logging.util.XMLUtil;

@JsonInclude(Include.NON_NULL)
public class CoreGetStateQrRBMRq implements Serializable {

	private static final long serialVersionUID = 3616927184326801140L;

	@JsonProperty("fechaTransaccion")
	private String fechaTransaccion;
	
	@JsonProperty("idTerminal")
	private String idTerminal;
	
	@JsonProperty("idAdquiriente")
	private String idAdquiriente;
	
	@JsonProperty("idTransaccionTerminal")
	private String idTransaccionTerminal;
	
	public String getFechaTransaccion() {
		return fechaTransaccion;
	}
	public void setFechaTransaccion(String fechaTransaccion) {
		this.fechaTransaccion = fechaTransaccion;
	}
	public String getIdTerminal() {
		return idTerminal;
	}
	public void setIdTerminal(String idTerminal) {
		this.idTerminal = idTerminal;
	}
	public String getIdAdquiriente() {
		return idAdquiriente;
	}
	public void setIdAdquiriente(String idAdquiriente) {
		this.idAdquiriente = idAdquiriente;
	}
	public String getIdTransaccionTerminal() {
		return idTransaccionTerminal;
	}
	public void setIdTransaccionTerminal(String idTransaccionTerminal) {
		this.idTransaccionTerminal = idTransaccionTerminal;
	}
	
	
	@Override
	public String toString() {
		XMLUtil<CoreGetStateQrRBMRq> util = new XMLUtil<CoreGetStateQrRBMRq>();
		return util.convertObjectToJson(this);
	}
		
	
}
