
package co.com.ath.pgw.client.bank.info;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;

import co.com.ath.pgw.client.bank.info.xsd.ifx.BankInfoInqRqType;
import co.com.ath.pgw.core.logging.util.XMLUtil;


/**
 * <p>Clase Java para anonymous complex type.
 * 
 * <p>El siguiente fragmento de esquema especifica el contenido que se espera que haya en esta clase.
 * 
 * <pre>
 * &lt;complexType>
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element ref="{urn://grupoaval.com/inquiry/v1/}BankInfoInqRq"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "", propOrder = {
    "bankInfoInqRq"
})
@XmlRootElement(name = "getBankInfoRequest",namespace = "urn://grupoaval.com/inquiry/v1/")
public class GetBankInfoRequest {

    @XmlElement(name = "BankInfoInqRq",namespace = "urn://grupoaval.com/inquiry/v1/", required = true)
    protected BankInfoInqRqType bankInfoInqRq;

    /**
     * Obtiene el valor de la propiedad bankInfoInqRq.
     * 
     * @return
     *     possible object is
     *     {@link BankInfoInqRqType }
     *     
     */
    public BankInfoInqRqType getBankInfoInqRq() {
        return bankInfoInqRq;
    }

    /**
     * Define el valor de la propiedad bankInfoInqRq.
     * 
     * @param value
     *     allowed object is
     *     {@link BankInfoInqRqType }
     *     
     */
    public void setBankInfoInqRq(BankInfoInqRqType value) {
        this.bankInfoInqRq = value;
    }
    
    public String toString() {
    	XMLUtil<GetBankInfoRequest> requestParser = 
    							new XMLUtil<GetBankInfoRequest>();
		return requestParser.convertObjectToXml(this);
    }

}
