
package co.com.ath.pgw.client.rbm.model;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;

/**
 * <p>
 * Clase Java para TipoInfoTerminal complex type.
 * 
 * <p>
 * El siguiente fragmento de esquema especifica el contenido que se espera que
 * haya en esta clase.
 * 
 * <pre>
 * &lt;complexType name="TipoInfoTerminal"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="nombreAdquiriente" type="{http://www.w3.org/2001/XMLSchema}string"/&gt;
 *         &lt;element name="infoUbicacion" type="{http://www.rbm.com.co/esb/}TipoInfoUbicacion"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "infoTerminal", propOrder = { "nombreAdquiriente", "infoUbicacion" }, namespace = "http://www.rbm.com.co/esb/comercio/")
public class TipoInfoTerminal {

	@XmlElement(name = "nombreAdquiriente", namespace= "http://www.rbm.com.co/esb/comercio/")
	protected String nombreAdquiriente;
	@XmlElement(name = "infoUbicacion", namespace= "http://www.rbm.com.co/esb/comercio/")
	protected TipoInfoUbicacion infoUbicacion;

	/**
	 * Obtiene el valor de la propiedad nombreAdquiriente.
	 * 
	 * @return possible object is {@link String }
	 * 
	 */
	public String getNombreAdquiriente() {
		return nombreAdquiriente;
	}

	/**
	 * Define el valor de la propiedad nombreAdquiriente.
	 * 
	 * @param value allowed object is {@link String }
	 * 
	 */
	public void setNombreAdquiriente(String value) {
		this.nombreAdquiriente = value;
	}

	/**
	 * Obtiene el valor de la propiedad infoUbicacion.
	 * 
	 * @return possible object is {@link TipoInfoUbicacion }
	 * 
	 */
	public TipoInfoUbicacion getInfoUbicacion() {
		return infoUbicacion;
	}

	/**
	 * Define el valor de la propiedad infoUbicacion.
	 * 
	 * @param value allowed object is {@link TipoInfoUbicacion }
	 * 
	 */
	public void setInfoUbicacion(TipoInfoUbicacion value) {
		this.infoUbicacion = value;
	}

}
