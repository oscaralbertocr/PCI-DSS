
package co.com.ath.pgw.rest.dto;

import java.io.Serializable;
import java.math.BigDecimal;

import com.fasterxml.jackson.annotation.JsonProperty;

public class CurAmt implements Serializable
{

	@JsonProperty("Amt")
    private BigDecimal amt;
	
	@JsonProperty("CurCode")
    private String curCode;
	
    private final static long serialVersionUID = 5131904000808967745L;

    public BigDecimal getAmt() {
        return amt;
    }

    public void setAmt(BigDecimal amt) {
        this.amt = amt;
    }

    public String getCurCode() {
        return curCode;
    }

    public void setCurCode(String curCode) {
        this.curCode = curCode;
    }

}
