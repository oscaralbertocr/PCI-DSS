
package co.com.ath.pgw.client.globalPay.dto;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlSchemaType;
import javax.xml.bind.annotation.XmlType;

import co.com.ath.pgw.client.globalPay.model.TipoCabeceraSolicitud;
import co.com.ath.pgw.client.globalPay.model.TipoEstadoActualTransaccion;
import co.com.ath.pgw.client.globalPay.model.TipoInfoPago;
import co.com.ath.pgw.client.globalPay.model.TipoInfoRespuesta;
import co.com.ath.pgw.core.logging.util.XMLUtil;


/**
 * <p>Clase Java para anonymous complex type.
 * 
 * <p>El siguiente fragmento de esquema especifica el contenido que se espera que haya en esta clase.
 * 
 * <pre>
 * &lt;complexType&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="cabeceraRespuesta" type="{http://www.rbm.com.co/esb/globalpay/}TipoCabeceraSolicitud"/&gt;
 *         &lt;element name="infoPago" type="{http://www.rbm.com.co/esb/globalpay/}TipoInfoPago" minOccurs="0"/&gt;
 *         &lt;element name="estadoActualTransaccion" type="{http://www.rbm.com.co/esb/globalpay/}TipoEstadoActualTransaccion" minOccurs="0"/&gt;
 *         &lt;element name="infoRespuesta" type="{http://www.rbm.com.co/esb/}TipoInfoRespuesta"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "", propOrder = {
    "cabeceraRespuesta",
    "infoPago",
    "estadoActualTransaccion",
    "infoRespuesta"
})
@XmlRootElement(name = "ConsultarEstadoDePagoRespuesta")
public class ConsultarEstadoDePagoRespuestaResponse {

    @XmlElement(required = true)
    protected TipoCabeceraSolicitud cabeceraRespuesta;
    protected TipoInfoPago infoPago;
    @XmlSchemaType(name = "string")
    protected TipoEstadoActualTransaccion estadoActualTransaccion;
    @XmlElement(required = true)
    protected TipoInfoRespuesta infoRespuesta;

    /**
     * Obtiene el valor de la propiedad cabeceraRespuesta.
     * 
     * @return
     *     possible object is
     *     {@link TipoCabeceraSolicitud }
     *     
     */
    public TipoCabeceraSolicitud getCabeceraRespuesta() {
        return cabeceraRespuesta;
    }

    /**
     * Define el valor de la propiedad cabeceraRespuesta.
     * 
     * @param value
     *     allowed object is
     *     {@link TipoCabeceraSolicitud }
     *     
     */
    public void setCabeceraRespuesta(TipoCabeceraSolicitud value) {
        this.cabeceraRespuesta = value;
    }

    /**
     * Obtiene el valor de la propiedad infoPago.
     * 
     * @return
     *     possible object is
     *     {@link TipoInfoPago }
     *     
     */
    public TipoInfoPago getInfoPago() {
        return infoPago;
    }

    /**
     * Define el valor de la propiedad infoPago.
     * 
     * @param value
     *     allowed object is
     *     {@link TipoInfoPago }
     *     
     */
    public void setInfoPago(TipoInfoPago value) {
        this.infoPago = value;
    }

    /**
     * Obtiene el valor de la propiedad estadoActualTransaccion.
     * 
     * @return
     *     possible object is
     *     {@link TipoEstadoActualTransaccion }
     *     
     */
    public TipoEstadoActualTransaccion getEstadoActualTransaccion() {
        return estadoActualTransaccion;
    }

    /**
     * Define el valor de la propiedad estadoActualTransaccion.
     * 
     * @param value
     *     allowed object is
     *     {@link TipoEstadoActualTransaccion }
     *     
     */
    public void setEstadoActualTransaccion(TipoEstadoActualTransaccion value) {
        this.estadoActualTransaccion = value;
    }

    /**
     * Obtiene el valor de la propiedad infoRespuesta.
     * 
     * @return
     *     possible object is
     *     {@link TipoInfoRespuesta }
     *     
     */
    public TipoInfoRespuesta getInfoRespuesta() {
        return infoRespuesta;
    }

    /**
     * Define el valor de la propiedad infoRespuesta.
     * 
     * @param value
     *     allowed object is
     *     {@link TipoInfoRespuesta }
     *     
     */
    public void setInfoRespuesta(TipoInfoRespuesta value) {
        this.infoRespuesta = value;
    }
    
    @Override
	public String toString() {
		XMLUtil<ConsultarEstadoDePagoRespuestaResponse> requestParser = new XMLUtil<ConsultarEstadoDePagoRespuestaResponse>();
		return requestParser.convertObjectToXml(this);
	}

}
