package co.com.ath.ws.rs.objects;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonProperty;

public class Reference implements Serializable{

	private static final long serialVersionUID = 1L;
	
	@JsonProperty("refId")
    private String refId;
    
	@JsonProperty("refType")
    private String refType;

	public String getRefId() {
		return refId;
	}

	public void setRefId(String refId) {
		this.refId = refId;
	}

	public String getRefType() {
		return refType;
	}

	public void setRefType(String refType) {
		this.refType = refType;
	}
	
	 

}
