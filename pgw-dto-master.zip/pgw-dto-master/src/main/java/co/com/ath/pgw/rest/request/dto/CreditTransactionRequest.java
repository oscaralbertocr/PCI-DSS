package co.com.ath.pgw.rest.request.dto;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonProperty;

import co.com.ath.pgw.core.logging.util.XMLUtil;
import co.com.ath.pgw.rest.dto.Agreement;
import co.com.ath.pgw.rest.dto.CCAcctStmtRec;
import co.com.ath.pgw.rest.dto.CardAcctId;
import co.com.ath.pgw.rest.dto.CustInfo;
import co.com.ath.pgw.rest.dto.CustPayeeInfo;
import co.com.ath.pgw.rest.dto.Fee;
import co.com.ath.pgw.rest.dto.InvoicePmtInfo;
import co.com.ath.pgw.rest.dto.RefInfo;
import co.com.ath.pgw.rest.dto.TaxPmtInfo;
import co.com.ath.pgw.rest.dto.TrnSrcInfo;

public class CreditTransactionRequest implements Serializable {

	@JsonProperty("CustPayeeInfo")
	private CustPayeeInfo custPayeeInfo;
	@JsonProperty("CustInfo")
	private CustInfo custInfo;
	@JsonProperty("Agreement")
	private Agreement agreement;
	@JsonProperty("CCAcctStmtRec")
    private CCAcctStmtRec ccAcctStmtRec;
	@JsonProperty("CardAcctId")
	private CardAcctId cardAcctId;
	@JsonProperty("InvoicePmtInfo")
	private InvoicePmtInfo invoicePmtInfo;
	@JsonProperty("RefInfo")
	private List<RefInfo> refInfo = null;
	@JsonProperty("Fee")
	private Fee fee;
	@JsonProperty("TaxPmtInfo")
	private TaxPmtInfo taxPmtInfo;
	@JsonProperty("TrnSrcInfo")
	private TrnSrcInfo trnSrcInfo;
	private static final long serialVersionUID = -3510516630136587992L;

	public CustPayeeInfo getCustPayeeInfo() {
		return custPayeeInfo;
	}

	public void setCustPayeeInfo(CustPayeeInfo custPayeeInfo) {
		this.custPayeeInfo = custPayeeInfo;
	}

	public CustInfo getCustInfo() {
		return custInfo;
	}

	public void setCustInfo(CustInfo custInfo) {
		this.custInfo = custInfo;
	}

	public Agreement getAgreement() {
		return agreement;
	}

	public void setAgreement(Agreement agreement) {
		this.agreement = agreement;
	}

	public CCAcctStmtRec getCcAcctStmtRec() {
		return ccAcctStmtRec;
	}

	public void setCcAcctStmtRec(CCAcctStmtRec ccAcctStmtRec) {
		this.ccAcctStmtRec = ccAcctStmtRec;
	}

	public CardAcctId getCardAcctId() {
		return cardAcctId;
	}

	public void setCardAcctId(CardAcctId cardAcctId) {
		this.cardAcctId = cardAcctId;
	}

	public InvoicePmtInfo getInvoicePmtInfo() {
		return invoicePmtInfo;
	}

	public void setInvoicePmtInfo(InvoicePmtInfo invoicePmtInfo) {
		this.invoicePmtInfo = invoicePmtInfo;
	}

	public List<RefInfo> getRefInfo() {
		if (refInfo == null) {
			refInfo = new ArrayList<RefInfo>();
		}
		return refInfo;
	}

	public void setRefInfo(List<RefInfo> refInfo) {
		this.refInfo = refInfo;
	}

	public Fee getFee() {
		return fee;
	}

	public void setFee(Fee fee) {
		this.fee = fee;
	}

	public TaxPmtInfo getTaxPmtInfo() {
		return taxPmtInfo;
	}

	public void setTaxPmtInfo(TaxPmtInfo taxPmtInfo) {
		this.taxPmtInfo = taxPmtInfo;
	}

	public TrnSrcInfo getTrnSrcInfo() {
		return trnSrcInfo;
	}

	public void setTrnSrcInfo(TrnSrcInfo trnSrcInfo) {
		this.trnSrcInfo = trnSrcInfo;
	}

	@Override
	public String toString() {
		XMLUtil<CreditTransactionRequest> util = new XMLUtil<CreditTransactionRequest>();
		return util.convertObjectToJson(this);
	}

}