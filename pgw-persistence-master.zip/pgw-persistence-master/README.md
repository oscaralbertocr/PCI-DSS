# pgw-persistence
# Ejecucion Release [Persistence] - prv_jmrodriguez:PC_1
# [02082019] [RQ32840] Ejecucion Release [Persistence] - prv_jmrodriguez:PC_1.1
# [30082019] [IM47445] Ejecucion Release [Persistence] - prv_jmrodriguez:PC_1.2
# [09092019] [RQ32095] Ejecucion Release [Persistence] - prv_jmrodriguez:PC_1.3
# [11092019] [RQ32095] Ejecucion Release [Persistence] - prv_jmrodriguez:PC_1.4


# [11092019] [RQ32095] Ejecucion Release [Persistence] - prv_javendano:PC_1.5
# [11092019] [RQ32095] Ejecucion Release [Persistence] - prv_javendano:PC_1.6
# [30102019] [RQ32840] Ejecucion Release [Persistence] - prv_javendano:PC_1.7
 
