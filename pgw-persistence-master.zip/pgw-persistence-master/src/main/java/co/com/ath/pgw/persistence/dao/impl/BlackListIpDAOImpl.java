/*
 * BlackListIpDAOImpl
 *  
 * GSI - Integración
 * Creado el: 24/06/2015
 *
 * Copyright (c) A Toda Hora S.A. Todos los derechos reservados
 * 
 * Este software es confidencial y es propietario de ATH, queda prohibido
 * su uso, reproducción y copia de manera parcial o permanente salvo autorización
 * expresa de A Toda Hora S.A o de quién represente sus derechos.
 */
package co.com.ath.pgw.persistence.dao.impl;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.Query;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Repository;

import co.com.ath.pgw.persistence.AbstractDAO_JPA;
import co.com.ath.pgw.persistence.dao.BlackListIpDAO;
import co.com.ath.pgw.persistence.model.BlackListIp;

@Repository
public class BlackListIpDAOImpl extends AbstractDAO_JPA<BlackListIp> implements BlackListIpDAO {
	
	static Logger LOGGER = LoggerFactory.getLogger(BlackListIpDAOImpl.class);
	
	protected BlackListIpDAOImpl() {
		super(BlackListIp.class);
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<BlackListIp> findByIp(String ip) {
		StringBuilder hql = new StringBuilder("from BlackListIp bl ");
		hql.append("where bl.rowDeleted <> 1 ");
		hql.append("and bl.status = 1 ");
		hql.append("and bl.ip = :ip ");
		hql.append("and (bl.rowExpirationDate is null or (sysdate() < bl.rowExpirationDate))");
		
        Query query = entityManager.createQuery(hql.toString());
		query.setParameter("ip", ip);
		
		List<BlackListIp> blackListIp = new ArrayList<BlackListIp>();
		blackListIp = (List<BlackListIp>) query.getResultList();
		return blackListIp;
	}

}
