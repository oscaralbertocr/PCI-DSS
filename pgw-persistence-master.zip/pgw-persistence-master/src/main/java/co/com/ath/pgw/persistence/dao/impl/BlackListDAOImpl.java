/*
 * BlackListDAOImpl
 *  
 * GSI - Integración
 * Creado el: 24/06/2015
 *
 * Copyright (c) A Toda Hora S.A. Todos los derechos reservados
 * 
 * Este software es confidencial y es propietario de ATH, queda prohibido
 * su uso, reproducción y copia de manera parcial o permanente salvo autorización
 * expresa de A Toda Hora S.A o de quién represente sus derechos.
 */
package co.com.ath.pgw.persistence.dao.impl;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.Query;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Repository;

import co.com.ath.pgw.persistence.AbstractDAO_JPA;
import co.com.ath.pgw.persistence.dao.BlackListDAO;
import co.com.ath.pgw.persistence.model.BlackList;

@Repository
public class BlackListDAOImpl extends AbstractDAO_JPA<BlackList>  implements BlackListDAO {
	
	static Logger LOGGER = LoggerFactory.getLogger(BlackListDAOImpl.class);
	
	protected BlackListDAOImpl() {
		super(BlackList.class);
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<BlackList> findByDocument(String documentType, String documentId) {
		StringBuilder hql = new StringBuilder("from BlackList b ");
		hql.append("where b.rowDeleted <> 1 ");
		hql.append("and b.status = 1 ");
		hql.append("and b.documentType = :documentType ");
		hql.append("and b.documentId = :documentId ");
		hql.append("and (b.rowExpirationDate is null or (sysdate() < b.rowExpirationDate))");
		
        Query query = entityManager.createQuery(hql.toString());
		query.setParameter("documentType", documentType);
		query.setParameter("documentId", documentId);
		
		List<BlackList> blackList = new ArrayList<BlackList>();
		blackList = (List<BlackList>) query.getResultList();
		return blackList;
	}

}
