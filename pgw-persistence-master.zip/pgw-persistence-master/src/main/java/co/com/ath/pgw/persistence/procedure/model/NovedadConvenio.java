package co.com.ath.pgw.persistence.procedure.model;

import java.io.Serializable;

import org.springframework.stereotype.Service;

import co.com.ath.pgw.core.logging.util.XMLUtil;

@Service
public class NovedadConvenio implements Serializable{
	
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private String operacion;
	private String estado;
	private String codigoEAN;
	private String codigoNura;
	private String codigoIncocredito;
	private String codigoAch;
	private String codigoHomologaBAVV;
	private String codigoTerminal;
	private String idActEcnomica;
	private String idBanco;
	private String idMunicipio;
	private String razonSocial;
	private String direccion;
	private String telefono;
	private String email;
	private String extension;
	private String repLegal;
	private String emailCont;
	private String telCont;
	
	public NovedadConvenio() {
		// TODO Auto-generated constructor stub
	}
	
	public String getOperacion() {
		return operacion;
	}
	public void setOperacion(String operacion) {
		this.operacion = operacion;
	}
	public String getEstado() {
		return estado;
	}
	public void setEstado(String estado) {
		this.estado = estado;
	}
	public String getCodigoEAN() {
		return codigoEAN;
	}
	public void setCodigoEAN(String codigoEAN) {
		this.codigoEAN = codigoEAN;
	}
	public String getCodigoNura() {
		return codigoNura;
	}
	public void setCodigoNura(String codigoNura) {
		this.codigoNura = codigoNura;
	}
	public String getCodigoIncocredito() {
		return codigoIncocredito;
	}
	public void setCodigoIncocredito(String codigoIncocredito) {
		this.codigoIncocredito = codigoIncocredito;
	}
	public String getCodigoAch() {
		return codigoAch;
	}
	public void setCodigoAch(String codigoAch) {
		this.codigoAch = codigoAch;
	}
	public String getCodigoHomologaBAVV() {
		return codigoHomologaBAVV;
	}
	public void setCodigoHomologaBAVV(String codigoHomologaBAVV) {
		this.codigoHomologaBAVV = codigoHomologaBAVV;
	}
	public String getCodigoTerminal() {
		return codigoTerminal;
	}
	public void setCodigoTerminal(String codigoTerminal) {
		this.codigoTerminal = codigoTerminal;
	}
	public String getIdActEcnomica() {
		return idActEcnomica;
	}
	public void setIdActEcnomica(String idActEcnomica) {
		this.idActEcnomica = idActEcnomica;
	}
	public String getIdBanco() {
		return idBanco;
	}
	public void setIdBanco(String idBanco) {
		this.idBanco = idBanco;
	}
	public String getIdMunicipio() {
		return idMunicipio;
	}
	public void setIdMunicipio(String idMunicipio) {
		this.idMunicipio = idMunicipio;
	}
	public String getRazonSocial() {
		return razonSocial;
	}

	public void setRazonSocial(String razonSocial) {
		this.razonSocial = razonSocial;
	}

	public String getDireccion() {
		return direccion;
	}
	public void setDireccion(String direccion) {
		this.direccion = direccion;
	}
	public String getTelefono() {
		return telefono;
	}
	public void setTelefono(String telefono) {
		this.telefono = telefono;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getExtension() {
		return extension;
	}
	public void setExtension(String extension) {
		this.extension = extension;
	}
	public String getRepLegal() {
		return repLegal;
	}
	public void setRepLegal(String repLegal) {
		this.repLegal = repLegal;
	}
	public String getEmailCont() {
		return emailCont;
	}
	public void setEmailCont(String emailCont) {
		this.emailCont = emailCont;
	}
	public String getTelCont() {
		return telCont;
	}
	public void setTelCont(String telCont) {
		this.telCont = telCont;
	}
	@Override
	public String toString() {
		XMLUtil<NovedadConvenio> requestParser = 
				new XMLUtil<NovedadConvenio>();
		return requestParser.convertObjectToXml(this);
	}

}
