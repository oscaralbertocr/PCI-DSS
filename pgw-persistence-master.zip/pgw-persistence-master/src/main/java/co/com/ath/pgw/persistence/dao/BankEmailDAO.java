package co.com.ath.pgw.persistence.dao;

import java.util.List;

import co.com.ath.pgw.persistence.DataAccessObject;
import co.com.ath.pgw.persistence.model.BankEmail;

public interface BankEmailDAO extends DataAccessObject<BankEmail>{
	
	List<BankEmail> findByBank(Long idBank);
	
}
