/**
 * 
 */
package co.com.ath.pgw.persistence.validation.model.impl;

import java.util.Locale;

import javax.annotation.Resource;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import co.com.ath.pgw.persistence.dao.TransactionDAO;
import co.com.ath.pgw.persistence.model.Transaction;
import co.com.ath.pgw.util.i18n.BundleKeys;
import co.com.ath.pgw.util.i18n.BundleType;
import co.com.ath.pgw.util.i18n.ResourceBundleManager;
import co.com.ath.pgw.util.validation.ErrorCode;
import co.com.ath.pgw.util.validation.IntValueValidator;
import co.com.ath.pgw.util.validation.NotEmptyValidator;
import co.com.ath.pgw.util.validation.NotNullValidator;
import co.com.ath.pgw.util.validation.ObjectValidationException;
import co.com.ath.pgw.util.validation.ObjectValidator;
import co.com.ath.pgw.util.validation.ValidationException;
import co.com.ath.pgw.util.validation.model.TransactionIdNuraCodeValidator;
import co.com.ath.pgw.util.validation.model.dto.TransactionIdNuraCodeInDTO;
/**
 * @author proveedor_japiza
 *
 */
@Service
public class TransactionIdNuraCodeValidatorImpl implements
		TransactionIdNuraCodeValidator {
	
static Logger LOGGER = LoggerFactory.getLogger(TransactionIdNuraCodeValidatorImpl.class);
	
	private ObjectValidator validator;

	@Resource
	private TransactionDAO transactionDAO;

	@Autowired
	private ResourceBundleManager bundleManager;
	
	@Override
	public void validate(TransactionIdNuraCodeInDTO inDTO)
			throws ValidationException {
		validator = new NotNullValidator(new IntValueValidator());
		validator.setBundleManager(bundleManager);
		try {
			validator.validate(inDTO.getPmtIdTransaction(), inDTO.getLocale());			
		} catch (ObjectValidationException e) {
			throwException(e, inDTO.getLocale(), BundleKeys.ERROR_INVALID_TRANSACTION_ID, ErrorCode.INVALID_TRANSACTION_ID);
		}
		validator = new NotNullValidator(new NotEmptyValidator());
		validator.setBundleManager(bundleManager);
		try {
			validator.validate(inDTO.getNuraCode(), inDTO.getLocale());			
		} catch (ObjectValidationException e) {
			throwException(e, inDTO.getLocale(), BundleKeys.ERROR_INVALID_AGREEMENT_ID, ErrorCode.INVALID_AGREEMENT_ID);
		}
		validateTransactionNuraCode(inDTO);

	}
	
	private void validateTransactionNuraCode(TransactionIdNuraCodeInDTO inDTO) throws ValidationException{
		Long pmtIdTransation = Long.valueOf(inDTO.getPmtIdTransaction());
		String nuraCode = inDTO.getNuraCode();
		Transaction transaction = transactionDAO.findByPmtIdTransactionNuraCode(pmtIdTransation, nuraCode);
		if (transaction == null) {
			throwException(
					getNotFoundEx(inDTO, inDTO.getLocale()), 
					inDTO.getLocale(),
					BundleKeys.ERROR_INVALID_TRANSACTION_ID, 
					ErrorCode.INVALID_TRANSACTION_ID);
		}
	}
	
	/**
	 * Retorna la exepción si el registro no existe.
	 * 
	 * @param attribute Id de la transacción para mostrar en el mensaje.
	 * @param locale Localización.
	 * @return Objeto ObjectValidationException con la descripción del error.
	 */
	private ObjectValidationException getNotFoundEx(Object attribute,
			Locale locale) {
		
		
		return new ObjectValidationException(getMessage(
				BundleKeys.ERROR_INVALID_TRANSACTION_ID_NURA_CODE_NOT_FOUND,
				new Object[] { ((TransactionIdNuraCodeInDTO)attribute).getPmtIdTransaction(),((TransactionIdNuraCodeInDTO)attribute).getNuraCode()}, locale));
	}
	

	/**
	 * Obtiene los mensajes del bundle basado en la llave que llega por
	 * parámetro.
	 * 
	 * @param messageKey
	 *            Clave del mensaje.
	 * @param args
	 *            Argumentos dinamicos para el mensaje.
	 * @param locale
	 *            Localización.
	 * @return Mensaje de error formateado o la messageKey si la llave no fue
	 *         encontrada.
	 */
	private String getMessage(String messageKey, Object[] args, Locale locale) {
		if (bundleManager == null) {
			return messageKey;
		}
		bundleManager.setBundle(BundleType.ERRORS);
		return bundleManager.getMessage(messageKey, args, locale);
	}
	
	/**
	 * Método encargado de lanzar la excepción encontrada en los validadores.
	 * 
	 * @param e
	 *            Excepción de los validadores.
	 * @param locale
	 *            Localización.
	 * @throws ValidationException
	 */
	private void throwException(ObjectValidationException e, Locale locale, String messageKey, int errorCode)
			throws ValidationException {
		ValidationException ve = new ValidationException(getMessage(
				messageKey, null, locale),
				errorCode, 	e);
		LOGGER.warn("Fallo en validador: \n{}", ve.toString());
		throw ve;
	}

}
