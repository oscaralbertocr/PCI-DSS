/*
 * GenericQueryDAO
 *  
 * GSI - Integración
 * Creado el: 14/04/2015
 *
 * Copyright (c) A Toda Hora S.A. Todos los derechos reservados
 * 
 * Este software es confidencial y es propietario de ATH, queda prohibido
 * su uso, reproducción y copia de manera parcial o permanente salvo autorización
 * expresa de A Toda Hora S.A o de quién represente sus derechos.
 */
package co.com.ath.pgw.persistence.dao;

import java.util.Date;
import java.util.List;

import co.com.ath.pgw.persistence.model.BatchJobExecution;

/**
 * Class description goes here...
 *
 * @author Andrés Méndez Juanias <proveedor_mamendez@ath.com.co> 
 * @version 1.0 14/04/2015
 * @since 1.0
 * 
 * @IM714148  
 * <strong>Autor</strong>Andres Eduardo Hernandez</br>
 * <strong>Descripcion</strong>Extracto Digital Pagos PSE</br>
 * <strong>Numero de Cambios</strong>1</br>
 * <strong>Identificador corto</strong>C01</br>
 * 
 */
public interface GenericQueryDAO {
	
	/**
	 * Método encargado de retornar la fecha del job mas reciente que se ejecutó.
	 * @param jobName Nombre del job a consultar.
	 * @return Fecha del job mas reciente ejecutado.
	 */
	Date findMaxDateBatch(String jobName);
	
	/**INICIO-C01*/
	/**
	 * Método encargado de retornar el listado de JOB ejecutados
	 * @param jobName Nombre del job a consultar.
	 * @return Listado de JOB ejecutados
	 */
	public List<BatchJobExecution> findByJobName( String jobName );
	
	/**
	 * Método encargado de validar si la propiedad de ejecución del JOB existe
	 * @param idExecution identificador del Job.
	 * @param keyName nombre del parametro.
	 * @param stringVal valor del parametro.
	 * @return Valor encontrado
	 */
	public boolean findBatchParams( long idExecution, String keyName, String stringVal );
	/**FIN-C01*/
}
