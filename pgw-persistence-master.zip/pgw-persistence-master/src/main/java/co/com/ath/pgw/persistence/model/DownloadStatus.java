/*
 * DownloadStatus
 *  
 * GSI - Integración
 * Creado el: 28/08/2014
 *
 * Copyright (c) A Toda Hora S.A. Todos los derechos reservados
 * 
 * Este software es confidencial y es propietario de ATH, queda prohibido
 * su uso, reproducción y copia de manera parcial o permanente salvo autorización
 * expresa de A Toda Hora S.A o de quién represente sus derechos.
 */
package co.com.ath.pgw.persistence.model;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import co.com.ath.pgw.persistence.PersistentObject;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;


/**
 * The persistent class for the ESTADOSDESCARGA database table.
 * 
 */
@Entity
@Table(name="ESTADOSDESCARGA")
public class DownloadStatus implements PersistentObject {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = -2385638875278076890L;

	/** id Atributo de la clase. */
	@Id
    @Column(name = "ID")
	private Long id;

	/** status Atributo de la clase. */
	@Column(name="ESTADO")
	private String status;

	/** rowCreationDate Atributo de la clase. */
	@Column(name="REGFECHACREACION")
    @Temporal(TemporalType.TIMESTAMP)
	private Date rowCreationDate;

	/** rowLastUpdate Atributo de la clase. */
	@Column(name="REGFECHAMODIFICACION")
    @Temporal(TemporalType.TIMESTAMP)
	private Date rowLastUpdate;
	
	/** rowDeleted Atributo de la clase. */
	@Column(name="REGELIMINADO")
	private boolean rowDeleted;
	
	public DownloadStatus() {}

	/**
	 * Método encargado de recuperar el valor del atributo id.
	 * @return El atributo id asociado a la clase.
	 */
	public Long getId() {
		return id;
	}

	/**
	 * Método encargado de actualizar el atributo id.
	 * @param id Nuevo valor para id.
	 */
	public void setId(Long id) {
		this.id = id;
	}

	/**
	 * Método encargado de recuperar el valor del atributo status.
	 * @return El atributo status asociado a la clase.
	 */
	public String getStatus() {
		return status;
	}

	/**
	 * Método encargado de actualizar el atributo status.
	 * @param status Nuevo valor para status.
	 */
	public void setStatus(String status) {
		this.status = status;
	}

	/**
	 * Método encargado de recuperar el valor del atributo rowCreationDate.
	 * @return El atributo rowCreationDate asociado a la clase.
	 */
	public Date getRowCreationDate() {
		return rowCreationDate;
	}

	/**
	 * Método encargado de actualizar el atributo rowCreationDate.
	 * @param rowCreationDate Nuevo valor para rowCreationDate.
	 */
	public void setRowCreationDate(Date rowCreationDate) {
		this.rowCreationDate = rowCreationDate;
	}

	/**
	 * Método encargado de recuperar el valor del atributo rowLastUpdate.
	 * @return El atributo rowLastUpdate asociado a la clase.
	 */
	public Date getRowLastUpdate() {
		return rowLastUpdate;
	}

	/**
	 * Método encargado de actualizar el atributo rowLastUpdate.
	 * @param rowLastUpdate Nuevo valor para rowLastUpdate.
	 */
	public void setRowLastUpdate(Date rowLastUpdate) {
		this.rowLastUpdate = rowLastUpdate;
	}

	/**
	 * Método encargado de recuperar el valor del atributo rowDeleted.
	 * @return El atributo rowDeleted asociado a la clase.
	 */
	public boolean isRowDeleted() {
		return rowDeleted;
	}

	/**
	 * Método encargado de actualizar el atributo rowDeleted.
	 * @param rowDeleted Nuevo valor para rowDeleted.
	 */
	public void setRowDeleted(boolean rowDeleted) {
		this.rowDeleted = rowDeleted;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + (int) (id ^ (id >>> 32));
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		DownloadStatus other = (DownloadStatus) obj;
		if (id != other.id)
			return false;
		return true;
	}

	@Override
	public String toString() {
		return "DownloadStatus [status=" + status + ", rowDeleted="
				+ rowDeleted + "]";
	}	

}