/*
 * ResponseCodeForPaymentWayDAOImpl
 *  
 * GSI - Integración
 * Creado el: 29/08/2014
 *
 * Copyright (c) A Toda Hora S.A. Todos los derechos reservados
 * 
 * Este software es confidencial y es propietario de ATH, queda prohibido
 * su uso, reproducción y copia de manera parcial o permanente salvo autorización
 * expresa de A Toda Hora S.A o de quién represente sus derechos.
 */
package co.com.ath.pgw.persistence.dao.impl;

import javax.persistence.NoResultException;
import javax.persistence.NonUniqueResultException;
import javax.persistence.Query;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Repository;

import co.com.ath.pgw.persistence.AbstractDAO_JPA;
import co.com.ath.pgw.persistence.dao.ResponseCodeForPaymentWayDAO;
import co.com.ath.pgw.persistence.model.ResponseCodeForPaymentWay;

/**
 * Implementación por defecto de ResponseCodeForPaymentWayDAO
 *
 * @author Andrés Méndez Juanias <proveedor_mamendez@ath.com.co>
 * @version 1.0 29 Ago 2014
 * @since 1.0
 */
@Repository
public class ResponseCodeForPaymentWayDAOImpl 
							extends AbstractDAO_JPA<ResponseCodeForPaymentWay>
							implements ResponseCodeForPaymentWayDAO {
	
	static Logger LOGGER = LoggerFactory.getLogger(ResponseCodeForPaymentWayDAOImpl.class);

	public ResponseCodeForPaymentWayDAOImpl() {
		super(ResponseCodeForPaymentWay.class);
	}

	@Override
	public ResponseCodeForPaymentWay find(Long paymentWayId, String responseCode) {
		ResponseCodeForPaymentWay entity;
		StringBuilder sb = new StringBuilder();
		sb.append(" from ResponseCodeForPaymentWay pw where pw.rowDeleted <> 1 ");
		sb.append(" and pw.paymentWay.id = :paymentWayId");
		sb.append(" and pw.responseCode.code = :responseCode");
		
		Query query = entityManager.createQuery(sb.toString());
		query.setParameter("paymentWayId", paymentWayId);
		query.setParameter("responseCode", responseCode);
		
		try {
			entity = (ResponseCodeForPaymentWay)query.getSingleResult();
		} catch(NoResultException ex){
			LOGGER.info("Error en consulta ResponseCodeForPaymentWay.find({}, {})\n{}", "[paymentWayId="+paymentWayId +",responseCode="+ responseCode+"]",ex.toString());
			//LOGGER.info("Error en consulta ResponseCodeForPaymentWay.find({}, {})\n{}", paymentWayId, responseCode, ex.toString());
			entity = null;
		} catch (NonUniqueResultException ex) {
			LOGGER.info("Error en consulta ResponseCodeForPaymentWay.find({}, {})\n{}","[paymentWayId="+paymentWayId+", responseCode="+responseCode+"]",ex.toString());
			//LOGGER.info("Error en consulta ResponseCodeForPaymentWay.find({}, {})\n{}", paymentWayId, responseCode, ex.toString());
			entity = null;
		}
		return entity;
	}

}
