package co.com.ath.pgw.persistence.dao.impl;

import co.com.ath.pgw.persistence.model.Transaction;

import javax.annotation.Resource;
import javax.transaction.Transactional;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Repository;

import co.com.ath.pgw.persistence.AbstractDAO_JPA;
import co.com.ath.pgw.persistence.dao.ITransaccionQRDAO;
import co.com.ath.pgw.persistence.dao.TransactionDAO;

@Repository
public class TransaccionQRDAOImpl extends AbstractDAO_JPA<Transaction> implements ITransaccionQRDAO {
	private static final Long ID_ESTADO_FALLIDO = 5L;
	private static final String COD_TRANSACCIONES_QR = "QR";
	
	@Resource
	public TransactionDAO transactionDAO;
	
	static Logger LOGGER = LoggerFactory.getLogger(TransaccionQRDAOImpl.class);

	public TransaccionQRDAOImpl() {
		super(Transaction.class);
	}
	
	@Override
	@Transactional
	public void estadoFallido(long pmtId) {
		Transaction transaction = transactionDAO.findByPmtId(pmtId);
		transaction.getStatus().setCode(ID_ESTADO_FALLIDO);
		entityManager.persist(transaction);
	}

	@Override
	@Transactional
	public void identTransaccionQR(long pmtId)  throws Exception{
		try {
			LOGGER.info("idTransaccion: "+pmtId);
			Transaction transaction = transactionDAO.findByPmtId(pmtId);
			transaction.setModalidadPago(COD_TRANSACCIONES_QR);
			entityManager.merge(transaction);
			LOGGER.info("estado actualizado ");
		} catch (Exception e) {
			LOGGER.error("Error actualizando modalidad pago: "+e);
			throw new Exception(e);
		}
	}

	@Override
	@Transactional
	public Transaction findById(long pmtId) {
		LOGGER.info("entro byId: "+pmtId);		
		return  transactionDAO.findByPmtId(pmtId); 
	}
	
	
}
