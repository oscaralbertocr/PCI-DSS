/*
 * BrandDAOImpl
 *  
 * GSI - Integración
 * Creado el: 29/08/2014
 *
 * Copyright (c) A Toda Hora S.A. Todos los derechos reservados
 * 
 * Este software es confidencial y es propietario de ATH, queda prohibido
 * su uso, reproducción y copia de manera parcial o permanente salvo autorización
 * expresa de A Toda Hora S.A o de quién represente sus derechos.
 */
package co.com.ath.pgw.persistence.dao.impl;

import javax.persistence.NoResultException;
import javax.persistence.NonUniqueResultException;
import javax.persistence.Query;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Repository;

import co.com.ath.pgw.persistence.AbstractDAO_JPA;
import co.com.ath.pgw.persistence.dao.BrandDAO;
import co.com.ath.pgw.persistence.model.Bank;
import co.com.ath.pgw.persistence.model.Brand;

/**
 * Implementación por defecto de BrandDAO
 *
 * @author Andrés Méndez Juanias <proveedor_mamendez@ath.com.co>
 * @version 1.0 29 Ago 2014
 * @since 1.0
 */
@Repository
public class BrandDAOImpl extends AbstractDAO_JPA<Brand> implements BrandDAO {

	static Logger LOGGER = LoggerFactory.getLogger(BrandDAOImpl.class);
	
	public BrandDAOImpl() {
		super(Brand.class);
	}

	@Override
	public Brand findByName(String name) {

		StringBuilder hql = new StringBuilder("from Brand b ");
		hql.append("where b.rowDeleted <> 1 ");
		hql.append("and UPPER(b.name) like CONCAT('%',:name,'%') ");
		
        Query query = entityManager.createQuery(hql.toString());
		query.setParameter("name", name);
		
		Brand brand = null;
		
		try {
			brand = (Brand) query.getSingleResult(); 
		} catch (NoResultException e) {
			LOGGER.info("Problemas en query buscando la franquicia: {}", e.toString());
			return null;
		} catch (NonUniqueResultException e){
			LOGGER.warn("Problemas en query buscando la franquicia: {}", e.toString());
            return null;
        }
		return brand;
		
	}

}
