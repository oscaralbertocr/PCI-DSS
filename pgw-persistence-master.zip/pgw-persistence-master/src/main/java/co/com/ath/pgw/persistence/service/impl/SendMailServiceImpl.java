package co.com.ath.pgw.persistence.service.impl;

import java.io.File;
import java.io.FileOutputStream;
import java.text.NumberFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

import javax.annotation.Resource;

import org.apache.commons.validator.routines.UrlValidator;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import co.com.ath.pgw.persistence.dao.BrandDAO;
import co.com.ath.pgw.persistence.dao.TransactionDAO;
import co.com.ath.pgw.persistence.model.Brand;
import co.com.ath.pgw.persistence.model.Transaction;
import co.com.ath.pgw.persistence.service.SendMailService;
import co.com.ath.pgw.util.constants.CoreConstants;
import co.com.ath.pgw.util.constants.PaymentWayCodes;
import co.com.ath.pgw.util.converter.DateUtil;
import co.com.ath.pgw.util.converter.Util;
import co.com.ath.pgw.util.enums.BusinessStatusEnum;
import co.com.ath.pgw.util.enums.MailTypeEnum;
import co.com.ath.pgw.util.enums.TransactionStatusEnum;
import co.com.ath.pgw.util.mail.dto.MailServiceInDTO;
import co.com.ath.pgw.util.mailservice.impl.MailServiceImpl;
import co.com.ath.pgw.util.mask.MaskData;

/**
 * 
 * @PDP-374
 * <strong>Autor</strong>Camilo Bustamante</br>
 * <strong>Descripcion</strong>Envio de correo promocional</br>
 * <strong>Numero de Cambios</strong>1</br>
 * <strong>Identificador corto</strong>C01</br>
 *
 */
@Service
public class SendMailServiceImpl implements SendMailService{
	
	static Logger LOGGER = LoggerFactory.getLogger(SendMailServiceImpl.class);
	
	
	@Resource
	private TransactionDAO transactionDAO;
	
	@Resource
	private MailServiceImpl mailService;
	
	@Resource
    private MaskData maskData;
	
	@Resource
	public BrandDAO brandDAO; 
	
	private Locale locale;
	
	@Value("${pasarela.mail.subject.payment.confirmation}")
	private String subject;
	
	@Value("${pasarela.pse.url}")
	private String paymentURL;
	
	@Value("${pasarela.mail.template.images.url}")
	private String imageRepoURL;
	
	@Value("${pasarela.mail.template.default.header.url}")
	private String defaultHeader;
	
	@Value("${pasarela.mail.template.path}")
	private String tempFiles;
	
	/** Nit Agregador PSE */
	@Value("${pasarela.pse.nitagregador}")
	private String nitAgregator;
	
	/** Nit Agregador Av Villas */
	@Value("${pasarela.pse.nitagregador.avVillas}")
	private String nitAgregatorAvVillas;
	
	/** INICIO-C01 */
	@Value("${pasarela.mail.promo.encendido}")
	private String promoState;
	
	@Value("${pasarela.mail.promo.template.path}")
	private String promoTemplate;
	
	@Value("${pasarela.mail.promo.subject}")
	private String promoSubject;
	
	@Value("${pasarela.mail.promo.template.imagen1}")
	String promoImagen1;
	
	@Value("${pasarela.mail.promo.template.imagen2}")
	String promoImagen2;
	
	@Value("${pasarela.mail.promo.template.imagen3}")
	String promoImagen3;
	
	@Value("${pasarela.mail.promo.template.imagen4}")
	String promoImagen4;
	
	@Value("${pasarela.mail.promo.template.imagen5}")
	String promoImagen5;
	
	@Value("${pasarela.mail.promo.template.imagen6}")
	String promoImagen6;
	/** FIN-C01 */
	
	public SendMailServiceImpl(){
		locale = Locale.getDefault();
	}
	
	private String completePaymentWay(Transaction tx) {
		String paymentWay = "";
		if(tx.getPaymentWay().getId().equals(PaymentWayCodes.PAGOS_AVAL)) {
			paymentWay = tx.getPaymentWay().getName();
		}
		
		if(tx.getPaymentWay().getId().equals(PaymentWayCodes.PSE)) {
			String bankName = tx.getBank() != null ? tx.getBank().getName() : "";
			if(tx.getPaymentWay() == null){
				return bankName;
			}
			paymentWay = tx.getPaymentWay().getName() + " - " + bankName;
		}
		
		if(tx.getPaymentWay().getId().equals(PaymentWayCodes.TC)) {
			if ( null != tx.isGlobalPay() && !tx.isGlobalPay() ) {
				Brand brand = brandDAO.read(Long.valueOf(tx.getIdBrand().toString()));
				paymentWay = "Tarjeta de crédito - "+ brand.getName() + " - " + tx.getCreditCardNumber().substring(9, 16);
			} else {
				paymentWay = "Tarjeta de crédito.";
			}
		}
		
		return paymentWay;
	}
	
	private boolean showAutorizationNumber(Transaction tx) {
		boolean returnValue = true;
		if(tx != null) {
			if(tx.getStatus().getCode().equals(TransactionStatusEnum.CANCELLED.getCode()) 
					|| tx.getStatus().getCode().equals(TransactionStatusEnum.FAILED.getCode())
					|| tx.getStatus().getCode().equals(TransactionStatusEnum.CONFIRMED_NA.getCode()) 
					|| tx.getStatus().getCode().equals(TransactionStatusEnum.EXPIRED.getCode())
					) {
				returnValue = false;
			} else {
				returnValue =  true;
			}
		}
	  return returnValue;
	}
	
	@Override
	public void sendMail(Transaction tx) {
		
		LOGGER.info("Transaccion pmtid {} flagCorreo {}",tx.getPmtId(),tx.getEmailflag());
		if(tx.getPayerMail()==null || tx.getPayerMail().isEmpty()){
			LOGGER.info("No existe correo para la transaccion pmtid: {}", tx.getPmtId());
			return;
		}
		
		// Ingresar argumentos que seran remplazados en el mensaje de email
		Map<String, String> args = new HashMap<String, String>();
		//Verifica si es pago PSE y si es convenio modelo agregador para retornar el NIT
		args.put("fullIdentification", transactionDAO.getAggregatorNit(tx,nitAgregator,nitAgregatorAvVillas));
        //args.put("fullIdentification", tx.getCommerce().getNit().toString());
		args.put("fullName", tx.getCommerce().getSubscription().getCompanyName());
		args.put("completePaymentWay", completePaymentWay(tx));
		args.put("transactioDate", new SimpleDateFormat(CoreConstants.DISPLAY_DATE_FORMAT).format(tx.getTransactionDate()));
		args.put("transactionId", tx.getPmtId().toString());
		args.put("businessState", tx.getStatus().getBusinessCode().getDescription().toString());
		/**INICIO-C01 */
		try {
			if(tx.getInvoiceReferen2() != null 
					&& !tx.getInvoiceReferen2().isEmpty()) {
				String[] references = null;
				String ab = "";
				args.put("inicio2", "<!-- ");
				args.put("fin2", " -->");
				List<String> myListReferences = new ArrayList<String>(Arrays.asList(tx.getInvoiceReferen2().split(CoreConstants.SEPARATOR_MULTIPLES_REFERENCIAS)));
				for(String refes : myListReferences){
					references = refes.split(CoreConstants.SEPARATOR_MULTIPLES_REFERENCIAS_VALOR);
					ab += references[0] + ":" + references[1] + "<br/>";
				}
				args.put("references", ab);
				args.put("description", tx.getDescription());
				LOGGER.info("String ab final: ", ab);
			}else{
				args.put("inicio2", "<!-- ");
				args.put("fin2", " -->");
				args.put("description", tx.getDescription());
				args.put("references", "");
			}
		} catch (Exception e) {
			LOGGER.info("Error al obtener referencia 2 REFERENCE2: {}", tx.getInvoiceReferen2());
		}
		/**FIN-C01 */
		args.put("totalValue", NumberFormat.getCurrencyInstance(locale).format(tx.getTotalValue().doubleValue()));
		args.put("autorizationNumber", tx.getApprovalNumber());
		args.put("paymentURL", paymentURL+"?pmtId="+tx.getPmtId());
		args.put("imageRepoURL", imageRepoURL );
//		args.put("bankName", tx.getBank().getName());
		args.put("bankName", tx.getBank() != null ? tx.getBank().getName() : "");
		args.put("curCode", tx.getCurrency() != null ? tx.getCurrency() : "");
		args.put("transactionIp", tx.getIpAddress() != null ? tx.getIpAddress() : "");

		String imgDefault1 = "";
		String imgDefault2 = "";
		String imgTaquilla1 = "<!-- ";
		String imgTaquilla2 = " -->";
		
		List<File> fileList = null;
		String headerImg = defaultHeader;

		//Imagen del header para Taquillas
		if( tx.getPlantilla() == CoreConstants.TAQUILLA_ON ){
			
			imgDefault1 = "<!-- ";
			imgDefault2 = " -->";
			imgTaquilla1 = "";
			imgTaquilla2 = "";
			
			String urlLogo = new String(tx.getUrlLogo());
			
			UrlValidator urlValidator = new UrlValidator();
			if (urlValidator.isValid(urlLogo)) {
				headerImg = urlLogo;
			} else {
				
				fileList = new ArrayList<File>();
				FileOutputStream fileSt = null;
				
				try {
					
					String base64Image = urlLogo.split(",")[1];
					byte[] imageByte = javax.xml.bind.DatatypeConverter.parseBase64Binary(base64Image);
					
					headerImg = "PmtId_"+tx.getPmtId().toString()+".jpg";
					String fileUrl = tempFiles
							+ CoreConstants.SEPARADOR + "temp"
							+ CoreConstants.SEPARADOR  + headerImg;
					
					File headerLogo = new File(fileUrl);
					headerLogo.deleteOnExit();
					
					fileSt = new FileOutputStream(headerLogo);
					fileSt.write(imageByte);
					
					fileList.add(headerLogo);
				} catch (Exception e) {
					LOGGER.error("pmtid: {} No fue posible crear el archivo: {}", tx.getPmtId(), urlLogo);
					LOGGER.error(e.getLocalizedMessage());
					headerImg = defaultHeader;
				}finally{
					if(null!=fileSt)
						Util.safeClose(fileSt); // Correccion de hallazgo Fortify
				}
				
			}
			
		}
		
		//Ventanilla de Pagos
		args.put("imgDefault1", imgDefault1);
		args.put("imgDefault2", imgDefault2);
		args.put("imgTaquilla1", imgTaquilla1);
		args.put("imgTaquilla2", imgTaquilla2);
		args.put("headerLogo", headerImg);
		args.put("footerLogo", tx.getTaquilla().getFooter());
		args.put("style", mailService.getEmailCSS(tx.getTaquilla().getCss()));
		
		// muestra el nÃºmero de autorizacion si la transaccion no es fallida o cancelada
		if(showAutorizationNumber(tx)){
			args.put("lblAutorizationNumber", tx.getApprovalNumber() != null ? CoreConstants.LBL_AUTORIZATION_NUMBER : CoreConstants.LBL_EMPTY_AUTORIZATION_NUMBER);
		} else {
			args.put("lblAutorizationNumber", CoreConstants.LBL_EMPTY_AUTORIZATION_NUMBER);
			args.remove("autorizationNumber");
			args.put("autorizationNumber", "");
		}
		
		if(tx.getOrderNumber() != null && tx.getOrderNumber().length() > 0) {
			args.put("inicio1", "");
			args.put("fin1", "");
			/** INICIO-C01 **/
			if (tx.getTokenized() != null) {

				args.put("invoiceReference1",
						tx.getOrderNumber() != null ? maskData.getTruncateData(tx.getOrderNumber()) : "");
			} else {
				args.put("invoiceReference1", tx.getOrderNumber() != null ? tx.getOrderNumber() : "");
			}
			/** FIN-C01 **/	
			
		} else {
			args.put("inicio1", "<!-- ");
			args.put("fin1", " -->");
		}

		if(tx.getInvoiceReferen3() != null && tx.getInvoiceReferen3().length() > 0) {
			args.put("inicio3", "");
			args.put("fin3", "");
			args.put("invoiceReference3", tx.getInvoiceReferen3() != null ? tx.getInvoiceReferen3() : "");
		} else {
			args.put("inicio3", "<!-- ");
			args.put("fin3", " -->");
		}
		
		if(tx.getInvoiceReferen4() != null && tx.getInvoiceReferen4().length() > 0) {
			args.put("inicio4", "");
			args.put("fin4", "");
			args.put("invoiceReference4", tx.getInvoiceReferen4() != null ? tx.getInvoiceReferen4() : "");
		} else {
			args.put("inicio4", "<!-- ");
			args.put("fin4", " -->");
		}
		
		// Parametros de entrada para enviar el email		
		MailServiceInDTO mailInDTO = new MailServiceInDTO();
		mailInDTO.setTo(tx.getPayerMail());
		mailInDTO.setSubject(subject);
		mailInDTO.setArgs(args);
		mailInDTO.setMailTypeEnum(MailTypeEnum.CONFIRMATION_HTML);
		
		if( null!=fileList && !fileList.isEmpty() )
			mailInDTO.setAttachmentList(fileList);
		
		try {
			mailService.send(mailInDTO, null);
			LOGGER.info("Se envio correo para la transaccion pmtid:{} Proceso:{}", tx.getPmtId(),tx.getJobLockId());
		} catch (Exception ex) {
			// Se controla excepcion general debido a la cantidad posible
			// de excepciones que puede generar este mÃ©todo.
			LOGGER.info("Fallo el envio del correo de la transaccion {}:\n {}", tx.getPmtId(), ex);
		}
	}

	/** INICIO-C01 */
	/**
	 * Se encarga de enviar correo promocional para BAVV.
	 */
	@Override
	public void sendPromoMail(Transaction tx) {
		
		// Valida si esta encendido el envio de correo promocional
		if(CoreConstants.ONE.equals(promoState)) {
			
			// Valida si la transaccion fue aprobada
			if( BusinessStatusEnum.APROBADA.getCode() == tx.getStatus().getBusinessCode().getCode() ) {

				// Valida si la tx ya cuenta con un banco recaudador.
				if(null!=tx.getBankCollecter() && null!=tx.getBankCollecter().getId()) {
					if(tx.getEmailflagprom()== null || tx.getEmailflagprom()==0 ) {
						// Valida si el banco recaudador es BAVV
						if(tx.getBankCollecter().getId().toString().equals(CoreConstants.ONE)) {
							
							// Argumentos a pasar al template del email.
							Map<String, String> args = new HashMap<String, String>();
							args.put("beneficiario", tx.getCustomerName());
							args.put("pagador", tx.getPayerName());
							args.put("transactionId", tx.getPmtId().toString());
							args.put("fecha", DateUtil.parseDate(tx.getTransactionDate(),"dd/MM/yyyy"));
							args.put("hora", DateUtil.parseDate(tx.getTransactionDate(),"hh:mm:ss aa"));
							
							// Parametros para enviar el email		
							MailServiceInDTO mailInDTO = new MailServiceInDTO();
							mailInDTO.setTo(tx.getPayerMail());
							mailInDTO.setSubject(promoSubject);
							mailInDTO.setArgs(args);
							
							Map<String, String> imagenes = new LinkedHashMap<String, String>();
							imagenes.put("imagen1", promoImagen1);
							imagenes.put("imagen2", promoImagen2);
							imagenes.put("imagen3", promoImagen3);
							imagenes.put("imagen4", promoImagen4);
							imagenes.put("imagen5", promoImagen5);
							imagenes.put("imagen6", promoImagen6);
							
							try {
								LOGGER.info("Pmtid:{} enviando correo promocional. JobLockId:{}", tx.getPmtId(),tx.getJobLockId());
								mailService.send(mailInDTO, promoTemplate, imagenes);
								LOGGER.info("Pmtid:{} se envio correo promocional. JobLockId:{}", tx.getPmtId(),tx.getJobLockId());
							tx.setEmailflagprom(1);
							transactionDAO.update(tx);
							} catch (Exception ex) {
								LOGGER.error("Pmtid:{} fallo el envio del correo promocional\n{}", tx.getPmtId(), ex);
							}
							
						}else {
							if(null!=tx.getBankCollecter().getName())
								LOGGER.info("Pmtid:{}, BancoRecaudador:{}. No se enviara correo promocional.", 
									tx.getPmtId(), tx.getBankCollecter().getName());
							else
								LOGGER.info("Pmtid:{}, IdBancoRecaudador:{}. No se enviara correo promocional.", 
										tx.getPmtId(), tx.getBankCollecter().getId());
						}	
					}else {
						LOGGER.info("Pmtid:{}, IdBancoRecaudador:{} Ya fue enviando previamente el correo promocional.", 
								tx.getPmtId(), tx.getBankCollecter().getId());
					}
					
				} else {
					LOGGER.error("Pmtid:{} aun no cuenta con banco recaudador para el envio "
							+ "de correo promocional.", tx.getPmtId());
				}
			}
		}
	}
	/** FIN-C01 */
	
}
