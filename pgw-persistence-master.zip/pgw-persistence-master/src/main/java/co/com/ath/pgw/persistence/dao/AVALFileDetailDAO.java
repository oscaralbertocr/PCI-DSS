/*
 * AVALFileDetailDAO
 *
 * GSI - Integración
 * Creado el: 22 de agosto de 2014
 *
 * Copyright (c) A Toda Hora S.A. Todos los derechos reservados
 *
 * Este software es confidencial y es propietario de ATH, queda prohibido
 * su uso, reproducción y copia de manera parcial o permanente salvo autorización
 * expresa de A Toda Hora S.A o de quién represente sus derechos.
 */
package co.com.ath.pgw.persistence.dao;

import co.com.ath.pgw.persistence.DataAccessObject;
import co.com.ath.pgw.persistence.model.AVALFileDetail;

/**
 * Objeto de Acceso a Datos para las entidades AVALFileDetailDAO
 * 
 * @author Andrés Méndez <proveedor_mamendez@ath.com.co>
 * @version 1.0
 * @since 1.0
 */
public interface AVALFileDetailDAO extends DataAccessObject<AVALFileDetail>{

}
