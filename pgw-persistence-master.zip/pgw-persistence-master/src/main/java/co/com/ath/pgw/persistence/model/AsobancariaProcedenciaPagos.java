/*
 * AsobancariaProcedenciaPagos
 *  
 * GSI - Integración
 * Creado el: 24/07/2017
 *
 * Copyright (c) A Toda Hora S.A. Todos los derechos reservados
 * 
 * Este software es confidencial y es propietario de ATH, queda prohibido
 * su uso, reproducción y copia de manera parcial o permanente salvo autorización
 * expresa de A Toda Hora S.A o de quién represente sus derechos.
 */
package co.com.ath.pgw.persistence.model;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import co.com.ath.pgw.persistence.PersistentObject;

import javax.persistence.Temporal;
import javax.persistence.TemporalType;


/**
 * Representa un tipo de procedencia de Pagos de Asobancaria 
 * Esta entidad pertenece al modelo persistente.
 * 
 * @author Camilo Andres Bustamante
 * @version 1.0 24 Jul 2017
 * @since 1.0
 *
 */


@Entity
@Table(name="ASOBANCARIA_PROCEDENCIAPAGOS")
public class AsobancariaProcedenciaPagos implements PersistentObject {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1749966843777969638L;

	/**
	 * Identificador del tipo de procedencia de pago.
	 */
	@Id
    @Column(name = "ID")
	private Long id;
	
	/**
	 * Nombre o descripción del tipo de procedencia de pago.
	 */
	@Column(name="PROCEDENCIAPAGOS")
	private String procedenciaPagos;	
		
	/**
	 * Fecha de creación del registro
	 */
	@Temporal(TemporalType.TIMESTAMP)
	@Column(name="REGFECHACREACION")
	private Date rowCreationDate;
	
	/**
	 * Fecha de última modificación del registro
	 */
	@Temporal(TemporalType.TIMESTAMP)
	@Column(name="REGFECHAMODIFICACION", nullable=true)
	private Date rowLastUpdate;
	
	/**
	 * Indica si el registro tiene marca lógica de borrado
	 */
	@Column(name="REGELIMINADO", nullable=true)
	private boolean rowDeleted;
	
	/**
	 * Construye un tipo de procedencia de pago vacio.
	 */
	public AsobancariaProcedenciaPagos(){
		super();
	}
	
	/**
	 * Construye un tipo de procedencia de pago especificando el identificador.
	 * 
	 * @param id Identificador del tipo de procedencia de pago.
	 */
	AsobancariaProcedenciaPagos(Long id){
		this.id = id;
	}
	
	/**
	 * Retorna el identificador del tipo de procedencia de pago.
	 * 
	 * @return Identificador del tipo de procedencia de pago.
	 */
	public Long getId() {
		return id;
	}

	public String getProcedenciaPagos() {
		return procedenciaPagos;
	}

	public void setProcedenciaPagos(String procedenciaPagos) {
		this.procedenciaPagos = procedenciaPagos;
	}

	/**
	 * Establece el identificador del tipo de procedencia de pago.
	 * 
	 * @param id Identificador del tipo de procedencia de pago.
	 */
	public void setId(Long id) {
		this.id = id;
	}

	@Override
	public boolean isRowDeleted() {
		return rowDeleted;
	}

	@Override
	public void setRowDeleted(boolean rowDeleted) {
		this.rowDeleted = rowDeleted;
		
	}

	@Override
	public Date getRowCreationDate() {
		return rowCreationDate;
	}

	@Override
	public void setRowCreationDate(Date rowCreationDate) {
		this.rowCreationDate = rowCreationDate;
	}

	@Override
	public Date getRowLastUpdate() {
		return rowLastUpdate;
	}

	@Override
	public void setRowLastUpdate(Date rowLastUpdate) {
		this.rowLastUpdate = rowLastUpdate;
	}
	
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + (int) (id ^ (id >>> 32));
		return result;
	}


	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		AsobancariaProcedenciaPagos other = (AsobancariaProcedenciaPagos) obj;
		if (id != other.id)
			return false;
		return true;
	}

	@Override
	public String toString() {
		return "AsobancariaProcedenciaPagos [id=" + id + ", procedenciaPagos=" + procedenciaPagos + ", rowDeleted="
				+ rowDeleted + "]";
	}


}