/*
 * BatchJobExecutionParams
 *  
 * GSI - Integración
 * Creado el: 23/05/2018
 *
 * Copyright (c) A Toda Hora S.A. Todos los derechos reservados
 * 
 * Este software es confidencial y es propietario de ATH, queda prohibido
 * su uso, reproducción y copia de manera parcial o permanente salvo autorización
 * expresa de A Toda Hora S.A o de quién represente sus derechos.
 */
package co.com.ath.pgw.persistence.model;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

/**
 * Clase que representa los parametros de ejecución del JOB.
 * 
 * @author Andrés Eduardo Hernandez <andres.hernandez@sophossolutions.com>
 * @version 23/05/2018
 * @since 1.0
 */
@Entity
@Table(name="BATCH_JOB_EXECUTION_PARAMS")
public class BatchJobExecutionParams implements Serializable {

	/**
	 * ID de serialización.
	 */
	private static final long serialVersionUID = 145510001068911001L;

	@Id
	@Column(name="JOB_EXECUTION_ID", nullable=true)
	private String jobExecutionId;
	
	@Column(name="TYPE_CD", nullable=true)
	private String typeCd;
	
	@Column(name="KEY_NAME", nullable=true)
	private String keyName;
	
	@Column(name="STRING_VAL", nullable=false)
	private String stringVal;
	
	@Column(name="DATE_VAL", nullable=false)
	@Temporal(TemporalType.TIMESTAMP)
	private Date dateVal;
	
	@Column(name="LONG_VAL", nullable=false)
	private Long longVal;
	
	@Column(name="DOUBLE_VAL", nullable=false)
	private Long dubleVal;
	
	@Column(name="IDENTIFYING", nullable=false)
	private String indentifying;
	
	/**
	 * Constructor por defecto de un Banco
	 */
	public BatchJobExecutionParams(){
		super();
	}

	/**
	 * Método encargado de recuperar el valor del atributo batchJobExecution.
	 * @return El atributo batchJobExecution asociado a la clase.
	 */
	public String getJobExecutionId() {
		return jobExecutionId;
	}

	/**
	 * Método encargado de actualizar el atributo batchJobExecution.
	 * @param batchJobInstance Nuevo valor para batchJobExecution.
	 */
	public void setJobExecutionId(String jobExecutionId) {
		this.jobExecutionId = jobExecutionId;
	}

	/**
	 * Método encargado de recuperar el valor del atributo typeCd
	 * @return El valor de typeCd
	 */
	public String getTypeCd() {
		return typeCd;
	}

	/**
	 * Método encargado de actualizar el atributo typeCd.
	 * @param typeCd Nuevo valor para typeCd.
	 */
	public void setTypeCd(String typeCd) {
		this.typeCd = typeCd;
	}

	/**
	 * Método encargado de recuperar el valor del atributo keyName
	 * @return El valor de keyName
	 */
	public String getKeyName() {
		return keyName;
	}

	/**
	 * Método encargado de actualizar el atributo keyName.
	 * @param keyName Nuevo valor para keyName.
	 */
	public void setKeyName(String keyName) {
		this.keyName = keyName;
	}

	/**
	 * Método encargado de recuperar el valor del atributo stringVal
	 * @return El valor de stringVal
	 */
	public String getStringVal() {
		return stringVal;
	}

	/**
	 * Método encargado de actualizar el atributo stringVal.
	 * @param stringVal Nuevo valor para stringVal.
	 */
	public void setStringVal(String stringVal) {
		this.stringVal = stringVal;
	}

	/**
	 * Método encargado de recuperar el valor del atributo dateVal
	 * @return El valor de dateVal
	 */
	public Date getDateVal() {
		return dateVal;
	}

	/**
	 * Método encargado de actualizar el atributo dateVal.
	 * @param dateVal Nuevo valor para dateVal.
	 */
	public void setDateVal(Date dateVal) {
		this.dateVal = dateVal;
	}

	/**
	 * Método encargado de recuperar el valor del atributo longVal
	 * @return El valor de longVal
	 */
	public Long getLongVal() {
		return longVal;
	}

	/**
	 * Método encargado de actualizar el atributo longVal.
	 * @param longVal Nuevo valor para longVal.
	 */
	public void setLongVal(Long longVal) {
		this.longVal = longVal;
	}

	/**
	 * Método encargado de recuperar el valor del atributo dubleVal
	 * @return El valor de dubleVal
	 */
	public Long getDubleVal() {
		return dubleVal;
	}

	/**
	 * Método encargado de actualizar el atributo dubleVal.
	 * @param dubleVal Nuevo valor para dubleVal.
	 */
	public void setDubleVal(Long dubleVal) {
		this.dubleVal = dubleVal;
	}

	/**
	 * Método encargado de recuperar el valor del atributo indentifying
	 * @return El valor de indentifying
	 */
	public String getIndentifying() {
		return indentifying;
	}

	/**
	 * Método encargado de actualizar el atributo indentifying.
	 * @param indentifying Nuevo valor para indentifying.
	 */
	public void setIndentifying(String indentifying) {
		this.indentifying = indentifying;
	}
}