/*
 * CommerceRoleContact
 *  
 * GSI - Integración
 * Creado el: 28/08/2014
 *
 * Copyright (c) A Toda Hora S.A. Todos los derechos reservados
 * 
 * Este software es confidencial y es propietario de ATH, queda prohibido
 * su uso, reproducción y copia de manera parcial o permanente salvo autorización
 * expresa de A Toda Hora S.A o de quién represente sus derechos.
 */
package co.com.ath.pgw.persistence.model;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import co.com.ath.pgw.persistence.PersistentObject;

import javax.persistence.Temporal;
import javax.persistence.TemporalType;

/**
 * Clase que representa un rol válido para los contactos de un comercio. Esta es
 * una entidad del modelo persistente. 
 * 
 * @author proveedor_japiza
 * @version 1.0 29 Ago 2014
 * @since 1.0
 *
 */
@Entity
@Table(name="ROLESCONTACTOSCOMERCIO")
public class CommerceRoleContact implements PersistentObject {

	/**
	 * 
	 */
	private static final long serialVersionUID = 2601963231153530926L;

	/**
	 * Identificador único del rol
	 */
	@Id
    @Column(name = "ID")
	private Long id;

	/**
	 * Nombre del rol
	 */
	@Column(name="ROL")
	private String name;

	/**
	 * Indica si el registro tiene marca lógica de borrado
	 */
	@Column(name="REGELIMINADO", nullable=true)
	private boolean rowDeleted;
	
	/**
	 * Fecha de creación del registro
	 */
	@Temporal(TemporalType.TIMESTAMP)
	@Column(name="REGFECHACREACION", nullable=true)
	private Date rowCreationDate;
	
	/**
	 * Fecha de última modificación del registro
	 */
	@Temporal(TemporalType.TIMESTAMP)
	@Column(name="REGFECHAMODIFICACION", nullable=true)
	private Date rowLastUpdate;

	/**
	 * Construye un rol para un contacto de un comercio.
	 */
	public CommerceRoleContact(){
		super();
	}
	
	/**
	 * Construye un rol para un contacto de un comercio, especificando el
	 * identificador del rol.
	 * 
	 * @param id Identifidador del rol.
	 */
	CommerceRoleContact(Long id){
		super();
	}

	/**
	 * Retorna el Identificador único del rol.
	 * 
	 * @return Identificador único del rol
	 */
	public Long getId() {
		return id;
	}

	/**
	 * Establece el identificador único del rol
	 * 
	 * @param id Identificador único del rol
	 */
	public void setId(Long id) {
		this.id = id;
	}

	/**
	 * Retorna el nombre del rol.
	 * 
	 * @return Nombre del rol.
	 */
	public String getName() {
		return name;
	}

	/**
	 * Establece el nombre del rol.
	 * 
	 * @param name Nombre del rol.
	 */
	public void setName(String name) {
		this.name = name;
	}

	@Override
	public boolean isRowDeleted() {
		return rowDeleted;
	}

	@Override
	public void setRowDeleted(boolean rowDeleted) {
		this.rowDeleted = rowDeleted;
	}

	@Override
	public Date getRowCreationDate() {
		return rowCreationDate;
	}

	@Override
	public void setRowCreationDate(Date rowCreationDate) {
		this.rowCreationDate = rowCreationDate;
	}

	@Override
	public Date getRowLastUpdate() {
		return rowLastUpdate;
	}

	@Override
	public void setRowLastUpdate(Date rowLastUpdate) {
		this.rowLastUpdate = rowLastUpdate;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + (int) (id ^ (id >>> 32));
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		CommerceRoleContact other = (CommerceRoleContact) obj;
		if (id != other.id)
			return false;
		return true;
	}

	@Override
	public String toString() {
		return "CommerceRoleContact [name=" + name + ", rowDeleted="
				+ rowDeleted + "]";
	}

}