/*
 * BusinessStatusValidator
 *  
 * GSI - Integración
 * Creado el: 22/04/2015
 *
 * Copyright (c) A Toda Hora S.A. Todos los derechos reservados
 * 
 * Este software es confidencial y es propietario de ATH, queda prohibido
 * su uso, reproducción y copia de manera parcial o permanente salvo autorización
 * expresa de A Toda Hora S.A o de quién represente sus derechos.
 */
package co.com.ath.pgw.persistence.validation.model.impl;

import java.util.Locale;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import co.com.ath.pgw.util.enums.BusinessStatusEnum;
import co.com.ath.pgw.util.i18n.BundleKeys;
import co.com.ath.pgw.util.i18n.BundleType;
import co.com.ath.pgw.util.validation.AbstractAttributeValidator;
import co.com.ath.pgw.util.validation.ErrorCode;
import co.com.ath.pgw.util.validation.NotEmptyValidator;
import co.com.ath.pgw.util.validation.NotNullValidator;
import co.com.ath.pgw.util.validation.ObjectValidationException;
import co.com.ath.pgw.util.validation.ObjectValidator;
import co.com.ath.pgw.util.validation.ValidationException;
/**
 * Class description goes here...
 *
 * @author Andrés Méndez Juanias <proveedor_mamendez@ath.com.co> 
 * @version 1.0 22/04/2015
 * @since 1.0
 */
@Service
public class BusinessStatusValidator extends AbstractAttributeValidator {

	static Logger LOGGER = LoggerFactory.getLogger(BusinessStatusValidator.class);
	
	private ObjectValidator validator;
	
	
	@Override
	protected void doMandatoryValidate(Object attribute, Locale locale)
			throws ValidationException {
		validator = new NotNullValidator(new NotEmptyValidator());
		validator.setBundleManager(bundleManager);
		
		try {
			validator.validate(attribute, locale);
		} catch (ObjectValidationException e) {
			ValidationException vex = new ValidationException(getMessage(locale), ErrorCode.INVALID_BUSINES_STATUS, e);
			LOGGER.warn("Fallo el validador: \n{}", vex.toString());
			throw vex;
		}
		doOptionalValidate(attribute, locale);
	}

	@Override
	protected void doOptionalValidate(Object attribute, Locale locale)
			throws ValidationException {
		// Validar que no sea nulo
		if(attribute != null && !attribute.toString().isEmpty()){
			String state = attribute.toString();
			for(BusinessStatusEnum bEnum : BusinessStatusEnum.values()){
				if(state.equalsIgnoreCase(bEnum.name())){
					return;
				}
			}
			ValidationException vex = new ValidationException(
					getMessage(locale), ErrorCode.INVALID_BUSINES_STATUS,
					buildNotFoundException(locale, state));
			LOGGER.warn("Fallo el validador: \n{}", vex.toString());
			throw vex;
		}

	}
	
	private Throwable buildNotFoundException(Locale locale, String state) {
		String message = "validation.28.notfound";
		if (bundleManager != null) {
			bundleManager.setBundle(BundleType.ERRORS);
			message = bundleManager.getMessage(
					message, new Object[]{state}, locale);
		}
		return new ObjectValidationException(message);
	}

	private String getMessage(Locale locale) {
		if (bundleManager == null) {
			return BundleKeys.ERROR_INVALID_BUSINESS_STATUS;
		}
		bundleManager.setBundle(BundleType.ERRORS);
		return bundleManager.getMessage(
				BundleKeys.ERROR_INVALID_BUSINESS_STATUS, null, locale);
	}

}
