/*
 * ModTransactionInfoValidatorImpl
 *  
 * GSI - Integración
 * Creado el: 23/09/2014
 *
 * Copyright (c) A Toda Hora S.A. Todos los derechos reservados
 * 
 * Este software es confidencial y es propietario de ATH, queda prohibido
 * su uso, reproducción y copia de manera parcial o permanente salvo autorización
 * expresa de A Toda Hora S.A o de quién represente sus derechos.
 */
package co.com.ath.pgw.persistence.validation.model.impl;

import java.util.Date;
import java.util.Locale;

import javax.annotation.Resource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import co.com.ath.pgw.bsn.dto.in.ModTransactionInfoInDTO;
import co.com.ath.pgw.util.i18n.ResourceBundleManager;
import co.com.ath.pgw.util.validation.ValidationException;
import co.com.ath.pgw.util.validation.model.ModTransactionInfoValidator;


/**
 * Implementación por defecto del validador ModTransactionInfoValidator.
 *
 * @author Andrés Méndez Juanias <proveedor_mamendez@ath.com.co> 
 * @version 1.0 23/09/2014
 * @since 1.0
 */
@Service
public class ModTransactionInfoValidatorImpl implements
		ModTransactionInfoValidator {
	
	@Autowired
	private ResourceBundleManager bundleManager;
	
	@Resource
	private TrxSourceValidator sourceValidator;
	
	@Resource
	private RqDateValidator dateValidator;
	
	@Resource
	private IPAddressValidator ipAddressValidator;
	
	@Resource
	private TransactionIdValidator transactionIdValidator;
	
	@Resource
	private TransactionPmtIdValidator transactionPmtIdValidator;
	
	private Locale locale;
	
	public ModTransactionInfoValidatorImpl() {
		this.locale = Locale.getDefault();
	}

	@Override
	public void validate(ModTransactionInfoInDTO inDTO)
			throws ValidationException {
		validateChannelSource(inDTO.getTransactionBO().getSource().getId());
        validateRqDate(inDTO.getClientDt());
        validateIpAddress(inDTO.getIpAddr());
        validateTransactionPmtId(inDTO.getTransactionBO().getPmtId());
	}
	
	/**
     * Realiza la validación de un canal de origen.
     * 
     * @param channelId Canal de origen.
     * @throws ValidationException 
     */
    private void validateChannelSource(String channelId) 
    												throws ValidationException {
    	sourceValidator.setMandatory(true);
		sourceValidator.setBundleManager(bundleManager);
		sourceValidator.validate(channelId, locale);
		
	}

    /**
     * Realiza la validación de la fecha de solicitud.
     * 
     * @param clientDt				Fecha de solicitud.
     * @throws ValidationException	Si no supera las validaciones.
     */
	private void validateRqDate(Date clientDt) throws ValidationException {
		dateValidator.setMandatory(true);
		dateValidator.setBundleManager(bundleManager);
		dateValidator.validate(clientDt, locale);
	}

	/**
	 * Realiza la validación de la dirección IP origen de la transacción.
	 * 
	 * @param ipAddr 				Dirección ip origen.
	 * @throws ValidationException 	Si no supera las validaciones.
	 */
	private void validateIpAddress(String ipAddr) throws ValidationException {
		ipAddressValidator.setMandatory(true);
		ipAddressValidator.setBundleManager(bundleManager);
		ipAddressValidator.validate(ipAddr, locale);
	}
	
	/**
	 * Realiza la validación del pmtId de la transacción.
	 * 
	 * @param pmtid
	 *            pmtId de la transacción.
	 * @throws ValidationException
	 *             En caso que falle la validación.
	 */
	private void validateTransactionPmtId(String pmtId) throws ValidationException {
		transactionPmtIdValidator.setMandatory(true);
		transactionPmtIdValidator.setBundleManager(bundleManager);
		transactionPmtIdValidator.validate(pmtId, locale);
	}

}
