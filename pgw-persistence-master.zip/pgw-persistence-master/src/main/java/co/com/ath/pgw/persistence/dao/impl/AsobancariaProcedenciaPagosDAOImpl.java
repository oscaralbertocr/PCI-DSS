/*
 * AsobancariaProcedenciaPagosDAOImpl
 *  
 * GSI - Integración
 * Creado el: 24/07/2017
 *
 * Copyright (c) A Toda Hora S.A. Todos los derechos reservados
 * 
 * Este software es confidencial y es propietario de ATH, queda prohibido
 * su uso, reproducción y copia de manera parcial o permanente salvo autorización
 * expresa de A Toda Hora S.A o de quién represente sus derechos.
 */
package co.com.ath.pgw.persistence.dao.impl;

import javax.persistence.NoResultException;
import javax.persistence.Query;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Repository;

import co.com.ath.pgw.persistence.AbstractDAO_JPA;
import co.com.ath.pgw.persistence.dao.AsobancariaProcedenciaPagosDAO;
import co.com.ath.pgw.persistence.model.AsobancariaProcedenciaPagos;

/**
 * Implementación por defecto de AsobancariaProcedenciaPagosDAO
 *
 * @author Camilo Andres Bustamante <proveedor_cbustamant@ath.com.co>
 * @version 1.0 24 Jul 2017
 * @since 1.0
 */
@Repository
public class AsobancariaProcedenciaPagosDAOImpl 
			extends AbstractDAO_JPA<AsobancariaProcedenciaPagos> implements AsobancariaProcedenciaPagosDAO {

	static Logger LOGGER = LoggerFactory.getLogger(AsobancariaProcedenciaPagosDAOImpl.class);
	
	public AsobancariaProcedenciaPagosDAOImpl() {
		super(AsobancariaProcedenciaPagos.class);
	}
	
	@Override
	public AsobancariaProcedenciaPagos findByType(String procedenciaPagos) {
		
		StringBuilder sb = new StringBuilder("from AsobancariaProcedenciaPagos a ");
		sb.append("where a.procedenciaPagos like :procedenciaPagos ");

		Query query = entityManager.createQuery(sb.toString());
		query.setParameter("procedenciaPagos", "%"+procedenciaPagos+"%");

		AsobancariaProcedenciaPagos procedencia = null;

		try {
			procedencia = (AsobancariaProcedenciaPagos) query.getSingleResult();
		} catch (NoResultException e) {
			LOGGER.info("No hay resultados en la consulta de tipos de procedencia de Pagos de Asobancaria PROCEDENCIAPAGOS: {}", type);
			return procedencia;
		} catch (Exception ex) {
			LOGGER.warn("Problemas en query {}", ex);
			return procedencia;
		}
		return procedencia;
		
	}

}
