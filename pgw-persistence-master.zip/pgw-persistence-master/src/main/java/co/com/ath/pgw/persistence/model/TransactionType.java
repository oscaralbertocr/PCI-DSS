/*
 * TransactionType
 *  
 * GSI - Integración
 * Creado el: 29/08/2014
 *
 * Copyright (c) A Toda Hora S.A. Todos los derechos reservados
 * 
 * Este software es confidencial y es propietario de ATH, queda prohibido
 * su uso, reproducción y copia de manera parcial o permanente salvo autorización
 * expresa de A Toda Hora S.A o de quién represente sus derechos.
 */
package co.com.ath.pgw.persistence.model;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import co.com.ath.pgw.persistence.PersistentObject;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

/**
 * Representa un tipo de transacción. Esta entidad pertenece al modelo
 * persistente.
 *  
 * @author proveedor_japiza
 * @version 1.0 19 Ago 2014
 * @since 1.0
 */
@Entity
@Table(name="TIPOSTRANSACCION")
public class TransactionType implements PersistentObject {

	/**
	 * 
	 */
	private static final long serialVersionUID = -8969815354219635761L;

	/**
	 * Identificador del tipo de transacción.
	 */
	@Id
    @Column(name = "ID")
	private Long id;
	
	/**
	 * Descripción del tipo de transacción.
	 */
	@Column(name="TIPOTRANSACCION")
	private String description;
	
	/**
	 * Indica si el registro tiene marca lógica de borrado
	 */
	@Column(name="REGELIMINADO", nullable=true)
	private boolean rowDeleted;
	
	/**
	 * Fecha de creación del registro
	 */
	@Temporal(TemporalType.TIMESTAMP)
	@Column(name="REGFECHACREACION", nullable=true)
	private Date rowCreationDate;
	
	/**
	 * Fecha de última modificación del registro
	 */
	@Temporal(TemporalType.TIMESTAMP)
	@Column(name="REGFECHAMODIFICACION", nullable=true)
	private Date rowLastUpdate;


	/**
	 * Construye un tipo de transacción.
	 */
	public TransactionType(){
		super();
	}
	
	/**
	 * Construye un tipo de transacción especificando el identificador.
	 * 
	 * @param id Identificador del tipo de transacción.
	 */
	TransactionType(Long id){
		this.id = id;
	}
	
	/**
	 * Retorna el identificador del tipo de transacción.
	 * 
	 * @return Identificador del tipo de transacción.
	 */
	public Long getId() {
		return id;
	}

	/**
	 * Establece el identificador del tipo de transacción.
	 * 
	 * @param id Identificador del tipo de transacción.
	 */
	public void setId(Long id) {
		this.id = id;
	}

	/**
	 * Retorna la descripción del tipo de transacción.
	 * 
	 * @return Descripción del tipo de transacción.
	 */
	public String getDescription() {
		return description;
	}

	/**
	 * Establece la descripción del tipo de transacción.
	 * @param description Descripción del tipo de transacción.
	 */
	public void setDescription(String description) {
		this.description = description;
	}

	@Override
	public boolean isRowDeleted() {
		return rowDeleted;
	}

	@Override
	public void setRowDeleted(boolean rowDeleted) {
		this.rowDeleted = rowDeleted;
		
	}

	@Override
	public Date getRowCreationDate() {
		return rowCreationDate;
	}

	@Override
	public void setRowCreationDate(Date rowCreationDate) {
		this.rowCreationDate = rowCreationDate;
	}

	@Override
	public Date getRowLastUpdate() {
		return rowLastUpdate;
	}

	@Override
	public void setRowLastUpdate(Date rowLastUpdate) {
		this.rowLastUpdate = rowLastUpdate;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + (int) (id ^ (id >>> 32));
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		TransactionType other = (TransactionType) obj;
		if (id != other.id)
			return false;
		return true;
	}

	@Override
	public String toString() {
		return "TransactionType [id=" + id + ", description=" + description
				+ ", rowDeleted=" + rowDeleted + "]";
	}

	
}