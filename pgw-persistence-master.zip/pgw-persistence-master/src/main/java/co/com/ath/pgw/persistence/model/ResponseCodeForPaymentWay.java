/*
 * ResponseCodeForPaymentWay
 *  
 * GSI - Integración
 * Creado el: 28/08/2014
 *
 * Copyright (c) A Toda Hora S.A. Todos los derechos reservados
 * 
 * Este software es confidencial y es propietario de ATH, queda prohibido
 * su uso, reproducción y copia de manera parcial o permanente salvo autorización
 * expresa de A Toda Hora S.A o de quién represente sus derechos.
 */
package co.com.ath.pgw.persistence.model;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import co.com.ath.pgw.persistence.PersistentObject;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

/**
 * The persistent class for the CODIGOSRESPUESTAXMEDIOPAGO database table.
 * 
 */
@Entity
@Table(name="CODIGOSRESPUESTAXMEDIOPAGO")
public class ResponseCodeForPaymentWay implements PersistentObject {

	/**
	 * 
	 */
	private static final long serialVersionUID = -5357888303044718512L;

	//uni-directional many-to-one association to PaymentWay
	/** mediospago Atributo de la clase. */
	@Id
	@ManyToOne(fetch=FetchType.LAZY)
	@JoinColumn(name="IDMEDIOPAGO")
	private PaymentWay paymentWay;
	
	//uni-directional many-to-one association to ResponseCode
	/** codigosrespuesta Atributo de la clase. */
	@Id
	@ManyToOne(fetch=FetchType.EAGER)
	@JoinColumn(name="CODIGORESPUESTA")
	private ResponseCode responseCode;
	
	/** mappingCode Atributo de la clase. */
	@Column(name="CODIGOMAPEO")
	private String mappingCode;	

	/** rowCreationDate Atributo de la clase. */
	@Column(name="REGFECHACREACION")
    @Temporal(TemporalType.TIMESTAMP)
	private Date rowCreationDate;

	/** rowLastUpdate Atributo de la clase. */
	@Column(name="REGFECHAMODIFICACION")
    @Temporal(TemporalType.TIMESTAMP)
	private Date rowLastUpdate;
	
	/** rowDeleted Atributo de la clase. */
	@Column(name="REGELIMINADO")
	private boolean rowDeleted;

	public ResponseCodeForPaymentWay() {}

	/**
	 * Método encargado de recuperar el valor del atributo paymentWay.
	 * @return El atributo paymentWay asociado a la clase.
	 */
	public PaymentWay getPaymentWay() {
		return paymentWay;
	}

	/**
	 * Método encargado de actualizar el atributo paymentWay.
	 * @param paymentWay Nuevo valor para paymentWay.
	 */
	public void setPaymentWay(PaymentWay paymentWay) {
		this.paymentWay = paymentWay;
	}

	/**
	 * Método encargado de recuperar el valor del atributo responseCode.
	 * @return El atributo responseCode asociado a la clase.
	 */
	public ResponseCode getResponseCode() {
		return responseCode;
	}

	/**
	 * Método encargado de actualizar el atributo responseCode.
	 * @param responseCode Nuevo valor para responseCode.
	 */
	public void setResponseCode(ResponseCode responseCode) {
		this.responseCode = responseCode;
	}

	/**
	 * Método encargado de recuperar el valor del atributo mappingCode.
	 * @return El atributo mappingCode asociado a la clase.
	 */
	public String getMappingCode() {
		return mappingCode;
	}

	/**
	 * Método encargado de actualizar el atributo mappingCode.
	 * @param mappingCode Nuevo valor para mappingCode.
	 */
	public void setMappingCode(String mappingCode) {
		this.mappingCode = mappingCode;
	}

	/**
	 * Método encargado de recuperar el valor del atributo rowCreationDate.
	 * @return El atributo rowCreationDate asociado a la clase.
	 */
	public Date getRowCreationDate() {
		return rowCreationDate;
	}

	/**
	 * Método encargado de actualizar el atributo rowCreationDate.
	 * @param rowCreationDate Nuevo valor para rowCreationDate.
	 */
	public void setRowCreationDate(Date rowCreationDate) {
		this.rowCreationDate = rowCreationDate;
	}

	/**
	 * Método encargado de recuperar el valor del atributo rowLastUpdate.
	 * @return El atributo rowLastUpdate asociado a la clase.
	 */
	public Date getRowLastUpdate() {
		return rowLastUpdate;
	}

	/**
	 * Método encargado de actualizar el atributo rowLastUpdate.
	 * @param rowLastUpdate Nuevo valor para rowLastUpdate.
	 */
	public void setRowLastUpdate(Date rowLastUpdate) {
		this.rowLastUpdate = rowLastUpdate;
	}

	/**
	 * Método encargado de recuperar el valor del atributo rowDeleted.
	 * @return El atributo rowDeleted asociado a la clase.
	 */
	public boolean isRowDeleted() {
		return rowDeleted;
	}

	/**
	 * Método encargado de actualizar el atributo rowDeleted.
	 * @param rowDeleted Nuevo valor para rowDeleted.
	 */
	public void setRowDeleted(boolean rowDeleted) {
		this.rowDeleted = rowDeleted;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result
				+ ((paymentWay == null) ? 0 : paymentWay.hashCode());
		result = prime * result
				+ ((responseCode == null) ? 0 : responseCode.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		ResponseCodeForPaymentWay other = (ResponseCodeForPaymentWay) obj;
		if (paymentWay == null) {
			if (other.paymentWay != null)
				return false;
		} else if (!paymentWay.equals(other.paymentWay))
			return false;
		if (responseCode == null) {
			if (other.responseCode != null)
				return false;
		} else if (!responseCode.equals(other.responseCode))
			return false;
		return true;
	}

	@Override
	public String toString() {
		return "ResponseCodeForPaymentWay [mappingCode=" + mappingCode
				+ ", rowDeleted=" + rowDeleted + "]";
	}	
	
}