/*
 * AddRBMPaymentValidatorImpl
 *  
 * GSI - Integración
 * Creado el: 20/09/2014
 *
 * Copyright (c) A Toda Hora S.A. Todos los derechos reservados
 * 
 * Este software es confidencial y es propietario de ATH, queda prohibido
 * su uso, reproducción y copia de manera parcial o permanente salvo autorización
 * expresa de A Toda Hora S.A o de quién represente sus derechos.
 */
package co.com.ath.pgw.persistence.validation.model.impl;

import java.math.BigDecimal;
import java.util.Date;
import java.util.Locale;

import javax.annotation.Resource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import co.com.ath.pgw.bsn.dto.in.AddRBMPaymentInDTO;
import co.com.ath.pgw.util.i18n.ResourceBundleManager;
import co.com.ath.pgw.util.validation.ValidationException;
import co.com.ath.pgw.util.validation.model.AddRBMPaymentValidator;

/**
 * Implementación por defecto del validador AddRBMPaymentValidator.
 * 
 * @version 0.0.0 20/09/2014
 * @author Andrés Méndez Juanias <proveedor_mamendez@ath.com.co>
 */
@Service
public class AddRBMPaymentValidatorImpl implements AddRBMPaymentValidator {

	@Autowired
	private ResourceBundleManager bundleManager;
    
    @Resource
	private TrxSourceValidator sourceValidator;
	
	@Resource
	private RqDateValidator dateValidator;
	
	@Resource
	private IPAddressValidator ipAddressValidator;
	
	@Resource
	private DocumentTypeValidator docTypeValidator;
	
	@Resource
	private DocumentIdValidator docIdValidator;
    
    @Resource
    private CustomerEmailValidator custEmailValidator;

    @Resource
	private TransactionIdValidator transactionIdValidator;
    
    @Resource
	private TransactionPmtIdValidator transactionPmtIdValidator;

	@Resource
	private PhoneNumberValidator phoneNumberValidator;

	@Resource
	private AgreementValidatorImpl agreementValidator;

	@Resource
	private CreditCardNumberValidator creditCardNumberValidator;

	@Resource
	private BrandIdValidator brandIdValidator;

	@Resource
	private OrderNumberValidator orderNumberValidator;

	@Resource
	private ObligatoryValidator obligatoryValidator;

	@Resource
	private TotalValueValidator totalValueValidator;

	@Resource
	private CurrencyValidator currencyValidator;

	@Resource
	private TaxValueValidator taxValueValidator;

	private Locale locale;

	public AddRBMPaymentValidatorImpl() {
		this.locale = Locale.getDefault();
	}

	@Override
	public void validate(AddRBMPaymentInDTO inDTO) throws ValidationException {
		validateChannelSource(inDTO.getTransactionBO().getSource().getId());
        validateRqDate(inDTO.getClientDt());
        validateIpAddress(inDTO.getIpAddr());
        validateDocType(inDTO.getTransactionBO().getCustomerDocType());
        validateDocId(inDTO.getTransactionBO().getCustomerDocId());
        validateCustomerEmail(inDTO.getTransactionBO().getCustomerEmail());

        validateTransactionPmtId(inDTO.getTransactionBO().getPmtId());
		validatePhoneNumber(inDTO.getTransactionBO().getCustomerMobileNumber());
		validateAgreementId(inDTO.getTransactionBO().getCommerce().getNuraCode());
		validateCreditCard(inDTO.getTransactionBO().getCreditCard().getNumber());
		validateBrandId(inDTO.getTransactionBO().getCreditCard().getBrand().getId());
		validateOrderNumber(inDTO.getTransactionBO().getOrderNumber());
		validateDescription(inDTO.getTransactionBO().getDescription());
		validateTotalValue(inDTO.getTransactionBO().getTotalValue());
		validateCurrency(inDTO.getTransactionBO().getCurrency());
		validateTaxValue(inDTO.getTransactionBO().getTaxValue());
		
		//Validar información del pagador
		validatePayerCity(inDTO.getTransactionBO().getPayerCity());
		validatePayerMail(inDTO.getTransactionBO().getPayerMail());
		validatePayerAddress(inDTO.getTransactionBO().getPayerAddress());
		validatePayerDepartment(inDTO.getTransactionBO().getPayerDepartment());
		validatePayerBirthDate(inDTO.getTransactionBO().getPayerBirthDate());
		validatePayerGender(inDTO.getTransactionBO().getPayerGender());
		validatePayerNickName(inDTO.getTransactionBO().getPayerNickName());
		validatePayerCompany(inDTO.getTransactionBO().getPayerCompany());
		validatePayerName(inDTO.getTransactionBO().getFirstNamePayer());
		validatePayerDocId(inDTO.getTransactionBO().getPayerDocId());
		validatePayerCountry(inDTO.getTransactionBO().getPayerCountry());
		validatePayerPhone(inDTO.getTransactionBO().getPayerPhone());
		validatePayerDocType(inDTO.getTransactionBO().getCustomerDocType());
		
	}
    
    /**
     * Realiza la validación de un canal de origen.
     * 
     * @param channelId Canal de origen.
     * @throws ValidationException 
     */
    private void validateChannelSource(String channelId) throws ValidationException {
    	sourceValidator.setMandatory(true);
		sourceValidator.setBundleManager(bundleManager);
		sourceValidator.validate(channelId, locale);
		
	}

    /**
     * Realiza la validación de la fecha de solicitud.
     * 
     * @param clientDt				Fecha de solicitud.
     * @throws ValidationException	Si no supera las validaciones.
     */
	private void validateRqDate(Date clientDt) throws ValidationException {
		dateValidator.setMandatory(true);
		dateValidator.setBundleManager(bundleManager);
		dateValidator.validate(clientDt, locale);
	}

	/**
	 * Realiza la validación de la dirección IP origen de la transacción.
	 * 
	 * @param ipAddr 				Dirección ip origen.
	 * @throws ValidationException 	Si no supera las validaciones.
	 */
	private void validateIpAddress(String ipAddr) throws ValidationException {
		ipAddressValidator.setMandatory(true);
		ipAddressValidator.setBundleManager(bundleManager);
		ipAddressValidator.validate(ipAddr, locale);
	}

	/**
	 * Realiza la validación del tipo de documento del cliente.
	 * 
	 * @param customerDocType	Tipo de docuemnto del cliente.
	 * @throws ValidationException Si no supera las validaciones.
	 */
	private void validateDocType(String customerDocType) throws ValidationException {
		docTypeValidator.setMandatory(true);
		docTypeValidator.setBundleManager(bundleManager);
		docTypeValidator.validate(customerDocType, locale);
	}

	/**
	 * Realiza la validación del número de documento del cliente.
	 * 
	 * @param customerDocId Número de documento del cliente.
	 * @throws ValidationException En caso de no superar la validación.
	 */
	private void validateDocId(String customerDocId) throws ValidationException {
		docIdValidator.setMandatory(true);
		docIdValidator.setBundleManager(bundleManager);
		docIdValidator.validate(customerDocId, locale);
	}
    
    /**
	 * Realiza la validación del email del cliente.
	 * 
	 * @param customerEmail email del cliente.
	 * @throws ValidationException 
	 */
	private void validateCustomerEmail(String customerEmail) throws ValidationException {
		custEmailValidator.setMandatory(false);
		custEmailValidator.setBundleManager(bundleManager);
		custEmailValidator.validate(customerEmail, locale);
	}

	/**
	 * Realiza la validación del id de la transacción.
	 * 
	 * @param id
	 *            Id de la transacción.
	 * @throws ValidationException
	 *             En caso que falle la validación.
	 */
	private void validateTransactionId(String id) throws ValidationException {
		transactionIdValidator.setMandatory(true);
		transactionIdValidator.setBundleManager(bundleManager);
		transactionIdValidator.validate(id, locale);
	}
	
	/**
	 * Realiza la validación del id de la transacción.
	 * 
	 * @param pmtid
	 *            PmtId de la transacción.
	 * @throws ValidationException
	 *             En caso que falle la validación.
	 */
	private void validateTransactionPmtId(String pmtid) throws ValidationException {
		transactionPmtIdValidator.setMandatory(true);
		transactionPmtIdValidator.setBundleManager(bundleManager);
		transactionPmtIdValidator.validate(pmtid, locale);
	}

	/**
	 * Realiza la validación del numero de telefono.
	 * 
	 * @param phoneNumber
	 *            Numero de telefono.
	 * @throws ValidationException
	 *             En caso que falle la validación.
	 */
	private void validatePhoneNumber(String phoneNumber) throws ValidationException {
		phoneNumberValidator.setMandatory(false);
		phoneNumberValidator.setBundleManager(bundleManager);
		phoneNumberValidator.validate(phoneNumber, locale);
	}

	/**
	 * Realiza la validación del convenio del comercio.
	 * 
	 * @param nuraCode
	 *            Código nura del comercio.
	 * @throws ValidationException
	 *             En caso que falle la validación.
	 */
	private void validateAgreementId(String nuraCode) throws ValidationException {
//		agreementValidator.setMandatory(true);
//		agreementValidator.setBundleManager(bundleManager);
		agreementValidator.validate(nuraCode, locale);
	}

	/**
	 * Realiza la validación del número de tarjeta de crédito.
	 * 
	 * @param creditCard
	 *            Número de tarjeta de crédito.
	 * @throws ValidationException
	 *             En caso que falle la validación.
	 */
	private void validateCreditCard(String creditCard)
			throws ValidationException {
		creditCardNumberValidator.setMandatory(true);
		creditCardNumberValidator.setBundleManager(bundleManager);
		creditCardNumberValidator.validate(creditCard, locale);
	}

	/**
	 * Realiza la validación de la franquicia.
	 * 
	 * @param id
	 *            Id de la franquicia.
	 * @throws ValidationException
	 *             En caso que falle la validación.
	 */
	private void validateBrandId(String id) throws ValidationException {
		brandIdValidator.setMandatory(true);
		brandIdValidator.setBundleManager(bundleManager);
		brandIdValidator.validate(id, locale);
	}

	/**
	 * Realiza la validación del número de orden.
	 * 
	 * @param orderNumber
	 *            Número de orden.
	 * @throws ValidationException
	 *             En caso que falle la validación.
	 */
	private void validateOrderNumber(String orderNumber)
			throws ValidationException {
		orderNumberValidator.setMandatory(true);
		orderNumberValidator.setBundleManager(bundleManager);
		orderNumberValidator.validate(orderNumber, locale);
	}

	/**
	 * Realiza la validación de la descipción.
	 * 
	 * @param description
	 *            Descripción a validar.
	 * @throws ValidationException
	 *             En caso que falle la validación.
	 */
	private void validateDescription(String description)
			throws ValidationException {
		obligatoryValidator.setMandatory(true);
		obligatoryValidator.setBundleManager(bundleManager);
		obligatoryValidator.validate(description, locale);
	}

	/**
	 * Realiza la validación del valor total.
	 * 
	 * @param totalValue
	 *            Valor total de la transacción.
	 * @throws ValidationException
	 *             En caso que falle la validaión.
	 */
	private void validateTotalValue(BigDecimal totalValue)
			throws ValidationException {
		totalValueValidator.setMandatory(true);
		totalValueValidator.setBundleManager(bundleManager);
		totalValueValidator.validate(totalValue, locale);
	}

	/**
	 * Realiza la validación del tipo de moneda.
	 * 
	 * @param currency
	 *            Tipo de moneda.
	 * @throws ValidationException
	 *             En caso que falle la validación.
	 */
	private void validateCurrency(String currency) throws ValidationException {
		currencyValidator.setMandatory(false);
		currencyValidator.setBundleManager(bundleManager);
		currencyValidator.validate(currency, locale);
	}

	/**
	 * Realiza la validación del valor del impuesto.
	 * 
	 * @param taxValue
	 *            Valor del impuesto.
	 * @throws ValidationException
	 *             En caso que falle la validación.
	 */
	private void validateTaxValue(BigDecimal taxValue) throws ValidationException {
		taxValueValidator.setMandatory(true);
		taxValueValidator.setBundleManager(bundleManager);
		taxValueValidator.validate(taxValue, locale);
	}
	
	/**
	 * Realiza la validación de la ciudad del pagador.
	 * 
	 * @param payerCity
	 *            Ciudad pagador a validar.
	 * @throws ValidationException
	 *             En caso que falle la validación.
	 */
	private void validatePayerCity(String payerCity) throws ValidationException {
		obligatoryValidator.setMandatory(false);
		obligatoryValidator.setBundleManager(bundleManager);
		obligatoryValidator.validate(payerCity, locale);
	}
	
	
    /**
	 * Realiza la validación del email del pagador.
	 * 
	 * @param payerMail email del pagador.
	 * @throws ValidationException 
	 */
	private void validatePayerMail(String payerMail) throws ValidationException {
		custEmailValidator.setMandatory(false);
		custEmailValidator.setBundleManager(bundleManager);
		custEmailValidator.validate(payerMail, locale);
	}
	
	/**
	 * Realiza la validación de la dirección del pagador.
	 * 
	 * @param payerAddress a validar.
	 * @throws ValidationException
	 *             En caso que falle la validación.
	 */
	private void validatePayerAddress(String payerAddress) throws ValidationException {
		obligatoryValidator.setMandatory(false);
		obligatoryValidator.setBundleManager(bundleManager);
		obligatoryValidator.validate(payerAddress, locale);
	}
	
	/**
	 * Realiza la validación del nombre del departamento del pagador
	 * 
	 * @param payerDepartment
	 *            departamento pagador a validar.
	 * @throws ValidationException
	 *             En caso que falle la validación.
	 */
	private void validatePayerDepartment(String payerDepartment) throws ValidationException {
		obligatoryValidator.setMandatory(false);
		obligatoryValidator.setBundleManager(bundleManager);
		obligatoryValidator.validate(payerDepartment, locale);
	}
	
    /**
     * Realiza la validación de la fecha de nacimiento del pagador
     * 
     * @param payerBirthDate
     * @throws ValidationException	Si no supera las validaciones.
     */
	private void validatePayerBirthDate(Date payerBirthDate) throws ValidationException {
		dateValidator.setMandatory(false);
		dateValidator.setBundleManager(bundleManager);
		dateValidator.validate(payerBirthDate, locale);
	}
	
	/**
	 * Realiza la validación del género del pagador
	 * 
	 * @param payerGender
	 *            
	 * @throws ValidationException
	 *             En caso que falle la validación.
	 */
	private void validatePayerGender(String payerGender) throws ValidationException {
		obligatoryValidator.setMandatory(false);
		obligatoryValidator.setBundleManager(bundleManager);
		obligatoryValidator.validate(payerGender, locale);
	}
	
	/**
	 * Realiza la validación del alias del pagador
	 * 
	 * @param payerNickName
	 *            Descripción a validar.
	 * @throws ValidationException
	 *             En caso que falle la validación.
	 */
	private void validatePayerNickName(String payerNickName) throws ValidationException {
		obligatoryValidator.setMandatory(false);
		obligatoryValidator.setBundleManager(bundleManager);
		obligatoryValidator.validate(payerNickName, locale);
	}

	/**
	 * Realiza la validación del nombre de la compañía del pagador.
	 * 
	 * @param payerCompany
	 *            Descripción a validar.
	 * @throws ValidationException
	 *             En caso que falle la validación.
	 */
	private void validatePayerCompany(String payerCompany) throws ValidationException {
		obligatoryValidator.setMandatory(false);
		obligatoryValidator.setBundleManager(bundleManager);
		obligatoryValidator.validate(payerCompany, locale);
	}
	
	/**
	 * Realiza la validación del nombre del pagador.
	 * 
	 * @param payerName
	 *            Descripción a validar.
	 * @throws ValidationException
	 *             En caso que falle la validación.
	 */
	private void validatePayerName(String payerName) throws ValidationException {
		obligatoryValidator.setMandatory(false);
		obligatoryValidator.setBundleManager(bundleManager);
		obligatoryValidator.validate(payerName, locale);
	}
	
	/**
	 * Realiza la validación del número de documento del pagador.
	 * 
	 * @param payerDocId Número de documento del cliente.
	 * @throws ValidationException En caso de no superar la validación.
	 */
	private void validatePayerDocId(String payerDocId) throws ValidationException {
		docIdValidator.setMandatory(false);
		docIdValidator.setBundleManager(bundleManager);
		docIdValidator.validate(payerDocId, locale);
	}
	
	/**
	 * Realiza la validación del país del pagador.
	 * 
	 * @param payerCountry
	 *            Ciudad pagador a validar.
	 * @throws ValidationException
	 *             En caso que falle la validación.
	 */
	private void validatePayerCountry(String payerCountry)
			throws ValidationException {
		obligatoryValidator.setMandatory(false);
		obligatoryValidator.setBundleManager(bundleManager);
		obligatoryValidator.validate(payerCountry, locale);
	}
	
	/**
	 * Realiza la validación del numero de telefono del pagador.
	 * 
	 * @param PayerPhone
	 *            Numero de telefono.
	 * @throws ValidationException
	 *             En caso que falle la validación.
	 */
	private void validatePayerPhone(String PayerPhone) throws ValidationException {
		phoneNumberValidator.setMandatory(false);
		phoneNumberValidator.setBundleManager(bundleManager);
		phoneNumberValidator.validate(PayerPhone, locale);
	}
	
	/**
	 * Realiza la validación del tipo de documento del pagador.
	 * 
	 * @param payerDocType	.
	 * @throws ValidationException Si no supera las validaciones.
	 */
	private void validatePayerDocType(String payerDocType) throws ValidationException {
		docTypeValidator.setMandatory(false);
		docTypeValidator.setBundleManager(bundleManager);
		docTypeValidator.validate(payerDocType, locale);
	}
}