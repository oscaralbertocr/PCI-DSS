/*
 * BankDAOImpl
 *
 * GSI - Integración
 * Creado el: 22 de agosto de 2014
 *
 * Copyright (c) A Toda Hora S.A. Todos los derechos reservados
 *
 * Este software es confidencial y es propietario de ATH, queda prohibido
 * su uso, reproducción y copia de manera parcial o permanente salvo autorización
 * expresa de A Toda Hora S.A o de quién represente sus derechos.
 */
package co.com.ath.pgw.persistence.dao.impl;

import javax.persistence.NoResultException;
import javax.persistence.NonUniqueResultException;
import javax.persistence.Query;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Repository;

import co.com.ath.pgw.persistence.AbstractDAO_JPA;
import co.com.ath.pgw.persistence.dao.NotificacionTecnicaDAO;
import co.com.ath.pgw.persistence.model.NotificacionTecnica;

/**
 * Implementación por defecto de NotificacionTecnicaDAO
 * 
 * @author Andrés Eduardo Hernandez <andres.hernandez@sophossolutions.com>
 * @version 28/05/2018
 * @since 1.0
 */
@Repository
public class NotificacionTecnicaDAOImpl extends AbstractDAO_JPA<NotificacionTecnica> implements NotificacionTecnicaDAO {
	
	static Logger LOGGER = LoggerFactory.getLogger(NotificacionTecnicaDAOImpl.class);
	
	/**
	 * Constructor por defecto
	 */
	public NotificacionTecnicaDAOImpl() {
		super(NotificacionTecnica.class);
	}

	@Override
	public NotificacionTecnica findByTipoNotificacion(String tipo) {

		StringBuilder hql = new StringBuilder("from NotificacionTecnica b ");
		hql.append("where b.rowDeleted <> 1 ");
		hql.append("and b.tipoNotificacion = :tipo ");
		
        Query query = entityManager.createQuery(hql.toString());
		query.setParameter("tipo", tipo);
		
		NotificacionTecnica notificacionTecnica = null;
		try {
			notificacionTecnica = (NotificacionTecnica) query.getSingleResult(); 
		} catch (NoResultException e) {
			LOGGER.info("Problemas en query: {}", e.toString());
			return null;
		} catch (NonUniqueResultException e){
			LOGGER.warn("Problemas en query: {}", e.toString());
            return null;
        }
		return notificacionTecnica;
	}
}