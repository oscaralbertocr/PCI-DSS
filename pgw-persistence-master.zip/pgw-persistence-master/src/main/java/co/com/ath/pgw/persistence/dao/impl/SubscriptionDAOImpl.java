/*
 * SubscriptionDAOImpl
 *  
 * GSI - Integración
 * Creado el: 29/08/2014
 *
 * Copyright (c) A Toda Hora S.A. Todos los derechos reservados
 * 
 * Este software es confidencial y es propietario de ATH, queda prohibido
 * su uso, reproducción y copia de manera parcial o permanente salvo autorización
 * expresa de A Toda Hora S.A o de quién represente sus derechos.
 */
package co.com.ath.pgw.persistence.dao.impl;

import org.springframework.stereotype.Repository;

import co.com.ath.pgw.persistence.AbstractDAO_JPA;
import co.com.ath.pgw.persistence.dao.SubscriptionDAO;
import co.com.ath.pgw.persistence.model.Subscription;

/**
 * Implementación por defecto de SubscriptionDAO
 *
 * @author Andrés Méndez Juanias <proveedor_mamendez@ath.com.co>
 * @version 1.0 29 Ago 2014
 * @since 1.0
 */
@Repository
public class SubscriptionDAOImpl 
			extends AbstractDAO_JPA<Subscription> implements SubscriptionDAO {

	public SubscriptionDAOImpl() {
		super(Subscription.class);
	}

}
