/*
 * OrderNumberApprovedValidatorImpl
 *  
 * GSI - Integración
 * Creado el: 9/04/2015
 *
 * Copyright (c) A Toda Hora S.A. Todos los derechos reservados
 * 
 * Este software es confidencial y es propietario de ATH, queda prohibido
 * su uso, reproducción y copia de manera parcial o permanente salvo autorización
 * expresa de A Toda Hora S.A o de quién represente sus derechos.
 */
package co.com.ath.pgw.persistence.validation.model.impl;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

import javax.annotation.Resource;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import co.com.ath.pgw.bsn.model.bo.TransactionBO;
import co.com.ath.pgw.persistence.dao.TransactionDAO;
import co.com.ath.pgw.persistence.model.Transaction;
import co.com.ath.pgw.util.enums.TransactionStatusEnum;
import co.com.ath.pgw.util.i18n.BundleKeys;
import co.com.ath.pgw.util.i18n.BundleType;
import co.com.ath.pgw.util.i18n.ResourceBundleManager;
import co.com.ath.pgw.util.validation.ErrorCode;
import co.com.ath.pgw.util.validation.ValidationException;
import co.com.ath.pgw.util.validation.model.OrderNumberApprovedValidator;

/**
 * Implementación del validador OrderNumberApprovedValidator.
 *
 * @author Andrés Méndez Juanias <proveedor_mamendez@ath.com.co> 
 * @version 1.0 9/04/2015
 * @since 1.0
 */
@Service
public class OrderNumberApprovedValidatorImpl implements
		OrderNumberApprovedValidator {
	
	static Logger LOGGER = LoggerFactory.getLogger(OrderNumberApprovedValidatorImpl.class);
	
	@Autowired
	private ResourceBundleManager bundleManager;
	
	@Resource
	private TransactionDAO transactionDAO;
	
	private Locale locale = Locale.getDefault();
	
	/* (non-Javadoc)
	 * @see co.com.ath.pgw.validation.model.OrderNumberApprovedValidator#validate(co.com.ath.pgw.model.bo.TransactionBO)
	 */
	@Override
	public void validate(TransactionBO transactionBO)
			throws ValidationException {
		ArrayList<TransactionStatusEnum> statusList = new ArrayList<TransactionStatusEnum>();
		statusList.add(TransactionStatusEnum.CONFIRMED_OK);
		List<Transaction> list = transactionDAO.findByOrderNumberNuraCodeStatus(transactionBO
				.getOrderNumber(), transactionBO.getCommerce().getNuraCode(),
				statusList, null, null, null, null);
		if (!list.isEmpty()) {
			ValidationException ve = new ValidationException(getMessage(),
					ErrorCode.INVALID_ORDER_NUMBER_APPROVED);
			LOGGER.warn("Fallo en validador: \n{}", ve.toString());
			throw ve;
		}

	}
	
	private String getMessage() {
		if (bundleManager == null) {
			return BundleKeys.ERROR_INVALID_ORDER_NUMBER_APPROVED;
		}
		bundleManager.setBundle(BundleType.ERRORS);
		return bundleManager.getMessage(
			BundleKeys.ERROR_INVALID_ORDER_NUMBER_APPROVED, null, locale);
	}

}
