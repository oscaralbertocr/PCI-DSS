package co.com.ath.pgw.persistence.dao;

import java.math.BigDecimal;
import java.util.List;

import co.com.ath.pgw.persistence.DataAccessObject;
import co.com.ath.pgw.persistence.model.Top;

/**
 * Objeto de Acceso a Datos para las entidades Topes
 * 
 * @author ATH
 * @version 1.0 17/08/2017
 * @RQ27199
 * <strong>Autor</strong> Jordan Andrei Cortes </br>
 * <strong>Descripcion</strong> Validcación de Topes </br>
 */
public interface TopDAO extends DataAccessObject<Top>{
	
	/**
	 * 
	 * @param idComercio
	 * @return
	 * @throws Exception
	 */
	public List<Top> findByCommerce(Long idComercio) throws Exception;
	
	/**
	 * 
	 * @param idComercio
	 * @param paymentWay
	 * @return
	 * @throws Exception
	 */
	public List<Top> findByCommerceAndPaymentWay(Long idComercio, Long paymentWay) throws Exception;
	
	/**
	 * 
	 * @param idComercio
	 * @param paymentWay
	 * @return
	 */
	public Top findTopPermanentTran(Long idComercio, Long paymentWay, BigDecimal valor);
	
	/**
	 * 
	 * @param idComercio
	 * @param paymentWay
	 * @param valor
	 * @return
	 */
	public Top findTopByDateTran(Long idComercio, Long paymentWay, BigDecimal valor);
	
	/**
	 * 
	 * @param desc
	 * @return
	 * @throws Exception 
	 */
	public Top findTopByDesc(String desc) throws Exception;
	
	
}
