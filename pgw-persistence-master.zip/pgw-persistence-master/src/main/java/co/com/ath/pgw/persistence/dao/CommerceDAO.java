/*
 * CommerceDAO
 *  
 * GSI - Integración
 * Creado el: 29/08/2014
 *
 * Copyright (c) A Toda Hora S.A. Todos los derechos reservados
 * 
 * Este software es confidencial y es propietario de ATH, queda prohibido
 * su uso, reproducción y copia de manera parcial o permanente salvo autorización
 * expresa de A Toda Hora S.A o de quién represente sus derechos.
 */
package co.com.ath.pgw.persistence.dao;

import java.util.List;

import co.com.ath.pgw.persistence.DataAccessObject;
import co.com.ath.pgw.persistence.model.Commerce;
import co.com.ath.pgw.persistence.procedure.model.CreacionConvenio;
import co.com.ath.pgw.persistence.procedure.model.NovedadConvenio;

/**
 * Objeto de Acceso a Datos para las entidades Commerce
 *
 * @author Andrés Méndez Juanias <proveedor_mamendez@ath.com.co>
 * @version 1.0 29 Ago 2014
 * @since 1.0
 */
public interface CommerceDAO extends DataAccessObject<Commerce> {

	/**
	 * Realiza la búsqueda de un comercio por el código NURA, retorna
	 * <strong>null</strong> si no encuentra el convenio.
	 * 
	 * @param nuraCode Código NURA
	 * @return Comercio con el código NURA buscado.
	 */
	Commerce findByNura(String nuraCode);

	List<Commerce> listPaymentFileActive();
	
	List<Commerce> listZipAsobancariaActive();
	
	Commerce agreementSynchronization(NovedadConvenio novedadConvenio);
	
	Commerce agreementCreate(CreacionConvenio creacionConvenio);
	
	Commerce findByNuraDeleted(String nuraCode);

	Long getCommerceByIncoCredito(String codigoIncocredito, String nit) throws Exception;

	Long getCommerceByTerminal(String codigoIncocredito, String codigoTerminal, String codigoNura) throws Exception;
}
