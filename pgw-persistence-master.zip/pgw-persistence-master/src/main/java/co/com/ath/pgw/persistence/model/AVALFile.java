/*
 * AVALFile
 *  
 * GSI - Integración
 * Creado el: 28/08/2014
 *
 * Copyright (c) A Toda Hora S.A. Todos los derechos reservados
 * 
 * Este software es confidencial y es propietario de ATH, queda prohibido
 * su uso, reproducción y copia de manera parcial o permanente salvo autorización
 * expresa de A Toda Hora S.A o de quién represente sus derechos.
 */
package co.com.ath.pgw.persistence.model;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import co.com.ath.pgw.persistence.PersistentObject;

/**
 * Clase que representa un archivo AVAL para conciliacion de transacciones.
 * 
 * @author Andrés Méndez <proveedor_mamendez@ath.com.co>
 * @version 17/12/2014
 * @since 1.0
 */
@Entity
@Table(name="ARCHIVOSAVAL")
public class AVALFile implements PersistentObject {

	/**
	 * ID de serialización.
	 */
	private static final long serialVersionUID = 1786118152957467367L;

	/**
	 * Identificador único del archivo AVAL.
	 */
	@Id
	@SequenceGenerator(
			name="ARCHIVOSAVAL_ID_GENERATOR",
			sequenceName="ARCHIVOSAVAL_SEC",
			initialValue=1,
			allocationSize=1
			)
	@GeneratedValue(
			strategy=GenerationType.SEQUENCE,
			generator="ARCHIVOSAVAL_ID_GENERATOR"
			)
	@Column(name="ID", nullable=false)
	private Long id;
	
	/**
	 * Identificador de relación con el banco.
	 */
	@Column(name="BANREPUBLICA")
	private String banrepublica;
	
	/**
	 * Nombre del archivo
	 */
	@Column(name="NOMBRE")
	private String name;
	
	/**
	 * Ruta del archivo.
	 */
	@Column(name="RUTA")
	private String path;
	
	/**
	 * Fecha de generación del archivo
	 */
	@Temporal(TemporalType.TIMESTAMP)
	@Column(name="FECHAGENERACION")
	private Date generationDate;
	
	/**
	 * Estado del archivo.
	 */
	@Column(name="ESTADO")
	private String status;
	
	/**
	 * Indica si el registro tiene marca lógica de borrado
	 */
	@Column(name="REGELIMINADO", nullable=true)
	private boolean rowDeleted;
	
	/**
	 * Fecha de creación del registro
	 */
	@Temporal(TemporalType.TIMESTAMP)
	@Column(name="REGFECHACREACION", nullable=true)
	private Date rowCreationDate;
	
	/**
	 * Fecha de última modificación del registro
	 */
	@Temporal(TemporalType.TIMESTAMP)
	@Column(name="REGFECHAMODIFICACION", nullable=true)
	private Date rowLastUpdate;
	
	/**
	 * Constructor por defecto de un Banco
	 */
	public AVALFile(){
		super();
	}
	
	/**
	 * Método encargado de recuperar el valor del atributo id.
	 * @return El atributo id asociado a la clase.
	 */
	public Long getId() {
		return id;
	}

	/**
	 * Método encargado de actualizar el atributo id.
	 * @param id Nuevo valor para id.
	 */
	public void setId(Long id) {
		this.id = id;
	}

	/**
	 * Método encargado de recuperar el valor del atributo banrepublicaId.
	 * @return El atributo banrepublicaId asociado a la clase.
	 */
	public String getBanrepublica() {
		return banrepublica;
	}

	/**
	 * Método encargado de actualizar el atributo banrepublicaId.
	 * @param banrepublicaId Nuevo valor para banrepublicaId.
	 */
	public void setBanrepublica(String banrepublica) {
		this.banrepublica = banrepublica;
	}

	/**
	 * Método encargado de recuperar el valor del atributo name.
	 * @return El atributo name asociado a la clase.
	 */
	public String getName() {
		return name;
	}

	/**
	 * Método encargado de actualizar el atributo name.
	 * @param name Nuevo valor para name.
	 */
	public void setName(String name) {
		this.name = name;
	}

	/**
	 * Método encargado de recuperar el valor del atributo path.
	 * @return El atributo path asociado a la clase.
	 */
	public String getPath() {
		return path;
	}

	/**
	 * Método encargado de actualizar el atributo path.
	 * @param path Nuevo valor para path.
	 */
	public void setPath(String path) {
		this.path = path;
	}

	/**
	 * Método encargado de recuperar el valor del atributo generationDate.
	 * @return El atributo generationDate asociado a la clase.
	 */
	public Date getGenerationDate() {
		return generationDate;
	}

	/**
	 * Método encargado de actualizar el atributo generationDate.
	 * @param generationDate Nuevo valor para generationDate.
	 */
	public void setGenerationDate(Date generationDate) {
		this.generationDate = generationDate;
	}

	/**
	 * Método encargado de recuperar el valor del atributo status.
	 * @return El atributo status asociado a la clase.
	 */
	public String getStatus() {
		return status;
	}

	/**
	 * Método encargado de actualizar el atributo status.
	 * @param status Nuevo valor para status.
	 */
	public void setStatus(String status) {
		this.status = status;
	}

	/**
	 * Método encargado de recuperar el valor del atributo rowDeleted.
	 * @return El atributo rowDeleted asociado a la clase.
	 */
	public boolean isRowDeleted() {
		return rowDeleted;
	}

	/**
	 * Método encargado de actualizar el atributo rowDeleted.
	 * @param rowDeleted Nuevo valor para rowDeleted.
	 */
	public void setRowDeleted(boolean rowDeleted) {
		this.rowDeleted = rowDeleted;
	}

	/**
	 * Método encargado de recuperar el valor del atributo rowCreationDate.
	 * @return El atributo rowCreationDate asociado a la clase.
	 */
	public Date getRowCreationDate() {
		return rowCreationDate;
	}

	/**
	 * Método encargado de actualizar el atributo rowCreationDate.
	 * @param rowCreationDate Nuevo valor para rowCreationDate.
	 */
	public void setRowCreationDate(Date rowCreationDate) {
		this.rowCreationDate = rowCreationDate;
	}

	/**
	 * Método encargado de recuperar el valor del atributo rowLastUpdate.
	 * @return El atributo rowLastUpdate asociado a la clase.
	 */
	public Date getRowLastUpdate() {
		return rowLastUpdate;
	}

	/**
	 * Método encargado de actualizar el atributo rowLastUpdate.
	 * @param rowLastUpdate Nuevo valor para rowLastUpdate.
	 */
	public void setRowLastUpdate(Date rowLastUpdate) {
		this.rowLastUpdate = rowLastUpdate;
	}

}