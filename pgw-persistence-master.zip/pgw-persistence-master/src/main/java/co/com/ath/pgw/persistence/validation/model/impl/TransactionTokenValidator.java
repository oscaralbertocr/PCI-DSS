/*
 * TransactionTokenValidator
 *  
 * GSI - Integración
 * Creado el: 19/09/2014
 *
 * Copyright (c) A Toda Hora S.A. Todos los derechos reservados
 * 
 * Este software es confidencial y es propietario de ATH, queda prohibido
 * su uso, reproducción y copia de manera parcial o permanente salvo autorización
 * expresa de A Toda Hora S.A o de quién represente sus derechos.
 */
package co.com.ath.pgw.persistence.validation.model.impl;

import java.sql.Timestamp;
import java.util.Locale;

import javax.annotation.Resource;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import co.com.ath.pgw.persistence.dao.TokenDAO;
import co.com.ath.pgw.persistence.model.Token;
import co.com.ath.pgw.util.constants.TokenStatus;
import co.com.ath.pgw.util.i18n.BundleKeys;
import co.com.ath.pgw.util.i18n.BundleType;
import co.com.ath.pgw.util.validation.AbstractAttributeValidator;
import co.com.ath.pgw.util.validation.ErrorCode;
import co.com.ath.pgw.util.validation.NotEmptyValidator;
import co.com.ath.pgw.util.validation.NotNullValidator;
import co.com.ath.pgw.util.validation.ObjectValidationException;
import co.com.ath.pgw.util.validation.ObjectValidator;
import co.com.ath.pgw.util.validation.ValidationException;

/**
 * Validador para el token de la transacción.
 * 
 * @version 0.0.0 19/09/2014
 * @author Andrés Méndez Juanias <proveedor_mamendez@ath.com.co>
 */
@Service
public class TransactionTokenValidator extends AbstractAttributeValidator {

	static Logger LOGGER = LoggerFactory.getLogger(TransactionTokenValidator.class);
	
	private ObjectValidator validator;

	@Resource
	private TokenDAO tokenDAO;

	@Override
	protected void doMandatoryValidate(Object attribute, Locale locale)
			throws ValidationException {
		validator = new NotNullValidator(new NotEmptyValidator());
		validator.setBundleManager(bundleManager);
		try {
			validator.validate(attribute, locale);
		} catch (ObjectValidationException e) {
			throwException(e, locale);
		}
		doOptionalValidate(attribute, locale);
	}

	@Override
	protected void doOptionalValidate(Object attribute, Locale locale)
			throws ValidationException {
		validateExistence(attribute, locale);
	}

	/**
	 * Valida la existencia y/o expiración del token
	 * 
	 * @param attribute
	 *            Token relacionado.
	 * @param locale
	 *            Localización.
	 * @throws ValidationException
	 *             En caso de no encontrar el token o estar expirado.
	 */
	private void validateExistence(Object attribute, Locale locale)
			throws ValidationException {
		String transactionToken = attribute.toString();
		Token token = tokenDAO.read(transactionToken);
		java.util.Date date= new java.util.Date();
		Timestamp time = new Timestamp(date.getTime());
		if (token == null || token.getStatus().equals(TokenStatus.INACTIVE)
				|| token.getStatus().equals(TokenStatus.BLOCKED)) {
			throwException(getNotFoundEx(attribute, locale), locale);
		} else if (token != null && token.getExpirationDate().before(time)) {
			token.setStatus(TokenStatus.EXPIRED);
			throwException(getTimeOutEx(attribute, locale), locale);
		}
	}

	/**
	 * Retorna la exepción si el registro no existe.
	 * 
	 * @param attribute
	 *            token para mostrar en el mensaje.
	 * @param locale
	 *            Localización.
	 * @return Objeto ObjectValidationException con la descripción del error.
	 */
	private ObjectValidationException getNotFoundEx(Object attribute,
			Locale locale) {
		return new ObjectValidationException(getMessage(
				BundleKeys.ERROR_INVALID_TRANSACTION_TOKEN_NOT_FOUND,
				new Object[] { attribute }, locale));
	}
	
	/**
	 * Retorna la exepción si el token ya expiro.
	 * 
	 * @param attribute
	 *            token para mostrar en el mensaje.
	 * @param locale
	 *            Localización.
	 * @return Objeto ObjectValidationException con la descripción del error.
	 */	
	private ObjectValidationException getTimeOutEx(Object attribute,
			Locale locale) {
		return new ObjectValidationException(getMessage(
				BundleKeys.ERROR_INVALID_TRANSACTION_TOKEN_TIME_OUT,
				new Object[] { attribute }, locale));
	}
	

	/**
	 * Obtiene los mensajes del bundle basado en la llave que llega por
	 * parámetro.
	 * 
	 * @param messageKey
	 *            Clave del mensaje.
	 * @param args
	 *            Argumentos dinamicos para el mensaje.
	 * @param locale
	 *            Localización.
	 * @return Mensaje de error formateado o la messageKey si la llave no fue
	 *         encontrada.
	 */
	private String getMessage(String messageKey, Object[] args, Locale locale) {
		if (bundleManager == null) {
			return messageKey;
		}
		bundleManager.setBundle(BundleType.ERRORS);
		return bundleManager.getMessage(messageKey, args, locale);
	}

	/**
	 * Método encargado de lanzar la excepción encontrada en los validadores.
	 * 
	 * @param e
	 *            Excepción de los validadores.
	 * @param locale
	 *            Localización.
	 * @throws ValidationException
	 */
	private void throwException(ObjectValidationException e, Locale locale)
			throws ValidationException {
		ValidationException ve = new ValidationException(getMessage(
				BundleKeys.ERROR_INVALID_TRANSACTION_TOKEN, null, locale),
				ErrorCode.INVALID_TRANSACTION_TOKEN, e);
		LOGGER.warn("Fallo en validador: \n{}", ve.toString());
		throw ve;
	}
}
