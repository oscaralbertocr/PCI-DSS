/*
 * BlackList
 *  
 * GSI - Integración
 * Creado el: 23/06/2015
 *
 * Copyright (c) A Toda Hora S.A. Todos los derechos reservados
 * 
 * Este software es confidencial y es propietario de ATH, queda prohibido
 * su uso, reproducción y copia de manera parcial o permanente salvo autorización
 * expresa de A Toda Hora S.A o de quién represente sus derechos.
 */
package co.com.ath.pgw.persistence.model;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

import co.com.ath.pgw.persistence.PersistentObject;

import javax.persistence.Temporal;
import javax.persistence.TemporalType;


/**
 * Representa la lista negra de pasarela de pagos. Esta es una 
 * entidad del modelo persistente.
 * 
 * @author proveedor_edrobles
 * @version 1.0 23 Jun 2015
 * @since 1.0
 *
 */
@Entity
@Table(name="LISTANEGRA")
public class BlackList implements PersistentObject {

	private static final long serialVersionUID = 3423779153925344658L;

	/**
	 * Identificador único de lista negra
	 */
	@Id
	@SequenceGenerator(
			name="LISTANEGRA_ID_GENERATOR",
			sequenceName="LISTANEGRA_SEC",
			initialValue=1,
			allocationSize=1
			)
	@GeneratedValue(
			strategy=GenerationType.SEQUENCE, 
			generator="LISTANEGRA_ID_GENERATOR"
			)
	@Column(name = "ID", nullable=false)
	private Long id;
	
	/**
	 * Tipo documento
	 */
	@Column(name = "TIPODOCUMENTO", nullable=false)
	private String documentType;
	 
	/**
	 * Número documento
	 */
	@Column(name = "NUMERODOCUMENTO", nullable=false)
	private String documentId;
	
	/**
	 * Nombre
	 */
	@Column(name = "NOMBRE", nullable=false)
	private String name;
	
	/**
	 * Descripción
	 */
	@Column(name = "DESCRIPCION", nullable=true)
	private String description;
	
	/**
	 * Estado
	 */
	@Column(name = "ESTADO", nullable=true)
	private short status;
	
	/**
	 * Fecha de creación registro
	 */
	@Column(name = "FECHACREACION", nullable=true)
	@Temporal(TemporalType.TIMESTAMP)
	private Date rowCreationDate;
	
	/**
	 * Fecha de modificación del registro
	 */
	@Column(name = "FECHAMODIFICACION", nullable=true)
	@Temporal(TemporalType.TIMESTAMP)
	private Date rowLastUpdate;
	
	/**
	 * Indica si el registro tiene marca lógica de borrado
	 */
	@Column(name="REGELIMINADO", nullable=true)
	private boolean rowDeleted;
	
	/**
	 * Fecha de expiración
	 */
	@Column(name = "FECHAEXPIRACION", nullable=true)
	@Temporal(TemporalType.TIMESTAMP)
	private Date rowExpirationDate;

	/**
	 * Justificación
	 */
	@Column(name = "JUSTIFICACION", nullable=false)
	private String justification;
	
	/**
	 * Email del solicitante
	 */
	@Column(name = "EMAILSOLICITANTE", nullable=false)
	private String applicantEmail;
	
	/**
	 * Construye un tema sin especificar sus parámetros.
	 */
	public BlackList(){
		super();
	}

	@Override
	public boolean isRowDeleted() {
		return rowDeleted;
	}

	@Override
	public void setRowDeleted(boolean rowDeleted) {
		this.rowDeleted = rowDeleted;
		
	}

	@Override
	public Date getRowCreationDate() {
		return rowCreationDate;
	}

	@Override
	public void setRowCreationDate(Date rowCreationDate) {
		this.rowCreationDate = rowCreationDate;
	}

	@Override
	public Date getRowLastUpdate() {
		return rowLastUpdate;
	}

	@Override
	public void setRowLastUpdate(Date rowLastUpdate) {
		this.rowLastUpdate = rowLastUpdate;
	}
	
	public Date getExpirationDate() {
		return rowExpirationDate;
	}

	public void setExpirationDate(Date rowExpirationDate) {
		this.rowExpirationDate = rowExpirationDate;
	}
	
	public String getJustification() {
		return justification;
	}

	public void setJustification(String justification) {
		this.justification = justification;
	}
	
	public String getApplicantEmail() {
		return applicantEmail;
	}

	public void setApplicantEmail(String applicantEmail) {
		this.applicantEmail = applicantEmail;
	}
	
	/**
	 * Id de lista negra
	 * 
	 * @return id
	 */
	public Long getId() {
		return id;
	}
	
	/**
	 *  Establece el identificador único de la lista negra.
	 *  
	 * @param id
	 */
	public void setId(Long id) {
		this.id = id;
	}

	/**
	 * Retorna el documentType de la lista negra.
	 * 
	 * @return documentType
	 */
	public String getDocumentType() {
		return documentType;
	}

	/**
	 *  Establece el documentType de la lista negra.
	 *  
	 * @param documentType
	 */
	public void setDocumentType(String documentType) {
		this.documentType = documentType;
	}

	/**
	 * Retorna el documentId de la lista negra.
	 * 
	 * @return documentId
	 */
	public String getDocumentId() {
		return documentId;
	}

	/**
	 *  Establece el documentId de la lista negra.
	 *  
	 * @param documentId
	 */
	public void setDocumentId(String documentId) {
		this.documentId = documentId;
	}

	/**
	 * Retorna el name de la lista negra.
	 * 
	 * @return name
	 */
	public String getName() {
		return name;
	}

	/**
	 *  Establece el name de la lista negra.
	 *  
	 * @param name
	 */
	public void setName(String name) {
		this.name = name;
	}

	/**
	 * Retorna description de la lista negra.
	 * 
	 * @return description
	 */
	public String getDescription() {
		return description;
	}

	/**
	 *  Establece description de la lista negra.
	 *  
	 * @param description
	 */
	public void setDescription(String description) {
		this.description = description;
	}

	/**
	 * Retorna status de la lista negra.
	 * 
	 * @return status
	 */
	public short getStatus() {
		return status;
	}

	/**
	 *  Establece status de la lista negra.
	 *  
	 * @param status de la lista negra
	 */
	public void setStatus(short status) {
		this.status = status;
	}

	
}