/*
 * AVALFileDAOImpl
 *  
 * GSI - Integración
 * Creado el: 29/08/2014
 *
 * Copyright (c) A Toda Hora S.A. Todos los derechos reservados
 * 
 * Este software es confidencial y es propietario de ATH, queda prohibido
 * su uso, reproducción y copia de manera parcial o permanente salvo autorización
 * expresa de A Toda Hora S.A o de quién represente sus derechos.
 */
package co.com.ath.pgw.persistence.dao.impl;

import javax.persistence.NoResultException;
import javax.persistence.NonUniqueResultException;
import javax.persistence.Query;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Repository;

import co.com.ath.pgw.persistence.AbstractDAO_JPA;
import co.com.ath.pgw.persistence.dao.AVALFileDAO;
import co.com.ath.pgw.persistence.model.AVALFile;

/**
 * Implementación por defecto de AVALFileDAO
 *
 * @author Andrés Méndez Juanias <proveedor_mamendez@ath.com.co>
 * @version 1.0 17/12/2014
 * @since 1.0
 */
@Repository
public class AVALFileDAOImpl 
					extends AbstractDAO_JPA<AVALFile> implements AVALFileDAO {
	
	static Logger LOGGER = LoggerFactory.getLogger(AVALFileDAOImpl.class);

	public AVALFileDAOImpl() {
		super(AVALFile.class);
	}

	@Override
	public AVALFile findByName(String fileName) {
		
		StringBuilder hql = new StringBuilder("from AVALFile f ");
		hql.append("where f.rowDeleted <> 1 ");
		hql.append("and f.name = :fileName ");
		
        Query query = entityManager.createQuery(hql.toString());
		query.setParameter("fileName", fileName);
		
		AVALFile avalFile = null;
		
		try {
			avalFile = (AVALFile) query.getSingleResult(); 
		} catch (NoResultException e) {
			LOGGER.info("Resultado del query: {}", e.toString());
			return null;
		} catch (NonUniqueResultException e){
			LOGGER.warn("Problemas en query: \n{}", e.toString());
            return null;
        }
		return avalFile;
	}

}
