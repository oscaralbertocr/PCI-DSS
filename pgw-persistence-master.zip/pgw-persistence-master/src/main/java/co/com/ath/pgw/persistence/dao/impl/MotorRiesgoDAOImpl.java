/*
 * HistoricSmsDAOImpl
 *  
 * PASARELA DE PAGOS - Recaudos.
 * Creado el: 14/07/2016
 *
 * Copyright (c) A Toda Hora S.A. Todos los derechos reservados
 * 
 * Este software es confidencial y es propietario de ATH, queda prohibido
 * su uso, reproducción y copia de manera parcial o permanente salvo autorización
 * expresa de A Toda Hora S.A o de quién represente sus derechos.
 */
package co.com.ath.pgw.persistence.dao.impl;

import java.math.BigInteger;

import javax.persistence.NoResultException;
import javax.persistence.NonUniqueResultException;
import javax.persistence.Query;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Repository;

import co.com.ath.pgw.persistence.AbstractDAO_JPA;
import co.com.ath.pgw.persistence.dao.MotorRiesgoDAO;
import co.com.ath.pgw.persistence.model.MotorRiesgo;

/**
 * Implementación por defecto de HistoricSmsDAO
 *
 * @author Camilo Andres Bustamante <proveedor_cbustamant@ath.com.co>
 * @version 1.0 14 Sept 2016
 * @since 1.0
 */
@Repository
public class MotorRiesgoDAOImpl extends AbstractDAO_JPA<MotorRiesgo> implements MotorRiesgoDAO {

	static Logger LOGGER = LoggerFactory.getLogger(MotorRiesgoDAOImpl.class);
	
	public MotorRiesgoDAOImpl() {
		super(MotorRiesgo.class);
	}

	@Override
	public MotorRiesgo findLastQuery(BigInteger pmtid) {

		StringBuilder hql = new StringBuilder(" FROM MotorRiesgo MR ");
		hql.append(" WHERE MR.pmtid = :pmtid ");
		hql.append(" AND ROWNUM = 1 ");
		hql.append(" ORDER BY MR.Id DESC ");
		
		Query query = entityManager.createQuery(hql.toString());
		query.setParameter("pmtid", pmtid);
		
		MotorRiesgo rsa = null;
		
		try {
			rsa = (MotorRiesgo) query.getSingleResult();
		} catch (NoResultException ex) {
			LOGGER.warn("MotorRiesgo, La consulta no retorno ningun registro. {}", ex.toString());
			return null;
		} catch (NonUniqueResultException ex) {
			LOGGER.warn("MotorRiesgo, La consulta no retorno un unico registro. {}", ex.toString());
			return null;
		}
		return rsa;

	}
	
}
