/*
 * Download
 *  
 * GSI - Integración
 * Creado el: 28/08/2014
 *
 * Copyright (c) A Toda Hora S.A. Todos los derechos reservados
 * 
 * Este software es confidencial y es propietario de ATH, queda prohibido
 * su uso, reproducción y copia de manera parcial o permanente salvo autorización
 * expresa de A Toda Hora S.A o de quién represente sus derechos.
 */
package co.com.ath.pgw.persistence.model;

import java.math.BigDecimal;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

import co.com.ath.pgw.persistence.PersistentObject;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;




/**
 * The persistent class for the DESCARGA database table.
 * 
 */
@Entity
@Table(name="DESCARGA")
public class Download implements PersistentObject {

	/**
	 * 
	 */
	private static final long serialVersionUID = -3925286150446671394L;

	/** id Atributo de la clase. */
	@Id
    @Column(name = "ID")
	@SequenceGenerator(name="DESCARGA_ID_GENERATOR", sequenceName="DESCARGA_SEC")
	@GeneratedValue(strategy=GenerationType.SEQUENCE, generator="DESCARGA_ID_GENERATOR")
	private Long id;

	/** userId Atributo de la clase. */
	@Column(name="IDUSUARIO")
	private String userId;
	
	//uni-directional many-to-one association to DownloadStatus
	/** estadosdescarga Atributo de la clase. */
	@ManyToOne(fetch=FetchType.LAZY)
	@JoinColumn(name="IDESTADO")
	private DownloadStatus downloadStatus;
	
	/** format Atributo de la clase. */
	@Column(name="FORMATO")
	private BigDecimal format;
	
	/** userArchive Atributo de la clase. */
	@Column(name="ARCHIVOUSUARIO")
	private String userFile;
	
	/** systemFile Atributo de la clase. */
	@Column(name="ARCHIVOSYSTEMA")
	private String systemFile;	

	/** startingDate Atributo de la clase. */
	@Column(name="FECHAINICIAL")
    @Temporal(TemporalType.TIMESTAMP)
	private Date startDate;
	
	/** endingDate Atributo de la clase. */
	@Column(name="FECHAFINAL")
    @Temporal(TemporalType.TIMESTAMP)
	private Date endDate;	

	/** filtro Atributo de la clase. */
	@Column(name="FILTRO")
	private String filter;	

	/** retry Atributo de la clase. */
	@Column(name="INTENTOS")
	private BigDecimal retry;

	/** rowCreationDate Atributo de la clase. */
	@Column(name="REGFECHACREACION")
    @Temporal(TemporalType.TIMESTAMP)
	private Date rowCreationDate;

	/** rowLastUpdate Atributo de la clase. */
	@Column(name="REGFECHAMODIFICACION")
    @Temporal(TemporalType.TIMESTAMP)
	private Date rowLastUpdate;

	/** rowDeleted Atributo de la clase. */
	@Column(name="REGELIMINADO")
	private boolean rowDeleted;

	public Download() {}

	/**
	 * Método encargado de recuperar el valor del atributo id.
	 * @return El atributo id asociado a la clase.
	 */
	public Long getId() {
		return id;
	}

	/**
	 * Método encargado de actualizar el atributo id.
	 * @param id Nuevo valor para id.
	 */
	public void setId(Long id) {
		this.id = id;
	}

	/**
	 * Método encargado de recuperar el valor del atributo userId.
	 * @return El atributo userId asociado a la clase.
	 */
	public String getUserId() {
		return userId;
	}

	/**
	 * Método encargado de actualizar el atributo userId.
	 * @param userId Nuevo valor para userId.
	 */
	public void setUserId(String userId) {
		this.userId = userId;
	}

	/**
	 * Método encargado de recuperar el valor del atributo statusId.
	 * @return El atributo statusId asociado a la clase.
	 */
	public DownloadStatus getStatusId() {
		return downloadStatus;
	}

	/**
	 * Método encargado de actualizar el atributo statusId.
	 * @param statusId Nuevo valor para statusId.
	 */
	public void setStatusId(DownloadStatus downloadStatus) {
		this.downloadStatus = downloadStatus;
	}

	/**
	 * Método encargado de recuperar el valor del atributo format.
	 * @return El atributo format asociado a la clase.
	 */
	public BigDecimal getFormat() {
		return format;
	}

	/**
	 * Método encargado de actualizar el atributo format.
	 * @param format Nuevo valor para format.
	 */
	public void setFormat(BigDecimal format) {
		this.format = format;
	}

	/**
	 * Método encargado de recuperar el valor del atributo userFile.
	 * @return El atributo userFile asociado a la clase.
	 */
	public String getUserFile() {
		return userFile;
	}

	/**
	 * Método encargado de actualizar el atributo userFile.
	 * @param userFile Nuevo valor para userFile.
	 */
	public void setUserFile(String userFile) {
		this.userFile = userFile;
	}

	/**
	 * Método encargado de recuperar el valor del atributo systemFile.
	 * @return El atributo systemFile asociado a la clase.
	 */
	public String getSystemFile() {
		return systemFile;
	}

	/**
	 * Método encargado de actualizar el atributo systemFile.
	 * @param systemFile Nuevo valor para systemFile.
	 */
	public void setSystemFile(String systemFile) {
		this.systemFile = systemFile;
	}

	/**
	 * Método encargado de recuperar el valor del atributo startDate.
	 * @return El atributo startDate asociado a la clase.
	 */
	public Date getStartDate() {
		return startDate;
	}

	/**
	 * Método encargado de actualizar el atributo startDate.
	 * @param startDate Nuevo valor para startDate.
	 */
	public void setStartDate(Date startDate) {
		this.startDate = startDate;
	}

	/**
	 * Método encargado de recuperar el valor del atributo endDate.
	 * @return El atributo endDate asociado a la clase.
	 */
	public Date getEndDate() {
		return endDate;
	}

	/**
	 * Método encargado de actualizar el atributo endDate.
	 * @param endDate Nuevo valor para endDate.
	 */
	public void setEndDate(Date endDate) {
		this.endDate = endDate;
	}

	/**
	 * Método encargado de recuperar el valor del atributo filter.
	 * @return El atributo filter asociado a la clase.
	 */
	public String getFilter() {
		return filter;
	}

	/**
	 * Método encargado de actualizar el atributo filter.
	 * @param filter Nuevo valor para filter.
	 */
	public void setFilter(String filter) {
		this.filter = filter;
	}

	/**
	 * Método encargado de recuperar el valor del atributo retry.
	 * @return El atributo retry asociado a la clase.
	 */
	public BigDecimal getRetry() {
		return retry;
	}

	/**
	 * Método encargado de actualizar el atributo retry.
	 * @param retry Nuevo valor para retry.
	 */
	public void setRetry(BigDecimal retry) {
		this.retry = retry;
	}

	/**
	 * Método encargado de recuperar el valor del atributo rowCreationDate.
	 * @return El atributo rowCreationDate asociado a la clase.
	 */
	public Date getRowCreationDate() {
		return rowCreationDate;
	}

	/**
	 * Método encargado de actualizar el atributo rowCreationDate.
	 * @param rowCreationDate Nuevo valor para rowCreationDate.
	 */
	public void setRowCreationDate(Date rowCreationDate) {
		this.rowCreationDate = rowCreationDate;
	}

	/**
	 * Método encargado de recuperar el valor del atributo rowLastUpdate.
	 * @return El atributo rowLastUpdate asociado a la clase.
	 */
	public Date getRowLastUpdate() {
		return rowLastUpdate;
	}

	/**
	 * Método encargado de actualizar el atributo rowLastUpdate.
	 * @param rowLastUpdate Nuevo valor para rowLastUpdate.
	 */
	public void setRowLastUpdate(Date rowLastUpdate) {
		this.rowLastUpdate = rowLastUpdate;
	}

	/**
	 * Método encargado de recuperar el valor del atributo rowDeleted.
	 * @return El atributo rowDeleted asociado a la clase.
	 */
	public boolean isRowDeleted() {
		return rowDeleted;
	}

	/**
	 * Método encargado de actualizar el atributo rowDeleted.
	 * @param rowDeleted Nuevo valor para rowDeleted.
	 */
	public void setRowDeleted(boolean rowDeleted) {
		this.rowDeleted = rowDeleted;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + (int) (id ^ (id >>> 32));
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Download other = (Download) obj;
		if (id != other.id)
			return false;
		return true;
	}

	@Override
	public String toString() {
		return "Download [userId=" + userId + ", downloadStatus=" + downloadStatus
				+ ", format=" + format + ", userFile=" + userFile
				+ ", systemFile=" + systemFile + ", startDate=" + startDate
				+ ", endDate=" + endDate + ", retry=" + retry + ", rowDeleted="
				+ rowDeleted + "]";
	}
	
}