/*
 * BatchJobExecution
 *  
 * GSI - Integración
 * Creado el: 14/04/2015
 *
 * Copyright (c) A Toda Hora S.A. Todos los derechos reservados
 * 
 * Este software es confidencial y es propietario de ATH, queda prohibido
 * su uso, reproducción y copia de manera parcial o permanente salvo autorización
 * expresa de A Toda Hora S.A o de quién represente sus derechos.
 */
package co.com.ath.pgw.persistence.model;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

/**
 * Clase que representa un registro del JOB.
 * 
 * @author Andrés Méndez <proveedor_mamendez@ath.com.co>
 * @version 14/04/2015
 * @since 1.0
 */
@Entity
@Table(name="BATCH_JOB_EXECUTION")
public class BatchJobExecution implements Serializable {

	/**
	 * ID de serialización.
	 */
	private static final long serialVersionUID = 1786118152957467367L;

	/**
	 * Identificador único del job.
	 */
	@Id
	@SequenceGenerator(
			name="BATCH_JOB_EXECUTION_ID_GENERATOR",
			sequenceName="BATCH_JOB_EXECUTION_SEQ",
			initialValue=1,
			allocationSize=1
			)
	@GeneratedValue(
			strategy=GenerationType.SEQUENCE,
			generator="BATCH_JOB_EXECUTION_ID_GENERATOR"
			)
	
	@Column(name="JOB_EXECUTION_ID", nullable=false)
	private Long id;
	
	@Column(name = "VERSION", nullable = true)
	private Long version;
	
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "JOB_INSTANCE_ID")
	private BatchJobInstance batchJobInstance;
	
	@Column(name="CREATE_TIME", nullable=false)
	@Temporal(TemporalType.TIMESTAMP)
	private Date createTime;
	
	@Column(name="START_TIME", nullable=true)
	@Temporal(TemporalType.TIMESTAMP)
	private Date startTime;
	
	@Column(name="END_TIME", nullable=true)
	@Temporal(TemporalType.TIMESTAMP)
	private Date endTime;
	
	@Column(name="STATUS", nullable=true)
	private String status;
	
	@Column(name="EXIT_CODE", nullable=true)
	private String exitCode;
	
	@Column(name="EXIT_MESSAGE", nullable=true)
	private String exitMessage;
	
	@Column(name="LAST_UPDATED", nullable=true)
	@Temporal(TemporalType.TIMESTAMP)
	private Date lastUpdated;

	@Column(name="JOB_CONFIGURATION_LOCATION", nullable=true)
	private String jobConfigurationLocation;
	
	/**
	 * Constructor por defecto de un Banco
	 */
	public BatchJobExecution(){
		super();
	}
	
	/**
	 * Método encargado de recuperar el valor del atributo id.
	 * @return El atributo id asociado a la clase.
	 */
	public Long getId() {
		return id;
	}

	/**
	 * Método encargado de actualizar el atributo id.
	 * @param id Nuevo valor para id.
	 */
	public void setId(Long id) {
		this.id = id;
	}

	/**
	 * Método encargado de recuperar el valor del atributo status.
	 * @return El atributo status asociado a la clase.
	 */
	public String getStatus() {
		return status;
	}

	/**
	 * Método encargado de actualizar el atributo status.
	 * @param status Nuevo valor para status.
	 */
	public void setStatus(String status) {
		this.status = status;
	}

	/**
	 * Método encargado de actualizar el atributo version.
	 * @param version Nuevo valor para version.
	 */
	public Long getVersion() {
		return version;
	}

	/**
	 * Método encargado de actualizar el atributo version.
	 * @param version Nuevo valor para version.
	 */
	public void setVersion(Long version) {
		this.version = version;
	}

	/**
	 * Método encargado de recuperar el valor del atributo batchJobInstance.
	 * @return El atributo batchJobInstance asociado a la clase.
	 */
	public BatchJobInstance getBatchJobInstance() {
		return batchJobInstance;
	}

	/**
	 * Método encargado de actualizar el atributo batchJobInstance.
	 * @param batchJobInstance Nuevo valor para batchJobInstance.
	 */
	public void setBatchJobInstance(BatchJobInstance batchJobInstance) {
		this.batchJobInstance = batchJobInstance;
	}

	/**
	 * Método encargado de actualizar el atributo createTime.
	 * @param createTime Nuevo valor para createTime.
	 */
	public Date getCreateTime() {
		return createTime;
	}
	
	/**
	 * Método encargado de actualizar el atributo createTime.
	 * @param createTime Nuevo valor para createTime.
	 */
	public void setCreateTime(Date createTime) {
		this.createTime = createTime;
	}

	/**
	 * Método encargado de actualizar el atributo startTime.
	 * @param startTime Nuevo valor para startTime.
	 */
	public Date getStartTime() {
		return startTime;
	}

	/**
	 * Método encargado de actualizar el atributo startTime.
	 * @param startTime Nuevo valor para startTime.
	 */
	public void setStartTime(Date startTime) {
		this.startTime = startTime;
	}

	/**
	 * Método encargado de actualizar el atributo endTime.
	 * @param endTime Nuevo valor para endTime.
	 */
	public Date getEndTime() {
		return endTime;
	}

	/**
	 * Método encargado de actualizar el atributo endTime.
	 * @param endTime Nuevo valor para endTime.
	 */
	public void setEndTime(Date endTime) {
		this.endTime = endTime;
	}

	/**
	 * Método encargado de actualizar el atributo exitCode.
	 * @param exitCode Nuevo valor para exitCode.
	 */
	public String getExitCode() {
		return exitCode;
	}

	/**
	 * Método encargado de actualizar el atributo exitCode.
	 * @param exitCode Nuevo valor para exitCode.
	 */
	public void setExitCode(String exitCode) {
		this.exitCode = exitCode;
	}

	/**
	 * Método encargado de actualizar el atributo exitMessage.
	 * @param exitMessage Nuevo valor para exitMessage.
	 */
	public String getExitMessage() {
		return exitMessage;
	}

	/**
	 * Método encargado de actualizar el atributo exitMessage.
	 * @param exitMessage Nuevo valor para exitMessage.
	 */
	public void setExitMessage(String exitMessage) {
		this.exitMessage = exitMessage;
	}

	/**
	 * Método encargado de actualizar el atributo lastUpdated.
	 * @param lastUpdated Nuevo valor para lastUpdated.
	 */
	public Date getLastUpdated() {
		return lastUpdated;
	}

	/**
	 * Método encargado de actualizar el atributo lastUpdated.
	 * @param lastUpdated Nuevo valor para lastUpdated.
	 */
	public void setLastUpdated(Date lastUpdated) {
		this.lastUpdated = lastUpdated;
	}

	/**
	 * Método encargado de actualizar el atributo jobConfigurationLocation.
	 * @param jobConfigurationLocation Nuevo valor para jobConfigurationLocation.
	 */
	public String getJobConfigurationLocation() {
		return jobConfigurationLocation;
	}

	/**
	 * Método encargado de actualizar el atributo jobConfigurationLocation.
	 * @param jobConfigurationLocation Nuevo valor para jobConfigurationLocation.
	 */
	public void setJobConfigurationLocation(String jobConfigurationLocation) {
		this.jobConfigurationLocation = jobConfigurationLocation;
	}

}