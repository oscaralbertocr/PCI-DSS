package co.com.ath.pgw.persistence.validation.model.impl;
import java.util.Locale;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import co.com.ath.pgw.util.i18n.BundleKeys;
import co.com.ath.pgw.util.i18n.BundleType;
import co.com.ath.pgw.util.validation.AbstractAttributeValidator;
import co.com.ath.pgw.util.validation.EmailValidator;
import co.com.ath.pgw.util.validation.ErrorCode;
import co.com.ath.pgw.util.validation.NotEmptyValidator;
import co.com.ath.pgw.util.validation.NotNullValidator;
import co.com.ath.pgw.util.validation.ObjectValidationException;
import co.com.ath.pgw.util.validation.ObjectValidator;
import co.com.ath.pgw.util.validation.ValidationException;


/**
 * Valida la dirección de email de un cliente.
 * 
 * @author proveedor_zagarcia
 * @version 1.0 23-sep-2014
 * @since 1.0
 */
@Service
public class CustomerEmailValidator extends AbstractAttributeValidator {
	
	static Logger LOGGER = LoggerFactory.getLogger(CustomerEmailValidator.class);

	private ObjectValidator validator;

	public CustomerEmailValidator(){
		super();
	}

	@Override
	protected void doMandatoryValidate(Object attribute, Locale locale)
													throws ValidationException {
		validator = new NotNullValidator(new NotEmptyValidator());
		validator.setBundleManager(bundleManager);
		try {
			validator.validate(attribute, locale);
		} catch (ObjectValidationException e) {
			LOGGER.warn("Fallo en validador: \n{}", e.toString());
			throw new ValidationException(
					getMessage(locale), 
					ErrorCode.INVALID_CUSTOMER_EMAIL, e);
		}
		doOptionalValidate(attribute, locale);
	}

	@Override
	protected void doOptionalValidate(Object attribute, Locale locale)
													throws ValidationException {
		if (attribute == null || attribute.toString().trim().length() == 0) {
			return;
		}
		validator = new EmailValidator();
		validator.setBundleManager(bundleManager);
		try {
			validator.validate(attribute, locale);
		} catch (ObjectValidationException e) {
			LOGGER.warn("Fallo en validador: \n{}", e.toString());
			throw new ValidationException(
					getMessage(locale), 
					ErrorCode.INVALID_CUSTOMER_EMAIL, e);
		}
		
	}
	
	private String getMessage(Locale locale) {
		if (bundleManager == null) {
			return BundleKeys.ERROR_INVALID_CUSTOMER_EMAIL;
		}
		bundleManager.setBundle(BundleType.ERRORS);
		return bundleManager.getMessage(
			BundleKeys.ERROR_INVALID_CUSTOMER_EMAIL, null, locale);
	}


}