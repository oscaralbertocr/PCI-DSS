/*
 * GetTransactionByTokenValidatorImpl
 *  
 * GSI - Integración
 * Creado el: 20/09/2014
 *
 * Copyright (c) A Toda Hora S.A. Todos los derechos reservados
 * 
 * Este software es confidencial y es propietario de ATH, queda prohibido
 * su uso, reproducción y copia de manera parcial o permanente salvo autorización
 * expresa de A Toda Hora S.A o de quién represente sus derechos.
 */
package co.com.ath.pgw.persistence.validation.model.impl;

import java.util.Locale;

import javax.annotation.Resource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import co.com.ath.pgw.bsn.dto.in.GetTransactionStatusInDTO;
import co.com.ath.pgw.util.i18n.ResourceBundleManager;
import co.com.ath.pgw.util.validation.ValidationException;
import co.com.ath.pgw.util.validation.model.GetTransactionStatusValidator;
import co.com.ath.pgw.util.validation.model.dto.TransactionIdNuraCodeInDTO;

/**
 * Implementación por defecto de GetTransactionStatusValidator.
 * 
 * @author proveedor_zagarcia
 * @version 1.0 28 Sep 2014
 * @since 1.0
 */
@Service
public class GetTransactionStatusValidatorImpl implements GetTransactionStatusValidator {

	@Autowired
	private ResourceBundleManager bundleManager;

	@Resource
	private AgreementValidatorImpl agreementValidator;

	@Resource
	private TransactionIdNuraCodeValidatorImpl transactionIdNuraCodeValidatorImpl;

	@Resource
	private TransactionPmtIdValidator transactionPmtIdValidator;

	private Locale locale;

	public GetTransactionStatusValidatorImpl() {
		super();
		this.locale = Locale.getDefault();
	}

	@Override
	public void validate(GetTransactionStatusInDTO inDTO) throws ValidationException {
		validateTransactionPmtId(inDTO.getTransactionBO().getPmtId());
		// validateAgreement(inDTO.getTransactionBO().getCommerce().getNuraCode());
		// validateIdTransactionNuraCode(inDTO.getTransactionBO().getPmtId(), inDTO.getTransactionBO().getCommerce().getNuraCode());
	}

	private void validateTransactionPmtId(String pmtId) throws ValidationException {
		transactionPmtIdValidator.setMandatory(true);
		transactionPmtIdValidator.setBundleManager(bundleManager);
		transactionPmtIdValidator.validate(pmtId, locale);
	}

	private void validateIdTransactionNuraCode(String pmtId, String nuraCode) throws ValidationException {
		TransactionIdNuraCodeInDTO data = new TransactionIdNuraCodeInDTO();
		data.setPmtIdTransaction(pmtId);
		data.setNuraCode(nuraCode);
		data.setLocale(locale);
		transactionIdNuraCodeValidatorImpl.validate(data);
	}

	/**
	 * 
	 * @param nuraCode
	 * @throws ValidationException
	 */
	private void validateAgreement(String nuraCode) throws ValidationException {
//	    agreementValidator.setMandatory(true);
//	    agreementValidator.setBundleManager(bundleManager);
		agreementValidator.validate(nuraCode, locale);
	}

}
