package co.com.ath.pgw.persistence.model;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Id;
import javax.persistence.Entity;
import javax.persistence.Table;

import co.com.ath.pgw.persistence.PersistentObject;


@Entity
@Table(name = "REPORT_TLF")
public class ReportTLF implements PersistentObject {

	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	@Id
	@Column(name = "RESULTADO")
	private String resultado;

	public final String getResultado() {
		return resultado;
	}
	@Override
	public boolean isRowDeleted() {
		// TODO Auto-generated method stub
		return false;
	}
	@Override
	public void setRowDeleted(boolean rowDeleted) {
		// TODO Auto-generated method stub
		
	}
		@Override
	public Date getRowCreationDate() {
		// TODO Auto-generated method stub
		return null;
	}
		@Override
	public void setRowCreationDate(Date rowCreationDate) {
		// TODO Auto-generated method stub
		
	}
		@Override
	public Date getRowLastUpdate() {
		// TODO Auto-generated method stub
		return null;
	}

	public void setRowLastUpdate(Date rowLastUpdate) {
		// TODO Auto-generated method stub
		
	}

	public void setResultado(String resultado) {
		// TODO Auto-generated method stub
		
	}

	
}
