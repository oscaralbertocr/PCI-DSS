/*
 * PaymentWay
 *  
 * GSI - Integración
 * Creado el: 28/08/2014
 *
 * Copyright (c) A Toda Hora S.A. Todos los derechos reservados
 * 
 * Este software es confidencial y es propietario de ATH, queda prohibido
 * su uso, reproducción y copia de manera parcial o permanente salvo autorización
 * expresa de A Toda Hora S.A o de quién represente sus derechos.
 */
package co.com.ath.pgw.persistence.model;

import java.util.Date;
import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.ManyToMany;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import co.com.ath.pgw.persistence.PersistentObject;


/**
 * Entidad persistente que representa un medio de pago válido en la Pasarela de
 * Pagos AVAL.
 * 
 * @author proveedor_japiza
 * @version 1.0 29 Ago 2014 
 * @since
 *
 *  @RQ27199
 *  <strong>Autor</strong>Jordan Andrei Cortes y Mauricio Tascon</br>
 *  <strong>Descripcion</strong> Validcación de Topes</br>
 *  <strong>Numero de Cambios</strong>2</br>
 *  <strong>Identificador corto</strong>C01</br>
 *
 */
@Entity
@Table(name="MEDIOSPAGO")
public class PaymentWay implements PersistentObject {	

	/**
	 * 
	 */
	private static final long serialVersionUID = 4551213890982367073L;

	/**
	 * Identificador único del medio de pago en el Core de la Pararela de Pagos.
	 */
	@Id
    @Column(name = "ID")
	private Long id;

	/** 
	 * Nombre del medio de pago.
	 */
	@Column(name="MEDIOPAGO")
	private String name;
	
	/**
	 * Comercios que admiten el medio de pago.
	 */
	@ManyToMany(fetch =  FetchType.LAZY, mappedBy = "paymentWays")
	private List<Commerce> commerces;
	
	@OneToMany(fetch =  FetchType.LAZY,mappedBy="paymentWay")
	private List<PaymentWayByCommerce> paymentWayByCommerce;

	/**
	 * Fecha de creación del registro.
	 */
	@Column(name="REGFECHACREACION")
    @Temporal(TemporalType.TIMESTAMP)
	private Date rowCreationDate;

	/**
	 * Fecha de la última modificación del registro.
	 */
	@Column(name="REGFECHAMODIFICACION")
    @Temporal(TemporalType.TIMESTAMP)
	private Date rowLastUpdate;
	
	/**
	 * Indica si el registro tiene marca de borrado lógico.
	 */
	@Column(name="REGELIMINADO")
	private boolean rowDeleted;

	
	
	/**
	 * Construye un medio de pago
	 */
	/**INI C01**/
	public PaymentWay(){
		super();
	}
	/**FIN C01**/
	
	/**
	 * Construye un medio de pago especificando el id.
	 * @param id Identificador del medio de pago.
	 */
	/**INI C01**/
	public PaymentWay(Long id){
		this.id = id;
	}
	/**FIN C01**/

	/**
	 * Retorna el identificador único del medio de pago en el Core de la 
	 * Pararela de Pagos.
	 * 
	 * @return Identificador del medio de pago.
	 */
	public Long getId() {
		return id;
	}

	/**
	 * Establece el identificador único del medio de pago en el Core de la 
	 * Pararela de Pagos.
	 * 
	 * @param id Identificador del medio de pago.
	 */
	public void setId(Long id) {
		this.id = id;
	}

	/**
	 * Retorna el nombre del medio de pago.
	 * 
	 * @return Nombre del medio de pago.
	 */
	public String getName() {
		return name;
	}


	/**
	 * Establece el nombre del medio de pago.
	 * 
	 * @param name Nombre del medio de pago.
	 */
	public void setPaymentWay(String name) {
		this.name = name;
	}

	/**
	 * Retorna la lista de comercios que admiten este medio de pago.
	 * 
	 * @return the commerces Comercios habilitados para el medio de pago.
	 */
	public List<Commerce> getCommerces() {
		return commerces;
	}

	/**
	 * @param commerces the commerces to set
	 */
	public void setCommerces(List<Commerce> commerces) {
		this.commerces = commerces;
	}

	@Override
	public Date getRowCreationDate() {
		return rowCreationDate;
	}


	@Override
	public void setRowCreationDate(Date rowCreationDate) {
		this.rowCreationDate = rowCreationDate;
	}


	@Override
	public Date getRowLastUpdate() {
		return rowLastUpdate;
	}


	@Override
	public void setRowLastUpdate(Date rowLastUpdate) {
		this.rowLastUpdate = rowLastUpdate;
	}


	@Override
	public boolean isRowDeleted() {
		return rowDeleted;
	}


	@Override
	public void setRowDeleted(boolean rowDeleted) {
		this.rowDeleted = rowDeleted;
	}
	
	

	public List<PaymentWayByCommerce> getPaymentWayByCommerce() {
		return paymentWayByCommerce;
	}

	public void setPaymentWayByCommerce(
			List<PaymentWayByCommerce> paymentWayByCommerce) {
		this.paymentWayByCommerce = paymentWayByCommerce;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + (int) (id ^ (id >>> 32));
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		PaymentWay other = (PaymentWay) obj;
		if (id != other.id)
			return false;
		return true;
	}

	@Override
	public String toString() {
		return "PaymentWay [name=" + name + ", rowDeleted="
				+ rowDeleted + "]";
	}

}