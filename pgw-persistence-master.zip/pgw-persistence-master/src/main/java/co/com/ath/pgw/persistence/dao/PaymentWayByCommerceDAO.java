package co.com.ath.pgw.persistence.dao;

import java.util.List;

import co.com.ath.pgw.persistence.DataAccessObject;
import co.com.ath.pgw.persistence.model.Commerce;
import co.com.ath.pgw.persistence.model.NonWorkingDay;
import co.com.ath.pgw.persistence.model.PaymentWayByCommerce;

public interface PaymentWayByCommerceDAO extends DataAccessObject<PaymentWayByCommerce>{
	
	public PaymentWayByCommerce findByComerce(Long idComercio);
	
	
}
