/*
 * Token
 *  
 * GSI - Integración
 * Creado el: 29/08/2014
 *
 * Copyright (c) A Toda Hora S.A. Todos los derechos reservados
 * 
 * Este software es confidencial y es propietario de ATH, queda prohibido
 * su uso, reproducción y copia de manera parcial o permanente salvo autorización
 * expresa de A Toda Hora S.A o de quién represente sus derechos.
 */
package co.com.ath.pgw.persistence.model;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import co.com.ath.pgw.persistence.PersistentObject;

/**
 * Representa el token generado para una transacción. Esta entidad pertenece
 * al modelo persistente.
 * 
 * @author proveedor_japiza
 * @version 1.0 29 Ago 2014
 * @since 1.0
 */
@Entity
@Table(name = "TOKEN")
public class Token implements PersistentObject {

	/**
	 * 
	 */
	private static final long serialVersionUID = -6239451815767935688L;

	/**
	 * Identificador único del Token.
	 */
	@Id
    @Column(name = "ID")
	private String id;

	/**
	 * Transacción asociada con el Token.
	 */
	@OneToOne(fetch=FetchType.EAGER)
	@JoinColumn(name="IDTRANSACCION")
	private Transaction transaction;
	
	/**
	 * Fecha de creación del Token.
	 */
	@Column(name="FECHACREACION")
    @Temporal(TemporalType.TIMESTAMP)
	private Date creationDate;

	/**
	 * Fecha de expiración del Token.
	 */
	@Column(name="FECHAEXPIRACION")
    @Temporal(TemporalType.TIMESTAMP)
	private Date expirationDate;
	
	/**
	 * Estado del Token
	 */
	@Column(name="ESTADO")
	private String status;	

	/**
	 * Número de intentos de consulta del token.
	 */
	@Column(name="INTENTO")
	private Integer retryCount;

	/**
	 * Indica si el registro tiene marca lógica de borrado
	 */
	@Column(name="REGELIMINADO", nullable=true)
	private boolean rowDeleted;
	
	/**
	 * Fecha de creación del registro
	 */
	@Temporal(TemporalType.TIMESTAMP)
	@Column(name="REGFECHACREACION", nullable=true)
	private Date rowCreationDate;
	
	/**
	 * Fecha de última modificación del registro
	 */
	@Temporal(TemporalType.TIMESTAMP)
	@Column(name="REGFECHAMODIFICACION", nullable=true)
	private Date rowLastUpdate;

	/**
	 * Construye el Token de una transacción.
	 */
	public Token(){
		super();
	}
	
	/**
	 * Construye un token de una transacción especificando su id.
	 * 
	 * @param id Identificador de transacción.
	 */
	Token(String id){
		this.id = id;
	}

	/**
	 * Retorna el identificador único del Token.
	 * 
	 * @return Identificador del Token.
	 */
	public String getId() {
		return id;
	}

	/**
	 * Establece el identificador único del Token.
	 * 
	 * @param id Identificador del Token.
	 */
	public void setId(String id) {
		this.id = id;
	}

	/**
	 * Retorna la transacción asociada al Token.
	 * 
	 * @return Transacción asociada al Token.
	 */
	public Transaction getTransaction() {
		return transaction;
	}

	/**
	 * Establece la transacción asociada al Token.
	 * 
	 * @param transaction Transacción asociada al Token.
	 */
	public void setTransaction(Transaction transaction) {
		this.transaction = transaction;
	}

	/**
	 * Retorna la fecha de creación del Token.
	 * 
	 * @return Fecha de creación del Token.
	 */
	public Date getCreationDate() {
		return creationDate;
	}

	/**
	 * Establece la fecha de creación del Token.
	 * 
	 * @param creationDate Fecha de creación del Token.
	 */
	public void setCreationDate(Date creationDate) {
		this.creationDate = creationDate;
	}

	/**
	 * Retorna la fecha de expiración del Token.
	 * 
	 * @return Fecha de expiración del Token.
	 */
	public Date getExpirationDate() {
		return expirationDate;
	}

	/**
	 * Establece la fecha de expiración del Token.
	 * 
	 * @param expirationDate Fecha de expiración del Token.
	 */
	public void setExpirationDate(Date expirationDate) {
		this.expirationDate = expirationDate;
	}

	/**
	 * Retorna el estado del Token.
	 * 
	 * @return Estado del Token.
	 */
	public String getStatus() {
		return status;
	}

	/**
	 * Establece el estado del Token.
	 * 
	 * @param status Estado del Token.
	 */
	public void setStatus(String status) {
		this.status = status;
	}

	/**
	 * Retorna el número de intentos de consulta del token.
	 * 
	 * @return Número de intentos de consulta del token.
	 */
	public Integer getRetryCount() {
		return retryCount;
	}

	/**
	 * Establece el número de intentos de consulta del token.
	 * 
	 * @param retryCount Número de intentos de consulta.
	 */
	public void setRetryCount(Integer retryCount) {
		this.retryCount = retryCount;
	}

	@Override
	public boolean isRowDeleted() {
		return rowDeleted;
	}

	@Override
	public void setRowDeleted(boolean rowDeleted) {
		this.rowDeleted = rowDeleted;
		
	}

	@Override
	public Date getRowCreationDate() {
		return rowCreationDate;
	}

	@Override
	public void setRowCreationDate(Date rowCreationDate) {
		this.rowCreationDate = rowCreationDate;
	}

	@Override
	public Date getRowLastUpdate() {
		return rowLastUpdate;
	}

	@Override
	public void setRowLastUpdate(Date rowLastUpdate) {
		this.rowLastUpdate = rowLastUpdate;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((id == null) ? 0 : id.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Token other = (Token) obj;
		if (id == null) {
			if (other.id != null)
				return false;
		} else if (!id.equals(other.id))
			return false;
		return true;
	}
	
	@Override
	public String toString() {
		return "Token [id=" + id + ", transaction=" + transaction + ", status="
				+ status + ", retryCount=" + retryCount + ", rowDeleted="
				+ rowDeleted + "]";
	}

}