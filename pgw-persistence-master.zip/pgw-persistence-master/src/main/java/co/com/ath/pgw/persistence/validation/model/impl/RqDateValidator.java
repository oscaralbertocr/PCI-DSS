/*
 * RqDateValidator
 *  
 * GSI - Integración
 * Creado el: 22/09/2014
 *
 * Copyright (c) A Toda Hora S.A. Todos los derechos reservados
 * 
 * Este software es confidencial y es propietario de ATH, queda prohibido
 * su uso, reproducción y copia de manera parcial o permanente salvo autorización
 * expresa de A Toda Hora S.A o de quién represente sus derechos.
 */
package co.com.ath.pgw.persistence.validation.model.impl;

import java.util.Locale;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import co.com.ath.pgw.util.i18n.BundleKeys;
import co.com.ath.pgw.util.i18n.BundleType;
import co.com.ath.pgw.util.validation.AbstractAttributeValidator;
import co.com.ath.pgw.util.validation.ErrorCode;
import co.com.ath.pgw.util.validation.NotNullValidator;
import co.com.ath.pgw.util.validation.ObjectValidationException;
import co.com.ath.pgw.util.validation.ObjectValidator;
import co.com.ath.pgw.util.validation.ValidationException;

/**
 * Validador de fechas de solicitud
 * 
 * @author proveedor_zagarcia
 * @version 1.0  22 Sep 2014
 * @since 1.0
 */
@Service
public class RqDateValidator extends AbstractAttributeValidator {


	static Logger LOGGER = LoggerFactory.getLogger(RqDateValidator.class);


	private ObjectValidator validator;
	
	public RqDateValidator(){
		super();
	}

	@Override
	protected void doMandatoryValidate(Object attribute, Locale locale)
			throws ValidationException {
		validator = new NotNullValidator();
		validator.setBundleManager(bundleManager);
		try {
			validator.validate(attribute, locale);
		} catch (ObjectValidationException e) {
			LOGGER.warn("Fallo en validador: \n{}", e.toString());
			throw new ValidationException(
					getMessage(locale), 
						ErrorCode.INVALID_REQUEST_DATE, e);
		}
	}

	@Override
	protected void doOptionalValidate(Object attribute, Locale locale)
													throws ValidationException {
		/*
		 * No se ha definido funcionalmente si se deba realizar validación
		 * sobre la fecha de solicitud.
		 */
	}

	private String getMessage(Locale locale) {
		if (bundleManager == null) {
			return BundleKeys.ERROR_INVALID_REQUEST_DATE;
		}
		bundleManager.setBundle(BundleType.ERRORS);
		return bundleManager.getMessage(
				BundleKeys.ERROR_INVALID_REQUEST_DATE, null, locale);
	}

}