/*
 * TransactionSource
 *  
 * GSI - Integración
 * Creado el: 28/08/2014
 *
 * Copyright (c) A Toda Hora S.A. Todos los derechos reservados
 * 
 * Este software es confidencial y es propietario de ATH, queda prohibido
 * su uso, reproducción y copia de manera parcial o permanente salvo autorización
 * expresa de A Toda Hora S.A o de quién represente sus derechos.
 */
package co.com.ath.pgw.persistence.model;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import co.com.ath.pgw.persistence.PersistentObject;

import javax.persistence.Temporal;
import javax.persistence.TemporalType;


/**
 * Clase que representa el origen de una transacción en el modelo persistente
 * del Core de la Pasarela de Pagos.
 * 
 * @author proveedor_japiza
 * @version 1.0 29 Ago 2014
 * @since 1.0
 * 
 * @RQ30455
*  <strong>Autor</strong>Camilo Bustamante</br>
*  <strong>Descripcion</strong>Permitir Compartir Recaudos PSE</br>
*  <strong>Numero de Cambios</strong>1</br>
*  <strong>Identificador corto</strong>C01</br>
*  
 */
@Entity
@Table(name="ORIGENESTRANSACCION")
public class TransactionSource implements PersistentObject {

	/**
	 * 
	 */
	private static final long serialVersionUID = -3337246897290510763L;

	/**
	 * Identificador único del origen de la transacción.
	 */
	@Id
    @Column(name = "ID")
	private Long id;

	/**
	 * Nombre del origen de la transacción.
	 */
	@Column(name="ORIGENTRANSACCION")
	private String name;	

	/**
	 * Indica si el registro tiene marca lógica de borrado
	 */
	@Column(name="REGELIMINADO", nullable=true)
	private boolean rowDeleted;
	
	/**
	 * Fecha de creación del registro
	 */
	@Temporal(TemporalType.TIMESTAMP)
	@Column(name="REGFECHACREACION", nullable=true)
	private Date rowCreationDate;
	
	/**
	 * Fecha de última modificación del registro
	 */
	@Temporal(TemporalType.TIMESTAMP)
	@Column(name="REGFECHAMODIFICACION", nullable=true)
	private Date rowLastUpdate;
	
	/**
	 * Canal del origen de la transacción.
	 */
	@Column(name="CANAL")
	private String canal;
	
	/**INICIO-C01**/
	/**
	 * Identificador del Portal de Origen
	 */
	@ManyToOne(fetch=FetchType.EAGER)
	@JoinColumn(name="IDPORTALORIGEN")
	private SourcePortal sourcePortal;
	/**FIN-C01**/
	
	
	/**
	 * Construye un origen de transacción
	 */
	public TransactionSource(){
		super();
	}
	
	/**
	 * Construye un origen de transacción especificando el identificador.
	 * 
	 * @param id Identificador del origen de transacción.
	 */
	TransactionSource(Long id){
		this.id = id;
	}
	
	/**
	 * Retorna el identificador único del origen de la transacción.
	 * 
	 * @return Identificador único del origen de la transacción.
	 */
	public Long getId() {
		return id;
	}

	/**
	 * Establece el identificador único del origen de la transacción.
	 * 
	 * @param id
	 */
	public void setId(Long id) {
		this.id = id;
	}

	/**
	 * Retorna el nombre del origen de la transacción.
	 * 
	 * @return Nombre del origen de la transacción.
	 */
	public String getName() {
		return name;
	}

	/**
	 * Establece el nombre del origen de la transacción.
	 * 
	 * @param name Nombre del origen de la transacción.
	 */
	public void setName(String name) {
		this.name = name;
	}
	
	/**
	 * Retorna el canal del origen de la transacción.
	 * 
	 * @return Canal del origen de la transacción.
	 */
	public String getCanal() {
		return canal;
	}

	/**
	 * Establece el canal del origen de la transacción.
	 * 
	 * @param canal Canal del origen de la transacción.
	 */
	public void setCanal(String canal) {
		this.canal = canal;
	}
	
	/**INICIO-C01**/
	/**
	 * @return the sourcePortal
	 */
	public SourcePortal getSourcePortal() {
		return sourcePortal;
	}

	/**
	 * @param sourcePortal the sourcePortal to set
	 */
	public void setSourcePortal(SourcePortal sourcePortal) {
		this.sourcePortal = sourcePortal;
	}
	/**FIN-C01**/

	@Override
	public boolean isRowDeleted() {
		return rowDeleted;
	}

	@Override
	public void setRowDeleted(boolean rowDeleted) {
		this.rowDeleted = rowDeleted;
	}

	@Override
	public Date getRowCreationDate() {
		return rowCreationDate;
	}

	@Override
	public void setRowCreationDate(Date rowCreationDate) {
		this.rowCreationDate = rowCreationDate;
	}

	@Override
	public Date getRowLastUpdate() {
		return rowLastUpdate;
	}

	@Override
	public void setRowLastUpdate(Date rowLastUpdate) {
		this.rowLastUpdate = rowLastUpdate;
	}	

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + (int) (id ^ (id >>> 32));
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		TransactionSource other = (TransactionSource) obj;
		if (id != other.id)
			return false;
		return true;
	}

	@Override
	public String toString() {
		return "TransactionSource [id=" + id + ", name=" + name 
				+ ", canal=" + canal
				/**INICIO-C01**/
				+ ", sourcePortal=" + sourcePortal
				/**FIN-C01**/
				+ ", rowDeleted=" + rowDeleted + "]";
	}
	
}