/*
W * TrxSourceValidator
 *
 * GSI - Integración
 * Creado el: 18 de septiembre de 2014
 *
 * Copyright (c) A Toda Hora S.A. Todos los derechos reservados
 *
 * Este software es confidencial y es propietario de ATH, queda prohibido
 * su uso, reproducción y copia de manera parcial o permanente salvo autorización
 * expresa de A Toda Hora S.A o de quién represente sus derechos.
 */
package co.com.ath.pgw.persistence.validation.model.impl;

import java.util.Locale;

import javax.annotation.Resource;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import co.com.ath.pgw.persistence.dao.TransactionSourceDAO;
import co.com.ath.pgw.persistence.model.TransactionSource;
import co.com.ath.pgw.util.i18n.BundleKeys;
import co.com.ath.pgw.util.i18n.BundleType;
import co.com.ath.pgw.util.validation.AbstractAttributeValidator;
import co.com.ath.pgw.util.validation.ErrorCode;
import co.com.ath.pgw.util.validation.IntValueValidator;
import co.com.ath.pgw.util.validation.NotEmptyValidator;
import co.com.ath.pgw.util.validation.NotNullValidator;
import co.com.ath.pgw.util.validation.ObjectValidationException;
import co.com.ath.pgw.util.validation.ObjectValidator;
import co.com.ath.pgw.util.validation.ValidationException;
/**
 * Realiza las validaciones sobre orígenes de transacción.
 * 
 * @author proveedor_zagarcia
 * @version 1.0 20 Sep 2014
 * @since 1.0
 */
@Service
public class TrxSourceValidator extends AbstractAttributeValidator {
	

static Logger LOGGER = LoggerFactory.getLogger(TrxSourceValidator.class);


	private ObjectValidator validator;
	
	@Resource
	private TransactionSourceDAO sourceDAO;

	@Override 
	protected void doMandatoryValidate(Object attribute, Locale locale)
													throws ValidationException {
		validator = new NotNullValidator(new NotEmptyValidator());
		validator.setBundleManager(bundleManager);
		try {
			validator.validate(attribute, locale);
		} catch (ObjectValidationException e) {
			ValidationException vex = new ValidationException(getMessage(locale), ErrorCode.INVALID_CHANNEL_SOURCE, e);
			LOGGER.warn("Fallo el validador: \n{}", vex.toString());
			throw vex;
		}
		doOptionalValidate(attribute, locale);
		
	}

	@Override
	protected void doOptionalValidate(Object attribute, Locale locale)throws ValidationException {
		if (attribute == null || attribute.toString().trim().length() == 0) {
			return;
		}
		validator = new IntValueValidator();
		validator.setBundleManager(bundleManager);
		try {
			validator.validate(attribute, locale);
		} catch (ObjectValidationException e) {
			ValidationException vex = new ValidationException(getMessage(locale), ErrorCode.INVALID_CHANNEL_SOURCE, e); 
			LOGGER.warn("Fallo el validador: \n{}", vex.toString());
			throw vex;
		}
		validateExistence(attribute,locale);
		
	}

	private void validateExistence(Object attribute, Locale locale) 
													throws ValidationException {
		TransactionSource trxSource = 
			sourceDAO.read(new Long(attribute.toString()));
			
		if (trxSource == null) {
			ValidationException e = new ValidationException(getMessage(locale),ErrorCode.INVALID_CHANNEL_SOURCE,getNotFoundSourceEx(attribute, locale));
			LOGGER.warn("Fallo el validador: \n{}", e.toString());
			throw e;
		} 
		
	}

	private String getMessage(Locale locale) {
		if (bundleManager == null) {
			return BundleKeys.ERROR_INVALID_CHANNEL_SOURCE;
		}
		bundleManager.setBundle(BundleType.ERRORS);
		return bundleManager.getMessage(
				BundleKeys.ERROR_INVALID_CHANNEL_SOURCE, null, locale);
	}

	private ObjectValidationException getNotFoundSourceEx(Object attribute, 
														  Locale locale){
		String message = "validation.1.notfound";
		if (bundleManager != null) {
			bundleManager.setBundle(BundleType.ERRORS);
			message = bundleManager.getMessage(
					message, new Object[]{attribute}, locale);
		}
		return new ObjectValidationException(message);
	}

}
