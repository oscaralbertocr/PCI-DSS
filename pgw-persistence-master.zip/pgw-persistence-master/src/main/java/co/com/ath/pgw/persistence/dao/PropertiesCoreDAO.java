package co.com.ath.pgw.persistence.dao;

import co.com.ath.pgw.persistence.DataAccessObject;
import co.com.ath.pgw.persistence.model.PropertiesCore;

public interface PropertiesCoreDAO extends DataAccessObject<PropertiesCore> {

	PropertiesCore findByPropertieNumber(Long propertieNumber);

	void updateProperty(Long propertieNumber, String property);

	void updatePropertyParameter(PropertiesCore propertiesCore);

}
