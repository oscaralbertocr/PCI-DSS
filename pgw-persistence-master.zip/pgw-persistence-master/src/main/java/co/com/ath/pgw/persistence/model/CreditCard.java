/*
 * CreditCard
 *  
 * GSI - Integración
 * Creado el: 28/08/2014
 *
 * Copyright (c) A Toda Hora S.A. Todos los derechos reservados
 * 
 * Este software es confidencial y es propietario de ATH, queda prohibido
 * su uso, reproducción y copia de manera parcial o permanente salvo autorización
 * expresa de A Toda Hora S.A o de quién represente sus derechos.
 */
package co.com.ath.pgw.persistence.model;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import co.com.ath.pgw.persistence.PersistentObject;


/**
 * Representa una tarjeta de crédito. Esta es una entidad del modelo
 * persistente.
 * 
 * @author proveedor_japiza
 * @version 1.0 29 Ago 2014
 * @since 1.0
 *
 */
@Entity
@Table(name="TARJETASCREDITO")
public class CreditCard implements PersistentObject {

	/**
	 * 
	 */
	private static final long serialVersionUID = 4603377538948428198L;


	/**
	 * Identificador de la tarjeta de crédito ante el sistema.
	 */
	@Id
    @Column(name = "ID")
	@SequenceGenerator(
			name="TARJETASCREDITO_ID_GENERATOR", 
			sequenceName="TARJETASCREDITO_SEC")
	@GeneratedValue(
			strategy=GenerationType.SEQUENCE,
			generator="TARJETASCREDITO_ID_GENERATOR")
	private Long id;
	
	
	/**
	 * Número de la tarjeta de crédito.
	 */
	@Column(name="NUMERO")
	private String number;
	
	/**
	 * Código de seguridad de la tarjeta de crédito (CSC)
	 */
	@Column(name="CODIGOSEGURIDAD")
	private Integer securityCode;


	/**
	 * Fecha de vencimiento del plástico de la tarjeta de crédito.
	 */
	@Column(name="FECHAVENCIMIENTO")
	private String dueDate;	

	/**
	 * Marca (o franquicia) de la tarjeta de crédito.
	 */
	@ManyToOne(fetch=FetchType.LAZY)
	@JoinColumn(name="IDFRANQUICIA")
	private Brand brand;


	/**
	 * Titular de la tarjeta de crédito.
	 */
	@ManyToOne(fetch=FetchType.LAZY)
	@JoinColumn(name="IDTARJETAHABIENTE")
	private CardHolder cardHolder;


	/**
	 * Indica si el registro tiene marca lógica de borrado
	 */
	@Column(name="REGELIMINADO", nullable=true)
	private boolean rowDeleted;
	
	/**
	 * Fecha de creación del registro
	 */
	@Temporal(TemporalType.TIMESTAMP)
	@Column(name="REGFECHACREACION", nullable=true)
	private Date rowCreationDate;
	
	/**
	 * Fecha de última modificación del registro
	 */
	@Temporal(TemporalType.TIMESTAMP)
	@Column(name="REGFECHAMODIFICACION", nullable=true)
	private Date rowLastUpdate;

	/**
	 * Construye una tarjeta de crédito sin datos.
	 */
	public CreditCard(){
		super();
	}
	
	/**
	 * Construye una tarjeta de crédito especificando el identificador único
	 * en el sistema.
	 * 
	 * @param id Identificador
	 */
	CreditCard(Long id){
		this.id = id;
	}

	/**
	 * Retorna el identificador de la tarjeta de crédito ante el sistema.
	 * 
	 * @return Identificador de la tarjeta de crédito ante el sistema.
	 */
	public Long getId() {
		return id;
	}

	/**
	 * Establce el identificador de la tarjeta de crédito ante el sistema.
	 * 
	 * @param id Identificador de la tarjeta de crédito ante el sistema.
	 */
	public void setId(Long id) {
		this.id = id;
	}

	/**
	 * Retorna el número de la tarjeta de crédito.
	 * 
	 * @return Número de la tarjeta de crédito.
	 */
	public String getNumber() {
		return number;
	}

	/**
	 * Establece el número de la tarjeta de crédito.
	 * 
	 * @param number Número de la tarjeta de crédito.
	 */
	public void setNumber(String number) {
		this.number = number;
	}

	/**
	 * Retorna el código de seguridad de la tarjeta de crédito (CSC)
	 * @return Código de seguridad de la tarjeta.
	 */
	public Integer getSecurityCode() {
		return securityCode;
	}

	/**
	 * Establece el código de seguridad de la tarjeta de crédito (CSC)
	 * @param securityCode Código de seguridad de la tarjeta.
	 */
	public void setSecurityCode(Integer securityCode) {
		this.securityCode = securityCode;
	}

	/**
	 * Retorna la fecha de vencimiento del plástico de la tarjeta de crédito.
	 * @return Fecha de vencimiento de la tarjeta de crédito.
	 */
	public String getDueDate() {
		return dueDate;
	}

	/**
	 * Establece la fecha de vencimiento del plástico de la tarjeta de crédito.
	 * @param dueDate Fecha de vencimiento de la tarjeta de crédito.
	 */
	public void setDueDate(String dueDate) {
		this.dueDate = dueDate;
	}

	/**
	 * Retorna la marca (o franquicia) de la tarjeta de crédito.
	 * 
	 * @return Marca de la tarjeta de crédito.
	 */
	public Brand getBrand() {
		return brand;
	}

	/**
	 * Establece la marca (o franquicia) de la tarjeta de crédito.
	 * 
	 * @param brand Marca de la tarjeta de crédito.
	 */
	public void setBrand(Brand brand) {
		this.brand = brand;
	}

	/**
	 * Retorna el titular de la tarjeta de crédito.
	 * 
	 * @return Titular de la tarjeta de crédito.
	 */
	public CardHolder getCardHolder() {
		return cardHolder;
	}

	/**
	 * Establece el titular de la tarjeta de crédito.
	 * 
	 * @param cardHolder Titular de la tarjeta de crédito.
	 */
	public void setCardHolder(CardHolder cardHolder) {
		this.cardHolder = cardHolder;
	}

	@Override
	public boolean isRowDeleted() {
		return rowDeleted;
	}

	@Override
	public void setRowDeleted(boolean rowDeleted) {
		this.rowDeleted = rowDeleted;
	}

	@Override
	public Date getRowCreationDate() {
		return rowCreationDate;
	}

	@Override
	public void setRowCreationDate(Date rowCreationDate) {
		this.rowCreationDate = rowCreationDate;
	}

	@Override
	public Date getRowLastUpdate() {
		return rowLastUpdate;
	}

	@Override
	public void setRowLastUpdate(Date rowLastUpdate) {
		this.rowLastUpdate = rowLastUpdate;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((number == null) ? 0 : number.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		CreditCard other = (CreditCard) obj;
		if (number == null) {
			if (other.number != null)
				return false;
		} else if (!number.equals(other.number))
			return false;
		return true;
	}

	@Override
	public String toString() {
		return "CreditCard [id=" + id + ", number=" + number + ", rowDeleted="
				+ rowDeleted + "]";
	}

}