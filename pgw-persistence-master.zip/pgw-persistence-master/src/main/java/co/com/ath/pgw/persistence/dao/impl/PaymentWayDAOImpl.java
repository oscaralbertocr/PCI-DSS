/*
 * PaymentWayDAOImpl
 *  
 * GSI - Integración
 * Creado el: 29/08/2014
 *
 * Copyright (c) A Toda Hora S.A. Todos los derechos reservados
 * 
 * Este software es confidencial y es propietario de ATH, queda prohibido
 * su uso, reproducción y copia de manera parcial o permanente salvo autorización
 * expresa de A Toda Hora S.A o de quién represente sus derechos.
 */
package co.com.ath.pgw.persistence.dao.impl;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.NoResultException;
import javax.persistence.NonUniqueResultException;
import javax.persistence.Query;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Repository;

import co.com.ath.pgw.persistence.AbstractDAO_JPA;
import co.com.ath.pgw.persistence.dao.PaymentWayDAO;
import co.com.ath.pgw.persistence.model.PaymentWay;
import co.com.ath.pgw.persistence.model.PaymentWayByCommerce;

/**
 * Implementación por defecto de PaymentWayDAO
 *
 * @author Andrés Méndez Juanias <proveedor_mamendez@ath.com.co>
 * @version 1.0 29 Ago 2014
 * @since 1.0
 * 
 * @PCI
 * <strong>Autor</strong>Nelly Rocio Linares</br>
 * <strong>Descripcion</strong>Se crea metodo para recuperar entidades bancarias</br>
 * <strong>Numero de Cambios</strong>1</br>
 * <strong>Identificador corto</strong>C01</br>
 * 
 * 
 */
@Repository
public class PaymentWayDAOImpl 
				extends AbstractDAO_JPA<PaymentWay> implements PaymentWayDAO {

	static Logger LOGGER = LoggerFactory.getLogger(PaymentWayDAOImpl.class);
	
	public PaymentWayDAOImpl() {
		super(PaymentWay.class);
	}
	
	
	@Override
	public String findAuthorizedAccountByIdPaymentCommerce(Long idComercio,
			Long medioPago) {
		StringBuilder hql = new StringBuilder("from PaymentWayByCommerce t ");
		hql.append("where t.rowDeleted <> 1 ");
		hql.append("and t.commerceId = :idComercio ");
		hql.append("and t.paymentWay.id = :medioPago ");		
		
        Query query = entityManager.createQuery(hql.toString());
		query.setParameter("idComercio", idComercio);
		query.setParameter("medioPago", medioPago);
		
		PaymentWayByCommerce authorizedAccount = null;
		
		try {
			authorizedAccount = (PaymentWayByCommerce) query.getSingleResult(); 
		} catch (NoResultException e) {
			LOGGER.warn("Problemas en query", e);
			return null;
		} catch (NonUniqueResultException e){
			LOGGER.warn("Problemas en query", e);
            return null;
        }
		return null;
	}

	
	/**INICIO-C01**/
	@Override
	public List<PaymentWay> findAll() {
		
		LOGGER.info("@findAll ingreso");
		StringBuilder hql = new StringBuilder("from PaymentWay t ");
		hql.append("where t.rowDeleted <> 1 ");

		List<PaymentWay> mediosPago = new ArrayList<PaymentWay>();

		try {
			Query query = entityManager.createQuery(hql.toString());
			mediosPago = query.getResultList();

		} catch (NoResultException e) {
			LOGGER.info("query Exception ", e.toString());
			return new ArrayList<PaymentWay>();
		}

		return mediosPago;
	}
	/**FIN-C01**/
}
