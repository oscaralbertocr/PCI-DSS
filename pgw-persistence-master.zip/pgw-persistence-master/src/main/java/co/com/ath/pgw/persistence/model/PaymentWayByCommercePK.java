package co.com.ath.pgw.persistence.model;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Embeddable;

import co.com.ath.pgw.persistence.PersistentObject;

@Embeddable
public class PaymentWayByCommercePK implements PersistentObject{
	
	private static final long serialVersionUID = 4551213890982367073L;
	
	@Column(insertable=false, updatable=false)
	private long idcomercio;

	@Column(insertable=false, updatable=false)
	private long idmediopago;
	
	@Override
	public boolean isRowDeleted() {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public void setRowDeleted(boolean rowDeleted) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public Date getRowCreationDate() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void setRowCreationDate(Date rowCreationDate) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public Date getRowLastUpdate() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void setRowLastUpdate(Date rowLastUpdate) {
		// TODO Auto-generated method stub
		
	}

	public long getIdcomercio() {
		return idcomercio;
	}

	public void setIdcomercio(long idcomercio) {
		this.idcomercio = idcomercio;
	}

	public long getIdmediopago() {
		return idmediopago;
	}

	public void setIdmediopago(long idmediopago) {
		this.idmediopago = idmediopago;
	}
	
	
	
}
