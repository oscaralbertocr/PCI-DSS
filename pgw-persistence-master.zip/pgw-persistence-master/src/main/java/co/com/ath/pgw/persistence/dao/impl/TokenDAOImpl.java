/*
 * TokenDAOImpl
 *  
 * GSI - Integración
 * Creado el: 29/08/2014
 *
 * Copyright (c) A Toda Hora S.A. Todos los derechos reservados
 * 
 * Este software es confidencial y es propietario de ATH, queda prohibido
 * su uso, reproducción y copia de manera parcial o permanente salvo autorización
 * expresa de A Toda Hora S.A o de quién represente sus derechos.
 */
package co.com.ath.pgw.persistence.dao.impl;

import javax.persistence.NoResultException;
import javax.persistence.NonUniqueResultException;
import javax.persistence.Query;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Repository;

import co.com.ath.pgw.persistence.AbstractDAO_JPA;
import co.com.ath.pgw.persistence.dao.TokenDAO;
import co.com.ath.pgw.persistence.model.Token;

/**
 * Implementación por defecto de TokenDAO
 *
 * @author Andrés Méndez Juanias <proveedor_mamendez@ath.com.co>
 * @version 1.0 29 Ago 2014
 * @since 1.0
 */
@Repository
public class TokenDAOImpl extends AbstractDAO_JPA<Token> implements TokenDAO {
	
	static Logger LOGGER = LoggerFactory.getLogger(TokenDAOImpl.class);

	public TokenDAOImpl() {
		super(Token.class);
	}

	@Override
	public Token findByTransactionId(Long transactionId) {
		StringBuilder hql = new StringBuilder(" FROM Token tk ");
		hql.append(" WHERE tk.rowDeleted <> 1 ");
		hql.append(" AND tk.transaction.id = :transactionId ");
		
		Query query = entityManager.createQuery(hql.toString());
		query.setParameter("transactionId", transactionId);
		
		Token token = null;
		
		try {
			token = (Token) query.getSingleResult();
		} catch (NoResultException ex) {
			LOGGER.warn("Resultado Query: {}", ex.toString());
			return null;
		} catch (NonUniqueResultException ex) {
			LOGGER.warn("Problemas en query: {}", ex.toString());
			return null;
		}
		return token;
	}
}
