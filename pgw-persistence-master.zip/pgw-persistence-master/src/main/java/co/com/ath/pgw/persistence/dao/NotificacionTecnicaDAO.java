package co.com.ath.pgw.persistence.dao;

import co.com.ath.pgw.persistence.DataAccessObject;
import co.com.ath.pgw.persistence.model.NotificacionTecnica;

/**
 * Objeto de Acceso a Datos para las entidades NotificacionTecnica 
 *
 * @author Andrés Eduardo Hernandez <andres.hernandez@sophossolutions.com>
 * @version 28/05/2018
 * @since 1.0
 */
public interface NotificacionTecnicaDAO extends DataAccessObject<NotificacionTecnica>{
	
	NotificacionTecnica findByTipoNotificacion(String tipo);

}
