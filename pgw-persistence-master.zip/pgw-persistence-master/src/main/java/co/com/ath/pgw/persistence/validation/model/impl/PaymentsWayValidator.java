/*
 * PaymentWayValidator
 *  
 * GSI - Integración
 * Creado el: 23/09/2014
 *
 * Copyright (c) A Toda Hora S.A. Todos los derechos reservados
 * 
 * Este software es confidencial y es propietario de ATH, queda prohibido
 * su uso, reproducción y copia de manera parcial o permanente salvo autorización
 * expresa de A Toda Hora S.A o de quién represente sus derechos.
 */
package co.com.ath.pgw.persistence.validation.model.impl;

import java.util.Locale;

import javax.annotation.Resource;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import co.com.ath.pgw.persistence.dao.PaymentWayDAO;
import co.com.ath.pgw.persistence.model.PaymentWay;
import co.com.ath.pgw.util.i18n.BundleKeys;
import co.com.ath.pgw.util.i18n.BundleType;
import co.com.ath.pgw.util.validation.AbstractAttributeValidator;
import co.com.ath.pgw.util.validation.ErrorCode;
import co.com.ath.pgw.util.validation.IntValueValidator;
import co.com.ath.pgw.util.validation.NotEmptyValidator;
import co.com.ath.pgw.util.validation.NotNullValidator;
import co.com.ath.pgw.util.validation.ObjectValidationException;
import co.com.ath.pgw.util.validation.ObjectValidator;
import co.com.ath.pgw.util.validation.ValidationException;
/**
 * Validador para el medio de pago.
 * 
 * @author Andrés Méndez Juanias <proveedor_mamendez@ath.com.co>
 * @version 1.0 23/09/2014
 * @since 1.0
 */
@Service
public class PaymentsWayValidator extends AbstractAttributeValidator {

	static Logger LOGGER = LoggerFactory.getLogger(PaymentsWayValidator.class);

	private ObjectValidator validator;

	@Resource
	private PaymentWayDAO paymentWayDAO;

	@Override
	protected void doMandatoryValidate(Object attribute, Locale locale) throws ValidationException {
		validator = new NotNullValidator(new NotEmptyValidator());
		validator.setBundleManager(bundleManager);
		try {
			validator.validate(attribute, locale);
		} catch (ObjectValidationException e) {
			ValidationException vex = new ValidationException(getMessage(locale), ErrorCode.INVALID_PAYMENT_WAY, e);
			LOGGER.warn("Fallo el validador: \n{}", vex.toString());
			throw vex;
		}
		doOptionalValidate(attribute, locale);

	}

	@Override
	protected void doOptionalValidate(Object attribute, Locale locale) throws ValidationException {
		if (attribute == null || attribute.toString().trim().length() == 0) {
			return;
		}
		validator = new IntValueValidator();
		validator.setBundleManager(bundleManager);
		try {
			validator.validate(attribute, locale);
		} catch (ObjectValidationException e) {
			ValidationException vex = new ValidationException(getMessage(locale), ErrorCode.INVALID_PAYMENT_WAY, e);
			LOGGER.warn("Fallo el validador: \n{}", vex.toString());
			throw vex;
		}
		validateExistence(attribute, locale);

	}

	/**
	 * Valida la existencia del medio de pago.
	 * 
	 * @param attribute
	 *            Id del medio de pago.
	 * @param locale
	 *            Localización.
	 * @throws ValidationException
	 *             En caso de no encontrar el registro.
	 */
	private void validateExistence(Object attribute, Locale locale) throws ValidationException {

		Long paymentWayId = Long.valueOf(attribute.toString());
		PaymentWay paymentWay = paymentWayDAO.read(paymentWayId);
		if (paymentWay == null) {
			ValidationException e = new ValidationException(getMessage(locale), ErrorCode.INVALID_PAYMENT_WAY,
					getNotFoundSourceEx(attribute, locale));
			LOGGER.warn("Fallo el validador: \n{}", e.toString());
			throw e;
		}
	}

	
	
	private String getMessage(Locale locale) {
		if (bundleManager == null) {
			return BundleKeys.ERROR_INVALID_PAYMENT_WAY;
		}
		bundleManager.setBundle(BundleType.ERRORS);
		return bundleManager.getMessage(BundleKeys.ERROR_INVALID_PAYMENT_WAY, null, locale);
	}

	

	private ObjectValidationException getNotFoundSourceEx(Object attribute, Locale locale) {
		String message = "validation.1.notfound";
		if (bundleManager != null) {
			bundleManager.setBundle(BundleType.ERRORS);
			message = bundleManager.getMessage(message, new Object[] { attribute }, locale);
		}
		return new ObjectValidationException(message);
	}

}
