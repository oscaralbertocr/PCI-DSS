/*
 * ObligatoryValidator
 *  
 * GSI - Integración
 * Creado el: 19/09/2014
 *
 * Copyright (c) A Toda Hora S.A. Todos los derechos reservados
 * 
 * Este software es confidencial y es propietario de ATH, queda prohibido
 * su uso, reproducción y copia de manera parcial o permanente salvo autorización
 * expresa de A Toda Hora S.A o de quién represente sus derechos.
 */
package co.com.ath.pgw.persistence.validation.model.impl;

import java.util.Locale;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import co.com.ath.pgw.util.i18n.BundleKeys;
import co.com.ath.pgw.util.i18n.BundleType;
import co.com.ath.pgw.util.validation.AbstractAttributeValidator;
import co.com.ath.pgw.util.validation.ErrorCode;
import co.com.ath.pgw.util.validation.NotEmptyValidator;
import co.com.ath.pgw.util.validation.NotNullValidator;
import co.com.ath.pgw.util.validation.ObjectValidationException;
import co.com.ath.pgw.util.validation.ObjectValidator;
import co.com.ath.pgw.util.validation.ValidationException;
/**
 * Validador para los valores obligatorios.
 * 
 * @version 0.0.0 19/09/2014
 * @author Andrés Méndez Juanias <proveedor_mamendez@ath.com.co>
 */
@Service
public class ObligatoryValidator extends AbstractAttributeValidator {

	static Logger LOGGER = LoggerFactory.getLogger(ObligatoryValidator.class);
	
	private ObjectValidator validator;

	@Override
	protected void doMandatoryValidate(Object attribute, Locale locale)
			throws ValidationException {
		validator = new NotNullValidator(new NotEmptyValidator());
		validator.setBundleManager(bundleManager);
		try {
			validator.validate(attribute, locale);
		} catch (ObjectValidationException e) {
			throwException(e, locale);
		}

	}

	@Override
	protected void doOptionalValidate(Object attribute, Locale locale)
			throws ValidationException {
	}

	/**
	 * Obtiene los mensajes del bundle basado en la llave que llega por
	 * parámetro.
	 * 
	 * @param messageKey
	 *            Clave del mensaje.
	 * @param args
	 *            Argumentos dinamicos para el mensaje.
	 * @param locale
	 *            Localización.
	 * @return Mensaje de error formateado o la messageKey si la llave no fue
	 *         encontrada.
	 */
	private String getMessage(String messageKey, Object[] args, Locale locale) {
		if (bundleManager == null) {
			return messageKey;
		}
		bundleManager.setBundle(BundleType.ERRORS);
		return bundleManager.getMessage(messageKey, args, locale);
	}

	/**
	 * Método encargado de lanzar la excepción encontrada en los validadores.
	 * 
	 * @param e
	 *            Excepción de los validadores.
	 * @param locale
	 *            Localización.
	 * @throws ValidationException
	 */
	private void throwException(ObjectValidationException e, Locale locale)
			throws ValidationException {
		ValidationException ve = new ValidationException(getMessage(BundleKeys.ERROR_NULL_VALUE,
				null, locale), ErrorCode.INVALID_FIELD_NULL_VALUE, e);
		LOGGER.warn("Fallo en validador: \n{}", ve.toString());
		throw ve;
	}

}
