/*
 * PersistentObjectFactory
 *
 * GSI - Integración
 * Creado el: 22 de agosto de 2014
 *
 * Copyright (c) A Toda Hora S.A. Todos los derechos reservados
 *
 * Este software es confidencial y es propietario de ATH, queda prohibido
 * su uso, reproducción y copia de manera parcial o permanente salvo autorización
 * expresa de A Toda Hora S.A o de quién represente sus derechos.
 */
package co.com.ath.pgw.persistence;

import co.com.ath.pgw.persistence.model.AVALFile;
import co.com.ath.pgw.persistence.model.AVALFileContent;
import co.com.ath.pgw.persistence.model.AVALFileDetail;
import co.com.ath.pgw.persistence.model.Bank;
import co.com.ath.pgw.persistence.model.Brand;
import co.com.ath.pgw.persistence.model.CardHolder;
import co.com.ath.pgw.persistence.model.City;
import co.com.ath.pgw.persistence.model.Commerce;
import co.com.ath.pgw.persistence.model.CommerceConfiguration;
import co.com.ath.pgw.persistence.model.CommerceContact;
import co.com.ath.pgw.persistence.model.CommerceRoleContact;
import co.com.ath.pgw.persistence.model.CreditCard;
import co.com.ath.pgw.persistence.model.Department;
import co.com.ath.pgw.persistence.model.Download;
import co.com.ath.pgw.persistence.model.DownloadStatus;
import co.com.ath.pgw.persistence.model.NotificacionTecnica;
import co.com.ath.pgw.persistence.model.PaymentWay;
import co.com.ath.pgw.persistence.model.ProductType;
import co.com.ath.pgw.persistence.model.ReconciledTransaction;
import co.com.ath.pgw.persistence.model.ResponseCode;
import co.com.ath.pgw.persistence.model.ResponseCodeForPaymentWay;
import co.com.ath.pgw.persistence.model.Subscription;
import co.com.ath.pgw.persistence.model.Taquilla;
import co.com.ath.pgw.persistence.model.Template;
import co.com.ath.pgw.persistence.model.Theme;
import co.com.ath.pgw.persistence.model.Token;
import co.com.ath.pgw.persistence.model.Transaction;
import co.com.ath.pgw.persistence.model.TransactionSource;
import co.com.ath.pgw.persistence.model.TransactionStatus;
import co.com.ath.pgw.persistence.model.TransactionType;

/**
 * Fábrica de Objetos persistentes
 * @author proveedor_zagarcia
 * @version 1.0
 * @since 1.0
 */
public interface PersistentObjectFactory {

	/**
	 * Crea un objeto Bank vacío.
     * @return Bank Objeto creado
	 */
	public Bank createBank();

	/**
	 * Crea un Banco estableciendo un id para éste.
	 * 
	 * @param id    Identificador del Banco
	 */
	public Bank createBank(Long id);
	
	/**
	 * Crea un objeto Brand vacío.
     * @return Brand Objeto creado.
	 */
	public Brand createBrand();
	
	/**
	 * Crea un objeto CardHolder vacío.
     * @return CardHolder Objeto creado.
	 */
	public CardHolder createCardHolder();
	
    /**
	 * Crea un objeto City vacío
     * @return City Objeto creado.
	 */
	public City createCity();
	
    /**
	 * Crea un objeto Commerce vacío
     * @return Commerce Objeto creado.
	 */
	public Commerce createCommerce();
	
    /**
	 * Crea un objeto CommerceConfiguration vacío.
     * @return CommerceConfiguration Objeto creado.
	 */
	public CommerceConfiguration createCommerceConfiguration();
    
    /**
	 * Crea un objeto CommerceContact vacío.
     * @return CommerceContact Objeto creado.
	 */
	public CommerceContact createCommerceContact();
    
    /**
	 * Crea un objeto CommerceContact vacío.
     * @return CommerceRoleContact Objeto creado.
	 */
	public CommerceRoleContact createCommerceRoleContact();
    
    /**
	 * Crea un objeto CreditCard vacío.
     * @return CreditCard Objeto creado.
	 */
	public CreditCard createCreditCard();
    
    /**
	 * Crea un objeto Department vacío.
     * @return Department Objeto creado.
	 */
	public Department createDepartment();
    
    /**
	 * Crea un objeto Download vacío.
     * @return Download Objeto creado.
	 */
	public Download createDownload();
    
    /**
	 * Crea un objeto DownloadStatus vacío.
     * @return DownloadStatus Objeto creado.
	 */
	public DownloadStatus createDownloadStatus();
    
    /**
	 * Crea un objeto PaymentWay vacío.
     * @return PaymentWay Objeto creado.
	 */
	public PaymentWay createPaymentWay();
    
    /**
	 * Crea un objeto ProductType vacío.
     * @return ProductType Objeto creado.
	 */
	public ProductType createProductType();
    
    /**
	 * Crea un objeto ReconciledTransaction vacío.
     * @return ReconciledTransaction Objeto creado.
	 */
	public ReconciledTransaction createReconciledTransaction();
    
    /**
	 * Crea un objeto ResponseCodeForPaymentWay vacío.
     * @return ResponseCodeForPaymentWay Objeto creado.
	 */
	public ResponseCodeForPaymentWay createResponseCodeForPaymentWay();
    
    /**
	 * Crea un objeto ResponseCode vacío.
     * @return ResponseCode Objeto creado.
	 */
	public ResponseCode createResponseCode();
    
    /**
	 * Crea un objeto Subscription vacío.
     * @return Subscription Objeto creado.
	 */
	public Subscription createSubscription();
    
    /**
	 * Crea un objeto Template vacío.
     * @return Template Objeto creado.
	 */
	public Template createTemplate();
    
    /**
	 * Crea un objeto Theme vacío.
     * @return Theme Objeto creado.
	 */
	public Theme createTheme();
    
    /**
	 * Crea un objeto Token vacío.
     * @return Token Objeto creado.
	 */
	public Token createToken();	
    
    /**
	 * Crea un objeto TransactionSource vacío.
     * @return TransactionSource Objeto creado.
	 */
	public TransactionSource createTransactionSource();
    
    /**
	 * Crea un objeto TransactionStatus vacío.
     * @return TransactionStatus Objeto creado.
	 */
	public TransactionStatus createTransactionStatus();
    
    /**
	 * Crea un objeto TransactionType vacío.
     * @return TransactionType Objeto creado.
	 */
	public TransactionType createTransactionType();
    
    /**
	 * Crea un objeto Transaction vacío.
     * @return Transaction Objeto creado.
	 */
	public Transaction createTransaction();
	
	/**
	 * Crea un objeto AVALFile vacío.
     * @return AVALFile Objeto creado.
	 */
	public AVALFile createAVALFile();
	
	/**
	 * Crea un objeto AVALFileContent vacío.
     * @return AVALFileContent Objeto creado.
	 */
	public AVALFileContent createAVALFileContent();
	
	/**
	 * Crea un objeto AVALFileDetail vacío.
     * @return AVALFileDetail Objeto creado.
	 */
	public AVALFileDetail createAVALFileDetail();
	
	/**
	 * Crea un objeto Taquilla vacío.
     * @return Taquilla Objeto creado.
	 */
	public Taquilla createTaquilla();
	
	/**
	 * Crea un objeto Notificación Técnica vacío.
     * @return Notificación Técnica Objeto creado.
	 */
	public NotificacionTecnica createNotificacionTecnica();
}