package co.com.ath.pgw.persistence.dao.impl;

import org.springframework.stereotype.Repository;

import co.com.ath.pgw.persistence.AbstractDAO_JPA;
import co.com.ath.pgw.persistence.dao.GeneralEmailDAO;
import co.com.ath.pgw.persistence.model.GeneralEmail;

/**
 * Implementación por defecto de BankDAO
 * 
 * @author proveedor_jlara
 * @version 1.0 24 Nov 2016
 * @since 1.0
 */

@Repository
public class GeneralEmailDAOImpl extends AbstractDAO_JPA<GeneralEmail> implements GeneralEmailDAO{

	/**
	 * Constructor por defecto
	 */
	public GeneralEmailDAOImpl() {
		super(GeneralEmail.class);
	}
}
