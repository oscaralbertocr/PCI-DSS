/*
 * IPAddressValidator
 *
 * GSI - Integración
 * Creado el: 22 de septiembre de 2014
 *
 * Copyright (c) A Toda Hora S.A. Todos los derechos reservados
 *
 * Este software es confidencial y es propietario de ATH, queda prohibido
 * su uso, reproducción y copia de manera parcial o permanente salvo autorización
 * expresa de A Toda Hora S.A o de quién represente sus derechos.
 */
package co.com.ath.pgw.persistence.validation.model.impl;

import java.util.Locale;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import co.com.ath.pgw.util.i18n.BundleKeys;
import co.com.ath.pgw.util.i18n.BundleType;
import co.com.ath.pgw.util.validation.AbstractAttributeValidator;
import co.com.ath.pgw.util.validation.ErrorCode;
import co.com.ath.pgw.util.validation.NotEmptyValidator;
import co.com.ath.pgw.util.validation.NotNullValidator;
import co.com.ath.pgw.util.validation.ObjectValidationException;
import co.com.ath.pgw.util.validation.ObjectValidator;
import co.com.ath.pgw.util.validation.ValidationException;

/**
 * Realiza la validación de direcciones IP.
 * 
 * @author proveedor_zagarcia
 * @version 1.0 22 Sep 2014
 * @since 1.0
 */
@Service
public class IPAddressValidator extends AbstractAttributeValidator {
	
	static Logger LOGGER = LoggerFactory.getLogger(IPAddressValidator.class);

	
	private ObjectValidator validator;

	public IPAddressValidator(){
		super();
	}

	@Override
	protected void doMandatoryValidate(Object attribute, Locale locale)
			throws ValidationException {
		validator = new NotNullValidator(new NotEmptyValidator());
		validator.setBundleManager(bundleManager);
		try {
			validator.validate(attribute, locale);
		} catch (ObjectValidationException e) {
			LOGGER.warn("Fallo en validador: \n{}", e.toString());
			throw new ValidationException(
						getMessage(locale), 
						ErrorCode.INVALID_IP_ADDRESS, e);
		}
		
	}

	@Override
	protected void doOptionalValidate(Object attribute, Locale locale)
			throws ValidationException {
		/*
		 * No se está realizando validación de dirección IP, solo que sea
		 * obligatoria.
		 */
	}

	private String getMessage(Locale locale) {
		if (bundleManager == null) {
			return BundleKeys.ERROR_INVALID_IP_ADDRESS;
		}
		bundleManager.setBundle(BundleType.ERRORS);
		return bundleManager.getMessage(
			BundleKeys.ERROR_INVALID_IP_ADDRESS, null, locale);
	}



}