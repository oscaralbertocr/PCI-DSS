/*
 * CardHolder
 *  
 * GSI - Integración
 * Creado el: 28/08/2014
 *
 * Copyright (c) A Toda Hora S.A. Todos los derechos reservados
 * 
 * Este software es confidencial y es propietario de ATH, queda prohibido
 * su uso, reproducción y copia de manera parcial o permanente salvo autorización
 * expresa de A Toda Hora S.A o de quién represente sus derechos.
 */
package co.com.ath.pgw.persistence.model;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

import co.com.ath.pgw.persistence.PersistentObject;

import javax.persistence.Temporal;
import javax.persistence.TemporalType;

/**
 * Representa un tarjetahabiente en el modelo persistente del Core de la
 * pasarela de pagos.
 * 
 * @author proveedor_japiza
 * @version 1.0 29 Ago 2014
 * @since 1.0
 */
@Entity
@Table(name="TARJETAHABIENTE")
public class CardHolder implements PersistentObject {	

	/**
	 * 
	 */
	private static final long serialVersionUID = -6590662551567530439L;

	/**
	 * Identificador único del tarjetahabiente.
	 */
	@Id
    @Column(name = "ID")
	@SequenceGenerator(
		name="TARJETAHABIENTE_ID_GENERATOR", 
		sequenceName="TARJETAHABIENTE_SEC")
	@GeneratedValue(
		strategy=GenerationType.SEQUENCE, 
		generator="TARJETAHABIENTE_ID_GENERATOR")
	private Long id;

	/**
	 * Número de identificación del tarjetahabiente.
	 */
	@Column(name="NUMEROIDENTIFICACION")
	private String identificationNumber;

	/**
	 * Nombre del tarjetahabiente.
	 */
	@Column(name="NOMBRE")
	private String name;

	/**
	 * Apellido(s) del tarjetahabiente.
	 */
	@Column(name="APELLIDO")
	private String lastName;

	/**
	 * Correo electrónico del tarjetahabiente.
	 */
	@Column(name = "EMAIL")
	private String email;

	/**
	 * Número de celular del tarjetahabiente.
	 */
	@Column(name="CELULAR")
	private String mobileNumber;

	/**
	 * Dirección del tarjetahabiente.
	 */
	@Column(name="DIRECCION")
	private String address;

	/**
	 * Indica si el registro tiene marca lógica de borrado
	 */
	@Column(name="REGELIMINADO", nullable=true)
	private boolean rowDeleted;
	
	/**
	 * Fecha de creación del registro
	 */
	@Temporal(TemporalType.TIMESTAMP)
	@Column(name="REGFECHACREACION", nullable=true)
	private Date rowCreationDate;
	
	/**
	 * Fecha de última modificación del registro
	 */
	@Temporal(TemporalType.TIMESTAMP)
	@Column(name="REGFECHAMODIFICACION", nullable=true)
	private Date rowLastUpdate;

	/**
	 * Construye un tarjetahabiente sin datos
	 */
	public CardHolder(){
		super();
	}
	
	/**
	 * Construye un tarjetahabiente especificando el identificador.
	 * 
	 * @param id Identificador único del tarjetahabiente en el sistema.
	 */
	CardHolder(Long id){
		super();
	}

	/**
	 * Retorna el identificador único del tarjetahabiente.
	 * 
	 * @return Identificador único del tarjetahabiente.
	 */
	public Long getId() {
		return id;
	}

	/**
	 * Establece el identificador único del tarjetahabiente.
	 * 
	 * @param id Identificador único del tarjetahabiente.
	 */
	public void setId(Long id) {
		this.id = id;
	}

	/**
	 * Retorna el número de identificación del tarjetahabiente.
	 * 
	 * @return Número de identificación del tarjetahabiente.
	 */
	public String getIdentificationNumber() {
		return identificationNumber;
	}

	/**
	 * Establece el número de identificación del tarjetahabiente.
	 * 
	 * @param identificationNumber Número de identificación del tarjetahabiente.
	 */
	public void setIdentificationNumber(String identificationNumber) {
		this.identificationNumber = identificationNumber;
	}

	/**
	 * Retorna el nombre del tarjetahabiente.
	 * 
	 * @return Nombre del tarjetahabiente.
	 */
	public String getName() {
		return name;
	}

	/**
	 * Establece el nombre del tarjetahabiente.
	 * @param name Nombre del tarjetahabiente.
	 */
	public void setName(String name) {
		this.name = name;
	}

	/**
	 * Retorna el(los) apellido(s) del tarjetahabiente.
	 * 
	 * @return Apellido del tarjetahabiente.
	 */
	public String getLastName() {
		return lastName;
	}

	/**
	 * Establece el(los) apellido(s) del tarjetahabiente.
	 * 
	 * @param lastName Apellido(s) del tarjetahabiente.
	 */
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	/**
	 * Retorna el correo electrónico del tarjetahabiente.
	 * 
	 * @return Correo electrónico del tarjetahabiente.
	 */
	public String getEmail() {
		return email;
	}

	/**
	 * Establece el correo electrónico del tarjetahabiente.
	 * 
	 * @param email Correo electrónico del tarjetahabiente.
	 */
	public void setEmail(String email) {
		this.email = email;
	}

	/**
	 * Retorna el número de celular del tarjetahabiente.
	 * 
	 * @return Número de celular del tarjetahabiente.
	 */
	public String getMobileNumber() {
		return mobileNumber;
	}

	/**
	 * Establece el número de celular del tarjetahabiente.
	 * 
	 * @param mobileNumber Número celular del tarjetahabiente.
	 */
	public void setMobileNumber(String mobileNumber) {
		this.mobileNumber = mobileNumber;
	}

	/**
	 * Retorna la dirección del tarjetahabiente.
	 * @return Dirección del tarjetahabiente.
	 */
	public String getAddress() {
		return address;
	}

	/**
	 * Establece la dirección del tarjetahabiente.
	 * 
	 * @param address Dirección del tarjetahabiente.
	 */
	public void setAddress(String address) {
		this.address = address;
	}

	@Override
	public boolean isRowDeleted() {
		return rowDeleted;
	}

	@Override
	public void setRowDeleted(boolean rowDeleted) {
		this.rowDeleted = rowDeleted;
	}

	@Override
	public Date getRowCreationDate() {
		return rowCreationDate;
	}

	@Override
	public void setRowCreationDate(Date rowCreationDate) {
		this.rowCreationDate = rowCreationDate;
	}

	@Override
	public Date getRowLastUpdate() {
		return rowLastUpdate;
	}

	@Override
	public void setRowLastUpdate(Date rowLastUpdate) {
		this.rowLastUpdate = rowLastUpdate;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime
				* result
				+ ((identificationNumber == null) ? 0 : identificationNumber
						.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		CardHolder other = (CardHolder) obj;
		if (identificationNumber == null) {
			if (other.identificationNumber != null)
				return false;
		} else if (!identificationNumber.equals(other.identificationNumber))
			return false;
		return true;
	}

	@Override
	public String toString() {
		return "CardHolder [id=" + id + ", identificationNumber="
				+ identificationNumber + ", name=" + name + ", lastName="
				+ lastName + ", rowDeleted=" + rowDeleted + "]";
	}

}