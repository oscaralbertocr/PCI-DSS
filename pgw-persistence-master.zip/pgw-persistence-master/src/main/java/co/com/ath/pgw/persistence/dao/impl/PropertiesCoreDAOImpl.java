package co.com.ath.pgw.persistence.dao.impl;

import java.util.Date;
import javax.persistence.NoResultException;
import javax.persistence.NonUniqueResultException;
import javax.persistence.PersistenceException;
import javax.persistence.Query;
import javax.persistence.QueryTimeoutException;
import javax.persistence.TransactionRequiredException;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Repository;

import co.com.ath.pgw.persistence.AbstractDAO_JPA;
import co.com.ath.pgw.persistence.dao.PropertiesCoreDAO;
import co.com.ath.pgw.persistence.model.PropertiesCore;

/**
 * Implementación por defecto de PropertiesCoreDAO
 * 
 * @author proveedor_jlara
 * @version 1.0 02 Dic 2016
 * @since 1.0
 * 
 * @PCI <strong>Autor</strong>Nelly Rocio Linares</br>
 *      <strong>Descripcion</strong>Se agrega metodo para modificar
 *      parametro</br>
 *      <strong>Numero de Cambios</strong>1</br>
 *      <strong>Identificador corto</strong>C01</br>
 * 
 * 
 */

@Repository
public class PropertiesCoreDAOImpl extends AbstractDAO_JPA<PropertiesCore> implements PropertiesCoreDAO {

	static Logger LOGGER = LoggerFactory.getLogger(PropertiesCoreDAOImpl.class);

	/**
	 * Constructor por defecto
	 */
	public PropertiesCoreDAOImpl() {
		super(PropertiesCore.class);
	}

	@Override
	public PropertiesCore findByPropertieNumber(Long propertieNumber) {
		StringBuilder hql = new StringBuilder("from PropertiesCore t ");
		hql.append("where t.rowDeleted <> 1 ");
		hql.append("and t.idProperty = :idPropiedad ");

		Query query = entityManager.createQuery(hql.toString());
		query.setParameter("idPropiedad", propertieNumber);

		PropertiesCore propertiesCore = null;

		try {
			propertiesCore = (PropertiesCore) query.getSingleResult();
		} catch (NoResultException e) {
			LOGGER.warn("Problemas en query", e);
			return null;
		} catch (NonUniqueResultException e) {
			LOGGER.warn("Problemas en query", e);
			return null;
		}
		return propertiesCore;
	}

	@Override
	public void updateProperty(Long propertieNumber, String property) {

		java.sql.Date date = new java.sql.Date(new Date().getTime());
		StringBuilder hql = new StringBuilder(" UPDATE PropertiesCore t ");
		hql.append(" SET t.property = :property ");
		hql.append(" , t.rowLastUpdate = :date ");
		hql.append(" WHERE t.rowDeleted <> 1 ");
		hql.append(" AND t.idProperty = :propertieNumber");

		Query query = entityManager.createQuery(hql.toString());
		query.setParameter("property", property);
		query.setParameter("date", date);
		query.setParameter("propertieNumber", propertieNumber);

		try {
			query.executeUpdate();
		} catch (IllegalStateException ex) {
			LOGGER.error("IllegalStateException, Error actualizando los registros para bloquear: \n{}", ex.toString());
		} catch (TransactionRequiredException ex) {
			LOGGER.error("TransactionRequiredException, Error actualizando los registros para bloquear: \n{}",
					ex.toString());
		} catch (QueryTimeoutException ex) {
			LOGGER.error("QueryTimeoutException,Error actualizando los registros para bloquear: \n{}", ex.toString());
		} catch (PersistenceException ex) {
			LOGGER.error("PersistenceException, Error actualizando los registros para bloquear: \n{}", ex.toString());
		}
	}

	// INI C01
	@Override
	public void updatePropertyParameter(PropertiesCore propertiesCore) {

		LOGGER.info("@updatePropertyParameter INPUT  " + propertiesCore.toString());

		java.sql.Date date = new java.sql.Date(new Date().getTime());
		StringBuilder hql = new StringBuilder(" UPDATE PropertiesCore t ");
		hql.append(" SET t.property = :property ");
		hql.append(" , t.parameter = :parameter ");
		hql.append(" , t.rowLastUpdate = :date ");
		hql.append(" WHERE t.rowDeleted <> 1 ");
		hql.append(" AND t.idProperty = :propertieNumber");

		Query query = entityManager.createQuery(hql.toString());
		query.setParameter("property", propertiesCore.getProperty());
		query.setParameter("date", date);
		query.setParameter("propertieNumber", propertiesCore.getIdProperty());
		query.setParameter("parameter", propertiesCore.getParameter());

		LOGGER.info("@updatePropertyParameter modificación terminada.");
		
		try {
			query.executeUpdate();
		} catch (IllegalStateException ex) {
			LOGGER.error("IllegalStateException, Error actualizando los registros para bloquear: \n{}", ex.toString());
		} catch (TransactionRequiredException ex) {
			LOGGER.error("TransactionRequiredException, Error actualizando los registros para bloquear: \n{}",
					ex.toString());
		} catch (QueryTimeoutException ex) {
			LOGGER.error("QueryTimeoutException,Error actualizando los registros para bloquear: \n{}", ex.toString());
		} catch (PersistenceException ex) {
			LOGGER.error("PersistenceException, Error actualizando los registros para bloquear: \n{}", ex.toString());
		}

	}
	// FIN C01

}
