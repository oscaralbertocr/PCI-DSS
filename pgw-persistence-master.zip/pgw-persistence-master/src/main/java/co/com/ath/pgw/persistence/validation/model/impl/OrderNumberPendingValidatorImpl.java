/*
 * OrderNumberPendingValidatorImpl
 *  
 * GSI - Integración
 * Creado el: 9/04/2015
 *
 * Copyright (c) A Toda Hora S.A. Todos los derechos reservados
 * 
 * Este software es confidencial y es propietario de ATH, queda prohibido
 * su uso, reproducción y copia de manera parcial o permanente salvo autorización
 * expresa de A Toda Hora S.A o de quién represente sus derechos.
 */
package co.com.ath.pgw.persistence.validation.model.impl;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

import javax.annotation.Resource;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import co.com.ath.pgw.bsn.model.bo.TransactionBO;
import co.com.ath.pgw.persistence.dao.TransactionDAO;
import co.com.ath.pgw.persistence.model.Transaction;
import co.com.ath.pgw.util.constants.PaymentWayCodes;
import co.com.ath.pgw.util.enums.TransactionStatusEnum;
import co.com.ath.pgw.util.i18n.BundleKeys;
import co.com.ath.pgw.util.i18n.BundleType;
import co.com.ath.pgw.util.i18n.ResourceBundleManager;
import co.com.ath.pgw.util.validation.ErrorCode;
import co.com.ath.pgw.util.validation.ValidationException;
import co.com.ath.pgw.util.validation.model.OrderNumberPendingValidator;


/**
 * Implementación del validador OrderNumberPendingValidator.
 *
 * @author Andrés Méndez Juanias <proveedor_mamendez@ath.com.co> 
 * @version 1.0 9/04/2015
 * @since 1.0
 */
@Service
public class OrderNumberPendingValidatorImpl implements
		OrderNumberPendingValidator {
	
	static Logger LOGGER = LoggerFactory.getLogger(OrderNumberPendingValidatorImpl.class);
	
	@Autowired
	private ResourceBundleManager bundleManager;
	
	@Resource
	private TransactionDAO transactionDAO;
	
	private Locale locale = Locale.getDefault();

	/* (non-Javadoc)
	 * @see co.com.ath.pgw.validation.model.OrderNumberPendingValidator#validate(co.com.ath.pgw.model.bo.TransactionBO)
	 */
	@Override
	public void validate(String pmtType, TransactionBO transactionBO)
			throws ValidationException {
		// Estados pendientes
		List<TransactionStatusEnum> statusList = new ArrayList<TransactionStatusEnum>();
		statusList.add(TransactionStatusEnum.REGISTERED);
		statusList.add(TransactionStatusEnum.LOGGED_IN);
		statusList.add(TransactionStatusEnum.PROCESSING);
		// Consultar las transacciones
		List<Transaction> list = transactionDAO.findByOrderNumberNuraCodeStatus(transactionBO
				.getOrderNumber(), transactionBO.getCommerce().getNuraCode(),
				statusList, pmtType, transactionBO.getInvoiceReference2(), 
				transactionBO.getInvoiceReference3(), transactionBO.getInvoiceReference4());
		
		if (!list.isEmpty()) {
			// Se obtiene la transacción
			Transaction tx = list.get(0);
			// Se crea la exepción
			ValidationException ve = new ValidationException(getMessage(tx),
					ErrorCode.INVALID_ORDER_NUMBER_PENDING);
			LOGGER.warn("Fallo en validador: \n{}", ve.toString());
			throw ve;
		}
	}
	
//	/* (non-Javadoc)
//	 * @see co.com.ath.pgw.validation.model.OrderNumberPendingValidator#validate(co.com.ath.pgw.model.bo.TransactionBO)
//	 */
//	@Override
//	public void validatePayPse(TransactionBO transactionBO)
//			throws ValidationException {
//		// Estados pendientes
//		List<TransactionStatusEnum> statusList = new ArrayList<TransactionStatusEnum>();
//		statusList.add(TransactionStatusEnum.REGISTERED);
//		statusList.add(TransactionStatusEnum.LOGGED_IN);
//		statusList.add(TransactionStatusEnum.PROCESSING);
//		// Medio de pago PSE
//		List<Long> paymentWayList = new ArrayList<Long>();
//		paymentWayList.add(PaymentWayCodes.PSE);
//		// Consultar las transacciones
//		List<Transaction> list = transactionDAO.findByOrderNumberNuraCodeStatusPending(transactionBO
//				.getOrderNumber(), transactionBO.getCommerce().getNuraCode(),
//				statusList, transactionBO.getTrnChannel(), transactionBO.getInvoiceReference2(), 
//				transactionBO.getInvoiceReference3(), transactionBO.getInvoiceReference4());
//		if (!list.isEmpty()) {
//			// Se obtiene la transacción
//			Transaction tx = list.get(0);
//			// Se crea la exepción
//			ValidationException ve = new ValidationException(getMessage(tx),
//					ErrorCode.INVALID_ORDER_NUMBER_PENDING);
//			LOGGER.warn("Fallo en validador: \n{}", ve.toString());
//			throw ve;
//		}
//	}
	
	private String getMessage(Transaction tx) {
		if (bundleManager == null) {
			return BundleKeys.ERROR_INVALID_ORDER_NUMBER_PENDING;
		}
		
		bundleManager.setBundle(BundleType.ERRORS);
		if(tx.getPaymentWay().getId() == PaymentWayCodes.PSE) {
			return bundleManager.getMessage(
					BundleKeys.ERROR_INVALID_ORDER_NUMBER_PENDING_PSE, 
					new Object[]{
							tx.getOrderNumber(),
							tx.getCommerce().getSubscription().getPhone(), 
							tx.getCommerce().getSubscription().getEmail(),
							tx.getTrazabilityCode()},
					locale);
		} else {
			return bundleManager.getMessage(
					BundleKeys.ERROR_INVALID_ORDER_NUMBER_PENDING, 
					new Object[]{
							tx.getOrderNumber(),
							tx.getCommerce().getSubscription().getPhone(), 
							tx.getCommerce().getSubscription().getEmail(), 
							tx.getPmtId().toString()},
					locale);
		}
	}

}