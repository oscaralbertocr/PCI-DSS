/*
 * CommerceContact
 *  
 * GSI - Integración
 * Creado el: 29/08/2014
 *
 * Copyright (c) A Toda Hora S.A. Todos los derechos reservados
 * 
 * Este software es confidencial y es propietario de ATH, queda prohibido
 * su uso, reproducción y copia de manera parcial o permanente salvo autorización
 * expresa de A Toda Hora S.A o de quién represente sus derechos.
 */
package co.com.ath.pgw.persistence.model;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import co.com.ath.pgw.persistence.PersistentObject;


/**
 * Contacto de un comercio. Esta entidad pertenece al modelo persistente.
 * 
 * @author proveedor_japiza
 * @version 1.0 29 Ago 2014
 * @since 1.0
 */
@Entity
@Table(name="CONTACTOSCOMERCIO")
public class CommerceContact implements PersistentObject {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1904670980677941218L;

	/**
	 * Comercio al que pertenece el contacto.
	 */
	@Id
	@ManyToOne(fetch=FetchType.LAZY)
	@JoinColumn(name="IDCOMERCIO")	
	private Commerce commerce;

	/**
	 * Rol del contacto en la pasarela para el comercio.
	 */
	@Id
	@ManyToOne(fetch=FetchType.EAGER)
	@JoinColumn(name="IDROL")
	private CommerceRoleContact role;

	/**
	 * Nombre del contacto.
	 */
	@Column(name="NOMBRE")
	private String name;
	
	/**
	 * Apellido del contacto.
	 */
	@Column(name="APELLIDO")
	private String apellido;

	/**
	 * Número celualar del contacto.
	 */
	@Column(name="CELULAR")
	private String mobilePhone;

	public String getApellido() {
		return apellido;
	}

	public void setApellido(String apellido) {
		this.apellido = apellido;
	}

	/**
	 * Correo electrónico del contacto.
	 */
	@Column(name="EMAIL")
	private String email;

	/**
	 * Indica si el registro tiene marca lógica de borrado
	 */
	@Column(name="REGELIMINADO", nullable=true)
	private boolean rowDeleted;
	
	/**
	 * Fecha de creación del registro
	 */
	@Temporal(TemporalType.TIMESTAMP)
	@Column(name="REGFECHACREACION", nullable=true)
	private Date rowCreationDate;
	
	/**
	 * Fecha de última modificación del registro
	 */
	@Temporal(TemporalType.TIMESTAMP)
	@Column(name="REGFECHAMODIFICACION", nullable=true)
	private Date rowLastUpdate;
	
	@Column(name="NUMERODOCUMENTO")
    private String numerodocumento;
    @Column(name="TIPODOCUMENTO")
    private String tipodocumento;


	/**
	 * Construye un contacto de un comercio.
	 */
	public CommerceContact(){
		super();
	}

	/**
	 * Retorna el comercio al que pertenece el contacto.
	 * 
	 * @return Comercio al que pertenece el contacto.
	 */
	public Commerce getCommerce(){
		return commerce;
	}

	/**
	 * Establece le comercio al que pertenece el contacto.
	 * 
	 * @param commerce Comercio al que pertenece el contacto.
	 */
	public void setCommerce(Commerce commerce){
		this.commerce = commerce;
	}

	/**
	 * Retorna el rol del contacto para el comercio.
	 * 
	 * @return Rol del contacto para el comercio.
	 */
	public CommerceRoleContact getRole(){
		return role;
	}

	/**
	 * Establece el rol del contacto para el comercio.
	 * 
	 * @param role Rol del contacto para el comercio.
	 */
	public void setRole(CommerceRoleContact role){
		this.role = role;
	}

	/**
	 * Retorna el nombre del contacto.
	 * 
	 * @return Nombre del contacto.
	 */
	public String getName(){
		return name;
	}

	/**
	 * Establece el nombre del contacto.
	 * 
	 * @param name Nombre del contacto.
	 */
	public void setName(String name){
		this.name = name;
	}

	/**
	 * Retorna el número celular del contacto.
	 * 
	 * @return Número celular del contacto.
	 */
	public String getMobilePhone(){
		return mobilePhone;
	}

	/**
	 * Establece el número celular del contacto.
	 * 
	 * @param mobilePhone Número celular del contacto.
	 */
	public void setMobilePhone(String mobilePhone){
		this.mobilePhone = mobilePhone;
	}

	/**
	 * Retorna el correo electrónico del contacto.
	 * 
	 * @return Correo electrónico del contacto.
	 */
	public String getEmail(){
		return email;
	}

	/**
	 * Establece el correo electrónico del contacto.
	 * 
	 * @param email Correo electrónico del contacto.
	 */
	public void setEmail(String email){
		this.email = email;
	}

	@Override
	public boolean isRowDeleted() {
		return rowDeleted;
	}

	@Override
	public void setRowDeleted(boolean rowDeleted) {
		this.rowDeleted = rowDeleted;
		
	}

	@Override
	public Date getRowCreationDate() {
		return rowCreationDate;
	}

	@Override
	public void setRowCreationDate(Date rowCreationDate) {
		this.rowCreationDate = rowCreationDate;
	}

	@Override
	public Date getRowLastUpdate() {
		return rowLastUpdate;
	}

	@Override
	public void setRowLastUpdate(Date rowLastUpdate) {
		this.rowLastUpdate = rowLastUpdate;
	}

	@Override
	public int hashCode(){
		final int prime = 31;
		int result = 1;
		result = prime * result
				+ ((commerce == null) ? 0 : commerce.hashCode());
		result = prime
				* result
				+ ((role == null) ? 0 : role.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj){
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		CommerceContact other = (CommerceContact) obj;
		if (commerce == null){
			if (other.commerce != null)
				return false;
		} else if (!commerce.equals(other.commerce))
			return false;
		if (role == null){
			if (other.role != null)
				return false;
		} else if (!role.equals(other.role))
			return false;
		return true;
	}
	
	

	public String getNumerodocumento() {
		return numerodocumento;
	}

	public void setNumerodocumento(String numerodocumento) {
		this.numerodocumento = numerodocumento;
	}

	public String getTipodocumento() {
		return tipodocumento;
	}

	public void setTipodocumento(String tipodocumento) {
		this.tipodocumento = tipodocumento;
	}

	@Override
	public String toString(){
		return "CommerceContact [commerce=" + commerce
				+ ", role=" + role + ", name="
				+ name + ", rowDeleted=" + rowDeleted + "]";
	}

}