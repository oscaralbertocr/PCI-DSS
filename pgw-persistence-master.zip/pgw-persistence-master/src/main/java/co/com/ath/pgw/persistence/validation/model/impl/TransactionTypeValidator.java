/*
 * TransactionTypeValidator
 *  
 * GSI - Integración
 * Creado el: 18/09/2014
 *
 * Copyright (c) A Toda Hora S.A. Todos los derechos reservados
 * 
 * Este software es confidencial y es propietario de ATH, queda prohibido
 * su uso, reproducción y copia de manera parcial o permanente salvo autorización
 * expresa de A Toda Hora S.A o de quién represente sus derechos.
 */
package co.com.ath.pgw.persistence.validation.model.impl;

import java.util.Locale;

import javax.annotation.Resource;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import co.com.ath.pgw.persistence.dao.TransactionTypeDAO;
import co.com.ath.pgw.persistence.model.TransactionType;
import co.com.ath.pgw.util.i18n.BundleKeys;
import co.com.ath.pgw.util.i18n.BundleType;
import co.com.ath.pgw.util.validation.AbstractAttributeValidator;
import co.com.ath.pgw.util.validation.ErrorCode;
import co.com.ath.pgw.util.validation.IntValueValidator;
import co.com.ath.pgw.util.validation.NotNullValidator;
import co.com.ath.pgw.util.validation.ObjectValidationException;
import co.com.ath.pgw.util.validation.ObjectValidator;
import co.com.ath.pgw.util.validation.ValidationException;

/**
 * Validador para el tipo de transacción.
 * 
 * @version 0.0.0 18/09/2014
 * @author Andrés Méndez Juanias <proveedor_mamendez@ath.com.co>
 */
@Service
public class TransactionTypeValidator extends AbstractAttributeValidator {

	static Logger LOGGER = LoggerFactory.getLogger(TransactionTypeValidator.class);
	
	private ObjectValidator validator;

	@Resource
	private TransactionTypeDAO transactionTypeDAO;

	@Override
	protected void doMandatoryValidate(Object attribute, Locale locale)
			throws ValidationException {
		validator = new NotNullValidator();
		validator.setBundleManager(bundleManager);
		try {
			validator.validate(attribute, locale);
		} catch (ObjectValidationException e) {
			throwException(e, locale);
		}
		doOptionalValidate(attribute, locale);
	}

	@Override
	protected void doOptionalValidate(Object attribute, Locale locale)
			throws ValidationException {
		validator = new IntValueValidator();
		validator.setBundleManager(bundleManager);
		try {
			validator.validate(attribute, locale);
		} catch (ObjectValidationException e) {
			throwException(e, locale);
		}
		validateExistence(attribute, locale);
	}

	/**
	 * Valida la existencia del tipo de transacción.
	 * 
	 * @param attribute
	 *            Id del tipo de transacción.
	 * @param locale
	 *            Localización.
	 * @throws ValidationException
	 *             En caso que no exista el registro.
	 */
	private void validateExistence(Object attribute, Locale locale)
			throws ValidationException {
		Long idType = Long.valueOf(attribute.toString());
		TransactionType transactionType = transactionTypeDAO.read(idType);
		if (transactionType == null) {
			throwException(getNotFoundEx(attribute, locale), locale);
		}
	}

	/**
	 * Retorna la exepción si el registro no existe.
	 * 
	 * @param attribute
	 *            Id del tipo de transacción para mostrar en el mensaje.
	 * @param locale
	 *            Localización.
	 * @return Objeto ObjectValidationException con la descripción del error.
	 */
	private ObjectValidationException getNotFoundEx(Object attribute,
			Locale locale) {
		return new ObjectValidationException(getMessage(
				BundleKeys.ERROR_INVALID_TRANSACTION_TYPE_NOT_FOUND,
				new Object[] { attribute }, locale));
	}

	/**
	 * Retorna el mensaje solicitado según los parametros.
	 * 
	 * @param messageKey
	 *            Clave del mensaje para el bundle.
	 * @param args
	 *            Argumentos construir el mensaje.
	 * @param locale
	 *            Localización.
	 * @return Mensaje formateado.
	 */
	private String getMessage(String messageKey, Object[] args, Locale locale) {
		if (bundleManager == null) {
			return messageKey;
		}
		bundleManager.setBundle(BundleType.ERRORS);
		return bundleManager.getMessage(messageKey, args, locale);
	}

	/**
	 * Método encargado de lanzar la excepción encontrada en los validadores.
	 * 
	 * @param e
	 *            Excepción de los validadores.
	 * @param locale
	 *            Localización.
	 * @throws ValidationException
	 */
	private void throwException(ObjectValidationException e, Locale locale)throws ValidationException {
		ValidationException ve =  new ValidationException(getMessage(
				BundleKeys.ERROR_INVALID_TRANSACTION_TYPE, null, locale),
				ErrorCode.INVALID_TRANSACTION_TYPE, e);
		LOGGER.warn("Fallo en validador: \n{}", e.toString());
		throw ve; 
		
	}
	
}
