/*
 * ReconciledTransactionDAOImpl
 *  
 * GSI - Integración
 * Creado el: 29/08/2014
 *
 * Copyright (c) A Toda Hora S.A. Todos los derechos reservados
 * 
 * Este software es confidencial y es propietario de ATH, queda prohibido
 * su uso, reproducción y copia de manera parcial o permanente salvo autorización
 * expresa de A Toda Hora S.A o de quién represente sus derechos.
 */
package co.com.ath.pgw.persistence.dao.impl;

import java.math.BigDecimal;

import javax.persistence.NoResultException;
import javax.persistence.NonUniqueResultException;
import javax.persistence.Query;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Repository;

import co.com.ath.pgw.persistence.AbstractDAO_JPA;
import co.com.ath.pgw.persistence.dao.ReconciledTransactionDAO;
import co.com.ath.pgw.persistence.model.ReconciledTransaction;

/**
 * Implementación por defecto de ReconciledTransactionDAO
 *
 * @author Andrés Méndez Juanias <proveedor_mamendez@ath.com.co>
 * @version 1.0 29 Ago 2014
 * @since 1.0
 */
@Repository
public class ReconciledTransactionDAOImpl 
								extends AbstractDAO_JPA<ReconciledTransaction> 
								implements ReconciledTransactionDAO {

	static Logger LOGGER = LoggerFactory.getLogger(ReconciledTransactionDAOImpl.class);
	
	public ReconciledTransactionDAOImpl() {
		super(ReconciledTransaction.class);
	}

	@Override
	public ReconciledTransaction findByTransactionId(Long transactionId) {
		StringBuilder hql = new StringBuilder(" from ReconciledTransaction r ");
		hql.append(" where r.rowDeleted <> 1 ");
		hql.append(" and r.transactionId.id = :transactionId ");
		
        Query query = entityManager.createQuery(hql.toString());
		query.setParameter("transactionId", transactionId);
		
		ReconciledTransaction reconciledTransaction = null;
		
		try {
			reconciledTransaction = (ReconciledTransaction) query.getSingleResult(); 
		} catch (NoResultException e) {
			LOGGER.warn("Resultado del query: NoResultException");
			return null;
		} catch (NonUniqueResultException e){
			LOGGER.warn("Problemas en query: \n{}", e);
            return null;
        }
		return reconciledTransaction;
	}

	@Override
	public BigDecimal sequenceIdTx() {
		StringBuilder sql = new StringBuilder("SELECT TRANSACCIONESCONCILIADAS_SEC.NEXTVAL FROM DUAL");
				
		Query query = entityManager.createNativeQuery(sql.toString());
		BigDecimal idTxC = null;
		
		try {
			idTxC = (BigDecimal) query.getSingleResult();
		} catch (NoResultException ex) {
			LOGGER.info("Query Exception : {}", ex.toString());
			return null;
		}
		return idTxC;
	}
	
}
