/*
 * CurrencyValidator
 *
 * GSI - Integración
 * Creado el: 18 de septiembre de 2014
 *
 * Copyright (c) A Toda Hora S.A. Todos los derechos reservados
 *
 * Este software es confidencial y es propietario de ATH, queda prohibido
 * su uso, reproducción y copia de manera parcial o permanente salvo autorización
 * expresa de A Toda Hora S.A o de quién represente sus derechos.
 */
package co.com.ath.pgw.persistence.validation.model.impl;

import java.util.Locale;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import co.com.ath.pgw.util.i18n.BundleKeys;
import co.com.ath.pgw.util.i18n.BundleType;
import co.com.ath.pgw.util.validation.AbstractAttributeValidator;
import co.com.ath.pgw.util.validation.ErrorCode;
import co.com.ath.pgw.util.validation.ObjectValidationException;
import co.com.ath.pgw.util.validation.ValidationException;

/**
 * Validador para el tipo de moneda.
 * 
 * @version 0.0.0 19/09/2014
 * @author Andrés Méndez Juanias <proveedor_mamendez@ath.com.co>
 */
@Service
public class CurrencyValidator extends AbstractAttributeValidator {

	static Logger LOGGER = LoggerFactory.getLogger(CurrencyValidator.class);

    private enum SupportedCurrency{ COP };
    
	@Override
	protected void doMandatoryValidate(Object attribute, Locale locale)
			throws ValidationException {
	}

	@Override
	protected void doOptionalValidate(Object attribute, Locale locale)
			throws ValidationException {
		if(attribute == null || attribute.toString().trim().isEmpty()){
            return;
        }
        String currency = attribute.toString().toUpperCase();
        for(SupportedCurrency cu: SupportedCurrency.values()){
            if(cu.toString().equals(currency)){
                return;
            }
        }
        throwException(getNotSupportedEx(attribute, locale), locale);
	}
    
    /**
	 * Retorna la exepción si el registro no existe.
	 * 
	 * @param attribute
	 *            token para mostrar en el mensaje.
	 * @param locale
	 *            Localización.
	 * @return Objeto ObjectValidationException con la descripción del error.
	 */
	private ObjectValidationException getNotSupportedEx(Object attribute,
			Locale locale) {
		return new ObjectValidationException(getMessage(
				BundleKeys.ERROR_INVALID_CURRENCY_TYPE_NOT_SUPPORTED,
				new Object[] { attribute }, locale));
	}
    
    /**
	 * Obtiene los mensajes del bundle basado en la llave que llega por
	 * parámetro.
	 * 
	 * @param messageKey
	 *            Clave del mensaje.
	 * @param args
	 *            Argumentos dinamicos para el mensaje.
	 * @param locale
	 *            Localización.
	 * @return Mensaje de error formateado o la messageKey si la llave no fue
	 *         encontrada.
	 */
	private String getMessage(String messageKey, Object[] args, Locale locale) {
		if (bundleManager == null) {
			return messageKey;
		}
		bundleManager.setBundle(BundleType.ERRORS);
		return bundleManager.getMessage(messageKey, args, locale);
	}

	/**
	 * Método encargado de lanzar la excepción encontrada en los validadores.
	 * 
	 * @param e
	 *            Excepción de los validadores.
	 * @param locale
	 *            Localización.
	 * @throws ValidationException
	 */
	private void throwException(ObjectValidationException e, Locale locale)
			throws ValidationException {
		ValidationException ve = new ValidationException(getMessage(
				BundleKeys.ERROR_INVALID_CURRENCY_TYPE, null, locale),
				ErrorCode.INVALID_CURRENCY_TYPE, e);
		LOGGER.warn("Fallo en validador: \n{}", ve.toString());
		throw ve;
	}

}
