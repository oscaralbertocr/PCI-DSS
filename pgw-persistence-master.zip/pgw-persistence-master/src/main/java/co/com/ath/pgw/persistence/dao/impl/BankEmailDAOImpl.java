package co.com.ath.pgw.persistence.dao.impl;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.NoResultException;
import javax.persistence.Query;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Repository;

import co.com.ath.pgw.persistence.AbstractDAO_JPA;
import co.com.ath.pgw.persistence.dao.BankEmailDAO;
import co.com.ath.pgw.persistence.model.BankEmail;

/**
 * Implementación por defecto de BankDAO
 * 
 * @author proveedor_jlara
 * @version 1.0 24 Nov 2016
 * @since 1.0
 */

@Repository
public class BankEmailDAOImpl extends AbstractDAO_JPA<BankEmail> implements BankEmailDAO{

	static Logger LOGGER = LoggerFactory.getLogger(BankEmailDAOImpl.class);
	
	/**
	 * Constructor por defecto
	 */
	public BankEmailDAOImpl() {
		super(BankEmail.class);
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<BankEmail> findByBank(Long idBank) {
		
		StringBuilder hql = new StringBuilder("from BankEmail t ");
		hql.append("where t.rowDeleted <> 1 ");
		hql.append("and t.bank.id = :idBank ");

        Query query = entityManager.createQuery(hql.toString());
		query.setParameter("idBank", idBank);
		
		List<BankEmail> bankEmailList = null;
		try {
			bankEmailList = (List<BankEmail>) query.getResultList(); 
		} catch (NoResultException e) {
			LOGGER.info("query Exception ", e.toString());
			return new ArrayList<BankEmail>();
		} 
		return bankEmailList;
	}
	
}
