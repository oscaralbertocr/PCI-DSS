package co.com.ath.pgw.persistence.model;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.validation.constraints.Size;

import co.com.ath.pgw.persistence.PersistentObject;

/**
 * Entidad persistente que representa los medios de pago asociados a un comercio
 * 
 * @author proveedor_jlara
 * @version 1.0 17 Noviembre 2016 
 * @since
 * 
 *  @RQ25510
 *  <strong>Autor</strong>Camilo Bustamante</br>
 *  <strong>Descripcion</strong>Extracto Digital</br>
 *  <strong>Numero de Cambios</strong>1</br>
 *  <strong>Identificador corto</strong>C01</br>
 */

@Entity
@Table(name="MEDIOSPAGOXCOMERCIO")
public class PaymentWayByCommerce implements PersistentObject{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 4551213890982367073L;

	@EmbeddedId
	private PaymentWayByCommercePK id;
	/**
	 * Identificador del comercio.
	 */
	@ManyToOne(fetch=FetchType.LAZY)
	@JoinColumn(name="IDCOMERCIO")
	private Commerce commerce;
	
	/**
	 * Medio de pago.
	 */
	@ManyToOne(fetch=FetchType.LAZY)
	@JoinColumn(name="IDMEDIOPAGO")
	private PaymentWay paymentWay;
	
	/**
	 * Número de cuenta autorizada por el banco
	 */
	@Size(max = 22)
	@Column(name="CUENTAASOCIADA")
	private String authorizedAccount;
	
	/**
	 * Indica si el registro tiene marca lógica de borrado
	 */
	@Column(name="REGELIMINADO", nullable=true)
	private boolean rowDeleted;
	
	/**
	 * Fecha de creación del registro
	 */
	@Temporal(TemporalType.TIMESTAMP)
	@Column(name="REGFECHACREACION", nullable=true)
	private Date rowCreationDate;
	
	/**
	 * Fecha de última modificación del registro
	 */
	@Temporal(TemporalType.TIMESTAMP)
	@Column(name="REGFECHAMODIFICACION", nullable=true)
	private Date rowLastUpdate;
	
	
	/**INICIO-C01*/
	@OneToOne(fetch=FetchType.EAGER)
	@JoinColumn(name="IDASOBTIPOCUENTA")
	private AsobancariaTipoCuenta asobancariaTipoCuenta;
	
	@OneToOne(fetch=FetchType.EAGER)
	@JoinColumn(name="IDASOBTIPORECAUDO")
	private AsobancariaTipoRecaudo asobancariaTipoRecaudo;
	
	@OneToOne(fetch=FetchType.EAGER)
	@JoinColumn(name="IDASOBPROCEPAGOS")
	private AsobancariaProcedenciaPagos asobancariaProcedenciaPagos;
	
	@OneToOne(fetch=FetchType.EAGER)
	@JoinColumn(name="IDASOBMEDIOPAGO")
	private AsobancariaMedioDePago asobancariaMedioDePago;
	/**FIN-C01*/
	
	@Size(max = 1)
	@Column(name="QR")
	private String qr;
	

	public Commerce getCommerce() {
		return commerce;
	}

	public void setCommerce(Commerce commerce) {
		this.commerce = commerce;
	}

	/**
	 * Retorna el medio de pago asociado al convenio
	 * 
	 * @return PaymentWay
	 */
	public PaymentWay getPaymentWay() {
		return paymentWay;
	}
	
	/**
	 * Establece el medio de pago
	 * 
	 * @param PaymentWay paymentWay
	 */
	public void setPaymentWay(PaymentWay paymentWay) {
		this.paymentWay = paymentWay;
	}

	public String getAuthorizedAccount() {
		return authorizedAccount;
	}

	public void setAuthorizedAccount(String authorizedAccount) {
		this.authorizedAccount = authorizedAccount;
	}

	@Override
	public boolean isRowDeleted() {
		return rowDeleted;
	}

	@Override
	public void setRowDeleted(boolean rowDeleted) {
		this.rowDeleted = rowDeleted;
	}

	@Override
	public Date getRowCreationDate() {
		return rowCreationDate;
	}

	@Override
	public void setRowCreationDate(Date rowCreationDate) {
		this.rowCreationDate = rowCreationDate;
	}

	@Override
	public Date getRowLastUpdate() {
		return rowLastUpdate;
	}

	@Override
	public void setRowLastUpdate(Date rowLastUpdate) {
		this.rowLastUpdate = rowLastUpdate;
	}

	 /**INICIO-C01*/
	/**
	 * @return the productType
	 */
	/**
	 * @return the asobancariaTipoCuenta
	 */
	public AsobancariaTipoCuenta getAsobancariaTipoCuenta() {
		return asobancariaTipoCuenta;
	}

	/**
	 * @param asobancariaTipoCuenta the asobancariaTipoCuenta to set
	 */
	public void setAsobancariaTipoCuenta(AsobancariaTipoCuenta asobancariaTipoCuenta) {
		this.asobancariaTipoCuenta = asobancariaTipoCuenta;
	}

	/**
	 * @return the asobancariaTipoRecaudo
	 */
	public AsobancariaTipoRecaudo getAsobancariaTipoRecaudo() {
		return asobancariaTipoRecaudo;
	}

	/**
	 * @param asobancariaTipoRecaudo the asobancariaTipoRecaudo to set
	 */
	public void setAsobancariaTipoRecaudo(
			AsobancariaTipoRecaudo asobancariaTipoRecaudo) {
		this.asobancariaTipoRecaudo = asobancariaTipoRecaudo;
	}

	/**
	 * @return the asobancariaProcedenciaPagos
	 */
	public AsobancariaProcedenciaPagos getAsobancariaProcedenciaPagos() {
		return asobancariaProcedenciaPagos;
	}

	/**
	 * @param asobancariaProcedenciaPagos the asobancariaProcedenciaPagos to set
	 */
	public void setAsobancariaProcedenciaPagos(
			AsobancariaProcedenciaPagos asobancariaProcedenciaPagos) {
		this.asobancariaProcedenciaPagos = asobancariaProcedenciaPagos;
	}

	/**
	 * @return the asobancariaMedioDePago
	 */
	public AsobancariaMedioDePago getAsobancariaMedioDePago() {
		return asobancariaMedioDePago;
	}

	/**
	 * @param asobancariaMedioDePago the asobancariaMedioDePago to set
	 */
	public void setAsobancariaMedioDePago(
			AsobancariaMedioDePago asobancariaMedioDePago) {
		this.asobancariaMedioDePago = asobancariaMedioDePago;
	}
	
	/**FIN-C01*/
	
	public String getQr() {
		return qr;
	}

	public void setQr(String qr) {
		this.qr = qr;
	}
}
