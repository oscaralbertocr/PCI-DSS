/*
 * CollectionAccountDAOImpl
 *  
 * GSI - Integración
 * Creado el: 29/08/2014
 *
 * Copyright (c) A Toda Hora S.A. Todos los derechos reservados
 * 
 * Este software es confidencial y es propietario de ATH, queda prohibido
 * su uso, reproducción y copia de manera parcial o permanente salvo autorización
 * expresa de A Toda Hora S.A o de quién represente sus derechos.
 */
package co.com.ath.pgw.persistence.dao.impl;

import java.util.List;

import javax.persistence.Query;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Repository;

import co.com.ath.pgw.persistence.AbstractDAO_JPA;
import co.com.ath.pgw.persistence.dao.CollectionAccountDAO;
import co.com.ath.pgw.persistence.model.CollectionAccount;

/**
 * Implementación por defecto de CollectionAccountDAO
 *
 * @author Camilo Andres Bustamante <camilo.bustamante@sophossolutions.com>
 * @version 1.0 11/07/2018
 * @since 1.0
 * 
 */
@Repository
public class CollectionAccountDAOImpl extends AbstractDAO_JPA<CollectionAccount> 
	implements CollectionAccountDAO {

	static Logger LOGGER = LoggerFactory.getLogger(CollectionAccountDAOImpl.class);


	public CollectionAccountDAOImpl() {
		super(CollectionAccount.class);
	}


	@SuppressWarnings("unchecked")
	@Override
	public List<CollectionAccount> getByCommerce(Long idComercio, Long idMedioPago) {

		List<CollectionAccount> list = null; 

		StringBuilder hql = new StringBuilder("from CollectionAccount c ");
		hql.append("where c.rowDeleted <> 1 ");
		hql.append("and c.commerce.id = :idComercio ");
		hql.append("and c.paymentWay.id = :idMedioPago ");

		Query query = entityManager.createQuery(hql.toString());
		query.setParameter("idComercio", idComercio);
		query.setParameter("idMedioPago", idMedioPago);
		
		try {
			list = (List<CollectionAccount>) query.getResultList();
		} catch (Exception e) {
			LOGGER.error("Ocurrio un error al consultar la lista de CUENTARECAUDADORA. "
					+ "Convenio:{}, Medio de Pago:{}\nError: {}","[idComercio="+idComercio+", idMedioPago="+idMedioPago+"]");
			/*LOGGER.error("Ocurrio un error al consultar la lista de CUENTARECAUDADORA. "
					+ "Convenio:{}, Medio de Pago:{}\nError: {}", 
					idComercio, idMedioPago, e.getMessage());*/
			
			return null;
		}

		return list;
		
	}

}
