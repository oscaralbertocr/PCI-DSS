package co.com.ath.pgw.persistence.procedure.model;

import java.io.Serializable;
import java.util.List;

import org.springframework.stereotype.Service;

import co.com.ath.pgw.core.logging.util.XMLUtil;
import co.com.ath.pgw.rest.dto.AssociateInfo;
import co.com.ath.pgw.rest.dto.PmtInfo;
import co.com.ath.pgw.rest.response.dto.AgreementSuccesResponse;

@Service
public class CreacionConvenio implements Serializable{
	private String operacion;
	private String estado;
	private String codigoNura;
	private String nit;
	private String codigoEan;
	private String codigoAch;
	private String agregador;
	private String codigoIncocredito;
	private String codigoTerminal;
	private String codigoGlobalPay;
	private String llaveGlobalPay;
	private String idActEcnomica;
	private String tarjetaCredito;
	private String idMunicipio;
	private String idBanco;	
	private String razonSocial;
	private String digitoVerificacion;
	private String direccion;
	private String telefono;
	private String email;
	private String repLegal;
	private String apeRepLegal;
	private String numDocRL;
	private String tipoDocRL;
	private String fax;
	private String tema;
	private String plantilla;
	private String logo;
	private String usuario;
	private String contrasena;
	private String urlRespuesta;
	private String urlConfirmacion;
	private String rutaCertificado;
	private String regEliminado;
	private String gender;
	private String tipoServicio;
	private String noFactMultipleRef;
	private String idMedioPago;
	private String cuentaAsociada;
	private String tipoCuenta;
	private String descTipoCuenta;
	private String idRol;
	private String tipoAdministrador;
	//Comercial
	private String nombreComercial;
	private String apellidoComercial;
	private String numDocComercial;
	private String tipoDocContComercial;
	private String emailContComercial;
	private String telContComercial;
	//Tecnico
	private String nombreTecnico;
	private String apellidoTecnico;
	private String numDocTecnico;
	private String tipoDocContTecnico;
	private String emailContTecnico;
	private String telContTecnico;
	//Operativo
	private String nombreOperativo;
	private String apellidoOperativo;
	private String numDocOperativo;
	private String tipoDocContOperativo;
	private String emailContOperativo;
	private String telContOperativo;
	
	private String codigoAchCuentaRecaudo;
 	private String idBancoCuentaRecaudo;
 	private String cuentaRecaudoAsociada;
 	private String tipoCuentaRecaudo;
 	private String descTipoCuentaREcaudo ;
	private static final long serialVersionUID = 1L;
	
	
	public String getCodigoGlobalPay() {
		return codigoGlobalPay;
	}

	public void setCodigoGlobalPay(String codigoGlobalPay) {
		this.codigoGlobalPay = codigoGlobalPay;
	}

	public String getLlaveGlobalPay() {
		return llaveGlobalPay;
	}

	public void setLlaveGlobalPay(String llaveGlobalPay) {
		this.llaveGlobalPay = llaveGlobalPay;
	}

	public String getTipoAdministrador() {
		return tipoAdministrador;
	}

	public void setTipoAdministrador(String tipoAdministrador) {
		this.tipoAdministrador = tipoAdministrador;
	}

	public String getCodigoAchCuentaRecaudo() {
		return codigoAchCuentaRecaudo;
	}

	public void setCodigoAchCuentaRecaudo(String codigoAchCuentaRecaudo) {
		this.codigoAchCuentaRecaudo = codigoAchCuentaRecaudo;
	}

	public String getIdBancoCuentaRecaudo() {
		return idBancoCuentaRecaudo;
	}

	public void setIdBancoCuentaRecaudo(String idBancoCuentaRecaudo) {
		this.idBancoCuentaRecaudo = idBancoCuentaRecaudo;
	}

	public String getCuentaRecaudoAsociada() {
		return cuentaRecaudoAsociada;
	}

	public void setCuentaRecaudoAsociada(String cuentaRecaudoAsociada) {
		this.cuentaRecaudoAsociada = cuentaRecaudoAsociada;
	}

	public String getTipoCuentaRecaudo() {
		return tipoCuentaRecaudo;
	}

	public void setTipoCuentaRecaudo(String tipoCuentaRecaudo) {
		this.tipoCuentaRecaudo = tipoCuentaRecaudo;
	}

	public String getDescTipoCuentaREcaudo() {
		return descTipoCuentaREcaudo;
	}

	public void setDescTipoCuentaREcaudo(String descTipoCuentaREcaudo) {
		this.descTipoCuentaREcaudo = descTipoCuentaREcaudo;
	}

	public CreacionConvenio() {
		// TODO Auto-generated constructor stub
	}

	public String getOperacion() {
		return operacion;
	}

	public void setOperacion(String operacion) {
		this.operacion = operacion;
	}

	public String getCodigoNura() {
		return codigoNura;
	}

	public void setCodigoNura(String codigoNura) {
		this.codigoNura = codigoNura;
	}

	public String getNit() {
		return nit;
	}

	public void setNit(String nit) {
		this.nit = nit;
	}

	public String getCodigoEan() {
		return codigoEan;
	}

	public void setCodigoEan(String codigoEan) {
		this.codigoEan = codigoEan;
	}

	public String getCodigoAch() {
		return codigoAch;
	}

	public void setCodigoAch(String codigoAch) {
		this.codigoAch = codigoAch;
	}

	public String getAgregador() {
		return agregador;
	}

	public void setAgregador(String agregador) {
		this.agregador = agregador;
	}

	public String getCodigoIncocredito() {
		return codigoIncocredito;
	}

	public void setCodigoIncocredito(String codigoIncocredito) {
		this.codigoIncocredito = codigoIncocredito;
	}

	public String getCodigoTerminal() {
		return codigoTerminal;
	}

	public void setCodigoTerminal(String codigoTerminal) {
		this.codigoTerminal = codigoTerminal;
	}

	public String getIdActEcnomica() {
		return idActEcnomica;
	}

	public void setIdActEcnomica(String idActEcnomica) {
		this.idActEcnomica = idActEcnomica;
	}

	public String getTarjetaCredito() {
		return tarjetaCredito;
	}

	public void setTarjetaCredito(String tarjetaCredito) {
		this.tarjetaCredito = tarjetaCredito;
	}

	public String getIdMunicipio() {
		return idMunicipio;
	}

	public void setIdMunicipio(String idMunicipio) {
		this.idMunicipio = idMunicipio;
	}

	public String getIdBanco() {
		return idBanco;
	}

	public void setIdBanco(String idBanco) {
		this.idBanco = idBanco;
	}

	public String getRazonSocial() {
		return razonSocial;
	}

	public void setRazonSocial(String razonSocial) {
		this.razonSocial = razonSocial;
	}

	public String getDigitoVerificacion() {
		return digitoVerificacion;
	}

	public void setDigitoVerificacion(String digitoVerificacion) {
		this.digitoVerificacion = digitoVerificacion;
	}

	public String getDireccion() {
		return direccion;
	}

	public void setDireccion(String direccion) {
		this.direccion = direccion;
	}

	public String getTelefono() {
		return telefono;
	}

	public void setTelefono(String telefono) {
		this.telefono = telefono;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getRepLegal() {
		return repLegal;
	}

	public void setRepLegal(String repLegal) {
		this.repLegal = repLegal;
	}

	public String getApeRepLegal() {
		return apeRepLegal;
	}

	public void setApeRepLegal(String apeRepLegal) {
		this.apeRepLegal = apeRepLegal;
	}

	public String getNumDocRL() {
		return numDocRL;
	}

	public void setNumDocRL(String numDocRL) {
		this.numDocRL = numDocRL;
	}

	public String getTipoDocRL() {
		return tipoDocRL;
	}

	public void setTipoDocRL(String tipoDocRL) {
		this.tipoDocRL = tipoDocRL;
	}

	public String getFax() {
		return fax;
	}

	public void setFax(String fax) {
		this.fax = fax;
	}

	public String getTema() {
		return tema;
	}

	public void setTema(String tema) {
		this.tema = tema;
	}

	public String getPlantilla() {
		return plantilla;
	}

	public void setPlantilla(String plantilla) {
		this.plantilla = plantilla;
	}

	public String getLogo() {
		return logo;
	}

	public void setLogo(String logo) {
		this.logo = logo;
	}

	public String getUsuario() {
		return usuario;
	}

	public void setUsuario(String usuario) {
		this.usuario = usuario;
	}

	public String getContrasena() {
		return contrasena;
	}

	public void setContrasena(String contrasena) {
		this.contrasena = contrasena;
	}

	public String getUrlConfirmacion() {
		return urlConfirmacion;
	}

	public void setUrlConfirmacion(String urlConfirmacion) {
		this.urlConfirmacion = urlConfirmacion;
	}

	public String getRutaCertificado() {
		return rutaCertificado;
	}

	public void setRutaCertificado(String rutaCertificado) {
		this.rutaCertificado = rutaCertificado;
	}

	public String getRegEliminado() {
		return regEliminado;
	}

	public void setRegEliminado(String regEliminado) {
		this.regEliminado = regEliminado;
	}

	public String getGender() {
		return gender;
	}

	public void setGender(String gender) {
		this.gender = gender;
	}

	public String getTipoServicio() {
		return tipoServicio;
	}

	public void setTipoServicio(String tipoServicio) {
		this.tipoServicio = tipoServicio;
	}

	public String getNoFactMultipleRef() {
		return noFactMultipleRef;
	}

	public void setNoFactMultipleRef(String noFactMultipleRef) {
		this.noFactMultipleRef = noFactMultipleRef;
	}

	
	
	public String getIdMedioPago() {
		return idMedioPago;
	}

	public void setIdMedioPago(String idMedioPago) {
		this.idMedioPago = idMedioPago;
	}

	public String getCuentaAsociada() {
		return cuentaAsociada;
	}

	public void setCuentaAsociada(String cuentaAsociada) {
		this.cuentaAsociada = cuentaAsociada;
	}

	public String getTipoCuenta() {
		return tipoCuenta;
	}

	public void setTipoCuenta(String tipoCuenta) {
		this.tipoCuenta = tipoCuenta;
	}

	public String getDescTipoCuenta() {
		return descTipoCuenta;
	}

	public void setDescTipoCuenta(String descTipoCuenta) {
		this.descTipoCuenta = descTipoCuenta;
	}

	public String getIdRol() {
		return idRol;
	}

	public void setIdRol(String idRol) {
		this.idRol = idRol;
	}

	

	public String getNombreComercial() {
		return nombreComercial;
	}

	public void setNombreComercial(String nombreComercial) {
		this.nombreComercial = nombreComercial;
	}

	public String getApellidoComercial() {
		return apellidoComercial;
	}

	public void setApellidoComercial(String apellidoComercial) {
		this.apellidoComercial = apellidoComercial;
	}

	public String getNumDocComercial() {
		return numDocComercial;
	}

	public void setNumDocComercial(String numDocComercial) {
		this.numDocComercial = numDocComercial;
	}

	public String getTipoDocContComercial() {
		return tipoDocContComercial;
	}

	public void setTipoDocContComercial(String tipoDocContComercial) {
		this.tipoDocContComercial = tipoDocContComercial;
	}

	public String getEmailContComercial() {
		return emailContComercial;
	}

	public void setEmailContComercial(String emailContComercial) {
		this.emailContComercial = emailContComercial;
	}

	public String getTelContComercial() {
		return telContComercial;
	}

	public void setTelContComercial(String telContComercial) {
		this.telContComercial = telContComercial;
	}

	public String getNombreTecnico() {
		return nombreTecnico;
	}

	public void setNombreTecnico(String nombreTecnico) {
		this.nombreTecnico = nombreTecnico;
	}

	public String getApellidoTecnico() {
		return apellidoTecnico;
	}

	public void setApellidoTecnico(String apellidoTecnico) {
		this.apellidoTecnico = apellidoTecnico;
	}

	public String getNumDocTecnico() {
		return numDocTecnico;
	}

	public void setNumDocTecnico(String numDocTecnico) {
		this.numDocTecnico = numDocTecnico;
	}

	public String getTipoDocContTecnico() {
		return tipoDocContTecnico;
	}

	public void setTipoDocContTecnico(String tipoDocContTecnico) {
		this.tipoDocContTecnico = tipoDocContTecnico;
	}

	public String getEmailContTecnico() {
		return emailContTecnico;
	}

	public void setEmailContTecnico(String emailContTecnico) {
		this.emailContTecnico = emailContTecnico;
	}

	public String getTelContTecnico() {
		return telContTecnico;
	}

	public void setTelContTecnico(String telContTecnico) {
		this.telContTecnico = telContTecnico;
	}

	public String getNombreOperativo() {
		return nombreOperativo;
	}  

	public void setNombreOperativo(String nombreOperativo) {
		this.nombreOperativo = nombreOperativo;
	}

	public String getApellidoOperativo() { 
		return apellidoOperativo;
	}

	public void setApellidoOperativo(String apellidoOperativo) {
		this.apellidoOperativo = apellidoOperativo;
	}

	public String getNumDocOperativo() {
		return numDocOperativo;
	}

	public void setNumDocOperativo(String numDocOperativo) {
		this.numDocOperativo = numDocOperativo;
	}

	public String getTipoDocContOperativo() {
		return tipoDocContOperativo;
	}

	public void setTipoDocContOperativo(String tipoDocContOperativo) {
		this.tipoDocContOperativo = tipoDocContOperativo;
	}

	public String getEmailContOperativo() {
		return emailContOperativo;
	}

	public void setEmailContOperativo(String emailContOperativo) {
		this.emailContOperativo = emailContOperativo;
	}

	public String getTelContOperativo() {
		return telContOperativo;
	}

	public void setTelContOperativo(String telContOperativo) {
		this.telContOperativo = telContOperativo;
	}

	public String getUrlRespuesta() {
		return urlRespuesta;
	}

	public void setUrlRespuesta(String urlRespuesta) {
		this.urlRespuesta = urlRespuesta;
	}

	public String getEstado() {
		return estado;
	}

	public void setEstado(String estado) {
		this.estado = estado;
	}
	
	@Override
	public String toString() {
		XMLUtil<CreacionConvenio> requestParser = 
				new XMLUtil<CreacionConvenio>();
		return requestParser.convertObjectToXml(this);
	}
	
}
