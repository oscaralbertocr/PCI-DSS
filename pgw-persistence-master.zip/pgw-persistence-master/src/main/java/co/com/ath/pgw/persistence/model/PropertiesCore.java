package co.com.ath.pgw.persistence.model;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import co.com.ath.pgw.persistence.PersistentObject;

/**
 * Clase que representa las propiedades de configuración del Core de la Pasarela
 * 
 * @author proveedor_jlara
 * @version 1.0 02 Dic 2016
 * @since 1.0
 */
@Entity
@Table(name="PROPIEDADES")
public class PropertiesCore implements PersistentObject{
	
	private static final long serialVersionUID = 8658947969768783083L;
	
	@Id
    @Column(name="ID_PROPIEDAD")
	private Long idProperty;
	
	@Column(name="CLAVE")
	private String passProperty;
	
	@Column(name="PROPIEDAD")
	private String property;
	
	@Column(name="PARAMETRO")
	private String parameter;
	
	@Column(name="DESCRIPCION")
	private String description;
	
	@Column(name="REGELIMINADO")
	private boolean rowDeleted;
	
	@Column(name="REGFECHACREACION")
    @Temporal(TemporalType.TIMESTAMP)
	private Date rowCreationDate;
	
	@Temporal(TemporalType.TIMESTAMP)
	@Column(name="REGFECHAMODIFICACION", nullable=true)
	private Date rowLastUpdate;
	
	public Long getIdProperty() {
		return idProperty;
	}

	public void setIdProperty(Long idProperty) {
		this.idProperty = idProperty;
	}

	public String getPassProperty() {
		return passProperty;
	}

	public void setPassProperty(String passProperty) {
		this.passProperty = passProperty;
	}

	public String getProperty() {
		return property;
	}

	public void setProperty(String property) {
		this.property = property;
	}

	public String getParameter() {
		return parameter;
	}

	public void setParameter(String parameter) {
		this.parameter = parameter;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	@Override
	public boolean isRowDeleted() {
		return rowDeleted;
	}

	@Override
	public void setRowDeleted(boolean rowDeleted) {
		this.rowDeleted = rowDeleted;
	}

	@Override
	public Date getRowCreationDate() {
		return rowCreationDate;
	}

	@Override
	public void setRowCreationDate(Date rowCreationDate) {
		this.rowCreationDate = rowCreationDate;
	}

	@Override
	public Date getRowLastUpdate(){
		return rowLastUpdate;
	}

	@Override
	public void setRowLastUpdate(Date rowLastUpdate){
		this.rowLastUpdate = rowLastUpdate;
	}

	@Override
	public String toString() {
		return "PropertiesCore [idProperty=" + idProperty + ", passProperty=" + passProperty + ", property=" + property
				+ ", parameter=" + parameter + ", description=" + description + ", rowDeleted=" + rowDeleted
				+ ", rowCreationDate=" + rowCreationDate + ", rowLastUpdate=" + rowLastUpdate + "]";
	}

	
}
