/*
 * Brand
 *  
 * GSI - Integración
 * Creado el: 28/08/2014
 *
 * Copyright (c) A Toda Hora S.A. Todos los derechos reservados
 * 
 * Este software es confidencial y es propietario de ATH, queda prohibido
 * su uso, reproducción y copia de manera parcial o permanente salvo autorización
 * expresa de A Toda Hora S.A o de quién represente sus derechos.
 */

package co.com.ath.pgw.persistence.model;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import co.com.ath.pgw.persistence.PersistentObject;

import javax.persistence.Temporal;
import javax.persistence.TemporalType;


/**
 * Marca de una tarjeta de crédito, usualmente conocida como Franquicia. Esta
 * entidad pertenece al modelo persistente.
 * 
 * @author proveedor_japiza
 * @version 1.0 19 Ago 2014
 * @since 1.0
 */
@Entity
@Table(name="FRANQUICIA")
public class Brand implements PersistentObject {	

	/**
	 * 
	 */
	private static final long serialVersionUID = -6625012948100906899L;

	/**
	 * Identificador de la marca en el sistema.
	 */
	@Id
    @Column(name = "ID")
	private Long id;

	/**
	 * Nombre de la marca.
	 */
	@Column(name="NOMBRE")
	private String name;

	/**
	 * Estado de la franquicia.
	 */
	@Column(name="ESTADO")
	private String status;

	/**
	 * Indica si el registro tiene marca lógica de borrado
	 */
	@Column(name="REGELIMINADO", nullable=true)
	private boolean rowDeleted;
	
	/**
	 * Fecha de creación del registro
	 */
	@Temporal(TemporalType.TIMESTAMP)
	@Column(name="REGFECHACREACION", nullable=true)
	private Date rowCreationDate;
	
	/**
	 * Fecha de última modificación del registro
	 */
	@Temporal(TemporalType.TIMESTAMP)
	@Column(name="REGFECHAMODIFICACION", nullable=true)
	private Date rowLastUpdate;

	/**
	 * Construye una marca de tarjeta.
	 */
	public Brand(){
		super();
	}

	/**
	 * Retorna el identificador de la marca en el sistema.
	 * 
	 * @return Identificador de la marca en el sistema.
	 */
	public Long getId(){
		return id;
	}

	/**
	 * Establece el identificador de la marca en el sistema.
	 * 
	 * @param id identificador de la marca en el sistema.
	 */
	public void setId(Long id){
		this.id = id;
	}

	/**
	 * Retorna el nombre de la marca.
	 * 
	 * @return Nombre de la marca.
	 */
	public String getName(){
		return name;
	}

	/**
	 * Establece el Nombre de la marca.
	 * 
	 * @param name Método encargado de actualizar el atributo name.
	 */
	public void setName(String name){
		this.name = name;
	}

	/**
	 * Retorna el estado de la marca en el sistema.
	 * 
	 * @return Estado de la marca.
	 */
	public String getStatus(){
		return status;
	}

	/**
	 * Establece el estado de la marca en el sistema.
	 * 
	 * @param status Estado de la marca.
	 */
	public void setStatus(String status){
		this.status = status;
	}

	@Override
	public boolean isRowDeleted(){
		return rowDeleted;
	}

	@Override
	public void setRowDeleted(boolean rowDeleted){
		this.rowDeleted = rowDeleted;
		
	}

	@Override
	public Date getRowCreationDate(){
		return rowCreationDate;
	}

	@Override
	public void setRowCreationDate(Date rowCreationDate){
		this.rowCreationDate = rowCreationDate;
	}

	@Override
	public Date getRowLastUpdate(){
		return rowLastUpdate;
	}

	@Override
	public void setRowLastUpdate(Date rowLastUpdate){
		this.rowLastUpdate = rowLastUpdate;
	}

	@Override
	public int hashCode(){
		final int prime = 31;
		int result = 1;
		result = prime * result + (int) (id ^ (id >>> 32));
		return result;
	}


	@Override
	public boolean equals(Object obj){
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Brand other = (Brand) obj;
		if (id != other.id)
			return false;
		return true;
	}

	@Override
	public String toString(){
		return "Brand [status=" + status + ", name=" + name + ", rowDeleted="
				+ rowDeleted + "]";
	}

}