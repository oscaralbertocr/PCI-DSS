/*
 * TransactionStatus
 *  
 * GSI - Integración
 * Creado el: 29/08/2014
 *
 * Copyright (c) A Toda Hora S.A. Todos los derechos reservados
 * 
 * Este software es confidencial y es propietario de ATH, queda prohibido
 * su uso, reproducción y copia de manera parcial o permanente salvo autorización
 * expresa de A Toda Hora S.A o de quién represente sus derechos.
 */
package co.com.ath.pgw.persistence.model;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import co.com.ath.pgw.persistence.PersistentObject;
import co.com.ath.pgw.util.enums.TransactionStatusEnum;

/**
 * Estado de una transacción. Esta entidad pertenece al modelo persitente.
 * 
 * @author proveedor_japiza
 * @version 1.0 29 Ago 2014
 * @since 1.0
 */
@Entity
@Table(name="ESTADOSTRANSACCION")
public class TransactionStatus implements PersistentObject {

	/**
	 * 
	 */
	private static final long serialVersionUID = 322204533976265649L;

	/**
	 * Código de estado.
	 */
	@Id
    @Column(name = "ID")
	private Long code;
	
	/**
	 * Codigo del estado del negocio de la transacción.
	 */		
	@ManyToOne(fetch=FetchType.EAGER)
	@JoinColumn(name="IDESTADONEGOCIO")
	private BusinessStatus businessCode;

	/**
	 * Descripcón del estado.
	 */
	@Column(name="ESTADO")
	@Enumerated(EnumType.STRING)
	private TransactionStatusEnum description;	

	/**
	 * Indica si el registro tiene marca lógica de borrado
	 */
	@Column(name="REGELIMINADO", nullable=true)
	private boolean rowDeleted;
	
	/**
	 * Fecha de creación del registro
	 */
	@Temporal(TemporalType.TIMESTAMP)
	@Column(name="REGFECHACREACION", nullable=true)
	private Date rowCreationDate;
	
	/**
	 * Fecha de última modificación del registro
	 */
	@Temporal(TemporalType.TIMESTAMP)
	@Column(name="REGFECHAMODIFICACION", nullable=true)
	private Date rowLastUpdate;

	/**
	 * Construye el estado de una transacción.
	 */
	public TransactionStatus(){
		super();
	}

	/**
	 * Retorna el código del estado.
	 * 
	 * @return Código del estado.
	 */
	public Long getCode(){
		return code;
	}

	/**
	 * Establece el código del estado.
	 * 
	 * @param code Código del estado.
	 */
	public void setCode(Long code){
		this.code = code;
	}

	/**
	 * @return the businessCode
	 */
	public BusinessStatus getBusinessCode() {
		return businessCode;
	}

	/**
	 * @param businessCode the businessCode to set
	 */
	public void setBusinessCode(BusinessStatus businessCode) {
		this.businessCode = businessCode;
	}

	/**
	 * Retorna la descripción del estado.
	 * 
	 * @return Descripción del estado.
	 */
	public TransactionStatusEnum getDescription(){
		return description;
	}

	/**
	 * Establece la descripción del estado.
	 * @param description Descripción del estado.
	 */
	public void setDescription(TransactionStatusEnum description){
		this.description = description;
	}

	@Override
	public boolean isRowDeleted(){
		return rowDeleted;
	}

	@Override
	public void setRowDeleted(boolean rowDeleted){
		this.rowDeleted = rowDeleted;
		
	}

	@Override
	public Date getRowCreationDate(){
		return rowCreationDate;
	}

	@Override
	public void setRowCreationDate(Date rowCreationDate){
		this.rowCreationDate = rowCreationDate;
	}

	@Override
	public Date getRowLastUpdate(){
		return rowLastUpdate;
	}

	@Override
	public void setRowLastUpdate(Date rowLastUpdate){
		this.rowLastUpdate = rowLastUpdate;
	}

	@Override
	public int hashCode(){
		final int prime = 31;
		int result = 1;
		result = prime * result + ((code == null) ? 0 : code.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj){
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		TransactionStatus other = (TransactionStatus) obj;
		if (code == null){
			if (other.code != null)
				return false;
		} else if (!code.equals(other.code))
			return false;
		return true;
	}

	@Override
	public String toString(){
		return "TransactionStatus [code=" + code + ", description="
				+ description + ", rowDeleted=" + rowDeleted + "]";
	}
	
}