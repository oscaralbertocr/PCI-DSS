/*
 * CrossingRulesImpl
 *  
 * GSI - Integración
 * Creado el: 29/08/2014
 *
 * Copyright (c) A Toda Hora S.A. Todos los derechos reservados
 * 
 * Este software es confidencial y es propietario de ATH, queda prohibido
 * su uso, reproducción y copia de manera parcial o permanente salvo autorización
 * expresa de A Toda Hora S.A o de quién represente sus derechos.
 */
package co.com.ath.pgw.persistence.dao.impl;

import java.util.List;

import javax.persistence.Query;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Repository;

import co.com.ath.pgw.persistence.AbstractDAO_JPA;
import co.com.ath.pgw.persistence.dao.CrossingRulesDAO;
import co.com.ath.pgw.persistence.model.CrossingRules;

/**
 * Implementación por defecto de CollectionBankTailDAO
 *
 * @author Camilo Andres Bustamante <camilo.bustamante@sophossolutions.com>
 * @version 1.0 11/07/2018
 * @since 1.0
 * 
 */
@Repository
public class CrossingRulesDAOImpl extends AbstractDAO_JPA<CrossingRules> 
	implements CrossingRulesDAO {

	static Logger LOGGER = LoggerFactory.getLogger(CrossingRulesDAOImpl.class);


	public CrossingRulesDAOImpl() {
		super(CrossingRules.class);
	}


	@SuppressWarnings("unchecked")
	@Override
	public List<CrossingRules> getByBankId(Long bankId) {

		List<CrossingRules> list = null; 

		StringBuilder hql = new StringBuilder("from CrossingRules c ");
		hql.append("where c.rowDeleted <> 1 ");
		hql.append("and c.bankPrimary.id = :bankId ");
		hql.append("order by c.priority asc ");

		Query query = entityManager.createQuery(hql.toString());
		query.setParameter("bankId", bankId);
		
		try {
			list = (List<CrossingRules>) query.getResultList(); 
		} catch (Exception e) {
			LOGGER.error("Ocurrio un error al obtener las reglas de cruce. "
					+ "bankId:{} \nError: {}", bankId, e.getMessage());
			return null;
		}

		return list;
		
	}

}
