/*
 * ReconciledTransactions
 *  
 * GSI - Integración
 * Creado el: 28/08/2014
 *
 * Copyright (c) A Toda Hora S.A. Todos los derechos reservados
 * 
 * Este software es confidencial y es propietario de ATH, queda prohibido
 * su uso, reproducción y copia de manera parcial o permanente salvo autorización
 * expresa de A Toda Hora S.A o de quién represente sus derechos.
 */
package co.com.ath.pgw.persistence.model;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

import co.com.ath.pgw.persistence.PersistentObject;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

/**
 * Representa la información de las transacciónes conciliadas.
 * 
 * @author proveedor_piza
 * @version 1.0 29 Ago 2014
 * @since 1.0
 */
@Entity
@Table(name="TRANSACCIONESCONCILIADAS")
public class ReconciledTransaction implements PersistentObject {

	/**
	 * 
	 */
	private static final long serialVersionUID = -3418177299433860054L;

	/** id Atributo de la clase. */
	/*@Id
	@Column(name = "ID")
	@GeneratedValue(strategy=GenerationType.SEQUENCE, generator="TRANSACCIONESCONCILIADAS_ID_GENERATOR")
	@SequenceGenerator(name="TRANSACCIONESCONCILIADAS_ID_GENERATOR", sequenceName="TRANSACCIONESCONCILIADAS_SEC", allocationSize = 580000)
	private Long id;*/

	
	@Id
	@Column(name="ID", unique=true, scale=22, precision=0)
	private Long id;
	
	//uni-directional many-to-one association to Transactions
	/** transaccione Atributo de la clase. */
	@ManyToOne(fetch=FetchType.LAZY)
	@JoinColumn(name="IDTRANSACCION")
	private Transaction transactionId;
	
	/** status Atributo de la clase. */
	@Column(name="ESTADO")
	private String status;
	
	/** red Atributo de la clase. */
	@Column(name="RED")
	private String red;

	/** reconciledDate Atributo de la clase. */
	@Column(name="FECHACONCILIACION")
	@Temporal(TemporalType.TIMESTAMP)
	private Date reconciledDate;	

	/** rowCreationDate Atributo de la clase. */
	@Column(name="REGFECHACREACION")
    @Temporal(TemporalType.TIMESTAMP)
	private Date rowCreationDate;

	/** rowLastUpdate Atributo de la clase. */
	@Column(name="REGFECHAMODIFICACION")	
    @Temporal(TemporalType.TIMESTAMP)
	private Date rowLastUpdate;
	
	/** rowDeleted Atributo de la clase. */
	@Column(name="REGELIMINADO")
	private boolean rowDeleted;	

	public ReconciledTransaction(){
		super();
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + (int) (id ^ (id >>> 32));
		return result;
	}

	/**
	 * Método encargado de recuperar el valor del atributo id.
	 * @return El atributo id asociado a la clase.
	 */
	public Long getId() {
		return id;
	}

	/**
	 * Método encargado de actualizar el atributo ReconciledTransactions.java.
	 * @param id Nuevo valor para id.
	 */
	public void setId(Long id) {
		this.id = id;
	}

	/**
	 * Método encargado de recuperar el valor del atributo transactionId.
	 * @return El atributo transactionId asociado a la clase.
	 */
	public Transaction getTransactionId() {
		return transactionId;
	}

	/**
	 * Método encargado de actualizar el atributo ReconciledTransactions.java.
	 * @param transactionId Nuevo valor para transactionId.
	 */
	public void setTransactionId(Transaction transactionId) {
		this.transactionId = transactionId;
	}

	/**
	 * Método encargado de recuperar el valor del atributo status.
	 * @return El atributo status asociado a la clase.
	 */
	public String getStatus() {
		return status;
	}

	/**
	 * Método encargado de actualizar el atributo ReconciledTransactions.java.
	 * @param status Nuevo valor para status.
	 */
	public void setStatus(String status) {
		this.status = status;
	}

	/**
	 * Método encargado de recuperar el valor del atributo red.
	 * @return El atributo red asociado a la clase.
	 */
	public String getRed() {
		return red;
	}

	/**
	 * Método encargado de actualizar el atributo ReconciledTransactions.java.
	 * @param red Nuevo valor para red.
	 */
	public void setRed(String red) {
		this.red = red;
	}

	/**
	 * Método encargado de recuperar el valor del atributo reconciledDate.
	 * @return El atributo reconciledDate asociado a la clase.
	 */
	public Date getReconciledDate() {
		return reconciledDate;
	}

	/**
	 * Método encargado de actualizar el atributo ReconciledTransactions.java.
	 * @param reconciledDate Nuevo valor para reconciledDate.
	 */
	public void setReconciledDate(Date reconciledDate) {
		this.reconciledDate = reconciledDate;
	}

	/**
	 * Método encargado de recuperar el valor del atributo rowCreationDate.
	 * @return El atributo rowCreationDate asociado a la clase.
	 */
	public Date getRowCreationDate() {
		return rowCreationDate;
	}

	/**
	 * Método encargado de actualizar el atributo ReconciledTransactions.java.
	 * @param rowCreationDate Nuevo valor para rowCreationDate.
	 */
	public void setRowCreationDate(Date rowCreationDate) {
		this.rowCreationDate = rowCreationDate;
	}

	/**
	 * Método encargado de recuperar el valor del atributo rowLastUpdate.
	 * @return El atributo rowLastUpdate asociado a la clase.
	 */
	public Date getRowLastUpdate() {
		return rowLastUpdate;
	}

	/**
	 * Método encargado de actualizar el atributo ReconciledTransactions.java.
	 * @param rowLastUpdate Nuevo valor para rowLastUpdate.
	 */
	public void setRowLastUpdate(Date rowLastUpdate) {
		this.rowLastUpdate = rowLastUpdate;
	}

	/**
	 * Método encargado de recuperar el valor del atributo rowDeleted.
	 * @return El atributo rowDeleted asociado a la clase.
	 */
	public boolean isRowDeleted() {
		return rowDeleted;
	}

	/**
	 * Método encargado de actualizar el atributo ReconciledTransactions.java.
	 * @param rowDeleted Nuevo valor para rowDeleted.
	 */
	public void setRowDeleted(boolean rowDeleted) {
		this.rowDeleted = rowDeleted;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		ReconciledTransaction other = (ReconciledTransaction) obj;
		if (id != other.id)
			return false;
		return true;
	}

	@Override
	public String toString() {
		return "ReconciledTransactions [id=" + id + ", transactionId="
				+ transactionId + ", status=" + status + ", red=" + red
				+ ", reconciledDate=" + reconciledDate + ", rowDeleted="
				+ rowDeleted + "]";
	}	
}