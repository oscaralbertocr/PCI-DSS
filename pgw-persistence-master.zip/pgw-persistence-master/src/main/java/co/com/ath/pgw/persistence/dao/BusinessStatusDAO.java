/**
 * 
 */
package co.com.ath.pgw.persistence.dao;

import co.com.ath.pgw.persistence.DataAccessObject;
import co.com.ath.pgw.persistence.model.BusinessStatus;

/**
 * @author proveedor_japiza
 *
 */
public interface BusinessStatusDAO extends DataAccessObject<BusinessStatus> {

}
