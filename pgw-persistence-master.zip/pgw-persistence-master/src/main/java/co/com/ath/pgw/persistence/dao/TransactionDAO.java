/*
 * TransactionDAO
 *  
 * GSI - Integración
 * Creado el: 29/08/2014
 *
 * Copyright (c) A Toda Hora S.A. Todos los derechos reservados
 * 
 * Este software es confidencial y es propietario de ATH, queda prohibido
 * su uso, reproducción y copia de manera parcial o permanente salvo autorización
 * expresa de A Toda Hora S.A o de quién represente sus derechos.
 */
package co.com.ath.pgw.persistence.dao;

import java.math.BigDecimal;
import java.sql.Timestamp;
import java.util.Date;
import java.util.List;

import co.com.ath.pgw.persistence.DataAccessObject;
import co.com.ath.pgw.persistence.model.Transaction;
import co.com.ath.pgw.persistence.model.TransactionSource;
import co.com.ath.pgw.persistence.model.TransactionStatus;
import co.com.ath.pgw.util.enums.TransactionStatusEnum;

/**
 * Objeto de Acceso a Datos para las entidades Transaction
 *
 * @author Andrés Méndez Juanias <proveedor_mamendez@ath.com.co>
 * @version 1.0 29 Ago 2014
 * @since 1.0
 * 
 *  @IM30719
 *  <strong>Autor</strong>Henry Hernandez</br>
 *  <strong>Descripcion</strong>Actualizacion tx pendientes mediante SP</br>
 *  <strong>Numero de Cambios</strong>1</br>
 *  <strong>Identificador corto</strong>C01</br>
 */
public interface TransactionDAO extends DataAccessObject<Transaction> {
    
	Transaction findByOrderNumber(String orderNumber);
    
	Transaction findByIdTransactionNuraCode(Long idTransaction, String nuraCode);
    
	/*INICIO C01*/
	//se elimina el campo de entrada statusList para el metodo lockTransactionForClose
    //void lockTransactionForClose(Long jobLockId, Date transactionDate, List<TransactionStatusEnum> statusList);
    void lockTransactionForClose(Long jobLockId, Date transactionDate);
    /*FIN C01*/
    void lockTransactionForClosePending(Long jobLockId, Date transactionDate, List<TransactionStatusEnum> statusList);
    
    Object[] countTotalRows(Long commerceId, Long statusCode,Timestamp compensationDateStart, Timestamp compensationDateEnd);
    
    Object[] countTotalRows(Timestamp startDate, Timestamp endDate, Long statusCode, Long bankCode);
    
    Object[] countTotalRows(TransactionSource source, Timestamp startDate, Timestamp endDate, TransactionStatus statusCode);
    
    List<Transaction> findByOrderNumberNuraCodeStatus(String orderNumber, String nuraCode, List<TransactionStatusEnum> statusList, String trnChannel,
			String invoiceReference2, String invoiceReference3, String invoiceReference4);
    
	List<Transaction> findHistoric(String docType, String docNum,Date startDate, Date endDate, String state, String paymentWayId);
	
	BigDecimal sequenceIdTx();
	
	Transaction findByPmtId(Long pmtId);
	
	Transaction findByPmtIdTransactionNuraCode(Long pmtIdTransaction, String nuraCode);
	
	String getAggregatorNit(Transaction tx, String NitAg, String nitAvVillas);

	public void lockRBMTransactionForClose(Long jobLockId, Date jobDate, List<TransactionStatusEnum> statusList);
	
	public void lockTransaction(Long jobLockId, Date transactionDate, List<TransactionStatusEnum> statusList);

}
