/*
 * Commerce
 *  
 * GSI - Integración
 * Creado el: 28/08/2014
 *
 * Copyright (c) A Toda Hora S.A. Todos los derechos reservados
 * 
 * Este software es confidencial y es propietario de ATH, queda prohibido
 * su uso, reproducción y copia de manera parcial o permanente salvo autorización
 * expresa de A Toda Hora S.A o de quién represente sus derechos.
 */
package co.com.ath.pgw.persistence.model;

import java.util.Date;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.OneToOne;
import javax.persistence.OneToMany;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import co.com.ath.pgw.persistence.PersistentObject;

/**
 * Representa un comercio asociado. Esta entidad pertenece al modelo
 * persistente.
 * 
 * @author proveedor_japiza
 * @version 1.0 29 Ago 2014
 * @since 1.0
 * 
 * @RQ27828 <strong>Autor</strong>Sandra Redondo</br>
 *          <strong>Descripcion</strong> Tokenizacion TC</br>
 *          <strong>Fecha</strong>12/09/2017</br>
 *          <strong>Numero de Cambios</strong> 2</br>
 *          <strong>Identificador corto</strong> C01</br>
 */
@Entity
@Table(name="COMERCIO")
public class Commerce implements PersistentObject {	

	/**
	 * 
	 */
	private static final long serialVersionUID = -261659643938991974L;

	/**
	 * Identificador único del comercio en el sistema.
	 */
	@Id
    @Column(name = "ID")
	@SequenceGenerator(	name="COMERCIO_ID_GENERATOR", sequenceName="COMERCIO_SEC")
	@GeneratedValue( strategy=GenerationType.SEQUENCE, generator="COMERCIO_ID_GENERATOR")
	private Long id;

	/**
	 * Número de identificación tributaria (NIT) de la empresa que inscribe
	 * el comercio.
	 */
	@Column(name = "NIT")
	private Long nit;

	/**
	 * Código NURA del comercio.
	 */
	@Column(name="CODIGONURA")
	private String nuraCode;

	/**
	 * Código ACH del comercio.
	 */
	@Column(name="CODIGOACH")
	private String achCode;

	/**
	 * Código EAN del comercio.
	 */
	@Column(name="CODIGOEAN")
	private String eanCode;

	/**
	 * Código Incocredito del comercio.
	 */
	@Column(name="CODIGOINCOCREDITO")
	private String incocreditoCode;
	
	/**
	 * Código Terminal del comercio.
	 */
	@Column(name="CODIGOTERMINAL")
	private String terminalCode;

	/**
	 * Código de homologación banco AV Villas
	 */
	@Column(name="HOMOLOGATION_BAVV_CODE")
	private String homologationBAVVCode;

	/**
	 * Estado del comercio.
	 */
	@Column(name="ESTADO")
	private String status;
	
	/** INICIO-C01 **/
	/**
	 * Indicador para determinar si el comercio hace referencia a una tarjeta de crédito
	 * Agregado por proveedor_sredondo .
	 */
	@Column(name="TARJETA_CREDITO")
	private String creditCardInd;
	/** FIN-C01 **/


	/**
	 * Configuración técnica del comercio.
	 */
	@OneToOne(mappedBy="commerce", fetch=FetchType.EAGER)
	private CommerceConfiguration configuration;

	/**
	 * Medios de pago habilidatos para el comercio.
	 */
	@ManyToMany(fetch = FetchType.EAGER, cascade = CascadeType.ALL)
	@JoinTable(
		name="MEDIOSPAGOXCOMERCIO",
		joinColumns={
				@JoinColumn(name="IDCOMERCIO", referencedColumnName="id")},
		inverseJoinColumns={
				@JoinColumn(name="IDMEDIOPAGO", referencedColumnName="id")}
		)
	private List<PaymentWay> paymentWays;
	
	@OneToMany(mappedBy="commerce", fetch=FetchType.EAGER, cascade = CascadeType.ALL)
	private List<PaymentWayByCommerce> paymentWayByCommerce;
	
	@OneToMany(mappedBy="commerce", fetch=FetchType.LAZY, cascade = CascadeType.ALL)
	private List<CommerceContact> commerceContact;
	
	/**
	 * Información detallada del comercio.
	 */
	@OneToOne(mappedBy="commerce", fetch=FetchType.EAGER)
	private Subscription subscription;

	public List<CommerceContact> getCommerceContact() {
		return commerceContact;
	}
	public void setCommerceContact(List<CommerceContact> commerceContact) {
		this.commerceContact = commerceContact;
	}

	/**
	 * Indica si el registro tiene marca lógica de borrado
	 */
	@Column(name="REGELIMINADO", nullable=true)
	private boolean rowDeleted;
	
	/**
	 * Fecha de creación del registro
	 */
	@Temporal(TemporalType.TIMESTAMP)
	@Column(name="REGFECHACREACION", nullable=true)
	private Date rowCreationDate;
	
	/**
	 * Fecha de última modificación del registro
	 */
	@Temporal(TemporalType.TIMESTAMP)
	@Column(name="REGFECHAMODIFICACION", nullable=true)
	private Date rowLastUpdate;
		
	/**
	 * Indica si el comercio es agregador
	 */
	@Column(name="AGREGADOR", nullable=true)
	private boolean aggregator;
	
	/**
	 * Código actividad economica del comercio.
	 */
	@Column(name="IDACTIVIDADECONOMICA")
	private String idEconomicActivity;

	/**
	 * Zip Asobancaria - Flag
	 */
	@Column(name="ZIPASOBANCARIA")
	private Long zipasobancaria;
	
	
	/**
	 * codigo de la llave appCode
	 */
	@Column(name="CODIGOAPPRBM")
	private String codigoAppRbm;
	
	/**
	 * llave applicationKey
	 */
	@Column(name="KEYRBM")
	private String keyRbm;
	
	
	/**
	 * Construye un comercio sin atributos.
	 */
	 public Commerce(){
		super();
	}
	 public Commerce(Long id){
		 this.id= id;
	 }

	/**
	 * Retorna el identificador único del comercio en el sistema.
	 * 
	 * @return Identificador único del comercio en el sistema.
	 */
	public Long getId() {
		return id;
	}

	/**
	 * Establece el identificador único del comercio en el sistema.
	 * 
	 * @param id identificador único del comercio.
	 */
	public void setId(Long id) {
		this.id = id;
	}

	/**
	 * Retorna el número de identificación tributaria (NIT) de la empresa que
	 * inscribe el comercio.
	 * 
	 * @return NIT del comercio.
	 */
	public Long getNit() {
		return nit;
	}

	/**
	 * Establece el número de identificación tributaria (NIT) de la empresa que
	 * inscribe el comercio.
	 * 
	 * @param nit NIT del comercio.
	 */
	public void setNit(Long nit) {
		this.nit = nit;
	}

	/**
	 * Retorna el código NURA del comercio.
	 * 
	 * @return Código NURA.
	 */
	public String getNuraCode() {
		return nuraCode;
	}

	/**
	 * Establece el código NURA del comercio.
	 *  
	 * @param nuraCode Código NURA.
	 */
	public void setNuraCode(String nuraCode) {
		this.nuraCode = nuraCode;
	}

	/**
	 * Retorna el código ACH del comercio.
	 * 
	 * @return Código ACH.
	 */
	public String getAchCode() {
		return achCode;
	}

	/**
	 * Establece el código ACH del comercio.
	 * 
	 * @param achCode Código ACH.
	 */
	public void setAchCode(String achCode) {
		this.achCode = achCode;
	}

	/**
	 * Retorna el código EAN del comercio.
	 * 
	 * @return Código EAN.
	 */
	public String getEanCode() {
		return eanCode;
	}

	/**
	 * Establece el código EAN del comercio.
	 * 
	 * @param eanCode Código EAN.
	 */
	public void setEanCode(String eanCode) {
		this.eanCode = eanCode;
	}

	/**
	 * Retorna el código asignado por Incocrédito al comercio.
	 * 
	 * @return Código Incocrédito.
	 */
	public String getIncocreditoCode() {
		return incocreditoCode;
	}

	/**
	 * Establece el código que Incocrédito asignó al comercio.
	 * 
	 * @param incocreditoCode Código Incocrédito.
	 */
	public void setIncocreditoCode(String incocreditoCode) {
		this.incocreditoCode = incocreditoCode;
	}
	
	/**
	 * Retorna el código asignado por Terminal al comercio.
	 * 
	 * @return Código Terminal.
	 */
	public String getTerminalCode() {
		return terminalCode;
	}

	/**
	 * Establece el código que Terminal asignó al comercio.
	 * 
	 * @param terminalCode Código Terminal.
	 */
	public void setTerminalCode(String terminalCode) {
		this.terminalCode = terminalCode;
	}

	/**
	 * Existen algunos convenios de recaudo suscritos con el Banco AV Villas que
	 * tienen códigos de 8 dígitos (Diferentes al código NURA) y para que el 
	 * banco pueda procesar los pagos de estos se debe homologar el código NURA
	 * registrado en la pasarela al código registrado en el Banco AV Villas.
	 * 
	 * @return Código de homologación AV Villas
	 */
	public String getHomologationBAVVCode() {
		return homologationBAVVCode;
	}
	
	/**
	 * Establece el codigo de homologación para el banco AV Villas.
	 * @see Commerce#getHomologationBAVVCode()
	 * 
	 * @param homologationBAVVCode Código de homologación Av Villas
	 */
	public void setHomologationBAVVCode(String homologationBAVVCode) {
		this.homologationBAVVCode = homologationBAVVCode;
	}

	/**
	 * Retorna el estado del comercio.
	 * 
	 * @return Estado del comercio.
	 */
	public String getStatus() {
		return status;
	}

	/**
	 * Establece el estado del comericio.
	 * 
	 * @param status Estado del comercio.
	 */
	public void setStatus(String status) {
		this.status = status;
	}
	
	
	/** INICIO-C01 **/
	/**
	 * Retorna el indicativo de relación con referencia de tarjeta de credito.
	 * 
	 * @return Indicativo 1 o 0.
	 */
	
	public String getCreditCardInd() {
		return creditCardInd;
	}
	
	/**
	 * Establece el indicativo de relación con referencia de tarjeta de crédito.
	 * 
	 * @param status Estado del comercio.
	 */

	public void setCreditCardInd(String creditCardInd) {
		this.creditCardInd = creditCardInd;
	}
	/** FIN-C01 **/

	/**
	 * Retorna la configuración técnica del comercio. Incluye la información
	 * gráfica del comercio.
	 * 
	 * @return Configuración técnica.
	 */
	public CommerceConfiguration getConfiguration() {
		return configuration;
	}

	/**
	 * Establece la configuración técnica del comercio.
	 * 
	 * @param configuration Configuración técnica.
	 */
	public void setConfiguration(CommerceConfiguration configuration) {
		this.configuration = configuration;
	}

	/**
	 * Retorna los medios de pago disponibles para el comercio.
	 * 
	 * @return Medios de pago disponibles.
	 */
	public List<PaymentWay> getPaymentWays() {
		return paymentWays;
	}

	/**
	 * Establece los medios de pago disponibles para el comercio.
	 * 
	 * @param paymentWays Medios de pago.
	 */
	public void setPaymentWays(List<PaymentWay> paymentWays) {
		this.paymentWays = paymentWays;
	}

	/**
	 * Retorna la información detallada del comercio.
	 * 
	 * @return Infomación detallada del comercio.
	 */
	public Subscription getSubscription() {
		return subscription;
	}

	/**
	 * Establece la información detallada del comercio.
	 * 
	 * @param subscription Información detallada del comercio.
	 */
	public void setSubscription(Subscription subscription) {
		this.subscription = subscription;
	}

	/**
	 * Retorna la marcacion si el comercio es agregador.
	 * 
	 * @return Infomación de marca de comercio.
	 */
     public boolean getAggregator() {
	   return aggregator;
 	 }

	/**
	 * Establece marcacion si el comercio es agregador.
	 * 
	 * @param marcacion si el comercio es agregador.
	 */
	public void setAggregator(boolean aggregator) {
		this.aggregator = aggregator;
	}
	
	/**
	 * Retorna el código de actividad económica del comercio.
	 * 
	 * @return Infomación el código de actividad económica del comercio.
	 */
     public String getIdEconomicActivity() {
	   return idEconomicActivity;
 	 }
     
	public Long getZipasobancaria() {
		return zipasobancaria;
	}

	public void setZipasobancaria(Long zipasobancaria) {
		this.zipasobancaria = zipasobancaria;
	}

	/**
	 * Establece el código de actividad económica del comercio.
	 * 
	 * @param código de actividad económica del comercio.
	 */
	public void setIdEconomicActivity(String idEconomicActivity) {
		this.idEconomicActivity = idEconomicActivity;
	}
	
	

	public List<PaymentWayByCommerce> getPaymentWayByCommerce() {
		return paymentWayByCommerce;
	}

	public void setPaymentWayByCommerce(
			List<PaymentWayByCommerce> paymentWayByCommerce) {
		this.paymentWayByCommerce = paymentWayByCommerce;
	}

	@Override
	public boolean isRowDeleted() {
		return rowDeleted;
	}

	@Override
	public void setRowDeleted(boolean rowDeleted) {
		this.rowDeleted = rowDeleted;
		
	}

	@Override
	public Date getRowCreationDate() {
		return rowCreationDate;
	}

	@Override
	public void setRowCreationDate(Date rowCreationDate) {
		this.rowCreationDate = rowCreationDate;
	}

	@Override
	public Date getRowLastUpdate() {
		return rowLastUpdate;
	}

	@Override
	public void setRowLastUpdate(Date rowLastUpdate) {
		this.rowLastUpdate = rowLastUpdate;
	}

	@Override
	public int hashCode(){
		final int prime = 31;
		int result = 1;
		result = prime * result
				+ ((nuraCode == null) ? 0 : nuraCode.hashCode());
		return result;
	}

	public boolean equals(Object obj){
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Commerce other = (Commerce) obj;
		if (nuraCode == null){
			if (other.nuraCode != null)
				return false;
		} else if (!nuraCode.equals(other.nuraCode))
			return false;
		return true;
	}
	
	@Override
	public String toString(){
		return "Commerce [id=" + id + ", nuraCode=" + nuraCode + ", status="
				+ status + ", nit=" + nit + ", rowDeleted=" + rowDeleted + "]";
	}
	/**
	 * @return the codigoAppRbm
	 */
	public String getCodigoAppRbm() {
		return codigoAppRbm;
	}
	/**
	 * @param codigoAppRbm the codigoAppRbm to set
	 */
	public void setCodigoAppRbm(String codigoAppRbm) {
		this.codigoAppRbm = codigoAppRbm;
	}
	/**
	 * @return the keyRbm
	 */
	public String getKeyRbm() {
		return keyRbm;
	}
	/**
	 * @param keyRbm the keyRbm to set
	 */
	public void setKeyRbm(String keyRbm) {
		keyRbm = keyRbm;
	}
}