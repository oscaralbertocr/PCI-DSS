/*
 * HistoricSms
 *  
 * PASARELA DE PAGOS - Recaudos.
 * Creado el: 14/07/2016
 *
 * Copyright (c) A Toda Hora S.A. Todos los derechos reservados
 * 
 * Este software es confidencial y es propietario de ATH, queda prohibido
 * su uso, reproducción y copia de manera parcial o permanente salvo autorización
 * expresa de A Toda Hora S.A o de quién represente sus derechos.
 */
package co.com.ath.pgw.persistence.dao;

import co.com.ath.pgw.persistence.DataAccessObject;
import co.com.ath.pgw.persistence.model.TipoDocumento;

/**
 * Objeto de Acceso a Datos para las entidades HistoricSms. 
 *
 * @author Camilo Andres Bustamante <proveedor_cbustamante@ath.com.co>
 * @version 1.0 14 Sept 2016
 * @since 1.0
 */

public interface TipoDocumentoDAO extends DataAccessObject<TipoDocumento> {
	
}
