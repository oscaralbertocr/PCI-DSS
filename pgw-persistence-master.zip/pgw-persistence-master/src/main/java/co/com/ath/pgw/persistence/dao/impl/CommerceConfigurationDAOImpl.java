/*
 * CommerceConfigurationDAOImpl
 *  
 * GSI - Integración
 * Creado el: 29/08/2014
 *
 * Copyright (c) A Toda Hora S.A. Todos los derechos reservados
 * 
 * Este software es confidencial y es propietario de ATH, queda prohibido
 * su uso, reproducción y copia de manera parcial o permanente salvo autorización
 * expresa de A Toda Hora S.A o de quién represente sus derechos.
 */
package co.com.ath.pgw.persistence.dao.impl;

import javax.persistence.NoResultException;
import javax.persistence.Query;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Repository;

import co.com.ath.pgw.persistence.AbstractDAO_JPA;
import co.com.ath.pgw.persistence.dao.CommerceConfigurationDAO;
import co.com.ath.pgw.persistence.model.CommerceConfiguration;

/**
 * Implementación por defecto de CommerceConfigurationDAO
 * 
 * @author Andrés Méndez Juanias <proveedor_mamendez@ath.com.co>
 * @version 1.0 29 Ago 2014
 * @since 1.0
 */
@Repository
public class CommerceConfigurationDAOImpl extends
		AbstractDAO_JPA<CommerceConfiguration> implements
		CommerceConfigurationDAO {
	
	static Logger LOGGER = LoggerFactory.getLogger(CommerceDAOImpl.class);

	public CommerceConfigurationDAOImpl() {
		super(CommerceConfiguration.class);
	}

	@Override
	public CommerceConfiguration findById(Long idComercio) {

		StringBuilder sb = new StringBuilder("from CommerceConfiguration c ");
		sb.append("where c.commerceId = :commerceId ");

		Query query = entityManager.createQuery(sb.toString());
		query.setParameter("commerceId", idComercio);

		CommerceConfiguration commerceConf = null;

		try {
			commerceConf = (CommerceConfiguration) query.getSingleResult();
		} catch (NoResultException e) {
			LOGGER.info("No hay resultados en la consulta de configuracion de comercio ("+ idComercio + ")");
			return commerceConf;
		} catch (Exception ex) {
			LOGGER.warn("Problemas en query", ex);
			return commerceConf;
		}
		
		return commerceConf;
	}

}
