/*
 * ReconciledTransactionServiceImpl
 *  
 * GSI - Integración
 * Creado el: 13/01/2015
 *
 * Copyright (c) A Toda Hora S.A. Todos los derechos reservados
 * 
 * Este software es confidencial y es propietario de ATH, queda prohibido
 * su uso, reproducción y copia de manera parcial o permanente salvo autorización
 * expresa de A Toda Hora S.A o de quién represente sus derechos.
 */
package co.com.ath.pgw.persistence.service.impl;

import java.math.BigDecimal;
import java.util.Date;

import javax.annotation.Resource;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import co.com.ath.pgw.persistence.PersistentObjectFactory;
import co.com.ath.pgw.persistence.dao.ReconciledTransactionDAO;
import co.com.ath.pgw.persistence.model.ReconciledTransaction;
import co.com.ath.pgw.persistence.model.Transaction;
import co.com.ath.pgw.persistence.service.ReconciledTransactionService;

/**
 * Implementacion por defecto de ReconciledTransactionService.
 *
 * @author Andrés Méndez Juanias <proveedor_mamendez@ath.com.co> 
 * @version 1.0 13/01/2015
 * @since 1.0
 */
@Service
public class ReconciledTransactionServiceImpl implements
		ReconciledTransactionService {
	
	static Logger LOGGER = LoggerFactory.getLogger(ReconciledTransactionServiceImpl.class);

	@Resource
	private PersistentObjectFactory persistentObjectFactory;
	
	@Resource
	private ReconciledTransactionDAO reconciledTransactionDAO;
	
	/* (non-Javadoc)
	 * @see co.com.ath.pgw.bsn.services.ReconciledTransactionService#createOrUpdate(co.com.ath.pgw.persistence.model.Transaction)
	 */
	@Override
	public ReconciledTransaction createOrUpdate(Transaction tx, String statusRed) {
		ReconciledTransaction reconciledTransaction = null;
		try {
			if(tx != null) {
				Date curDate = new Date();
				reconciledTransaction = reconciledTransactionDAO.findByTransactionId(tx.getId());
				if(statusRed == null){
					statusRed = (tx.getResponseCode()!= null)? tx.getResponseCode().getCode(): null;
				}
				if(reconciledTransaction != null) {
					reconciledTransaction.setStatus((tx.getStatus() != null)? tx.getStatus().getDescription().toString(): null);
					reconciledTransaction.setRed(statusRed);
					reconciledTransaction.setReconciledDate(curDate);
					reconciledTransaction.setRowLastUpdate(curDate);
					reconciledTransactionDAO.update(reconciledTransaction);
				} else {
					
					reconciledTransaction = persistentObjectFactory.createReconciledTransaction();
					BigDecimal idTxC = reconciledTransactionDAO.sequenceIdTx();
					reconciledTransaction.setId(Long.parseLong(idTxC.toString()));
					reconciledTransaction.setTransactionId(tx);
					reconciledTransaction.setStatus((tx.getStatus() != null)? tx.getStatus().getDescription().toString(): null);
					reconciledTransaction.setRed(statusRed);
					reconciledTransaction.setReconciledDate(curDate);
					reconciledTransaction.setRowCreationDate(curDate);
					
					LOGGER.info(" transaccion a reconciliar \n" + reconciledTransaction.toString());
					
					reconciledTransaction = reconciledTransactionDAO.create(reconciledTransaction);
				}
			}
		} catch (NumberFormatException e) {
			// TODO Auto-generated catch block
			LOGGER.info("Error en la Creación o Actualizacion de ReconciledTransaction PMTID: {}" , tx.getPmtId());
			LOGGER.info("El estado actual de la trancción es: {}" , tx.getStatus());
			e.printStackTrace();
			return reconciledTransaction;
		}
		return reconciledTransaction;
	}
}
