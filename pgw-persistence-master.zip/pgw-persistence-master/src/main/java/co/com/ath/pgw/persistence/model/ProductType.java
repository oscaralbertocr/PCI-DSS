/*
 * ProductTypes
 *  
 * GSI - Integración
 * Creado el: 28/08/2014
 *
 * Copyright (c) A Toda Hora S.A. Todos los derechos reservados
 * 
 * Este software es confidencial y es propietario de ATH, queda prohibido
 * su uso, reproducción y copia de manera parcial o permanente salvo autorización
 * expresa de A Toda Hora S.A o de quién represente sus derechos.
 */
package co.com.ath.pgw.persistence.model;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import co.com.ath.pgw.persistence.PersistentObject;

import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.validation.constraints.Size;


/**
 * Representa un tupo de producto financiero válido en la Pasarela de Pagos.
 * Esta entidad pertenece al modelo persistente.
 * 
 * @author proveedor_japiza
 * @version 1.0 29 Ago 2014
 * @since 1.0
 *
 */
@Entity
@Table(name="TIPOSPRODUCTO")
public class ProductType implements PersistentObject {

	/**
	 * 
	 */
	private static final long serialVersionUID = 7158486713902564453L;

	/**
	 * Identificador del tipo de producto.
	 */
	@Id
    @Column(name = "ID")
	private long id;
	
	/**
	 * Nombre o descripción del tipo de producto.
	 */
	@Column(name="TIPOPRODUCTO")
	private String name;	
	/**INICIO-C01*/
	/**
	 * Identificador del tipo de producto (recaudo) en Asobancaria.
	 */
    @Column(name = "ASOBANCARIA")
	private long asobancaria;
    /**FIN-C01*/

	/**
	 * Indica si el registro tiene marca lógica de borrado
	 */
	@Column(name="REGELIMINADO", nullable=true)
	private boolean rowDeleted;
	
	/**
	 * Fecha de creación del registro
	 */
	@Temporal(TemporalType.TIMESTAMP)
	@Column(name="REGFECHACREACION", nullable=true)
	private Date rowCreationDate;
	
	/**
	 * Fecha de última modificación del registro
	 */
	@Temporal(TemporalType.TIMESTAMP)
	@Column(name="REGFECHAMODIFICACION", nullable=true)
	private Date rowLastUpdate;
	
	/**
	 * Construye un tipo de producto vacío.
	 */
	public ProductType(){
		super();
	}
	
	/**
	 * Construye un tipo de producto especificando el identificador.
	 * 
	 * @param id Identificador del tipo de producto.
	 */
	ProductType(Long id){
		this.id = id;
	}
	
	/**
	 * Retorna el identificador del tipo de producto.
	 * 
	 * @return Identificador del tipo de producto.
	 */
	public long getId() {
		return id;
	}

	/**
	 * Establece el identificador del tipo de producto.
	 * 
	 * @param id Identificador del tipo de producto.
	 */
	public void setId(long id) {
		this.id = id;
	}

	/**
	 * Retorna el nombre o descripción del tipo de producto.
	 * 
	 * @return Nombre del tipo de producto.
	 */
	public String getName() {
		return name;
	}

	/**
	 * Establece el nombre o descripción del tipo de producto.
	 * 
	 * @param name Nombre del tipo de producto.
	 */
	public void setName(String name) {
		this.name = name;
	}
	/**INICIO-C01*/
	/**
	 * @return the asobancaria
	 */
	public long getAsobancaria() {
		return asobancaria;
	}

	/**
	 * @param asobancaria the asobancaria to set
	 */
	public void setAsobancaria(long asobancaria) {
		this.asobancaria = asobancaria;
	}
	/**FIN-C01*/

	@Override
	public boolean isRowDeleted() {
		return rowDeleted;
	}

	@Override
	public void setRowDeleted(boolean rowDeleted) {
		this.rowDeleted = rowDeleted;
		
	}

	@Override
	public Date getRowCreationDate() {
		return rowCreationDate;
	}

	@Override
	public void setRowCreationDate(Date rowCreationDate) {
		this.rowCreationDate = rowCreationDate;
	}

	@Override
	public Date getRowLastUpdate() {
		return rowLastUpdate;
	}

	@Override
	public void setRowLastUpdate(Date rowLastUpdate) {
		this.rowLastUpdate = rowLastUpdate;
	}
	
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + (int) (id ^ (id >>> 32));
		return result;
	}


	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		ProductType other = (ProductType) obj;
		if (id != other.id)
			return false;
		return true;
	}

	@Override
	public String toString() {
		return "ProductType [id=" + id + ", name=" + name + ", rowDeleted="
				+ rowDeleted + "]";
	}

}