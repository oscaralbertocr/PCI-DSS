package co.com.ath.pgw.persistence.service;

import co.com.ath.pgw.persistence.model.Transaction;

/**
 * 
 * @PDP-374
 * <strong>Autor</strong>Camilo Bustamante</br>
 * <strong>Descripcion</strong>Envio de correo promocional</br>
 * <strong>Numero de Cambios</strong>1</br>
 * <strong>Identificador corto</strong>C01</br>
 * 
 */
public interface SendMailService {
	
	public void sendMail(Transaction tx);
	
	/** INICIO-C01 */
	public void sendPromoMail(Transaction tx);
	/** FIN-C01 */
	
}
