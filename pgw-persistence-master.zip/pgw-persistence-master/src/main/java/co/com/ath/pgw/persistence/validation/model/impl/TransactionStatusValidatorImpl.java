/*
 * TransactionStatusValidator
 *  
 * GSI - Integración
 * Creado el: 15/10/2014
 *
 * Copyright (c) A Toda Hora S.A. Todos los derechos reservados
 * 
 * Este software es confidencial y es propietario de ATH, queda prohibido
 * su uso, reproducción y copia de manera parcial o permanente salvo autorización
 * expresa de A Toda Hora S.A o de quién represente sus derechos.
 */
package co.com.ath.pgw.persistence.validation.model.impl;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

import javax.annotation.Resource;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import co.com.ath.pgw.persistence.dao.TransactionDAO;
import co.com.ath.pgw.persistence.model.Transaction;
import co.com.ath.pgw.util.constants.PaymentGatewayOperation;
import co.com.ath.pgw.util.enums.TransactionStatusEnum;
import co.com.ath.pgw.util.i18n.BundleKeys;
import co.com.ath.pgw.util.i18n.BundleType;
import co.com.ath.pgw.util.i18n.ResourceBundleManager;
import co.com.ath.pgw.util.validation.ErrorCode;
import co.com.ath.pgw.util.validation.ObjectValidationException;
import co.com.ath.pgw.util.validation.TransactionStatusValidator;
import co.com.ath.pgw.util.validation.ValidationException;


/**
 * Implementación por defecto del validador de estado de la transacción.
 * 
 * @version 0.0.0 15/10/2014
 * @author Andrés Méndez Juanias <proveedor_mamendez@ath.com.co>
 */
@Service
public class TransactionStatusValidatorImpl implements TransactionStatusValidator {

	static Logger LOGGER = LoggerFactory.getLogger(TransactionStatusValidatorImpl.class);
	
	@Autowired
	private ResourceBundleManager bundleManager; 
	
	private Map<Long, List<String>> operationsAllowedByStatus;
	
	private Locale locale;
	
	public TransactionStatusValidatorImpl() {
		List<String> operationList;
		operationsAllowedByStatus = new HashMap<Long, List<String>>();
		
		operationList = new ArrayList<String>();
		operationList.add(PaymentGatewayOperation.GET_TRANSACTION_BY_TOKEN);
		operationsAllowedByStatus.put(TransactionStatusEnum.REGISTERED.getCode(), operationList);
		
		operationList = new ArrayList<String>();
		operationList.add(PaymentGatewayOperation.ADD_AVAL_PAYMENT);
		operationList.add(PaymentGatewayOperation.ADD_PSE_TRANSACTION);
		operationList.add(PaymentGatewayOperation.ADD_RBM_PAYMENT);
		operationsAllowedByStatus.put(TransactionStatusEnum.LOGGED_IN.getCode(), operationList);
		operationsAllowedByStatus.put(TransactionStatusEnum.PROCESSING.getCode(), operationList);
		
		operationList = new ArrayList<String>();
		operationList.add(PaymentGatewayOperation.GET_TRANSACTION_BY_ID);
		operationsAllowedByStatus.put(TransactionStatusEnum.CONFIRMED_OK.getCode(), operationList);
		operationsAllowedByStatus.put(TransactionStatusEnum.CONFIRMED_NA.getCode(), operationList);
		operationsAllowedByStatus.put(TransactionStatusEnum.FAILED.getCode(), operationList);
		operationsAllowedByStatus.put(TransactionStatusEnum.CANCELLED.getCode(), operationList);
		
		locale = Locale.getDefault();
	}
	
	@Resource
	private TransactionDAO transactionDAO;

	
	@Override
	public void validate(Long idTransaction, String operation) throws ValidationException {
		Transaction transaction = transactionDAO.read(idTransaction);
		if(transaction == null || transaction.getStatus() == null){
			throwException(getErrorEx(), locale);
		}
		List<String> operatioList = operationsAllowedByStatus.get(
				transaction.getStatus().getCode());
		
		if(operatioList == null || !operatioList.contains(operation)){
			throwException(getErrorEx(), locale);
		}
	}

	/**
	 * Retorna la exepción si la operacion no se puede ejecutar en el estado de 
	 * la transacción.
	 * 
	 * @return Objeto ObjectValidationException con la descripción del error.
	 */
	private ObjectValidationException getErrorEx() {
		return new ObjectValidationException(getMessage(
				BundleKeys.ERROR_INVALID_TRANSACTION_STATUS_FOR_OPERATION,
				null, locale));
	}

	/**
	 * Obtiene los mensajes del bundle basado en la llave que llega por
	 * parámetro.
	 * 
	 * @param messageKey
	 *            Clave del mensaje.
	 * @param args
	 *            Argumentos dinamicos para el mensaje.
	 * @param locale
	 *            Localización.
	 * @return Mensaje de error formateado o la messageKey si la llave no fue
	 *         encontrada.
	 */
	private String getMessage(String messageKey, Object[] args, Locale locale) {
		if (bundleManager == null) {
			return messageKey;
		}
		bundleManager.setBundle(BundleType.ERRORS);
		return bundleManager.getMessage(messageKey, args, locale);
	}

	/**
	 * Método encargado de lanzar la excepción encontrada en los validadores.
	 * 
	 * @param e
	 *            Excepción de los validadores.
	 * @param locale
	 *            Localización.
	 * @throws ValidationException
	 */
	private void throwException(ObjectValidationException e, Locale locale)
			throws ValidationException {
		ValidationException ve = new ValidationException(getMessage(
				BundleKeys.ERROR_INVALID_TRANSACTION_STATUS_FOR_OPERATION, null, locale),
				ErrorCode.INVALID_TRANSACTION_STATUS_FOR_OPERATON, 	e);
		LOGGER.warn("Fallo en validador: \n{}", ve.toString());
		throw ve;
	}

}
