/*
f * Transactions
 *  
 * GSI - Integración
 * Creado el: 29/08/2014
 *
 * Copyright (c) A Toda Hora S.A. Todos los derechos reservados
 * 
 * Este software es confidencial y es propietario de ATH, queda prohibido
 * su uso, reproducción y copia de manera parcial o permanente salvo autorización
 * expresa de A Toda Hora S.A o de quién represente sus derechos.
 */
package co.com.ath.pgw.persistence.model;

import java.math.BigDecimal;
import java.util.Arrays;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.Lob;
import javax.persistence.ManyToOne;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import co.com.ath.pgw.persistence.PersistentObject;

/**
 * Representa una transacción de pago en el Core de la Pasarela de Pago. Esta
 * entidad pertenece al modelo persistente.
 * 
 * @author proveedor_japiza
 * @version 1.0 29 Ago 2014
 * @since 1.0
 * 
 * @RQ27828 
 * <strong>Autor</strong> Luis Hernando Bonilla Cortes</br>
 * <strong>Descripcion</strong> Consumo operacion addTokenize para TC</br>
 * <strong>Fecha</strong>12/09/2017</br>
 * <strong>Numero de Cambios</strong> 2</br>
 * <strong>Identificador corto</strong> C01</br>
 * 
 * @RQ30455
 * <strong>Autor</strong>Camilo Bustamante</br>
 * <strong>Descripcion</strong>Permitir Compartir Recaudos PSE</br>
 * <strong>Numero de Cambios</strong>1</br>
 * <strong>Identificador corto</strong>C02</br>
 * 
 * @RQ31686
 * <strong>Autor</strong>Camilo Bustamante</br>
 * <strong>Descripcion</strong>RBM Integracion Boton TC GlobalPay</br>
 * <strong>Numero de Cambios</strong>1</br>
 * <strong>Identificador corto</strong>C03</br>
 * 
 */
@Entity
@Table(name="TRANSACCIONES")
public class Transaction implements PersistentObject {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1298057270811481702L;

	/**
	 * Identificador de la transacción en el Core de la Pasarela de Pagos.
	 */
	@Id
	@Column(name="ID", unique=true, scale=22, precision=0)
	private Long id;
	
	/**
	 * Comercio que inicia la transacción.
	 */
	@ManyToOne(fetch=FetchType.EAGER)
	@JoinColumn(name="IDCOMERCIO")
	private Commerce commerce;

	/**
	 * Estado de la transacción.
	 */
	@ManyToOne(fetch=FetchType.EAGER)
	@JoinColumn(name="IDESTADO")
	private TransactionStatus status;
	
	/**
	 * Tipo de transacción.
	 */
	@ManyToOne(fetch=FetchType.EAGER)
	@JoinColumn(name="IDTIPOTRANSACCION")
	private TransactionType transactionType;
	
	/**
	 * Origen de la transacción.
	 */
	@ManyToOne(fetch=FetchType.EAGER)
	@JoinColumn(name="IDORIGENTRANSACCION")
	private TransactionSource source;

	/**
	 * Medio de pago.
	 */
	@ManyToOne(fetch=FetchType.EAGER)
	@JoinColumn(name="IDMEDIOPAGO")
	private PaymentWay PaymentWay;
	
	/**
	 * Tipo de producto financiero usado para el pago.
	 */
	@ManyToOne(fetch=FetchType.EAGER)
	@JoinColumn(name="IDTIPOPRODUCTO")
	private ProductType productType;
	
	/**
	 * Tarjeta de crédito asociada a la transacción.
	 */
	@ManyToOne(fetch=FetchType.EAGER)
	@JoinColumn(name="IDTARJETACREDITO")
	private CreditCard creditCard;

	/**
	 * Código de trazabilidad con redes externas (ACH, Redeban, etc)
	 */
	@Column(name="IDTRANSACCIONRED")
	private String trazabilityCode;
	/**
	 * acepta terminos y condiciones del pago
	 */
	@Column(name="TERMINOSYCONDICIONES", nullable=true)
	private Boolean termsAndConditions;
	/**
	 * Banco autorizador de la transacción. Este campo se usa solo con pagos
	 * AVAL y PSE 
	 */
	@ManyToOne(fetch=FetchType.EAGER)
	@JoinColumn(name="IDBANCO")
	private Bank bank;
	
	
	/**
	 * Banco recaudador de la transacción.
	 */
	@ManyToOne(fetch=FetchType.EAGER)
	@JoinColumn(name="IDBANCORECAUDADOR")
	private Bank bankCollecter;

	/**
	 * Dirección IP relacionada a la transacción.
	 */
	@Column(name="IPTRANSACCION")
	private String ipAddress;
	
	/**
	 * Código de respuesta de los servicios de pago.
	 */
	@ManyToOne(fetch=FetchType.EAGER)
	@JoinColumn(name="CODIGORESPUESTA")
	private ResponseCode responseCode;

	/**
	 * Fecha en la que se inició la transacción.
	 */
	@Temporal(TemporalType.TIMESTAMP)
	@Column(name="FECHATRANSACCION")
	private Date transactionDate;

	/**
	 * Referencia de pago que envia el comercio.
	 */
	@Column(name="NUMEROORDEN")
	private String orderNumber;

	/**
	 * Valor total de la transacción.
	 */
	@Column(name="VALORTOTAL")
	private BigDecimal totalValue;

	/**
	 * Valor del impuesto de la transacción.
	 */
	@Column(name="VALORIMPUESTO")
	private BigDecimal taxValue;

	/**
	 * Código de la moneda usada para la transacción. (Currency code).
	 */
	@Column(name="MONEDA")
	private String currency;

	/**
	 * Descripción de la transacción.
	 */
	@Column(name="DESCRIPCION")
	private String description;

	/**
	 * Número de aprobación del pago de la transacción para AVAL y RBM.
	 */
	@Column(name="NUMEROAPROBACION")
	private String approvalNumber;

	/**
	 * Fecha de pago de la transacción.
	 */
	@Temporal(TemporalType.TIMESTAMP)
	@Column(name="FECHAPAGO")
	private Date payDate;

	/**
	 * Fecha en que se hace efectiva la compensación del pago de la transacción.
	 */
	@Temporal(TemporalType.TIMESTAMP)
	@Column(name="FECHACOMPENSACION")
	private Date compensationDate;
	
	/**
	 * Indicador del tipo de persona (0 Natural, 1 Jurídica).
	 */
	@Column(name="IDTIPOPERSONA")
	private Integer customerType;

	/**
	 * Tipo de documento del comprador que generó la transacción.
	 */
	@Column(name="TIPODOCUMENTOCOMPRADOR")
	private String customerDocType;
	
	/**
	 * Número de documento del comprador que generó la transacción.
	 */
	@Column(name="NUMERODOCUMENTOCOMPRADOR")
	private String customerDocId;

	/**
	 * Nombre del comprador que generó la transacción.
	 */
	@Column(name="NOMBRECOMPRADOR")
	private String customerName;
	
	/**
	 * Correo electrónico del comprador que generó la transacción.
	 */
	@Column(name="CORREOCOMPRADOR")
	private String customerEmail;

	/**
	 * Número de celular del comprador que generó la transacción.
	 */
	@Column(name="NROCELULARCOMPRADOR")
	private String customerMobileNumber;

	/**
	 * Referencia 1 adicional en la transacción
	 */
	@Column(name="REFERENCIA1")
	private String reference1;

	/**
	 * Referencia 2 adicional en la transacción
	 */
	@Column(name="REFERENCIA2")
	private String reference2;

	/**
	 * Referencia 3 adicional en la transacción
	 */
	@Column(name="REFERENCIA3")
	private String reference3;
	
	/**
	 * Id de bloqueo de job.
	 */
	@Column(name="IDBLOQUEOJOB")
	private Long jobLockId;

	/**
	 * Indica si el registro tiene marca lógica de borrado
	 */
	@Column(name="REGELIMINADO", nullable=true)
	private boolean rowDeleted;
	
	/**
	 * Fecha de creación del registro
	 */
	@Temporal(TemporalType.TIMESTAMP)
	@Column(name="REGFECHACREACION", nullable=true)
	private Date rowCreationDate;
	
	/**
	 * Fecha de última modificación del registro
	 */
	@Temporal(TemporalType.TIMESTAMP)
	@Column(name="REGFECHAMODIFICACION", nullable=true)
	private Date rowLastUpdate;
	
	/**
	 * Identificador de la transacción D.V.
	 */
	@Column(name="PMTID", unique=true, scale=22, precision=0)
	private Long pmtId;
	
	/**
	 * Nombre compañía del pagador.
	 */
	@Column(name="COMPANIAPAGADOR")
	private String payerCompany;
	
	/**
	 * Nombre del pagador.
	 */
	@Column(name="NOMBREPAGADOR")
	private String payerName;
	
	/**
	 * Nombre alias pagador.
	 */
	@Column(name="ALIASPAGADOR")
	private String payerNickName;
	
	/**
	 * Tipo de documento del pagador.
	 */
	@Column(name="TIPODOCUMENTOPAGADOR")
	private String payerDocType;
	
	/**
	 * Número de documento del pagador.
	 */
	@Column(name="NUMERODOCUMENTOPAGADOR")
	private String payerDocId;
	
	/**
	 * Género del pagador.
	 */
	@Column(name="GENEROPAGADOR")
	private String payerGender;
	
	/**
	 * Fecha de nacimiento del pagador.
	 */
	@Temporal(TemporalType.TIMESTAMP)
	@Column(name="FECHANACIMIENTOPAGADOR")
	private Date payerBirthDate;
	
	/**
	 * Ciudad de nacimiento del pagador.
	 */
	@Column(name="CIUDADPAGADOR")
	private String payerCity;
	
	/**
	 * Departamento de nacimiento del pagador.
	 */
	@Column(name="DEPARTAMENTOPAGADOR")
	private String payerDepartment;
	
	/**
	 * País de nacimiento del pagador.
	 */
	@Column(name="PAISPAGADOR")
	private String payerCounty;
	
	/**
	 * Dirección del pagador.
	 */
	@Column(name="DIRECCIONPAGADOR")
	private String payerAddress;
	
	/**
	 * Mail del pagador.
	 */
	@Column(name="CORREOPAGADOR")
	private String payerMail;
	
	/**
	 * Telefono del pagador.
	 */
	@Column(name="TELEFONOPAGADOR")
	private String payerPhone;

	/**
	 * Id de la franquicia.
	 */
	@Column(name="IDBRAND")
	private BigDecimal idBrand;
	
	/**
	 * Numero de la tarjeta de credito.
	 */
	@Column(name="NUMEROTARJETACREDITO")
	private String creditCardNumber;
	
	/**
	 * Url de respuesta.
	 */
	@Column(name="URLRESPUESTA")
	private String urlResponse;

	/**
	 * Tipo de transaccion.
	 */
	@Column(name="TIPOTRANSACCION")
	private String trnType;
	
	/**
	 * Referencia 2 de pago.
	 */
	@Column(name="REFERENCIAPAGO2")
	private String invoiceReferen2;
	
	/**
	 * Referencia 3 de pago.
	 */
	@Column(name="REFERENCIAPAGO3")
	private String invoiceReferen3;
	
	/**
	 * Referencia 4 de pago.
	 */
	@Column(name="REFERENCIAPAGO4")
	private String invoiceReferen4;
	
	/**
	 * Intención de pago.
	 */
	@Column(name="INTENCIONPAGO")
	private String categoryId;
	
	/**
	 * Tipo de pago.
	 */
	@Column(name="TIPOPAGO")
	private String pmtType;
	
	/**
	 * Canal de la transaccion.
	 */
	@Column(name="CANAL")
	private String trnChannel;
	
	/**
	 * Trm.
	 */ 
	@Column(name="TRM")
	private String trm;
	
	/**
	 * Ciclo de la transacción para PSE.
	 */
	@Column(name="CICLOTRANSACCION")
	private String trnCycle;
	
	/**
	 * Ciclo de la transacción para PSE.
	 */
	@Column(name="MONEDATRM")
	private String curCodeTrm;
	
	/**
	 * Rquid de RBM.
	 */
	@Column(name="RQUID")
	private String rquId;
	
	/**
* Segundo Nombre del comprador que generó la transacción.
	 */
	@Column(name="SEGUNDONOMBRECOMPRADOR")
	private String middleNameBuyer;
	
	/**
	 * Primer Apellido del comprador que generó la transacción.
	 */
	@Column(name="PRIMERAPELLIDOCOMPRADOR")
	private String lastNameBuyer;
	
	/**
	 * Segundo Apellido del comprador que generó la transacción.
	 */
	@Column(name="SEGUNDOAPELLIDOCOMPRADOR")
	private String secondLastNameBuyer;
	
	/**
	 * Segundo Nombre del pagador que generó la transacción.
	 */
	@Column(name="SEGUNDONOMBREPAGADOR")
	private String middleNamePayer;
	
	/**
	 * Primer Apellido del pagador que generó la transacción.
	 */
	@Column(name="PRIMERAPELLIDOPAGADOR")
	private String lastNamePayer;
	
	/**
	 * Segundo Apellido del pagador que generó la transacción.
	 */
	@Column(name="SEGUNDOAPELLIDOPAGADOR")
	private String secondLastNamePayer;
	
	/**
	 * Flag envío de correo electrónico (0 No enviado, 1 Enviado).
	 */
	@Column(name="FLAGCORREO")
	private Integer emailflag;
	
	/**
	 * Flag envío de correo electrónico (0 No enviado, 1 Enviado).
	 */
	@Column(name="FLAGCORREOPROMO")
	private Integer emailflagprom;
	
	

	/**
	 * Flag indicador Si aplica Taquillas para la transaccion, Ventanilla de pagos
	 */
	@Column(name="PLANTILLA")
	private Integer plantilla;

	/**
	 * Url del logo para taquillas, Ventanilla de pagos
	 */
	@Lob
	@Column(name="URLLOGO")
	private byte[] urlLogo;
	
	/**
	 * Identificador de la taquilla a aplicar, Ventanilla de pagos
	 */
	@OneToOne(fetch=FetchType.EAGER)
	@JoinColumn(name="IDTAQUILLAS")
	private Taquilla taquilla;
	
	/**
	 * Referencia BBOG, indica el id del tipo de documento del dueño de la referencia de pago
	 */
	@Column(name="IDTYPEDOC")
	private String idTypeDoc;
	
	/**
	 * Referencia BBOG, indica el numero de documento del dueño de la referencia de pago 
	 */
	@Column(name="NUMDOC")
	private String numDoc;
	
	/** INICIO-C01 **/
	/**
	 *  Número tokenizado de tarjeta de crédito referenciada en la transacción.
	 */
	@Column(name="TOKENIZADO")
	private String tokenized;
	/** FIN-C01 **/
	
	/**INICIO-C02**/
	/*
	 * Numero de la Cuenta de recaudo para los pagos PSE.
	 */
	@Column(name="CUENTADERECAUDO")
	private String collectAcount;
	/**FIN-C02**/
	
	/**INICIO-C03**/
	/**
	 * Indica si el registro tiene marca lógica de borrado
	 */
	@Column(name="GLOBALPAY")
	private Boolean globalPay;
	/**FIN-C03**/
	
	/**
	 * Flag envío notificacion a portal de pagos (0 No enviado, 1 Enviado).
	 */
	@Column(name="NOTIFICACIONPORTALPAGOS")
	private Integer notificacionPPagos;
	
	/**	
	 * Modalidad de pago, identifica una transaccion con QR	
	 */	
	@Column(name="MODALIDAD_PAGO")	
	private String modalidadPago;	
	
	/**
	 * Flag  de repeticiones expiradas.
	 */
	@Column(name="FLAGEXPIRED")
	private Integer flagExpired;

	/**
	 * Construye una transacción.
	 */
	Transaction(){
		super();
	}
	
	/**
	 * Retorna el identificador de la transacción en el Core de la Pasarela de
	 * Pagos.
	 * 
	 * @return Identificador de la transacción.
	 */
	public Long getId(){
		return id;
	}

	/**
	 * Retorna el identificador de la transacción en el Core de la Pasarela de
	 * Pagos.
	 * 
	 * @param id Identificador de la transacción.
	 */
	public void setId(Long id){
		this.id = id;
	}

	/**
	 * Retorna el comercio beneficiario del pago.
	 * 
	 * @return Comercio involucrado.
	 */
	public Commerce getCommerce(){
		return commerce;
	}

	/**
	 * Establece el comercio beneficiario del pago.
	 * 
	 * @param commerce Comercio involucrado.
	 */
	public void setCommerce(Commerce commerce){
		this.commerce = commerce;
	}

	/**
	 * Retorna el estado de la transacción.
	 * 
	 * @return Estado de la transacción.
	 */
	public TransactionStatus getStatus(){
		return status;
	}

	/**
	 * Establece el estado de la transacción.
	 * 
	 * @param status Estado de la transacción.
	 */
	public void setStatus(TransactionStatus status){
		this.status = status;
	}

	/**
	 * Retorna el tipo de transacción.
	 * 
	 * @return Tipo de transacción.
	 */
	public TransactionType getTransactionType(){
		return transactionType;
	}

	/**
	 * Establece el tipo de transacción.
	 * 
	 * @param transactionType Tipo de transacción.
	 */
	public void setTransactionType(TransactionType transactionType){
		this.transactionType = transactionType;
	}

	/**
	 * Retorna el origen de la transacción.
	 * 
	 * @return Origen de la transacción.
	 */
	public TransactionSource getSource(){
		return source;
	}

	/**
	 * Establece el origen de la transacción.
	 * 
	 * @param source Origen de la transacción.
	 */
	public void setTransactionSource(TransactionSource source){
		this.source = source;
	}

	/**
	 * Retorna el medio de pago de la transacción.
	 * 
	 * @return Medio de pago.
	 */
	public PaymentWay getPaymentWay(){
		return PaymentWay;
	}

	/**
	 * Establece el medio de pago de la transacción.
	 * 
	 * @param paymentWay Medio de pago.
	 */
	public void setPaymentWay(PaymentWay paymentWay){
		PaymentWay = paymentWay;
	}

	/**
	 * Retorna el tipo de producto financiero usado para el pago.
	 * 
	 * @return Tipo de producto.
	 */
	public ProductType getProductType(){
		return productType;
	}

	/**
	 * Establece el tipo de producto financiero usado para el pago.
	 * 
	 * @param productType Tipo de producto.
	 */
	public void setProductType(ProductType productType){
		this.productType = productType;
	}

	/**
	 * Retorna la tarjeta de crédito asociada a la transacción.
	 * 
	 * @return Tarjeta de crédito asociada a la transacción.
	 */
	public CreditCard getCreditCard(){
		return creditCard;
	}

	/**
	 * Establece la tarjeta de crédito asociada a la transacción.
	 * 
	 * @param creditCard Tarjeta de crédito asociada a la transacción.
	 */
	public void setCreditCard(CreditCard creditCard){
		this.creditCard = creditCard;
	}

	/**
	 * Retorna el código de trazabilidad con redes externas (ACH, Redeban, etc).
	 * 
	 * @return Código de trazabilidad con redes externas.
	 */
	public String getTrazabilityCode(){
		return trazabilityCode;
	}

	/**
	 * Establece el código de trazabilidad con redes externas 
	 * (ACH, Redeban, etc).
	 * 
	 * @param trazabilityCode Código de trazabilidad con redes externas..
	 */
	public void setTrazabilityCode(String trazabilityCode){
		this.trazabilityCode = trazabilityCode;
	}

	/**
	 * Retorna el Banco autorizador del pago de la transacción. Este campo se 
	 * usa únicamente con pagos AVAL y PSE.
	 *  
	 * @return  Banco autorizador del pago.
	 */
	public Bank getBank(){
		return bank;
	}

	/**
	 * Establece el Banco autorizador del pago de la transacción. Este campo se 
	 * usa únicamente con pagos AVAL y PSE.
	 * 
	 * @param bank Banco atorizador del pago.
	 */
	public void setBank(Bank bank){
		this.bank = bank;
	}
	/**
	 * Retorna el Banco recaudador del pago de la transacción.
	 *  
	 * @return  Banco recaudador del pago.
	 */
	public Bank getBankCollecter(){
		return bankCollecter;
	}

	/**
	 * Establece el Banco racaudador del pago de la transacción.
	 * 
	 * @param bank Banco recaudador del pago.
	 */
	public void setBankCollecter(Bank bankCollecter){
		this.bankCollecter = bankCollecter;
	}

	/**
	 * Retorna la dirección IP relacionada con la transacción.
	 * 
	 * @return Dirección IP relacionada.
	 */
	public String getIpAddress(){
		return ipAddress;
	}

	/**
	 * Establece la dirección IP relacionada con la transacción.
	 * 
	 * @param ipAddress Dirección IP relacionada.
	 */
	public void setIpAddress(String ipAddress){
		this.ipAddress = ipAddress;
	}

	/**
	 * Retorna el código de respuesta emitido por los servicios de pago.
	 * 
	 * @return Código de respuesta de los servicios de pago.
	 */
	public ResponseCode getResponseCode(){
		return responseCode;
	}

	/**
	 * Establece el código de respuesta emitido por los servicios de pago.
	 * 
	 * @param responseCode Código de respuesta de los servicios de pago.
	 */
	public void setResponseCode(ResponseCode responseCode){
		this.responseCode = responseCode;
	}

	/**
	 * Retorna la fecha en la que se inició la transacción.
	 * 
	 * @return Fecha en la que se inició la transacción.
	 */
	public Date getTransactionDate(){
		return transactionDate;
	}

	/**
	 * Establede la fecha en la que se inició la transacción.
	 * @param transactionDate Fecha en la que se inició la transacción.
	 */
	public void setTransactionDate(Date transactionDate){
		this.transactionDate = transactionDate;
	}

	/**
	 * Retorna la referencia de pago que envia el comercio.
	 * 
	 * @return La referencia de pago que envia el comercio.
	 */
	public String getOrderNumber(){
		return orderNumber;
	}

	/**
	 * Establece la referencia de pago que envia el comercio.
	 * 
	 * @param orderNumber Referencia de pago.
	 */
	public void setOrderNumber(String orderNumber){
		this.orderNumber = orderNumber;
	}

	/**
	 * Retorna el valor total de la transacción.
	 * 
	 * @return Valor total de la transacción.
	 */
	public BigDecimal getTotalValue(){
		return totalValue;
	}

	/**
	 * Establece el valor total de la transacción.
	 * 
	 * @param totalValue Valor total de la transacción.
	 */
	public void setTotalValue(BigDecimal totalValue){
		this.totalValue = totalValue;
	}

	/**
	 * Retorna el valor del impuesto de la transacción.
	 * 
	 * @return Valor del impuesto de la transacción.
	 */
	public BigDecimal getTaxValue(){
		return taxValue;
	}

	/**
	 * Establece el valor del impuesto de la transacción.
	 * 
	 * @param taxValue Valor del impuesto.
	 */
	public void setTaxValue(BigDecimal taxValue){
		this.taxValue = taxValue;
	}

	/**
	 * Retorna el código de la moneda usada en la transacción. (Currency code).
	 * 
	 * @return Código de la moneda usada.
	 */
	public String getCurrency(){
		return currency;
	}

	/**
	 * Establece el código de la moneda usada en la transacción. 
	 * (Currency code).
	 * 
	 * @param currency Código de la moneda usada.
	 */
	public void setCurrency(String currency){
		this.currency = currency;
	}

	/**
	 * Retorna la descripción de la transacción.
	 * 
	 * @return Descripción de la transacción.
	 */
	public String getDescription(){
		return description;
	}

	/**
	 * Retorna la descripción de la transacción.
	 * 
	 * @param description Descripción de la transacción.
	 */
	public void setDescription(String description){
		this.description = description;
	}

	/**
	 * Retorna el número de aprobación del pago de la transacción para AVAL y
	 * RBM.
	 * 
	 * @return Número de aprobación del pago.
	 */
	public String getApprovalNumber(){
		return approvalNumber;
	}

	/**
	 * Establece el número de aprobación del pago de la transacción para AVAL y
	 * RBM.
	 * 
	 * @param approvalNumber Número de aprobación del pago.
	 */
	public void setApprovalNumber(String approvalNumber){
		this.approvalNumber = approvalNumber;
	}

	/**
	 * Retorna la fecha de pago de la transacción.
	 * 
	 * @return Fecha de pago de la transacción.
	 */
	public Date getPayDate(){
		return payDate;
	}

	/**
	 * Establece la fecha de pago de la transacción.
	 * 
	 * @param payDate Fecha de pago de la transacción.
	 */
	public void setPayDate(Date payDate){
		this.payDate = payDate;
	}

	/**
	 * Retorna la fecha en que se hace efectiva la compensación del pago de la 
	 * transacción.
	 * 
	 * @return Fecha de compensación.
	 */
	public Date getCompensationDate(){
		return compensationDate;
	}

	/**
	 * Establece la fecha en que se hace efectiva la compensación del pago de la 
	 * transacción.
	 * 
	 * @param compensationDate Fecha de compensación.
	 */
	public void setCompensationDate(Date compensationDate){
		this.compensationDate = compensationDate;
	}

	/**
	 * Retorna el tipo de cliente (0 Natural, 1 Jurídica).
	 * 
	 * @return Tipo de cliente.
	 */
	public Integer getCustomerType(){
		return customerType;
	}

	/**
	 * Establece el tipo de cliente (0 Natural, 1 Jurídica).
	 * 
	 * @param customerType Tipo de cliente.
	 */
	public void setCustomerType(Integer customerType){
		this.customerType = customerType;
	}

	/**
	 * Retorna el tipo de documento del comprador que generó la transacción.
	 * @return Tipo de documento del comprador.
	 */
	public String getCustomerDocType(){
		return customerDocType;
	}

	/**
	 * Establece el tipo de documento del comprador que generó la transacción.
	 * 
	 * @param customerDocType Tipo de documento del comprador.
	 */
	public void setCustomerDocType(String customerDocType){
		this.customerDocType = customerDocType;
	}

	/**
	 * Retorna el número de documento del comprador que generó la transacción.
	 * 
	 * @return Número de documento del comprador.
	 */
	public String getCustomerDocId(){
		return customerDocId;
	}

	/**
	 * Establece el número de documento del comprador que generó la transacción.
	 * 
	 * @param customerDocId Número de documento del comprador.
	 */
	public void setCustomerDocId(String customerDocId){
		this.customerDocId = customerDocId;
	}

	/**
	 * Retorna el nombre del comprador que generó la transacción.
	 * 
	 * @return Nombre del comprador.
	 */
	public String getCustomerName(){
		return customerName;
	}

	/**
	 * Establece el nombre del comprador que generó la transacción.
	 * 
	 * @param customerName Nombre del comprador.
	 */
	public void setCustomerName(String customerName){
		this.customerName = customerName;
	}

	/**
	 * Retorna la dirección de correo electrónico del comprador que generó la 
	 * transacción.
	 * 
	 * @return Correo electrónico del comprador.
	 */
	public String getCustomerEmail(){
		return customerEmail;
	}

	/**
	 * Establece la dirección de correo electrónico del comprador que generó la 
	 * transacción.
	 * 
	 * @param customerEmail Correo electrónico del comprador.
	 */
	public void setCustomerEmail(String customerEmail){
		this.customerEmail = customerEmail;
	}

	/**
	 * Retorna el número de celular del comprador que generó la transacción.
	 * 
	 * @return Número celular del comprador.
	 */
	public String getCustomerMobileNumber(){
		return customerMobileNumber;
	}

	/**
	 * Establece el número de celular del comprador que generó la transacción.
	 * 
	 * @param customerMobileNumber Número celular del comprador.
	 */
	public void setCustomerMobileNumber(String customerMobileNumber){
		this.customerMobileNumber = customerMobileNumber;
	}

	/**
	 * Retorna la primera referencia adicional relacionada con la transacción.
	 * 
	 * @return Primera referencia adicional.
	 */
	public String getReference1(){
		return reference1;
	}

	/**
	 * Establece la primera referencia adicional relacionada con la transacción.
	 * 
	 * @param reference1 Primera referencia adicional.
	 */
	public void setReference1(String reference1){
		this.reference1 = reference1;
	}

	/**
	 * Retorna la segunda referencia adicional relacionada con la transacción.
	 * 
	 * @return Segunda referencia adicional.
	 */
	public String getReference2(){
		return reference2;
	}

	/**
	 * Establece la segunda referencia adicional relacionada con la transacción.
	 * 
	 * @param reference2 Segunda referencia adicional.
	 */
	public void setReference2(String reference2){
		this.reference2 = reference2;
	}

	/**
	 * Retorna la tercera referencia adicional relacionada con la transacción.
	 * @return Tercera referencia adicional.
	 */
	public String getReference3(){
		return reference3;
	}

	/**
	 * Establece la tercera referencia adicional relacionada con la transacción.
	 * 
	 * @param reference3 Tercera referencia adicional.
	 */
	public void setReference3(String reference3){
		this.reference3 = reference3;
	}

	/**
	 * Método encargado de recuperar el valor del atributo jobLockId.
	 * @return El atributo jobLockId asociado a la clase.
	 */
	public Long getJobLockId() {
		return jobLockId;
	}

	/**
	 * Método encargado de actualizar el atributo jobLockId.
	 * @param jobLockId Nuevo valor para jobLockId.
	 */
	public void setJobLockId(Long jobLockId) {
		this.jobLockId = jobLockId;
	}

	/**
	 * Retorna el identificador de la transacción en el Core de la Pasarela de
	 * Pagos.
	 * 
	 * @return Identificador de la transacción.
	 */
	public Long getPmtId(){
		return pmtId;
	}

	/**
	 * Retorna el identificador de la transacción en el Core de la Pasarela de
	 * Pagos.
	 * 
	 * @param pmtId Identificador de la transacción.
	 */
	public void setPmtId(Long pmtId){
		this.pmtId = pmtId;
	}
	

	@Override
	public boolean isRowDeleted(){
		return rowDeleted;
	}

	@Override
	public void setRowDeleted(boolean rowDeleted){
		this.rowDeleted = rowDeleted;
		
	}

	@Override
	public Date getRowCreationDate(){
		return rowCreationDate;
	}

	@Override
	public void setRowCreationDate(Date rowCreationDate){
		this.rowCreationDate = rowCreationDate;
	}

	@Override
	public Date getRowLastUpdate(){
		return rowLastUpdate;
	}

	@Override
	public void setRowLastUpdate(Date rowLastUpdate){
		this.rowLastUpdate = rowLastUpdate;
	}

	@Override
	public int hashCode(){
		final int prime = 31;
		int result = 1;
		result = prime * result + (int) (id ^ (id >>> 32));
		return result;
	}

	@Override
	public boolean equals(Object obj){
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Transaction other = (Transaction) obj;
		if (id != other.id)
			return false;
		return true;
	}

	@Override
	public String toString() {
		return "Transaction [id=" + id + ", commerce=" + commerce + ", status="
				+ status + ", transactionType=" + transactionType + ", source="
				+ source + ", PaymentWay=" + PaymentWay + ", productType="
				+ productType + ", creditCard=" + creditCard
				+ ", trazabilityCode=" + trazabilityCode + ", bank=" + bank + ", bankCollecter=" + bankCollecter
				+ ", ipAddress=" + ipAddress + ", responseCode=" + responseCode
				+ ", transactionDate=" + transactionDate + ", orderNumber="
				+ orderNumber + ", totalValue=" + totalValue + ", taxValue="
				+ taxValue + ", currency=" + currency + ", description="
				+ description + ", approvalNumber=" + approvalNumber
				+ ", payDate=" + payDate + ", compensationDate="
				+ compensationDate + ", customerType=" + customerType
				+ ", customerDocType=" + customerDocType + ", customerDocId="
				+ customerDocId + ", customerName=" + customerName
				+ ", customerEmail=" + customerEmail
				+ ", customerMobileNumber=" + customerMobileNumber
				+ ", reference1=" + reference1 + ", reference2=" + reference2
				+ ", reference3=" + reference3 + ", jobLockId=" + jobLockId
				+ ", rowDeleted=" + rowDeleted + ", rowCreationDate="
				+ rowCreationDate + ", rowLastUpdate=" + rowLastUpdate
				+ ", pmtId=" + pmtId + ", payerCompany=" + payerCompany
				+ ", payerName=" + payerName + ", payerNickName="
				+ payerNickName + ", payerDocType=" + payerDocType
				+ ", payerDocId=" + payerDocId + ", payerGender=" + payerGender
				+ ", payerBirthDate=" + payerBirthDate + ", payerCity="
				+ payerCity + ", payerDepartment=" + payerDepartment
				+ ", payerCounty=" + payerCounty + ", payerAddress="
				+ payerAddress + ", payerMail=" + payerMail + ", payerPhone="
				+ payerPhone + ", idBrand=" + idBrand + ", creditCardNumber="
				+ creditCardNumber + ", urlResponse=" + urlResponse
				+ ", trnType=" + trnType + ", invoiceReferen2="
				+ invoiceReferen2 + ", invoiceReferen3=" + invoiceReferen3
				+ ", invoiceReferen4=" + invoiceReferen4 + ", categoryId="
				+ categoryId + ", pmtType=" + pmtType + ", trnChannel="
				+ trnChannel + ", trm=" + trm + ", trnCycle=" + trnCycle
				+ ", curCodeTrm=" + curCodeTrm + ", rquId=" + rquId
				+ ", middleNameBuyer=" + middleNameBuyer + ", lastNameBuyer="
				+ lastNameBuyer + ", secondLastNameBuyer="
				+ secondLastNameBuyer + ", middleNamePayer=" + middleNamePayer
				+ ", lastNamePayer=" + lastNamePayer + ", secondLastNamePayer="
				+ secondLastNamePayer + ", emailflag=" + emailflag
				+ ", plantilla=" + plantilla + ", urlLogo="
				+ Arrays.toString(urlLogo) + ", taquilla=" + taquilla
				+ ", idTypeDoc=" + idTypeDoc + ", numDoc=" + numDoc + "]";
	}

	/**
	 * Método encargado de recuperar el valor del atributo payerCompany.
	 * @return El atributo payerCompany asociado a la clase payerCompany.
	 */
	public String getPayerCompany() {
		return payerCompany;
	}

	/**
	 * Método encargado de actualizar el atributo payerCompany.
	 * @param payerCompany Nuevo valor para payerCompany.
	 */
	public void setPayerCompany(String payerCompany) {
		this.payerCompany = payerCompany;
	}

	/**
	 * Método encargado de recuperar el valor del atributo payerName.
	 * @return El atributo jobLockId asociado a la clase payerName.
	 */
	public String getPayerName() {
		return payerName;
	}

	/**
	 * Método encargado de actualizar el atributo payerName.
	 * @param payerName Nuevo valor para .
	 */
	public void setPayerName(String payerName) {
		this.payerName = payerName;
	}

	/**
	 * Método encargado de recuperar el valor del atributo payerNickName.
	 * @return El atributo payerNickName asociado a la clase.
	 */
	public String getPayerNickName() {
		return payerNickName;
	}

	/**
	 * Método encargado de actualizar el atributo payerNickName.
	 * @param payerNickName Nuevo valor para payerNickName.
	 */
	public void setPayerNickName(String payerNickName) {
		this.payerNickName = payerNickName;
	}

	/**
	 * Método encargado de recuperar el valor del atributo payerDocType.
	 * @return El atributo jobLockId asociado a la clase payerDocType.
	 */
	public String getPayerDocType() {
		return payerDocType;
	}

	/**
	 * Método encargado de actualizar el atributo payerDocType.
	 * @param payerDocType Nuevo valor para payerDocType.
	 */
	public void setPayerDocType(String payerDocType) {
		this.payerDocType = payerDocType;
	}

	/**
	 * Método encargado de recuperar el valor del atributo payerDocId.
	 * @return El atributo payerDocId asociado a la clase.
	 */
	public String getPayerDocId() {
		return payerDocId;
	}

	/**
	 * Método encargado de actualizar el atributo payerDocId.
	 * @param payerDocId Nuevo valor para payerDocId.
	 */
	public void setPayerDocId(String payerDocId) {
		this.payerDocId = payerDocId;
	}

	/**
	 * Método encargado de recuperar el valor del atributo payerGender.
	 * @return El atributo payerGender asociado a la clase.
	 */
	public String getPayerGender() {
		return payerGender;
	}

	/**
	 * Método encargado de actualizar el atributo payerGender.
	 * @param payerGender Nuevo valor para payerGender.
	 */
	public void setPayerGender(String payerGender) {
		this.payerGender = payerGender;
	}

	/**
	 * Método encargado de recuperar el valor del atributo payerBirthDate.
	 * @return El atributo payerBirthDate asociado a la clase.
	 */
	public Date getPayerBirthDate() {
		return payerBirthDate;
	}

	/**
	 * Método encargado de actualizar el atributo payerBirthDate.
	 * @param payerBirthDate Nuevo valor para payerBirthDate.
	 */
	public void setPayerBirthDate(Date payerBirthDate) {
		this.payerBirthDate = payerBirthDate;
	}

	/**
	 * Método encargado de recuperar el valor del atributo payerCity.
	 * @return El atributo payerCity asociado a la clase.
	 */
	public String getPayerCity() {
		return payerCity;
	}

	/**
	 * Método encargado de actualizar el atributo payerCity.
	 * @param payerCity Nuevo valor para payerCity.
	 */
	public void setPayerCity(String payerCity) {
		this.payerCity = payerCity;
	}

	/**
	 * Método encargado de recuperar el valor del atributo payerDepartment.
	 * @return El atributo payerDepartment asociado a la clase.
	 */
	public String getPayerDepartment() {
		return payerDepartment;
	}

	/**
	 * Método encargado de actualizar el atributo payerDepartment.
	 * @param payerDepartment Nuevo valor para payerDepartment.
	 */
	public void setPayerDepartment(String payerDepartment) {
		this.payerDepartment = payerDepartment;
	}

	/**
	 * Método encargado de recuperar el valor del atributo payerCounty.
	 * @return El atributo payerCounty asociado a la clase.
	 */
	public String getPayerCounty() {
		return payerCounty;
	}

	/**
	 * Método encargado de actualizar el atributo payerCounty.
	 * @param payerCounty Nuevo valor para payerCounty.
	 */
	public void setPayerCounty(String payerCounty) {
		this.payerCounty = payerCounty;
	}

	/**
	 * Método encargado de recuperar el valor del atributo payerAddress.
	 * @return El atributo payerAddress asociado a la clase.
	 */
	public String getPayerAddress() {
		return payerAddress;
	}

	/**
	 * Método encargado de actualizar el atributo payerAddress.
	 * @param payerAddress Nuevo valor para payerAddress.
	 */
	public void setPayerAddress(String payerAddress) {
		this.payerAddress = payerAddress;
	}

	/**
	 * Método encargado de recuperar el valor del atributo payerMail.
	 * @return El atributo payerMail asociado a la clase.
	 */
	public String getPayerMail() {
		return payerMail;
	}

	/**
	 * Método encargado de actualizar el atributo payerMail.
	 * @param payerMail Nuevo valor para payerMail.
	 */
	public void setPayerMail(String payerMail) {
		this.payerMail = payerMail;
	}

	/**
	 * Método encargado de recuperar el valor del atributo payerPhone.
	 * @return El atributo payerPhone asociado a la clase.
	 */
	public String getPayerPhone() {
		return payerPhone;
	}

	/**
	 * Método encargado de actualizar el atributo payerPhone.
	 * @param payerPhone Nuevo valor para payerPhone.
	 */
	public void setPayerPhone(String payerPhone) {
		this.payerPhone = payerPhone;
	}

	/**
	 * Método encargado de recuperar el valor del tipo idBrand
	 * @return El atributo idBrand asociado a la clase.
	 */
	public BigDecimal getIdBrand() {
		return idBrand;
	}

	/**
	 * Método encargado de actualizar el atributo idBrand.
	 * @param idBrand Nuevo valor para idBrand.
	 */
	public void setIdBrand(BigDecimal idBrand) {
		this.idBrand = idBrand;
	}

	/**
	 * Método encargado de recuperar el valor del tipo creditCardNumber
	 * @return El atributo creditCardNumber asociado a la clase.
	 */
	public String getCreditCardNumber() {
		return creditCardNumber;
	}

	/**
	 * Método encargado de actualizar el atributo creditCardNumber.
	 * @param creditCardNumber Nuevo valor para creditCardNumber.
	 */
	public void setCreditCardNumber(String creditCardNumber) {
		this.creditCardNumber = creditCardNumber;
	}
	
	/**
	 * Retorna la url de respuesta.
	 * 
	 * @return Url de respuesta.
	 */
	public String getUrlResponse(){
		return urlResponse;
	}

	/**
	 * Método encargado de actualizar el atributo urlResponse.
	 * @param urlResponse Nuevo valor para urlResponse.
	 */
	public void setUrlResponse(String urlResponse){
		this.urlResponse = urlResponse;
	}
	
	/**
	 * Retorna el tipo de transaccion.
	 * 
	 * @return Tipo de transaccion de pago.
	 */
	public String getTrnType(){
		return trnType;
	}

	/**
	 * Método encargado de actualizar el atributo trnType.
	 * @param trnType nuevo valor para trnType.
	 */
	public void setTrnType(String trnType){
		this.trnType = trnType;
	}
	
	/**
	 * Retorna la referencia 2 de pago.
	 * 
	 * @return Referencia 2 de pago.
	 */
	public String getInvoiceReferen2(){
		return invoiceReferen2;
	}

	/**
	 * Método encargado de actualizar el atributo invoiceReferen2.
	 * @param invoiceReferen2 nuevo valor para invoiceReferen2.
	 */
	public void setInvoiceReferen2(String invoiceReferen2){
		this.invoiceReferen2 = invoiceReferen2;
	}
	
	/**
	 * Retorna la referencia 3 de pago.
	 * 
	 * @return Referencia 3 de pago.
	 */
	public String getInvoiceReferen3(){
		return invoiceReferen3;
	}

	/**
	 * Método encargado de actualizar el atributo invoiceReferen3.
	 * @param invoiceReferen3 nuevo valor para invoiceReferen3.
	 */
	public void setInvoiceReferen3(String invoiceReferen3){
		this.invoiceReferen3 = invoiceReferen3;
	}
	
	/**
	 * Retorna la referencia 4 de pago.
	 * 
	 * @return Referencia 4 de pago.
	 */
	public String getInvoiceReferen4(){
		return invoiceReferen4;
	}

	/**
	 * Método encargado de actualizar el atributo invoiceReferen4.
	 * @param invoiceReferen4 nuevo valor para invoiceReferen4.
	 */
	public void setInvoiceReferen4(String invoiceReferen4){
		this.invoiceReferen4 = invoiceReferen4;
	}
	
	/**
	 * Método encargado de actualizar el atributo categoryId.
	 * @param categoryId nuevo valor para categoryId.
	 */
	public void setCategoryId(String categoryId){
		this.categoryId = categoryId;
	}
	
	/**
	 * Retorna categoryId.
	 * 
	 * @return categoryId.
	 */
	public String getCategoryId(){
		return categoryId;
	}
	
	/**
	 * Método encargado de actualizar el atributo pmtType.
	 * @param pmtType nuevo valor para pmtType.
	 */
	public void setPmtType(String pmtType){
		this.pmtType = pmtType;
	}
	
	/**
	 * Retorna pmtType.
	 * 
	 * @return pmtType.
	 */
	public String getPmtType(){
		return pmtType;
	}
	
	/**
	 * Método encargado de actualizar el atributo trnChannel.
	 * @param trnChannel nuevo valor para trnChannel.
	 */
	public void setTrnChannel(String trnChannel){
		this.trnChannel = trnChannel;
	}
	
	/**
	 * Retorna trnChannel.
	 * 
	 * @return trnChannel.
	 */
	public String getTrnChannel(){
		return trnChannel;
	}
	
	/**
	 * Método encargado de actualizar el atributo trm.
	 * @param trm nuevo valor para trm.
	 */
	public void setTrm(String trm){
		this.trm = trm;
	}
	
	/**
	 * Retorna trm.
	 * 
	 * @return trm.
	 */
	public String getTrm(){
		return trm;
	}
	
	/**
	 * Método encargado de actualizar el atributo curCodeTrm.
	 * @param curCodeTrm nuevo valor para curCodeTrm.
	 */
	public void setCurCodeTrm(String curCodeTrm){
		this.curCodeTrm = curCodeTrm;
	}
	
	/**
	 * Retorna curCodeTrm.
	 * 
	 * @return curCodeTrm.
	 */
	public String getCurCodeTrm(){
		return curCodeTrm;
	}
	
	/**
	 * Método encargado de actualizar el atributo trnCycle.
	 * @param trnCycle nuevo valor para trnCycle.
	 */
	public void setTrnCycle(String trnCycle){
		this.trnCycle = trnCycle;
	}
	
	/**
	 * Retorna trnCycle.
	 * 
	 * @return trnCycle.
	 */
	public String getTrnCycle(){
		return trnCycle;
	}
	
	/**
	 * Método encargado de actualizar el atributo rquId.
	 * @param rquId nuevo valor para rquId.
	 */
	public void setRquId(String rquId){
		this.rquId = rquId;
	}
	
	/**
	 * Retorna rquId.
	 * 
	 * @return rquId.
	 */
	public String getRquId(){
		return rquId;
	}
	/**
	 * Retorna el segundo nombre del comprador que generó la transacción.
	 * 
	 * @return Segundo Nombre del comprador.
	 */
	public String getMiddleNameBuyer(){
		return middleNameBuyer;
	}

	/**
	 * Establece el segundo nombre del comprador que generó la transacción.
	 * 
	 * @param middleNameBuyer Segundo Nombre del comprador.
	 */
	public void setMiddleNameBuyer(String middleNameBuyer){
		this.middleNameBuyer = middleNameBuyer;
	}
	
	/**
	 * Retorna el primer apellido del comprador que generó la transacción.
	 * 
	 * @return Primer Apellido del comprador.
	 */
	public String getLastNameBuyer(){
		return lastNameBuyer;
	}

	/**
	 * Establece el primer apellido del comprador que generó la transacción.
	 * 
	 * @param lastNameBuyer Primer Apellido del comprador.
	 */
	public void setLastNameBuyer(String lastNameBuyer){
		this.lastNameBuyer = lastNameBuyer;
	}
	
	/**
	 * Retorna el segundo apellido del comprador que generó la transacción.
	 * 
	 * @return Segundo Apellido del comprador.
	 */
	public String getSecondLastNameBuyer(){
		return secondLastNameBuyer;
	}

	/**
	 * Establece el segundo apellido del comprador que generó la transacción.
	 * 
	 * @param secondLastNameBuyer Segundo Apellido del comprador.
	 */
	public void setSecondLastNameBuyer(String secondLastNameBuyer){
		this.secondLastNameBuyer = secondLastNameBuyer;
	}
	
	/**
	 * Retorna el segundo nombre del pagador que generó la transacción.
	 * 
	 * @return Segundo Nombre del pagador.
	 */
	public String getMiddleNamePayer(){
		return middleNamePayer;
	}

	/**
	 * Establece el segundo nombre del pagador que generó la transacción.
	 * 
	 * @param middleNamePayer Segundo Nombre del pagador.
	 */
	public void setMiddleNamePayer(String middleNamePayer){
		this.middleNamePayer = middleNamePayer;
	}
	
	/**
	 * Retorna el primer apellido del pagador que generó la transacción.
	 * 
	 * @return Primer Apellido del pagador.
	 */
	public String getLastNamePayer(){
		return lastNamePayer;
	}

	/**
	 * Establece el primer apellido del pagador que generó la transacción.
	 * 
	 * @param lastNamePayer Primer Apellido del pagador.
	 */
	public void setLastNamePayer(String lastNamePayer){
		this.lastNamePayer = lastNamePayer;
	}
	
	/**
	 * Retorna el segundo apellido del pagador que generó la transacción.
	 * 
	 * @return Segundo Apellido del pagador.
	 */
	public String getSecondLastNamePayer(){
		return secondLastNamePayer;
	}

	/**
	 * Establece el segundo apellido del pagador que generó la transacción.
	 * 
	 * @param secondLastNamePayer Segundo Apellido del pagador.
	 */
	public void setSecondLastNamePayer(String secondLastNamePayer){
		this.secondLastNamePayer = secondLastNamePayer;
	}

	/**
	 * Establece el Flag si el correo electrónico de la TX fue enviado
	 * 
	 * @param emailflag
	 */
	public Integer getEmailflag() {
		return emailflag;
	}

	public void setEmailflag(Integer emailflag) {
		this.emailflag = emailflag;
	}

	/**
	 * @return the plantilla
	 */
	public Integer getPlantilla() {
		return plantilla;
	}

	/**
	 * @param plantilla the plantilla to set
	 */
	public void setPlantilla(Integer plantilla) {
		this.plantilla = plantilla;
	}

	/**
	 * @return the idTypeDoc
	 */
	public String getIdTypeDoc() {
		return idTypeDoc;
	}

	/**
	 * @param idTypeDoc the idTypeDoc to set
	 */
	public void setIdTypeDoc(String idTypeDoc) {
		this.idTypeDoc = idTypeDoc;
	}

	/**
	 * @return the numDoc
	 */
	public String getNumDoc() {
		return numDoc;
	}

	/**
	 * @param numDoc the numDoc to set
	 */
	public void setNumDoc(String numDoc) {
		this.numDoc = numDoc;
	}
	
	/** INICIO-C01 **/
	/**
	 * @return the tokenized
	 */
	public String getTokenized() {
		return tokenized;
	}
	/** FIN-C01 **/
	
	
	/** INICIO-C01 **/
	/**
	 * @param tokenized the tokenized reference to set
	 */
	public void setTokenized(String tokenized) {
		this.tokenized = tokenized;
	}
	/** FIN-C01 **/
	
	
	public byte[] getUrlLogo() {
		return urlLogo;
	}

	public void setUrlLogo(byte[] urlLogo) {
		this.urlLogo = urlLogo;
	}

	public Taquilla getTaquilla() {
		return taquilla;
	}

	public void setTaquilla(Taquilla taquilla) {
		this.taquilla = taquilla;
	}

	public String getCollectAcount() {
		return collectAcount;
	}

	public void setCollectAcount(String collectAcount) {
		this.collectAcount = collectAcount;
	}
	
	/**INICIO-C03**/
	public Boolean isGlobalPay() {
		return globalPay;
	}

	public void setGlobalPay(Boolean globalPay) {
		this.globalPay = globalPay;
	}
	/**FIN-C03**/
	public Boolean isTermsAndConditions() {
		return termsAndConditions;
	}

	public void setTermsAndConditions(Boolean termsAndConditions) {
		this.termsAndConditions = termsAndConditions;
	}

	public Integer getNotificacionPPagos() {
		return notificacionPPagos;
	}

	public void setNotificacionPPagos(Integer notificacionPPagos) {
		this.notificacionPPagos = notificacionPPagos;
	}

	public final Integer getEmailflagprom() {
		return emailflagprom;
	}

	public final void setEmailflagprom(Integer emailflagprom) {
		this.emailflagprom = emailflagprom;
	}
	/**	
	 * @return	
	 */	
	public String getModalidadPago() {	
		return modalidadPago;	
	}	


	public void setModalidadPago(String modalidadPago) {	
		this.modalidadPago = modalidadPago;	
	}

	public Integer getFlagExpired() {
		return flagExpired;
	}

	public void setFlagExpired(Integer flagExpired) {
		this.flagExpired = flagExpired;
	}

}