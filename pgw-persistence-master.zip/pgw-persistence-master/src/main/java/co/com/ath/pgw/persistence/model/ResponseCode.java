/*
 * ResponseCodes
 *  
 * GSI - Integración
 * Creado el: 28/08/2014
 *
 * Copyright (c) A Toda Hora S.A. Todos los derechos reservados
 * 
 * Este software es confidencial y es propietario de ATH, queda prohibido
 * su uso, reproducción y copia de manera parcial o permanente salvo autorización
 * expresa de A Toda Hora S.A o de quién represente sus derechos.
 */
package co.com.ath.pgw.persistence.model;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import co.com.ath.pgw.persistence.PersistentObject;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

/**
 * Representa los códigos de respuesta de los servicios de pago. Esta entidad
 * pertenece al modelo persistente.
 * 
 * @author proveedor_japiza
 * @version 1.0 29 Ago 2014
 * @since
 */
@Entity
@Table(name="CODIGOSRESPUESTA")
public class ResponseCode implements PersistentObject {

	/**
	 * 
	 */
	private static final long serialVersionUID = -1163439229507845595L;

	/**
	 * Código de respuesta
	 */
	@Id
	@Column(name="CODIGORESPUESTA")
	private String code;

	/**
	 * Descripción del código de respuesta
	 */
	@Column(name="DESCRIPCION")
	private String description;

	/**
	 * Indica si el registro tiene marca lógica de borrado
	 */
	@Column(name="REGELIMINADO", nullable=true)
	private boolean rowDeleted;
	
	/**
	 * Fecha de creación del registro
	 */
	@Temporal(TemporalType.TIMESTAMP)
	@Column(name="REGFECHACREACION", nullable=true)
	private Date rowCreationDate;
	
	/**
	 * Fecha de última modificación del registro
	 */
	@Temporal(TemporalType.TIMESTAMP)
	@Column(name="REGFECHAMODIFICACION", nullable=true)
	private Date rowLastUpdate;

	/**
	 * Construye un código de respuesta.
	 */
	public ResponseCode(){
		super();
	}

	/**
	 * Retorna el código de respuesta.
	 * 
	 * @return Código de respuesta.
	 */
	public String getCode() {
		return code;
	}

	/**
	 * Establece el código de respuesta.
	 * 
	 * @param code Código de respuesta.
	 */
	public void setCode(String code) {
		this.code = code;
	}

	/**
	 * Retorna la descripción del código de respuesta.
	 * 
	 * @return Descripción del código de respuesta.
	 */
	public String getDescription() {
		return description;
	}

	/**
	 * Establece la descripción del código de respuesta.
	 * 
	 * @param description Descripción.
	 */
	public void setDescription(String description) {
		this.description = description;
	}

	@Override
	public boolean isRowDeleted() {
		return rowDeleted;
	}

	@Override
	public void setRowDeleted(boolean rowDeleted) {
		this.rowDeleted = rowDeleted;
		
	}

	@Override
	public Date getRowCreationDate() {
		return rowCreationDate;
	}

	@Override
	public void setRowCreationDate(Date rowCreationDate) {
		this.rowCreationDate = rowCreationDate;
	}

	@Override
	public Date getRowLastUpdate() {
		return rowLastUpdate;
	}

	@Override
	public void setRowLastUpdate(Date rowLastUpdate) {
		this.rowLastUpdate = rowLastUpdate;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result
				+ ((code == null) ? 0 : code.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		ResponseCode other = (ResponseCode) obj;
		if (code == null) {
			if (other.code != null)
				return false;
		} else if (!code.equals(other.code))
			return false;
		return true;
	}

	@Override
	public String toString() {
		return "ResponseCode [code=" + code + ", description="
				+ description + ", rowDeleted=" + rowDeleted + "]";
	}
	
}