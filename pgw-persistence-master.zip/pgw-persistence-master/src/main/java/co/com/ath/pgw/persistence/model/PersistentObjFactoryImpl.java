/*
 * PersistentObjFactoryImpl
 *
 * GSI - Integración
 * Creado el: 22 de agosto de 2014
 *
 * Copyright (c) A Toda Hora S.A. Todos los derechos reservados
 *
 * Este software es confidencial y es propietario de ATH, queda prohibido
 * su uso, reproducción y copia de manera parcial o permanente salvo autorización
 * expresa de A Toda Hora S.A o de quién represente sus derechos.
 */
package co.com.ath.pgw.persistence.model;

import org.springframework.stereotype.Service;

import co.com.ath.pgw.persistence.PersistentObjectFactory;

/**
 * Implementación por defecto de PersistentObjectFactory
 * @author proveedor_zagarcia
 * @version 1.0
 * @since 1.0
 */
@Service
public class PersistentObjFactoryImpl implements PersistentObjectFactory {

	public PersistentObjFactoryImpl(){
		super();
	}

	public Bank createBank() {
		return new Bank();
	}

	public Bank createBank(Long id) {
		return null;
	}

    public Brand createBrand() {
        return new Brand();
    }

    public CardHolder createCardHolder() {
        return new CardHolder();
    }

    public City createCity() {
        return new City();
    }

    public Commerce createCommerce() {
        return new Commerce();
    }

    public CommerceConfiguration createCommerceConfiguration() {
        return new CommerceConfiguration();
    }

    public CommerceContact createCommerceContact() {
        return new CommerceContact();
    }

    public CommerceRoleContact createCommerceRoleContact() {
        return new CommerceRoleContact();
    }

    public CreditCard createCreditCard() {
        return new CreditCard();
    }

    public Department createDepartment() {
        return new Department();
    }

    public Download createDownload() {
        return new Download();
    }

    public DownloadStatus createDownloadStatus() {
        return new DownloadStatus();
    }

    public PaymentWay createPaymentWay() {
        return new PaymentWay();
    }

    public ProductType createProductType() {
        return new ProductType();
    }

    public ReconciledTransaction createReconciledTransaction() {
        return new ReconciledTransaction();
    }

    public ResponseCodeForPaymentWay createResponseCodeForPaymentWay() {
        return new ResponseCodeForPaymentWay();
    }

    public ResponseCode createResponseCode() {
        return new ResponseCode();
    }

    public Subscription createSubscription() {
        return new Subscription();
    }

    public Template createTemplate() {
        return new Template();
    }

    public Theme createTheme() {
        return new Theme();
    }

    public Token createToken() {
        return new Token();
    }    
    
    public TransactionSource createTransactionSource() {
        return new TransactionSource();
    }

    public TransactionStatus createTransactionStatus() {
        return new TransactionStatus();
    }

    public TransactionType createTransactionType() {
        return new TransactionType();
    }

    public Transaction createTransaction() {
        return new Transaction();
    }

	public AVALFile createAVALFile() {
		return new AVALFile();
	}

	public AVALFileContent createAVALFileContent() {
		return new AVALFileContent();
	}

	public AVALFileDetail createAVALFileDetail() {
		return new AVALFileDetail();
	}

	public Taquilla createTaquilla() {
		return new Taquilla();
	}
	
	public NotificacionTecnica createNotificacionTecnica() {
		return new NotificacionTecnica();
	}

//	public NonWorkingDay createNonWorkingDay() {
//		return new NonWorkingDay();
//	}
}