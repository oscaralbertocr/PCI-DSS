/*
 * ThemeDAOImpl
 *  
 * GSI - Integración
 * Creado el: 29/08/2014
 *
 * Copyright (c) A Toda Hora S.A. Todos los derechos reservados
 * 
 * Este software es confidencial y es propietario de ATH, queda prohibido
 * su uso, reproducción y copia de manera parcial o permanente salvo autorización
 * expresa de A Toda Hora S.A o de quién represente sus derechos.
 */
package co.com.ath.pgw.persistence.dao.impl;

import javax.persistence.NoResultException;
import javax.persistence.NonUniqueResultException;
import javax.persistence.Query;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Repository;

import co.com.ath.pgw.persistence.AbstractDAO_JPA;
import co.com.ath.pgw.persistence.dao.TaquillaDAO;
import co.com.ath.pgw.persistence.model.Taquilla;

/**
 * Implementación por defecto de TaquillaDAO
 *
 * @author Camilo Andres Bustamante <proveedor_cbustamant@ath.com.co>
 * @version 1.0 22 Mar 2017
 * @since 1.0
 */
@Repository
public class TaquillaDAOImpl extends AbstractDAO_JPA<Taquilla> implements TaquillaDAO {
	
	static Logger LOGGER = LoggerFactory.getLogger(TaquillaDAOImpl.class);

	public TaquillaDAOImpl() {
		super(Taquilla.class);
	}

	@Override
	public Taquilla getByName(String nombre) {
		
		StringBuilder hql = new StringBuilder("from Taquilla t ");
		hql.append("where t.rowDeleted <> 1 ");
		hql.append("and t.nombre = :nombre ");
		
        Query query = entityManager.createQuery(hql.toString());
		query.setParameter("nombre", nombre);
		
		Taquilla taquilla = null;
		
		try {
			taquilla = (Taquilla) query.getSingleResult(); 
		} catch (NoResultException e) {
			LOGGER.info("Resultado del query: {}", e.toString());
			return null;
		} catch (NonUniqueResultException e){
			LOGGER.warn("Problemas en query: \n{}", e.toString());
            return null;
        }
		return taquilla;
		
	}

}
