package co.com.ath.pgw.persistence.model;

import java.math.BigDecimal;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import co.com.ath.pgw.persistence.PersistentObject;

import java.util.Date;

/**
 * Entidad que contiene los topes registrados en el CORE
 * 
 * @author ATH
 * @version 1.0 17/08/2017
 * @RQ27199
 * <strong>Autor</strong> Jordan Andrei Cortes </br>
 * <strong>Descripcion</strong> Validcación de Topes </br>
 */
@Entity
@Table(name = "TOPES")
public class Top implements PersistentObject, Comparable<Top> {

	private static final long serialVersionUID = -1527091107005764626L;

	@Id
	@SequenceGenerator(
			name="ID_GENERATOR_SEQ_TOPES",
			sequenceName="SEQ_TOPES",
			initialValue=1,
			allocationSize=1
			)
	@GeneratedValue(
			strategy=GenerationType.SEQUENCE,
			generator="ID_GENERATOR_SEQ_TOPES"
			)
	@Column(name = "IDTOPE")
	private BigDecimal Id;
	
	/**
	 * Tope asociado al medio de pago  
	 */
	@ManyToOne(fetch=FetchType.LAZY)
	@JoinColumn(name="IDMEDIOPAGO")
	private PaymentWay paymentWay;
	
	/**
	 * Tope para el convenio
	 */
	@ManyToOne(fetch=FetchType.LAZY)
	@JoinColumn(name="IDCOMERCIO")
	private Commerce commerce;
	
	@Column(name = "RQUID")
	private Long rquid;
	
	@Column(name = "CHANNEL", length=20)
	private String channel;
	
	@Column(name = "IPTOPES", length=20)
	private String ipTopes;
	
	@Column(name = "TIPOTOPE", length=20)
	private String typeTop;
	
	@Column(name = "DESCTOPE", length=30)
	private String descTop;
	
	@Column(name = "INFOTOPE", length=30)
	private String infoTop;
	
	@Column(name = "TOPEMAX")
	private BigDecimal topMax;
	
	@Column(name = "TOPEMIN")
	private BigDecimal topMin;
	
	@Column(name = "TOPEPERMANENTE")
	private Integer topPermanent;

	@Column(name = "FECHAFIN")
	private Date endDate;

	@Column(name = "FECHAINI")
	private Date beginDate;
	
	@Column(name = "CANTIDADXTRANSACCION")
	private String accountXTransaction;
	
	@Column(name = "PERIODOLIMPROGRAMADO")
	private String periodLimProgrammed;
	
	@Column(name = "PERIODOTIEMPO")
	private String periodTime;
	
	@Column(name = "TIPOMONEDA")
	private String typeCurrency;
	
	@Column(name = "TIPODOCCLIENTE")
	private String typeDocClient;
	
	@Column(name = "IDENTCLIENTE")
	private String docClient;
	
	@Column(name = "TIPOTRANSACCIONTOPE")
	private String typeTransactionTope;
	
	@Column(name = "TIPOSERVICIOTOPE")
	private String typeServiceTope;
	
	/**
	 * Indica si el registro tiene marca de borrado lógico.
	 */
	@Column(name = "REGELIMINADO")
	private boolean rowDeleted;

	/**
	 * Fecha de creación del registro.
	 */
	@Column(name = "REGFECHACREACION", nullable=false)
	@Temporal(TemporalType.TIMESTAMP)
	private Date rowCreationDate;
	
	/**
	 * Fecha de última modificación del registro
	 */
	@Temporal(TemporalType.TIMESTAMP)
	@Column(name="REGFECHAMODIFICACION", nullable=true)
	private Date rowLastUpdate;

	public BigDecimal getId() {
		return Id;
	}

	public void setId(BigDecimal id) {
		Id = id;
	}

	public PaymentWay getPaymentWay() {
		return paymentWay;
	}

	public void setPaymentWay(PaymentWay paymentWay) {
		this.paymentWay = paymentWay;
	}

	public Commerce getCommerce() {
		return commerce;
	}

	public void setCommerce(Commerce commerce) {
		this.commerce = commerce;
	}

	public String getTypeTop() {
		return typeTop;
	}

	public void setTypeTop(String typeTop) {
		this.typeTop = typeTop;
	}

	public String getDescTop() {
		return descTop;
	}

	public void setDescTop(String descTop) {
		this.descTop = descTop;
	}

	public Integer getTopPermanent() {
		return topPermanent;
	}

	public void setTopPermanent(Integer topPermanent) {
		this.topPermanent = topPermanent;
	}

	public Date getEndDate() {
		return endDate;
	}

	public void setEndDate(Date endDate) {
		this.endDate = endDate;
	}

	public Date getBeginDate() {
		return beginDate;
	}

	public void setBeginDate(Date beginDate) {
		this.beginDate = beginDate;
	}

	public String getAccountXTransaction() {
		return accountXTransaction;
	}

	public void setAccountXTransaction(String accountXTransaction) {
		this.accountXTransaction = accountXTransaction;
	}

	public String getPeriodLimProgrammed() {
		return periodLimProgrammed;
	}

	public void setPeriodLimProgrammed(String periodLimProgrammed) {
		this.periodLimProgrammed = periodLimProgrammed;
	}

	public String getPeriodTime() {
		return periodTime;
	}

	public void setPeriodTime(String periodTime) {
		this.periodTime = periodTime;
	}

	public String getTypeCurrency() {
		return typeCurrency;
	}

	public void setTypeCurrency(String typeCurrency) {
		this.typeCurrency = typeCurrency;
	}

	@Override
	public void setRowDeleted(boolean rowDeleted){
		this.rowDeleted = rowDeleted;
		
	}

	@Override
	public Date getRowCreationDate(){
		return rowCreationDate;
	}

	@Override
	public void setRowCreationDate(Date rowCreationDate){
		this.rowCreationDate = rowCreationDate;
	}

	@Override
	public Date getRowLastUpdate(){
		return rowLastUpdate;
	}

	@Override
	public void setRowLastUpdate(Date rowLastUpdate){
		this.rowLastUpdate = rowLastUpdate;
	}

	@Override
	public boolean isRowDeleted(){
		return rowDeleted;
	}

	public Long getRquid() {
		return rquid;
	}

	public void setRquid(Long rquid) {
		this.rquid = rquid;
	}

	public String getChannel() {
		return channel;
	}

	public void setChannel(String channel) {
		this.channel = channel;
	}

	public String getIpTopes() {
		return ipTopes;
	}

	public void setIpTopes(String ipTopes) {
		this.ipTopes = ipTopes;
	}

	public String getInfoTop() {
		return infoTop;
	}

	public void setInfoTop(String infoTop) {
		this.infoTop = infoTop;
	}

	public BigDecimal getTopMax() {
		return topMax;
	}

	public void setTopMax(BigDecimal topMax) {
		this.topMax = topMax;
	}

	public BigDecimal getTopMin() {
		return topMin;
	}

	public void setTopMin(BigDecimal topMin) {
		this.topMin = topMin;
	}

	public String getTypeDocClient() {
		return typeDocClient;
	}

	public void setTypeDocClient(String typeDocClient) {
		this.typeDocClient = typeDocClient;
	}

	public String getDocClient() {
		return docClient;
	}

	public void setDocClient(String docClient) {
		this.docClient = docClient;
	}

	public String getTypeTransactionTope() {
		return typeTransactionTope;
	}

	public void setTypeTransactionTope(String typeTransactionTope) {
		this.typeTransactionTope = typeTransactionTope;
	}

	public String getTypeServiceTope() {
		return typeServiceTope;
	}

	public void setTypeServiceTope(String typeServiceTope) {
		this.typeServiceTope = typeServiceTope;
	}

	@Override
	//TODO: Ajustar la comparacion de acuerdo a la llave de negocio que se defina
	
	public int compareTo(Top tope) {
		if(this.Id.equals(tope.getId()))
			return 1;
		return 0;
	}
	
}
