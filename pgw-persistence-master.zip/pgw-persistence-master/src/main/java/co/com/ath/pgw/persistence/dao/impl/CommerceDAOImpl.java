/*
 * CommerceDAOImpl
 *  
 * GSI - Integración
 * Creado el: 29/08/2014
 *
 * Copyright (c) A Toda Hora S.A. Todos los derechos reservados
 * 
 * Este software es confidencial y es propietario de ATH, queda prohibido
 * su uso, reproducción y copia de manera parcial o permanente salvo autorización
 * expresa de A Toda Hora S.A o de quién represente sus derechos.
 */
package co.com.ath.pgw.persistence.dao.impl;

import java.util.ArrayList;
import java.util.List;

import javax.annotation.Resource;
import javax.persistence.NoResultException;
import javax.persistence.ParameterMode;
import javax.persistence.Query;
import javax.persistence.StoredProcedureQuery;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Repository;

import co.com.ath.pgw.persistence.AbstractDAO_JPA;
import co.com.ath.pgw.persistence.dao.BankDAO;
import co.com.ath.pgw.persistence.dao.CommerceDAO;
import co.com.ath.pgw.persistence.model.Commerce;
import co.com.ath.pgw.persistence.procedure.model.CreacionConvenio;
import co.com.ath.pgw.persistence.procedure.model.NovedadConvenio;

/**
 * Implementación por defecto de CommerceDAO
 *
 * @author Andrés Méndez Juanias <proveedor_mamendez@ath.com.co>
 * @version 1.0 29 Ago 2014
 * @since 1.0
 * 
 * @IM23090
 * <strong>Autor</strong>Henry Hernandez</br>
 * <strong>Descripcion</strong>eliminacion espacios en blanco para el campo CODIGOACH</br>
 * <strong>Numero de Cambios</strong>1</br>
 * <strong>Identificador corto</strong>C01</br>
 * 
 */
@Repository
public class CommerceDAOImpl extends AbstractDAO_JPA<Commerce> implements CommerceDAO {

	static Logger LOGGER = LoggerFactory.getLogger(CommerceDAOImpl.class);
	@Resource
	BankDAO bankDAO;
	
	public CommerceDAOImpl() {
		super(Commerce.class);
	}

	@Override
	public Commerce findByNura(String nuraCode) {
		StringBuilder sb = new StringBuilder("from Commerce c ");
		sb.append("where c.nuraCode = :nuraCode ");

		Query query = entityManager.createQuery(sb.toString());
		query.setParameter("nuraCode", nuraCode);

		Commerce commerce = null;

		try {
			commerce = (Commerce) query.getSingleResult();			
		} catch (NoResultException e) {			
			LOGGER.info("No hay resultados en la consulta convenio ("+nuraCode+")");
			return commerce;
		}
		catch (Exception ex){
		  LOGGER.warn("Problemas en query", ex);
		 return commerce;
		}
		return commerce;
	}
	
	@Override
	public Commerce findByNuraDeleted(String nuraCode) {
		StringBuilder sb = new StringBuilder("from Commerce c ");
		sb.append("where c.rowDeleted = 0 ");
		sb.append("and c.nuraCode = :nuraCode");

		Query query = entityManager.createQuery(sb.toString());
		query.setParameter("nuraCode", nuraCode);

		Commerce commerce = null;

		try {
			commerce = (Commerce) query.getSingleResult();
		} catch (NoResultException e) {
			     LOGGER.info("No Existe el convenio ("+nuraCode+") o se encuentra Inactivo");
			     return commerce;
		}
		catch (Exception ex){
		       LOGGER.warn("Problemas en query", ex);
		       return commerce;
		}
	  return commerce;
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<Commerce> listPaymentFileActive() {
		StringBuilder sb = new StringBuilder("from Commerce c ");
		sb.append("where c.rowDeleted <> 1 ");
		sb.append("and c.configuration.paymentFileActive = :paymentFileActive");

		Query query = entityManager.createQuery(sb.toString());
		query.setParameter("paymentFileActive", Boolean.TRUE);

		List<Commerce> commerceList = null;

		try {
			commerceList = query.getResultList(); 
		} catch (NoResultException e) {
			LOGGER.info("No hay resultados para la consulta", e);
			return new ArrayList<Commerce>();
		}
		catch (Exception ex){
		       LOGGER.warn("Problemas en query", ex);
		       return new ArrayList<Commerce>();
		}
		return commerceList;
	}
	
	@SuppressWarnings("unchecked")
	@Override
	public List<Commerce> listZipAsobancariaActive() {
		StringBuilder sb = new StringBuilder("from Commerce c ");
		sb.append("where c.rowDeleted <> 1 ");
		sb.append("and c.zipasobancaria = :zipasobancaria");

		Query query = entityManager.createQuery(sb.toString());
		query.setParameter("zipasobancaria", 1L);

		List<Commerce> commerceList = null;

		try {
			commerceList = query.getResultList(); 
		} catch (NoResultException e) {
			LOGGER.info("No hay resultados para la consulta", e);
			return new ArrayList<Commerce>();
		}
		catch (Exception ex){
		       LOGGER.warn("Problemas en query", ex);
		       return new ArrayList<Commerce>();
		}
		return commerceList;
	}

	@Override
	public Commerce agreementSynchronization(NovedadConvenio novedadConvenio) {
				
		Commerce commerce = null;
		try {
			StoredProcedureQuery storedProcedure = entityManager.createStoredProcedureQuery("SP_NOVEDADES_CONVENIOS");
			storedProcedure.registerStoredProcedureParameter("P_OPERACION", String.class, ParameterMode.IN);
			storedProcedure.registerStoredProcedureParameter("P_ESTADO", String.class, ParameterMode.IN);
			storedProcedure.registerStoredProcedureParameter("P_CODIGOEAN", String.class, ParameterMode.IN);
			storedProcedure.registerStoredProcedureParameter("P_CODIGONURA", String.class, ParameterMode.IN);
			storedProcedure.registerStoredProcedureParameter("P_CODIGOINCOCREDITO", String.class, ParameterMode.IN);
			storedProcedure.registerStoredProcedureParameter("P_CODIGOACH", String.class, ParameterMode.IN);
			storedProcedure.registerStoredProcedureParameter("P_HOMOLOGATION_BAVV_CODE", String.class, ParameterMode.IN);
			storedProcedure.registerStoredProcedureParameter("P_CODIGOTERMINAL", String.class, ParameterMode.IN);
			storedProcedure.registerStoredProcedureParameter("P_ACTIVIDAD_ECONOMICA", String.class, ParameterMode.IN);
			storedProcedure.registerStoredProcedureParameter("P_IDBANCO", String.class, ParameterMode.IN);
			storedProcedure.registerStoredProcedureParameter("P_IDMUNICIPIO", String.class, ParameterMode.IN);
			storedProcedure.registerStoredProcedureParameter("P_RAZONSOCIAL", String.class, ParameterMode.IN);
			storedProcedure.registerStoredProcedureParameter("P_DIRECCION", String.class, ParameterMode.IN);
			storedProcedure.registerStoredProcedureParameter("P_TELEFONO", String.class, ParameterMode.IN);
			storedProcedure.registerStoredProcedureParameter("P_EMAIL", String.class, ParameterMode.IN);
			storedProcedure.registerStoredProcedureParameter("P_EXTENSION", String.class, ParameterMode.IN);
			storedProcedure.registerStoredProcedureParameter("P_REPRESENTATELEGAL", String.class, ParameterMode.IN);
			storedProcedure.registerStoredProcedureParameter("P_EMAIL_CONT", String.class, ParameterMode.IN);
			storedProcedure.registerStoredProcedureParameter("P_TELEFONO_CONT", String.class, ParameterMode.IN);
			
			//Parametros GENERALES
			storedProcedure.setParameter("P_OPERACION", novedadConvenio.getOperacion());
			storedProcedure.setParameter("P_ESTADO", novedadConvenio.getEstado());
			
			//COMERCIO
			storedProcedure.setParameter("P_CODIGOEAN", novedadConvenio.getCodigoEAN());
			storedProcedure.setParameter("P_CODIGONURA", novedadConvenio.getCodigoNura());
			storedProcedure.setParameter("P_CODIGOINCOCREDITO", novedadConvenio.getCodigoIncocredito());
			storedProcedure.setParameter("P_CODIGOACH", novedadConvenio.getCodigoAch());
			storedProcedure.setParameter("P_HOMOLOGATION_BAVV_CODE", novedadConvenio.getCodigoHomologaBAVV());
			storedProcedure.setParameter("P_CODIGOTERMINAL", novedadConvenio.getCodigoTerminal());
			storedProcedure.setParameter("P_ACTIVIDAD_ECONOMICA",novedadConvenio.getIdActEcnomica());
			
			//SUBSCRIPCION
			storedProcedure.setParameter("P_IDBANCO", novedadConvenio.getIdBanco());
			storedProcedure.setParameter("P_IDMUNICIPIO", novedadConvenio.getIdMunicipio());
			storedProcedure.setParameter("P_RAZONSOCIAL", novedadConvenio.getRazonSocial());
			storedProcedure.setParameter("P_DIRECCION", novedadConvenio.getDireccion());
			storedProcedure.setParameter("P_TELEFONO", novedadConvenio.getTelefono());
			storedProcedure.setParameter("P_EMAIL", novedadConvenio.getEmail());
			storedProcedure.setParameter("P_EXTENSION", novedadConvenio.getExtension());
			
			//CONTACTOSCOMERCIO
			storedProcedure.setParameter("P_REPRESENTATELEGAL", novedadConvenio.getRepLegal());
			storedProcedure.setParameter("P_EMAIL_CONT", novedadConvenio.getEmailCont());
			storedProcedure.setParameter("P_TELEFONO_CONT", novedadConvenio.getTelCont());
			LOGGER.info("Novedad convenio: " + novedadConvenio);
			storedProcedure.execute();
			
			//if(novedadConvenio.getOperacion().equals("Enroll") || novedadConvenio.getOperacion().equals("Modify")) {
				commerce = findByNura("CPV"+novedadConvenio.getCodigoNura());
			//}
		}catch (NoResultException e) {
			LOGGER.error("Error SP_NOVEDADES_CONVENIOS: ", e);
			return null;
		}
		catch (Exception ex){
			  LOGGER.error("Problemas en query", ex);
			 return null;
		}
		
		return commerce;
	}
	
	@Override
	public Commerce agreementCreate(CreacionConvenio creacionConvenio) {
	
		Commerce commerce = null;
	
		try {
						
			StoredProcedureQuery storedProcedure = entityManager.createStoredProcedureQuery("SP_CREATE_AGREEMENT");
			storedProcedure.registerStoredProcedureParameter("P_OPERACION", String.class, ParameterMode.IN);
			
			storedProcedure.registerStoredProcedureParameter("P_CODIGONURA", String.class, ParameterMode.IN);
			storedProcedure.registerStoredProcedureParameter("P_NIT", String.class, ParameterMode.IN);
			storedProcedure.registerStoredProcedureParameter("P_CODIGOEAN", String.class, ParameterMode.IN);
			storedProcedure.registerStoredProcedureParameter("P_CODIGOACH", String.class, ParameterMode.IN);
			storedProcedure.registerStoredProcedureParameter("P_AGREGADOR", String.class, ParameterMode.IN);
			storedProcedure.registerStoredProcedureParameter("P_CODIGOINCOCREDITO", String.class, ParameterMode.IN);
			storedProcedure.registerStoredProcedureParameter("P_CODIGOTERMINAL", String.class, ParameterMode.IN);
			storedProcedure.registerStoredProcedureParameter("P_IDACTIVIDADECONOMICA", String.class, ParameterMode.IN);
			storedProcedure.registerStoredProcedureParameter("P_TARJETA_CREDITO", String.class, ParameterMode.IN);
			storedProcedure.registerStoredProcedureParameter("P_ESTADO", String.class, ParameterMode.IN);
			storedProcedure.registerStoredProcedureParameter("P_CODIGOAPPRBM", String.class, ParameterMode.IN);
			storedProcedure.registerStoredProcedureParameter("P_KEYRBM", String.class, ParameterMode.IN);
			
			storedProcedure.registerStoredProcedureParameter("P_IDMUNICIPIO", String.class, ParameterMode.IN);
			storedProcedure.registerStoredProcedureParameter("P_IDBANCO", String.class, ParameterMode.IN);
			storedProcedure.registerStoredProcedureParameter("P_RAZONSOCIAL", String.class, ParameterMode.IN);
			storedProcedure.registerStoredProcedureParameter("P_DIGITOVERIFICACION", String.class, ParameterMode.IN);
			storedProcedure.registerStoredProcedureParameter("P_DIRECCION", String.class, ParameterMode.IN);
			storedProcedure.registerStoredProcedureParameter("P_TELEFONO", String.class, ParameterMode.IN);
			storedProcedure.registerStoredProcedureParameter("P_EMAIL", String.class, ParameterMode.IN);
			storedProcedure.registerStoredProcedureParameter("P_APELLIDOREPRESENTANTE", String.class, ParameterMode.IN);
			storedProcedure.registerStoredProcedureParameter("P_REPRESENTATELEGAL", String.class, ParameterMode.IN);
			storedProcedure.registerStoredProcedureParameter("P_CCREPRESENTANTELEGAL", String.class, ParameterMode.IN);
			storedProcedure.registerStoredProcedureParameter("P_TIPODOCUMENTORL", String.class, ParameterMode.IN);
			storedProcedure.registerStoredProcedureParameter("P_FAX", String.class, ParameterMode.IN);
			
			storedProcedure.registerStoredProcedureParameter("P_TEMA", String.class, ParameterMode.IN);
			storedProcedure.registerStoredProcedureParameter("P_PLANTILLA", String.class, ParameterMode.IN);
			storedProcedure.registerStoredProcedureParameter("P_LOGO", String.class, ParameterMode.IN);
			storedProcedure.registerStoredProcedureParameter("P_USUARIO", String.class, ParameterMode.IN);
			storedProcedure.registerStoredProcedureParameter("P_CONTRASENA", String.class, ParameterMode.IN);
			storedProcedure.registerStoredProcedureParameter("P_URLRESPUESTA", String.class, ParameterMode.IN);
			storedProcedure.registerStoredProcedureParameter("P_URLCONFIRMACION", String.class, ParameterMode.IN);
			storedProcedure.registerStoredProcedureParameter("P_RUTACERTIFICADO", String.class, ParameterMode.IN);
			storedProcedure.registerStoredProcedureParameter("P_REGELIMINADO", String.class, ParameterMode.IN);
			storedProcedure.registerStoredProcedureParameter("P_GENDER", String.class, ParameterMode.IN);
			storedProcedure.registerStoredProcedureParameter("P_TIPODESERVICIO", String.class, ParameterMode.IN);
			storedProcedure.registerStoredProcedureParameter("P_NOFACTMULTIPLEREF", String.class, ParameterMode.IN);
			storedProcedure.registerStoredProcedureParameter("P_TIPOADMINISTRADOR", String.class, ParameterMode.IN);
			
			storedProcedure.registerStoredProcedureParameter("P_IDMEDIOPAGO", String.class, ParameterMode.IN);
			storedProcedure.registerStoredProcedureParameter("P_CUENTAASOCIADA", String.class, ParameterMode.IN);
			storedProcedure.registerStoredProcedureParameter("P_TIPOCUENTA", String.class, ParameterMode.IN);
			storedProcedure.registerStoredProcedureParameter("P_DESCRIPCIONTIPOCUENTA", String.class, ParameterMode.IN);
			
			storedProcedure.registerStoredProcedureParameter("P_IDROL", String.class, ParameterMode.IN);
			//COMERCIAL
			storedProcedure.registerStoredProcedureParameter("P_NOMBRE_COMERCIAL", String.class, ParameterMode.IN);
			storedProcedure.registerStoredProcedureParameter("P_APELLIDO_COMERCIAL", String.class, ParameterMode.IN);
			storedProcedure.registerStoredProcedureParameter("P_NUMERODOCUMENTO_COMERCIAL", String.class, ParameterMode.IN);
			storedProcedure.registerStoredProcedureParameter("P_EMAIL_CONT_COMERCIAL", String.class, ParameterMode.IN);
			storedProcedure.registerStoredProcedureParameter("P_TELEFONO_CONT_COMERCIAL", String.class, ParameterMode.IN);
			storedProcedure.registerStoredProcedureParameter("P_TIPODOCUMENTO_CONT_COMERCIAL", String.class, ParameterMode.IN);
			//TECNICO			
			storedProcedure.registerStoredProcedureParameter("P_NOMBRE_TECNICO", String.class, ParameterMode.IN);
			storedProcedure.registerStoredProcedureParameter("P_APELLIDO_TECNICO", String.class, ParameterMode.IN);
			storedProcedure.registerStoredProcedureParameter("P_NUMERODOCUMENTO_TECNICO", String.class, ParameterMode.IN);
			storedProcedure.registerStoredProcedureParameter("P_EMAIL_CONT_TECNICO", String.class, ParameterMode.IN);
			storedProcedure.registerStoredProcedureParameter("P_TELEFONO_CONT_TECNICO", String.class, ParameterMode.IN);
			storedProcedure.registerStoredProcedureParameter("P_TIPODOCUMENTO_CONT_TECNICO", String.class, ParameterMode.IN);
			//OPERATIVO
			storedProcedure.registerStoredProcedureParameter("P_NOMBRE_OPERATIVO", String.class, ParameterMode.IN);
			storedProcedure.registerStoredProcedureParameter("P_APELLIDO_OPERATIVO", String.class, ParameterMode.IN);
			storedProcedure.registerStoredProcedureParameter("P_NUMERODOCUMENTO_OPERATIVO", String.class, ParameterMode.IN);
			storedProcedure.registerStoredProcedureParameter("P_EMAIL_CONT_OPERATIVO", String.class, ParameterMode.IN);
			storedProcedure.registerStoredProcedureParameter("P_TELEFONO_CONT_OPERATIVO", String.class, ParameterMode.IN);
			storedProcedure.registerStoredProcedureParameter("P_TIPODOCUMENTO_CONT_OPERATIVO", String.class, ParameterMode.IN);
			//Cuentas Recaudadoras Adicionales	
 			storedProcedure.registerStoredProcedureParameter("P_CUENTA_RECAUDO_ASOCIADA", String.class, ParameterMode.IN);	
 			storedProcedure.registerStoredProcedureParameter("P_ID_BANCO_CUENTA_RECAUDO", String.class, ParameterMode.IN);	
 			storedProcedure.registerStoredProcedureParameter("P_CODIGO_ACH_CUENTA_RECAUDO", String.class, ParameterMode.IN);
			storedProcedure.registerStoredProcedureParameter("statusOUT", String.class, ParameterMode.OUT);
				
			//Parametros GENERALES
			storedProcedure.setParameter("P_OPERACION", creacionConvenio.getOperacion());
		
			//COMERCIO
			storedProcedure.setParameter("P_CODIGONURA", creacionConvenio.getCodigoNura());
			storedProcedure.setParameter("P_NIT", creacionConvenio.getNit());
			storedProcedure.setParameter("P_CODIGOEAN", creacionConvenio.getCodigoEan());
			storedProcedure.setParameter("P_AGREGADOR", creacionConvenio.getAgregador());
			storedProcedure.setParameter("P_CODIGOINCOCREDITO", creacionConvenio.getCodigoIncocredito());
			storedProcedure.setParameter("P_CODIGOACH", creacionConvenio.getCodigoAch());
			storedProcedure.setParameter("P_CODIGOTERMINAL", creacionConvenio.getCodigoTerminal());
			storedProcedure.setParameter("P_IDACTIVIDADECONOMICA",creacionConvenio.getIdActEcnomica());
			storedProcedure.setParameter("P_TARJETA_CREDITO", creacionConvenio.getTarjetaCredito());
			storedProcedure.setParameter("P_ESTADO",creacionConvenio.getEstado());
			storedProcedure.setParameter("P_CODIGOAPPRBM", creacionConvenio.getCodigoGlobalPay());
			storedProcedure.setParameter("P_KEYRBM", creacionConvenio.getLlaveGlobalPay());
							
			//SUBSCRIPCION
			storedProcedure.setParameter("P_IDBANCO", creacionConvenio.getIdBanco());
			storedProcedure.setParameter("P_IDMUNICIPIO", creacionConvenio.getIdMunicipio());
			storedProcedure.setParameter("P_RAZONSOCIAL", creacionConvenio.getRazonSocial());
			storedProcedure.setParameter("P_DIGITOVERIFICACION", creacionConvenio.getDigitoVerificacion());
			storedProcedure.setParameter("P_DIRECCION", creacionConvenio.getDireccion());
			storedProcedure.setParameter("P_TELEFONO", creacionConvenio.getTelefono());
			storedProcedure.setParameter("P_EMAIL", creacionConvenio.getEmail());
			storedProcedure.setParameter("P_FAX", creacionConvenio.getFax());
			storedProcedure.setParameter("P_APELLIDOREPRESENTANTE", creacionConvenio.getApeRepLegal());
			storedProcedure.setParameter("P_REPRESENTATELEGAL", creacionConvenio.getRepLegal());
			storedProcedure.setParameter("P_CCREPRESENTANTELEGAL", creacionConvenio.getNumDocRL());
			storedProcedure.setParameter("P_TIPODOCUMENTORL", creacionConvenio.getTipoDocRL());
			
			//CONFIGURACIONCOMERCIO
			storedProcedure.setParameter("P_TEMA", creacionConvenio.getTema());
			storedProcedure.setParameter("P_PLANTILLA", creacionConvenio.getPlantilla());
			storedProcedure.setParameter("P_LOGO", creacionConvenio.getLogo());
			storedProcedure.setParameter("P_USUARIO", creacionConvenio.getUsuario());
			storedProcedure.setParameter("P_CONTRASENA", creacionConvenio.getContrasena());
			storedProcedure.setParameter("P_URLRESPUESTA", creacionConvenio.getUrlRespuesta());
			storedProcedure.setParameter("P_URLCONFIRMACION", creacionConvenio.getUrlConfirmacion());
			storedProcedure.setParameter("P_RUTACERTIFICADO", creacionConvenio.getRutaCertificado());
			storedProcedure.setParameter("P_GENDER", creacionConvenio.getGender());
			storedProcedure.setParameter("P_TIPODESERVICIO", creacionConvenio.getTipoServicio());
			storedProcedure.setParameter("P_NOFACTMULTIPLEREF", creacionConvenio.getNoFactMultipleRef());
			storedProcedure.setParameter("P_REGELIMINADO", creacionConvenio.getRegEliminado());
			storedProcedure.setParameter("P_TIPOADMINISTRADOR", creacionConvenio.getTipoAdministrador());
			
			//MEDIOSPAGOSXCOMERCIO
			storedProcedure.setParameter("P_IDMEDIOPAGO", creacionConvenio.getIdMedioPago());
			storedProcedure.setParameter("P_CUENTAASOCIADA", creacionConvenio.getCuentaAsociada());
			storedProcedure.setParameter("P_TIPOCUENTA", creacionConvenio.getTipoCuenta());
			storedProcedure.setParameter("P_DESCRIPCIONTIPOCUENTA", creacionConvenio.getDescTipoCuenta());
			
			//CONTACTOSCOMERCIO
			storedProcedure.setParameter("P_IDROL", creacionConvenio.getIdRol());
			
			//COMERCIAL
			storedProcedure.setParameter("P_NOMBRE_COMERCIAL", creacionConvenio.getNombreComercial());
			storedProcedure.setParameter("P_APELLIDO_COMERCIAL", creacionConvenio.getApellidoComercial());
			storedProcedure.setParameter("P_NUMERODOCUMENTO_COMERCIAL", creacionConvenio.getNumDocComercial());
			storedProcedure.setParameter("P_EMAIL_CONT_COMERCIAL", creacionConvenio.getEmailContComercial());
			storedProcedure.setParameter("P_TELEFONO_CONT_COMERCIAL", creacionConvenio.getTelContComercial());
			storedProcedure.setParameter("P_TIPODOCUMENTO_CONT_COMERCIAL", creacionConvenio.getTipoDocContComercial());
		
			//TECNICO
			storedProcedure.setParameter("P_NOMBRE_TECNICO", creacionConvenio.getNombreTecnico());
			storedProcedure.setParameter("P_APELLIDO_TECNICO", creacionConvenio.getApellidoTecnico());
			storedProcedure.setParameter("P_NUMERODOCUMENTO_TECNICO", creacionConvenio.getNumDocTecnico());
			storedProcedure.setParameter("P_EMAIL_CONT_TECNICO", creacionConvenio.getEmailContTecnico());
			storedProcedure.setParameter("P_TELEFONO_CONT_TECNICO", creacionConvenio.getTelContTecnico());
			storedProcedure.setParameter("P_TIPODOCUMENTO_CONT_TECNICO", creacionConvenio.getTipoDocContTecnico());
			
			//OPERATIVO
			storedProcedure.setParameter("P_NOMBRE_OPERATIVO", creacionConvenio.getNombreOperativo());
			storedProcedure.setParameter("P_APELLIDO_OPERATIVO", creacionConvenio.getApellidoOperativo());
			storedProcedure.setParameter("P_NUMERODOCUMENTO_OPERATIVO", creacionConvenio.getNumDocOperativo());
			storedProcedure.setParameter("P_EMAIL_CONT_OPERATIVO", creacionConvenio.getEmailContOperativo());
			storedProcedure.setParameter("P_TELEFONO_CONT_OPERATIVO", creacionConvenio.getTelContOperativo());
			storedProcedure.setParameter("P_TIPODOCUMENTO_CONT_OPERATIVO", creacionConvenio.getTipoDocContOperativo());
			//CUENTARECAUDADORA	
 			storedProcedure.setParameter("P_CUENTA_RECAUDO_ASOCIADA",creacionConvenio.getCuentaRecaudoAsociada());	
 			storedProcedure.setParameter("P_ID_BANCO_CUENTA_RECAUDO",  creacionConvenio.getIdBancoCuentaRecaudo());	
 			storedProcedure.setParameter("P_CODIGO_ACH_CUENTA_RECAUDO", creacionConvenio.getCodigoAchCuentaRecaudo());
			LOGGER.info("Creacion convenio inicio execute: " + creacionConvenio);
			storedProcedure.execute();
			
			String estadoProcedimiento = (String) storedProcedure.getOutputParameterValue("statusOUT");
			LOGGER.info("Estado SP: "+estadoProcedimiento);
				
			commerce = findByNura(creacionConvenio.getCodigoNura());
			
		}catch (NoResultException e) {
			LOGGER.error("Error SP_CREATE_AGREEMENT: ", e);
			return null;
		}
		catch (Exception ex){
				ex.printStackTrace();
			  LOGGER.error("Problemas en query", ex);
			 return null;
		}
		
		return commerce;
	}
	/***/
	@SuppressWarnings("unchecked")
	@Override
	public Long getCommerceByIncoCredito(String codigoIncocredito, String nit) throws Exception{
		LOGGER.info("Entro al método getCommerceByIncoCredito()");
		
		  try{ 
		  StringBuilder sql = new StringBuilder();
		  sql.append("SELECT COUNT(c.id) FROM Commerce c WHERE c.incocreditoCode = :codigoIncocredito and c.nit <> :nit");
		  Query query = entityManager.createQuery(sql.toString());
		 
		  query.setParameter("codigoIncocredito", codigoIncocredito);
		  query.setParameter("nit", Long.parseLong(nit));
		  long count= (Long)query.getSingleResult();
		  return count;
		  
		}catch(Exception ex){
			LOGGER.error("::: Error consultando la lista de comercios por codigo incocredito y nit :::", ex);
				throw ex;
		}
	}
	
	/***/
	@SuppressWarnings("unchecked")
	@Override
	public Long  getCommerceByTerminal(String codigoIncocredito,  String codigoTerminal, String codigoNura) throws Exception{
		LOGGER.info("Entro al método getCommerceByIncoCredito()");
		
		  try{ 
		  StringBuilder sql = new StringBuilder();
		  sql.append(" SELECT COUNT(c.id) FROM Commerce c WHERE c.terminalCode =:codigoTerminal and  c.incocreditoCode <> :codigoIncocredito and c.nuraCode <> :codigonura");
		  Query query = entityManager.createQuery(sql.toString());
		  
		  query.setParameter("codigoTerminal", codigoTerminal);
		  query.setParameter("codigoIncocredito", codigoIncocredito);
		  query.setParameter("codigonura", codigoNura);
		  long count= (Long)query.getSingleResult();
		  return count;
		  
		}catch(Exception ex){
			LOGGER.error("::: Error consultando la lista de comercios por terminal :::", ex);
				throw ex;
		}
	}
}