package co.com.ath.pgw.persistence.dao.impl;

import java.math.BigDecimal;
import java.util.List;

import javax.persistence.NoResultException;
import javax.persistence.NonUniqueResultException;
import javax.persistence.Query;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Repository;

import co.com.ath.pgw.persistence.AbstractDAO_JPA;
import co.com.ath.pgw.persistence.dao.TopDAO;
import co.com.ath.pgw.persistence.model.Top;

/**
 * @author ATH
 * @version 1.0 17/08/2017
 * @RQ27199 <strong>Autor</strong> Jordan Andrei Cortes </br>
 *          <strong>Descripcion</strong> Validcación de Topes </br>
 */
@Repository
public class TopDAOImpl extends AbstractDAO_JPA<Top> implements TopDAO {

	static Logger LOGGER = LoggerFactory.getLogger(TopDAOImpl.class);

	protected TopDAOImpl() {
		super(Top.class);
	}

	@Override
	public List<Top> findByCommerce(Long idComercio) throws Exception {
		List<Top> resultado;
		StringBuilder hql = new StringBuilder("select t from Top t ");
		hql.append(" WHERE t.commerce.id = :idCommerce ");
		hql.append(" AND t.rowDeleted = 0 ORDER BY t.beginDate ASC ");
		Query query = entityManager.createQuery(hql.toString());
		query.setParameter("idCommerce", idComercio);
		try {
			resultado = query.getResultList();
			
		} catch (NoResultException e) {
			LOGGER.warn("Problemas en query", e);
			throw e;
		} catch (Exception e) {
			LOGGER.warn("Problemas en query", e);
			throw e;
		}
		return resultado;
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<Top> findByCommerceAndPaymentWay(Long idComercio, Long paymentWay) throws Exception {
		List<Top> resultado = null;
		
		StringBuilder hql = new StringBuilder(" SELECT t FROM Top t ");
		hql.append(" WHERE t.commerce.id = :idCommerce ");
		hql.append(" AND t.paymentWay.id = :idPayment ");
		hql.append(" AND t.rowDeleted = 0 ");

		Query query = entityManager.createQuery(hql.toString());
		query.setParameter("idCommerce", idComercio);
		query.setParameter("idPayment", paymentWay);
		try {

			resultado = query.getResultList();


		} catch (NoResultException e) {
			LOGGER.warn("Problemas en query", e);
			throw e;
		} catch (Exception e) {
			LOGGER.warn("Problemas en query", e);
			throw e;
		}
		return resultado;

	}
	@Override
	public Top findTopPermanentTran(Long idComercio, Long paymentWay, BigDecimal valor) {
		Top resultado = null;
		
		StringBuilder hql = new StringBuilder(" SELECT t FROM Top t ");
		hql.append(" WHERE t.commerce.id = :idCommerce AND t.topPermanent = 1");
		hql.append(" AND t.paymentWay.id = :paymentWay AND t.rowDeleted = 0");
		hql.append(" AND ( t.topMin >= :valor OR t.topMax <= :valor )");
		
		Query query = entityManager.createQuery(hql.toString());
		query.setParameter("idCommerce", idComercio);
		query.setParameter("paymentWay", paymentWay);
		query.setParameter("valor", valor);
		
		try {

			resultado = (Top) query.getSingleResult();


		} catch (NoResultException e) {
			LOGGER.info("No hay tope permanente para la transaccion");
			return resultado;
		} catch (NonUniqueResultException e) {
			LOGGER.error("Existen varios topes permanentes", e);
			throw e;
		}
		return resultado;
	}
	
	@Override
	public Top findTopByDateTran(Long idComercio, Long paymentWay, BigDecimal valor) {
		Top resultado = null;
		
		StringBuilder hql = new StringBuilder(" SELECT t FROM Top t ");
		hql.append(" WHERE t.commerce.id = :idCommerce ");
		hql.append(" AND  t.paymentWay.id = :paymentWay AND t.rowDeleted = 0");
		hql.append(" AND CURRENT_DATE >= t.beginDate AND CURRENT_DATE <= t.endDate  ");
		hql.append(" AND ( :valor <= t.topMin OR :valor >= t.topMax )");
		
		Query query = entityManager.createQuery(hql.toString());
		query.setParameter("idCommerce", idComercio);
		query.setParameter("paymentWay", paymentWay);
		query.setParameter("valor", valor);
		
		try {

			resultado = (Top) query.getSingleResult();


		} catch (NoResultException e) {
			LOGGER.info("No hay tope de fechas para la transaccion");
			return resultado;
		} catch (NonUniqueResultException e) {
			LOGGER.warn("Problemas en query", e);
			throw e;
		}
		return  resultado;
	
	}

	@Override
	public Top findTopByDesc(String desc) throws Exception {
		
		Top tope = null;
		try{
			StringBuilder hql = new StringBuilder(" select t from Top t ");
			hql.append(" where t.descTop = :desc");
			hql.append(" and t.rowDeleted = 0 ");

			Query query = entityManager.createQuery(hql.toString());
			query.setParameter("desc", desc);
			
			tope = (Top) query.getSingleResult();
			
		} catch (NoResultException e) {
			LOGGER.info("No Existe el tope");
		} catch (Exception e) {
			LOGGER.error("Problemas en query", e);
			throw  new Exception(e);
		}
		
		
		return tope;
	}

	
}

