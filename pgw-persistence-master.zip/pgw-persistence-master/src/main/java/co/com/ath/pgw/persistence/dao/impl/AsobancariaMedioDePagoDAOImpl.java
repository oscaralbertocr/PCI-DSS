/*
 * AsobancariaMedioDePagoDAOImpl
 *  
 * GSI - Integración
 * Creado el: 24/07/2017
 *
 * Copyright (c) A Toda Hora S.A. Todos los derechos reservados
 * 
 * Este software es confidencial y es propietario de ATH, queda prohibido
 * su uso, reproducción y copia de manera parcial o permanente salvo autorización
 * expresa de A Toda Hora S.A o de quién represente sus derechos.
 */
package co.com.ath.pgw.persistence.dao.impl;

import javax.persistence.NoResultException;
import javax.persistence.NonUniqueResultException;
import javax.persistence.Query;

import org.springframework.stereotype.Repository;

import co.com.ath.pgw.persistence.AbstractDAO_JPA;
import co.com.ath.pgw.persistence.dao.AsobancariaMedioDePagoDAO;
import co.com.ath.pgw.persistence.model.AsobancariaMedioDePago;

/**
 * Implementación por defecto de AsobancariaMedioDePagoDAO
 *
 * @author Camilo Andres Bustamante <proveedor_cbustamant@ath.com.co>
 * @version 1.0 24 Jul 2017
 * @since 1.0
 */
@Repository
public class AsobancariaMedioDePagoDAOImpl 
			extends AbstractDAO_JPA<AsobancariaMedioDePago> implements AsobancariaMedioDePagoDAO {

	public AsobancariaMedioDePagoDAOImpl() {
		super(AsobancariaMedioDePago.class);
	}
	
	/**INICIO-C01**/
	@Override
	public AsobancariaMedioDePago findById(Long bankId) {

		StringBuilder hql = new StringBuilder("from AsobancariaMedioDePago b ");
		hql.append("where b.id = :bankId ");
		
        Query query = entityManager.createQuery(hql.toString());
		query.setParameter("bankId", bankId);
		
		AsobancariaMedioDePago bank = null;
		
		try {
			bank = (AsobancariaMedioDePago) query.getSingleResult();
		} catch (NoResultException e) {
			return null;
		} catch (NonUniqueResultException e){
            return null;
		} catch (Exception e) {
			return null;
		}
			
		return bank;
	}
	/**FIN-C01**/

}
