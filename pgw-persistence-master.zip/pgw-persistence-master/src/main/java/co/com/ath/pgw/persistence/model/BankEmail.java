package co.com.ath.pgw.persistence.model;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import co.com.ath.pgw.persistence.PersistentObject;

/**
 * Clase que representa los correos establecidos de parametrización de envío de correo
 * 
 * @author proveedor_jlara
 * @version 1.0 23 Nov 2016
 * @since 1.0
 */
@Entity
@Table(name="BANCOCORREOS")
public class BankEmail implements PersistentObject{
	
	private static final long serialVersionUID = 8658947969768783083L;
	
	@Id
    @Column(name="ID_CORREO")
	private Long idCorreo;
	
	@ManyToOne(fetch=FetchType.EAGER) 
	@JoinColumn(name="ID_BANCO")
	private Bank bank;
	
	@Column(name="CORREO")
	private String correo;
	
	@Column(name="REGELIMINADO")
	private boolean rowDeleted;
	
	@Column(name="REGFECHACREACION")
    @Temporal(TemporalType.TIMESTAMP)
	private Date rowCreationDate;
	
	@Temporal(TemporalType.TIMESTAMP)
	@Column(name="REGFECHAMODIFICACION", nullable=true)
	private Date rowLastUpdate;
	
	public Long getIdCorreo() {
		return idCorreo;
	}

	public void setIdCorreo(Long idCorreo) {
		this.idCorreo = idCorreo;
	}

	public Bank getBank() {
		return bank;
	}

	public void setBank(Bank bank) {
		this.bank = bank;
	}

	public String getCorreo() {
		return correo;
	}

	public void setCorreo(String correo) {
		this.correo = correo;
	}

	@Override
	public boolean isRowDeleted() {
		return rowDeleted;
	}

	@Override
	public void setRowDeleted(boolean rowDeleted) {
		this.rowDeleted = rowDeleted;
	}

	@Override
	public Date getRowCreationDate() {
		return rowCreationDate;
	}

	@Override
	public void setRowCreationDate(Date rowCreationDate) {
		this.rowCreationDate = rowCreationDate;
	}

	@Override
	public Date getRowLastUpdate(){
		return rowLastUpdate;
	}

	@Override
	public void setRowLastUpdate(Date rowLastUpdate){
		this.rowLastUpdate = rowLastUpdate;
	}
	
}
