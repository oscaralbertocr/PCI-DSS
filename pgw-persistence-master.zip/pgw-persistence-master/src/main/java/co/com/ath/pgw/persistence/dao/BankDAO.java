/*
 * BankDAO
 *
 * GSI - Integración
 * Creado el: 22 de agosto de 2014
 *
 * Copyright (c) A Toda Hora S.A. Todos los derechos reservados
 *
 * Este software es confidencial y es propietario de ATH, queda prohibido
 * su uso, reproducción y copia de manera parcial o permanente salvo autorización
 * expresa de A Toda Hora S.A o de quién represente sus derechos.
 */
package co.com.ath.pgw.persistence.dao;

import java.util.List;

import co.com.ath.pgw.persistence.DataAccessObject;
import co.com.ath.pgw.persistence.model.Bank;

/**
 * Objeto de Acceso a Datos para las entidades Bank
 * 
 * @author proveedor_zagarcia
 * @version 1.0
 * @since 1.0
 * 
 * 
 * @RQ30455 <strong>Autor</strong>Camilo Bustamante</br>
 *          <strong>Descripcion</strong>Permitir Compartir Recaudos PSE</br>
 *          <strong>Numero de Cambios</strong>1</br>
 *          <strong>Identificador corto</strong>C01</br>
 * 
 * @PCI
 * <strong>Autor</strong>Nelly Rocio Linares</br>
 * <strong>Descripcion</strong>Se crea metodo para recuperar las entidades bancarias</br>
 * <strong>Numero de Cambios</strong>1</br>
 * <strong>Identificador corto</strong>C02</br>
 *          
 * 
 * 
 */
public interface BankDAO extends DataAccessObject<Bank> {

	/** INICIO-C01 **/
	Bank findById(Long bankId);

	/** FIN-C01 **/

	Bank findByAVALCode(String avalCode);

	Bank findByACHCode(String achCode);

	Bank findByBANREPUBLICACode(String banrepCode);

	/***INICIO-C02*/
	List<Bank> findByIsAval(Long valor);
	/***FIN-C02*/

}
