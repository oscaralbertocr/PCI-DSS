/*
 * GenericQueryDAOImpl
 *  
 * GSI - Integración
 * Creado el: 14/04/2015
 *
 * Copyright (c) A Toda Hora S.A. Todos los derechos reservados
 * 
 * Este software es confidencial y es propietario de ATH, queda prohibido
 * su uso, reproducción y copia de manera parcial o permanente salvo autorización
 * expresa de A Toda Hora S.A o de quién represente sus derechos.
 */
package co.com.ath.pgw.persistence.dao.impl;

import java.sql.Timestamp;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.NoResultException;
import javax.persistence.NonUniqueResultException;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import co.com.ath.pgw.persistence.dao.GenericQueryDAO;
import co.com.ath.pgw.persistence.model.BatchJobExecution;

/**
 * Class description goes here...
 *
 * @author Andrés Méndez Juanias <proveedor_mamendez@ath.com.co> 
 * @version 1.0 14/04/2015
 * @since 1.0
 * 
 * @IM714148  
 * <strong>Autor</strong>Andres Eduardo Hernandez</br>
 * <strong>Descripcion</strong>Extracto Digital Pagos PSE</br>
 * <strong>Numero de Cambios</strong>1</br>
 * <strong>Identificador corto</strong>C01</br>
 * 
 *  @IM714148
 *  <strong>Autor</strong>Camilo Bustamante</br>
 *  <strong>Descripcion</strong>Correccion fechas en querys de reportes</br>
 *  <strong>Numero de Cambios</strong>2</br>
 *  <strong>Identificador corto</strong>C02</br>
 * 
 */
@Service
public class GenericQueryDAOImpl implements GenericQueryDAO {
	
	static Logger LOGGER = LoggerFactory.getLogger(GenericQueryDAOImpl.class);
	
	@PersistenceContext
	protected EntityManager entityManager;

	/* (non-Javadoc)
	 * @see co.com.ath.pgw.persistence.dao.GenericQueryDAO#findMaxDateBatch(java.lang.String)
	 */
	@Override
	public Date findMaxDateBatch(String jobName) {
		StringBuilder jpql = new StringBuilder();
		jpql.append(" SELECT MAX(bex.createTime) FROM BatchJobExecution bex ");
		jpql.append(" WHERE bex.batchJobInstance.jobName = :jobName ");
		
		Query query = entityManager.createQuery(jpql.toString());
		query.setParameter("jobName", jobName);
		
		Date date = null;
		try {
			date = (Date)query.getSingleResult();
		} catch(NoResultException ex){
			date = null;
		} catch(NonUniqueResultException ex){
			LOGGER.warn("Error en query: \n{}", ex.toString());
		}
		return date;
	}
	
	/**INICIO-C01*/
	@SuppressWarnings("unchecked")
	@Override
	public List<BatchJobExecution> findByJobName( String jobName ) {
		Calendar c = Calendar.getInstance();
		Date curDate = c.getTime();
		
		/**INICIO-C02**/
		Timestamp startDate = mergeDate(curDate, "00:00:00.000000000");
		Timestamp endDate = mergeDate(curDate, "23:59:59.999999999");
		/**FIN-C02**/
		
		StringBuilder jpql = new StringBuilder();
		jpql.append(" SELECT bex FROM BatchJobExecution bex ");
		jpql.append(" WHERE bex.batchJobInstance.jobName = :jobName ");
		jpql.append(" AND bex.createTime BETWEEN :startDate AND :endDate ");
		
        Query query = entityManager.createQuery(jpql.toString());
		query.setParameter("jobName", jobName);
		query.setParameter("startDate", startDate);
		query.setParameter("endDate", endDate);
		
		List<BatchJobExecution> batchJobExecutionList = query.getResultList();
		return batchJobExecutionList;
	}
	
	/**INICIO-C02**/
	private Timestamp mergeDate(Date date, String hora) {

        Calendar cal = Calendar.getInstance();
		StringBuilder sb = new StringBuilder();
		cal.setTime(date);
		sb.append(cal.get(Calendar.YEAR));
        sb.append("-");
		sb.append(cal.get(Calendar.MONTH)+1);
        sb.append("-");
		sb.append(cal.get(Calendar.DAY_OF_MONTH));
		sb.append(" ");
		sb.append(hora);
		try {
			return Timestamp.valueOf(sb.toString());
		} catch (Exception e) {
			LOGGER.error("Error realizando el parceo de la Fecha para consultar el estado de la Sonda:", ""+date+" - "+hora, e.toString());
			/*LOGGER.error("Error realizando el parceo de la Fecha para consultar el estado de la Sonda:", 
					date, hora, e.toString());*/
			return null;
		}
	}
	/**FIN-C02**/
	
	@Override
	public boolean findBatchParams( long idExecution, String keyName, String stringVal ) {

		StringBuilder jpql = new StringBuilder();
		jpql.append(" SELECT bexp.stringVal FROM BatchJobExecutionParams bexp ");
		jpql.append(" WHERE bexp.jobExecutionId = :idExecution ");
		jpql.append(" AND bexp.keyName = :keyName ");
		jpql.append(" AND bexp.stringVal = :stringVal ");
		
        Query query = entityManager.createQuery(jpql.toString());
		query.setParameter("idExecution", String.valueOf(idExecution));
		query.setParameter("keyName", keyName);
		query.setParameter("stringVal", stringVal);
		
		String value = null;
		try {
			value = (String)query.getSingleResult();
		} catch(NoResultException ex){
		} catch(NonUniqueResultException ex){
			LOGGER.warn("Error en query: \n{}", ex.toString());
		}
		if( value != null ) {
			return true;	
		}
		return false;
	}
	/**FIN-C01*/
	
}
