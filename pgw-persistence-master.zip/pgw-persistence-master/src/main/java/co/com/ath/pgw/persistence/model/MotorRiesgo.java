package co.com.ath.pgw.persistence.model;

import java.math.BigDecimal;
import java.math.BigInteger;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import co.com.ath.pgw.persistence.PersistentObject;

/**
 * 
 * @author proveedor_cbustamant
 */
@Entity
@Table(name = "MOTORRIESGO")
public class MotorRiesgo implements PersistentObject {

	private static final long serialVersionUID = 1L;

	@Id
	@SequenceGenerator(
			name="ID_GENERATOR_SEQ_MOTORRIESGO",
			sequenceName="SEQ_MOTORRIESGO",
			initialValue=1,
			allocationSize=1
			)
	@GeneratedValue(
			strategy=GenerationType.SEQUENCE,
			generator="ID_GENERATOR_SEQ_MOTORRIESGO"
			)
	@Column(name = "MOTOR_ID")
	private BigDecimal Id;
	
	@Column(name = "PMTID")
	private BigInteger pmtid;
	
	@Column(name = "DEVICEPRINT", length=3000)
	private String deviceprint;
	
	@Column(name = "IPADDRESS", length=39)
	private String ipaddress;
	
	@Column(name = "RISKTYPE", length=20)
	private String risktype;
	
	@Column(name = "METODOMOTOR", length=20)
	private String metodoMotor;
	
	@Column(name = "STATUSCODE", length=20)
	private String statuscode;
	
	@Column(name = "DEVICETOKENCOOKIE", length=3000)
	private String devicetokencookie;

	@Column(name = "USERSTATUS", length=20)
	private String userstatus;

	@Column(name = "HTTPACCEPT", length=500)
	private String httpAccept;
	
	@Column(name = "HTTPACCEPTLANGUAGE", length=200)
	private String httpAcceptLanguage;
	
	@Column(name = "HTTPREFERRER", length=500)
	private String httpReferrer;
	
	@Column(name = "USERAGENT", length=500)
	private String userAgent;
	
	
	/**
	 * Indica si el registro tiene marca de borrado lógico.
	 */
	@Column(name = "REGELIMINADO")
	private boolean rowDeleted;

	/**
	 * Fecha de creación del registro.
	 */
	@Column(name = "REGFECHACREACION", nullable=false)
	@Temporal(TemporalType.TIMESTAMP)
	private Date rowCreationDate;

	/**
	 * Fecha de la última modificación del registro.
	 */
	@Column(name = "REGFECHAMODIFICACION")
	@Temporal(TemporalType.TIMESTAMP)
	private Date rowLastUpdate;

	public MotorRiesgo() {
	}

	public MotorRiesgo(BigDecimal motorId) {
		this.Id = motorId;
	}

	public BigDecimal getId() {
		return Id;
	}

	public BigInteger getPmtid() {
		return pmtid;
	}

	public void setPmtid(BigInteger pmtid) {
		this.pmtid = pmtid;
	}

	public String getDeviceprint() {
		return deviceprint;
	}

	public void setDeviceprint(String deviceprint) {
		this.deviceprint = deviceprint;
	}

	public String getIpaddress() {
		return ipaddress;
	}

	public void setIpaddress(String ipaddress) {
		this.ipaddress = ipaddress;
	}

	public String getRisktype() {
		return risktype;
	}

	public void setRisktype(String risktype) {
		this.risktype = risktype;
	}

	public String getMetodoMotor() {
		return metodoMotor;
	}

	public void setMetodoMotor(String metodoMotor) {
		this.metodoMotor = metodoMotor;
	}
	
	public String getStatuscode() {
		return statuscode;
	}

	public void setStatuscode(String statuscode) {
		this.statuscode = statuscode;
	}

	public String getDevicetokencookie() {
		return devicetokencookie;
	}

	public void setDevicetokencookie(String devicetokencookie) {
		this.devicetokencookie = devicetokencookie;
	}

	public String getUserstatus() {
		return userstatus;
	}

	public void setUserstatus(String userstatus) {
		this.userstatus = userstatus;
	}
	
	public String getHttpAccept() {
		return httpAccept;
	}

	public void setHttpAccept(String httpAccept) {
		this.httpAccept = httpAccept;
	}

	public String getHttpAcceptLanguage() {
		return httpAcceptLanguage;
	}

	public void setHttpAcceptLanguage(String httpAcceptLanguage) {
		this.httpAcceptLanguage = httpAcceptLanguage;
	}

	public String getHttpReferrer() {
		return httpReferrer;
	}

	public void setHttpReferrer(String httpReferrer) {
		this.httpReferrer = httpReferrer;
	}

	public String getUserAgent() {
		return userAgent;
	}

	public void setUserAgent(String userAgent) {
		this.userAgent = userAgent;
	}
	
	@Override
	public boolean isRowDeleted() {
		return rowDeleted;
	}

	@Override
	public void setRowDeleted(boolean rowDeleted) {
		this.rowDeleted = rowDeleted;
	}

	@Override
	public Date getRowCreationDate() {
		return rowCreationDate;
	}

	@Override
	public void setRowCreationDate(Date rowCreationDate) {
		this.rowCreationDate = rowCreationDate;
	}

	@Override
	public Date getRowLastUpdate() {
		return rowLastUpdate;
	}

	@Override
	public void setRowLastUpdate(Date rowLastUpdate) {
		this.rowLastUpdate = rowLastUpdate;
	}

}
