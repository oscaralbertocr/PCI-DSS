package co.com.ath.pgw.persistence.model;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import co.com.ath.pgw.persistence.PersistentObject;

/**
 * Clase que representa los correos establecidos de parametrización de envío de correo
 * 
 * @author proveedor_jlara
 * @version 1.0 23 Nov 2016
 * @since 1.0
 */
@Entity
@Table(name="CORREOSGENERALES")
public class GeneralEmail implements PersistentObject{
	private static final long serialVersionUID = 8658947969768783083L;
	
	@Id
    @Column(name="IDCORREOGENERAL")
	private String idCorreoGeneral;
	
	@Column(name="PARAMETRO1")
	private String parametro1;
	
	@Column(name="IDBLOQUEOJOB")
	private Long idbloqueojob;
	
	@Column(name="REGELIMINADO")
	private boolean rowDeleted;
	
	@Column(name="REGFECHACREACION")
    @Temporal(TemporalType.TIMESTAMP)
	private Date rowCreationDate;
	
	@Temporal(TemporalType.TIMESTAMP)
	@Column(name="REGFECHAMODIFICACION", nullable=true)
	private Date rowLastUpdate;
	
	public String getIdCorreoGeneral() {
		return idCorreoGeneral;
	}

	public void setIdCorreoGeneral(String idCorreoGeneral) {
		this.idCorreoGeneral = idCorreoGeneral;
	}

	public String getParametro1() {
		return parametro1;
	}

	public void setParametro1(String parametro1) {
		this.parametro1 = parametro1;
	}

	public Long getIdbloqueojob() {
		return idbloqueojob;
	}

	public void setIdbloqueojob(Long idbloqueojob) {
		this.idbloqueojob = idbloqueojob;
	}

	@Override
	public boolean isRowDeleted() {
		return rowDeleted;
	}

	@Override
	public void setRowDeleted(boolean rowDeleted) {
		this.rowDeleted = rowDeleted;
	}

	@Override
	public Date getRowCreationDate() {
		return rowCreationDate;
	}

	@Override
	public void setRowCreationDate(Date rowCreationDate) {
		this.rowCreationDate = rowCreationDate;
	}

	@Override
	public Date getRowLastUpdate(){
		return rowLastUpdate;
	}

	@Override
	public void setRowLastUpdate(Date rowLastUpdate){
		this.rowLastUpdate = rowLastUpdate;
	}
}
