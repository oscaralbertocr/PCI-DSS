package co.com.ath.pgw.persistence.dao.impl;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.Query;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Repository;

import co.com.ath.pgw.persistence.AbstractDAO_JPA;
import co.com.ath.pgw.persistence.dao.PaymentWayByCommerceDAO;
import co.com.ath.pgw.persistence.model.Bank;
import co.com.ath.pgw.persistence.model.Commerce;
import co.com.ath.pgw.persistence.model.PaymentWayByCommerce;

/**
 * Implementación por defecto de PaymentWayByCommerceDAO
 * 
 * @author proveedor_jlara
 * @version 1.0 01 Dic 2016
 * @since 1.0
 */
@Repository
public class PaymentWayByCommerceDAOImpl extends AbstractDAO_JPA<PaymentWayByCommerce> 
implements PaymentWayByCommerceDAO{
	
	static Logger LOGGER = LoggerFactory.getLogger(PaymentWayByCommerceDAOImpl.class);

	/**
	 * Constructor por defecto
	 */
	public PaymentWayByCommerceDAOImpl() {
		super(PaymentWayByCommerce.class);
	}
	
	
	@SuppressWarnings("unchecked")
	@Override
	public PaymentWayByCommerce findByComerce(Long idComercio) {
		StringBuilder hql = new StringBuilder("from PaymentWayByCommerce pwc ");
		hql.append("where pwc.rowDeleted <> 1 ");
		hql.append("and pwc.paymentWay.id = 2 ");
		hql.append("and pwc.commerce.id = :idComercio ");
		
        Query query = entityManager.createQuery(hql.toString());
		query.setParameter("idComercio", idComercio);
		
		PaymentWayByCommerce paymentWayByCommerce = null;
		try {
			paymentWayByCommerce = (PaymentWayByCommerce) query.getSingleResult();
		} catch (Exception e) {
			LOGGER.error("Error PaymentWayByCommerceDAOImpl -> findByComerce en query: {}", e);
			return null;
		}
		
		return paymentWayByCommerce;
	}
	
	
	
}
