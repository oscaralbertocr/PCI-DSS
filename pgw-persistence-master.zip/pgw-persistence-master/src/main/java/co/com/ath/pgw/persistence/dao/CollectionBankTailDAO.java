/*
 * CollectionBankTailDAO
 *
 * GSI - Integración
 * Creado el: 22 de agosto de 2014
 *
 * Copyright (c) A Toda Hora S.A. Todos los derechos reservados
 *
 * Este software es confidencial y es propietario de ATH, queda prohibido
 * su uso, reproducción y copia de manera parcial o permanente salvo autorización
 * expresa de A Toda Hora S.A o de quién represente sus derechos.
 */
package co.com.ath.pgw.persistence.dao;

import co.com.ath.pgw.persistence.DataAccessObject;
import co.com.ath.pgw.persistence.model.Bank;
import co.com.ath.pgw.persistence.model.CollectionBankTail;

/**
 * Objeto de Acceso a Datos para la entidad
 *
 * @author Camilo Andres Bustamante <camilo.bustamante@sophossolutions.com>
 * @version 1.0 11/07/2018
 * @since 1.0
 */
public interface CollectionBankTailDAO extends DataAccessObject<CollectionBankTail>{

	public Bank getCollectionBank();
	
}
