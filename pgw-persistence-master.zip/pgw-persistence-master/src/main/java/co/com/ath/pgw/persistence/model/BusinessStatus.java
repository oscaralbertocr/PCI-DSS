/*
 * TransactionStatus
 *  
 * GSI - Integracion
 * Creado el: 21/10/2014
 *
 * Copyright (c) A Toda Hora S.A. Todos los derechos reservados
 * 
 * Este software es confidencial y es propietario de ATH, queda prohibido
 * su uso, reproduccion y copia de manera parcial o permanente salvo autorizacion
 * expresa de A Toda Hora S.A o de quien represente sus derechos.
 */
package co.com.ath.pgw.persistence.model;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import co.com.ath.pgw.persistence.PersistentObject;
import co.com.ath.pgw.util.enums.BusinessStatusEnum;


/**
 * The persistent class for the ESTADOSNEGOCIO database table.
 * 
 */
@Entity
@Table(name="ESTADOSNEGOCIO")
public class BusinessStatus implements PersistentObject {
	
	private static final long serialVersionUID = 1L;

	@Id
	@Column(name="ID")
	private long code;

	@Column(name="ESTADO")
	@Enumerated(EnumType.STRING)
	private BusinessStatusEnum description;

	@Column(name="REGELIMINADO", nullable=true)
	private boolean rowDeleted;

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name="REGFECHACREACION")
	private Date rowCreationDate;

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name="REGFECHAMODIFICACION")
	private Date rowLastUpdate;

	public BusinessStatus() {
		super();
    }

	public long getCode() {
		return this.code;
	}

	public void setCode(long code) {
		this.code = code;
	}

	public BusinessStatusEnum getDescription() {
		return description;
	}

	public void setDescription(BusinessStatusEnum description) {
		this.description = description;
	}

	@Override
	public boolean isRowDeleted() {
		return rowDeleted;
	}

	@Override
	public void setRowDeleted(boolean rowDeleted) {
		this.rowDeleted = rowDeleted;
	}

	@Override
	public Date getRowCreationDate() {
		return rowCreationDate;
	}

	@Override
	public void setRowCreationDate(Date rowCreationDate) {
		this.rowCreationDate = rowCreationDate;
	}

	@Override
	public Date getRowLastUpdate() {
		return rowLastUpdate;
	}

	@Override
	public void setRowLastUpdate(Date rowLastUpdate) {
		this.rowLastUpdate = rowLastUpdate;
	}


	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + (int) (code ^ (code >>> 32));
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		BusinessStatus other = (BusinessStatus) obj;
		if (code != other.code)
			return false;
		return true;
	}
	
	@Override
	public String toString() {
		return "BusinessStatus [code=" + code + ", description=" + description
				+ "]";
	}
		
	
}