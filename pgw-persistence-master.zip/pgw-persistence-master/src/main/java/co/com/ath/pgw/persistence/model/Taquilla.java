/*
 * Transactions
 *  
 * GSI - Integración
 * Creado el: 29/08/2014
 *
 * Copyright (c) A Toda Hora S.A. Todos los derechos reservados
 * 
 * Este software es confidencial y es propietario de ATH, queda prohibido
 * su uso, reproducción y copia de manera parcial o permanente salvo autorización
 * expresa de A Toda Hora S.A o de quién represente sus derechos.
 */
package co.com.ath.pgw.persistence.model;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import co.com.ath.pgw.persistence.PersistentObject;

/**
 * Representa las taquillas en el Core de la Pasarela de Pago. 
 * 
 * @author proveedor_cbustamant
 * @version 1.0 22 Marzo 2017
 * @since 1.0
 */
@Entity
@Table(name="TAQUILLAS")
public class Taquilla implements PersistentObject {

	private static final long serialVersionUID = 1L;

	/**
	 * IDENTIFICADOR DE LA TAQUILLA
	 */
	@Id
	@Column(name="IDTAQUILLAS", unique=true, scale=22, precision=0)
	private Integer idTaquilla;
	
	/**
	 * NOMBRE DE LA TAQUILLA
	 */
	@Column(name="NOMBRE")
	private String nombre;
	
	/**
	 * URL DEL CSS DE LA TAQUILLA
	 */
	@Column(name="CSS")
	private String css;
	
	/**
	 * URL DEL FOOTER DE LA TAQUILLA
	 */
	@Column(name="FOOTER")
	private String footer;

	/**
	 * FECHA DE CREACION
	 */
	@Temporal(TemporalType.TIMESTAMP)
	@Column(name="REGFECHACREACION")
	private Date rowCreationDate;
	
	/**
	 * FECHA DE MODIFICACION
	 */
	@Temporal(TemporalType.TIMESTAMP)
	@Column(name="REGFECHAMODIFICACION")
	private Date rowLastUpdate;

	/**
	 * Indica si el registro tiene marca de borrado lógico.
	 */
	@Column(name = "REGELIMINADO")
	private boolean rowDeleted;
	
		
	public Integer getIdTaquilla() {
		return idTaquilla;
	}

	public void setIdTaquilla(Integer idTaquilla) {
		this.idTaquilla = idTaquilla;
	}

	public String getNombre() {
		return nombre;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	public String getCss() {
		return css;
	}

	public void setCss(String css) {
		this.css = css;
	}

	public String getFooter() {
		return footer;
	}

	public void setFooter(String footer) {
		this.footer = footer;
	}

	@Override
	public boolean isRowDeleted() {
		return rowDeleted;
	}

	@Override
	public void setRowDeleted(boolean rowDeleted) {
		this.rowDeleted = rowDeleted;
	}

	@Override
	public Date getRowCreationDate() {
		return rowCreationDate;
	}

	@Override
	public void setRowCreationDate(Date rowCreationDate) {
		this.rowCreationDate = rowCreationDate;
	}

	@Override
	public Date getRowLastUpdate() {
		return rowLastUpdate;
	}

	@Override
	public void setRowLastUpdate(Date rowLastUpdate) {
		this.rowLastUpdate = rowLastUpdate;
	}
	
}