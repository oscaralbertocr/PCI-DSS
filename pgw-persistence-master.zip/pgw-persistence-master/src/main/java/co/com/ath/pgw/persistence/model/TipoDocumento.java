package co.com.ath.pgw.persistence.model;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import co.com.ath.pgw.persistence.PersistentObject;

/**
 * 
 * @author proveedor_cbustamant
 */
@Entity
@Table(name = "TIPODOCUMENTO")
public class TipoDocumento implements PersistentObject {

	private static final long serialVersionUID = 1L;
	@Id
	@Column(name = "TIPODOC_ID")
	private String tipoDocId;

	@Column(name = "TIPODOC_DESCRIPCION")
	private String tipoDocDescripcion;

	@Column(name = "TIPODOC_CODIGO")
	private short tipoDocCodigo;

	/**
	 * Indica si el registro tiene marca de borrado lógico.
	 */
	@Column(name = "REGELIMINADO")
	private boolean rowDeleted;

	/**
	 * Fecha de creación del registro.
	 */
	@Column(name = "REGFECHACREACION")
	@Temporal(TemporalType.TIMESTAMP)
	private Date rowCreationDate;

	/**
	 * Fecha de la última modificación del registro.
	 */
	@Column(name = "REGFECHAMODIFICACION")
	@Temporal(TemporalType.TIMESTAMP)
	private Date rowLastUpdate;

	public TipoDocumento() {
	}

	public TipoDocumento(String tipoDocId) {
		this.tipoDocId = tipoDocId;
	}

	public String getTipoDocId() {
		return tipoDocId;
	}

	public void setTipodocId(String tipoDocId) {
		this.tipoDocId = tipoDocId;
	}

	public String getTipoDocDescripcion() {
		return tipoDocDescripcion;
	}

	public void setTipodocDescripcion(String tipoDocDescripcion) {
		this.tipoDocDescripcion = tipoDocDescripcion;
	}

	public short getTipoDocCodigo() {
		return tipoDocCodigo;
	}

	public void setTipodocCodigo(short tipoDocCodigo) {
		this.tipoDocCodigo = tipoDocCodigo;
	}

	@Override
	public boolean isRowDeleted() {
		return rowDeleted;
	}

	@Override
	public void setRowDeleted(boolean rowDeleted) {
		this.rowDeleted = rowDeleted;
	}

	@Override
	public Date getRowCreationDate() {
		return rowCreationDate;
	}

	@Override
	public void setRowCreationDate(Date rowCreationDate) {
		this.rowCreationDate = rowCreationDate;
	}

	@Override
	public Date getRowLastUpdate() {
		return rowLastUpdate;
	}

	@Override
	public void setRowLastUpdate(Date rowLastUpdate) {
		this.rowLastUpdate = rowLastUpdate;
	}

}
