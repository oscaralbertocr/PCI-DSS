package co.com.ath.pgw.persistence.util.converter;

import java.security.SecureRandom;
import java.util.Date;

import co.com.ath.pgw.bsn.dto.in.TokenizeInDTO;
import co.com.ath.pgw.bsn.model.bo.BankBO;
import co.com.ath.pgw.bsn.model.bo.UserBO;
import co.com.ath.pgw.persistence.model.Transaction;

/**
 * Convertidor de objetos que vienen de los servicios a objetos del core
 * 
 * @author proveedor_sredondo
 * @version 1.0
 * @since 1.0
 */

public class PaymentsBsnObjectsConverterUtil {

	private static final String BANK_PPA = "CorePasarela";
	private static final String BANK_PPA_ID = "901";
	/**
	 * Convierte de Transaction a TokenizeInDTO
	 * 
	 * @param transaction
	 */
	public static TokenizeInDTO toTokenizeInDTO(Transaction transaction) {
		TokenizeInDTO tokenizeInDTO = new TokenizeInDTO();
		tokenizeInDTO.setClientDt(new Date());
		tokenizeInDTO.setIpAddr(transaction.getIpAddress());
		
		if (transaction.getRquId() != null) {
			tokenizeInDTO.setRqUID(Long.valueOf(transaction.getRquId()));
		} else {
			SecureRandom codGen = new SecureRandom();
			Long temporalRqid = codGen.nextLong();
			if (temporalRqid <= 0) {
				temporalRqid = temporalRqid * (-1);
			}
			tokenizeInDTO.setRqUID(temporalRqid);
		}
		tokenizeInDTO.setChannel(transaction.getTrnChannel());
		
		UserBO userBO = new UserBO();
		userBO.setCustIdNum(transaction.getCustomerDocId());
		userBO.setCustIdType(transaction.getCustomerDocType());

		// TODO: Mapear de acuerdo a especificacion o eliminar
		BankBO bankBO = new BankBO();
		bankBO.setId(0l);
		bankBO.setName(BANK_PPA);
		bankBO.setBranchId(BANK_PPA_ID);

		tokenizeInDTO.setUserBO(userBO);
		tokenizeInDTO.setBankBO(bankBO);

		return tokenizeInDTO;

	}

}
