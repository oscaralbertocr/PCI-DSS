/*
 * DocumentTypeValidator
 *  
 * GSI - Integración
 * Creado el: 22/09/2014
 *
 * Copyright (c) A Toda Hora S.A. Todos los derechos reservados
 * 
 * Este software es confidencial y es propietario de ATH, queda prohibido
 * su uso, reproducción y copia de manera parcial o permanente salvo autorización
 * expresa de A Toda Hora S.A o de quién represente sus derechos.
 */
package co.com.ath.pgw.persistence.validation.model.impl;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import co.com.ath.pgw.util.enums.DocumentTypesEnum;
import co.com.ath.pgw.util.i18n.BundleKeys;
import co.com.ath.pgw.util.i18n.BundleType;
import co.com.ath.pgw.util.validation.AbstractAttributeValidator;
import co.com.ath.pgw.util.validation.ErrorCode;
import co.com.ath.pgw.util.validation.NotEmptyValidator;
import co.com.ath.pgw.util.validation.NotNullValidator;
import co.com.ath.pgw.util.validation.ObjectValidationException;
import co.com.ath.pgw.util.validation.ObjectValidator;
import co.com.ath.pgw.util.validation.ValidationException;

/**
 * Validador de tipos de documento de identidad.
 * 
 * @author proveedor_zagarcia
 * @version 1.0 22 Sep 2014
 * @since 1.0
 */
@Service
public class DocumentTypeValidator extends AbstractAttributeValidator {
	
	static Logger LOGGER = LoggerFactory.getLogger(DocumentTypeValidator.class);

	private ObjectValidator validator;
	
	private List<String> documentTypes;

	public DocumentTypeValidator(){
		documentTypes = new ArrayList<String>();
		documentTypes.add(DocumentTypesEnum.CC.name()); //Cédula de ciudadanía.
		documentTypes.add(DocumentTypesEnum.CE.name()); //Cédula de extranjería.
		documentTypes.add(DocumentTypesEnum.TI.name()); //Tarjeta de identidad.
		documentTypes.add(DocumentTypesEnum.PP.name()); //Pasaporte.
		documentTypes.add(DocumentTypesEnum.RC.name()); //Registro civil.
		documentTypes.add(DocumentTypesEnum.NIT.name()); //NIT.
		documentTypes.add(DocumentTypesEnum.GUEST.name()); //Invitado.
	}

	@Override
	protected void doMandatoryValidate(Object attribute, Locale locale)
			throws ValidationException {
		validator = new NotNullValidator(new NotEmptyValidator());
		validator.setBundleManager(bundleManager);
		try {
			validator.validate(attribute, locale);
		} catch (ObjectValidationException e) {
			LOGGER.warn("Fallo en validador: \n{}", e.toString());
			throw new ValidationException(
					getMessage(locale), 
					ErrorCode.INVALID_DOCUMENT_TYPE, e);
		}
		doOptionalValidate(attribute, locale);
		
	}

	@Override
	protected void doOptionalValidate(Object attribute, Locale locale)
			throws ValidationException {
		if (attribute == null || attribute.toString().trim().length() == 0) {
			return;
		}
		if (!documentTypes.contains(attribute.toString())) {
			throw new ValidationException(
					getMessage(locale), 
					ErrorCode.INVALID_DOCUMENT_TYPE,
					getDocTypeNotFndEx(attribute, locale));
		}
	}
	
	private String getMessage(Locale locale) {
		if (bundleManager == null) {
			return BundleKeys.ERROR_INVALID_DOCUMENT_TYPE;
		}
		bundleManager.setBundle(BundleType.ERRORS);
		return bundleManager.getMessage(
			BundleKeys.ERROR_INVALID_DOCUMENT_TYPE, null, locale);
	}
	
	/**
	 * Retorna la excepción para tipo de documento no encontrado.
	 * 
	 * @param obj		Tipo de documento.
	 * @param locale	Localización.
	 * @return			Excepción para tipo de documento no encontrado.
	 */
	private ObjectValidationException getDocTypeNotFndEx(Object obj, 
														 Locale locale){
		String message = "validation.4.notfound";
		if (bundleManager != null) {
			bundleManager.setBundle(BundleType.ERRORS);
			message = bundleManager.getMessage(
					message, new Object[]{obj}, locale);
		}
		return new ObjectValidationException(message);
		
	}


}