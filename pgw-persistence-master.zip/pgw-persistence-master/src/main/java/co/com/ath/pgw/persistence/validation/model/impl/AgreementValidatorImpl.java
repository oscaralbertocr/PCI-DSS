/*
 * AgreementValidator
 *
 * GSI - Integración
 * Creado el: 18 de septiembre de 2014
 *
 * Copyright (c) A Toda Hora S.A. Todos los derechos reservados
 *
 * Este software es confidencial y es propietario de ATH, queda prohibido
 * su uso, reproducción y copia de manera parcial o permanente salvo autorización
 * expresa de A Toda Hora S.A o de quién represente sus derechos.
 */
package co.com.ath.pgw.persistence.validation.model.impl;
import java.util.Locale;

import javax.annotation.Resource;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import co.com.ath.pgw.persistence.dao.CommerceDAO;
import co.com.ath.pgw.persistence.model.Commerce;
import co.com.ath.pgw.util.constants.CoreConstants;
import co.com.ath.pgw.util.i18n.BundleKeys;
import co.com.ath.pgw.util.i18n.BundleType;
import co.com.ath.pgw.util.i18n.ResourceBundleManager;
import co.com.ath.pgw.util.validation.ErrorCode;
import co.com.ath.pgw.util.validation.ObjectValidationException;
import co.com.ath.pgw.util.validation.ValidationException;
import co.com.ath.pgw.util.validation.model.AgreementAuthenticatorValidator;
import co.com.ath.pgw.util.validation.model.AgreementValidator;


/**
 * Validador de convenios (Comercios).
 * 
 * @author proveedor_zagarcia
 * @version 1.0 18 Sep 2014
 * @since 1.0
 */
@Service
public class AgreementValidatorImpl implements AgreementValidator {
	private static Logger LOGGER = LoggerFactory.getLogger(AgreementAuthenticatorValidator.class);
	
	@Autowired
	private ResourceBundleManager bundleManager;

	@Resource
	private CommerceDAO commerceDAO;

	public AgreementValidatorImpl(){
		super();
	}
	
	@Override
	public void validate(String nuraCode, Locale locale) throws ValidationException {
		Commerce commerce = commerceDAO.findByNura(nuraCode);
		// Validar si esta inactivo
		if (commerce != null && !CoreConstants.ONE.equals(commerce.getStatus())) {
			commerce = null;
		}
		if (commerce == null) {
			ValidationException ve = new ValidationException(
					getMessage(locale),
					ErrorCode.INVALID_AGREEMENT_ID,
					getNotFoundCommerceEx(nuraCode, locale));
			LOGGER.warn("Fallo en validador: \n{}", ve.toString());
			throw ve;
		}
	}
	
	private String getMessage(Locale locale) {
	if (bundleManager == null) {
		return BundleKeys.ERROR_INVALID_AGREEMENT_ID;
	}
	bundleManager.setBundle(BundleType.ERRORS);
	return bundleManager.getMessage(BundleKeys.ERROR_INVALID_AGREEMENT_ID, null, locale);
}
	
	/**
	 * Retorna la excepción de comercio no encontrado, en caso de ser requerido.
	 * 
	 * @param nuraCode	Código NURA
	 * @param locale 	Localización.
	 * 
	 * @return ObjectValidationException con la descripción del error.
	 */
	private ObjectValidationException getNotFoundCommerceEx(String nuraCode, Locale locale){
		String message = "validation.6.notfound";
		if (bundleManager != null) {
			bundleManager.setBundle(BundleType.ERRORS);
			message = bundleManager.getMessage(
					message, new Object[]{nuraCode}, locale);
		}
		return new ObjectValidationException(message);
	}
	

//	static Logger LOGGER = LoggerFactory.getLogger(AgreementValidatorImpl.class);
//	
//	private ObjectValidator validator;
//	
//	@Resource
//	private CommerceDAO commerceDAO;
//	
//	public AgreementValidatorImpl(){
//		super();
//	}
//
//	@Override
//	protected void doMandatoryValidate(Object attribute, Locale locale) 
//													throws ValidationException {
//		validator = new NotNullValidator(new NotEmptyValidator());
//		validator.setBundleManager(bundleManager);
//		try {
//			validator.validate(attribute, locale);
//		} catch (ObjectValidationException e) {
//			LOGGER.warn("Fallo en validador: \n{}", e.toString());
//			throw new ValidationException(
//					getMessage(locale), 
//						ErrorCode.INVALID_AGREEMENT_ID, e);
//		}
//		doOptionalValidate(attribute, locale);
//	}
//
//	@Override
//	protected void doOptionalValidate(Object attribute, Locale locale) 
//													throws ValidationException {
//		if (attribute == null || attribute.toString().trim().length() == 0) {
//			return;
//		}
//		validator = new IntValueValidator();
//		validator.setBundleManager(bundleManager);
//		try {
//			validator.validate(attribute, locale);
//		} catch (ObjectValidationException e) {
//			ValidationException ve = new ValidationException(
//					getMessage(locale), 
//						ErrorCode.INVALID_AGREEMENT_ID, e);
//			LOGGER.warn("Fallo en validador: \n{}", ve.toString());
//			throw ve;
//		}
//		validateExistenceStatus(attribute,locale);
//	}
//
//	/**
//	 * Valida que el convenio exista.
//	 * 
//	 * @param attribute	Código nura
//	 * @param locale	Localización
//	 * @throws ValidationException 
//	 */
//	private void validateExistenceStatus(Object attribute, Locale locale) 
//													throws ValidationException {
//		Commerce commerce = commerceDAO.findByNura(attribute.toString());
//		// Validar si esta inactivo
//		if (commerce != null && !CoreConstants.ONE.equals(commerce.getStatus())) {
//			commerce = null;
//		}
//		if (commerce == null) {
//			throw new ValidationException(
//					getMessage(locale), 
//						ErrorCode.INVALID_AGREEMENT_ID, 
//						getNotFoundCommerceEx(locale, attribute));
//		}
//		
//	}
//
//	private String getMessage(Locale locale) {
//		if (bundleManager == null) {
//			return BundleKeys.ERROR_INVALID_AGREEMENT_ID;
//		}
//		bundleManager.setBundle(BundleType.ERRORS);
//		return bundleManager.getMessage(
//				BundleKeys.ERROR_INVALID_AGREEMENT_ID, null, locale);
//	}
//
//	/**
//	 * Retorna la excepción de comercio no encontrado, en caso de ser requerido.
//	 * 
//	 * @param locale 	Localización.
//	 * @param nuraCode	Código NURA
//	 * 
//	 * @return ObjectValidationException con la descripción del error. 
//	 */
//	private ObjectValidationException getNotFoundCommerceEx(Locale locale, 
//															Object nuraCode){
//		String message = "validation.6.notfound";
//		if (bundleManager != null) {
//			bundleManager.setBundle(BundleType.ERRORS);
//			message = bundleManager.getMessage(
//					message, new Object[]{nuraCode}, locale);
//		}
//		return new ObjectValidationException(message);
//	}
}