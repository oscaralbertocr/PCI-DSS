/*
 * AddAVALPaymentValidatorImpl
 *  
 * GSI - Integración
 * Creado el: 20/09/2014
 *
 * Copyright (c) A Toda Hora S.A. Todos los derechos reservados
 * 
 * Este software es confidencial y es propietario de ATH, queda prohibido
 * su uso, reproducción y copia de manera parcial o permanente salvo autorización
 * expresa de A Toda Hora S.A o de quién represente sus derechos.
 */
package co.com.ath.pgw.persistence.validation.model.impl;

import java.util.Date;
import java.util.Locale;

import javax.annotation.Resource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import co.com.ath.pgw.bsn.dto.in.GatewayCustLimitInDTO;
import co.com.ath.pgw.util.i18n.ResourceBundleManager;
import co.com.ath.pgw.util.validation.ValidationException;
import co.com.ath.pgw.util.validation.model.AdmCustLimitValidator;


/**
 * Implementación por defecto del validador admCustLimit Validacion de Topes.
 * 
 * @author Mauricio Tascon Hernandez
 * @version 0.0.0 23/08/2017
 */
@Service
public class AdmCustLimitValidatorImpl  implements AdmCustLimitValidator {

	@Autowired
	private ResourceBundleManager bundleManager;
    
    @Resource
	private TrxSourceValidator sourceValidator;
    
    @Resource
	private PaymentsWayValidator paymentsWayValidator;
	
	@Resource
	private RqDateValidator dateValidator;
	
	@Resource
	private IPAddressValidator ipAddressValidator;
	
	@Resource
	private DocumentTypeValidator docTypeValidator;
	
	@Resource
	private DocumentIdValidator docIdValidator;

	@Resource
	private AgreementValidatorImpl agreementValidator;


	@Resource
	private ObligatoryValidator obligatoryValidator;


	
	private Locale locale;

	public AdmCustLimitValidatorImpl() {
		this.locale = Locale.getDefault();
	}

	@Override
	public void validate(GatewayCustLimitInDTO inDTO) throws ValidationException {	
		validateRqUID(inDTO.getRqUID().toString());
        validateChannelSource(inDTO.getChannel());
        validateRqDate(inDTO.getClientDt());
        validateIpAddress(inDTO.getIpAddr());
        validateAgreement(inDTO.getAgreementId());
        validateTopeMaximo(String.valueOf(inDTO.getTransactionLimitBO().getTopAmt()));
        validateTopeMinimo(String.valueOf(inDTO.getTransactionLimitBO().getLstAmt()));
        validateMedioPgo(inDTO.getTransactionLimitBO().getPmtWayType());
	}
	
	
	@Override
	public void validateDelete(GatewayCustLimitInDTO inDTO) throws ValidationException {
		validateRqUID(inDTO.getRqUID().toString());
        validateChannelSource(inDTO.getChannel());
        validateRqDate(inDTO.getClientDt());
        validateIpAddress(inDTO.getIpAddr());
        validateAgreement(inDTO.getAgreementId());
        validateMedioPgo(inDTO.getTransactionLimitBO().getPmtWayType());
		
	}
	
	
	
	@Override
	public void validateFechaInicioFinal(GatewayCustLimitInDTO inDTO) throws ValidationException {	
        validateRqDate(inDTO.getTransactionLimitBO().getEffDt());
        validateRqDate(inDTO.getTransactionLimitBO().getEndDt());	
	}
	
	
	
	
	/**
	 * Realiza la validación del RqUID.
	 * 
	 * @param description
	 *            Descripción a validar.
	 * @throws ValidationException
	 *             En caso que falle la validación.
	 */
	private void validateRqUID(String RqUID)throws ValidationException {
		if(RqUID.equals("0"))
			RqUID="";
		obligatoryValidator.setMandatory(true);
		obligatoryValidator.setBundleManager(bundleManager);
		obligatoryValidator.validate(RqUID, locale);
	}
	
    
    /**
     * Realiza la validación de un canal de origen.
     * 
     * @param channelId Canal de origen.
     * @throws ValidationException 
     */
    private void validateChannelSource(String channelId) throws ValidationException {
    	sourceValidator.setMandatory(true);
		sourceValidator.setBundleManager(bundleManager);
		sourceValidator.validate(channelId, locale);	
	}
    

    /**
     * Realiza la validación de la fecha de solicitud.
     * 
     * @param clientDt				Fecha de solicitud.
     * @throws ValidationException	Si no supera las validaciones.
     */
	private void validateRqDate(Date clientDt) throws ValidationException {
		dateValidator.setMandatory(true);
		dateValidator.setBundleManager(bundleManager);
		dateValidator.validate(clientDt, locale);
	}

	/**
	 * Realiza la validación de la dirección IP origen de la transacción.
	 * 
	 * @param ipAddr 				Dirección ip origen.
	 * @throws ValidationException 	Si no supera las validaciones.
	 */
	private void validateIpAddress(String ipAddr) throws ValidationException {
		ipAddressValidator.setMandatory(true);
		ipAddressValidator.setBundleManager(bundleManager);
		ipAddressValidator.validate(ipAddr, locale);
	}

	/**
	 * Realiza la validación del tipo de documento del cliente.
	 * 
	 * @param customerDocType	Tipo de docuemnto del cliente.
	 * @throws ValidationException Si no supera las validaciones.
//	 */
//	private void validateDocType(String customerDocType) 
//													throws ValidationException {
//		docTypeValidator.setMandatory(true);
//		docTypeValidator.setBundleManager(bundleManager);
//		docTypeValidator.validate(customerDocType, locale);
//	}
//
//	/**
//	 * Realiza la validación del número de documento del cliente.
//	 * 
//	 * @param customerDocId Número de documento del cliente.
//	 * @throws ValidationException En caso de no superar la validación.
//	 */
//	private void validateDocId(String customerDocId) throws ValidationException {
//		docIdValidator.setMandatory(true);
//		docIdValidator.setBundleManager(bundleManager);
//		docIdValidator.validate(customerDocId, locale);
//	}
//    
//   
	/**
	 * Realiza la validación del convenio del comercio.
	 * 
	 * @param nuraCode
	 *            Código nura del comercio.
	 * @throws ValidationException
	 *             En caso que falle la validación.
	 */
	private void validateAgreement(String nuraCode) throws ValidationException {
//		agreementValidator.setMandatory(true);
//		agreementValidator.setBundleManager(bundleManager);
		agreementValidator.validate(nuraCode, locale);
	}


	
	private void validateTopeMaximo(String tope) throws ValidationException {
		if(tope=="null")
			tope="";
		obligatoryValidator.setMandatory(true);
		obligatoryValidator.setBundleManager(bundleManager);
		obligatoryValidator.validate(tope, locale);
		
	}
	
	
	
	private void validateTopeMinimo(String tope) throws ValidationException {
		if(tope=="null")
			tope="";
		obligatoryValidator.setMandatory(true);
		obligatoryValidator.setBundleManager(bundleManager);
		obligatoryValidator.validate(tope, locale);	
	}
	
	/**
     * Realiza la validación del medio de Pago.
     * 
     * @param pmtWayType medio de pago.
     * @throws ValidationException 
     */
    private void validateMedioPgo(String pmtWayType) throws ValidationException {
    	paymentsWayValidator.setMandatory(true);
    	paymentsWayValidator.setBundleManager(bundleManager);
    	paymentsWayValidator.validate(pmtWayType, locale);
		
    }


}
