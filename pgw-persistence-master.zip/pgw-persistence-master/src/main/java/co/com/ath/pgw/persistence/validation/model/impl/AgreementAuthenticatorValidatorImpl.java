/*
 * AgreementAuthenticatorValidatorImpl
 *
 * GSI - Integración
 * Creado el: 18 de septiembre de 2014
 *
 * Copyright (c) A Toda Hora S.A. Todos los derechos reservados
 *
 * Este software es confidencial y es propietario de ATH, queda prohibido
 * su uso, reproducción y copia de manera parcial o permanente salvo autorización
 * expresa de A Toda Hora S.A o de quién represente sus derechos.
 */
package co.com.ath.pgw.persistence.validation.model.impl;

import java.util.Locale;

import javax.annotation.Resource;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import co.com.ath.pgw.persistence.dao.CommerceDAO;
import co.com.ath.pgw.persistence.model.Commerce;
import co.com.ath.pgw.persistence.model.CommerceConfiguration;
import co.com.ath.pgw.util.i18n.BundleKeys;
import co.com.ath.pgw.util.i18n.BundleType;
import co.com.ath.pgw.util.i18n.ResourceBundleManager;
import co.com.ath.pgw.util.validation.ErrorCode;
import co.com.ath.pgw.util.validation.ValidationException;
import co.com.ath.pgw.util.validation.model.AgreementAuthData;
import co.com.ath.pgw.util.validation.model.AgreementAuthenticatorValidator;

/**
 * Implementación por defecto de AgreementAuthenticatorValidator
 * 
 * @author proveedor_zagarcia
 * @version 1.0 22-sep-2014
 * @since 1.0
 */
@Service
public class AgreementAuthenticatorValidatorImpl 
									implements AgreementAuthenticatorValidator {
	
	private static Logger LOGGER = 
			LoggerFactory.getLogger(AgreementAuthenticatorValidator.class);
	
	@Autowired
	private ResourceBundleManager bundleManager;

	@Resource
	private CommerceDAO commerceDAO;

	public AgreementAuthenticatorValidatorImpl(){
		super();
	}

	@Override
	public void validate(AgreementAuthData authData) throws ValidationException{
		Commerce commerce = commerceDAO.findByNura(authData.getCommerceId());
		
		if (commerce == null) {
			ValidationException ve = new ValidationException(
					getMessage(authData.getLocale()),
					ErrorCode.INVALID_AUTH_DATA);
			LOGGER.warn("Fallo en validador: \n{}", ve.toString());
			throw ve;
		}
		
		CommerceConfiguration configuration = commerce.getConfiguration();

		boolean failLogon = false;
		if (!configuration.getUser().equals(authData.getUser())) {
			failLogon = true;
		}
		if (!configuration.getPhrase().equals(authData.getPassword())) {
			failLogon = true;
		}
		
		if (failLogon) {
			ValidationException ve = new ValidationException(
					getMessage(authData.getLocale()),
					ErrorCode.INVALID_AUTH_DATA);
			LOGGER.warn("Fallo en validador: \n{}", ve.toString());
			throw ve;
		}
	}
	
	private String getMessage(Locale locale) {
		if (bundleManager == null) {
			return BundleKeys.ERROR_INVALID_AUTH_DATA;
		}
		if (locale == null) {
			locale = Locale.getDefault();
		}
		bundleManager.setBundle(BundleType.ERRORS);
		return bundleManager.getMessage(
			BundleKeys.ERROR_INVALID_AUTH_DATA, null, locale);
	}


}