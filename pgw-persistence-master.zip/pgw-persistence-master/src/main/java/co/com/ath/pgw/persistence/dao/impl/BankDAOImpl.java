/*
 * BankDAOImpl
 *
 * GSI - Integración
 * Creado el: 22 de agosto de 2014
 *
 * Copyright (c) A Toda Hora S.A. Todos los derechos reservados
 *
 * Este software es confidencial y es propietario de ATH, queda prohibido
 * su uso, reproducción y copia de manera parcial o permanente salvo autorización
 * expresa de A Toda Hora S.A o de quién represente sus derechos.
 */
package co.com.ath.pgw.persistence.dao.impl;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.NoResultException;
import javax.persistence.NonUniqueResultException;
import javax.persistence.Query;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Repository;

import co.com.ath.pgw.persistence.AbstractDAO_JPA;
import co.com.ath.pgw.persistence.dao.BankDAO;
import co.com.ath.pgw.persistence.model.Bank;
import co.com.ath.pgw.util.constants.CoreConstants;

/**
 * Implementación por defecto de BankDAO
 * 
 * @author proveedor_zagarcia
 * @version 1.0 22 Ago 2014
 * @since 1.0
 * 
 * 
 * @RQ30455 <strong>Autor</strong>Camilo Bustamante</br>
 *          <strong>Descripcion</strong>Permitir Compartir Recaudos PSE</br>
 *          <strong>Numero de Cambios</strong>1</br>
 *          <strong>Identificador corto</strong>C01</br>
 *          
 *          
 * @PCI
 * <strong>Autor</strong>Nelly Rocio Linares</br>
 * <strong>Descripcion</strong>Se crea metodo para recuperar las entidades bancarias</br>
 * <strong>Numero de Cambios</strong>1</br>
 * <strong>Identificador corto</strong>C02</br>
 *          
 * 
 */
@Repository
public class BankDAOImpl extends AbstractDAO_JPA<Bank> implements BankDAO {

	static Logger LOGGER = LoggerFactory.getLogger(BankDAOImpl.class);

	/**
	 * Constructor por defecto
	 */
	public BankDAOImpl() {
		super(Bank.class);
	}

	@Override
	public Bank findByAVALCode(String avalCode) {

		StringBuilder hql = new StringBuilder("from Bank b ");
		hql.append("where b.rowDeleted <> 1 ");
		hql.append("and b.avalCode = :avalCode ");

		Query query = entityManager.createQuery(hql.toString());
		query.setParameter("avalCode", avalCode);

		Bank bank = null;

		try {
			bank = (Bank) query.getSingleResult();
		} catch (NoResultException e) {
			LOGGER.info("Problemas en query: {}", e.toString());
			return null;
		} catch (NonUniqueResultException e) {
			LOGGER.warn("Problemas en query: {}", e.toString());
			return null;
		}
		return bank;
	}

	@Override
	public Bank findByACHCode(String achCode) {
		StringBuilder hql = new StringBuilder("from Bank b ");
		hql.append("where b.rowDeleted <> 1 ");
		hql.append("and b.achCode = :achCode ");

		Query query = entityManager.createQuery(hql.toString());
		query.setParameter("achCode", achCode);

		Bank bank = null;

		try {
			bank = (Bank) query.getSingleResult();
		} catch (NoResultException e) {
			LOGGER.warn("Problemas en query", e);
			return null;
		} catch (NonUniqueResultException e) {
			LOGGER.warn("Problemas en query", e);
			return null;
		}
		return bank;
	}

	@Override
	public Bank findByBANREPUBLICACode(String banrepCode) {
		StringBuilder hql = new StringBuilder("from Bank b ");
		hql.append("where b.rowDeleted <> 1 ");
		hql.append("and b.banRepublicaCode = :banRepublicaCode ");

		Query query = entityManager.createQuery(hql.toString());
		query.setParameter("banRepublicaCode", banrepCode);

		Bank bank = null;

		try {
			bank = (Bank) query.getSingleResult();
		} catch (NoResultException e) {
			LOGGER.warn("Problemas en query", e);
			return null;
		} catch (NonUniqueResultException e) {
			LOGGER.warn("Problemas en query", e);
			return null;
		}
		return bank;
	}

	/** INICIO-C01 **/
	@Override
	public Bank findById(Long bankId) {

		StringBuilder hql = new StringBuilder("from Bank b ");
		hql.append("where b.rowDeleted <> 1 ");
		hql.append("and b.id = :bankId ");

		Query query = entityManager.createQuery(hql.toString());
		query.setParameter("bankId", bankId);

		Bank bank = null;

		try {
			bank = (Bank) query.getSingleResult();
		} catch (NoResultException e) {
			LOGGER.error("El query no retorno algun registro: {}", e.toString());
			return null;
		} catch (NonUniqueResultException e) {
			LOGGER.error("El query no retorno un unico registro. {}", e.toString());
			return null;
		} catch (Exception e) {
			LOGGER.error("Problemas en query: {}", e.toString());
			return null;
		}

		return bank;
	}

	/** FIN-C01 **/

	/**INICIO-C02**/
	@Override
	public List<Bank> findByIsAval(Long valor) {

		StringBuilder hql = new StringBuilder("from Bank b ");
		hql.append("where b.rowDeleted <> 1 ");
		List<Bank> banks = new ArrayList<Bank>();

		if (CoreConstants.RETURN_ALL_BANKS == valor || CoreConstants.RETURN_IS_AVAL == valor
				|| CoreConstants.RETURN_NOT_IS_AVAL == valor) {

			if (CoreConstants.RETURN_ALL_BANKS != valor) {
				hql.append(" and b.avalEntity = :isAval ");

			}

			Query query = entityManager.createQuery(hql.toString());

			if (CoreConstants.RETURN_ALL_BANKS != valor) {

				if (CoreConstants.RETURN_IS_AVAL == valor)
					query.setParameter("isAval", true);
				if (CoreConstants.RETURN_NOT_IS_AVAL == valor)
					query.setParameter("isAval", false);

			}

			try {
				banks = query.getResultList();
			} catch (NoResultException e) {
				LOGGER.error("El query no retorno algun registro: {}", e.toString());
				return new ArrayList<Bank>();
			} catch (Exception e) {
				LOGGER.error("Problemas en query: {}", e.toString());
				return new ArrayList<Bank>();
			}
		} else {
			return new ArrayList<Bank>();
		}

		return banks;
	}
	/**FIN-C02**/
}