/*
 * AVALFileDetail
 *  
 * GSI - Integración
 * Creado el: 28/08/2014
 *
 * Copyright (c) A Toda Hora S.A. Todos los derechos reservados
 * 
 * Este software es confidencial y es propietario de ATH, queda prohibido
 * su uso, reproducción y copia de manera parcial o permanente salvo autorización
 * expresa de A Toda Hora S.A o de quién represente sus derechos.
 */
package co.com.ath.pgw.persistence.model;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import co.com.ath.pgw.persistence.PersistentObject;

/**
 * Clase que representa un registro detallado del archivo AVAL para conciliacion 
 * de transacciones.
 * 
 * @author Andrés Méndez <proveedor_mamendez@ath.com.co>
 * @version 17/12/2014
 * @since 1.0
 */
@Entity
@Table(name="DETALLESARCHIVOSAVAL")
public class AVALFileDetail implements PersistentObject {

	/**
	 * ID de serialización.
	 */
	private static final long serialVersionUID = 1786118152957467367L;

	/**
	 * Identificador único del archivo AVAL.
	 */
	@Id
	@SequenceGenerator(
			name="DETALLESARCHIVOSAVAL_ID_GENERATOR",
			sequenceName="DETALLESARCHIVOSAVAL_SEC",
			initialValue=1,
			allocationSize=1
			)
	@GeneratedValue(
			strategy=GenerationType.SEQUENCE,
			generator="DETALLESARCHIVOSAVAL_ID_GENERATOR"
			)
	@Column(name="ID")
	private Long id;
	
	@Column(name="IDARCHIVO")
	private Long fileId;
	
	/** tipoDeRegistro Atributo de la clase. */
	@Column(name="COLUMN1")
	private String rowType;
	
	/** referenciaPrincipalDelUsuario Atributo de la clase. */
	@Column(name="COLUMN2")
	private String mainUserReference;
	
	/** segundaReferenciaDelUsuario Atributo de la clase. */
	@Column(name="COLUMN3")
	private String secondUserReference;
	
	/** tipoDeRecaudo Atributo de la clase. */
	@Column(name="COLUMN4")
	private String collectType;
	
	/** fechaRealDeRecaudo Atributo de la clase. */
	@Column(name="COLUMN5")
	private String realCollectDate;
	
	/** horaRealDelRecaudo Atributo de la clase. */
	@Column(name="COLUMN6")
	private String realCollectTime;
	
	/** valorRecaudado Atributo de la clase. */
	@Column(name="COLUMN7")
	private String collectValue;
	
	/** valorRecaudadoEnCanje Atributo de la clase. */
	@Column(name="COLUMN8")
	private String exchangeCollectValue;
	
	/** procedenciaDePago Atributo de la clase. */
	@Column(name="COLUMN9")
	private String paymentSource;
	
	/** mediosDePago Atributo de la clase. */
	@Column(name="COLUMN10")
	private String paymentWay;
	
	/** numeroDeOperacion Atributo de la clase. */
	@Column(name="COLUMN11")
	private String operationNumber;
	
	/** numeroDeCheque Atributo de la clase. */
	@Column(name="COLUMN12")
	private String chequeNumber;
	
	/** codigoCompensacionDelCheque Atributo de la clase. */
	@Column(name="COLUMN13")
	private String chequeCompensationCode;
	
	/** numeroDeAutorizacion Atributo de la clase. */
	@Column(name="COLUMN14")
	private String autorizationNumber;
	
	/** codigoDeLaEntidadFinancieraDebitada Atributo de la clase. */
	@Column(name="COLUMN15")
	private String debitedBankCode;
	
	/** codigoDeSucursalUOficinaRecaudadora Atributo de la clase. */
	@Column(name="COLUMN16")
	private String collectBankOfficeCode;
	
	/** secuencia Atributo de la clase. */
	@Column(name="COLUMN17")
	private String sequence;
	
	/** causalDeDevolucion Atributo de la clase. */
	@Column(name="COLUMN18")
	private String returnCausal;
	
	/** reservado Atributo de la clase. */
	@Column(name="COLUMN19")
	private String reserved;
	
	/** reservado Atributo de la clase. */
	@Column(name="CODIGOCONVENIO")
	private String agreementCode;
	
	/**
	 * Indica si el registro tiene marca lógica de borrado
	 */
	@Column(name="REGELIMINADO", nullable=true)
	private boolean rowDeleted;
	
	/**
	 * Fecha de creación del registro
	 */
	@Temporal(TemporalType.TIMESTAMP)
	@Column(name="REGFECHACREACION", nullable=true)
	private Date rowCreationDate;
	
	/**
	 * Fecha de última modificación del registro
	 */
	@Temporal(TemporalType.TIMESTAMP)
	@Column(name="REGFECHAMODIFICACION", nullable=true)
	private Date rowLastUpdate;
	
	/**
	 * Constructor por defecto de un Banco
	 */
	public AVALFileDetail(){
		super();
	}
	
	/**
	 * Método encargado de recuperar el valor del atributo id.
	 * @return El atributo id asociado a la clase.
	 */
	public Long getId() {
		return id;
	}

	/**
	 * Método encargado de actualizar el atributo id.
	 * @param id Nuevo valor para id.
	 */
	public void setId(Long id) {
		this.id = id;
	}

	/**
	 * Método encargado de recuperar el valor del atributo fileId.
	 * @return El atributo fileId asociado a la clase.
	 */
	public Long getFileId() {
		return fileId;
	}

	/**
	 * Método encargado de actualizar el atributo fileId.
	 * @param fileId Nuevo valor para fileId.
	 */
	public void setFileId(Long fileId) {
		this.fileId = fileId;
	}

	/**
	 * Método encargado de recuperar el valor del atributo rowType.
	 * @return El atributo rowType asociado a la clase.
	 */
	public String getRowType() {
		return rowType;
	}

	/**
	 * Método encargado de actualizar el atributo rowType.
	 * @param rowType Nuevo valor para rowType.
	 */
	public void setRowType(String rowType) {
		this.rowType = rowType;
	}

	/**
	 * Método encargado de recuperar el valor del atributo mainUserReference.
	 * @return El atributo mainUserReference asociado a la clase.
	 */
	public String getMainUserReference() {
		return mainUserReference;
	}

	/**
	 * Método encargado de actualizar el atributo mainUserReference.
	 * @param mainUserReference Nuevo valor para mainUserReference.
	 */
	public void setMainUserReference(String mainUserReference) {
		this.mainUserReference = mainUserReference;
	}

	/**
	 * Método encargado de recuperar el valor del atributo secondUserReference.
	 * @return El atributo secondUserReference asociado a la clase.
	 */
	public String getSecondUserReference() {
		return secondUserReference;
	}

	/**
	 * Método encargado de actualizar el atributo secondUserReference.
	 * @param secondUserReference Nuevo valor para secondUserReference.
	 */
	public void setSecondUserReference(String secondUserReference) {
		this.secondUserReference = secondUserReference;
	}

	/**
	 * Método encargado de recuperar el valor del atributo collectType.
	 * @return El atributo collectType asociado a la clase.
	 */
	public String getCollectType() {
		return collectType;
	}

	/**
	 * Método encargado de actualizar el atributo collectType.
	 * @param collectType Nuevo valor para collectType.
	 */
	public void setCollectType(String collectType) {
		this.collectType = collectType;
	}

	/**
	 * Método encargado de recuperar el valor del atributo realCollectDate.
	 * @return El atributo realCollectDate asociado a la clase.
	 */
	public String getRealCollectDate() {
		return realCollectDate;
	}

	/**
	 * Método encargado de actualizar el atributo realCollectDate.
	 * @param realCollectDate Nuevo valor para realCollectDate.
	 */
	public void setRealCollectDate(String realCollectDate) {
		this.realCollectDate = realCollectDate;
	}

	/**
	 * Método encargado de recuperar el valor del atributo realCollectTime.
	 * @return El atributo realCollectTime asociado a la clase.
	 */
	public String getRealCollectTime() {
		return realCollectTime;
	}

	/**
	 * Método encargado de actualizar el atributo realCollectTime.
	 * @param realCollectTime Nuevo valor para realCollectTime.
	 */
	public void setRealCollectTime(String realCollectTime) {
		this.realCollectTime = realCollectTime;
	}

	/**
	 * Método encargado de recuperar el valor del atributo collectValue.
	 * @return El atributo collectValue asociado a la clase.
	 */
	public String getCollectValue() {
		return collectValue;
	}

	/**
	 * Método encargado de actualizar el atributo collectValue.
	 * @param collectValue Nuevo valor para collectValue.
	 */
	public void setCollectValue(String collectValue) {
		this.collectValue = collectValue;
	}

	/**
	 * Método encargado de recuperar el valor del atributo exchangeCollectValue.
	 * @return El atributo exchangeCollectValue asociado a la clase.
	 */
	public String getExchangeCollectValue() {
		return exchangeCollectValue;
	}

	/**
	 * Método encargado de actualizar el atributo exchangeCollectValue.
	 * @param exchangeCollectValue Nuevo valor para exchangeCollectValue.
	 */
	public void setExchangeCollectValue(String exchangeCollectValue) {
		this.exchangeCollectValue = exchangeCollectValue;
	}

	/**
	 * Método encargado de recuperar el valor del atributo paymentSource.
	 * @return El atributo paymentSource asociado a la clase.
	 */
	public String getPaymentSource() {
		return paymentSource;
	}

	/**
	 * Método encargado de actualizar el atributo paymentSource.
	 * @param paymentSource Nuevo valor para paymentSource.
	 */
	public void setPaymentSource(String paymentSource) {
		this.paymentSource = paymentSource;
	}

	/**
	 * Método encargado de recuperar el valor del atributo paymentWay.
	 * @return El atributo paymentWay asociado a la clase.
	 */
	public String getPaymentWay() {
		return paymentWay;
	}

	/**
	 * Método encargado de actualizar el atributo paymentWay.
	 * @param paymentWay Nuevo valor para paymentWay.
	 */
	public void setPaymentWay(String paymentWay) {
		this.paymentWay = paymentWay;
	}

	/**
	 * Método encargado de recuperar el valor del atributo operationNumber.
	 * @return El atributo operationNumber asociado a la clase.
	 */
	public String getOperationNumber() {
		return operationNumber;
	}

	/**
	 * Método encargado de actualizar el atributo operationNumber.
	 * @param operationNumber Nuevo valor para operationNumber.
	 */
	public void setOperationNumber(String operationNumber) {
		this.operationNumber = operationNumber;
	}

	/**
	 * Método encargado de recuperar el valor del atributo chequeNumber.
	 * @return El atributo chequeNumber asociado a la clase.
	 */
	public String getChequeNumber() {
		return chequeNumber;
	}

	/**
	 * Método encargado de actualizar el atributo chequeNumber.
	 * @param chequeNumber Nuevo valor para chequeNumber.
	 */
	public void setChequeNumber(String chequeNumber) {
		this.chequeNumber = chequeNumber;
	}

	/**
	 * Método encargado de recuperar el valor del atributo chequeCompensationCode.
	 * @return El atributo chequeCompensationCode asociado a la clase.
	 */
	public String getChequeCompensationCode() {
		return chequeCompensationCode;
	}

	/**
	 * Método encargado de actualizar el atributo chequeCompensationCode.
	 * @param chequeCompensationCode Nuevo valor para chequeCompensationCode.
	 */
	public void setChequeCompensationCode(String chequeCompensationCode) {
		this.chequeCompensationCode = chequeCompensationCode;
	}

	/**
	 * Método encargado de recuperar el valor del atributo autorizationNumber.
	 * @return El atributo autorizationNumber asociado a la clase.
	 */
	public String getAutorizationNumber() {
		return autorizationNumber;
	}

	/**
	 * Método encargado de actualizar el atributo autorizationNumber.
	 * @param autorizationNumber Nuevo valor para autorizationNumber.
	 */
	public void setAutorizationNumber(String autorizationNumber) {
		this.autorizationNumber = autorizationNumber;
	}

	/**
	 * Método encargado de recuperar el valor del atributo debitedBankCode.
	 * @return El atributo debitedBankCode asociado a la clase.
	 */
	public String getDebitedBankCode() {
		return debitedBankCode;
	}

	/**
	 * Método encargado de actualizar el atributo debitedBankCode.
	 * @param debitedBankCode Nuevo valor para debitedBankCode.
	 */
	public void setDebitedBankCode(String debitedBankCode) {
		this.debitedBankCode = debitedBankCode;
	}

	/**
	 * Método encargado de recuperar el valor del atributo collectBankOfficeCode.
	 * @return El atributo collectBankOfficeCode asociado a la clase.
	 */
	public String getCollectBankOfficeCode() {
		return collectBankOfficeCode;
	}

	/**
	 * Método encargado de actualizar el atributo collectBankOfficeCode.
	 * @param collectBankOfficeCode Nuevo valor para collectBankOfficeCode.
	 */
	public void setCollectBankOfficeCode(String collectBankOfficeCode) {
		this.collectBankOfficeCode = collectBankOfficeCode;
	}

	/**
	 * Método encargado de recuperar el valor del atributo sequence.
	 * @return El atributo sequence asociado a la clase.
	 */
	public String getSequence() {
		return sequence;
	}

	/**
	 * Método encargado de actualizar el atributo sequence.
	 * @param sequence Nuevo valor para sequence.
	 */
	public void setSequence(String sequence) {
		this.sequence = sequence;
	}

	/**
	 * Método encargado de recuperar el valor del atributo returnCausal.
	 * @return El atributo returnCausal asociado a la clase.
	 */
	public String getReturnCausal() {
		return returnCausal;
	}

	/**
	 * Método encargado de actualizar el atributo returnCausal.
	 * @param returnCausal Nuevo valor para returnCausal.
	 */
	public void setReturnCausal(String returnCausal) {
		this.returnCausal = returnCausal;
	}

	/**
	 * Método encargado de recuperar el valor del atributo reserved.
	 * @return El atributo reserved asociado a la clase.
	 */
	public String getReserved() {
		return reserved;
	}

	/**
	 * Método encargado de actualizar el atributo reserved.
	 * @param reserved Nuevo valor para reserved.
	 */
	public void setReserved(String reserved) {
		this.reserved = reserved;
	}

	/**
	 * Método encargado de recuperar el valor del atributo agreementCode.
	 * @return El atributo agreementCode asociado a la clase.
	 */
	public String getAgreementCode() {
		return agreementCode;
	}

	/**
	 * Método encargado de actualizar el atributo agreementCode.
	 * @param agreementCode Nuevo valor para agreementCode.
	 */
	public void setAgreementCode(String agreementCode) {
		this.agreementCode = agreementCode;
	}

	/**
	 * Método encargado de recuperar el valor del atributo rowDeleted.
	 * @return El atributo rowDeleted asociado a la clase.
	 */
	public boolean isRowDeleted() {
		return rowDeleted;
	}

	/**
	 * Método encargado de actualizar el atributo rowDeleted.
	 * @param rowDeleted Nuevo valor para rowDeleted.
	 */
	public void setRowDeleted(boolean rowDeleted) {
		this.rowDeleted = rowDeleted;
	}

	/**
	 * Método encargado de recuperar el valor del atributo rowCreationDate.
	 * @return El atributo rowCreationDate asociado a la clase.
	 */
	public Date getRowCreationDate() {
		return rowCreationDate;
	}

	/**
	 * Método encargado de actualizar el atributo rowCreationDate.
	 * @param rowCreationDate Nuevo valor para rowCreationDate.
	 */
	public void setRowCreationDate(Date rowCreationDate) {
		this.rowCreationDate = rowCreationDate;
	}

	/**
	 * Método encargado de recuperar el valor del atributo rowLastUpdate.
	 * @return El atributo rowLastUpdate asociado a la clase.
	 */
	public Date getRowLastUpdate() {
		return rowLastUpdate;
	}

	/**
	 * Método encargado de actualizar el atributo rowLastUpdate.
	 * @param rowLastUpdate Nuevo valor para rowLastUpdate.
	 */
	public void setRowLastUpdate(Date rowLastUpdate) {
		this.rowLastUpdate = rowLastUpdate;
	}

	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "AVALFileDetail [id=" + id + ", fileId=" + fileId + ", rowType="
				+ rowType + ", mainUserReference=" + mainUserReference
				+ ", secondUserReference=" + secondUserReference
				+ ", collectType=" + collectType + ", realCollectDate="
				+ realCollectDate + ", realCollectTime=" + realCollectTime
				+ ", collectValue=" + collectValue + ", exchangeCollectValue="
				+ exchangeCollectValue + ", paymentSource=" + paymentSource
				+ ", paymentWay=" + paymentWay + ", operationNumber="
				+ operationNumber + ", chequeNumber=" + chequeNumber
				+ ", chequeCompensationCode=" + chequeCompensationCode
				+ ", autorizationNumber=" + autorizationNumber
				+ ", debitedBankCode=" + debitedBankCode
				+ ", collectBankOfficeCode=" + collectBankOfficeCode
				+ ", sequence=" + sequence + ", returnCausal=" + returnCausal
				+ ", reserved=" + reserved + ", rowDeleted=" + rowDeleted
				+ ", rowCreationDate=" + rowCreationDate + ", rowLastUpdate="
				+ rowLastUpdate + "]";
	}

}