/*
 * AVALFileDAOImpl
 *  
 * GSI - Integración
 * Creado el: 29/08/2014
 *
 * Copyright (c) A Toda Hora S.A. Todos los derechos reservados
 * 
 * Este software es confidencial y es propietario de ATH, queda prohibido
 * su uso, reproducción y copia de manera parcial o permanente salvo autorización
 * expresa de A Toda Hora S.A o de quién represente sus derechos.
 */
package co.com.ath.pgw.persistence.dao.impl;

import javax.annotation.Resource;
import javax.persistence.ParameterMode;
import javax.persistence.StoredProcedureQuery;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Repository;

import co.com.ath.pgw.persistence.AbstractDAO_JPA;
import co.com.ath.pgw.persistence.dao.BankDAO;
import co.com.ath.pgw.persistence.dao.CollectionBankTailDAO;
import co.com.ath.pgw.persistence.model.Bank;
import co.com.ath.pgw.persistence.model.CollectionBankTail;

/**
 * Implementación por defecto de CollectionBankTailDAO
 *
 * @author Camilo Andres Bustamante <camilo.bustamante@sophossolutions.com>
 * @version 1.0 11/07/2018
 * @since 1.0
 * 
 */
@Repository
public class CollectionBankTailDAOImpl extends AbstractDAO_JPA<CollectionBankTail> 
	implements CollectionBankTailDAO {

	static Logger LOGGER = LoggerFactory.getLogger(CollectionBankTailDAOImpl.class);
	
	@Resource
	private BankDAO bankDAO;

	public CollectionBankTailDAOImpl() {
		super(CollectionBankTail.class);
	}
	
	@Override
	public Bank getCollectionBank() {

		Bank collectionBank = null;
		String storeProcedure = "PGW_GET_BANCO_RECAUDO";

		try {

			StoredProcedureQuery spQuery = entityManager.createStoredProcedureQuery(storeProcedure)
					.registerStoredProcedureParameter(1, Long.class, ParameterMode.OUT);

			spQuery.execute();
			
			Long bankId = null;
			bankId = (Long) spQuery.getOutputParameterValue(1);
			
			if (null == bankId) {
				LOGGER.error("El procedimiento almacenado '{}' no retorno un IdBank valido.", storeProcedure);
				return null;
			}
						
			collectionBank = bankDAO.findById(bankId);

			if (null == collectionBank) {
				LOGGER.error("No se encontro un banco con el ID:{}", bankId);
				return null;
			}else {
				LOGGER.info("Cola de Bancos retorno Banco: {}-{}",collectionBank.getId(), collectionBank.getName());
				return collectionBank;
			}
				
		} catch (Exception e) {
			LOGGER.error("No fue posible obtener un Banco de recaudo. Error: {}", e.getMessage());
			return null;
		}
		
	} 

}
