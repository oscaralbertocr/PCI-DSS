package co.com.ath.pgw.persistence.dao;

import co.com.ath.pgw.persistence.DataAccessObject;
import co.com.ath.pgw.persistence.model.BillCollector;

public interface BillCollectorDAO  extends DataAccessObject<BillCollector>{
	
	BillCollector findServiceCode(Long commerceId);

}
