/*
 * Subscription
 *  
 * GSI - Integración
 * Creado el: 28/08/2014
 *
 * Copyright (c) A Toda Hora S.A. Todos los derechos reservados
 * 
 * Este software es confidencial y es propietario de ATH, queda prohibido
 * su uso, reproducción y copia de manera parcial o permanente salvo autorización
 * expresa de A Toda Hora S.A o de quién represente sus derechos.
 */
package co.com.ath.pgw.persistence.model;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToOne;
import javax.persistence.PrimaryKeyJoinColumn;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import org.hibernate.annotations.GenericGenerator;
import org.hibernate.annotations.Parameter;

import co.com.ath.pgw.persistence.PersistentObject;


/**
 * Representa la información detallada de un comercio. Esta es una entidad del
 * modelo persistente.
 * 
 * @author proveedor_piza
 * @version 1.0 29 Ago 2014
 * @since 1.0
 *
 */
@Entity
@Table(name="SUBSCRIPCION")
public class Subscription implements PersistentObject {

	/**
	 * 
	 */
	private static final long serialVersionUID = 7402740964397678777L;

	/**
	 * Identificador del comercio.
	 * 
	 */
	@Id
	@GeneratedValue(generator = "subscriptionGen")
	@GenericGenerator(
		name = "subscriptionGen",
		strategy = "foreign",
		parameters = @Parameter(name = "property", value = "commerce")
	)
	@Column(name="IDCOMERCIO", nullable = false)
	private Long idComercio;
	
	/**
	 * Comercio asociado a los detalles.
	 */
	@PrimaryKeyJoinColumn
	@OneToOne(fetch=FetchType.LAZY)
	private Commerce commerce;
	
	/**
	 * Razón social del comercio.
	 */
	@Column(name="RAZONSOCIAL")
	private String companyName;
	
	/**
	 * Dígito de verificación del NIT del comercio.
	 */
	@Column(name="DIGITOVERIFICACION")
	private Integer checkDigit;
	
	/**
	 * Dirección de notificación del comercio.
	 */
	@Column(name="DIRECCION")
	private String address;
	
	/**
	 * Número telefónico del comercio
	 */
	@Column(name="TELEFONO")
	private String phone;
	
	/**
	 * Correo electrónico del comercio.
	 */
	@Column(name="EMAIL")
	private String email;
	
	/**
	 * Número del fax del comercio.
	 */
	@Column(name="FAX")
	private String fax;
	
	/**
	 * Nombre del representante legal del comercio.
	 */
	@Column(name="REPRESENTATELEGAL")
	private String legalAgent;
		/**
	 * Apellido del representante legal del comercio.
	 */
	@Column(name="APELLIDOREPRESENTANTE")
	private String legalAgentLastName;

	/**
	 * Número de identificación del representante legal del comercio.
	 */
	@Column(name="CEDULAREPRESENTELEGAL")
	private String legalAgentId;
	
	/**
	 * tipo de identificación del representante legal del comercio.
	 */
	@Column(name="TIPODOCUMENTO")
	private String legalAgentType;

	/**
	 * Banco dueño del convenio con el comercio.
	 */
	@ManyToOne(fetch=FetchType.EAGER)
	@JoinColumn(name="IDBANCO")
	private Bank bank;

	/**
	 * Ubicación del comercio.
	 */
	@ManyToOne(fetch=FetchType.LAZY)
	@JoinColumn(name="IDMUNICIPIO")
	private City city;

	/**
	 * Indica si el registro tiene marca lógica de borrado
	 */
	@Column(name="REGELIMINADO", nullable=true)
	private boolean rowDeleted;
	
	/**
	 * Fecha de creación del registro
	 */
	@Temporal(TemporalType.TIMESTAMP)
	@Column(name="REGFECHACREACION", nullable=true)
	private Date rowCreationDate;
	
	/**
	 * Fecha de última modificación del registro
	 */
	@Temporal(TemporalType.TIMESTAMP)
	@Column(name="REGFECHAMODIFICACION", nullable=true)
	private Date rowLastUpdate;
	
	/**
	 * Construye los detalles de un comercio
	 */
	public Subscription(){
		super();
	}
	
	/**
	 * Construye los detalles de un comercio especificando el id del comercio.
	 */
	Subscription(Long idComercio){
		this.idComercio = idComercio;
	}
	
	/**
	 * Retorna el identificador del comercio.
	 * 
	 * @return Identificador del comercio.
	 */
	public Long getIdComercio() {
		return idComercio;
	}
	
	/**
	 * Establece el identificador del comercio.
	 * 
	 * @param idComercio Identificador del comercio.
	 */
	public void setIdComercio(Long idComercio) {
		this.idComercio = idComercio;
	}

	/**
	 * Retorna el comercio asociado a los detalles.
	 * 
	 * @return Comercio asociado a los detalles.
	 */
	public Commerce getCommerce() {
		return commerce;
	}

	/**
	 * Establece el comercio asociado a los detalles.
	 * 
	 * @param commerce Comercio asociado a los detalles.
	 */
	public void setCommerce(Commerce commerce) {
		this.commerce = commerce;
	}

	/**
	 * Retorna la razón social del comercio.
	 * 
	 * @return Razón social del comercio.
	 */
	public String getCompanyName() {
		return companyName;
	}

	/**
	 * Establece la razón social del comercio.
	 * 
	 * @param companyName Razón social del comercio.
	 */
	public void setCompanyName(String companyName) {
		this.companyName = companyName;
	}

	/**
	 * Retorna el dígito de verificación del NIT del comercio.
	 * 
	 * @return Dígito de verificación del NIT del comercio.
	 */
	public Integer getCheckDigit() {
		return checkDigit;
	}

	/**
	 * Establece el dígito de verificación del NIT del comercio.
	 * 
	 * @param checkDigit Dígito de verificación del NIT del comercio.
	 */
	public void setCheckDigit(Integer checkDigit) {
		this.checkDigit = checkDigit;
	}

	/**
	 * Retorna la dirección de notificación del comercio.
	 * 
	 * @return Dirección de notificación del comercio.
	 */
	public String getAddress() {
		return address;
	}

	/**
	 * Establece la dirección de notificación del comercio.
	 * 
	 * @param address Dirección de notificación del comercio.
	 */
	public void setAddress(String address) {
		this.address = address;
	}

	/**
	 * Retorna el número telefónico del comercio.
	 * 
	 * @return Número telefónico del comercio.
	 */
	public String getPhone() {
		return phone;
	}

	/**
	 * Establece el número telefónico del comercio.
	 * 
	 * @param phone Número telefónico del comercio.
	 */
	public void setPhone(String phone) {
		this.phone = phone;
	}

	/**
	 * Retorna el correo electrónico del comercio.
	 * 
	 * @return Correo electrónico del comercio.
	 */
	public String getEmail() {
		return email;
	}

	/**
	 * Establece el correo electrónico del comercio.
	 * 
	 * @param email Correo electrónico del comercio.
	 */
	public void setEmail(String email) {
		this.email = email;
	}

	/**
	 * Retorna el número del fax del comercio.
	 * 
	 * @return Número del fax del comercio.
	 */
	public String getFax() {
		return fax;
	}

	/**
	 * Establece el número del fax del comercio.
	 * 
	 * @param fax Número del fax del comercio.
	 */
	public void setFax(String fax) {
		this.fax = fax;
	}

	/**
	 * Retorna el nombre del representante legal del comercio.
	 * 
	 * @return Nombre del representante legal del comercio.
	 */
	public String getLegalAgent() {
		return legalAgent;
	}

	/**
	 * Establece el nombre del representante legal del comercio.
	 * 
	 * @param legalAgent Nombre del representante legal del comercio.
	 */
	public void setLegalAgent(String legalAgent) {
		this.legalAgent = legalAgent;
	}

	/**
	 * Retorna el número de identificación del representante legal del comercio.
	 * 
	 * @return Número de identificación del representante legal del comercio.
	 */
	public String getLegalAgentId() {
		return legalAgentId;
	}

	/**
	 * Establece el número de identificación del representante legal del 
	 * comercio.
	 * 
	 * @param legalAgentId Número de identificación del representante legal del
	 * comercio.
	 */
	public void setLegalAgentId(String legalAgentId) {
		this.legalAgentId = legalAgentId;
	}

	/**
	 * Retorna el banco dueño del convenio con el comercio.
	 * 
	 * @return Banco dueño del convenio con el comercio.
	 */
	public Bank getBank() {
		return bank;
	}

	/**
	 * Establece el banco dueño del convenio con el comercio.
	 * 
	 * @param bank Banco dueño del convenio con el comercio.
	 */
	public void setBank(Bank bank) {
		this.bank = bank;
	}

	/**
	 * Return la ubicación del comercio.
	 * 
	 * @return Ubicación del comercio.
	 */
	public City getCity() {
		return city;
	}
	/**
	 * Return el tipo de documento.
	 * 
	 * @return tipo de documento.
	 */
	

	public String getLegalAgentType() {
		return legalAgentType;
	}
	
	/**
	 * Establece el tipo de documento del representante legal.
	 * 
	 * @param tipo de documento del representante legal.
	 */

	public void setLegalAgentType(String legalAgentType) {
		this.legalAgentType = legalAgentType;
	}
/**
	 * Retorna el Apellido del representante legal del comercio.
	 * 
	 * @return Apellido del representante legal del comercio.
	 */
	public String getLegalAgentLastName() {
		return legalAgentLastName;
	}
/**
	 * Establece el Apellido del representante legal del comercio.
	 * 
	 * @param LegalAgentLastName Apellido del representante legal del comercio.
	 */
	public void setLegalAgentLastName(String legalAgentLastName) {
		this.legalAgentLastName = legalAgentLastName;
	}


	/**
	 * Establece la ubicación del comercio.
	 * 
	 * @param city Ubicación del comercio.
	 */
	public void setCity(City city) {
		this.city = city;
	}

	@Override
	public boolean isRowDeleted() {
		return rowDeleted;
	}

	@Override
	public void setRowDeleted(boolean rowDeleted) {
		this.rowDeleted = rowDeleted;
	}

	@Override
	public Date getRowCreationDate() {
		return rowCreationDate;
	}

	@Override
	public void setRowCreationDate(Date rowCreationDate) {
		this.rowCreationDate = rowCreationDate;
	}

	@Override
	public Date getRowLastUpdate() {
		return rowLastUpdate;
	}

	@Override
	public void setRowLastUpdate(Date rowLastUpdate) {
		this.rowLastUpdate = rowLastUpdate;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + (int) (idComercio ^ (idComercio >>> 32));
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Subscription other = (Subscription) obj;
		if (idComercio != other.idComercio)
			return false;
		return true;
	}

	@Override
	public String toString() {
		return "Subscription [commerce=" + commerce + ", companyName="
				+ companyName + ", rowDeleted=" + rowDeleted + "]";
	}

}