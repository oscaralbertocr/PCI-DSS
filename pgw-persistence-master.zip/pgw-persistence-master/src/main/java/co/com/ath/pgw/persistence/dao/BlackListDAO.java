/*
 * BlackListDAO
 *  
 * GSI - Integración
 * Creado el: 24/06/2015
 *
 * Copyright (c) A Toda Hora S.A. Todos los derechos reservados
 * 
 * Este software es confidencial y es propietario de ATH, queda prohibido
 * su uso, reproducción y copia de manera parcial o permanente salvo autorización
 * expresa de A Toda Hora S.A o de quién represente sus derechos.
 */
package co.com.ath.pgw.persistence.dao;

import java.util.List;

import co.com.ath.pgw.persistence.DataAccessObject;
import co.com.ath.pgw.persistence.model.BlackList;
/**
 * Objeto de Acceso a Datos para las entidades Commerce
 *
 * @author <proveedor_edrobles@ath.com.co>
 * @version 1.0 24 Jun 2015
 * @since 1.0
 */
public interface BlackListDAO extends DataAccessObject<BlackList> {

	List<BlackList> findByDocument(String docType, String docNum);
}
