package co.com.ath.pgw.persistence.model;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import co.com.ath.pgw.persistence.PersistentObject;

@Entity
@Table(name = "CUENTARECAUDADORA")
public class BillCollector implements PersistentObject {
	
	private static final long serialVersionUID = 4749203375927141091L;
	
	@Id
	@Column(name="ID", unique=true, scale=10, precision=0)
	private Long id;	
	
	@ManyToOne(fetch=FetchType.EAGER)
	@JoinColumn(name="IDCOMERCIO")
	private Commerce commerce;
	
	@ManyToOne(fetch=FetchType.EAGER)
	@JoinColumn(name="IDMEDIOPAGO")
	private PaymentWay PaymentWay;
	
	@ManyToOne(fetch=FetchType.EAGER)
	@JoinColumn(name="IDBANCO")
	private Bank bank;

	@Column(name="CUENTAASOCIADA")
	private String cuentaAsociada;
	
	@Column(name="CODIGOSERVICIO")
	private String codigoServicio;	
	
	@Column(name="REGELIMINADO", nullable=true)
	private boolean rowDeleted;
	
	@Temporal(TemporalType.TIMESTAMP)
	@Column(name="REGFECHACREACION", nullable=true)
	private Date rowCreationDate;
	
	@Temporal(TemporalType.TIMESTAMP)
	@Column(name="REGFECHAMODIFICACION", nullable=true)
	private Date rowLastUpdate;

	@Override
	public boolean isRowDeleted() {
		return false;
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public Commerce getCommerce() {
		return commerce;
	}

	public void setCommerce(Commerce commerce) {
		this.commerce = commerce;
	}

	public PaymentWay getPaymentWay() {
		return PaymentWay;
	}

	public void setPaymentWay(PaymentWay paymentWay) {
		PaymentWay = paymentWay;
	}

	public Bank getBank() {
		return bank;
	}

	public void setBank(Bank bank) {
		this.bank = bank;
	}

	public String getCuentaAsociada() {
		return cuentaAsociada;
	}

	public void setCuentaAsociada(String cuentaAsociada) {
		this.cuentaAsociada = cuentaAsociada;
	}

	public String getCodigoServicio() {
		return codigoServicio;
	}

	public void setCodigoServicio(String codigoServicio) {
		this.codigoServicio = codigoServicio;
	}

	public Date getRowCreationDate() {
		return rowCreationDate;
	}

	public void setRowCreationDate(Date rowCreationDate) {
		this.rowCreationDate = rowCreationDate;
	}

	public Date getRowLastUpdate() {
		return rowLastUpdate;
	}

	public void setRowLastUpdate(Date rowLastUpdate) {
		this.rowLastUpdate = rowLastUpdate;
	}

	public void setRowDeleted(boolean rowDeleted) {
		this.rowDeleted = rowDeleted;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((PaymentWay == null) ? 0 : PaymentWay.hashCode());
		result = prime * result + ((bank == null) ? 0 : bank.hashCode());
		result = prime * result + ((codigoServicio == null) ? 0 : codigoServicio.hashCode());
		result = prime * result + ((commerce == null) ? 0 : commerce.hashCode());
		result = prime * result + ((cuentaAsociada == null) ? 0 : cuentaAsociada.hashCode());
		result = prime * result + ((id == null) ? 0 : id.hashCode());
		result = prime * result + ((rowCreationDate == null) ? 0 : rowCreationDate.hashCode());
		result = prime * result + (rowDeleted ? 1231 : 1237);
		result = prime * result + ((rowLastUpdate == null) ? 0 : rowLastUpdate.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		BillCollector other = (BillCollector) obj;
		if (PaymentWay == null) {
			if (other.PaymentWay != null)
				return false;
		} else if (!PaymentWay.equals(other.PaymentWay))
			return false;
		if (bank == null) {
			if (other.bank != null)
				return false;
		} else if (!bank.equals(other.bank))
			return false;
		if (codigoServicio == null) {
			if (other.codigoServicio != null)
				return false;
		} else if (!codigoServicio.equals(other.codigoServicio))
			return false;
		if (commerce == null) {
			if (other.commerce != null)
				return false;
		} else if (!commerce.equals(other.commerce))
			return false;
		if (cuentaAsociada == null) {
			if (other.cuentaAsociada != null)
				return false;
		} else if (!cuentaAsociada.equals(other.cuentaAsociada))
			return false;
		if (id == null) {
			if (other.id != null)
				return false;
		} else if (!id.equals(other.id))
			return false;
		if (rowCreationDate == null) {
			if (other.rowCreationDate != null)
				return false;
		} else if (!rowCreationDate.equals(other.rowCreationDate))
			return false;
		if (rowDeleted != other.rowDeleted)
			return false;
		if (rowLastUpdate == null) {
			if (other.rowLastUpdate != null)
				return false;
		} else if (!rowLastUpdate.equals(other.rowLastUpdate))
			return false;
		return true;
	}

	@Override
	public String toString() {
		return "BillCollector [id=" + id + ", commerce=" + commerce + ", PaymentWay=" 
				+ PaymentWay + ", bank=" + bank	+ ", cuentaAsociada=" + cuentaAsociada 
				+ ", codigoServicio=" + codigoServicio + ", rowDeleted=" + rowDeleted 
				+ ", rowCreationDate=" + rowCreationDate + ", rowLastUpdate=" + rowLastUpdate + "]";
	}

}
