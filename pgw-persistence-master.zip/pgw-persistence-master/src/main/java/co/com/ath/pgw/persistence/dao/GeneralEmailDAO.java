package co.com.ath.pgw.persistence.dao;


import co.com.ath.pgw.persistence.DataAccessObject;
import co.com.ath.pgw.persistence.model.GeneralEmail;

public interface GeneralEmailDAO  extends DataAccessObject<GeneralEmail>{
	
	
}
