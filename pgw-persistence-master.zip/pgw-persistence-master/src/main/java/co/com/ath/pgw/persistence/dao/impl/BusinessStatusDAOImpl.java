/**
 * 
 */
package co.com.ath.pgw.persistence.dao.impl;

import org.springframework.stereotype.Repository;

import co.com.ath.pgw.persistence.AbstractDAO_JPA;
import co.com.ath.pgw.persistence.dao.BusinessStatusDAO;
import co.com.ath.pgw.persistence.model.BusinessStatus;

/**
 * Implementación por defecto de BusinessStatusDAO
 *
 * @author Andrés Piza <proveedor_japiza>
 * @version 1.0 05 Sep 2014
 * @since 1.0
 */

@Repository
public class BusinessStatusDAOImpl extends AbstractDAO_JPA<BusinessStatus>
		implements BusinessStatusDAO {

	protected BusinessStatusDAOImpl() {
		super(BusinessStatus.class);		
	}	

}
