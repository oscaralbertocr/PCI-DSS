/*
 * AddTransactionValidatorImpl
 *
 * GSI - Integración
 * Creado el: 18 de septiembre de 2014
 *
 * Copyright (c) A Toda Hora S.A. Todos los derechos reservados
 *
 * Este software es confidencial y es propietario de ATH, queda prohibido
 * su uso, reproducción y copia de manera parcial o permanente salvo autorización
 * expresa de A Toda Hora S.A o de quién represente sus derechos.
 */
package co.com.ath.pgw.persistence.validation.model.impl;

import java.math.BigDecimal;
import java.util.Date;
import java.util.Locale;

import javax.annotation.Resource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import co.com.ath.pgw.bsn.dto.in.AddTransactionInDTO;
import co.com.ath.pgw.bsn.model.bo.CommerceBO;
import co.com.ath.pgw.bsn.model.bo.TransactionBO;
import co.com.ath.pgw.util.i18n.ResourceBundleManager;
import co.com.ath.pgw.util.validation.ValidationException;
import co.com.ath.pgw.util.validation.model.AddTransactionValidator;
import co.com.ath.pgw.util.validation.model.AgreementAuthData;
import co.com.ath.pgw.util.validation.model.AgreementAuthenticatorValidator;
import co.com.ath.pgw.util.validation.model.AgreementValidator;
import co.com.ath.pgw.util.validation.model.OrderNumberApprovedValidator;
import co.com.ath.pgw.util.validation.model.OrderNumberPendingValidator;


/**
 * Implementación por defecto de AddTransactionValidator.
 * 
 * @author proveedor_zagarcia
 * @version 1.0 18 Sep 2014
 * @since 1.0
 */
@Service
public class AddTransactionValidatorImpl implements AddTransactionValidator{
	
	@Resource
	private TrxSourceValidator sourceValidator;
	
	@Resource
	private RqDateValidator dateValidator;
	
	@Resource
	private IPAddressValidator ipAddressValidator;
	
	@Resource
	private DocumentTypeValidator docTypeValidator;
	
	@Resource
	private DocumentIdValidator docIdValidator;
	
	@Resource
	private URLValidator urlValidator;
	
	@Resource
	private AgreementAuthenticatorValidator authenticatorValidator;
	
    @Resource
    private AgreementValidator agreementValidator;
    
    @Resource
    private CustomerEmailValidator custEmailValidator;
    
    @Resource
    private PhoneNumberValidator phoneNumberValidator;
    
    @Resource
    private OrderNumberValidator orderNumberValidator;
    
    @Resource
    private ObligatoryValidator obligatoryValidator;
    
    @Resource
    private TotalValueValidator totalValueValidator;
    
    @Resource
    private CurrencyValidator currencyValidator;
    
    @Resource
    private TaxValueValidator taxValueValidator;
    
    @Resource
    private TransactionTypeValidator transactionTypeValidator;
    
    @Resource
    private OrderNumberApprovedValidator orderNumberApprovedValidator;
    
    @Resource
    private OrderNumberPendingValidator orderNumberPendingValidator;
    
    @Autowired
	private ResourceBundleManager bundleManager;
	
    private Locale locale;

    
	public AddTransactionValidatorImpl(){
        this.locale = Locale.getDefault();
	}

    @Override
    public void validate(String pmtType,AddTransactionInDTO inDTO) throws ValidationException{
        validateChannelSource(inDTO.getTransactionBO().getSource().getId());
        validateRqDate(inDTO.getClientDt());
        validateIpAddress(inDTO.getIpAddr());
        validateDocType(inDTO.getTransactionBO().getPayerDocType());
        validateDocId(inDTO.getTransactionBO().getPayerDocId());
        //validateDocType(inDTO.getTransactionBO().getCustomerDocType());
        //validateDocId(inDTO.getTransactionBO().getCustomerDocId());
        validateAgreement(pmtType+inDTO.getTransactionBO().getCommerce().getNuraCode());
    	validateURL(inDTO.getTransactionBO().getCommerce().getConfiguration().getResponseURL());
    	validateAgreementAuth(pmtType, inDTO.getTransactionBO().getCommerce());
        validateCustomerEmail(inDTO.getTransactionBO().getCustomerEmail());
        validatePhoneNumber(inDTO.getTransactionBO().getCustomerMobileNumber());
        validateOrderNumber(inDTO.getTransactionBO().getOrderNumber());
        validateDescription(inDTO.getTransactionBO().getDescription());
        validateTotalValue(inDTO.getTransactionBO().getTotalValue());
        validateCurrency(inDTO.getTransactionBO().getCurrency());
        validateTaxValue(inDTO.getTransactionBO().getTaxValue());
        validateTransactionType(inDTO.getTransactionBO().getTransactionType().getId());
        validateOrderNumberPending(pmtType, inDTO.getTransactionBO());
    }

	/**
     * Realiza la validación de un canal de origen.
     * 
     * @param channelId Canal de origen.
     * @throws ValidationException 
     */
    private void validateChannelSource(String channelId) throws ValidationException{
    	sourceValidator.setMandatory(true);
		sourceValidator.setBundleManager(bundleManager);
		sourceValidator.validate(channelId, locale);
	}

    /**
     * Realiza la validación de la fecha de solicitud.
     * 
     * @param clientDt				Fecha de solicitud.
     * @throws ValidationException	Si no supera las validaciones.
     */
	private void validateRqDate(Date clientDt) throws ValidationException{
		dateValidator.setMandatory(true);
		dateValidator.setBundleManager(bundleManager);
		dateValidator.validate(clientDt, locale);
	}

	/**
	 * Realiza la validación de la dirección IP origen de la transacción.
	 * 
	 * @param ipAddr 				Dirección ip origen.
	 * @throws ValidationException 	Si no supera las validaciones.
	 */
	private void validateIpAddress(String ipAddr) throws ValidationException {
		ipAddressValidator.setMandatory(true);
		ipAddressValidator.setBundleManager(bundleManager);
		ipAddressValidator.validate(ipAddr, locale);
	}

	/**
	 * Realiza la validación del tipo de documento del cliente.
	 * 
	 * @param customerDocType	Tipo de docuemnto del cliente.
	 * @throws ValidationException Si no supera las validaciones.
	 */
	private void validateDocType(String customerDocType) throws ValidationException{
		docTypeValidator.setMandatory(true);
		docTypeValidator.setBundleManager(bundleManager);
		docTypeValidator.validate(customerDocType, locale);
	}

	/**
	 * Realiza la validación del número de documento del cliente.
	 * 
	 * @param customerDocId Número de documento del cliente.
	 * @throws ValidationException En caso de no superar la validación.
	 */
	private void validateDocId(String customerDocId) throws ValidationException{
		docIdValidator.setMandatory(true);
		docIdValidator.setBundleManager(bundleManager);
		docIdValidator.validate(customerDocId, locale);
	}

	/**
	 * 
	 * @param nuraCode
	 * @throws ValidationException
	 */
	private void validateAgreement(String nuraCode) throws ValidationException{
//	    agreementValidator.setMandatory(true);
//	    agreementValidator.setBundleManager(bundleManager);
		agreementValidator.validate(nuraCode, locale);
	}

	/**
	 * Valida la URL de respuesta
	 * @param responseURL
	 * @throws ValidationException 
	 */
	private void validateURL(String responseURL) throws ValidationException{
		urlValidator.setMandatory(true);
		urlValidator.setBundleManager(bundleManager);
		urlValidator.validate(responseURL, locale);
	}
	
	/**
	 * Realiza la validación de los datos de autenticación del comercio.
	 * 
	 * @param commerce
	 * @throws ValidationException
	 */
	private void validateAgreementAuth(String pmtType, CommerceBO commerce) throws ValidationException{
		AgreementAuthData authData = new AgreementAuthData();
		authData.setCommerceId(pmtType+commerce.getNuraCode());
		authData.setUser(commerce.getConfiguration().getUser());
		authData.setPassword(commerce.getConfiguration().getPhrase());
		authenticatorValidator.validate(authData );
	}

	/**
	 * Realiza la validación del email del cliente.
	 * 
	 * @param customerEmail email del cliente.
	 * @throws ValidationException 
	 */
	private void validateCustomerEmail(String customerEmail) throws ValidationException{
		custEmailValidator.setMandatory(false);
		custEmailValidator.setBundleManager(bundleManager);
		custEmailValidator.validate(customerEmail, locale);
	}

	/**
	 * Realiza la validación del número telefónico.
	 * 
	 * @param customerMobileNumber
	 *            Número telefónico del cliente.
	 * @throws ValidationException
	 *             En caso de fallar la validación.
	 */
	private void validatePhoneNumber(String customerMobileNumber) throws ValidationException{
		phoneNumberValidator.setMandatory(false);
		phoneNumberValidator.setBundleManager(bundleManager);
		phoneNumberValidator.validate(customerMobileNumber, locale);
	}

	/**
	 * Realiza la validación del numero de orden.
	 * 
	 * @param orderNumber
	 *            Numero de orden.
	 * @throws ValidationException
	 *             En caso de fallar la validación.
	 */
	private void validateOrderNumber(String orderNumber) throws ValidationException{
		orderNumberValidator.setMandatory(true);
		orderNumberValidator.setBundleManager(bundleManager);
		orderNumberValidator.validate(orderNumber, locale);
	}

	/**
	 * Realiza la validación de la descripción.
	 * 
	 * @param description
	 *            descipción.
	 * @throws ValidationException
	 *             En caso de fallar la validación.
	 */
	private void validateDescription(String description) throws ValidationException{
		obligatoryValidator.setMandatory(true);
		obligatoryValidator.setBundleManager(bundleManager);
		obligatoryValidator.validate(description, locale);
	}

	/**
	 * Realiza la validación de valor total.
	 * 
	 * @param totalValue
	 *            Valor total.
	 * @throws ValidationException
	 *             En caso de fallar la validación.
	 */
	private void validateTotalValue(BigDecimal totalValue) throws ValidationException{
		totalValueValidator.setMandatory(true);
		totalValueValidator.setBundleManager(bundleManager);
		totalValueValidator.validate(totalValue, locale);
	}

	/**
	 * Realiza la validación del tipo de moneda.
	 * 
	 * @param currency
	 *            tipo de moneda.
	 * @throws ValidationException
	 *             En caso de fallar la validación.
	 */
	private void validateCurrency(String currency) throws ValidationException{
		currencyValidator.setMandatory(false);
		currencyValidator.setBundleManager(bundleManager);
		currencyValidator.validate(currency, locale);
	}

	/**
	 * Realiza la validación del valor de impuesto.
	 * 
	 * @param taxValue
	 *            Valor del impuesto.
	 * @throws ValidationException
	 *             En caso de fallar la validación.
	 */
	private void validateTaxValue(BigDecimal taxValue) throws ValidationException{
		taxValueValidator.setMandatory(true);
		taxValueValidator.setBundleManager(bundleManager);
		taxValueValidator.validate(taxValue, locale);
	}

	/**
	 * Realiza la validación del tipo de transacción.
	 * 
	 * @param id
	 *            Id del tipo de transacción.
	 * @throws ValidationException
	 *             En caso de fallar la validación.
	 */
	private void validateTransactionType(String id) throws ValidationException{
		transactionTypeValidator.setMandatory(true);
		transactionTypeValidator.setBundleManager(bundleManager);
		transactionTypeValidator.validate(id, locale);
	}
	
	/**
	 * 
	 * Realiza la validación del estado pendiente de un número de orden.
	 * @param transactionBO
	 * @throws ValidationException
	 */
	private void validateOrderNumberPending(String pmtType,TransactionBO transactionBO)	throws ValidationException{
		orderNumberPendingValidator.validate(pmtType, transactionBO);
	}
}