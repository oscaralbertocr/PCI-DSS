/*
 * URLValidator
 *  
 * GSI - Integración
 * Creado el: 22/09/2014
 *
 * Copyright (c) A Toda Hora S.A. Todos los derechos reservados
 * 
 * Este software es confidencial y es propietario de ATH, queda prohibido
 * su uso, reproducción y copia de manera parcial o permanente salvo autorización
 * expresa de A Toda Hora S.A o de quién represente sus derechos.
 */
package co.com.ath.pgw.persistence.validation.model.impl;

import java.util.Locale;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import co.com.ath.pgw.util.i18n.BundleKeys;
import co.com.ath.pgw.util.i18n.BundleType;
import co.com.ath.pgw.util.validation.AbstractAttributeValidator;
import co.com.ath.pgw.util.validation.ErrorCode;
import co.com.ath.pgw.util.validation.NotEmptyValidator;
import co.com.ath.pgw.util.validation.NotNullValidator;
import co.com.ath.pgw.util.validation.ObjectValidationException;
import co.com.ath.pgw.util.validation.ObjectValidator;
import co.com.ath.pgw.util.validation.ValidationException;;

/**
 * Validador de URL
 * 
 * @author proveedor_zagarcia
 * @version 1.0 22-sep-2014
 * @since 1.0
 */
@Service
public class URLValidator extends AbstractAttributeValidator {
	
	static Logger LOGGER = LoggerFactory.getLogger(URLValidator.class);
	
	private ObjectValidator validator;

	public URLValidator(){
		super();
	}

	@Override
	protected void doMandatoryValidate(Object attribute, Locale locale)throws ValidationException {
		LOGGER.info("...");
		validator = new NotNullValidator(new NotEmptyValidator());
		validator.setBundleManager(bundleManager);
		try {
			validator.validate(attribute, locale);
		} catch (ObjectValidationException e) {
			throw new ValidationException(
					getMessage(locale), 
					ErrorCode.INVALID_URL, e);
		}
		doOptionalValidate(attribute, locale);
		
	}

	@Override
	protected void doOptionalValidate(Object attribute, Locale locale)throws ValidationException {
		LOGGER.info("...");
		/*
		 * Por ahora no se valida que sea una URL válida 
		 */
	}
	
	private String getMessage(Locale locale) {
		LOGGER.info("...");
		if (bundleManager == null) {
			return BundleKeys.ERROR_INVALID_URL;
		}
		bundleManager.setBundle(BundleType.ERRORS);
		return bundleManager.getMessage(
			BundleKeys.ERROR_INVALID_URL, null, locale);
	}

}