/*
 * ReconciledTransactionService
 *  
 * GSI - Integración
 * Creado el: 13/01/2015
 *
 * Copyright (c) A Toda Hora S.A. Todos los derechos reservados
 * 
 * Este software es confidencial y es propietario de ATH, queda prohibido
 * su uso, reproducción y copia de manera parcial o permanente salvo autorización
 * expresa de A Toda Hora S.A o de quién represente sus derechos.
 */
package co.com.ath.pgw.persistence.service;

import co.com.ath.pgw.persistence.model.ReconciledTransaction;
import co.com.ath.pgw.persistence.model.Transaction;

/**
 * Clase de servicio para el proceso de conciliación de transacciones.
 *
 * @author Andrés Méndez Juanias <proveedor_mamendez@ath.com.co> 
 * @version 1.0 13/01/2015
 * @since 1.0
 */
public interface ReconciledTransactionService {
	
	/**
	 * Método encargado crear o actualizar el registro de conciliación.
	 * 
	 * @param tx
	 *            Transacción a conciliar.
	 * @param statusRed
	 *            Estado de la red, si el valor es NULL entonces toma el valor
	 *            de la transacción.
	 * @return Objeto de conciliación.
	 */
	public ReconciledTransaction createOrUpdate(Transaction tx, String statusRed);

}
