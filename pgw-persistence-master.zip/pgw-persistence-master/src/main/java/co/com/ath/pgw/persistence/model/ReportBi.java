package co.com.ath.pgw.persistence.model;

import java.math.BigDecimal;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import co.com.ath.pgw.persistence.PersistentObject;

/**
 * Datos de la vista REPORTE_PORTAL_PAGO
 * 
 * @author Diego Alejandro Galeano Garzon <diego.galeano@sophossolutions.com>
 *
 */

@Entity
@Table(name = "REPORTE_PORTAL_PAGO")
public class ReportBi implements PersistentObject {
	
	private static final long serialVersionUID = 6576675773819599155L;

	@Column(name = "IDBANCO") 
    private Integer idBank;

	@Column(name = "NOMBREBANCO") 
    private String nameBank;

	@Column(name = "ESAVALBANCO") 
    private Boolean avalEntity;
  
	@Column(name = "BANREPUBANCO") 
    private String republicaCodeBank;
 
	@Column(name = "ACHBANCO") 
    private  String achBank;

	@Column(name = "AVALBANCO") 
    private  String avalCodeBank;

	@Column(name = "COMPENBANCO") 
    private  String compensationCodeBank;
    
    @Temporal(TemporalType.TIMESTAMP)
	@Column(name = "FECCREABANCO") 
    private Date creationDateBank;

    @Temporal(TemporalType.TIMESTAMP)
	@Column(name = "FECMODBANCO") 
    private Date lastUpdateBank;

	@Column(name = "ELIMBANCO") 
    private Boolean deletedBank;

	@Column(name = "HOMOLOBANCO") 
    private String homoloBank;

	@Column(name = "IDCOMERCIO") 
    private Integer idCommerce;

	@Column(name = "NITCOMERCIO") 
    private Long nitCommerce; 

	@Column(name = "ESTCOMERCIO") 
    private  String statusCommerce;

	@Column(name = "CODEANCOMERCIO") 
    private  String eanCodeCommerce;

	@Column(name = "CODNURACOMERCIO") 
    private  String nuraCodeCommerce;

	@Column(name = "CODINCREDICOMERCIO") 
    private String incoCreditCodeCommerce; 

	@Column(name = "CODACHCOMERCIO") 
    private  String achCodeCommerce;

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "FECCREACOMERCIO") 
    private Date creationDateCommerce;
 
	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "FECMODCOMERCIO") 
    private  Date lastUpdateCommerce;

	@Column(name = "ELIMCOMERCIO") 
    private Boolean deletedCommerce;

	@Column(name = "HOMOCODCOMERCIO") 
    private  String homologationBavvCodeCommerce;

	@Column(name = "CODTERMCOMERCIO") 
    private  String terminalCodeCommerce;

	@Column(name = "AGREGADORCOMERCIO") 
    private  Integer aggregatorCommerce;

	@Column(name = "ACTIVECONOCOMERCIO") 
    private  String economicActivityCommerce;

	@Column(name = "ZIPBANCCOMERCIO") 
    private Long zipaSobancariaCommerce;

	@Column(name = "TARCREDCOMERCIO") 
    private  String creditCardCommerce;

	@Column(name = "IDESTANEGO") 
    private Long  idEstaNego;

	@Column(name = "ESTADOESTANEGO") 
    private  String descriptionEstaNego;

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "FECCREAESTANEGO") 
    private  Date creationDateEstaNego;

	@Column(name = "ELIMESTANEGO") 
    private Boolean deletedEstaNego;

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "FECMODESTANEGO") 
    private  Date lastUpdateEstaNego;

	@Column(name = "IDESTATRANSAC") 
    private Long idEstaTransac;

	@Column(name = "IDESTNEGESTATRANSAC") 
    private Long businessCodeEstaTransac; 

	@Column(name = "ESTADOESTATRANSAC") 
    private  String descriptionEstaTransac;

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "FECCREAESTATRANSAC") 
    private  Date creationDateEstaTransac;

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "FECMODESTATRANSAC") 
    private  Date lastUpdateEstaTransac;

	@Column(name = "ELIMESTATRANSAC") 
    private Boolean deletedEstaTransac;

	@Column(name = "IDMEDPAGO") 
    private Long idMedPago;

	@Column(name = "MEDPAGO") 
    private  String nameMedPago;

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "FECCREAMEDPAGO") 
    private  Date creationDateMedPago;

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "FECMODMEDPAGO") 
    private  Date lastUpdateMedPago;

	@Column(name = "ELIMMEDPAGO") 
    private Boolean deletedMedPago;

	@Column(name = "IDCOMMEDPAGOCOM") 
    private Long idMedPagoCom;

	@Column(name = "IDMEDPAGOCOM") 
    private Long paymentWayMedPagoCom;

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "FECCREAMEDPAGOCOM") 
    private  Date creationDateMedPagoCom;

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "FECMODMEDPAGOCOM") 
    private  Date lastUpdateMedPagoCom;

	@Column(name = "ELIMMEDPAGOCOM") 
    private Boolean deletedMedPagoCom;

	@Column(name = "CUENASOCIMEDPAGOCOM") 
    private  String authorizedAccountMedPagoCom;

	@Column(name = "IDASOBMEDPAGOCOM") 
    private Long idAsobancariaMedPagoCom;

	@Column(name = "IDASOBPROMEDPAGOCOM") 
    private Long idProcedenciaMedPagoCom;

	@Column(name = "IDASOBTIPCUEMEDPAGOCOM") 
    private Long asobancariaTipCuenMedPagoCom;

	@Column(name = "IDASOBTIPRECMEDPAGOCOM") 
    private Long tipoRecaudoMedPagoCom; 

	@Column(name = "TIPCUEMEDPAGOCOM") 
    private Integer tipoCuentaMedPagoCom;

	@Column(name = "DESCRTIPCUEMEDPAGOCOM") 
    private String descriptionMedPagoCom;

	@Column(name = "IDORITRANSAC") 
    private Long idOriTransac;

	@Column(name = "ORIGENTRANSACCION") 
    private String nameOriTransac;

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "FECCREAORITRANSAC") 
    private Date creationDateOriTransac;

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "FECMODORITRANSAC") 
    private  Date lastUpdateOriTransac;

	@Column(name = "ELIMORITRANSAC") 
    private Boolean deletedOriTransac;

	@Column(name = "CANALORITRANSAC") 
    private String canalOriTransac;
	
	@Column(name = "IDPORTALORITRANSAC") 
    private Long sourcePortalOriTransac;

	@Column(name = "COMERSUBS") 
    private Long idComerSubs;

	@Column(name = "BANCSUBS") 
    private Long idBankSubs;

	@Column(name = "MUNISUBS") 
    private Long idMuniSubs;

	@Column(name = "RASOSOCISUBS") 
    private String companyNameSubs;

	@Column(name = "DIGVERISUBS") 
    private Integer checkDigitSubs;

	@Column(name = "DIRSUBS") 
    private String addressSubs;

	@Column(name = "TELSUBS") 
    private  String phoneSubs;

	@Column(name = "EMAILSUBS") 
    private  String emailSubs;

	@Column(name = "FAXSUBS") 
    private  String faxSubs;

	@Column(name = "REPRLEGALSUBS") 
    private  String legalAgentSubs;

	@Column(name = "CEDREPRLEGALSUBS") 
    private  String legalAgentIdSubs;

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "FECCREASUBS") 
    private  Date creationDateSubs;

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "REGFECCREASUBS") 
    private  Date regCreationDateSubs;

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "FECMODSUBS") 
    private  Date lastUpdateSubs;

	@Column(name = "ELIMSUBS") 
    private Boolean deletedSubs;

	@Column(name = "APELLREPRSUBS") 
    private String legalAgentLastNameSubs;

	@Column(name = "TIPDOCUSUBS") 
    private  String legalAgentTypeSubs;

	@Id
	@Column(name = "IDTRANSAC") 
    private Long idTransac;

	@Column(name = "IDCOMTRANSAC") 
    private Long idComercioTransac;

	@Column(name = "IDESTADOTRANSAC") 
    private Long statusTransac;

	@Column(name = "TIPTRANSAC") 
    private Long transactionTypeTransac;

	@Column(name = "IDORIGETRANSAC") 
    private Long sourceTransac;

	@Column(name = "IDMEDPAGTRANSAC") 
    private Long paymentWayTransac;

	@Column(name = "IDTIPPRODUCTRANSAC") 
    private Long productTypeTransac;

	@Column(name = "IDTARJCREDITTRANSAC") 
    private Long creditCardTransac;

	@Column(name = "IDTRANREDTRANSAC") 
    private String trazabilityCodeTransac;

	@Column(name = "IDBANCTRANSAC") 
    private Long idBankTransac;

	@Column(name = "IDTIPPERSONATRANSAC") 
    private Integer customerTypeTransac;

	@Column(name = "IPTRANSAC") 
    private String ipAddressTransac;

	@Column(name = "CODRESPUTRANSAC") 
    private String responseCodeTransac;

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "FECTRANSAC") 
    private Date creationDateTransac;

	@Column(name = "NUMORDENTRANSAC") 
    private  String orderNumTransac;

	@Column(name = "VALTOTALTRANSAC") 
    private BigDecimal totalValueTransac;

	@Column(name = "VALIMPUESTRANSAC") 
    private BigDecimal taxtValueTransac;

	@Column(name = "MONEDATRANSAC") 
    private  String currencyTransac;

	@Column(name = "DESCRIPTRANSAC") 
    private  String descriptionTransac;

	@Column(name = "NUMAPROBTRANSAC") 
    private  String approvalNumberTransac;

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "FECPAGOTRANSAC") 
    private Date payDateTransac;

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "FECCOMPENTRANSAC") 
    private  Date compensationDateTransac;

	@Column(name = "TIPDOCUCOMPRATRANSAC") 
    private  String customerDocTypeTransac;

	@Column(name = "NUMDOCUCOMPRATRANSAC") 
    private  String customerDocIdTransac;

	@Column(name = "NOMBCOMPRATRANSAC") 
    private  String customerNameTransac;

	@Column(name = "EMAILCOMPRATRANSAC") 
    private  String customerEmailTransac;

	@Column(name = "CELCOMPRATRANSAC") 
    private  String customerMobileNumberTransac;

	@Column(name = "REF1TRANSAC") 
    private  String ref1Transac;

	@Column(name = "REF2TRANSAC") 
    private  String ref2Transac;

	@Column(name = "REF3TRANSAC") 
    private String ref3Transac;

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "FECCREATRANSAC") 
    private  Date regCreationDateTransac;

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "FECMODTRANSAC") 
    private  Date regLastUpdateTransac;

	@Column(name = "ELIMTRANSAC") 
    private Boolean deletedTransac;

	@Column(name = "BLOQJOBTRANSAC") 
    private Long jobLockTransac;

	@Column(name = "PMTIDTRANSAC") 
    private Long pmtIdTransac;

	@Column(name = "COMPANIAPAGATRANSAC") 
    private String payerCompanyTransac;

	@Column(name = "NOMBPAGATRANSAC") 
    private  String payerNameTransac;

	@Column(name = "ALIASPAGATRANSAC") 
    private  String payerNickNameTransac;

	@Column(name = "TIPDOCUPAGATRANSAC") 
    private  String payerDocTypeTransac;

	@Column(name = "NUMDOCUPAGATRANSAC") 
    private  String payerDocIdTransac;

	@Column(name = "GENPAGATRANSAC") 
    private  String payerGenderTransac;

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "FECNACIPAGATRANSAC") 
    private  Date payerBirthDateTransac;

	@Column(name = "CIUDADPAGATRANSAC") 
    private  String payerCityTransac;

	@Column(name = "DEPAPAGATRANSAC") 
    private  String payerDepartmentTransac;

	@Column(name = "PAISPAGATRANSAC") 
    private  String payerCountyTransac;

	@Column(name = "DIRPAGATRANSAC") 
    private  String payerAddressTransac;

	@Column(name = "EMAILPAGATRANSAC") 
    private  String payerEmailTransac;

	@Column(name = "TELPAGATRANSAC") 
    private  String payerPhoneTransac;

	@Column(name = "NUMTARJECREDITTRANSAC") 
    private  String creditCardNumberTransac;

	@Column(name = "IDBRNADTRANSAC") 
    private  Long idBrandTransac;

	@Column(name = "URLRESPTRANSAC") 
    private  String urlResponseTransac;

	@Column(name = "INTENPAGOTRANSAC") 
    private  String categoryIdTransac;

	@Column(name = "MONEDATRMTRANSAC") 
    private  String curCodeTrmTransac;

	@Column(name = "REFPAGO2TRANSAC") 
    private  String refPago2Transac;

	@Column(name = "REFPAGO3TRANSAC") 
    private  String refPago3Transac;

	@Column(name = "REFPAGO4TRANSAC") 
    private  String refPago4Transac;

	@Column(name = "TIPPAGOTRANSAC") 
    private  String pmtTypeTransac;

	@Column(name = "TRMTRANSAC") 
    private  String trmTransac;

	@Column(name = "CANALTRANSAC") 
    private  String canalTransac;

	@Column(name = "CICLOTRANSAC") 
    private  String trnCycleTransac;

	@Column(name = "TIPOTRANSAC") 
    private  String trnTypeTransac;

	@Column(name = "RQUIDTRANSAC") 
    private  String rquIdTransac;

	@Column(name = "APELLCOMPRATRANSAC") 
    private  String lastNameBuyerTransac;

	@Column(name = "APELLPAGATRANSAC") 
    private  String lastNamePayerTransac;

	@Column(name = "SEGNOMCOMPRATRANSAC") 
    private  String middleNameBuyerTransac;

	@Column(name = "SEGNOMPAGATRANSAC") 
    private  String middleNamePayerTransac;

	@Column(name = "SEGAPELLCOMPRATRANSAC") 
    private  String secondLastNameBuyerTransac;

	@Column(name = "SEGAPELLPAGATRANSAC") 
    private  String secondLastNamePayerTransac;

	@Column(name = "FLAGCOREOTRANSAC") 
    private  Integer emailflagTransac;

	@Column(name = "TYPEDOCTRANSAC") 
    private  String idTypeDocTransac;

	@Column(name = "NUMDOCTRANSAC") 
    private  String numDocTransac;

	@Column(name = "PLANTILLATRANSAC") 
    private  Integer plantillaTransac;

	@Column(name = "TAQUILLASTRANSAC") 
    private  Integer taquillaTransac;

	@Column(name = "TOKENIZADOTRANSAC") 
    private  String tokenizedTransac;

	@Column(name = "BANCRECAUTRANSAC") 
    private Long bankCollecterTransac;

	@Column(name = "CUENTARECAUTRANSAC") 
    private  String collectAcountTransac;

	
	public boolean isRowDeleted() {
		// TODO Auto-generated method stub
		return false;
	}

	public void setRowDeleted(Boolean rowDeleted) {
		// TODO Auto-generated method stub
		
	}

	public Date getRowCreationDate() {
		// TODO Auto-generated method stub
		return null;
	}

	public void setRowCreationDate(Date rowCreationDate) {
		// TODO Auto-generated method stub
		
	}

	public Date getRowLastUpdate() {
		// TODO Auto-generated method stub
		return null;
	}

	public void setRowLastUpdate(Date rowLastUpdate) {
		// TODO Auto-generated method stub
		
	}

	/**
	 * @return the idBank
	 */
	public Integer getIdBank() {
		return idBank;
	}

	/**
	 * @param idBank the idBank to set
	 */
	public void setIdBank(Integer idBank) {
		this.idBank = idBank;
	}

	/**
	 * @return the nameBank
	 */
	public String getNameBank() {
		return nameBank;
	}

	/**
	 * @param nameBank the nameBank to set
	 */
	public void setNameBank(String nameBank) {
		this.nameBank = nameBank;
	}

	/**
	 * @return the avalEntity
	 */
	public Boolean isAvalEntity() {
		return avalEntity;
	}

	/**
	 * @param avalEntity the avalEntity to set
	 */
	public void setAvalEntity(Boolean avalEntity) {
		this.avalEntity = avalEntity;
	}

	/**
	 * @return the republicaCodeBank
	 */
	public String getRepublicaCodeBank() {
		return republicaCodeBank;
	}

	/**
	 * @param republicaCodeBank the republicaCodeBank to set
	 */
	public void setRepublicaCodeBank(String republicaCodeBank) {
		this.republicaCodeBank = republicaCodeBank;
	}

	/**
	 * @return the achBank
	 */
	public String getAchBank() {
		return achBank;
	}

	/**
	 * @param achBank the achBank to set
	 */
	public void setAchBank(String achBank) {
		this.achBank = achBank;
	}

	/**
	 * @return the avalCodeBank
	 */
	public String getAvalCodeBank() {
		return avalCodeBank;
	}

	/**
	 * @param avalCodeBank the avalCodeBank to set
	 */
	public void setAvalCodeBank(String avalCodeBank) {
		this.avalCodeBank = avalCodeBank;
	}

	/**
	 * @return the compensationCodeBank
	 */
	public String getCompensationCodeBank() {
		return compensationCodeBank;
	}

	/**
	 * @param compensationCodeBank the compensationCodeBank to set
	 */
	public void setCompensationCodeBank(String compensationCodeBank) {
		this.compensationCodeBank = compensationCodeBank;
	}

	/**
	 * @return the creationDateBank
	 */
	public Date getCreationDateBank() {
		return creationDateBank;
	}

	/**
	 * @param creationDateBank the creationDateBank to set
	 */
	public void setCreationDateBank(Date creationDateBank) {
		this.creationDateBank = creationDateBank;
	}

	/**
	 * @return the lastUpdateBank
	 */
	public Date getLastUpdateBank() {
		return lastUpdateBank;
	}

	/**
	 * @param lastUpdateBank the lastUpdateBank to set
	 */
	public void setLastUpdateBank(Date lastUpdateBank) {
		this.lastUpdateBank = lastUpdateBank;
	}

	/**
	 * @return the deletedBank
	 */
	public Boolean isDeletedBank() {
		return deletedBank;
	}

	/**
	 * @param deletedBank the deletedBank to set
	 */
	public void setDeletedBank(Boolean deletedBank) {
		this.deletedBank = deletedBank;
	}

	/**
	 * @return the homoloBank
	 */
	public String getHomoloBank() {
		return homoloBank;
	}

	/**
	 * @param homoloBank the homoloBank to set
	 */
	public void setHomoloBank(String homoloBank) {
		this.homoloBank = homoloBank;
	}

	/**
	 * @return the idCommerce
	 */
	public Integer getIdCommerce() {
		return idCommerce;
	}

	/**
	 * @param idCommerce the idCommerce to set
	 */
	public void setIdCommerce(Integer idCommerce) {
		this.idCommerce = idCommerce;
	}

	/**
	 * @return the nitCommerce
	 */
	public Long getNitCommerce() {
		return nitCommerce;
	}

	/**
	 * @param nitCommerce the nitCommerce to set
	 */
	public void setNitCommerce(Long nitCommerce) {
		this.nitCommerce = nitCommerce;
	}

	/**
	 * @return the statusCommerce
	 */
	public String getStatusCommerce() {
		return statusCommerce;
	}

	/**
	 * @param statusCommerce the statusCommerce to set
	 */
	public void setStatusCommerce(String statusCommerce) {
		this.statusCommerce = statusCommerce;
	}

	/**
	 * @return the eanCodeCommerce
	 */
	public String getEanCodeCommerce() {
		return eanCodeCommerce;
	}

	/**
	 * @param eanCodeCommerce the eanCodeCommerce to set
	 */
	public void setEanCodeCommerce(String eanCodeCommerce) {
		this.eanCodeCommerce = eanCodeCommerce;
	}

	/**
	 * @return the nuraCodeCommerce
	 */
	public String getNuraCodeCommerce() {
		return nuraCodeCommerce;
	}

	/**
	 * @param nuraCodeCommerce the nuraCodeCommerce to set
	 */
	public void setNuraCodeCommerce(String nuraCodeCommerce) {
		this.nuraCodeCommerce = nuraCodeCommerce;
	}

	/**
	 * @return the incoCreditCodeCommerce
	 */
	public String getIncoCreditCodeCommerce() {
		return incoCreditCodeCommerce;
	}

	/**
	 * @param incoCreditCodeCommerce the incoCreditCodeCommerce to set
	 */
	public void setIncoCreditCodeCommerce(String incoCreditCodeCommerce) {
		this.incoCreditCodeCommerce = incoCreditCodeCommerce;
	}

	/**
	 * @return the achCodeCommerce
	 */
	public String getAchCodeCommerce() {
		return achCodeCommerce;
	}

	/**
	 * @param achCodeCommerce the achCodeCommerce to set
	 */
	public void setAchCodeCommerce(String achCodeCommerce) {
		this.achCodeCommerce = achCodeCommerce;
	}

	/**
	 * @return the creationDateCommerce
	 */
	public Date getCreationDateCommerce() {
		return creationDateCommerce;
	}

	/**
	 * @param creationDateCommerce the creationDateCommerce to set
	 */
	public void setCreationDateCommerce(Date creationDateCommerce) {
		this.creationDateCommerce = creationDateCommerce;
	}

	/**
	 * @return the lastUpdateCommerce
	 */
	public Date getLastUpdateCommerce() {
		return lastUpdateCommerce;
	}

	/**
	 * @param lastUpdateCommerce the lastUpdateCommerce to set
	 */
	public void setLastUpdateCommerce(Date lastUpdateCommerce) {
		this.lastUpdateCommerce = lastUpdateCommerce;
	}

	/**
	 * @return the deletedCommerce
	 */
	public Boolean isDeletedCommerce() {
		return deletedCommerce;
	}

	/**
	 * @param deletedCommerce the deletedCommerce to set
	 */
	public void setDeletedCommerce(Boolean deletedCommerce) {
		this.deletedCommerce = deletedCommerce;
	}

	/**
	 * @return the homologationBavvCodeCommerce
	 */
	public String getHomologationBavvCodeCommerce() {
		return homologationBavvCodeCommerce;
	}

	/**
	 * @param homologationBavvCodeCommerce the homologationBavvCodeCommerce to set
	 */
	public void setHomologationBavvCodeCommerce(String homologationBavvCodeCommerce) {
		this.homologationBavvCodeCommerce = homologationBavvCodeCommerce;
	}

	/**
	 * @return the terminalCodeCommerce
	 */
	public String getTerminalCodeCommerce() {
		return terminalCodeCommerce;
	}

	/**
	 * @param terminalCodeCommerce the terminalCodeCommerce to set
	 */
	public void setTerminalCodeCommerce(String terminalCodeCommerce) {
		this.terminalCodeCommerce = terminalCodeCommerce;
	}

	/**
	 * @return the aggregatorCommerce
	 */
	public Integer getAggregatorCommerce() {
		return aggregatorCommerce;
	}

	/**
	 * @param aggregatorCommerce the aggregatorCommerce to set
	 */
	public void setAggregatorCommerce(Integer aggregatorCommerce) {
		this.aggregatorCommerce = aggregatorCommerce;
	}

	/**
	 * @return the economicActivityCommerce
	 */
	public String getEconomicActivityCommerce() {
		return economicActivityCommerce;
	}

	/**
	 * @param economicActivityCommerce the economicActivityCommerce to set
	 */
	public void setEconomicActivityCommerce(String economicActivityCommerce) {
		this.economicActivityCommerce = economicActivityCommerce;
	}

	/**
	 * @return the zipaSobancariaCommerce
	 */
	public Long getZipaSobancariaCommerce() {
		return zipaSobancariaCommerce;
	}

	/**
	 * @param zipaSobancariaCommerce the zipaSobancariaCommerce to set
	 */
	public void setZipaSobancariaCommerce(Long zipaSobancariaCommerce) {
		this.zipaSobancariaCommerce = zipaSobancariaCommerce;
	}

	/**
	 * @return the creditCardCommerce
	 */
	public String getCreditCardCommerce() {
		return creditCardCommerce;
	}

	/**
	 * @param creditCardCommerce the creditCardCommerce to set
	 */
	public void setCreditCardCommerce(String creditCardCommerce) {
		this.creditCardCommerce = creditCardCommerce;
	}

	/**
	 * @return the idEstaNego
	 */
	public Long getIdEstaNego() {
		return idEstaNego;
	}

	/**
	 * @param idEstaNego the idEstaNego to set
	 */
	public void setIdEstaNego(Long idEstaNego) {
		this.idEstaNego = idEstaNego;
	}

	/**
	 * @return the descriptionEstaNego
	 */
	public String getDescriptionEstaNego() {
		return descriptionEstaNego;
	}

	/**
	 * @param descriptionEstaNego the descriptionEstaNego to set
	 */
	public void setDescriptionEstaNego(String descriptionEstaNego) {
		this.descriptionEstaNego = descriptionEstaNego;
	}

	/**
	 * @return the creationDateEstaNego
	 */
	public Date getCreationDateEstaNego() {
		return creationDateEstaNego;
	}

	/**
	 * @param creationDateEstaNego the creationDateEstaNego to set
	 */
	public void setCreationDateEstaNego(Date creationDateEstaNego) {
		this.creationDateEstaNego = creationDateEstaNego;
	}

	/**
	 * @return the deletedEstaNego
	 */
	public Boolean isDeletedEstaNego() {
		return deletedEstaNego;
	}

	/**
	 * @param deletedEstaNego the deletedEstaNego to set
	 */
	public void setDeletedEstaNego(Boolean deletedEstaNego) {
		this.deletedEstaNego = deletedEstaNego;
	}

	/**
	 * @return the lastUpdateEstaNego
	 */
	public Date getLastUpdateEstaNego() {
		return lastUpdateEstaNego;
	}

	/**
	 * @param lastUpdateEstaNego the lastUpdateEstaNego to set
	 */
	public void setLastUpdateEstaNego(Date lastUpdateEstaNego) {
		this.lastUpdateEstaNego = lastUpdateEstaNego;
	}

	/**
	 * @return the idEstaTransac
	 */
	public Long getIdEstaTransac() {
		return idEstaTransac;
	}

	/**
	 * @param idEstaTransac the idEstaTransac to set
	 */
	public void setIdEstaTransac(Long idEstaTransac) {
		this.idEstaTransac = idEstaTransac;
	}

	/**
	 * @return the businessCodeEstaTransac
	 */
	public Long getBusinessCodeEstaTransac() {
		return businessCodeEstaTransac;
	}

	/**
	 * @param businessCodeEstaTransac the businessCodeEstaTransac to set
	 */
	public void setBusinessCodeEstaTransac(Long businessCodeEstaTransac) {
		this.businessCodeEstaTransac = businessCodeEstaTransac;
	}

	/**
	 * @return the descriptionEstaTransac
	 */
	public String getDescriptionEstaTransac() {
		return descriptionEstaTransac;
	}

	/**
	 * @param descriptionEstaTransac the descriptionEstaTransac to set
	 */
	public void setDescriptionEstaTransac(String descriptionEstaTransac) {
		this.descriptionEstaTransac = descriptionEstaTransac;
	}

	/**
	 * @return the creationDateEstaTransac
	 */
	public Date getCreationDateEstaTransac() {
		return creationDateEstaTransac;
	}

	/**
	 * @param creationDateEstaTransac the creationDateEstaTransac to set
	 */
	public void setCreationDateEstaTransac(Date creationDateEstaTransac) {
		this.creationDateEstaTransac = creationDateEstaTransac;
	}

	/**
	 * @return the lastUpdateEstaTransac
	 */
	public Date getLastUpdateEstaTransac() {
		return lastUpdateEstaTransac;
	}

	/**
	 * @param lastUpdateEstaTransac the lastUpdateEstaTransac to set
	 */
	public void setLastUpdateEstaTransac(Date lastUpdateEstaTransac) {
		this.lastUpdateEstaTransac = lastUpdateEstaTransac;
	}

	/**
	 * @return the deletedEstaTransac
	 */
	public Boolean isDeletedEstaTransac() {
		return deletedEstaTransac;
	}

	/**
	 * @param deletedEstaTransac the deletedEstaTransac to set
	 */
	public void setDeletedEstaTransac(Boolean deletedEstaTransac) {
		this.deletedEstaTransac = deletedEstaTransac;
	}

	/**
	 * @return the idMedPago
	 */
	public Long getIdMedPago() {
		return idMedPago;
	}

	/**
	 * @param idMedPago the idMedPago to set
	 */
	public void setIdMedPago(Long idMedPago) {
		this.idMedPago = idMedPago;
	}

	/**
	 * @return the nameMedPago
	 */
	public String getNameMedPago() {
		return nameMedPago;
	}

	/**
	 * @param nameMedPago the nameMedPago to set
	 */
	public void setNameMedPago(String nameMedPago) {
		this.nameMedPago = nameMedPago;
	}

	/**
	 * @return the cerationDateMedPago
	 */
	public Date getCreationDateMedPago() {
		return creationDateMedPago;
	}

	/**
	 * @param cerationDateMedPago the cerationDateMedPago to set
	 */
	public void setCreationDateMedPago(Date cerationDateMedPago) {
		this.creationDateMedPago = cerationDateMedPago;
	}

	/**
	 * @return the lastUpdateMedPago
	 */
	public Date getLastUpdateMedPago() {
		return lastUpdateMedPago;
	}

	/**
	 * @param lastUpdateMedPago the lastUpdateMedPago to set
	 */
	public void setLastUpdateMedPago(Date lastUpdateMedPago) {
		this.lastUpdateMedPago = lastUpdateMedPago;
	}

	/**
	 * @return the deletedMedPago
	 */
	public Boolean isDeletedMedPago() {
		return deletedMedPago;
	}

	/**
	 * @param deletedMedPago the deletedMedPago to set
	 */
	public void setDeletedMedPago(Boolean deletedMedPago) {
		this.deletedMedPago = deletedMedPago;
	}

	/**
	 * @return the idMedPagoCom
	 */
	public Long getIdMedPagoCom() {
		return idMedPagoCom;
	}

	/**
	 * @param idMedPagoCom the idMedPagoCom to set
	 */
	public void setIdMedPagoCom(Long idMedPagoCom) {
		this.idMedPagoCom = idMedPagoCom;
	}

	/**
	 * @return the paymentWayMedPagoCom
	 */
	public Long getPaymentWayMedPagoCom() {
		return paymentWayMedPagoCom;
	}

	/**
	 * @param paymentWayMedPagoCom the paymentWayMedPagoCom to set
	 */
	public void setPaymentWayMedPagoCom(Long paymentWayMedPagoCom) {
		this.paymentWayMedPagoCom = paymentWayMedPagoCom;
	}

	/**
	 * @return the creationDateMedPagoCom
	 */
	public Date getCreationDateMedPagoCom() {
		return creationDateMedPagoCom;
	}

	/**
	 * @param creationDateMedPagoCom the creationDateMedPagoCom to set
	 */
	public void setCreationDateMedPagoCom(Date creationDateMedPagoCom) {
		this.creationDateMedPagoCom = creationDateMedPagoCom;
	}

	/**
	 * @return the lastUpdateMedPagoCom
	 */
	public Date getLastUpdateMedPagoCom() {
		return lastUpdateMedPagoCom;
	}

	/**
	 * @param lastUpdateMedPagoCom the lastUpdateMedPagoCom to set
	 */
	public void setLastUpdateMedPagoCom(Date lastUpdateMedPagoCom) {
		this.lastUpdateMedPagoCom = lastUpdateMedPagoCom;
	}

	/**
	 * @return the deletedMedPagoCom
	 */
	public Boolean isDeletedMedPagoCom() {
		return deletedMedPagoCom;
	}

	/**
	 * @param deletedMedPagoCom the deletedMedPagoCom to set
	 */
	public void setDeletedMedPagoCom(Boolean deletedMedPagoCom) {
		this.deletedMedPagoCom = deletedMedPagoCom;
	}

	/**
	 * @return the authorizedAccountMedPagoCom
	 */
	public String getAuthorizedAccountMedPagoCom() {
		return authorizedAccountMedPagoCom;
	}

	/**
	 * @param authorizedAccountMedPagoCom the authorizedAccountMedPagoCom to set
	 */
	public void setAuthorizedAccountMedPagoCom(String authorizedAccountMedPagoCom) {
		this.authorizedAccountMedPagoCom = authorizedAccountMedPagoCom;
	}

	/**
	 * @return the idAsobancariaMedPagoCom
	 */
	public Long getIdAsobancariaMedPagoCom() {
		return idAsobancariaMedPagoCom;
	}

	/**
	 * @param idAsobancariaMedPagoCom the idAsobancariaMedPagoCom to set
	 */
	public void setIdAsobancariaMedPagoCom(Long idAsobancariaMedPagoCom) {
		this.idAsobancariaMedPagoCom = idAsobancariaMedPagoCom;
	}

	/**
	 * @return the idProcedenciaMedPagoCom
	 */
	public Long getIdProcedenciaMedPagoCom() {
		return idProcedenciaMedPagoCom;
	}

	/**
	 * @param idProcedenciaMedPagoCom the idProcedenciaMedPagoCom to set
	 */
	public void setIdProcedenciaMedPagoCom(Long idProcedenciaMedPagoCom) {
		this.idProcedenciaMedPagoCom = idProcedenciaMedPagoCom;
	}

	/**
	 * @return the asobancariaTipCuenMedPagoCom
	 */
	public Long getAsobancariaTipCuenMedPagoCom() {
		return asobancariaTipCuenMedPagoCom;
	}

	/**
	 * @param asobancariaTipCuenMedPagoCom the asobancariaTipCuenMedPagoCom to set
	 */
	public void setAsobancariaTipCuenMedPagoCom(Long asobancariaTipCuenMedPagoCom) {
		this.asobancariaTipCuenMedPagoCom = asobancariaTipCuenMedPagoCom;
	}

	/**
	 * @return the tipoRecaudoMedPagoCom
	 */
	public Long getTipoRecaudoMedPagoCom() {
		return tipoRecaudoMedPagoCom;
	}

	/**
	 * @param tipoRecaudoMedPagoCom the tipoRecaudoMedPagoCom to set
	 */
	public void setTipoRecaudoMedPagoCom(Long tipoRecaudoMedPagoCom) {
		this.tipoRecaudoMedPagoCom = tipoRecaudoMedPagoCom;
	}

	/**
	 * @return the tipoCuentaMedPagoCom
	 */
	public Integer getTipoCuentaMedPagoCom() {
		return tipoCuentaMedPagoCom;
	}

	/**
	 * @param tipoCuentaMedPagoCom the tipoCuentaMedPagoCom to set
	 */
	public void setTipoCuentaMedPagoCom(Integer tipoCuentaMedPagoCom) {
		this.tipoCuentaMedPagoCom = tipoCuentaMedPagoCom;
	}

	/**
	 * @return the descriptionMedPagoCom
	 */
	public String getDescriptionMedPagoCom() {
		return descriptionMedPagoCom;
	}

	/**
	 * @param descriptionMedPagoCom the descriptionMedPagoCom to set
	 */
	public void setDescriptionMedPagoCom(String descriptionMedPagoCom) {
		this.descriptionMedPagoCom = descriptionMedPagoCom;
	}

	/**
	 * @return the idOriTransac
	 */
	public Long getIdOriTransac() {
		return idOriTransac;
	}

	/**
	 * @param idOriTransac the idOriTransac to set
	 */
	public void setIdOriTransac(Long idOriTransac) {
		this.idOriTransac = idOriTransac;
	}

	/**
	 * @return the nameOriTransac
	 */
	public String getNameOriTransac() {
		return nameOriTransac;
	}

	/**
	 * @param nameOriTransac the nameOriTransac to set
	 */
	public void setNameOriTransac(String nameOriTransac) {
		this.nameOriTransac = nameOriTransac;
	}

	/**
	 * @return the creationDateOriTransac
	 */
	public Date getCreationDateOriTransac() {
		return creationDateOriTransac;
	}

	/**
	 * @param creationDateOriTransac the creationDateOriTransac to set
	 */
	public void setCreationDateOriTransac(Date creationDateOriTransac) {
		this.creationDateOriTransac = creationDateOriTransac;
	}

	/**
	 * @return the lastUpdateOriTransac
	 */
	public Date getLastUpdateOriTransac() {
		return lastUpdateOriTransac;
	}

	/**
	 * @param lastUpdateOriTransac the lastUpdateOriTransac to set
	 */
	public void setLastUpdateOriTransac(Date lastUpdateOriTransac) {
		this.lastUpdateOriTransac = lastUpdateOriTransac;
	}

	/**
	 * @return the deletedOriTransac
	 */
	public Boolean isDeletedOriTransac() {
		return deletedOriTransac;
	}

	/**
	 * @param deletedOriTransac the deletedOriTransac to set
	 */
	public void setDeletedOriTransac(Boolean deletedOriTransac) {
		this.deletedOriTransac = deletedOriTransac;
	}

	/**
	 * @return the canalOriTransac
	 */
	public String getCanalOriTransac() {
		return canalOriTransac;
	}

	/**
	 * @param canalOriTransac the canalOriTransac to set
	 */
	public void setCanalOriTransac(String canalOriTransac) {
		this.canalOriTransac = canalOriTransac;
	}

	/**
	 * @return the sourcePortalOriTransac
	 */
	public Long getSourcePortalOriTransac() {
		return sourcePortalOriTransac;
	}

	/**
	 * @param sourcePortalOriTransac the sourcePortalOriTransac to set
	 */
	public void setSourcePortalOriTransac(Long sourcePortalOriTransac) {
		this.sourcePortalOriTransac = sourcePortalOriTransac;
	}

	/**
	 * @return the idComerSubs
	 */
	public Long getIdComerSubs() {
		return idComerSubs;
	}

	/**
	 * @param idComerSubs the idComerSubs to set
	 */
	public void setIdComerSubs(Long idComerSubs) {
		this.idComerSubs = idComerSubs;
	}

	/**
	 * @return the idBankSubs
	 */
	public Long getIdBankSubs() {
		return idBankSubs;
	}

	/**
	 * @param idBankSubs the idBankSubs to set
	 */
	public void setIdBankSubs(Long idBankSubs) {
		this.idBankSubs = idBankSubs;
	}

	/**
	 * @return the idMuniSubs
	 */
	public Long getIdMuniSubs() {
		return idMuniSubs;
	}

	/**
	 * @param idMuniSubs the idMuniSubs to set
	 */
	public void setIdMuniSubs(Long idMuniSubs) {
		this.idMuniSubs = idMuniSubs;
	}

	/**
	 * @return the companyNameSubs
	 */
	public String getCompanyNameSubs() {
		return companyNameSubs;
	}

	/**
	 * @param companyNameSubs the companyNameSubs to set
	 */
	public void setCompanyNameSubs(String companyNameSubs) {
		this.companyNameSubs = companyNameSubs;
	}

	/**
	 * @return the checkDigitSubs
	 */
	public Integer getCheckDigitSubs() {
		return checkDigitSubs;
	}

	/**
	 * @param checkDigitSubs the checkDigitSubs to set
	 */
	public void setCheckDigitSubs(Integer checkDigitSubs) {
		this.checkDigitSubs = checkDigitSubs;
	}

	/**
	 * @return the addressSubs
	 */
	public String getAddressSubs() {
		return addressSubs;
	}

	/**
	 * @param addressSubs the addressSubs to set
	 */
	public void setAddressSubs(String addressSubs) {
		this.addressSubs = addressSubs;
	}

	/**
	 * @return the phoneSubs
	 */
	public String getPhoneSubs() {
		return phoneSubs;
	}

	/**
	 * @param phoneSubs the phoneSubs to set
	 */
	public void setPhoneSubs(String phoneSubs) {
		this.phoneSubs = phoneSubs;
	}

	/**
	 * @return the emailSubs
	 */
	public String getEmailSubs() {
		return emailSubs;
	}

	/**
	 * @param emailSubs the emailSubs to set
	 */
	public void setEmailSubs(String emailSubs) {
		this.emailSubs = emailSubs;
	}

	/**
	 * @return the faxSubs
	 */
	public String getFaxSubs() {
		return faxSubs;
	}

	/**
	 * @param faxSubs the faxSubs to set
	 */
	public void setFaxSubs(String faxSubs) {
		this.faxSubs = faxSubs;
	}

	/**
	 * @return the legalAgentSubs
	 */
	public String getLegalAgentSubs() {
		return legalAgentSubs;
	}

	/**
	 * @param legalAgentSubs the legalAgentSubs to set
	 */
	public void setLegalAgentSubs(String legalAgentSubs) {
		this.legalAgentSubs = legalAgentSubs;
	}

	/**
	 * @return the legalAgentIdSubs
	 */
	public String getLegalAgentIdSubs() {
		return legalAgentIdSubs;
	}

	/**
	 * @param legalAgentIdSubs the legalAgentIdSubs to set
	 */
	public void setLegalAgentIdSubs(String legalAgentIdSubs) {
		this.legalAgentIdSubs = legalAgentIdSubs;
	}

	/**
	 * @return the creationDateSubs
	 */
	public Date getCreationDateSubs() {
		return creationDateSubs;
	}

	/**
	 * @param creationDateSubs the creationDateSubs to set
	 */
	public void setCreationDateSubs(Date creationDateSubs) {
		this.creationDateSubs = creationDateSubs;
	}

	/**
	 * @return the regCreationDateSubs
	 */
	public Date getRegCreationDateSubs() {
		return regCreationDateSubs;
	}

	/**
	 * @param regCreationDateSubs the regCreationDateSubs to set
	 */
	public void setRegCreationDateSubs(Date regCreationDateSubs) {
		this.regCreationDateSubs = regCreationDateSubs;
	}

	/**
	 * @return the lastUpdateSubs
	 */
	public Date getLastUpdateSubs() {
		return lastUpdateSubs;
	}

	/**
	 * @param lastUpdateSubs the lastUpdateSubs to set
	 */
	public void setLastUpdateSubs(Date lastUpdateSubs) {
		this.lastUpdateSubs = lastUpdateSubs;
	}

	/**
	 * @return the deletedSubs
	 */
	public Boolean isDeletedSubs() {
		return deletedSubs;
	}

	/**
	 * @param deletedSubs the deletedSubs to set
	 */
	public void setDeletedSubs(Boolean deletedSubs) {
		this.deletedSubs = deletedSubs;
	}

	/**
	 * @return the legalAgentLastNameSubs
	 */
	public String getLegalAgentLastNameSubs() {
		return legalAgentLastNameSubs;
	}

	/**
	 * @param legalAgentLastNameSubs the legalAgentLastNameSubs to set
	 */
	public void setLegalAgentLastNameSubs(String legalAgentLastNameSubs) {
		this.legalAgentLastNameSubs = legalAgentLastNameSubs;
	}

	/**
	 * @return the legalAgentTypeSubs
	 */
	public String getLegalAgentTypeSubs() {
		return legalAgentTypeSubs;
	}

	/**
	 * @param legalAgentTypeSubs the legalAgentTypeSubs to set
	 */
	public void setLegalAgentTypeSubs(String legalAgentTypeSubs) {
		this.legalAgentTypeSubs = legalAgentTypeSubs;
	}

	/**
	 * @return the idTransac
	 */
	public Long getIdTransac() {
		return idTransac;
	}

	/**
	 * @param idTransac the idTransac to set
	 */
	public void setIdTransac(Long idTransac) {
		this.idTransac = idTransac;
	}

	/**
	 * @return the idComercioTransac
	 */
	public Long getIdComercioTransac() {
		return idComercioTransac;
	}

	/**
	 * @param idComercioTransac the idComercioTransac to set
	 */
	public void setIdComercioTransac(Long idComercioTransac) {
		this.idComercioTransac = idComercioTransac;
	}

	/**
	 * @return the statusTransac
	 */
	public Long getStatusTransac() {
		return statusTransac;
	}

	/**
	 * @param statusTransac the statusTransac to set
	 */
	public void setStatusTransac(Long statusTransac) {
		this.statusTransac = statusTransac;
	}

	/**
	 * @return the transactionTypeTransac
	 */
	public Long getTransactionTypeTransac() {
		return transactionTypeTransac;
	}

	/**
	 * @param transactionTypeTransac the transactionTypeTransac to set
	 */
	public void setTransactionTypeTransac(Long transactionTypeTransac) {
		this.transactionTypeTransac = transactionTypeTransac;
	}

	/**
	 * @return the sourceTransac
	 */
	public Long getSourceTransac() {
		return sourceTransac;
	}

	/**
	 * @param sourceTransac the sourceTransac to set
	 */
	public void setSourceTransac(Long sourceTransac) {
		this.sourceTransac = sourceTransac;
	}

	/**
	 * @return the paymentWayTransac
	 */
	public Long getPaymentWayTransac() {
		return paymentWayTransac;
	}

	/**
	 * @param paymentWayTransac the paymentWayTransac to set
	 */
	public void setPaymentWayTransac(Long paymentWayTransac) {
		this.paymentWayTransac = paymentWayTransac;
	}

	/**
	 * @return the productTypeTransac
	 */
	public Long getProductTypeTransac() {
		return productTypeTransac;
	}

	/**
	 * @param productTypeTransac the productTypeTransac to set
	 */
	public void setProductTypeTransac(Long productTypeTransac) {
		this.productTypeTransac = productTypeTransac;
	}

	/**
	 * @return the creditCardTransac
	 */
	public Long getCreditCardTransac() {
		return creditCardTransac;
	}

	/**
	 * @param creditCardTransac the creditCardTransac to set
	 */
	public void setCreditCardTransac(Long creditCardTransac) {
		this.creditCardTransac = creditCardTransac;
	}

	/**
	 * @return the trazabilityCodeTransac
	 */
	public String getTrazabilityCodeTransac() {
		return trazabilityCodeTransac;
	}

	/**
	 * @param trazabilityCodeTransac the trazabilityCodeTransac to set
	 */
	public void setTrazabilityCodeTransac(String trazabilityCodeTransac) {
		this.trazabilityCodeTransac = trazabilityCodeTransac;
	}

	/**
	 * @return the idBankTransac
	 */
	public Long getIdBankTransac() {
		return idBankTransac;
	}

	/**
	 * @param idBankTransac the idBankTransac to set
	 */
	public void setIdBankTransac(Long idBankTransac) {
		this.idBankTransac = idBankTransac;
	}

	/**
	 * @return the cutomerTypeTransac
	 */
	public Integer getCustomerTypeTransac() {
		return customerTypeTransac;
	}

	/**
	 * @param cutomerTypeTransac the cutomerTypeTransac to set
	 */
	public void setCustomerTypeTransac(Integer cutomerTypeTransac) {
		this.customerTypeTransac = cutomerTypeTransac;
	}

	/**
	 * @return the ipAddressTransac
	 */
	public String getIpAddressTransac() {
		return ipAddressTransac;
	}

	/**
	 * @param ipAddressTransac the ipAddressTransac to set
	 */
	public void setIpAddressTransac(String ipAddressTransac) {
		this.ipAddressTransac = ipAddressTransac;
	}

	/**
	 * @return the responseCodeTransac
	 */
	public String getResponseCodeTransac() {
		return responseCodeTransac;
	}

	/**
	 * @param responseCodeTransac the responseCodeTransac to set
	 */
	public void setResponseCodeTransac(String responseCodeTransac) {
		this.responseCodeTransac = responseCodeTransac;
	}

	/**
	 * @return the creationDateTransac
	 */
	public Date getCreationDateTransac() {
		return creationDateTransac;
	}

	/**
	 * @param creationDateTransac the creationDateTransac to set
	 */
	public void setCreationDateTransac(Date creationDateTransac) {
		this.creationDateTransac = creationDateTransac;
	}

	/**
	 * @return the orderNumTransac
	 */
	public String getOrderNumTransac() {
		return orderNumTransac;
	}

	/**
	 * @param orderNumTransac the orderNumTransac to set
	 */
	public void setOrderNumTransac(String orderNumTransac) {
		this.orderNumTransac = orderNumTransac;
	}

	/**
	 * @return the totalValueTransac
	 */
	public BigDecimal getTotalValueTransac() {
		return totalValueTransac;
	}

	/**
	 * @param totalValueTransac the totalValueTransac to set
	 */
	public void setTotalValueTransac(BigDecimal totalValueTransac) {
		this.totalValueTransac = totalValueTransac;
	}

	/**
	 * @return the taxtValueTransac
	 */
	public BigDecimal getTaxtValueTransac() {
		return taxtValueTransac;
	}

	/**
	 * @param taxtValueTransac the taxtValueTransac to set
	 */
	public void setTaxtValueTransac(BigDecimal taxtValueTransac) {
		this.taxtValueTransac = taxtValueTransac;
	}

	/**
	 * @return the currencyTransac
	 */
	public String getCurrencyTransac() {
		return currencyTransac;
	}

	/**
	 * @param currencyTransac the currencyTransac to set
	 */
	public void setCurrencyTransac(String currencyTransac) {
		this.currencyTransac = currencyTransac;
	}

	/**
	 * @return the descriptionTransac
	 */
	public String getDescriptionTransac() {
		return descriptionTransac;
	}

	/**
	 * @param descriptionTransac the descriptionTransac to set
	 */
	public void setDescriptionTransac(String descriptionTransac) {
		this.descriptionTransac = descriptionTransac;
	}

	/**
	 * @return the approvalNumberTransac
	 */
	public String getApprovalNumberTransac() {
		return approvalNumberTransac;
	}

	/**
	 * @param approvalNumberTransac the approvalNumberTransac to set
	 */
	public void setApprovalNumberTransac(String approvalNumberTransac) {
		this.approvalNumberTransac = approvalNumberTransac;
	}

	/**
	 * @return the payDateTransac
	 */
	public Date getPayDateTransac() {
		return payDateTransac;
	}

	/**
	 * @param payDateTransac the payDateTransac to set
	 */
	public void setPayDateTransac(Date payDateTransac) {
		this.payDateTransac = payDateTransac;
	}

	/**
	 * @return the compensationDateTransac
	 */
	public Date getCompensationDateTransac() {
		return compensationDateTransac;
	}

	/**
	 * @param compensationDateTransac the compensationDateTransac to set
	 */
	public void setCompensationDateTransac(Date compensationDateTransac) {
		this.compensationDateTransac = compensationDateTransac;
	}

	/**
	 * @return the customerDocTypeTransac
	 */
	public String getCustomerDocTypeTransac() {
		return customerDocTypeTransac;
	}

	/**
	 * @param customerDocTypeTransac the customerDocTypeTransac to set
	 */
	public void setCustomerDocTypeTransac(String customerDocTypeTransac) {
		this.customerDocTypeTransac = customerDocTypeTransac;
	}

	/**
	 * @return the customerDocIdTransac
	 */
	public String getCustomerDocIdTransac() {
		return customerDocIdTransac;
	}

	/**
	 * @param customerDocIdTransac the customerDocIdTransac to set
	 */
	public void setCustomerDocIdTransac(String customerDocIdTransac) {
		this.customerDocIdTransac = customerDocIdTransac;
	}

	/**
	 * @return the customerNameTransac
	 */
	public String getCustomerNameTransac() {
		return customerNameTransac;
	}

	/**
	 * @param customerNameTransac the customerNameTransac to set
	 */
	public void setCustomerNameTransac(String customerNameTransac) {
		this.customerNameTransac = customerNameTransac;
	}

	/**
	 * @return the customerEmailTransac
	 */
	public String getCustomerEmailTransac() {
		return customerEmailTransac;
	}

	/**
	 * @param customerEmailTransac the customerEmailTransac to set
	 */
	public void setCustomerEmailTransac(String customerEmailTransac) {
		this.customerEmailTransac = customerEmailTransac;
	}

	/**
	 * @return the customerMobileNumberTransac
	 */
	public String getCustomerMobileNumberTransac() {
		return customerMobileNumberTransac;
	}

	/**
	 * @param customerMobileNumberTransac the customerMobileNumberTransac to set
	 */
	public void setCustomerMobileNumberTransac(String customerMobileNumberTransac) {
		this.customerMobileNumberTransac = customerMobileNumberTransac;
	}

	/**
	 * @return the ref1Transac
	 */
	public String getRef1Transac() {
		return ref1Transac;
	}

	/**
	 * @param ref1Transac the ref1Transac to set
	 */
	public void setRef1Transac(String ref1Transac) {
		this.ref1Transac = ref1Transac;
	}

	/**
	 * @return the ref2Transac
	 */
	public String getRef2Transac() {
		return ref2Transac;
	}

	/**
	 * @param ref2Transac the ref2Transac to set
	 */
	public void setRef2Transac(String ref2Transac) {
		this.ref2Transac = ref2Transac;
	}

	/**
	 * @return the ref3Transac
	 */
	public String getRef3Transac() {
		return ref3Transac;
	}

	/**
	 * @param ref3Transac the ref3Transac to set
	 */
	public void setRef3Transac(String ref3Transac) {
		this.ref3Transac = ref3Transac;
	}

	/**
	 * @return the regCreationDateTransac
	 */
	public Date getRegCreationDateTransac() {
		return regCreationDateTransac;
	}

	/**
	 * @param regCreationDateTransac the regCreationDateTransac to set
	 */
	public void setRegCreationDateTransac(Date regCreationDateTransac) {
		this.regCreationDateTransac = regCreationDateTransac;
	}

	/**
	 * @return the regLastUpdateTransac
	 */
	public Date getRegLastUpdateTransac() {
		return regLastUpdateTransac;
	}

	/**
	 * @param regLastUpdateTransac the regLastUpdateTransac to set
	 */
	public void setRegLastUpdateTransac(Date regLastUpdateTransac) {
		this.regLastUpdateTransac = regLastUpdateTransac;
	}

	/**
	 * @return the deletedTransac
	 */
	public Boolean isDeletedTransac() {
		return deletedTransac;
	}

	/**
	 * @param deletedTransac the deletedTransac to set
	 */
	public void setDeletedTransac(Boolean deletedTransac) {
		this.deletedTransac = deletedTransac;
	}

	/**
	 * @return the jobLockTransac
	 */
	public Long getJobLockTransac() {
		return jobLockTransac;
	}

	/**
	 * @param jobLockTransac the jobLockTransac to set
	 */
	public void setJobLockTransac(Long jobLockTransac) {
		this.jobLockTransac = jobLockTransac;
	}

	/**
	 * @return the pmtIdTransac
	 */
	public Long getPmtIdTransac() {
		return pmtIdTransac;
	}

	/**
	 * @param pmtIdTransac the pmtIdTransac to set
	 */
	public void setPmtIdTransac(Long pmtIdTransac) {
		this.pmtIdTransac = pmtIdTransac;
	}

	/**
	 * @return the payerCompanyTransac
	 */
	public String getPayerCompanyTransac() {
		return payerCompanyTransac;
	}

	/**
	 * @param payerCompanyTransac the payerCompanyTransac to set
	 */
	public void setPayerCompanyTransac(String payerCompanyTransac) {
		this.payerCompanyTransac = payerCompanyTransac;
	}

	/**
	 * @return the payerNameTransac
	 */
	public String getPayerNameTransac() {
		return payerNameTransac;
	}

	/**
	 * @param payerNameTransac the payerNameTransac to set
	 */
	public void setPayerNameTransac(String payerNameTransac) {
		this.payerNameTransac = payerNameTransac;
	}

	/**
	 * @return the payerNickNameTransac
	 */
	public String getPayerNickNameTransac() {
		return payerNickNameTransac;
	}

	/**
	 * @param payerNickNameTransac the payerNickNameTransac to set
	 */
	public void setPayerNickNameTransac(String payerNickNameTransac) {
		this.payerNickNameTransac = payerNickNameTransac;
	}

	/**
	 * @return the payerDocTypeTransac
	 */
	public String getPayerDocTypeTransac() {
		return payerDocTypeTransac;
	}

	/**
	 * @param payerDocTypeTransac the payerDocTypeTransac to set
	 */
	public void setPayerDocTypeTransac(String payerDocTypeTransac) {
		this.payerDocTypeTransac = payerDocTypeTransac;
	}

	/**
	 * @return the payerDocIdTransac
	 */
	public String getPayerDocIdTransac() {
		return payerDocIdTransac;
	}

	/**
	 * @param payerDocIdTransac the payerDocIdTransac to set
	 */
	public void setPayerDocIdTransac(String payerDocIdTransac) {
		this.payerDocIdTransac = payerDocIdTransac;
	}

	/**
	 * @return the payerGenderTransac
	 */
	public String getPayerGenderTransac() {
		return payerGenderTransac;
	}

	/**
	 * @param payerGenderTransac the payerGenderTransac to set
	 */
	public void setPayerGenderTransac(String payerGenderTransac) {
		this.payerGenderTransac = payerGenderTransac;
	}

	/**
	 * @return the payerBirthDateTransac
	 */
	public Date getPayerBirthDateTransac() {
		return payerBirthDateTransac;
	}

	/**
	 * @param payerBirthDateTransac the payerBirthDateTransac to set
	 */
	public void setPayerBirthDateTransac(Date payerBirthDateTransac) {
		this.payerBirthDateTransac = payerBirthDateTransac;
	}

	/**
	 * @return the payerCityTransac
	 */
	public String getPayerCityTransac() {
		return payerCityTransac;
	}

	/**
	 * @param payerCityTransac the payerCityTransac to set
	 */
	public void setPayerCityTransac(String payerCityTransac) {
		this.payerCityTransac = payerCityTransac;
	}

	/**
	 * @return the payerDepartmentTransac
	 */
	public String getPayerDepartmentTransac() {
		return payerDepartmentTransac;
	}

	/**
	 * @param payerDepartmentTransac the payerDepartmentTransac to set
	 */
	public void setPayerDepartmentTransac(String payerDepartmentTransac) {
		this.payerDepartmentTransac = payerDepartmentTransac;
	}

	/**
	 * @return the payerCountyTransac
	 */
	public String getPayerCountyTransac() {
		return payerCountyTransac;
	}

	/**
	 * @param payerCountyTransac the payerCountyTransac to set
	 */
	public void setPayerCountyTransac(String payerCountyTransac) {
		this.payerCountyTransac = payerCountyTransac;
	}

	/**
	 * @return the payerAddressTransac
	 */
	public String getPayerAddressTransac() {
		return payerAddressTransac;
	}

	/**
	 * @param payerAddressTransac the payerAddressTransac to set
	 */
	public void setPayerAddressTransac(String payerAddressTransac) {
		this.payerAddressTransac = payerAddressTransac;
	}

	/**
	 * @return the payerMailTransac
	 */
	public String getPayerEmailTransac() {
		return payerEmailTransac;
	}

	/**
	 * @param payerMailTransac the payerMailTransac to set
	 */
	public void setPayerEmailTransac(String payerMailTransac) {
		this.payerEmailTransac = payerMailTransac;
	}

	/**
	 * @return the payerPhoneTransac
	 */
	public String getPayerPhoneTransac() {
		return payerPhoneTransac;
	}

	/**
	 * @param payerPhoneTransac the payerPhoneTransac to set
	 */
	public void setPayerPhoneTransac(String payerPhoneTransac) {
		this.payerPhoneTransac = payerPhoneTransac;
	}

	/**
	 * @return the creditCardNumberTransac
	 */
	public String getCreditCardNumberTransac() {
		return creditCardNumberTransac;
	}

	/**
	 * @param creditCardNumberTransac the creditCardNumberTransac to set
	 */
	public void setCreditCardNumberTransac(String creditCardNumberTransac) {
		this.creditCardNumberTransac = creditCardNumberTransac;
	}

	/**
	 * @return the idBrandTransac
	 */
	public Long getIdBrandTransac() {
		return idBrandTransac;
	}

	/**
	 * @param idBrandTransac the idBrandTransac to set
	 */
	public void setIdBrandTransac(Long idBrandTransac) {
		this.idBrandTransac = idBrandTransac;
	}

	/**
	 * @return the urlResponseTransac
	 */
	public String getUrlResponseTransac() {
		return urlResponseTransac;
	}

	/**
	 * @param urlResponseTransac the urlResponseTransac to set
	 */
	public void setUrlResponseTransac(String urlResponseTransac) {
		this.urlResponseTransac = urlResponseTransac;
	}

	/**
	 * @return the categoryIdTransac
	 */
	public String getCategoryIdTransac() {
		return categoryIdTransac;
	}

	/**
	 * @param categoryIdTransac the categoryIdTransac to set
	 */
	public void setCategoryIdTransac(String categoryIdTransac) {
		this.categoryIdTransac = categoryIdTransac;
	}

	/**
	 * @return the curCodeTrmTransac
	 */
	public String getCurCodeTrmTransac() {
		return curCodeTrmTransac;
	}

	/**
	 * @param curCodeTrmTransac the curCodeTrmTransac to set
	 */
	public void setCurCodeTrmTransac(String curCodeTrmTransac) {
		this.curCodeTrmTransac = curCodeTrmTransac;
	}

	/**
	 * @return the refPago2Transac
	 */
	public String getRefPago2Transac() {
		return refPago2Transac;
	}

	/**
	 * @param refPago2Transac the refPago2Transac to set
	 */
	public void setRefPago2Transac(String refPago2Transac) {
		this.refPago2Transac = refPago2Transac;
	}

	/**
	 * @return the refPago3Transac
	 */
	public String getRefPago3Transac() {
		return refPago3Transac;
	}

	/**
	 * @param refPago3Transac the refPago3Transac to set
	 */
	public void setRefPago3Transac(String refPago3Transac) {
		this.refPago3Transac = refPago3Transac;
	}

	/**
	 * @return the refPago4Transac
	 */
	public String getRefPago4Transac() {
		return refPago4Transac;
	}

	/**
	 * @param refPago4Transac the refPago4Transac to set
	 */
	public void setRefPago4Transac(String refPago4Transac) {
		this.refPago4Transac = refPago4Transac;
	}

	/**
	 * @return the pmtTypeTransac
	 */
	public String getPmtTypeTransac() {
		return pmtTypeTransac;
	}

	/**
	 * @param pmtTypeTransac the pmtTypeTransac to set
	 */
	public void setPmtTypeTransac(String pmtTypeTransac) {
		this.pmtTypeTransac = pmtTypeTransac;
	}

	/**
	 * @return the trmTransac
	 */
	public String getTrmTransac() {
		return trmTransac;
	}

	/**
	 * @param trmTransac the trmTransac to set
	 */
	public void setTrmTransac(String trmTransac) {
		this.trmTransac = trmTransac;
	}

	/**
	 * @return the canalTransac
	 */
	public String getCanalTransac() {
		return canalTransac;
	}

	/**
	 * @param canalTransac the canalTransac to set
	 */
	public void setCanalTransac(String canalTransac) {
		this.canalTransac = canalTransac;
	}

	/**
	 * @return the trnCycleTransac
	 */
	public String getTrnCycleTransac() {
		return trnCycleTransac;
	}

	/**
	 * @param trnCycleTransac the trnCycleTransac to set
	 */
	public void setTrnCycleTransac(String trnCycleTransac) {
		this.trnCycleTransac = trnCycleTransac;
	}

	/**
	 * @return the trnTypeTransac
	 */
	public String getTrnTypeTransac() {
		return trnTypeTransac;
	}

	/**
	 * @param trnTypeTransac the trnTypeTransac to set
	 */
	public void setTrnTypeTransac(String trnTypeTransac) {
		this.trnTypeTransac = trnTypeTransac;
	}

	/**
	 * @return the rquIdTransac
	 */
	public String getRquIdTransac() {
		return rquIdTransac;
	}

	/**
	 * @param rquIdTransac the rquIdTransac to set
	 */
	public void setRquIdTransac(String rquIdTransac) {
		this.rquIdTransac = rquIdTransac;
	}

	/**
	 * @return the lastNameBuyerTransac
	 */
	public String getLastNameBuyerTransac() {
		return lastNameBuyerTransac;
	}

	/**
	 * @param lastNameBuyerTransac the lastNameBuyerTransac to set
	 */
	public void setLastNameBuyerTransac(String lastNameBuyerTransac) {
		this.lastNameBuyerTransac = lastNameBuyerTransac;
	}

	/**
	 * @return the lastNamePayerTransac
	 */
	public String getLastNamePayerTransac() {
		return lastNamePayerTransac;
	}

	/**
	 * @param lastNamePayerTransac the lastNamePayerTransac to set
	 */
	public void setLastNamePayerTransac(String lastNamePayerTransac) {
		this.lastNamePayerTransac = lastNamePayerTransac;
	}

	/**
	 * @return the middleNameBuyerTransac
	 */
	public String getMiddleNameBuyerTransac() {
		return middleNameBuyerTransac;
	}

	/**
	 * @param middleNameBuyerTransac the middleNameBuyerTransac to set
	 */
	public void setMiddleNameBuyerTransac(String middleNameBuyerTransac) {
		this.middleNameBuyerTransac = middleNameBuyerTransac;
	}

	/**
	 * @return the middleNamePayerTransac
	 */
	public String getMiddleNamePayerTransac() {
		return middleNamePayerTransac;
	}

	/**
	 * @param middleNamePayerTransac the middleNamePayerTransac to set
	 */
	public void setMiddleNamePayerTransac(String middleNamePayerTransac) {
		this.middleNamePayerTransac = middleNamePayerTransac;
	}

	/**
	 * @return the secondLastNameBuyerTransac
	 */
	public String getSecondLastNameBuyerTransac() {
		return secondLastNameBuyerTransac;
	}

	/**
	 * @param secondLastNameBuyerTransac the secondLastNameBuyerTransac to set
	 */
	public void setSecondLastNameBuyerTransac(String secondLastNameBuyerTransac) {
		this.secondLastNameBuyerTransac = secondLastNameBuyerTransac;
	}

	/**
	 * @return the secondLastNamePayerTransac
	 */
	public String getSecondLastNamePayerTransac() {
		return secondLastNamePayerTransac;
	}

	/**
	 * @param secondLastNamePayerTransac the secondLastNamePayerTransac to set
	 */
	public void setSecondLastNamePayerTransac(String secondLastNamePayerTransac) {
		this.secondLastNamePayerTransac = secondLastNamePayerTransac;
	}

	/**
	 * @return the emailflagTransac
	 */
	public Integer getEmailflagTransac() {
		return emailflagTransac;
	}

	/**
	 * @param emailflagTransac the emailflagTransac to set
	 */
	public void setEmailflagTransac(Integer emailflagTransac) {
		this.emailflagTransac = emailflagTransac;
	}

	/**
	 * @return the idTypeDocTransac
	 */
	public String getIdTypeDocTransac() {
		return idTypeDocTransac;
	}

	/**
	 * @param idTypeDocTransac the idTypeDocTransac to set
	 */
	public void setIdTypeDocTransac(String idTypeDocTransac) {
		this.idTypeDocTransac = idTypeDocTransac;
	}

	/**
	 * @return the numDocTransac
	 */
	public String getNumDocTransac() {
		return numDocTransac;
	}

	/**
	 * @param numDocTransac the numDocTransac to set
	 */
	public void setNumDocTransac(String numDocTransac) {
		this.numDocTransac = numDocTransac;
	}

	/**
	 * @return the plantillaTransac
	 */
	public Integer getPlantillaTransac() {
		return plantillaTransac;
	}

	/**
	 * @param plantillaTransac the plantillaTransac to set
	 */
	public void setPlantillaTransac(Integer plantillaTransac) {
		this.plantillaTransac = plantillaTransac;
	}

	/**
	 * @return the taquillaTransac
	 */
	public Integer getTaquillaTransac() {
		return taquillaTransac;
	}

	/**
	 * @param taquillaTransac the taquillaTransac to set
	 */
	public void setTaquillaTransac(Integer taquillaTransac) {
		this.taquillaTransac = taquillaTransac;
	}

	/**
	 * @return the tokenizedTransac
	 */
	public String getTokenizedTransac() {
		return tokenizedTransac;
	}

	/**
	 * @param tokenizedTransac the tokenizedTransac to set
	 */
	public void setTokenizedTransac(String tokenizedTransac) {
		this.tokenizedTransac = tokenizedTransac;
	}

	/**
	 * @return the bankCollecterTransac
	 */
	public Long getBankCollecterTransac() {
		return bankCollecterTransac;
	}

	/**
	 * @param bankCollecterTransac the bankCollecterTransac to set
	 */
	public void setBankCollecterTransac(Long bankCollecterTransac) {
		this.bankCollecterTransac = bankCollecterTransac;
	}

	/**
	 * @return the collectAcountTransac
	 */
	public String getCollectAcountTransac() {
		return collectAcountTransac;
	}

	/**
	 * @param collectAcountTransac the collectAcountTransac to set
	 */
	public void setCollectAcountTransac(String collectAcountTransac) {
		this.collectAcountTransac = collectAcountTransac;
	}

	/**
	 * @return the serialversionuid
	 */
	public static long getSerialversionuid() {
		return serialVersionUID;
	}

	public void setRowDeleted(boolean rowDeleted) {
		// TODO Auto-generated method stub
		
	}

	
	
	
}