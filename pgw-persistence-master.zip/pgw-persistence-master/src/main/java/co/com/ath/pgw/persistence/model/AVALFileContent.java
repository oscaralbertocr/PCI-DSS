/*
 * AVALFileContent
 *  
 * GSI - Integración
 * Creado el: 28/08/2014
 *
 * Copyright (c) A Toda Hora S.A. Todos los derechos reservados
 * 
 * Este software es confidencial y es propietario de ATH, queda prohibido
 * su uso, reproducción y copia de manera parcial o permanente salvo autorización
 * expresa de A Toda Hora S.A o de quién represente sus derechos.
 */
package co.com.ath.pgw.persistence.model;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import co.com.ath.pgw.persistence.PersistentObject;

/**
 * Clase que representa un registro generico del archivo AVAL para conciliacion 
 * de transacciones.
 * 
 * @author Andrés Méndez <proveedor_mamendez@ath.com.co>
 * @version 17/12/2014
 * @since 1.0
 */
@Entity
@Table(name="DETALLESARCHIVOSAVAL")
public class AVALFileContent implements PersistentObject {

	/**
	 * ID de serialización.
	 */
	private static final long serialVersionUID = 1786118152957467367L;

	/**
	 * Identificador único del archivo AVAL.
	 */
	@Id
	@SequenceGenerator(
			name="DETALLESARCHIVOSAVAL_ID_GENERATOR",
			sequenceName="DETALLESARCHIVOSAVAL_SEC",
			initialValue=1,
			allocationSize=1
			)
	@GeneratedValue(
			strategy=GenerationType.SEQUENCE,
			generator="DETALLESARCHIVOSAVAL_ID_GENERATOR"
			)
	@Column(name="ID")
	private Long id;
	
	@Column(name="IDARCHIVO")
	private Long fileId;
	
	/** tipoDeRegistro Atributo de la clase. */
	@Column(name="COLUMN1")
	private String column1;
	
	/** referenciaPrincipalDelUsuario Atributo de la clase. */
	@Column(name="COLUMN2")
	private String column2;
	
	/** segundaReferenciaDelUsuario Atributo de la clase. */
	@Column(name="COLUMN3")
	private String column3;
	
	/** tipoDeRecaudo Atributo de la clase. */
	@Column(name="COLUMN4")
	private String column4;
	
	/** fechaRealDeRecaudo Atributo de la clase. */
	@Column(name="COLUMN5")
	private String column5;
	
	/** horaRealDelRecaudo Atributo de la clase. */
	@Column(name="COLUMN6")
	private String column6;
	
	/** valorRecaudado Atributo de la clase. */
	@Column(name="COLUMN7")
	private String column7;
	
	/** valorRecaudadoEnCanje Atributo de la clase. */
	@Column(name="COLUMN8")
	private String column8;
	
	/** procedenciaDePago Atributo de la clase. */
	@Column(name="COLUMN9")
	private String column9;
	
	/** mediosDePago Atributo de la clase. */
	@Column(name="COLUMN10")
	private String column10;
	
	/** numeroDeOperacion Atributo de la clase. */
	@Column(name="COLUMN11")
	private String column11;
	
	/** numeroDeCheque Atributo de la clase. */
	@Column(name="COLUMN12")
	private String column12;
	
	/** codigoCompensacionDelCheque Atributo de la clase. */
	@Column(name="COLUMN13")
	private String column13;
	
	/** numeroDeAutorizacion Atributo de la clase. */
	@Column(name="COLUMN14")
	private String column14;
	
	/** codigoDeLaEntidadFinancieraDebitada Atributo de la clase. */
	@Column(name="COLUMN15")
	private String column15;
	
	/** codigoDeSucursalUOficinaRecaudadora Atributo de la clase. */
	@Column(name="COLUMN16")
	private String column16;
	
	/** secuencia Atributo de la clase. */
	@Column(name="COLUMN17")
	private String column17;
	
	/** causalDeDevolucion Atributo de la clase. */
	@Column(name="COLUMN18")
	private String column18;
	
	/** reservado Atributo de la clase. */
	@Column(name="COLUMN19")
	private String column19;
	
	/** reservado Atributo de la clase. */
	@Column(name="CODIGOCONVENIO")
	private String agreementCode;
	
	/**
	 * Indica si el registro tiene marca lógica de borrado
	 */
	@Column(name="REGELIMINADO", nullable=true)
	private boolean rowDeleted;
	
	/**
	 * Fecha de creación del registro
	 */
	@Temporal(TemporalType.TIMESTAMP)
	@Column(name="REGFECHACREACION", nullable=true)
	private Date rowCreationDate;
	
	/**
	 * Fecha de última modificación del registro
	 */
	@Temporal(TemporalType.TIMESTAMP)
	@Column(name="REGFECHAMODIFICACION", nullable=true)
	private Date rowLastUpdate;
	
	/**
	 * Constructor por defecto de un Banco
	 */
	public AVALFileContent(){
		super();
	}
	
	/**
	 * Método encargado de recuperar el valor del atributo id.
	 * @return El atributo id asociado a la clase.
	 */
	public Long getId() {
		return id;
	}

	/**
	 * Método encargado de actualizar el atributo id.
	 * @param id Nuevo valor para id.
	 */
	public void setId(Long id) {
		this.id = id;
	}

	/**
	 * Método encargado de recuperar el valor del atributo fileId.
	 * @return El atributo fileId asociado a la clase.
	 */
	public Long getFileId() {
		return fileId;
	}

	/**
	 * Método encargado de actualizar el atributo fileId.
	 * @param fileId Nuevo valor para fileId.
	 */
	public void setFileId(Long fileId) {
		this.fileId = fileId;
	}

	/**
	 * Método encargado de recuperar el valor del atributo column1.
	 * @return El atributo column1 asociado a la clase.
	 */
	public String getColumn1() {
		return column1;
	}

	/**
	 * Método encargado de actualizar el atributo column1.
	 * @param column1 Nuevo valor para column1.
	 */
	public void setColumn1(String column1) {
		this.column1 = column1;
	}

	/**
	 * Método encargado de recuperar el valor del atributo column2.
	 * @return El atributo column2 asociado a la clase.
	 */
	public String getColumn2() {
		return column2;
	}

	/**
	 * Método encargado de actualizar el atributo column2.
	 * @param column2 Nuevo valor para column2.
	 */
	public void setColumn2(String column2) {
		this.column2 = column2;
	}

	/**
	 * Método encargado de recuperar el valor del atributo column3.
	 * @return El atributo column3 asociado a la clase.
	 */
	public String getColumn3() {
		return column3;
	}

	/**
	 * Método encargado de actualizar el atributo column3.
	 * @param column3 Nuevo valor para column3.
	 */
	public void setColumn3(String column3) {
		this.column3 = column3;
	}

	/**
	 * Método encargado de recuperar el valor del atributo column4.
	 * @return El atributo column4 asociado a la clase.
	 */
	public String getColumn4() {
		return column4;
	}

	/**
	 * Método encargado de actualizar el atributo column4.
	 * @param column4 Nuevo valor para column4.
	 */
	public void setColumn4(String column4) {
		this.column4 = column4;
	}

	/**
	 * Método encargado de recuperar el valor del atributo column5.
	 * @return El atributo column5 asociado a la clase.
	 */
	public String getColumn5() {
		return column5;
	}

	/**
	 * Método encargado de actualizar el atributo column5.
	 * @param column5 Nuevo valor para column5.
	 */
	public void setColumn5(String column5) {
		this.column5 = column5;
	}

	/**
	 * Método encargado de recuperar el valor del atributo column6.
	 * @return El atributo column6 asociado a la clase.
	 */
	public String getColumn6() {
		return column6;
	}

	/**
	 * Método encargado de actualizar el atributo column6.
	 * @param column6 Nuevo valor para column6.
	 */
	public void setColumn6(String column6) {
		this.column6 = column6;
	}

	/**
	 * Método encargado de recuperar el valor del atributo column7.
	 * @return El atributo column7 asociado a la clase.
	 */
	public String getColumn7() {
		return column7;
	}

	/**
	 * Método encargado de actualizar el atributo column7.
	 * @param column7 Nuevo valor para column7.
	 */
	public void setColumn7(String column7) {
		this.column7 = column7;
	}

	/**
	 * Método encargado de recuperar el valor del atributo column8.
	 * @return El atributo column8 asociado a la clase.
	 */
	public String getColumn8() {
		return column8;
	}

	/**
	 * Método encargado de actualizar el atributo column8.
	 * @param column8 Nuevo valor para column8.
	 */
	public void setColumn8(String column8) {
		this.column8 = column8;
	}

	/**
	 * Método encargado de recuperar el valor del atributo column9.
	 * @return El atributo column9 asociado a la clase.
	 */
	public String getColumn9() {
		return column9;
	}

	/**
	 * Método encargado de actualizar el atributo column9.
	 * @param column9 Nuevo valor para column9.
	 */
	public void setColumn9(String column9) {
		this.column9 = column9;
	}

	/**
	 * Método encargado de recuperar el valor del atributo column10.
	 * @return El atributo column10 asociado a la clase.
	 */
	public String getColumn10() {
		return column10;
	}

	/**
	 * Método encargado de actualizar el atributo column10.
	 * @param column10 Nuevo valor para column10.
	 */
	public void setColumn10(String column10) {
		this.column10 = column10;
	}

	/**
	 * Método encargado de recuperar el valor del atributo column11.
	 * @return El atributo column11 asociado a la clase.
	 */
	public String getColumn11() {
		return column11;
	}

	/**
	 * Método encargado de actualizar el atributo column11.
	 * @param column11 Nuevo valor para column11.
	 */
	public void setColumn11(String column11) {
		this.column11 = column11;
	}

	/**
	 * Método encargado de recuperar el valor del atributo column12.
	 * @return El atributo column12 asociado a la clase.
	 */
	public String getColumn12() {
		return column12;
	}

	/**
	 * Método encargado de actualizar el atributo column12.
	 * @param column12 Nuevo valor para column12.
	 */
	public void setColumn12(String column12) {
		this.column12 = column12;
	}

	/**
	 * Método encargado de recuperar el valor del atributo column13.
	 * @return El atributo column13 asociado a la clase.
	 */
	public String getColumn13() {
		return column13;
	}

	/**
	 * Método encargado de actualizar el atributo column13.
	 * @param column13 Nuevo valor para column13.
	 */
	public void setColumn13(String column13) {
		this.column13 = column13;
	}

	/**
	 * Método encargado de recuperar el valor del atributo column14.
	 * @return El atributo column14 asociado a la clase.
	 */
	public String getColumn14() {
		return column14;
	}

	/**
	 * Método encargado de actualizar el atributo column14.
	 * @param column14 Nuevo valor para column14.
	 */
	public void setColumn14(String column14) {
		this.column14 = column14;
	}

	/**
	 * Método encargado de recuperar el valor del atributo column15.
	 * @return El atributo column15 asociado a la clase.
	 */
	public String getColumn15() {
		return column15;
	}

	/**
	 * Método encargado de actualizar el atributo column15.
	 * @param column15 Nuevo valor para column15.
	 */
	public void setColumn15(String column15) {
		this.column15 = column15;
	}

	/**
	 * Método encargado de recuperar el valor del atributo column16.
	 * @return El atributo column16 asociado a la clase.
	 */
	public String getColumn16() {
		return column16;
	}

	/**
	 * Método encargado de actualizar el atributo column16.
	 * @param column16 Nuevo valor para column16.
	 */
	public void setColumn16(String column16) {
		this.column16 = column16;
	}

	/**
	 * Método encargado de recuperar el valor del atributo column17.
	 * @return El atributo column17 asociado a la clase.
	 */
	public String getColumn17() {
		return column17;
	}

	/**
	 * Método encargado de actualizar el atributo column17.
	 * @param column17 Nuevo valor para column17.
	 */
	public void setColumn17(String column17) {
		this.column17 = column17;
	}

	/**
	 * Método encargado de recuperar el valor del atributo column18.
	 * @return El atributo column18 asociado a la clase.
	 */
	public String getColumn18() {
		return column18;
	}

	/**
	 * Método encargado de actualizar el atributo column18.
	 * @param column18 Nuevo valor para column18.
	 */
	public void setColumn18(String column18) {
		this.column18 = column18;
	}

	/**
	 * Método encargado de recuperar el valor del atributo column19.
	 * @return El atributo column19 asociado a la clase.
	 */
	public String getColumn19() {
		return column19;
	}

	/**
	 * Método encargado de actualizar el atributo column19.
	 * @param column19 Nuevo valor para column19.
	 */
	public void setColumn19(String column19) {
		this.column19 = column19;
	}
	
	/**
	 * Método encargado de recuperar el valor del atributo agreementCode.
	 * @return El atributo agreementCode asociado a la clase.
	 */
	public String getAgreementCode() {
		return agreementCode;
	}

	/**
	 * Método encargado de actualizar el atributo agreementCode.
	 * @param agreementCode Nuevo valor para agreementCode.
	 */
	public void setAgreementCode(String agreementCode) {
		this.agreementCode = agreementCode;
	}

	/**
	 * Método encargado de recuperar el valor del atributo rowDeleted.
	 * @return El atributo rowDeleted asociado a la clase.
	 */
	public boolean isRowDeleted() {
		return rowDeleted;
	}

	/**
	 * Método encargado de actualizar el atributo rowDeleted.
	 * @param rowDeleted Nuevo valor para rowDeleted.
	 */
	public void setRowDeleted(boolean rowDeleted) {
		this.rowDeleted = rowDeleted;
	}

	/**
	 * Método encargado de recuperar el valor del atributo rowCreationDate.
	 * @return El atributo rowCreationDate asociado a la clase.
	 */
	public Date getRowCreationDate() {
		return rowCreationDate;
	}

	/**
	 * Método encargado de actualizar el atributo rowCreationDate.
	 * @param rowCreationDate Nuevo valor para rowCreationDate.
	 */
	public void setRowCreationDate(Date rowCreationDate) {
		this.rowCreationDate = rowCreationDate;
	}

	/**
	 * Método encargado de recuperar el valor del atributo rowLastUpdate.
	 * @return El atributo rowLastUpdate asociado a la clase.
	 */
	public Date getRowLastUpdate() {
		return rowLastUpdate;
	}

	/**
	 * Método encargado de actualizar el atributo rowLastUpdate.
	 * @param rowLastUpdate Nuevo valor para rowLastUpdate.
	 */
	public void setRowLastUpdate(Date rowLastUpdate) {
		this.rowLastUpdate = rowLastUpdate;
	}

	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "AVALFileContent [id=" + id + ", fileId=" + fileId
				+ ", column1=" + column1 + ", column2=" + column2
				+ ", column3=" + column3 + ", column4=" + column4
				+ ", column5=" + column5 + ", column6=" + column6
				+ ", column7=" + column7 + ", column8=" + column8
				+ ", column9=" + column9 + ", column10=" + column10
				+ ", column11=" + column11 + ", column12=" + column12
				+ ", column13=" + column13 + ", column14=" + column14
				+ ", column15=" + column15 + ", column16=" + column16
				+ ", column17=" + column17 + ", column18=" + column18
				+ ", column19=" + column19 + ", rowDeleted=" + rowDeleted
				+ ", rowCreationDate=" + rowCreationDate + ", rowLastUpdate="
				+ rowLastUpdate + "]";
	}

}