/*
 * GetTransactionValidatorImpl
 *  
 * GSI - Integración
 * Creado el: 20/09/2014
 *
 * Copyright (c) A Toda Hora S.A. Todos los derechos reservados
 * 
 * Este software es confidencial y es propietario de ATH, queda prohibido
 * su uso, reproducción y copia de manera parcial o permanente salvo autorización
 * expresa de A Toda Hora S.A o de quién represente sus derechos.
 */
package co.com.ath.pgw.persistence.validation.model.impl;

import java.util.Date;
import java.util.Locale;

import javax.annotation.Resource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import co.com.ath.pgw.bsn.dto.in.GetTransactionInDTO;
import co.com.ath.pgw.util.i18n.ResourceBundleManager;
import co.com.ath.pgw.util.validation.ValidationException;
import co.com.ath.pgw.util.validation.model.GetTransactionValidator;

/**
 * Implementacion por defecto del validador GetTransactionValidator.
 * 
 * @author Andrés Méndez Juanias <proveedor_mamendez@ath.com.co>
 * @version 0.0.0 20/09/2014
 */
@Service
public class GetTransactionValidatorImpl implements GetTransactionValidator {

	@Autowired
	private ResourceBundleManager bundleManager;
    
    @Resource
	private TrxSourceValidator sourceValidator;
    
    @Resource
	private RqDateValidator dateValidator;
	
	@Resource
	private IPAddressValidator ipAddressValidator;
    
    @Resource
    private AgreementValidatorImpl agreementValidator;

    @Resource
	private TransactionIdValidator transactionIdValidator;
    
    @Resource
	private TransactionPmtIdValidator transactionPmtIdValidator;

	private Locale locale;

	public GetTransactionValidatorImpl() {
		this.locale = Locale.getDefault();
	}

	@Override
	public void validate(GetTransactionInDTO inDTO) throws ValidationException {
        validateChannelSource(inDTO.getTransactionBO().getSource().getId());
        validateRqDate(inDTO.getClientDt());
        validateIpAddress(inDTO.getIpAddr());
        //validateAgreement(inDTO.getTransactionBO().getCommerce().getNuraCode());
        validateTransactionPmtId(inDTO.getTransactionBO().getPmtId());
	}
    
    /**
     * Realiza la validación de un canal de origen.
     * 
     * @param channelId Canal de origen.
     * @throws ValidationException 
     */
    private void validateChannelSource(String channelId) 
    												throws ValidationException {
    	sourceValidator.setMandatory(true);
		sourceValidator.setBundleManager(bundleManager);
		sourceValidator.validate(channelId, locale);
		
	}
    /**
     * Realiza la validación de la fecha de solicitud.
     * 
     * @param clientDt				Fecha de solicitud.
     * @throws ValidationException	Si no supera las validaciones.
     */
	private void validateRqDate(Date clientDt) throws ValidationException {
		dateValidator.setMandatory(true);
		dateValidator.setBundleManager(bundleManager);
		dateValidator.validate(clientDt, locale);
	}

	/**
	 * Realiza la validación de la dirección IP origen de la transacción.
	 * 
	 * @param ipAddr 				Dirección ip origen.
	 * @throws ValidationException 	Si no supera las validaciones.
	 */
	private void validateIpAddress(String ipAddr) throws ValidationException {
		ipAddressValidator.setMandatory(true);
		ipAddressValidator.setBundleManager(bundleManager);
		ipAddressValidator.validate(ipAddr, locale);
	}
    
    /**
	 * 
	 * @param nuraCode
	 * @throws ValidationException
	 */
	@Override
	public void validateAgreement(String nuraCode) throws ValidationException {
//	    agreementValidator.setMandatory(true);
//	    agreementValidator.setBundleManager(bundleManager);
	    agreementValidator.validate(nuraCode, locale);
	}

	/**
	 * Realiza la validación del id de la transacción.
	 * 
	 * @param id
	 *            Id de la transacción.
	 * @throws ValidationException
	 *             En caso que falle la validación.
	 */
	private void validateTransactionId(String id) throws ValidationException {
		transactionIdValidator.setMandatory(true);
		transactionIdValidator.setBundleManager(bundleManager);
		transactionIdValidator.validate(id, locale);
	}
	
	/**
	 * Realiza la validación del id de la transacción.
	 * 
	 * @param pmtid
	 *            PmtId de la transacción.
	 * @throws ValidationException
	 *             En caso que falle la validación.
	 */
	private void validateTransactionPmtId(String pmtid) throws ValidationException {
		transactionPmtIdValidator.setMandatory(true);
		transactionPmtIdValidator.setBundleManager(bundleManager);
		transactionPmtIdValidator.validate(pmtid, locale);
	}

}
