/*
 * CommerceConfiguration
 *  
 * GSI - Integración
 * Creado el: 28/08/2014
 *
 * Copyright (c) A Toda Hora S.A. Todos los derechos reservados
 * 
 * Este software es confidencial y es propietario de ATH, queda prohibido
 * su uso, reproducción y copia de manera parcial o permanente salvo autorización
 * expresa de A Toda Hora S.A o de quién represente sus derechos.
 */
package co.com.ath.pgw.persistence.model;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.validation.constraints.Size;

import co.com.ath.pgw.persistence.PersistentObject;

/**
 * Configuración técnica de un comercio, incluye entre otras la configuración
 * gráfica, certificados, URL's de redirección. Esta entidad pertenece al
 * modelo persistente.
 * 
 * @author proveedor_piza
 * @version 1.0 29 Ago 2014
 * @since 1.0
 * 
 *  @RQ25510
 *  <strong>Autor</strong>Camilo Bustamante</br>
 *  <strong>Descripcion</strong>Extracto Digital</br>
 *  <strong>Numero de Cambios</strong>1</br>
 *  <strong>Identificador corto</strong>C01</br>
 *  
 *  @RQ26730
 *  <strong>Autor</strong>Luis Bonilla</br>
 *  <strong>Descripcion</strong>Facilspass</br>
 *  <strong>Numero de Cambios</strong>2</br>
 *  <strong>Identificador corto</strong>C02</br>
 */
@Entity
@Table(name="CONFIGURACIONCOMERCIO")
public class CommerceConfiguration implements PersistentObject {

	/**
	 * 
	 */
	private static final long serialVersionUID = 351086621329282979L;

	/**
	 * Identificador del comercio.
	 */
	@Id
    @Column(name = "IDCOMERCIO")
	private Long commerceId;
	
    /**
     * Comercio asociado a la configuración.
     */
	@OneToOne(fetch=FetchType.LAZY)
	@JoinColumn(name="IDCOMERCIO")
	private Commerce commerce;

	/**
	 * Plantilla gráfica que usa el comercio.
	 */
	@ManyToOne(fetch=FetchType.LAZY)
	@JoinColumn(name="IDPLANTILLA")
	private Template template;

	/**
	 * Tema gráfico que usa el comercio.
	 */
	@OneToOne(fetch=FetchType.EAGER)
	@JoinColumn(name="IDTEMA")
	private Theme theme;

	/**
	 * Logo del comercio.
	 */
	@Column(name = "LOGO")
	private String logo;

	/**
	 * Usuario de autenticación técnica (Quién puede crear transacciones).
	 */
	@Column(name="USUARIO")
	private String user;

	/**
	 * Frase oculta del usuario de autenticación técnica.
	 */
	@Column(name="CONTRASENA")
	private String phrase;

	/**
	 * Ruta del certificado del comercio.
	 */
	@Column(name="RUTACERTIFICADO")
	private String certificatePath;

	/**
	 * URL de respuesta del comercio
	 */
	@Column(name="URLRESPUESTA")
	private String responseURL;

	/**
	 * Url de confirmaión del comercio.
	 */
	@Column(name="URLCONFIRMACION")
	private String confirmationURL;
	
	/**
	 * Indica si se debe generar el archivo de recaudo para el comercio.
	 */
	@Column(name="ARCHIVORECAUDO")
	private Boolean paymentFileActive;
	
	 /**INICIO-C01*/
	/**
	 * Patron del Nombre del archivo de Recaudo
	 */
	@Size(max = 50)
	@Column(name="NOMBREARCHIVO")
	private String nombreArchivo;
	  /**FIN-C01*/

	/**
	 * Indica si el registro tiene marca lógica de borrado
	 */
	@Column(name="REGELIMINADO", nullable=true)
	private boolean rowDeleted;
	
	/**
	 * Indica si el registro tiene marca lógica de borrado
	 */
	@Column(name="NOFACTMULTIPLEREF", nullable=true)
	private Integer noFactMultipleRef;
	
	/**
	 * Fecha de creación del registro
	 */
	@Temporal(TemporalType.TIMESTAMP)
	@Column(name="REGFECHACREACION", nullable=true)
	private Date rowCreationDate;
	
	/**
	 * Fecha de última modificación del registro
	 */
	@Temporal(TemporalType.TIMESTAMP)
	@Column(name="REGFECHAMODIFICACION", nullable=true)
	private Date rowLastUpdate;
	
	/**
	 * Fecha de última modificación del registro
	 */	
	@Column(name="TIPODESERVICIO", nullable=true)
	private String tipoDeServicio;
	
	
	/**
	 * tipo administrador del convenio
	 */	
	@Column(name="TIPOADMINISTRADOR", nullable=true)
	private String tipoAdministrador;
	
	 /**INICIO-C02*/
	
		/**
		 * Indica que la transaccion se crea desde el comercio, es decir sin pasar por portal de pagos
		 */
		@Column(name="CUSTOMSRC")
		private Boolean customSrc;
		
		/**
		 * Indica que no se debe concatenar el PMTID en la URL de respuesta hacia el comercio
		 */
		@Column(name="SENDPMTID")
		private Boolean sendPmtid;
		
	/**FIN-C02*/
		
	/**
	 * Construye la configuración de un comercio.
	 */
		public CommerceConfiguration(){
		super();
	}
	
	/**
	 * Retorna el identificador del comercio.
	 * @return Identificador del comercio.
	 */
	public Long getCommerceId(){
		return commerceId;
	}

	/**
	 * Establece la identificación del comercio.
	 * 
	 * @param commerceId Id del comercio.
	 */
	public void setCommerceId(Long commerceId){
		this.commerceId = commerceId;
	}

	/**
	 * Retorna el comercio asociado a la configuración.
	 * 
	 * @return Comercio asociado.
	 */
	public Commerce getCommerce(){
		return commerce;
	}

	/**
	 * Establece el comercio asociado a la configuración.
	 * 
	 * @param commerce Comercio asociado.
	 */
	public void setCommerce(Commerce commerce){
		this.commerce = commerce;
	}

	/**
	 * Retorna la plantilla de configuración gráfica que usa el comercio.
	 * 
	 * @return Plantilla gráfica.
	 */
	public Template getTemplate(){
		return template;
	}

	/**
	 * Establece la plantilla de configuración gráfica que usará el comercio.
	 * 
	 * @param template Plantilla Gráfica.
	 */
	public void setTemplate(Template template){
		this.template = template;
	}

	/**
	 * Retorna el tema de configuración gráfica que usa el comercio.
	 * 
	 * @return Tema gráfico.
	 */
	public Theme getTheme(){
		return theme;
	}

	/**
	 * Establece el tema de configuración gráfica que usará el comercio.
	 * 
	 * @param theme Tema gráfico.
	 */
	public void setTheme(Theme theme){
		this.theme = theme;
	}

	/**
	 * Retorna la ubicación del logo del comercio.
	 * 
	 * @return Ubicación logo.
	 */
	public String getLogo(){
		return logo;
	}

	/**
	 * Establece la ubicación del logo del comercio.
	 * 
	 * @param logo Ubicación logo.
	 */
	public void setLogo(String logo){
		this.logo = logo;
	}

	/**
	 * Retorna el nombre de usuario de autenticación técnica (Quién puede crear
	 * transacciones).
	 * 
	 * @return Nombre de usuario Web Services.
	 */
	public String getUser(){
		return user;
	}

	/**
	 * Retorna el nombre de usuario de autenticación técnica (Quién puede crear
	 * transacciones).
	 * 
	 * @param user Nombre de usuario Web Services.
	 */
	public void setUser(String user){
		this.user = user;
	}

	/**
	 * Retorna la frase oculta del usuario de autenticación técnica.
	 * 
	 * @return Contraseña del usuario.
	 */
	public String getPhrase(){
		return phrase;
	}

	/**
	 * Establece la frase oculta del usuario de autenticación técnica.
	 * 
	 * @param phrase Frase oculta de autenticación.
	 */
	public void setPhrase(String phrase){
		this.phrase = phrase;
	}

	/**
	 * Retorna la ruta del certificado del comercio.
	 * 
	 * @return Ruta del certificado.
	 */
	public String getCertificatePath(){
		return certificatePath;
	}

	/**
	 * Establece la ruta del certificado del comercio.
	 * 
	 * @param certificatePath Ruta del certificado.
	 */
	public void setCertificatePath(String certificatePath){
		this.certificatePath = certificatePath;
	}

	/**
	 * Retorna la URL de respuesta del comercio.
	 * 
	 * @return URL de respuesta del comercio.
	 */
	public String getResponseURL(){
		return responseURL;
	}

	/**
	 * Establece la URL de respuesta del comercio.
	 * @param responseURL URL de respuesta del comercio.
	 */
	public void setResponseURL(String responseURL){
		this.responseURL = responseURL;
	}

	/**
	 * Retorna la URL de confirmaión del comercio.
	 * 
	 * @return URL de confirmaión del comercio.
	 */
	public String getConfirmationURL(){
		return confirmationURL;
	}

	/**
	 * Establece la URL de confirmaión del comercio.
	 * 
	 * @param confirmationURL URL de confirmaión del comercio.
	 */
	public void setConfirmationURL(String confirmationURL){
		this.confirmationURL = confirmationURL;
	}
	
	/**
	 * Indica si se debe generar el archivo de recaudo para el comercio.
	 * 
	 * @return <strong>true</strong> Si se debe generar archivo de recaudo
	 *         para el comercio, <strong>false</strong> de lo contrario. 
	 */
	public Boolean isPaymentFileActive() {
		return paymentFileActive;
	}

	/**
	 * Establece si se debe generar el archivo de recaudo para el comercio.
	 * 
	 * @param paymentFileActive Indicador de generación.
	 */
	public void setPaymentFileActive(Boolean paymentFileActive) {
		this.paymentFileActive = paymentFileActive;
	}

	
	public String getTipoDeServicio() {
		return tipoDeServicio;
	}

	public void setTipoDeServicio(String tipoDeServicio) {
		this.tipoDeServicio = tipoDeServicio;
	}
	

	@Override
	public boolean isRowDeleted(){
		return rowDeleted;
	}

	@Override
	public void setRowDeleted(boolean rowDeleted){
		this.rowDeleted = rowDeleted;
		
	}

	@Override
	public Date getRowCreationDate(){
		return rowCreationDate;
	}

	@Override
	public void setRowCreationDate(Date rowCreationDate){
		this.rowCreationDate = rowCreationDate;
	}


	@Override
	public Date getRowLastUpdate(){
		return rowLastUpdate;
	}

	@Override
	public void setRowLastUpdate(Date rowLastUpdate){
		this.rowLastUpdate = rowLastUpdate;
	}
	
	public Integer getNoFactMultipleRef() {
		return noFactMultipleRef;
	}

	public void setNoFactMultipleRef(Integer noFactMultipleRef) {
		this.noFactMultipleRef = noFactMultipleRef;
	}

	public String getTipoAdministrador() {
		return tipoAdministrador;
	}

	public void setTipoAdministrador(String tipoAdministrador) {
		this.tipoAdministrador = tipoAdministrador;
	}

	@Override
	public int hashCode(){
		final int prime = 31;
		int result = 1;
		result = prime * result + (int) (commerceId ^ (commerceId >>> 32));
		return result;
	}

	@Override
	public boolean equals(Object obj){
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		CommerceConfiguration other = (CommerceConfiguration) obj;
		if (commerceId != other.commerceId)
			return false;
		return true;
	}

	@Override
	public String toString(){
		return "CommerceConfiguration [commerceId=" + commerceId
				+ ", rowDeleted=" + rowDeleted + "]";
	}

	/**INICIO-C01*/
	/**
	 * @return the nombreArchivo
	 */
	public String getNombreArchivo() {
		return nombreArchivo;
	}

	/**
	 * @param nombreArchivo the nombreArchivo to set
	 */
	public void setNombreArchivo(String nombreArchivo) {
		this.nombreArchivo = nombreArchivo;
	}
	/**FIN-C01*/
	
	/**INICIO-C02*/
	public Boolean getCustomSrc() {
		return customSrc;
	}

	public void setCustomSrc(Boolean customSrc) {
		this.customSrc = customSrc;
	}

	public Boolean getSendPmtid() {
		return sendPmtid;
	}

	public void setSendPmtid(Boolean sendPmtid) {
		this.sendPmtid = sendPmtid;
	}
	
	/**FIN-C02*/

}