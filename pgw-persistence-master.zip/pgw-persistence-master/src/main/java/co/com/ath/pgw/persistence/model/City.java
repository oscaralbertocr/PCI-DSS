/*
 * City
 *  
 * GSI - Integración
 * Creado el: 28/08/2014
 *
 * Copyright (c) A Toda Hora S.A. Todos los derechos reservados
 * 
 * Este software es confidencial y es propietario de ATH, queda prohibido
 * su uso, reproducción y copia de manera parcial o permanente salvo autorización
 * expresa de A Toda Hora S.A o de quién represente sus derechos.
 */
package co.com.ath.pgw.persistence.model;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import co.com.ath.pgw.persistence.PersistentObject;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

/**
 * Representa una ciudad o municipios en el modelo persistente de acuerdo a la 
 * codificación DANE
 * 
 * @author proveedor_japiza
 * @version 1.0 29 Ago 2014
 * @since 1.0
 * 
 */
@Entity
@Table(name="MUNICIPIO")
public class City implements PersistentObject {

	/**
	 * 
	 */
	private static final long serialVersionUID = 8996630179382637531L;

	/**
	 * Identificador único de la ciudad en el Core de la Pasarela de Pagos.
	 */
	@Id
    @Column(name = "ID")
	private Long id;
	
	/**
	 * Código DANE de la ciudad o municipio. 
	 */
	@Column(name="DANE")
	private String code;

	/**
	 * Nombre de ciudad o municipio.
	 */
	@Column(name="NOMBRE")
	private String name;

	/**
	 * Departamento al que pertenece la cuidad o municipio.
	 */
	@ManyToOne(fetch=FetchType.LAZY) 
	@JoinColumn(name="IDDEPARTAMENTO")
	private Department departament;

	/**
	 * Indica si el registro tiene marca de borrado lógico.
	 */
	@Column(name="REGELIMINADO")
	private boolean rowDeleted;

	/**
	 * Fecha de creación del registro.
	 */
	@Column(name="REGFECHACREACION")
    @Temporal(TemporalType.TIMESTAMP)
	private Date rowCreationDate;

	/**
	 * Fecha de la última modificación del registro.
	 */
	@Column(name="REGFECHAMODIFICACION")
    @Temporal(TemporalType.TIMESTAMP)
	private Date rowLastUpdate;

	/**
	 * Construye una ciudad o municipio sin datos.
	 */
	public City(){
		super();
	}
	
	/**
	 * Construye una ciudad o municipio especificando el identificador único
	 * en el Core de la Pasarela de Pagos.
	 * 
	 * @param id Identificador de ciudad o municipio.
	 */
	City(Long id){
		super();
	}

	/**
	 * Retorna el identificador único de la ciudad en el Core de la Pasarela de
	 * Pagos.
	 * 
	 * @return Identificador de la ciudad o municipio.
	 */
	public Long getId() {
		return id;
	}

	/**
	 * Establece el identificador único de la ciudad en el Core de la Pasarela
	 * de Pagos.
	 * 
	 * @param id Identificador de la ciudad o municipio.
	 */
	public void setId(Long id) {
		this.id = id;
	}

	/**
	 * Retorna el código DANE de la ciudad o municipio.
	 *  
	 * 
	 * @return Código DANE.
	 */
	public String getCode() {
		return code;
	}

	/**
	 * Establece el código DANE de la ciudad o municipio.
	 * 
	 * @param code Código DANE
	 */
	public void setCodeDane(String code) {
		this.code = code;
	}

	/**
	 * Retorna el nombre de la ciudad o municipio.
	 * 
	 * @return Nombre de la ciudad.
	 */
	public String getName() {
		return name;
	}

	/**
	 * Establece el nombre de la ciudad o municipio.
	 * 
	 * @param name Nombre de la ciudad o municipio.
	 */
	public void setName(String name) {
		this.name = name;
	}

	/**
	 * Retorna el departamento al que pertenece la cuidad o municipio.
	 * 
	 * @return Departamento al que pertenece la ciudad o municipio.
	 */
	public Department getDepartament() {
		return departament;
	}

	/**
	 * Establece el departamento al que pertenece la ciudad o municipio.
	 * 
	 * @param departament Departamento al que pertenece la ciudad o municipio.
	 */
	public void setDepartament(Department departament) {
		this.departament = departament;
	}

	@Override
	public boolean isRowDeleted() {
		return rowDeleted;
	}

	@Override
	public void setRowDeleted(boolean rowDeleted) {
		this.rowDeleted = rowDeleted;
	}

	@Override
	public Date getRowCreationDate() {
		return rowCreationDate;
	}

	@Override
	public void setRowCreationDate(Date rowCreationDate) {
		this.rowCreationDate = rowCreationDate;
	}

	@Override
	public Date getRowLastUpdate() {
		return rowLastUpdate;
	}

	@Override
	public void setRowLastUpdate(Date rowLastUpdate) {
		this.rowLastUpdate = rowLastUpdate;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result
				+ ((code == null) ? 0 : code.hashCode());
		return result;
	}
	
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		City other = (City) obj;
		if (code == null) {
			if (other.code != null)
				return false;
		} else if (!code.equals(other.code))
			return false;
		return true;
	}

	@Override
	public String toString() {
		return "City [id=" + id + ", code=" + code + ", name=" + name
				+ ", rowDeleted=" + rowDeleted + "]";
	}

}