package co.com.ath.pgw.persistence.model;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import co.com.ath.pgw.persistence.PersistentObject;

/**
 * Clase que representa los correos establecidos de parametrización de envío de correo
 * 
 * @author Andrés Eduardo Hernandez <andres.hernandez@sophossolutions.com>
 * @version 28/05/2018
 * @since 1.0
 */
@Entity
@Table(name="NOTIFICACIONTECNICA")
public class NotificacionTecnica implements PersistentObject {

	private static final long serialVersionUID = 1L;

	@Id
    @Column(name="ID")
	private Long id;
	
	@Column(name="LISTA_CORREO")
	private String listaCorreo;
	
	@Column(name="ASUNTO")
	private String asunto;
	
	@Column(name="CUERPO")
	private String cuerpo;
	
	@Column(name="ENVIA")
	private String envia;
	
	@Column(name="TIPO_NOTIFICACION")
	private String tipoNotificacion;
	
	@Column(name="REGELIMINADO", nullable=true)
	private boolean rowDeleted;
	
	@Temporal(TemporalType.TIMESTAMP)
	@Column(name="REGFECHACREACION", nullable=true)
	private Date rowCreationDate;
	
	@Temporal(TemporalType.TIMESTAMP)
	@Column(name="REGFECHAMODIFICACION", nullable=true)
	private Date rowLastUpdate;

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getListaCorreo() {
		return listaCorreo;
	}

	public void setListaCorreo(String listaCorreo) {
		this.listaCorreo = listaCorreo;
	}

	public String getAsunto() {
		return asunto;
	}

	public void setAsunto(String asunto) {
		this.asunto = asunto;
	}

	public String getCuerpo() {
		return cuerpo;
	}

	public void setCuerpo(String cuerpo) {
		this.cuerpo = cuerpo;
	}

	public String getEnvia() {
		return envia;
	}

	public void setEnvia(String envia) {
		this.envia = envia;
	}

	public String getTipoNotificacion() {
		return tipoNotificacion;
	}

	public void setTipoNotificacion(String tipoNotificacion) {
		this.tipoNotificacion = tipoNotificacion;
	}

	public boolean isRowDeleted() {
		return rowDeleted;
	}

	public void setRowDeleted(boolean rowDeleted) {
		this.rowDeleted = rowDeleted;
	}

	public Date getRowCreationDate() {
		return rowCreationDate;
	}

	public void setRowCreationDate(Date rowCreationDate) {
		this.rowCreationDate = rowCreationDate;
	}

	public Date getRowLastUpdate() {
		return rowLastUpdate;
	}

	public void setRowLastUpdate(Date rowLastUpdate) {
		this.rowLastUpdate = rowLastUpdate;
	}
}
