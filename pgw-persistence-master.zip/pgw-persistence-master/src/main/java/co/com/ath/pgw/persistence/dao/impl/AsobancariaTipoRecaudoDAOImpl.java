/*
 * AsobancariaTipoRecaudoDAOImpl
 *  
 * GSI - Integración
 * Creado el: 24/07/2017
 *
 * Copyright (c) A Toda Hora S.A. Todos los derechos reservados
 * 
 * Este software es confidencial y es propietario de ATH, queda prohibido
 * su uso, reproducción y copia de manera parcial o permanente salvo autorización
 * expresa de A Toda Hora S.A o de quién represente sus derechos.
 */
package co.com.ath.pgw.persistence.dao.impl;

import javax.persistence.NoResultException;
import javax.persistence.Query;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Repository;

import co.com.ath.pgw.persistence.AbstractDAO_JPA;
import co.com.ath.pgw.persistence.dao.AsobancariaTipoRecaudoDAO;
import co.com.ath.pgw.persistence.model.AsobancariaTipoRecaudo;

/**
 * Implementación por defecto de AsobancariaTipoRecaudoDAO
 *
 * @author Camilo Andres Bustamante <proveedor_cbustamant@ath.com.co>
 * @version 1.0 24 Jul 2017
 * @since 1.0
 */
@Repository
public class AsobancariaTipoRecaudoDAOImpl 
			extends AbstractDAO_JPA<AsobancariaTipoRecaudo> implements AsobancariaTipoRecaudoDAO {
	
	static Logger LOGGER = LoggerFactory.getLogger(AsobancariaTipoRecaudoDAOImpl.class);

	public AsobancariaTipoRecaudoDAOImpl() {
		super(AsobancariaTipoRecaudo.class);
	}

	@Override
	public AsobancariaTipoRecaudo findByType(String tipoRecaudo) {
		
		StringBuilder sb = new StringBuilder("from AsobancariaTipoRecaudo a ");
		sb.append("where a.tipoRecaudo = :tipoRecaudo ");

		Query query = entityManager.createQuery(sb.toString());
		query.setParameter("tipoRecaudo", tipoRecaudo);

		AsobancariaTipoRecaudo recaudo = null;

		try {
			recaudo = (AsobancariaTipoRecaudo) query.getSingleResult();
		} catch (NoResultException e) {
			LOGGER.info("No hay resultados en la consulta de tipos de recaudo Asobancaria TIPORECAUDO: {}", type);
			return recaudo;
		} catch (Exception ex) {
			LOGGER.warn("Problemas en query {}", ex);
			return recaudo;
		}
		return recaudo;
		
	}

}
