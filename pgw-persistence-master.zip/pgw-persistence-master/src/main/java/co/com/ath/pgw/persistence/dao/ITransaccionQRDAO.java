package co.com.ath.pgw.persistence.dao;

import co.com.ath.pgw.persistence.DataAccessObject;
import co.com.ath.pgw.persistence.model.Transaction;

public interface ITransaccionQRDAO extends DataAccessObject<Transaction> {
	
	public void estadoFallido(long pmtId ); 
	
	public void identTransaccionQR(long pmtId) throws Exception;
	
	public Transaction findById( long pmtId);

}
