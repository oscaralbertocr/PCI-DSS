/*
 * TransactionDAOImpl
 *  
 * GSI - Integración
 * Creado el: 29/08/2014
 *
 * Copyright (c) A Toda Hora S.A. Todos los derechos reservados
 * 
 * Este software es confidencial y es propietario de ATH, queda prohibido
 * su uso, reproducción y copia de manera parcial o permanente salvo autorización
 * expresa de A Toda Hora S.A o de quién represente sus derechos.
 */
package co.com.ath.pgw.persistence.dao.impl;

import java.math.BigDecimal;
import java.sql.Timestamp;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;
import javax.persistence.NoResultException;
import javax.persistence.NonUniqueResultException;
import javax.persistence.ParameterMode;
import javax.persistence.PersistenceException;
import javax.persistence.Query;
import javax.persistence.QueryTimeoutException;
import javax.persistence.StoredProcedureQuery;
import javax.persistence.TransactionRequiredException;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Repository;

import co.com.ath.pgw.persistence.AbstractDAO_JPA;
import co.com.ath.pgw.persistence.dao.TransactionDAO;
import co.com.ath.pgw.persistence.dao.TransactionStatusDAO;
import co.com.ath.pgw.persistence.model.Transaction;
import co.com.ath.pgw.persistence.model.TransactionSource;
import co.com.ath.pgw.persistence.model.TransactionStatus;
import co.com.ath.pgw.util.constants.CoreConstants;
import co.com.ath.pgw.util.constants.PaymentWayCodes;
import co.com.ath.pgw.util.enums.BusinessStatusEnum;
import co.com.ath.pgw.util.enums.TransactionStatusEnum;

/**
 * Implementación por defecto de TransactionDAO
 *
 * @author Andrés Méndez Juanias <proveedor_mamendez@ath.com.co>
 * @version 1.0 29 Ago 2014
 * 
 * @IM623798
 * <strong>Autor</strong> Mauricio Tascon </br>
 * <strong>Descripcion</strong>Ajuste Batch Close transaction Descuadre contable </br>
 * <strong>Numero de Cambios</strong>4</br>
 * <strong>Identificador corto</strong>C01</br>
 * 
 * 
 *  @IM703888
 *  <strong>Autor</strong>Camilo Bustamante</br>
 *  <strong>Descripcion</strong>Correccion Sonda ACH</br>
 *  <strong>Numero de Cambios</strong>1</br>
 *  <strong>Identificador corto</strong>C02</br>
 *  
 *  @RQ27199
 *  <strong>Autor</strong>Camilo Bustamante</br>
 *  <strong>Descripcion</strong>Ajuste de Estado, Manejo de Topes</br>
 *  <strong>Numero de Cambios</strong>1</br>
 *  <strong>Identificador corto</strong>C03</br>
 *  
 *  @IM714148
 *  <strong>Autor</strong>Camilo Bustamante</br>
 *  <strong>Descripcion</strong>Correccion fechas en querys de reportes</br>
 *  <strong>Numero de Cambios</strong>6</br>
 *  <strong>Identificador corto</strong>C04</br>
 *  
 *  @IM728420
 *  <strong>Autor</strong>Efren Lopez Galvis</br>
 *  <strong>Descripcion</strong>Correccion fechas en querys de historico transacciones</br>
 *  <strong>Numero de Cambios</strong>3</br>
 *  <strong>Identificador corto</strong>C05</br>
 *  
 *  @IM30719
 *  <strong>Autor</strong>Henry Hernandez</br>
 *  <strong>Descripcion</strong>Actualizacion tx pendientes mediante SP</br>
 *  <strong>Numero de Cambios</strong>1</br>
 *  <strong>Identificador corto</strong>C06</br>
 *  
 *  @IM98953
 *  <strong>Autor</strong>Dario Hernandez</br>
 *  <strong>Descripcion</strong>RBM_Integracion_Boton_TC_GlobalPay_el_cual_no_se_migro_a_PCI</br>
 *  <strong>Numero de Cambios</strong>1</br>
 *  <strong>Identificador corto</strong>C07</br>
 * 
 */
@Repository
public class TransactionDAOImpl extends AbstractDAO_JPA<Transaction> implements TransactionDAO {

	static Logger LOGGER = LoggerFactory.getLogger(TransactionDAOImpl.class);
	
	private TransactionStatus transactionStatusConfirmedOK;
	private TransactionStatus transactionStatusConfirmedNA;
	private TransactionStatus transactionStatusConfirmedFailed;
	private TransactionStatus transactionStatusRefused;
	
	@Resource
	private TransactionStatusDAO transactionStatusDAO;
	
	public TransactionDAOImpl() {
		super(Transaction.class);
	}

    @Override
    public Transaction findByOrderNumber(String orderNumber) {
        StringBuilder hql = new StringBuilder("from Transaction t ");
		hql.append("where t.rowDeleted <> 1 ");
		hql.append("and t.orderNumber = :orderNumber ");
		
        Query query = entityManager.createQuery(hql.toString());
		query.setParameter("orderNumber", orderNumber);
		
		Transaction transaction = null;
		
		try {
			transaction = (Transaction) query.getSingleResult(); 
		} catch (NoResultException e) {
			LOGGER.warn("Problemas en query", e);
			return null;
		} catch (NonUniqueResultException e){
			LOGGER.warn("Problemas en query", e);
            return null;
        }
		return transaction;
    }

    @Override
	public Transaction findByIdTransactionNuraCode(Long idTransaction,
			String nuraCode) {
		StringBuilder hql = new StringBuilder("from Transaction t ");
		hql.append("where t.rowDeleted <> 1 ");
		hql.append("and t.id = :idTransaction ");
		hql.append("and t.commerce.nuraCode = :nuraCode ");		
		
        Query query = entityManager.createQuery(hql.toString());
		query.setParameter("idTransaction", idTransaction);
		query.setParameter("nuraCode", nuraCode);
		
		Transaction transaction = null;
		
		try {
			transaction = (Transaction) query.getSingleResult(); 
		} catch (NoResultException e) {
			LOGGER.warn("Problemas en query", e);
			return null;
		} catch (NonUniqueResultException e){
			LOGGER.warn("Problemas en query", e);
            return null;
        }
		return transaction;
	}
    
    @Override
	public Transaction findByPmtIdTransactionNuraCode(Long pmtIdTransaction,
			String nuraCode) {
		StringBuilder hql = new StringBuilder("from Transaction t ");
		hql.append("where t.rowDeleted <> 1 ");
		hql.append("and t.pmtId = :pmtIdTransaction ");
		hql.append("and t.commerce.nuraCode = :nuraCode ");		
		
        Query query = entityManager.createQuery(hql.toString());
		query.setParameter("pmtIdTransaction", pmtIdTransaction);
		query.setParameter("nuraCode", nuraCode);
		
		Transaction transaction = null;
		
		try {
			transaction = (Transaction) query.getSingleResult(); 
		} catch (NoResultException e) {
			LOGGER.warn("Problemas en query", e);
			return null;
		} catch (NonUniqueResultException e){
			LOGGER.warn("Problemas en query", e);
            return null;
        }
		return transaction;
	}

    /**INICIO-C06**/
    //Se elimina el parametro de entrada statusList
    /**INICIO-C03**/
	@Override
	public void lockTransactionForClose(Long jobLockId, Date jobDate) {
		/**INICIO-C01**/
		/*StringBuilder hql = new StringBuilder(" UPDATE Transaction t ");
		hql.append(" SET t.jobLockId = :jobLockId ");
		hql.append(" WHERE t.rowDeleted <> 1 ");		
		hql.append(" AND t.status IN (FROM TransactionStatus ts WHERE ts.code IN(:statusList) ) ");
		hql.append(" AND t.transactionDate <= :jobDate ");
		hql.append(" AND t.PaymentWay.id = " + PaymentWayCodes.PSE);
		hql.append(" AND t.jobLockId IS NULL ");
		/**FIN-C01**/
		
		/*Query query = entityManager.createQuery(hql.toString());		
		query.setParameter("jobLockId", jobLockId);	
		query.setParameter("jobDate", jobDate);
		/**FIN-C02**/
		
		/**INICIO-C01**/
		/*List<Long> idStates = new ArrayList<Long>(1);
		if (!statusList.isEmpty()) {
			for (TransactionStatusEnum id : statusList) {
				idStates.add(id.getCode());
			}
		}
		
		query.setParameter("statusList", idStates);*/
		/**FIN-C01**/
		
		StoredProcedureQuery storedProcedure = entityManager.createStoredProcedureQuery("LOCK_TRANSACTION_FOR_CLOSE");
		storedProcedure.registerStoredProcedureParameter("jobLockId", Long.class, ParameterMode.IN);
		storedProcedure.registerStoredProcedureParameter("jobDate", Date.class, ParameterMode.IN);
		storedProcedure.registerStoredProcedureParameter("nrows", long.class, ParameterMode.OUT);
		
		// Asignar Parametros de entrada
		storedProcedure.setParameter("jobLockId", jobLockId);
		storedProcedure.setParameter("jobDate", jobDate );
		
		// Llamado a procedimiento y recibir parametro de salida cantidad de registros actualizados
		
		try {
			//query.executeUpdate();
			LOGGER.info("Inicia ejecucion del tasklet lockTransactionForClose: "+jobLockId+" y fecha "+jobDate);
			LOGGER.info("Inicia ejecucion de procedimiento almacenado");
			storedProcedure.execute();
			LOGGER.info("Finaliza ejecucion de procedimiento almacenado");
			Long numeroRegistrosActualizados = (Long) storedProcedure.getOutputParameterValue("nrows");
			LOGGER.info("Fin de ejecucion del tasklet lockTransactionForClose "+numeroRegistrosActualizados+ " Registros Actualizados");
			/*FIN C06*/
		} catch(IllegalStateException ex) {
			LOGGER.error("IllegalStateException. Error actualizando los registros para bloquear: \n{}", 
					ex.toString());
		} catch(TransactionRequiredException ex) {
			LOGGER.error("TransactionRequiredException. Error actualizando los registros para bloquear: \n{}", 
					ex.toString());
		} catch (QueryTimeoutException  ex) {
			LOGGER.error("QueryTimeoutException. Error actualizando los registros para bloquear: \n{}", 
					ex.toString());
		} catch(PersistenceException  ex){
			LOGGER.error("PersistenceException. Error actualizando los registros para bloquear: \n{}", 
					ex.toString());
		} 
	}

	
	@Override
	public void lockTransactionForClosePending(Long jobLockId, Date transactionDate, List<TransactionStatusEnum> statusList) {
		/**INICIO-C01**/
		StringBuilder hql = new StringBuilder(" UPDATE Transaction t ");
		hql.append(" SET t.jobLockId = :jobLockId ");
		hql.append(" WHERE t.rowDeleted <> 1 ");		
		hql.append(" AND t.status IN (FROM TransactionStatus ts WHERE ts.code IN(:statusList) ) ");
		hql.append(" AND t.transactionDate <= :transactionDate ");
		hql.append(" AND t.PaymentWay.id <> " + PaymentWayCodes.PSE);
		/**INICIO-C07**/
		hql.append(" AND t.globalPay <> 1 " );
		/**FIN-C07**/
		hql.append(" AND t.jobLockId IS NULL ");
		/**FIN-C01**/
		
		Query query = entityManager.createQuery(hql.toString());
		query.setParameter("jobLockId", jobLockId);
		query.setParameter("transactionDate", transactionDate);
		
		/**INICIO-C01**/				
		List<Long> idStates = new ArrayList<Long>(1);
		if (!statusList.isEmpty()) {
			for (TransactionStatusEnum id : statusList) {
				idStates.add(id.getCode());
			}
		}
		
		query.setParameter("statusList", idStates);
		/**FIN-C01**/
		
		try {
			query.executeUpdate();
			LOGGER.info("Se asigna id de bloqueo a las transacciones pendientes aval y null que se encuentran vencidas:{}", jobLockId);
		} catch(IllegalStateException ex) {
			LOGGER.info("IllegalStateException. Error actualizando los registros para bloquear: \n{}", 
					ex.toString());
		}
		catch(TransactionRequiredException ex) {
			LOGGER.info("TransactionRequiredException. Error actualizando los registros para bloquear: \n{}", 
					ex.toString());
		} catch (QueryTimeoutException  ex) {
			LOGGER.info("QueryTimeoutException. Error actualizando los registros para bloquear: \n{}", 
					ex.toString());
		} 
		catch(PersistenceException  ex){
			LOGGER.info("PersistenceException. Error actualizando los registros para bloquear: \n{}", 
					ex.toString());
		} 
	}
	
	@Override
	/**FIN-C04**/
	public Object[] countTotalRows(Long commerceId, Long statusCode, 
			Timestamp compensationDateStart, Timestamp compensationDateEnd){
	
		StringBuilder jpql = new StringBuilder();
		jpql.append(" SELECT COUNT(1), COALESCE(SUM(t.totalValue), 0) FROM Transaction t ");
		jpql.append(" WHERE t.commerce.id = :commerceId ");
		jpql.append(" AND t.status.code = :statusCode ");
		jpql.append(" AND t.PaymentWay.id = :paymentWay ");
		jpql.append(" AND t.compensationDate BETWEEN :compensationDateStart AND :compensationDateEnd ");
		
		Query query = entityManager.createQuery(jpql.toString());
		query.setParameter("commerceId", commerceId);
		query.setParameter("statusCode", statusCode);
		query.setParameter("paymentWay", PaymentWayCodes.PSE);
		query.setParameter("compensationDateStart", compensationDateStart);
		query.setParameter("compensationDateEnd", compensationDateEnd);
		
		Object[] result = null;
		try {
			result = (Object[])query.getSingleResult();
		} catch (NoResultException ex){
			result = null;
		} catch (NonUniqueResultException ex) {
			LOGGER.warn("Error en query: \n{}", ex.toString());
		} 
		return result;
	}
	/**FIN-C04**/

	@SuppressWarnings("unchecked")
	@Override
	public List<Transaction> findByOrderNumberNuraCodeStatus(String orderNumber,
			String nuraCode, List<TransactionStatusEnum> statusList, String pmtType, 
			String invoiceReference2, String invoiceReference3, String invoiceReference4) {
		StringBuilder hql = new StringBuilder("from Transaction t ");
		hql.append("where t.rowDeleted <> 1 ");
		hql.append("and t.orderNumber = :orderNumber ");
		hql.append("and t.commerce.nuraCode = :nuraCode ");
		hql.append("and t.status.description IN (:statusList) ");
		if (pmtType != null && pmtType.length() > 0 && pmtType.equals("CPV")) {
			if(invoiceReference2.length() > 0) {
				hql.append("and t.invoiceReferen2 = :invoiceReference2 ");
			} else {
				hql.append("and t.invoiceReferen2 IS NULL ");
			}
			
			if(invoiceReference3.length() > 0) {
				hql.append("and t.invoiceReferen3 = :invoiceReference3 ");
			} else {
				hql.append("and t.invoiceReferen3 IS NULL ");
			}
			
			if(invoiceReference4.length() > 0) {
				hql.append("and t.invoiceReferen4 = :invoiceReference4 ");
			} else {
				hql.append("and t.invoiceReferen4 IS NULL ");
			}
		}

        Query query = entityManager.createQuery(hql.toString());
		query.setParameter("orderNumber", orderNumber);
		query.setParameter("nuraCode", pmtType+nuraCode);
		query.setParameter("statusList", statusList);
		if (pmtType != null && pmtType.length() > 0 && pmtType.equals("CPV")) {
			if(invoiceReference2.length() > 0) {
				query.setParameter("invoiceReference2", invoiceReference2);
			}
			if(invoiceReference3.length() > 0) {
				query.setParameter("invoiceReference3", invoiceReference3);
			}
			if(invoiceReference4.length() > 0) {
				query.setParameter("invoiceReference4", invoiceReference4);
			}
		}
		
		List<Transaction> transactionList = null;
		try {
			transactionList = (List<Transaction>) query.getResultList(); 
		} catch (NoResultException e) {
			LOGGER.info("query Exception ", e.toString());
			return new ArrayList<Transaction>();
		} 
		return transactionList;
	}
	
	@SuppressWarnings("unchecked")
	@Override
	public List<Transaction> findHistoric(String docType, String docNum,
			Date startDate, Date endDate, String state, String paymentWayId) {
		StringBuilder hql = new StringBuilder(" FROM Transaction t ");
		hql.append(" WHERE t.rowDeleted <> 1 ");
		hql.append(" AND  t.customerDocType = :docType ");
		hql.append(" AND  t.customerDocId = :docNum ");
		/**
		 * INI-C05 
		 */
		hql.append(" AND  t.transactionDate >= TO_TIMESTAMP(:startDate, 'DD/MM/YYYY HH24.MI.SS.FF') ");
		hql.append(" AND  t.transactionDate <= TO_TIMESTAMP(:endDate, 'DD/MM/YYYY HH24.MI.SS.FF') ");
		/**
		 * FIN-C05 
		 */
		if (state != null) {
			hql.append(" AND t.status.businessCode.description = :state ");
		}
		if (paymentWayId != null) {
			hql.append(" AND t.PaymentWay.id = :paymentWayId ");
		}
		hql.append(" ORDER BY t.transactionDate DESC ");
		/**
		 * INI-C05 
		 */
		// Asignar los valores a la consulta
		SimpleDateFormat simpleDateFormat = new SimpleDateFormat("dd/MM/yyyy HH:mm:ss");
		String iStartDate = simpleDateFormat.format(startDate);
		String iEndDate = simpleDateFormat.format(endDate);
		/**
		 * FIN-C05 
		 */
		Query query = entityManager.createQuery(hql.toString());
		query.setParameter("docType", docType);
		query.setParameter("docNum", docNum);
		/**
		 * INI-C05 
		 */
		query.setParameter("startDate", iStartDate );
		query.setParameter("endDate", iEndDate );
		/**
		 * FIN-C05 
		 */
		if (state != null) {
			query.setParameter("state", BusinessStatusEnum.valueOf(state.toUpperCase()));
		}
		if (paymentWayId != null) {
			query.setParameter("paymentWayId", Long.valueOf(paymentWayId));
		}
		
		try {
			List<Transaction> list = query.getResultList();
			return list;
		} catch (NoResultException ex) {
			LOGGER.info("Query Exception : {}", ex.toString());
			return new ArrayList<Transaction>();
		}
	}
	
	@Override
	public BigDecimal sequenceIdTx() {
		StringBuilder sql = new StringBuilder("SELECT TRANSACCIONES_SEC.NEXTVAL FROM DUAL");
				
		Query query = entityManager.createNativeQuery(sql.toString());
		BigDecimal idTx = null;
		
		try {
			idTx = (BigDecimal) query.getSingleResult();
		} catch (NoResultException ex) {
			LOGGER.info("Query Exception : {}", ex.toString());
			return null;
		}
		return idTx;
	}
	
	@Override
	public Transaction findByPmtId(Long pmtId) {
		StringBuilder hql = new StringBuilder("from Transaction t ");
		hql.append("where t.rowDeleted <> 1 ");
		hql.append("and t.pmtId = :pmtId ");

        Query query = entityManager.createQuery(hql.toString());
		query.setParameter("pmtId", pmtId);

		Transaction transaction = null;

		try {
			transaction = (Transaction) query.getSingleResult(); 
		} catch (NoResultException e) {
			LOGGER.info("Error en la consulta del pmtid {} No existe en la Base de Datos. {}", pmtId, e.getMessage());
			return null;
		} catch (NonUniqueResultException e){
			LOGGER.warn("Problemas en query", e);
            return null;
        }
	  return transaction;
	}
	
	public Object[] countBalotoRows(Date startDate, Date endDate) {
		
		StringBuilder jpql = new StringBuilder();
		jpql.append(" SELECT COUNT(1), COALESCE(SUM(t.totalValue), 0) FROM Transaction t ");
		jpql.append(" WHERE t.status = :status ");
		jpql.append(" AND t.transactionDate >= :startDate ");
		jpql.append(" AND t.transactionDate <= :endDate ");
		jpql.append(" AND t.trnChannel = :trnChannel ");
		
		return null;
	}
	
	@Override
	/**INICIO-C04**/
	public Object[] countTotalRows(TransactionSource source, Timestamp startDate, Timestamp endDate, TransactionStatus statusCode){
	/**FIN-C04**/

		StringBuilder jpql = new StringBuilder();
		jpql.append(" SELECT COUNT(1), COALESCE(SUM(t.totalValue), 0) FROM Transaction t ");
		jpql.append(" WHERE t.status = :status ");
		/**INICIO-C04**/
		jpql.append(" AND t.transactionDate BETWEEN :startDate AND :endDate ");
		/**FIN-C04**/
		jpql.append(" AND t.source = :source ");
		
		Query query = entityManager.createQuery(jpql.toString());
		query.setParameter("status", statusCode);
		query.setParameter("startDate", startDate);
		query.setParameter("endDate", endDate);
		query.setParameter("source", source);
		
		Object[] result = null;
		try {
			result = (Object[])query.getSingleResult();
		} catch (NoResultException ex){
			result = null;
		} catch (NonUniqueResultException ex) {
			LOGGER.warn("Error en query: \n{}", ex.toString());
		} 
		return result;
	}

	@Override
	/**INICIO-C04**/
	public Object[] countTotalRows(Timestamp startDate, Timestamp endDate, Long statusCode, Long bankCode) {
	/**FIN-C04**/
		
		StringBuilder jpql = new StringBuilder();
		/**INICIO-C03**/
		jpql.append(" SELECT COUNT(1),");
		jpql.append(" COALESCE(SUM(case when t.status.code=5 or t.status.code=7 or t.status.code=9 then t.totalValue else 0 end),0),");
		jpql.append(" COALESCE(SUM(case when t.status.code=6 then t.totalValue else 0 end),0) FROM Transaction t");
		/**INICIO-C04**/
		jpql.append(" WHERE t.transactionDate BETWEEN :startDate AND :endDate");
		/**FIN-C04**/
		jpql.append(" AND t.status IN (:statusCodeConfirmed_ok,:statusCodeConfirmed_na,:statusCodeFailed,:statusCodeRefused)");
		jpql.append(" AND t.PaymentWay.id IN (:paymentWayPSE,:paymentWayAVAL,:paymentWayTC)");
		jpql.append(" AND t.bankCollecter.id = :bankCode ");
		/**FIN-C03**/
		
		Map<String,Object> params = parameterValues();
		
		Query query = entityManager.createQuery(jpql.toString());
		query.setParameter("startDate", startDate);
		query.setParameter("endDate", endDate);
		query.setParameter("statusCodeConfirmed_ok", params.get("statusCodeConfirmed_ok"));
		query.setParameter("statusCodeConfirmed_na", params.get("statusCodeConfirmed_na"));
		query.setParameter("statusCodeFailed", params.get("statusCodeFailed"));
		/**INICIO-C03**/
		query.setParameter("statusCodeRefused", params.get("statusCodeRefused"));
		/**FIN-C03**/
		query.setParameter("paymentWayPSE", params.get("paymentWayPSE"));
		query.setParameter("paymentWayAVAL", params.get("paymentWayAVAL"));
		query.setParameter("paymentWayTC", params.get("paymentWayTC"));
		query.setParameter("bankCode", bankCode);
		
		Object[] result = null;
		
		try {
			result = (Object[])query.getSingleResult();
		} catch (NoResultException ex) {
			LOGGER.warn("El Query no retorno resultados:\n{}", ex.toString());
			result = null;
		} catch (NonUniqueResultException ex) {
			LOGGER.warn("El Query no retorno un unico resultado:\n{}", ex.toString());
		} catch (Exception ex) {
			LOGGER.error("No fue posible retornar los datos de totalizacion del reporte:\n{}", ex.toString());
		} 
		
		return result;
	}
	
	private Map<String, Object> parameterValues() {
		fillPendingStates();
		
		Map<String, Object> params = new HashMap<String, Object>();
		params.put("statusCodeConfirmed_ok", transactionStatusConfirmedOK);
		params.put("statusCodeConfirmed_na", transactionStatusConfirmedNA);
		params.put("statusCodeFailed", transactionStatusConfirmedFailed);
		/**INICIO-C03**/
		params.put("statusCodeRefused", transactionStatusRefused);
		/**FIN-C03**/
		params.put("paymentWayPSE", PaymentWayCodes.PSE);
		params.put("paymentWayAVAL", PaymentWayCodes.PAGOS_AVAL);
		params.put("paymentWayTC", PaymentWayCodes.TC);
		return params;
	}
	
	private void fillPendingStates() {
		// Estados finales de la transacción
		transactionStatusConfirmedOK = transactionStatusDAO.read(TransactionStatusEnum.CONFIRMED_OK.getCode());
		transactionStatusConfirmedNA = transactionStatusDAO.read(TransactionStatusEnum.CONFIRMED_NA.getCode());
		transactionStatusConfirmedFailed = transactionStatusDAO.read(TransactionStatusEnum.FAILED.getCode());
		/**INICIO-C03**/
		transactionStatusRefused = transactionStatusDAO.read(TransactionStatusEnum.REFUSED.getCode());
		/**FIN-C03**/
	}
	
	/**
	 * retorna nit convenio agregador para transacciones PSE
	 * 
	 * @param paymentWayId
	 * @param isAggregator
	 * @param tx
	 * @return
	 */
	@Override
	public String getAggregatorNit(Transaction tx, String NitAg, String nitAvVillas) {
		if (tx.getCommerce().getAggregator() == CoreConstants.IS_AGREGATOR) {
			if (tx.getPaymentWay().getId() == PaymentWayCodes.EMTPY
					|| tx.getPaymentWay().getId() == PaymentWayCodes.PSE) {
				// Verifica el banco del comercio (Obligaciones)
				Long bankCommerce = tx.getCommerce().getSubscription().getBank().getId();
				// Verifica si es CPV para retornar el NIt de Av Villas sino el
				// de PSE
				if ((tx.getCommerce().getNuraCode().startsWith("CPV"))
						|| (tx.getCommerce().getNuraCode().startsWith("O")
								&& (bankCommerce.equals(CoreConstants.ID_AVVILLAS)))) {
					return nitAvVillas;
				} else {
					return NitAg;
				}
			} else {
				return tx.getCommerce().getNit().toString();
			}
		} else {
			return tx.getCommerce().getNit().toString();
		}
	}
	
	@Override
	public void lockRBMTransactionForClose(Long jobLockId, Date jobDate, List<TransactionStatusEnum> statusList) {
		
		StringBuilder hql = new StringBuilder(" UPDATE Transaction t ");
		hql.append(" SET t.jobLockId = :jobLockId ");
		hql.append(" WHERE t.rowDeleted <> 1 ");		
		hql.append(" AND t.status IN (FROM TransactionStatus ts WHERE ts.code IN(:statusList) ) ");
		hql.append(" AND t.transactionDate <= :jobDate ");
		hql.append(" AND t.PaymentWay.id <> " + PaymentWayCodes.PSE);
		hql.append(" AND t.globalPay = 1 " );
		hql.append(" AND t.jobLockId IS NULL ");
		
		Query query = entityManager.createQuery(hql.toString());		
		query.setParameter("jobLockId", jobLockId);	
		query.setParameter("jobDate", jobDate);
		
		List<Long> idStates = new ArrayList<Long>(1);
		if (!statusList.isEmpty()) {
			for (TransactionStatusEnum id : statusList) {
				idStates.add(id.getCode());
			}
		}
		
		query.setParameter("statusList", idStates);
		
		try {
			query.executeUpdate();
		} catch(IllegalStateException ex) {
			LOGGER.error("IllegalStateException. Error actualizando los registros RBM para bloquear: \n{}", 
					ex.toString());
		} catch(TransactionRequiredException ex) {
			LOGGER.error("TransactionRequiredException. Error actualizando los registros RBM para bloquear: \n{}", 
					ex.toString());
		} catch (QueryTimeoutException  ex) {
			LOGGER.error("QueryTimeoutException. Error actualizando los registros RBM para bloquear: \n{}", 
					ex.toString());
		} catch(PersistenceException  ex){
			LOGGER.error("PersistenceException. Error actualizando los registros RBM para bloquear: \n{}", 
					ex.toString());
		} 
	}
	
	
	@Override
	public void lockTransaction(Long jobLockId, Date transactionDate, List<TransactionStatusEnum> statusList) {
		StringBuilder hql = new StringBuilder(" UPDATE Transaction t ");
		hql.append(" SET t.jobLockId = :jobLockId ");
		hql.append(" WHERE t.rowDeleted <> 1 ");		
		hql.append(" AND t.status IN (FROM TransactionStatus ts WHERE ts.code IN(:statusList) ) ");
		hql.append(" AND t.transactionDate <= :transactionDate ");
		hql.append(" AND t.PaymentWay.id = " + PaymentWayCodes.EMTPY);
		hql.append(" AND t.jobLockId IS NULL ");
		hql.append(" AND ROWNUM <= 600");
		
		Query query = entityManager.createQuery(hql.toString());
		query.setParameter("jobLockId", jobLockId);
		query.setParameter("transactionDate", transactionDate);
						
		List<Long> idStates = new ArrayList<>(1);
		if (!statusList.isEmpty()) {
			for (TransactionStatusEnum id : statusList) {
				idStates.add(id.getCode());
			}
		}
		
		query.setParameter("statusList", idStates);
		
		try {
			query.executeUpdate();
			LOGGER.info("Se asigna id de bloqueo a las transacciones pendientes con medio de pago 9 que se encuentran vencidas:{}", jobLockId);
		} catch(IllegalStateException ex) {
			LOGGER.info("IllegalStateException. Error actualizando los registros para bloquear: \n{}",ex);
		}
		catch(TransactionRequiredException ex) {
			LOGGER.info("TransactionRequiredException. Error actualizando los registros para bloquear: \n{}",ex);
		} catch (QueryTimeoutException  ex) {
			LOGGER.info("QueryTimeoutException. Error actualizando los registros para bloquear: \n{}",ex);
		} 
		catch(PersistenceException  ex){
			LOGGER.info("PersistenceException. Error actualizando los registros para bloquear: \n{}", ex);
		} 
	}
}
