package co.com.ath.pgw.persistence.dao.impl;

import javax.persistence.Query;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Repository;
import co.com.ath.pgw.persistence.AbstractDAO_JPA;
import co.com.ath.pgw.persistence.dao.BillCollectorDAO;
import co.com.ath.pgw.persistence.model.BillCollector;

@Repository
public class BillCollectorDAOImpl extends AbstractDAO_JPA<BillCollector> implements BillCollectorDAO {
	
	static Logger LOGGER = LoggerFactory.getLogger(BillCollectorDAOImpl.class);
	
	public BillCollectorDAOImpl() {
		super(BillCollector.class);
	}

	@Override
	public BillCollector findServiceCode(Long commerceId) {
		BillCollector billCollector = null;
		try {
	        StringBuilder hql = new StringBuilder("FROM BillCollector bc ");
			hql.append(" WHERE bc.commerce.id = :commerceId");
			hql.append(" AND ROWNUM = 1");
			hql.append(" ORDER BY bc.id DESC ");
			
	        Query query = entityManager.createQuery(hql.toString());
			query.setParameter("commerceId", commerceId);
			
			billCollector = (BillCollector) query.getSingleResult();
		} catch (Exception e){
			LOGGER.warn("Problemas en query", e);
            return null;
        }		
		
		return billCollector;
	}

}
