/*
 * BatchJobInstance
 *  
 * GSI - Integración
 * Creado el: 14/04/2015
 *
 * Copyright (c) A Toda Hora S.A. Todos los derechos reservados
 * 
 * Este software es confidencial y es propietario de ATH, queda prohibido
 * su uso, reproducción y copia de manera parcial o permanente salvo autorización
 * expresa de A Toda Hora S.A o de quién represente sus derechos.
 */
package co.com.ath.pgw.persistence.model;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

/**
 * Clase que representa un registro del JOB.
 * 
 * @author Andrés Méndez <proveedor_mamendez@ath.com.co>
 * @version 14/04/2015
 * @since 1.0
 */
@Entity
@Table(name="BATCH_JOB_INSTANCE")
public class BatchJobInstance implements Serializable {

	/**
	 * ID de serialización.
	 */
	private static final long serialVersionUID = 1715718152957467367L;

	/**
	 * Identificador único del job.
	 */
	@Id
	@SequenceGenerator(
			name="BATCH_JOB_INSTANCE_ID_GENERATOR",
			sequenceName="BATCH_JOB_SEQ",
			initialValue=1,
			allocationSize=1
			)
	@GeneratedValue(
			strategy=GenerationType.SEQUENCE,
			generator="BATCH_JOB_INSTANCE_ID_GENERATOR"
			)
	
	@Column(name="JOB_INSTANCE_ID", nullable=false)
	private Long id;
	
	@Column(name="VERSION", nullable=true)
	private Long version;
	
	@Column(name="JOB_NAME", nullable=false)
	private String jobName;

	@Column(name="JOB_KEY", nullable=false)
	private String jobKey;
	
	/**
	 * Constructor por defecto de un Banco
	 */
	public BatchJobInstance(){
		super();
	}

	/**
	 * Método encargado de recuperar el valor del atributo id.
	 * @return El atributo id asociado a la clase.
	 */
	public Long getId() {
		return id;
	}

	/**
	 * Método encargado de actualizar el atributo id.
	 * @param id Nuevo valor para id.
	 */
	public void setId(Long id) {
		this.id = id;
	}
	
	/**
	 * Método encargado de recuperar el valor del atributo version.
	 * @return El atributo version asociado a la clase.
	 */
	public Long getVersion() {
		return version;
	}

	/**
	 * Método encargado de actualizar el atributo version.
	 * @param version Nuevo valor para version.
	 */
	public void setVersion(Long version) {
		this.version = version;
	}
	
	/**
	 * Método encargado de recuperar el valor del atributo jobName.
	 * @return El atributo jobName asociado a la clase.
	 */
	public String getJobName() {
		return jobName;
	}

	/**
	 * Método encargado de actualizar el atributo jobName.
	 * @param jobName Nuevo valor para jobName.
	 */
	public void setJobName(String jobName) {
		this.jobName = jobName;
	}

	/**
	 * Método encargado de recuperar el valor del atributo jobKey.
	 * @return El atributo jobKey asociado a la clase.
	 */
	public String getJobKey() {
		return jobKey;
	}

	/**
	 * Método encargado de actualizar el atributo jobKey.
	 * @param jobKey Nuevo valor para jobKey.
	 */
	public void setJobKey(String jobKey) {
		this.jobKey = jobKey;
	}

}