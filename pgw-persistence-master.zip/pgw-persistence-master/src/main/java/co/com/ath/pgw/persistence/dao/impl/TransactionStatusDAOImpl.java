/*
 * TransactionStatusDAOImpl
 *  
 * GSI - Integración
 * Creado el: 29/08/2014
 *
 * Copyright (c) A Toda Hora S.A. Todos los derechos reservados
 * 
 * Este software es confidencial y es propietario de ATH, queda prohibido
 * su uso, reproducción y copia de manera parcial o permanente salvo autorización
 * expresa de A Toda Hora S.A o de quién represente sus derechos.
 */
package co.com.ath.pgw.persistence.dao.impl;

import java.util.List;

import javax.persistence.NoResultException;
import javax.persistence.Query;

import org.hibernate.NonUniqueResultException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Repository;

import co.com.ath.pgw.persistence.AbstractDAO_JPA;
import co.com.ath.pgw.persistence.dao.TransactionStatusDAO;
import co.com.ath.pgw.persistence.model.TransactionStatus;
import co.com.ath.pgw.util.enums.TransactionStatusEnum;

/**
 * Implementación por defecto de TransactionStatusDAO
 *
 * @author Andrés Méndez Juanias <proveedor_mamendez@ath.com.co>
 * @version 1.0 29 Ago 2014
 * @since 1.0
 */
@Repository
public class TransactionStatusDAOImpl 
	extends AbstractDAO_JPA<TransactionStatus> implements TransactionStatusDAO {

	static Logger LOGGER = LoggerFactory.getLogger(TransactionStatusDAOImpl.class);
	
	public TransactionStatusDAOImpl() {
		super(TransactionStatus.class);
	}

	@Override
	public TransactionStatus findByDescription(TransactionStatusEnum description) {
		TransactionStatus entity;
		StringBuilder sb = new StringBuilder();
		sb.append(" from TransactionStatus ts where ts.rowDeleted <> 1 ");
		sb.append(" and ts.description = :description ");

		Query query = entityManager.createQuery(sb.toString());
		query.setParameter("description", description);

		try{
			entity = (TransactionStatus)query.getSingleResult();
		} catch(NoResultException ex){
			LOGGER.info("Error en query TransactionStatusDAOImpl.findByDescription({})\n{}", description, ex.toString());
			entity = null;
		}catch (NonUniqueResultException ex) {
			LOGGER.info("Error en query TransactionStatusDAOImpl.findByDescription({})\n{}", description, ex.toString());
			entity = null;
		}
		return entity;
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<TransactionStatus> findByBusinessCode(Long businessCode) {		
		List<TransactionStatus> entity;
		StringBuilder sb = new StringBuilder();
		sb.append(" from TransactionStatus ts where ts.rowDeleted <> 1 ");
		sb.append(" and ts.businessCode.code = :businessCode ");

		Query query = entityManager.createQuery(sb.toString());
		query.setParameter("businessCode", businessCode);

		try{
			entity = query.getResultList();
		} catch(NoResultException ex){
			LOGGER.info("Error en query TransactionStatusDAOImpl.findByBusinessCode({})\n{}", businessCode, ex.toString());
			entity = null;
		}
		return entity;
	}
	
	@Override
	public TransactionStatus findById(Long Id) {		
		TransactionStatus entity;
		StringBuilder sb = new StringBuilder();
		sb.append(" from TransactionStatus ts where ts.rowDeleted <> 1 ");
		sb.append(" and ts.code = :Id ");

		Query query = entityManager.createQuery(sb.toString());
		query.setParameter("Id", Id);

		try{
			entity = (TransactionStatus) query.getSingleResult();
		} catch(NoResultException ex){
			LOGGER.info("Error en query TransactionStatusDAOImpl.findById({})\n{}", Id, ex.toString());
			entity = null;
		}
		return entity;
	}

}
