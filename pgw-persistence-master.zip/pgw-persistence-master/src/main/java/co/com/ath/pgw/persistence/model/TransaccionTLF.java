package co.com.ath.pgw.persistence.model;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import co.com.ath.pgw.persistence.PersistentObject;

@Entity
@Table(name = "TRANSACCIONES_TLF")
public class TransaccionTLF implements PersistentObject {

	/**
	*  
	* Datos de la vista TRANSACCIONES_TLF
	*
	* @author Nelly Rocio Linares <nelly.linares@sophossolutions.com> 
	* @version 1.0 08/05/2019 
	* 
	**/
	
	private static final long serialVersionUID = 7313804626757797849L;

	/**
	 * 
	 */

	@Column(name = "PLN_TRAN_DATE")
	private String fechaTransaccion;

	@Column(name = "PLN_TRAN_TIME")
	private String horaTransaccion;

	@Column(name = "PLN_TRML_RECEIPT_NBR")
	private String numeroTransaccion;

	@Column(name = "PLN_TRANS_FI_NBR")
	private String codigoBanco;

	@Column(name = "PLN_AMT_TRAN")
	private String valorTransaccion;

	@Column(name = "PLN_OTHER_FI_NBR")
	private String autorizadorCredito;

	@Column(name = "PLN_BUS_DATE")
	private String fechaCompensacion;

	@Column(name = "PLN_AUTH_CODE")
	private String numeroAutorizacion;

	@Column(name = "PLN_NBR_SVC")
	private String codigoConvenio;

	@Column(name = "PLN_OTHER_MONEDA")
	private String otraMoneda;

	@Column(name = "PLN_TRML_RECEIPT_NBR_2")
	private String numeroTransaccion2;

	@Column(name = "PLN_TIPO_COMP")
	private String tipoCompensacion;

	@Column(name = "PLN_MEDIO_PAGO")
	private String medioPago;

	@Column(name = "PLN_NUM_REF")
	private String numeroReferencia;

	@Column(name = "PLN_FECHA_HORA")
	private String fechaHora;
	@Id
	@Column(name = "PLN_ID")
	private String identificadorUnico;

	@Override
	public boolean isRowDeleted() {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public void setRowDeleted(boolean rowDeleted) {
		// TODO Auto-generated method stub

	}

	@Override
	public Date getRowCreationDate() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void setRowCreationDate(Date rowCreationDate) {
		// TODO Auto-generated method stub

	}

	@Override
	public Date getRowLastUpdate() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void setRowLastUpdate(Date rowLastUpdate) {
		// TODO Auto-generated method stub

	}

	public String getFechaTransaccion() {
		return fechaTransaccion;
	}

	public void setFechaTransaccion(String fechaTransaccion) {
		this.fechaTransaccion = fechaTransaccion;
	}

	public String getHoraTransaccion() {
		return horaTransaccion;
	}

	public void setHoraTransaccion(String horaTransaccion) {
		this.horaTransaccion = horaTransaccion;
	}

	public String getNumeroTransaccion() {
		return numeroTransaccion;
	}

	public void setNumeroTransaccion(String numeroTransaccion) {
		this.numeroTransaccion = numeroTransaccion;
	}

	public String getCodigoBanco() {
		return codigoBanco;
	}

	public void setCodigoBanco(String codigoBanco) {
		this.codigoBanco = codigoBanco;
	}

	public String getValorTransaccion() {
		return valorTransaccion;
	}

	public void setValorTransaccion(String valorTransaccion) {
		this.valorTransaccion = valorTransaccion;
	}

	public String getAutorizadorCredito() {
		return autorizadorCredito;
	}

	public void setAutorizadorCredito(String autorizadorCredito) {
		this.autorizadorCredito = autorizadorCredito;
	}

	public String getFechaCompensacion() {
		return fechaCompensacion;
	}

	public void setFechaCompensacion(String fechaCompensacion) {
		this.fechaCompensacion = fechaCompensacion;
	}

	public String getNumeroAutorizacion() {
		return numeroAutorizacion;
	}

	public void setNumeroAutorizacion(String numeroAutorizacion) {
		this.numeroAutorizacion = numeroAutorizacion;
	}

	public String getCodigoConvenio() {
		return codigoConvenio;
	}

	public void setCodigoConvenio(String codigoConvenio) {
		this.codigoConvenio = codigoConvenio;
	}

	public String getOtraMoneda() {
		return otraMoneda;
	}

	public void setOtraMoneda(String otraMoneda) {
		this.otraMoneda = otraMoneda;
	}

	public String getNumeroTransaccion2() {
		return numeroTransaccion2;
	}

	public void setNumeroTransaccion2(String numeroTransaccion2) {
		this.numeroTransaccion2 = numeroTransaccion2;
	}

	public String getTipoCompensacion() {
		return tipoCompensacion;
	}

	public void setTipoCompensacion(String tipoCompensacion) {
		this.tipoCompensacion = tipoCompensacion;
	}

	public String getMedioPago() {
		return medioPago;
	}

	public void setMedioPago(String medioPago) {
		this.medioPago = medioPago;
	}

	public String getNumeroReferencia() {
		return numeroReferencia;
	}

	public void setNumeroReferencia(String numeroReferencia) {
		this.numeroReferencia = numeroReferencia;
	}

	public String getFechaHora() {
		return fechaHora;
	}

	public void setFechaHora(String fechaHora) {
		this.fechaHora = fechaHora;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((autorizadorCredito == null) ? 0 : autorizadorCredito.hashCode());
		result = prime * result + ((codigoBanco == null) ? 0 : codigoBanco.hashCode());
		result = prime * result + ((codigoConvenio == null) ? 0 : codigoConvenio.hashCode());
		result = prime * result + ((fechaCompensacion == null) ? 0 : fechaCompensacion.hashCode());
		result = prime * result + ((fechaHora == null) ? 0 : fechaHora.hashCode());
		result = prime * result + ((fechaTransaccion == null) ? 0 : fechaTransaccion.hashCode());
		result = prime * result + ((horaTransaccion == null) ? 0 : horaTransaccion.hashCode());
		result = prime * result + ((medioPago == null) ? 0 : medioPago.hashCode());
		result = prime * result + ((numeroAutorizacion == null) ? 0 : numeroAutorizacion.hashCode());
		result = prime * result + ((numeroReferencia == null) ? 0 : numeroReferencia.hashCode());
		result = prime * result + ((numeroTransaccion == null) ? 0 : numeroTransaccion.hashCode());
		result = prime * result + ((numeroTransaccion2 == null) ? 0 : numeroTransaccion2.hashCode());
		result = prime * result + ((otraMoneda == null) ? 0 : otraMoneda.hashCode());
		result = prime * result + ((tipoCompensacion == null) ? 0 : tipoCompensacion.hashCode());
		result = prime * result + ((valorTransaccion == null) ? 0 : valorTransaccion.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		TransaccionTLF other = (TransaccionTLF) obj;
		if (autorizadorCredito == null) {
			if (other.autorizadorCredito != null)
				return false;
		} else if (!autorizadorCredito.equals(other.autorizadorCredito))
			return false;
		if (codigoBanco == null) {
			if (other.codigoBanco != null)
				return false;
		} else if (!codigoBanco.equals(other.codigoBanco))
			return false;
		if (codigoConvenio == null) {
			if (other.codigoConvenio != null)
				return false;
		} else if (!codigoConvenio.equals(other.codigoConvenio))
			return false;
		if (fechaCompensacion == null) {
			if (other.fechaCompensacion != null)
				return false;
		} else if (!fechaCompensacion.equals(other.fechaCompensacion))
			return false;
		if (fechaHora == null) {
			if (other.fechaHora != null)
				return false;
		} else if (!fechaHora.equals(other.fechaHora))
			return false;
		if (fechaTransaccion == null) {
			if (other.fechaTransaccion != null)
				return false;
		} else if (!fechaTransaccion.equals(other.fechaTransaccion))
			return false;
		if (horaTransaccion == null) {
			if (other.horaTransaccion != null)
				return false;
		} else if (!horaTransaccion.equals(other.horaTransaccion))
			return false;
		if (medioPago == null) {
			if (other.medioPago != null)
				return false;
		} else if (!medioPago.equals(other.medioPago))
			return false;
		if (numeroAutorizacion == null) {
			if (other.numeroAutorizacion != null)
				return false;
		} else if (!numeroAutorizacion.equals(other.numeroAutorizacion))
			return false;
		if (numeroReferencia == null) {
			if (other.numeroReferencia != null)
				return false;
		} else if (!numeroReferencia.equals(other.numeroReferencia))
			return false;
		if (numeroTransaccion == null) {
			if (other.numeroTransaccion != null)
				return false;
		} else if (!numeroTransaccion.equals(other.numeroTransaccion))
			return false;
		if (numeroTransaccion2 == null) {
			if (other.numeroTransaccion2 != null)
				return false;
		} else if (!numeroTransaccion2.equals(other.numeroTransaccion2))
			return false;
		if (otraMoneda == null) {
			if (other.otraMoneda != null)
				return false;
		} else if (!otraMoneda.equals(other.otraMoneda))
			return false;
		if (tipoCompensacion == null) {
			if (other.tipoCompensacion != null)
				return false;
		} else if (!tipoCompensacion.equals(other.tipoCompensacion))
			return false;
		if (valorTransaccion == null) {
			if (other.valorTransaccion != null)
				return false;
		} else if (!valorTransaccion.equals(other.valorTransaccion))
			return false;
		return true;
	}

}
