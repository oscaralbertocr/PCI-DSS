/*
 * NonWorkingDayDAOImpl
 *  
 * GSI - Integración
 * Creado el: 29/08/2014
 *
 * Copyright (c) A Toda Hora S.A. Todos los derechos reservados
 * 
 * Este software es confidencial y es propietario de ATH, queda prohibido
 * su uso, reproducción y copia de manera parcial o permanente salvo autorización
 * expresa de A Toda Hora S.A o de quién represente sus derechos.
 */
package co.com.ath.pgw.persistence.dao.impl;

import java.util.List;

import javax.persistence.Query;

import org.springframework.stereotype.Repository;

import co.com.ath.pgw.persistence.AbstractDAO_JPA;
import co.com.ath.pgw.persistence.dao.NonWorkingDayDAO;
import co.com.ath.pgw.persistence.model.NonWorkingDay;

/**
 * Implementación por defecto de NonWorkingDayDAO.
 * 
 * @author proveedor_zagarcia
 * @version 1.0
 * @since 1.0 24/02/2015
 *
 */
@Repository
public class NonWorkingDayDAOImpl extends AbstractDAO_JPA<NonWorkingDay> implements NonWorkingDayDAO {
	
	public NonWorkingDayDAOImpl() {
		super(NonWorkingDay.class);
	}
	
	@SuppressWarnings("unchecked")
	@Override
	public List<NonWorkingDay> findByDay(int day) {
		StringBuilder hql = new StringBuilder("from NonWorkingDay nwd ");
		hql.append("where nwd.rowDeleted <> 1 ");
		hql.append("and nwd.id = :day ");
		
        Query query = entityManager.createQuery(hql.toString());
		query.setParameter("day", day);
		
		List<NonWorkingDay> nonWorkingDays = query.getResultList();
		return nonWorkingDays;
	}
}
