# pgw-agreement
# Ejecucion Release [RQ32865_Release_Agreement] - prv_jmrodriguez:AG_1
# Nueva Ejecucion Release [RQ32865_Release_Agreement] - prv_jmrodriguez:AG_1
# [30082019] 1_Release [RQ32095_Portal_Administrativo] - prv_jmrodriguez:AG_1.1 
# [09092019] 1_Release [RQ32095_Portal_Administrativo] - prv_jmrodriguez:AG_1.2 
# [11092019] 1_Release [RQ32095_Portal_Administrativo] - prv_jmrodriguez:AG_1.3 
# [18092019] 1_Release [RQ32095_Portal_Administrativo] - prv_jmrodriguez:AG_1.4 
# [18092019] 1_Release [RQ32095_Portal_Administrativo] - prv_javendano:AG_1.5 
# [15102019] 1_Release [Particion de Logs] - prv_javendano:AG_1.6 
# [25112019] 1_Release [RQ32865_Reporte fortify] - prv_javendano:AG_1.7:PT 
# [18022020] 1_Release [PDP81_Reporte fortify] - jmendoza:AG_1.8:PT 
# [04032020] 1_Release [PDP81_Reporte fortify] - jmendoza:AG_1.9:PT 
# [04032020] 1_Release [Reporte fortify] - jmendoza:AG_2.1:PT 
# [04032020] 1_Release [Reporte fortify] - jmendoza:AG_2.2:PT 
  



