package co.com.ath.pgw.srv;

/*
 * author: Edwin Bohorquez
 * description: Fachada para la exposicion de los 
 * 				servicios REST del Api agreementsManagement
*/

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import co.com.ath.pgw.bsn.controller.AgreementSynchronizationCtrlService;
import co.com.ath.pgw.bsn.controller.BankCtrlService;
import co.com.ath.pgw.in.dto.AgreementRsType;
import co.com.ath.pgw.rest.request.dto.Header;
import co.com.ath.pgw.rest.request.dto.RequestAgrmSynch;
import co.com.ath.pgw.rest.response.dto.BankListResponse;
import co.com.ath.pgw.rest.response.dto.GenericErrorResponse;
import co.com.ath.pgw.rest.response.dto.ResponseAgrmSynch;
import co.com.ath.pgw.srv.mapper.MapperAgreement;
import co.com.ath.pgw.srv.mapper.MapperGetBankInfo;
import co.com.ath.pgw.util.constants.CoreConstants;
import co.com.ath.pgw.util.exception.CustomException;


/**
 * Facade del Servicio agreement con las operaciones disponibles para le gestion de convenios.
 * @author SophosSolutions
 * @version 1.0 17/06/2019
 */

@CrossOrigin("*")
@RestController
@RequestMapping(path = "/agreementsManagement/v1")
public class AgreementServiceFacade {
	
	static Logger LOGGER = LoggerFactory.getLogger(AgreementServiceFacade.class);	
	
	@Autowired
	private AgreementSynchronizationCtrlService agreementSynchronizationCtrlService;
	
	@Value("${administrative.portal.chanel}")
    private String chanelPortalAdministrative;
	
	@Autowired
	private BankCtrlService bankCtrlService;
	
	/**
	 * servicio post para la creacion y sincronizacion de convenios.
	 * @param requestAgrmSynch
	 * @param header
	 * @return ResponseEntity
	 */	
	@PostMapping("/Agreements_BasicData/BasicData")		
	public ResponseEntity<?> synchInfo(
			@RequestHeader(name = "X-RqUID", required = true) Long rqUID,  
    		@RequestHeader(name = "X-Channel", required = true) String channel,
    		@RequestHeader(name = "X-CompanyId", required = true) String companyId,
    		@RequestHeader(name = "X-IPAddr", required = false) String ipAddr,
			@RequestBody RequestAgrmSynch requestAgrmSynch) throws CustomException{	
		
		String identSerialNum = "";
		String govIssueIdentType = "";
		Header header = new Header(rqUID, channel, companyId, identSerialNum, govIssueIdentType,ipAddr);
		LOGGER.info("@headerDto:  \n {}", header.getChannel());
		if (!header.getChannel().equalsIgnoreCase(chanelPortalAdministrative)) {
			try {
			LOGGER.info("@agrmntSynchAdm input\n{}", header + "\n" + requestAgrmSynch);    	
			AgreementRsType agreementRsType = agreementSynchronizationCtrlService.agrmntSynchAdm(MapperAgreement.mapperRequestToCoreRequest(requestAgrmSynch,header));    	
	    	
			if(agreementRsType.getStatus().getStatusCode() != CoreConstants.SUCCESS_STATUS_CODE) {
	    		LOGGER.info("statust sinc \n {}", agreementRsType.getStatus().getStatusCode()); 
	    		throw new CustomException(String.valueOf(agreementRsType.getStatus().getStatusCode()), agreementRsType);
	    	}
	    	
	    	//AgreementSuccesResponse responseSucces=	MapperAgreement.mapperResponseSuccessCore(agreementRsType);
	    	//LOGGER.info("@agrmntSynchAdm output\n {}", agreementRsType);
	    	
	    	HttpHeaders httpHeaders = new HttpHeaders();
	    	httpHeaders.add("X-RqUID", String.valueOf(rqUID));
	    	httpHeaders.add("X-ApprovalId", agreementRsType.getApprovalId());
	    	
	    	return new ResponseEntity<>(httpHeaders, HttpStatus.NO_CONTENT);
			}catch(CustomException e) {
				GenericErrorResponse responseError = MapperAgreement.mapperResponseError((AgreementRsType)e.getObjeto());
				LOGGER.info("@agrmntSynchAdm error output\n{}", header + "\n" + responseError);
				HttpHeaders httpHeaders = new HttpHeaders();
				httpHeaders.add("X-RqUID", String.valueOf(rqUID));
				httpHeaders.add("X-ApprovalId", CoreConstants.DEFAULT_APPROVAL);
				return new ResponseEntity<>(responseError,httpHeaders, HttpStatus.PARTIAL_CONTENT);
			}
		}else {
			try {
				LOGGER.info("@agrmCreate input\n{}", header + "\n" + requestAgrmSynch);    	
		    	AgreementRsType agreementRsType = agreementSynchronizationCtrlService.agrmCreate(requestAgrmSynch,header);
		    	if(agreementRsType.getStatus().getStatusCode() != CoreConstants.SUCCESS_STATUS_CODE) {
		    		LOGGER.info("statust \n {}", agreementRsType.getStatus().getStatusCode()); 
		    		throw new CustomException(String.valueOf(agreementRsType.getStatus().getStatusCode()), agreementRsType);
		    	}
		    	LOGGER.info("@agrmCreate output\n{}", header + "\n" + agreementRsType);
		    	HttpHeaders httpHeaders = new HttpHeaders();
		    	httpHeaders.add("X-RqUID", String.valueOf(rqUID));
		    	httpHeaders.add("X-ApprovalId", agreementRsType.getApprovalId());
		    	return new ResponseEntity<>(httpHeaders, HttpStatus.NO_CONTENT);
			}catch(CustomException e) {
				GenericErrorResponse genericErrorResponse = MapperAgreement.mapperResponseError((AgreementRsType)e.getObjeto());
				LOGGER.info("@agrmCreate error output\n{}", header + "\n" + genericErrorResponse);
				HttpHeaders httpHeaders = new HttpHeaders();
				httpHeaders.add("X-RqUID", String.valueOf(rqUID));
				httpHeaders.add("X-ApprovalId", CoreConstants.DEFAULT_APPROVAL);
				return new ResponseEntity<>(genericErrorResponse, httpHeaders, HttpStatus.PARTIAL_CONTENT);
			}
		}    	
	}		
	
	/**
	 * servicio put para buscar convenios.
	 * @param AgrmId
	 * @param header
	 * @return ResponseEntity
	 */	
	@GetMapping("/Agreements_BasicData/BasicData/{AgrmId}")		
	public ResponseEntity<?> searchAgrm(
			@RequestHeader(name = "X-RqUID", required = true) Long rqUID,  
    		@RequestHeader(name = "X-Channel", required = true) String channel,
    		@RequestHeader(name = "X-CompanyId", required = true) String companyId,
    		@RequestHeader(name = "X-IPAddr", required = false) String ipAddr,
    		@PathVariable(name = "AgrmId", required = true) String agrmId
	)throws CustomException {	
		
		String identSerialNum = "";
		String govIssueIdentType = "";
		Header header = new Header(rqUID, channel, companyId, identSerialNum, govIssueIdentType,ipAddr);
		LOGGER.info("@headerDto:  \n {}", agrmId);
		
		try {
			
		ResponseAgrmSynch responseAgrmSynch = agreementSynchronizationCtrlService.agrmFind(agrmId,header);    	
    	
		if(responseAgrmSynch.getStatusCode() != CoreConstants.SUCCESS_STATUS_CODE) {
    		LOGGER.info("statust find \n {}", responseAgrmSynch.getStatusCode()); 
    		throw new CustomException(String.valueOf(responseAgrmSynch.getStatusCode()), responseAgrmSynch);
    	}	
		
			RequestAgrmSynch requestAgrmSynch=	MapperAgreement.mapperResponsefind(responseAgrmSynch);    	
         	LOGGER.info("@agrmntFindAdm output\n{}", header + "\n" + responseAgrmSynch);    	
			HttpHeaders httpHeaders = new HttpHeaders();
			httpHeaders.add("X-RqUID", String.valueOf(rqUID));
			httpHeaders.add("X-ApprovalId", responseAgrmSynch.getApprovalId());
	    	
	    	return new ResponseEntity<>(requestAgrmSynch, httpHeaders, HttpStatus.OK);
		
		}catch(CustomException e) {
			GenericErrorResponse responseError = MapperAgreement.mapperResponseFindError((ResponseAgrmSynch)e.getObjeto());
			LOGGER.info("@agrmntFindAdm error output\n{}", header + "\n" + responseError);
			HttpHeaders headers = new HttpHeaders();
			headers.add("X-RqUID", String.valueOf(rqUID));
			headers.add("X-ApprovalId", CoreConstants.DEFAULT_APPROVAL);
			return new ResponseEntity<>(responseError, headers, HttpStatus.PARTIAL_CONTENT);
		}
	}   
	
	/**
	 * servicio put para actualizar convenios.
	 * @param requestAgrmSynch
	 * @param header
	 * @return ResponseEntity
	 */	
	@PutMapping("/Agreements_BasicData/BasicData")
	public ResponseEntity<?> agrmModify(
		@RequestHeader(name = "X-RqUID", required = true) Long rqUID,  
    	@RequestHeader(name = "X-Channel", required = true) String channel,
    	@RequestHeader(name = "X-CompanyId", required = true) String companyId,
    	@RequestHeader(name = "X-IPAddr", required = false) String ipAddr,
    	@RequestBody RequestAgrmSynch requestAgrmSynch) throws CustomException{		

		Header header = new Header(rqUID, channel, companyId, null, null, ipAddr);

		try{
			
			LOGGER.info("@agrmModify input\n{}", header + "\n" + requestAgrmSynch);
	    	AgreementRsType agreementRsType = agreementSynchronizationCtrlService.agrmModify(requestAgrmSynch, header, CoreConstants.UPDATE_OPERATION);
	    	
	    	if(agreementRsType.getStatus().getStatusCode() != CoreConstants.SUCCESS_STATUS_CODE) {
	    		LOGGER.info("statust \n {}", agreementRsType.getStatus().getStatusCode()); 
	    		throw new CustomException(String.valueOf(agreementRsType.getStatus().getStatusCode()), agreementRsType);
	    	}
	    	
	    	//AgreementSuccesResponse responseSucces=	MapperAgreement.mapperResponseSuccessCore(response);
	    	//LOGGER.info("@agrmModify output\n {}", response);
	    	
			HttpHeaders headers = new HttpHeaders();
			headers.add("X-RqUID", String.valueOf(rqUID));
			headers.add("X-ApprovalId", agreementRsType.getApprovalId());
			
			return new ResponseEntity<>(headers, HttpStatus.NO_CONTENT);
		}
		catch(CustomException e) {
			GenericErrorResponse genericErrorResponse = MapperAgreement.mapperResponseError((AgreementRsType)e.getObjeto());
			LOGGER.info("@agrmModify error output\n{}", header + "\n" + genericErrorResponse);
			HttpHeaders httpHeaders = new HttpHeaders();
			httpHeaders.add("X-RqUID", String.valueOf(rqUID));
			httpHeaders.add("X-ApprovalId", CoreConstants.DEFAULT_APPROVAL);
			return new ResponseEntity<>(genericErrorResponse, httpHeaders, HttpStatus.PARTIAL_CONTENT);
		}		
		
	}
	
	/**
	 * servicio delete para eliminar convenios de manera logica.
	 * @param header
	 * @return ResponseEntity
	 */	
	@DeleteMapping("/Agreements_BasicData/BasicData/{AgrmId}/{Type}")
	public ResponseEntity<?> agrmDelete(
		@RequestHeader(name = "X-RqUID", required = true) Long rqUID,  
    	@RequestHeader(name = "X-Channel", required = true) String channel,
    	@RequestHeader(name = "X-CompanyId", required = true) String companyId,
    	@RequestHeader(name = "X-IPAddr", required = false) String ipAddr,
    	@PathVariable(name = "AgrmId", required = true) String agrmId,
    	@PathVariable(name = "Type", required = true) String type) throws CustomException{		

		Header header = new Header(rqUID, channel, companyId, null, null, ipAddr);

		try{
			
			LOGGER.info("@agrmDelete input \n {}", agrmId);
	    	AgreementRsType agreementRsType = agreementSynchronizationCtrlService.agrmDelete(agrmId,type,header, CoreConstants.DELETE_OPERATION);
	    	
	    	if(agreementRsType.getStatus().getStatusCode() != CoreConstants.SUCCESS_STATUS_CODE) {
	    		LOGGER.info("statust \n {}", agreementRsType.getStatus().getStatusCode()); 
	    		throw new CustomException(String.valueOf(agreementRsType.getStatus().getStatusCode()), agreementRsType);
	    	}
	    	
	    	//AgreementSuccesResponse responseSucces=	MapperAgreement.mapperResponseSuccessCore(response);
	    	//LOGGER.info("@agrmDelete output\n {}", response);
	    	
			HttpHeaders httpHeaders = new HttpHeaders();
			httpHeaders.add("X-RqUID", String.valueOf(rqUID));
			httpHeaders.add("X-ApprovalId", agreementRsType.getApprovalId());
			
			return new ResponseEntity<>(httpHeaders, HttpStatus.NO_CONTENT);
		}
		catch(CustomException e) {
			GenericErrorResponse genericErrorResponse = MapperAgreement.mapperResponseError((AgreementRsType)e.getObjeto());
			LOGGER.info("@agrmDelete error output\n{}", header + "\n" + genericErrorResponse);
			HttpHeaders httpHeaders = new HttpHeaders();
			httpHeaders.add("X-RqUID", String.valueOf(rqUID));
			httpHeaders.add("X-ApprovalId", CoreConstants.DEFAULT_APPROVAL);
			return new ResponseEntity<>(genericErrorResponse, httpHeaders, HttpStatus.PARTIAL_CONTENT);
		}		
		
	}

	/**
	 * Servicio de consulta de entidades asociadas a convenios
	 * @param rqUID
	 * @param channel
	 * @param companyId
	 * @param iPAddr
	 * @param type
	 * @return ResponseEntity
	 */	
	@GetMapping("/Inquiries_Entity/Entity")
	public ResponseEntity<?> getInquiriesEntity(@RequestHeader(name = "X-RqUID", required = true) Long rqUID,
			@RequestHeader(name = "X-Channel", required = true) String channel,
			@RequestHeader(name = "X-CompanyId", required = true) String companyId,
			@RequestHeader(name = "X-IPAddr", required = false) String iPAddr,
			@RequestParam(name = "type", required = true) Long type) {

		LOGGER.info("@getInquiriesEntity queryParam type {}", type);

		Header header = new Header(rqUID, channel, companyId, null, null, iPAddr);

		BankListResponse bankResponse = bankCtrlService.findByIsAval(type);

		HttpHeaders headers = new HttpHeaders();
		headers.add("X-RqUID", String.valueOf(rqUID));
		headers.add("X-ApprovalId", CoreConstants.DEFAULT_APPROVAL);
		if (bankResponse.getBankInfo().isEmpty()) {
			LOGGER.info("@getInquiriesEntity No recupero datos");
			GenericErrorResponse response = MapperGetBankInfo.mapperResponseErrorCore();
			LOGGER.info("@getInquiriesEntity error output\n{}", header + "\n" + response);

			return new ResponseEntity<>(response, headers, HttpStatus.PARTIAL_CONTENT);

		}
		LOGGER.info("@getAdministrationAgreement proceso exitoso");
		return new ResponseEntity<>(bankResponse, headers, HttpStatus.OK);

	}
}		


