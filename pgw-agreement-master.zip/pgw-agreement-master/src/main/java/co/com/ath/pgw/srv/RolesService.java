package co.com.ath.pgw.srv;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import co.com.ath.pgw.bsn.model.bo.CommerceRoleContactBO;
import co.com.ath.pgw.bsn.controller.RoleCtrlService;
import co.com.ath.pgw.srv.mapper.MapperGetRol;
import co.com.ath.pgw.util.constants.CoreConstants;
import co.com.ath.pgw.rest.dto.RoleInfo;
import co.com.ath.pgw.rest.request.dto.Header;
import co.com.ath.pgw.rest.response.dto.GenericErrorResponse;

/*
* Servicio que Permite consultar los roles
* 
*
* @author Nelly Rocio Linares <nelly.linares@sophossolutions.com>
* @version 1.0 28/05/2019
* 
*/

@CrossOrigin("*")
@RestController
@RequestMapping("/securityManagement/v1")
public class RolesService {

	@Autowired
	RoleCtrlService roleCtrlService;

	static Logger LOGGER = LoggerFactory.getLogger(RolesService.class);

	@Deprecated
	@GetMapping("/Inquiries_Agreement/Agreement")
	public ResponseEntity<?> getAdministrationAgreement(@RequestHeader(name = "X-RqUID", required = true) Long rqUID,
			@RequestHeader(name = "X-Channel", required = true) String channel,
			@RequestHeader(name = "X-CompanyId", required = true) String companyId,
			@RequestHeader(name = "X-IPAddr", required = false) String iPAddr) {

		LOGGER.info("@getAdministrationAgreement ingreso");

		Header headerDto = new Header(rqUID, channel, companyId, null, null, iPAddr);

		List<CommerceRoleContactBO> lista = roleCtrlService.findAll();

		List<RoleInfo> roles = MapperGetRol.mapperResponseSuccessCore(lista);

		HttpHeaders headers = new HttpHeaders();
		headers.add("X-RqUID", String.valueOf(rqUID));

		if (roles.isEmpty()) {
			LOGGER.info("@getAdministrationAgreement No recupero datos");
			headers.add("X-RqUID", String.valueOf(rqUID));
			headers.add("X-ApprovalId", CoreConstants.DEFAULT_APPROVAL);
			GenericErrorResponse response = MapperGetRol.mapperResponseErrorCore();
			LOGGER.info("@getTransaction error output\n{}", headerDto + "\n" + response);
			return new ResponseEntity<>(response, headers, HttpStatus.INTERNAL_SERVER_ERROR);
		}

		LOGGER.info("@getAdministrationAgreement proceso exitoso");
		return new ResponseEntity<>(roles, headers, HttpStatus.OK);

	}

}
