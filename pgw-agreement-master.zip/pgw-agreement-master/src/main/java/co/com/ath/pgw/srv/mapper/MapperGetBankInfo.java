package co.com.ath.pgw.srv.mapper;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;

import co.com.ath.pgw.persistence.model.Bank;
import co.com.ath.pgw.rest.dto.AdditionalStatus;
import co.com.ath.pgw.rest.dto.BankInfo;
import co.com.ath.pgw.rest.dto.MsgRsHdr;
import co.com.ath.pgw.rest.dto.Status;
import co.com.ath.pgw.rest.response.dto.BankListResponse;
import co.com.ath.pgw.rest.response.dto.GenericErrorResponse;
import co.com.ath.pgw.util.constants.CoreConstants;

/*
* Mapper relacionado a los datos de las entidades bancarias
* 
*
* @author Nelly Rocio Linares <nelly.linares@sophossolutions.com>
* @version 1.0 28/05/2019
* 
*/

public class MapperGetBankInfo {

	public static BankListResponse mapperResponseSuccessCore(List<Bank> inn) {

		BankListResponse response = new BankListResponse();

		List<BankInfo> banksInfo = new ArrayList<BankInfo>();

		for (Bank bank : inn) {
			BankInfo bankInfo = new BankInfo();
			bankInfo.setBankId(bank.getId().toString());
			bankInfo.setName(bank.getName());
			bankInfo.setBranchId(bank.getAvalCode());
			banksInfo.add(bankInfo);
		}
		response.setBankInfo(banksInfo);
		return response;
	}

	public static GenericErrorResponse mapperResponseErrorCore() {
		GenericErrorResponse out = new GenericErrorResponse();
		Status status = new Status();
		status.setStatusCode(String.valueOf(CoreConstants.DATA_NOT_FOUND_INQUIRIES_ENTITY_STATUS_CODE));
		status.setStatusDesc(CoreConstants.DATA_NOT_FOUND_INQUIRIES_ENTITY_STATUS_DESC);
		status.setEndDt(Calendar.getInstance().getTime());

		AdditionalStatus additionalStatus = new AdditionalStatus();
		additionalStatus.setStatusCode(String.valueOf(CoreConstants.DATA_NOT_FOUND_INQUIRIES_ENTITY_STATUS_CODE));
		additionalStatus.setStatusDesc(CoreConstants.DATA_NOT_FOUND_INQUIRIES_ENTITY_STATUS_DESC);
		status.setAdditionalStatus(additionalStatus);

		MsgRsHdr msgRsHdr = new MsgRsHdr();
		msgRsHdr.setStatus(status);
		msgRsHdr.setEndDt(Calendar.getInstance().getTime());
		out.setMsgRsHdr(msgRsHdr);

		return out;
	}

}
