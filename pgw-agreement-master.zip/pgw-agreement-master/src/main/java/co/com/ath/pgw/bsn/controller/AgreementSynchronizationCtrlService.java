package co.com.ath.pgw.bsn.controller;

import co.com.ath.pgw.in.dto.AgreementSynchronizationRqType;
import co.com.ath.pgw.in.dto.AgreementRsType;
import co.com.ath.pgw.rest.request.dto.Header;
import co.com.ath.pgw.rest.request.dto.RequestAgrmSynch;
import co.com.ath.pgw.rest.response.dto.ResponseAgrmSynch;

/**
 * Servicio puente para las peticiones entre los servicios de AgreementSynchronization y el Core
 * @author proveedor_cjmurillo
 * @version 1.0
 * @since 1.0
 */
public interface AgreementSynchronizationCtrlService {
	
	/**
	 * Permite gestionar novedades en los convenios asociados.
	 * @param agreementSynchronizationRq
	 * @return AgreementRsType
	 */
	public AgreementRsType agrmntSynchAdm(AgreementSynchronizationRqType agreementSynchronizationRq);
    /**
	 * Permite crear convenios desde el portal administrativo.
	 * @param requestAgrmSynch
	 * @param headerDto
	 * @return AgreementRsType
	 */
	public AgreementRsType agrmCreate(RequestAgrmSynch requestAgrmSynch, Header headerDto);
	/**
	 * Permite buscar convenios desde el portal administrativo.
	 * @param agrmId
	 * @param headerDto
	 * @return RequestAgrmSynch
	 */
	public ResponseAgrmSynch agrmFind(String agrmId, Header headerDto);

	/**
	 * Permite gestionar novedades en los convenios asociados.
	 * @param requestAgrmSynch
	 * @param headerDto
	 * @param operacion	 
	 * @return AgreementRsType
	 */
	public AgreementRsType agrmModify(RequestAgrmSynch requestAgrmSynch, Header headerDto, String operacion);
	/**
	 * Permite eliminar convenios desde el portal administrativo.
	 * @param requestAgrmSynch
	 * @param headerDto
	 * @return AgreementRsType
	 */
	public AgreementRsType agrmDelete(String agrmId, String type, Header headerDto, String operacion);


}