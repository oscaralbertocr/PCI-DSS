package co.com.ath.pgw.srv.mapper;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;

import co.com.ath.pgw.bsn.model.bo.CommerceRoleContactBO;
import co.com.ath.pgw.rest.dto.AdditionalStatus;
import co.com.ath.pgw.rest.dto.MsgRsHdr;
import co.com.ath.pgw.rest.dto.RoleInfo;
import co.com.ath.pgw.rest.dto.Status;
import co.com.ath.pgw.rest.response.dto.GenericErrorResponse;
import co.com.ath.pgw.util.constants.CoreConstants;

/*
* Mapper relacionado a los roles
* 
*
* @author Nelly Rocio Linares <nelly.linares@sophossolutions.com>
* @version 1.0 28/05/2019
* 
*/

public class MapperGetRol {

	public static List<RoleInfo> mapperResponseSuccessCore(List<CommerceRoleContactBO> inn) {

		List<RoleInfo> listOut = new ArrayList<RoleInfo>();

		for (CommerceRoleContactBO roleInn : inn) {

			RoleInfo role = new RoleInfo();
			role.setName(roleInn.getName());
			role.setRoleInfoId(roleInn.getId());
			listOut.add(role);
		}

		return listOut;
	}

	public static GenericErrorResponse mapperResponseErrorCore() {
		GenericErrorResponse out = new GenericErrorResponse();
		Status status = new Status();
		status.setStatusCode(String.valueOf(CoreConstants.FAULT_STATUS_CODE));
		status.setStatusDesc(CoreConstants.FAULT_STATUS_DESC);
		status.setEndDt(Calendar.getInstance().getTime());

		AdditionalStatus additionalStatus = new AdditionalStatus();
		additionalStatus.setStatusCode(String.valueOf(CoreConstants.FAULT_STATUS_CODE));
		additionalStatus.setStatusDesc(CoreConstants.FAULT_STATUS_DESC);
		status.setAdditionalStatus(additionalStatus);

		MsgRsHdr msgRsHdr = new MsgRsHdr();
		msgRsHdr.setStatus(status);
		msgRsHdr.setEndDt(Calendar.getInstance().getTime());
		out.setMsgRsHdr(msgRsHdr);

		return out;
	}

}
