package co.com.ath.pgw.bsn.controller;

import co.com.ath.pgw.rest.response.dto.BankListResponse;

/*
* Interface del servicio de obtener las entidades bancarias
*
* @author Nelly Rocio Linares <nelly.linares@sophossolutions.com>
* @version 1.0 28/05/2019
* 
*/

public interface BankCtrlService {

	public BankListResponse findByIsAval(Long valor);

}
