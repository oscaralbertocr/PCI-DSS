package co.com.ath.pgw.bsn.controller.impl;

import javax.annotation.Resource;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import co.com.ath.pgw.bsn.controller.AgreementSynchronizationCtrlService;
import co.com.ath.pgw.bsn.dto.in.AgreementSynchronizationInDTO;
import co.com.ath.pgw.bsn.dto.out.AgreementOutDTO;
import co.com.ath.pgw.bsn.service.AgreementSynchronizationService;
import co.com.ath.pgw.in.dto.AgreementSynchronizationRqType;
import co.com.ath.pgw.in.dto.AgreementRsType;
import co.com.ath.pgw.rest.request.dto.Header;
import co.com.ath.pgw.rest.request.dto.RequestAgrmSynch;
import co.com.ath.pgw.rest.response.dto.ResponseAgrmSynch;
import co.com.ath.pgw.util.converter.AgreementObjectsConverter;

/**
 * Implementación de servicio puente para las peticiones entre los servicios de
 * Agreement y el Core Pasarela
 * 
 * @author proveedor_edrobles
 * @version 1.0
 * @since 1.0
 */
@Service
public class AgreementSynchronizationControlServiceImpl implements AgreementSynchronizationCtrlService {
	static Logger LOGGER = LoggerFactory.getLogger(AgreementSynchronizationControlServiceImpl.class);

	@Resource
	AgreementSynchronizationService agreementSynchronizationService;

	@Override
	public AgreementRsType agrmntSynchAdm(AgreementSynchronizationRqType agreementSynchronizationRq) {
		AgreementRsType agreementSynchronizationRsType = null;
		try {
			AgreementSynchronizationInDTO agreementSynchronizationInDTO = AgreementObjectsConverter
					.toAgreementSynchronizationInDTO(agreementSynchronizationRq);

			AgreementOutDTO agreementSynchronizationOutDTO = agreementSynchronizationService
					.agrmntSynchAdm(agreementSynchronizationInDTO);

			agreementSynchronizationRsType = AgreementObjectsConverter
					.toAgreementSynchronizationRsType(agreementSynchronizationOutDTO);
		} catch (Exception ex) {
			agreementSynchronizationRsType = AgreementObjectsConverter
					.toAgreementSynchronizationRsTypeError(agreementSynchronizationRq, ex);
		}
		return agreementSynchronizationRsType;
	}

	@Override
	public AgreementRsType agrmCreate(RequestAgrmSynch requestAgrmSynch, Header headerDto) {
		AgreementRsType agreementCreateRsType = null;
		try {
			AgreementOutDTO agreementCreateOutDTO = agreementSynchronizationService.agrmntCreateAdm(requestAgrmSynch,
					headerDto);

			agreementCreateRsType = AgreementObjectsConverter.toAgreementSynchronizationRsType(agreementCreateOutDTO);

		} catch (Exception ex) {
			LOGGER.error("Se presento un error en la creación del convenio", ex);
			agreementCreateRsType = AgreementObjectsConverter.toAgreementRsTypeError(headerDto, ex);
		}
		return agreementCreateRsType;
	}

	@Override
	public ResponseAgrmSynch agrmFind(String agrmId, Header headerDto) {
		ResponseAgrmSynch responseAgrmSynch = null;
		try {
			responseAgrmSynch = agreementSynchronizationService.agrmntFindAdm(agrmId, headerDto);
		} catch (Exception ex) {
			LOGGER.error("Se presento un error en la consulta del convenio", ex.getMessage());
			responseAgrmSynch = AgreementObjectsConverter.toAgreementFindRsTypeError(headerDto, ex);
		}
		return responseAgrmSynch;
	}

	@Override
	public AgreementRsType agrmModify(RequestAgrmSynch requestAgrmSynch, Header headerDto, String operacion) {
		AgreementRsType agreementModifyRsType = null;
		try {
			AgreementOutDTO agreementModifyOutDTO = agreementSynchronizationService.agrmntModifyAdm(requestAgrmSynch,
					headerDto, operacion);

			agreementModifyRsType = AgreementObjectsConverter.toAgreementSynchronizationRsType(agreementModifyOutDTO);

		} catch (Exception ex) {
			agreementModifyRsType = AgreementObjectsConverter.toAgreementRsTypeError(headerDto, ex);

			LOGGER.error("Se presento un error en la modificación del convenio", ex.getMessage());
		}
		return agreementModifyRsType;
	}
	
	@Override
	public AgreementRsType agrmDelete(String agrmId, String type, Header headerDto, String operacion) {
		AgreementRsType agreementDeleteRsType= null;
		try {
			AgreementOutDTO agreementDeleteOutDTO = 
					agreementSynchronizationService.agrmntDeleteAdm(agrmId, type, headerDto, operacion);
			
			agreementDeleteRsType = 
					AgreementObjectsConverter.toAgreementSynchronizationRsType(agreementDeleteOutDTO);
			
		}catch(Exception ex){
			agreementDeleteRsType = 
					AgreementObjectsConverter.toAgreementDeleteRsTypeError(headerDto, ex);
		
			LOGGER.error("Se presento un error en la eliminación del convenio", ex.getMessage());
		}
		return agreementDeleteRsType;
	}

}
