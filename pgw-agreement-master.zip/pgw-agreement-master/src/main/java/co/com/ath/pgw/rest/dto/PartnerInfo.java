package co.com.ath.pgw.rest.dto;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonProperty;

public class PartnerInfo implements Serializable
{

    @JsonProperty("PartnerType")
    private String partnerType;
    @JsonProperty("ContactInfo")
    private ContactInfo contactInfo;
    @JsonProperty("PersonInfo")
    private PersonInfo personInfo;
    private final static long serialVersionUID = 3696988956603154990L;

    @JsonProperty("PartnerType")
    public String getPartnerType() {
        return partnerType;
    }

    @JsonProperty("PartnerType")
    public void setPartnerType(String partnerType) {
        this.partnerType = partnerType;
    }

    @JsonProperty("ContactInfo")
    public ContactInfo getContactInfo() {
        return contactInfo;
    }

    @JsonProperty("ContactInfo")
    public void setContactInfo(ContactInfo contactInfo) {
        this.contactInfo = contactInfo;
    }

    @JsonProperty("PersonInfo")
    public PersonInfo getPersonInfo() {
        return personInfo;
    }

    @JsonProperty("PersonInfo")
    public void setPersonInfo(PersonInfo personInfo) {
        this.personInfo = personInfo;
    }


}
