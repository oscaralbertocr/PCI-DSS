package co.com.ath.pgw.srv.mapper;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

import co.com.ath.pgw.in.dto.AgreementSynchronizationRqType;
import co.com.ath.pgw.in.dto.AgreementRsType;
import co.com.ath.pgw.in.dto.TransactionAddRsType;
import co.com.ath.pgw.in.model.AgreementInfoType;
import co.com.ath.pgw.in.model.BankInfoType;
import co.com.ath.pgw.in.model.CompanyDetailType;
import co.com.ath.pgw.in.model.CompanyType;
import co.com.ath.pgw.in.model.CustNameType;
import co.com.ath.pgw.in.model.FeeType;
import co.com.ath.pgw.in.model.IndicatorType;
import co.com.ath.pgw.in.model.InvoiceReferenceType;
import co.com.ath.pgw.in.model.OrderInfoType;
import co.com.ath.pgw.in.model.PersonalDataType;
import co.com.ath.pgw.in.model.ReferenceType;
import co.com.ath.pgw.in.model.SecretListType;
import co.com.ath.pgw.in.model.TaxFeeType;
import co.com.ath.pgw.in.model.UserIdType;
import co.com.ath.pgw.rest.dto.AssociateInfo;
import co.com.ath.pgw.rest.dto.ContactInfo;
import co.com.ath.pgw.rest.dto.MsgRsHdr;
import co.com.ath.pgw.rest.dto.PartnerInfo;
import co.com.ath.pgw.rest.dto.AdditionalStatus;
import co.com.ath.pgw.rest.dto.Agreement;
import co.com.ath.pgw.rest.dto.PhoneNum;
import co.com.ath.pgw.rest.dto.RefInfo;
import co.com.ath.pgw.rest.dto.SecretList;
import co.com.ath.pgw.rest.dto.Status;
import co.com.ath.pgw.rest.dto.TrnSrcInfo;
import co.com.ath.pgw.rest.request.dto.Header;
import co.com.ath.pgw.rest.request.dto.RequestAgrmSynch;
import co.com.ath.pgw.rest.response.dto.AgreementSuccesResponse;
import co.com.ath.pgw.rest.response.dto.TransactionCreateResponse;
import co.com.ath.pgw.rest.response.dto.GenericErrorResponse;
import co.com.ath.pgw.rest.response.dto.ResponseAgrmSynch;
import co.com.ath.pgw.util.constants.CoreConstants;

/**
 * Servicio de Mapeo de objetos para la sincronizacion de convenios
 * @author proveedor_cjmurillo
 * @version 1.0
 * @since 1.0
 */
public class MapperAgreement {
	
	
	/**
	 * mapeo request para la sincronizacion de convenios.
	 * @param requestAgrmSynch
	 * @param header
	 * @return AgreementSynchronizationRqType
	 */	
	public static AgreementSynchronizationRqType mapperRequestToCoreRequest(RequestAgrmSynch requestAgrmSynch, Header header) {
		
		AgreementSynchronizationRqType agreementSynchronizationRqType = new AgreementSynchronizationRqType();
		
		agreementSynchronizationRqType.setRqUID(header.getRqUID());
		agreementSynchronizationRqType.setChannel(header.getChannel());
		
		CompanyType companyType = new CompanyType();
		companyType.setCompanyId(requestAgrmSynch.getAgreement().getAgrmId());
		agreementSynchronizationRqType.setCompany(companyType);
		
		agreementSynchronizationRqType.setCategoryId(requestAgrmSynch.getAgreement().getCategCode());
		
		
		AgreementInfoType agreementInfoType=new AgreementInfoType();
		agreementInfoType.setName(requestAgrmSynch.getAgreement().getName());
		agreementSynchronizationRqType.setAgreementInfo(agreementInfoType);		
		
		agreementSynchronizationRqType.setTrnChannel(requestAgrmSynch.getTrnSrcInfo().getTrnSrc());
		
		
		
		CompanyDetailType companyDetailType=new CompanyDetailType();
		companyDetailType.setEmailAddr(requestAgrmSynch.getAgreement().getContactInfo().getEmailAddr());
		for(PhoneNum phonetype : requestAgrmSynch.getAgreement().getContactInfo().getPhoneNum()) {
			if(phonetype.getPhone().equals(CoreConstants.TYPE_FAX))
				companyDetailType.setExtensions(phonetype.getPhoneType());
			else
				companyDetailType.setPhone(phonetype.getPhoneType());			
		}
		companyDetailType.setCityId(requestAgrmSynch.getAgreement().getContactInfo().getPostAddr().getCity());
		companyDetailType.setAddress(requestAgrmSynch.getAgreement().getContactInfo().getPostAddr().getAddr1());

		agreementSynchronizationRqType.setCompanyDetail(companyDetailType);
		
		PersonalDataType personalDataType= new PersonalDataType();
		CustNameType custNameType=new CustNameType();
		custNameType.setLegalName(requestAgrmSynch.getLegalPerson().getPersonName().getLegalName());
		personalDataType.setCustName(custNameType);
		
		
		for(PartnerInfo partnerInfo :requestAgrmSynch.getPartnerInfo()) {
			for(PhoneNum phonetype : partnerInfo.getContactInfo().getPhoneNum()) {
				personalDataType.setCellPhone(phonetype.getPhoneType());			
			}
			
			personalDataType.setEmailAddr(partnerInfo.getContactInfo().getEmailAddr());
			
		}
		
		
		agreementSynchronizationRqType.setPersonalData(personalDataType);
		
		for(RefInfo refInfoRq :requestAgrmSynch.getRefInfo()) {
			if(refInfoRq.getRefId().equalsIgnoreCase(CoreConstants.REFERENCE_CODEAN)) { 
				agreementInfoType.setAgreementId(refInfoRq.getRefType());
				agreementSynchronizationRqType.setAgreementInfo(agreementInfoType);
			}else if(refInfoRq.getRefId().equalsIgnoreCase(CoreConstants.REFERENCE_ADMTYPE)) {			
				agreementSynchronizationRqType.setAdmType(refInfoRq.getRefType());
			}else if(refInfoRq.getRefId().equalsIgnoreCase(CoreConstants.REFERENCE_ESTADO)) {			
				IndicatorType indicator= new IndicatorType();
				indicator.setState(refInfoRq.getRefType());
				agreementSynchronizationRqType.setIndicator(indicator);
			}
			else {
			ReferenceType referenceType = new ReferenceType();
			referenceType.setRefId(refInfoRq.getRefId());
			referenceType.setRefType(refInfoRq.getRefType());
			agreementSynchronizationRqType.getReference().add(referenceType);
			}
		}
		
		BankInfoType bankInfoType=new BankInfoType();
		bankInfoType.setBankId(requestAgrmSynch.getBankInfo().getBankId());
		agreementSynchronizationRqType.setBankInfo(bankInfoType);
		
		return agreementSynchronizationRqType;
	}
	/**
	 * mapeo respuesta exitosa para la sincronizacion de convenios.
	 * @param agreementRsType
	 * @return AgreementSuccesResponse
	 */	
	public static RequestAgrmSynch mapperResponsefind(ResponseAgrmSynch responseAgrmSynch) {		
		RequestAgrmSynch requestAgrmSynch= new RequestAgrmSynch();
		
		requestAgrmSynch.setAgreement(responseAgrmSynch.getAgreement());
		requestAgrmSynch.setBankInfo(responseAgrmSynch.getBankInfo());
		requestAgrmSynch.setLegalPerson(responseAgrmSynch.getLegalPerson());
		requestAgrmSynch.setPartnerInfo(responseAgrmSynch.getPartnerInfo());
		requestAgrmSynch.setPmtInfo(responseAgrmSynch.getPmtInfo());
		requestAgrmSynch.setRefInfo(responseAgrmSynch.getRefInfo());
		requestAgrmSynch.setSecretList(responseAgrmSynch.getSecretList());
		requestAgrmSynch.setTrnSrcInfo(responseAgrmSynch.getTrnSrcInfo());
		requestAgrmSynch.setAdditionalDepAcctId(responseAgrmSynch.getAdditionalDepAcctId());

		
		return requestAgrmSynch;
	}
	
	/**
	 * mapeo respuesta exitosa para la sincronizacion de convenios.
	 * @param agreementRsType
	 * @return AgreementSuccesResponse
	 */	
	public static AgreementSuccesResponse mapperResponseSuccessCore(AgreementRsType agreementRsType) {
		AgreementSuccesResponse agreementSuccesResponse= new AgreementSuccesResponse();
		
		MsgRsHdr msgRsHdr = new MsgRsHdr();
		Status status = new Status();
		status.setStatusCode(String.valueOf(agreementRsType.getStatus().getStatusCode()));
		status.setStatusDesc(agreementRsType.getStatus().getStatusDesc());
		
		DateFormat dateFormat = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss");
		Date date = new Date();
	
		status.setEndDt(date);
				
		AdditionalStatus additionalStatus = new AdditionalStatus();
		additionalStatus.setStatusCode(agreementRsType.getStatus().getServerStatusCode());
		additionalStatus.setStatusDesc(agreementRsType.getStatus().getServerStatusDesc());
		status.setAdditionalStatus(additionalStatus);
		msgRsHdr.setStatus(status);
		agreementSuccesResponse.setMsgRsHdr(msgRsHdr);
		
		return agreementSuccesResponse;
	}
	/**
	 * mapeo respuesta error para la sincronizacion de convenios.
	 * @param agreementRsType
	 * @return GenericErrorResponse
	 */		
	public static GenericErrorResponse mapperResponseError(AgreementRsType agreementRsType) {
		GenericErrorResponse genericErrorResponse = new GenericErrorResponse();
		
		MsgRsHdr msgRsHdr= new MsgRsHdr();
		Status status = new Status();
		status.setStatusCode(String.valueOf(agreementRsType.getStatus().getStatusCode()));
		status.setStatusDesc(agreementRsType.getStatus().getStatusDesc());
		
		DateFormat dateFormat = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss");
		Date date = new Date();
	
		status.setEndDt(Calendar.getInstance().getTime());
		
		AdditionalStatus additionalStatus = new AdditionalStatus();
		additionalStatus.setStatusCode(agreementRsType.getStatus().getServerStatusCode());
		additionalStatus.setStatusDesc(agreementRsType.getStatus().getServerStatusDesc());
		status.setAdditionalStatus(additionalStatus);
		
		msgRsHdr.setStatus(status);
		msgRsHdr.setEndDt(Calendar.getInstance().getTime());
		
		genericErrorResponse.setMsgRsHdr(msgRsHdr);
		
		return genericErrorResponse;
	}
	
	public static GenericErrorResponse mapperResponseFindError(ResponseAgrmSynch responseAgrmSynch) {
		GenericErrorResponse genericErrorResponse = new GenericErrorResponse();
		
		MsgRsHdr msgRsHdr= new MsgRsHdr();
		Status status = new Status();
		status.setStatusCode(String.valueOf(responseAgrmSynch.getStatusCode()));
		status.setStatusDesc(responseAgrmSynch.getStatusDesc());
		
		DateFormat dateFormat = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss");
		Date date = new Date();
	
		status.setEndDt(Calendar.getInstance().getTime());
		
		AdditionalStatus additionalStatus = new AdditionalStatus();
		additionalStatus.setStatusCode(responseAgrmSynch.getTrnServerStatusCode());
		additionalStatus.setStatusDesc(responseAgrmSynch.getTrnServerStatusDesc());
		status.setAdditionalStatus(additionalStatus);
		
		msgRsHdr.setStatus(status);
		msgRsHdr.setEndDt(Calendar.getInstance().getTime());
		
		genericErrorResponse.setMsgRsHdr(msgRsHdr);
		
		return genericErrorResponse;
	}
	
}

