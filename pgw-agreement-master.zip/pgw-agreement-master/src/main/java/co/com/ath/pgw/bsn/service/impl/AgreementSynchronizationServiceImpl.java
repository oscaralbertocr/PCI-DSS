/*
 * AgreementSynchronizationServiceImpl
 *  
 * GSI - Recaudos
 * Creado el: 05/11/2015
 *
 * Copyright (c) A Toda Hora S.A. Todos los derechos reservados
 * 
 * Este software es confidencial y es propietario de ATH, queda prohibido
 * su uso, reproducción y copia de manera parcial o permanente salvo autorización
 * expresa de A Toda Hora S.A o de quién represente sus derechos.
 */
package co.com.ath.pgw.bsn.service.impl;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

import javax.annotation.Resource;
import javax.persistence.NoResultException;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import co.com.ath.pgw.bsn.dto.in.AgreementSynchronizationInDTO;
import co.com.ath.pgw.bsn.dto.out.AgreementOutDTO;
import co.com.ath.pgw.bsn.service.AgreementSynchronizationService;
import co.com.ath.pgw.in.dto.AgreementSynchronizationRqType;
import co.com.ath.pgw.in.model.AgreementInfoType;
import co.com.ath.pgw.in.model.BankInfoType;
import co.com.ath.pgw.in.model.CompanyDetailType;
import co.com.ath.pgw.in.model.CompanyType;
import co.com.ath.pgw.in.model.IndicatorType;
import co.com.ath.pgw.in.model.PersonalDataType;
import co.com.ath.pgw.in.model.UserIdType;
import co.com.ath.pgw.in.model.ReferenceType;
import co.com.ath.pgw.persistence.dao.BankDAO;
import co.com.ath.pgw.persistence.dao.CollectionAccountDAO;
import co.com.ath.pgw.persistence.dao.CommerceDAO;
import co.com.ath.pgw.persistence.model.Bank;
import co.com.ath.pgw.persistence.model.CollectionAccount;
import co.com.ath.pgw.persistence.model.Commerce;
import co.com.ath.pgw.persistence.model.CommerceContact;
import co.com.ath.pgw.persistence.model.PaymentWayByCommerce;
import co.com.ath.pgw.persistence.procedure.model.CreacionConvenio;
import co.com.ath.pgw.persistence.procedure.model.NovedadConvenio;
import co.com.ath.pgw.rest.dto.AdditionalDepAcctId;
import co.com.ath.pgw.rest.dto.Agreement;
import co.com.ath.pgw.rest.dto.BankInfo;
import co.com.ath.pgw.rest.dto.ContactInfo;
import co.com.ath.pgw.rest.dto.DepAcctId;
import co.com.ath.pgw.rest.dto.GovIssueIdent;
import co.com.ath.pgw.rest.dto.Image;
import co.com.ath.pgw.rest.dto.LegalPerson;
import co.com.ath.pgw.rest.dto.PartnerInfo;
import co.com.ath.pgw.rest.dto.PersonInfo;
import co.com.ath.pgw.rest.dto.PersonName;
import co.com.ath.pgw.rest.dto.PhoneNum;
import co.com.ath.pgw.rest.dto.PmtInfo;
import co.com.ath.pgw.rest.dto.PostAddr;
import co.com.ath.pgw.rest.dto.RefInfo;
import co.com.ath.pgw.rest.dto.SecretList;
import co.com.ath.pgw.rest.request.dto.Header;
import co.com.ath.pgw.rest.request.dto.RequestAgrmSynch;
import co.com.ath.pgw.rest.response.dto.ResponseAgrmSynch;
import co.com.ath.pgw.util.constants.CoreConstants;
import co.com.ath.pgw.util.constants.PaymentWayCodes;
import co.com.ath.pgw.util.i18n.BundleKeys;
import co.com.ath.pgw.util.i18n.BundleType;
import co.com.ath.pgw.util.i18n.ResourceBundleManager;
import co.com.ath.pgw.util.validation.ValidationException;
import co.com.ath.pgw.util.validation.model.GetTransactionValidator;

/**
 * Implementación por defecto del servicio AgreementSynchronizationServiceImpl.
 * @version 0.0.0 05/11/2015
 * @author <proveedor_edrobles@ath.com.co>
 */
@Service
public class AgreementSynchronizationServiceImpl implements AgreementSynchronizationService {
	
	@Autowired
	private ResourceBundleManager bundleManager;
	
	@Resource
	private CommerceDAO commerceDAO;
	@Resource
	private CollectionAccountDAO collectionAccountDAO;
	@Resource
	private NovedadConvenio novedadconvenio;
	
	@Resource
	private CreacionConvenio creacionConvenio;
	
	@Resource
	private BankDAO bankDAO;
	
	@Resource
	private GetTransactionValidator getTransactionValidator;
	
	private Locale locale;
	
	private static Logger logger = LoggerFactory.getLogger(AgreementSynchronizationServiceImpl.class);
	
	public AgreementSynchronizationServiceImpl(){
		super();
		this.locale = Locale.getDefault();
	}
	
	@Override
	public AgreementOutDTO agrmntSynchAdm(AgreementSynchronizationInDTO agreementSynchronizationInDTO) {
		AgreementSynchronizationRqType agreementSynchronizationRqType = agreementSynchronizationInDTO.getAgreementSynchronizationRqType();
		String approvalId, trnServerStatusDesc;
		//Objeto de salida de información.
		AgreementOutDTO agreementOutDTO = new AgreementOutDTO();
		//Verifica si la operacion existe, si existe retorna el objeto error  
		if((agreementSynchronizationRqType.getAdmType().equals(CoreConstants.OPERACION_ENROLL)==false)&&(agreementSynchronizationRqType.getAdmType().equals(CoreConstants.OPERACION_MODIFY)==false )&&(agreementSynchronizationRqType.getAdmType().equals(CoreConstants.OPERACION_DELETE)==false)){			
			agreementOutDTO.setStatusCode(CoreConstants.ERROR_STATUS_CODE_600);
			agreementOutDTO.setStatusDesc(CoreConstants.ERROR_STATUS_CODE_DESC_600);
			agreementOutDTO.setTrnServerStatusCode(CoreConstants.ERROR_STATUS_CODE_600.toString());   
			trnServerStatusDesc = getMessage(BundleKeys.ERROR_INVALID_AGREEMENT_ID, null, locale,CoreConstants.ERRORS_BUNDLE);
			agreementOutDTO.setTrnServerStatusDesc(trnServerStatusDesc+agreementSynchronizationRqType.getAdmType());
			agreementOutDTO.setRqUID(agreementSynchronizationInDTO.getRqUID());
			agreementOutDTO.setApprovalId(null);
			return agreementOutDTO;
		} 
		
		Commerce commerce = agreementSynch(agreementSynchronizationInDTO);
		
		if(commerce == null) {
			approvalId = null;
			//Se verifica la operacion para sacar el mensaje q concuerda
			if(agreementSynchronizationRqType.getAdmType().equals(CoreConstants.OPERACION_ENROLL)) {
				trnServerStatusDesc = getMessage(BundleKeys.ERROR_SINCRONIZE_ENROLL, new Object[]{
						agreementSynchronizationRqType.getAdmType(),
						agreementSynchronizationRqType.getCompany().getCompanyId()}, locale,CoreConstants.ERRORS_BUNDLE);
				
			}else if (agreementSynchronizationRqType.getAdmType().equals(CoreConstants.OPERACION_MODIFY)) {
				trnServerStatusDesc = getMessage(BundleKeys.ERROR_SINCRONIZE_MODIFY, new Object[]{
						agreementSynchronizationRqType.getAdmType(),
						agreementSynchronizationRqType.getCompany().getCompanyId()}, locale,CoreConstants.ERRORS_BUNDLE);
			}else{ 
				trnServerStatusDesc = getMessage(BundleKeys.ERROR_SINCRONIZE_DELETE, new Object[]{
						agreementSynchronizationRqType.getAdmType(),
						agreementSynchronizationRqType.getCompany().getCompanyId()}, locale,CoreConstants.ERRORS_BUNDLE);
				}

			//trnServerStatusDesc = "Error en la operación "+ agreement.getAdmType() +", convenio CPV" + agreement.getCompany().getCompanyId()+".";
			agreementOutDTO.setStatusCode(CoreConstants.ERROR_STATUS_CODE_1260);
			agreementOutDTO.setStatusDesc(getMessage(BundleKeys.ERROR_UNKNOWN_ERROR, null, locale,CoreConstants.ERRORS_BUNDLE));
			agreementOutDTO.setTrnServerStatusCode(CoreConstants.ERROR_STATUS_CODE_1260.toString());
		} else {
			approvalId = commerce.getId().toString();
			trnServerStatusDesc = getMessage(BundleKeys.TRANSACTION_SUCCESS, null, locale,CoreConstants.MESSAGES_BUNDLE);
			agreementOutDTO.setStatusCode(CoreConstants.SUCCESS_STATUS_CODE);
			agreementOutDTO.setStatusDesc(getMessage(BundleKeys.TRANSACTION_SUCCESS, null, locale,CoreConstants.MESSAGES_BUNDLE));
			agreementOutDTO.setTrnServerStatusCode(CoreConstants.SUCCESS_STATUS_CODE.toString());
		}
		//Cargan los campos q siempre van a ir del objeto de salida	
		agreementOutDTO.setTrnServerStatusDesc(trnServerStatusDesc);
		agreementOutDTO.setRqUID(agreementSynchronizationInDTO.getRqUID());
		agreementOutDTO.setApprovalId(approvalId);
		return agreementOutDTO;
	}

	/**
	 * Obtiene los mensajes del bundle basado en la llave que llega por
	 * parámetro.
	 * 
	 * @param messageKey
	 *            Clave del mensaje.
	 * @param args
	 *            Argumentos dinamicos para el mensaje.
	 * @param locale
	 *            Localización.
	 * @return Mensaje de error formateado o la messageKey si la llave no fue
	 *         encontrada.
	 */
	private String getMessage(String messageKey, Object[] args, Locale locale, String typeBundle) {
		if (bundleManager == null) {
			return messageKey;
		}
		if(typeBundle.equals(CoreConstants.ERRORS_BUNDLE)) {
			bundleManager.setBundle(BundleType.ERRORS);
		}
		else {bundleManager.setBundle(BundleType.MESSAGES);}
		return bundleManager.getMessage(messageKey, args, locale);
	}
	
	private Commerce agreementSynch(AgreementSynchronizationInDTO agreementSynchronizationInDTO){
		
		Commerce commerce = null;
		
		AgreementInfoType agreementInfoType = null;
		BankInfoType bankInfoType = null;
		IndicatorType indicatorType = null;
		CompanyType companyType = null;
		CompanyDetailType companyDetailType = null;
		List<ReferenceType> referenceList;
		PersonalDataType personalDataType = null;
		UserIdType userIdType = null;
		String cuentarecaudo = "", codigoIncocredito = "", codigoTerminal = "", codigoAch = "";

		AgreementSynchronizationRqType agreementSynchronizationRqType = agreementSynchronizationInDTO.getAgreementSynchronizationRqType();		
		
		/*agreementInfoType*/
		
		if(agreementSynchronizationRqType.getAgreementInfo() != null) {
			agreementInfoType = agreementSynchronizationRqType.getAgreementInfo();
		}
		
		/*bankInfoType*/
		
		if(agreementSynchronizationRqType.getBankInfo() != null) {
			Bank bank;
			bank = bankDAO.findByAVALCode(agreementSynchronizationRqType.getBankInfo().getBankId());
			agreementSynchronizationRqType.getBankInfo().setBankId(bank.getId().toString());
			bankInfoType = agreementSynchronizationRqType.getBankInfo();
		}
		
		/*indicatorType*/
		
		if(agreementSynchronizationRqType.getIndicator() != null) {
			indicatorType = agreementSynchronizationRqType.getIndicator();
			//verifica el estado enviado en la trama y homologa con el que se debe enviar al procedimiento para el estado de los registros
			if (indicatorType.getState().equals(CoreConstants.STATE_INDICATOR_ON)){
				indicatorType.setState(CoreConstants.STATE_INDICATOR_OFF);
			}else {
				indicatorType.setState(CoreConstants.STATE_INDICATOR_ON);
			}
		}
		
		/*companyType*/
		
		if(agreementSynchronizationRqType.getCompany() != null) {
			companyType = agreementSynchronizationRqType.getCompany(); 
		}else{ // Correccion de hallazgo Fortify
			companyType = new CompanyType();
		}

		if(agreementSynchronizationRqType.getPmtId() == null || (agreementSynchronizationRqType.getPmtId().isEmpty())){
			agreementSynchronizationRqType.setPmtId("");
		}

		if(agreementSynchronizationRqType.getCategoryId() == null || (agreementSynchronizationRqType.getCategoryId().isEmpty())){
			agreementSynchronizationRqType.setCategoryId("");
		}
		
		/*companyDetail*/
		
		if(agreementSynchronizationRqType.getCompanyDetail() != null) {
			companyDetailType = agreementSynchronizationRqType.getCompanyDetail(); 
			//VALIDACIONES DE LOS CAMPOS
			if(companyDetailType.getCountryId() == null || (companyDetailType.getCountryId().isEmpty())){
				companyDetailType.setCountryId("");
			}
			if(companyDetailType.getEmailAddr() == null || (companyDetailType.getEmailAddr().isEmpty())){
				companyDetailType.setEmailAddr("");
			}
			if(companyDetailType.getExtensions() == null || (companyDetailType.getExtensions().isEmpty())){
				companyDetailType.setExtensions(CoreConstants.EXTENSION_EMPTY);
			}
		}else{
			// Correccion de hallazgo Fortify
			companyDetailType = new CompanyDetailType();
			companyDetailType.setCountryId("");
			companyDetailType.setEmailAddr("");
			companyDetailType.setExtensions(CoreConstants.EXTENSION_EMPTY);

		}
		
		/*personalData*/
		
		if(agreementSynchronizationRqType.getPersonalData() != null) {
			personalDataType = agreementSynchronizationRqType.getPersonalData(); 
			if(personalDataType.getEmailAddr() == null || (personalDataType.getEmailAddr().isEmpty())){
				personalDataType.setEmailAddr("");
			}
			if(personalDataType.getCellPhone() == null || (personalDataType.getCellPhone().isEmpty())){
				personalDataType.setCellPhone(CoreConstants.CELLPHONE_EMPTY);
			}
			if(personalDataType.getCustName().getLegalName() == null || (personalDataType.getCustName().getLegalName().isEmpty())){
				personalDataType.getCustName().setLegalName("");	
			}
		}else{
			// Correccion de hallazgo Fortify
			personalDataType = new PersonalDataType();
			personalDataType.setEmailAddr("");
			personalDataType.setCellPhone(CoreConstants.CELLPHONE_EMPTY);
			personalDataType.getCustName().setLegalName("");
		}
		
		/*personalData*/
		
		if(agreementSynchronizationRqType.getUserId() != null) {
			userIdType = agreementSynchronizationRqType.getUserId();
		}
		
		//reference
		
		if(agreementSynchronizationRqType.getReference().size() > 0) {
			referenceList = agreementSynchronizationRqType.getReference();
			for(int i=0; i<referenceList.size(); i++) {
				ReferenceType refType = referenceList.get(i);
				if(refType.getRefId().equals(CoreConstants.CUENTARECAUDO)) {
					cuentarecaudo = refType.getRefType() != null ? refType.getRefType() : "";
				}
				if(refType.getRefId().equals(CoreConstants.INCOCREDITO)) {
					codigoIncocredito = refType.getRefType() != null ? refType.getRefType() : "";
				}
				if(refType.getRefId().equals(CoreConstants.TERMINAL)) {
					codigoTerminal = refType.getRefType() != null ? refType.getRefType() : "";
				}
				if(refType.getRefId().equals(CoreConstants.ACH_SERVICECODE)) {
					codigoAch = refType.getRefType() != null ? refType.getRefType() : "";
				/**INICIO-C01**/			
					if(codigoAch != "")
						codigoAch = codigoAch.trim();
				/**FIN-C01**/
		
				}
			}
		}
		boolean start = false;
		try {
		
			//Modificación (Debe ser la primera operacion a revisar ya que Enroll la puede modificar)
			if(agreementSynchronizationRqType.getAdmType().equals(CoreConstants.OPERACION_MODIFY)) {
				commerce = commerceDAO.findByNura(CoreConstants.AGREEMENT_CPV+companyType.getCompanyId());
				if(commerce != null) {
					start = true;
				}
			}
			//Inserción
			if(agreementSynchronizationRqType.getAdmType().equals(CoreConstants.OPERACION_ENROLL)) {
			   commerce = commerceDAO.findByNura(CoreConstants.AGREEMENT_CPV+companyType.getCompanyId());
			   if(commerce != null) {
				   agreementSynchronizationRqType.setAdmType(CoreConstants.OPERACION_MODIFY);			
			   }
			   start = true;
			}
			//Eliminación Logica
			if(agreementSynchronizationRqType.getAdmType().equals(CoreConstants.OPERACION_DELETE)) {
				commerce = commerceDAO.findByNuraDeleted(CoreConstants.AGREEMENT_CPV+companyType.getCompanyId());
				if(commerce != null) {
					start = true;
				}
			}

			if(start) {
				novedadconvenio.setOperacion(agreementSynchronizationRqType.getAdmType());
				novedadconvenio.setEstado(indicatorType.getState());
				novedadconvenio.setCodigoEAN(agreementInfoType.getAgreementId());
				novedadconvenio.setCodigoNura(companyType.getCompanyId());
				novedadconvenio.setCodigoIncocredito(codigoIncocredito);
				novedadconvenio.setCodigoAch(codigoAch);
				novedadconvenio.setCodigoHomologaBAVV(agreementSynchronizationRqType.getTrnChannel());
				novedadconvenio.setCodigoTerminal(codigoAch);
				novedadconvenio.setIdActEcnomica(agreementSynchronizationRqType.getCategoryId());
				//SUBSCRIPCION
				novedadconvenio.setIdBanco(bankInfoType.getBankId());
				novedadconvenio.setIdMunicipio(companyDetailType.getCityId());
				novedadconvenio.setRazonSocial(agreementInfoType.getName());
				novedadconvenio.setDireccion(companyDetailType.getAddress());
				novedadconvenio.setTelefono(companyDetailType.getPhone());
				novedadconvenio.setEmail(companyDetailType.getEmailAddr());
				novedadconvenio.setExtension(companyDetailType.getExtensions());
				//CONTACTOSCOMERCIO
				novedadconvenio.setRepLegal(personalDataType.getCustName().getLegalName());
				novedadconvenio.setEmailCont(personalDataType.getEmailAddr());
				novedadconvenio.setTelCont(personalDataType.getCellPhone());			
				
				commerce=commerceDAO.agreementSynchronization(novedadconvenio);
			}	
		}catch (Exception e) {
			logger.error("Error en agreementSynch: ", e);
			return null;
		}
	
		return commerce;
	}

	
	@Override
	public ResponseAgrmSynch agrmntFindAdm(String agrmId, Header header) {
//		AgreementOutDTO outDTO = new AgreementOutDTO();
		
		Commerce commerce=null;
		if (agrmId.toUpperCase().startsWith("C") && !agrmId.toUpperCase().startsWith("CPV")) {
			
				 commerce = commerceDAO.findByNura(agrmId);
				 if (commerce== null) {
					 agrmId=agrmId.replaceFirst("C","CPV");
					 commerce = commerceDAO.findByNura(agrmId);
				 }			
		}
		else{
			 commerce = commerceDAO.findByNura(agrmId);
		}
		
		ResponseAgrmSynch responseAgrmSynch =new ResponseAgrmSynch();
//		try {
//            getTransactionValidator.validateAgreement(agrmId);
//        } catch (ValidationException ex){
//        	responseAgrmSynch.setStatusCode(CoreConstants.ERROR_DATA_VALIDATION_CODE);
//        	responseAgrmSynch.setStatusDesc(ex.getMessage());
//        	responseAgrmSynch.setTrnServerStatusCode(String.valueOf(ex.getErrorCode()));
//            if (ex.getCause() != null){
//            	responseAgrmSynch.setTrnServerStatusDesc(ex.getCause().getMessage());
//    		} else {
//    			responseAgrmSynch.setTrnServerStatusDesc(ex.getMessage());
//    		}
//            return responseAgrmSynch;
//        }
		

					
		Agreement agreement= new Agreement();
		agreement.setAgrmId(commerce.getNuraCode());
		agreement.setNit(String.valueOf(commerce.getNit()));
		agreement.setCategCode(commerce.getIdEconomicActivity());
		agreement.setAgrmVfrCode(String.valueOf(commerce.getSubscription().getCheckDigit()));
		agreement.setName(commerce.getSubscription().getCompanyName());
		Image image = new Image();
		image.setUrl(commerce.getConfiguration().getResponseURL());
		agreement.setImage(image);
		
		ContactInfo contactInfo = new ContactInfo();
		contactInfo.setEmailAddr(commerce.getSubscription().getEmail());

		List<PhoneNum>  phoneNumList=new ArrayList<PhoneNum>();
		PhoneNum phoneNumFax =new PhoneNum();
		phoneNumFax.setPhoneType(CoreConstants.REFERENCE_TYPEFAX);
		phoneNumFax.setPhone(commerce.getSubscription().getFax());
		phoneNumList.add(phoneNumFax);
		PhoneNum phoneNumCel =new PhoneNum();
		phoneNumCel.setPhoneType(CoreConstants.REFERENCE_TYPECEL);
		phoneNumCel.setPhone(commerce.getSubscription().getPhone());
		phoneNumList.add(phoneNumCel);
		PostAddr postAddr = new PostAddr(); 
		postAddr.setAddr1(commerce.getSubscription().getAddress());
		postAddr.setCity(String.valueOf(commerce.getSubscription().getCity().getId()));
		postAddr.setStateProv(String.valueOf(commerce.getSubscription().getCity().getDepartament().getId()));
		contactInfo.setPhoneNum(phoneNumList);
		contactInfo.setPostAddr(postAddr);
		agreement.setContactInfo(contactInfo);
		DepAcctId depAcctId= new DepAcctId();
		depAcctId.setAcctType(String.valueOf(commerce.getPaymentWayByCommerce().get(0).getAsobancariaTipoCuenta()));
		depAcctId.setAcctKey(String.valueOf(commerce.getPaymentWayByCommerce().get(0).getAuthorizedAccount()));
		depAcctId.setDesc(String.valueOf(commerce.getPaymentWayByCommerce().get(0).getAsobancariaTipoRecaudo()));
		agreement.setDepAcctId(depAcctId);
		responseAgrmSynch.setAgreement(agreement);
		LegalPerson legalPerson =new LegalPerson();
		GovIssueIdent govIssueIdent= new GovIssueIdent();
		PersonName personName = new PersonName();
		govIssueIdent.setGovIssueIdentType(commerce.getSubscription().getLegalAgentType());
		govIssueIdent.setIdentSerialNum(commerce.getSubscription().getLegalAgentId());
		legalPerson.setGovIssueIdent(govIssueIdent);

		personName.setLastName(commerce.getSubscription().getLegalAgentLastName());
		personName.setFirstName(commerce.getSubscription().getLegalAgent());
		personName.setLegalName(commerce.getSubscription().getLegalAgent()+" "+commerce.getSubscription().getLegalAgentLastName());
		legalPerson.setPersonName(personName);
		responseAgrmSynch.setLegalPerson(legalPerson);
		List<RefInfo> refInfoList= new ArrayList<RefInfo>();
		RefInfo refInfo= new RefInfo();
		refInfo.setRefType(CoreConstants.INCOCREDITO);
		refInfo.setRefId(commerce.getIncocreditoCode());		
		refInfoList.add(refInfo);
		
		RefInfo refInfoTerminal= new RefInfo();
		refInfoTerminal.setRefType(CoreConstants.TERMINAL);
		refInfoTerminal.setRefId(commerce.getTerminalCode());
		refInfoList.add(refInfoTerminal);
		
		
		RefInfo refInfoAppCodeRBM= new RefInfo();
		refInfoAppCodeRBM.setRefType("appCodeRBM");
		refInfoAppCodeRBM.setRefId(commerce.getCodigoAppRbm());
		refInfoList.add(refInfoAppCodeRBM);
		RefInfo refInfoAppKeyRBM= new RefInfo();
		refInfoAppKeyRBM.setRefType("appKeyRBM");
		refInfoAppKeyRBM.setRefId(commerce.getKeyRbm());
		refInfoList.add(refInfoAppKeyRBM);
		
		
		
		RefInfo refInfoACH= new RefInfo();
		refInfoACH.setRefType(CoreConstants.REFERENCE_CODACH);
		refInfoACH.setRefId(commerce.getAchCode());
		refInfoList.add(refInfoACH);
		
		RefInfo refInfoAgregador= new RefInfo();
		refInfoAgregador.setRefType(CoreConstants.REFERENCE_AGREGADOR);
		refInfoAgregador.setRefId(String.valueOf(commerce.getAggregator()));
		refInfoList.add(refInfoAgregador);
		
		RefInfo refInfoZip= new RefInfo();
		refInfoZip.setRefType(CoreConstants.REFERENCE_ZIPASOBANCARIA);
		refInfoZip.setRefId(String.valueOf(commerce.getZipasobancaria()));
		refInfoList.add(refInfoZip);
		
		RefInfo refInfoHomologation= new RefInfo();
		refInfoHomologation.setRefType(CoreConstants.REFERENCE_BAVVCODE);
		refInfoHomologation.setRefId(commerce.getHomologationBAVVCode());
		refInfoList.add(refInfoHomologation);
		
		RefInfo refInfoEAN= new RefInfo();
		refInfoEAN.setRefType(CoreConstants.REFERENCE_CODEAN);
		refInfoEAN.setRefId(commerce.getEanCode());
		refInfoList.add(refInfoEAN);
		
		RefInfo refInfoTC= new RefInfo();
		refInfoTC.setRefType(CoreConstants.REFERENCE_TC);
		refInfoTC.setRefId(commerce.getCreditCardInd());
		refInfoList.add(refInfoTC);
		
		RefInfo refInfoPlantilla= new RefInfo();
		refInfoPlantilla.setRefType(CoreConstants.REFERENCE_PLANTILLA);
		refInfoPlantilla.setRefId(String.valueOf(commerce.getConfiguration().getTemplate().getId()));
		refInfoList.add(refInfoPlantilla);
		
		RefInfo refInfoTema= new RefInfo();
		refInfoTema.setRefType(CoreConstants.REFERENCE_TEMA);
		refInfoTema.setRefId(String.valueOf(commerce.getConfiguration().getTheme()));
		refInfoList.add(refInfoTema);
		
		RefInfo refInfoLogo= new RefInfo();
		refInfoLogo.setRefType(CoreConstants.REFERENCE_LOGO);
		refInfoLogo.setRefId(commerce.getConfiguration().getLogo());
		refInfoList.add(refInfoLogo);
		
		RefInfo refInfoUrlconfirmacion= new RefInfo();
		refInfoUrlconfirmacion.setRefType(CoreConstants.REFERENCE_URLCONFIRMACION);
		refInfoUrlconfirmacion.setRefId(commerce.getConfiguration().getConfirmationURL());
		refInfoList.add(refInfoUrlconfirmacion);
	
		
		RefInfo refInfoRutacertificado= new RefInfo();
		refInfoRutacertificado.setRefType(CoreConstants.REFERENCE_RUTACERTIFICADO);
		refInfoRutacertificado.setRefId(commerce.getConfiguration().getCertificatePath());
		refInfoList.add(refInfoRutacertificado);
		
		RefInfo refInfoNofact= new RefInfo();
		refInfoNofact.setRefType(CoreConstants.REFERENCE_NOFACTMULTIREF);
		refInfoNofact.setRefId(String.valueOf(commerce.getConfiguration().getNoFactMultipleRef()));
		refInfoList.add(refInfoNofact);
		
		RefInfo refInfoArchivorecaudo= new RefInfo();
		refInfoArchivorecaudo.setRefType(CoreConstants.REFERENCE_ARCHIVORECAUDO);
		refInfoArchivorecaudo.setRefId(commerce.getConfiguration().getNombreArchivo());
		refInfoList.add(refInfoArchivorecaudo);
		
		RefInfo refInfoTiposervicio= new RefInfo();
		refInfoTiposervicio.setRefType(CoreConstants.REFERENCE_TIPODESERVICIO);
		refInfoTiposervicio.setRefId(commerce.getConfiguration().getTipoDeServicio());
		refInfoList.add(refInfoTiposervicio);
		
		RefInfo refInfoTipoAdministrador= new RefInfo();
		refInfoTipoAdministrador.setRefType(CoreConstants.REFERENCE_TIPOADMINISTRADOR);
		refInfoTipoAdministrador.setRefId(commerce.getConfiguration().getTipoAdministrador());
		refInfoList.add(refInfoTipoAdministrador);
		
		responseAgrmSynch.setRefInfo(refInfoList);
		BankInfo bankInfo = new BankInfo();
		bankInfo.setBankId(String.valueOf(commerce.getSubscription().getBank().getId()));
		bankInfo.setName(commerce.getSubscription().getBank().getName());
		responseAgrmSynch.setBankInfo(bankInfo);
		SecretList secret = new SecretList ();
		List<SecretList> secretList =new ArrayList<SecretList>();       
        secret.setSecret(commerce.getConfiguration().getPhrase());
        secret.setSecretId(commerce.getConfiguration().getUser());
        secretList.add(secret);
        responseAgrmSynch.setSecretList(secretList);
        Boolean  esPSE=false;
        List<PmtInfo> pmtInfoList = new ArrayList<PmtInfo>();
        for (PaymentWayByCommerce mp : commerce.getPaymentWayByCommerce()) {
 		PmtInfo pmtInfo = new PmtInfo();
        pmtInfo.setPmtInfoDesc(mp.getPaymentWay().getName());
        pmtInfo.setPmtInfoId(String.valueOf(mp.getPaymentWay().getId()));
        pmtInfoList.add(pmtInfo);
        if(mp.getPaymentWay().getId().equals(PaymentWayCodes.PSE)) {
        	esPSE=true;
        }
        }	
        responseAgrmSynch.setPmtInfo(pmtInfoList);
        if(esPSE && commerce.getAggregator() ) {
        List<CollectionAccount> collectionAccount=collectionAccountDAO.getByCommerce(commerce.getId(), PaymentWayCodes.PSE);
        
        List<AdditionalDepAcctId> additionalDepAcctIdList = new ArrayList<AdditionalDepAcctId>();
        for (CollectionAccount item : collectionAccount) {
     		DepAcctId depAcctIdCollection = new DepAcctId();
     		BankInfo bankInfoCollection = new BankInfo();
     		RefInfo refInfoCollection = new RefInfo();
     		AdditionalDepAcctId additionalDepAcctId=new AdditionalDepAcctId();
     		depAcctIdCollection.setAcctKey(item.getCuentaAsociada());
     		bankInfoCollection.setBankId(Long.toString(item.getBank().getId()));
     		bankInfoCollection.setName(item.getBank().getName());
     		refInfoCollection.setRefId(item.getCodigoServicio());
     		refInfoCollection.setRefType(CoreConstants.REFERENCE_AGREGADOR);
     		additionalDepAcctId.setBankInfo(bankInfoCollection);
     		additionalDepAcctId.setDepAcctId(depAcctIdCollection);
     		additionalDepAcctId.setRefInfo(refInfoCollection);
     		additionalDepAcctIdList.add(additionalDepAcctId);
            }	
        responseAgrmSynch.setAdditionalDepAcctId(additionalDepAcctIdList);
        }
		List<PartnerInfo> partnerInfoList = new ArrayList<>();

		for (CommerceContact commerceContact : commerce.getCommerceContact()) {
			PartnerInfo partnerInfo =new PartnerInfo();
			PersonInfo personInfoC = new PersonInfo() ; 
			ContactInfo contactInfoC= new ContactInfo();
			PhoneNum phoneNumC= new PhoneNum();
			PersonName personNameC = new PersonName();
			GovIssueIdent govIssueIdentC = new GovIssueIdent();
			
			contactInfoC.setEmailAddr(commerceContact.getEmail());
			partnerInfo.setPartnerType( String.valueOf(commerceContact.getRole().getId()));

			List<PhoneNum> phonNumListC =new ArrayList<PhoneNum>();
			phoneNumC.setPhoneType(CoreConstants.REFERENCE_TYPECEL);
            phoneNumC.setPhone(commerceContact.getMobilePhone());
            phonNumListC.add(phoneNumC);
            contactInfoC.setPhoneNum(phonNumListC);
            personNameC.setLegalName(commerceContact.getName() + " "+commerceContact.getApellido());
            personNameC.setFirstName(commerceContact.getName());
            personNameC.setLastName(commerceContact.getApellido());
            govIssueIdentC.setGovIssueIdentType(commerceContact.getTipodocumento());
            govIssueIdentC.setIdentSerialNum(commerceContact.getNumerodocumento());

			personInfoC.setPersonName(personNameC);
			personInfoC.setGovIssueIdent(govIssueIdentC);
			partnerInfo.setPersonInfo(personInfoC);
			partnerInfo.setContactInfo(contactInfoC);
			
			partnerInfoList.add(partnerInfo);
			
		}
		responseAgrmSynch.setPartnerInfo(partnerInfoList);
		responseAgrmSynch.setApprovalId(commerce.getId().toString());
		responseAgrmSynch.setStatusCode(CoreConstants.SUCCESS_STATUS_CODE);
		return responseAgrmSynch;
	}
	@Override
	public AgreementOutDTO agrmntCreateAdm(RequestAgrmSynch requestAgrmSynch, Header header) {
		
		logger.info("Entro en el metodo agrmntCreateAdm");
		AgreementOutDTO agreementOutDTO = new AgreementOutDTO();
		Commerce commerce = commerceDAO.findByNura(requestAgrmSynch.getAgreement().getAgrmId());
		String approvalId=null, trnServerStatusDesc=null,codigoIncocredito=null;
		if(commerce != null) {
			agreementOutDTO.setStatusCode(CoreConstants.ERROR_STATUS_CODE_600);
			agreementOutDTO.setStatusDesc(CoreConstants.ERROR_STATUS_CODE_DESC_600);
			agreementOutDTO.setTrnServerStatusCode(CoreConstants.ERROR_STATUS_CODE_600.toString());       
			trnServerStatusDesc=getMessage(BundleKeys.ERROR_ALREADY_AGREEMENT_ID, new Object[]{
					requestAgrmSynch.getAgreement().getAgrmId()}, locale,CoreConstants.ERRORS_BUNDLE);
			agreementOutDTO.setTrnServerStatusDesc(trnServerStatusDesc);
			agreementOutDTO.setApprovalId(null);
			agreementOutDTO.setRqUID(header.getRqUID());
			return agreementOutDTO;
		}
		
		try{
			if(requestAgrmSynch.getPmtInfo()!=null && !requestAgrmSynch.getPmtInfo().isEmpty()) {
				for(PmtInfo pmtInfo : requestAgrmSynch.getPmtInfo()) {
				if(pmtInfo.getPmtInfoType().equals("2")) {
					//Se Valida si el codigo incocredito es valido
					for(RefInfo refInfoRq :requestAgrmSynch.getRefInfo()) {
						if(refInfoRq.getRefId().equals(CoreConstants.REFERENCE_INCOCREDITO)) {
							codigoIncocredito = refInfoRq.getRefType();
					if(validarIncocredito(codigoIncocredito, requestAgrmSynch.getAgreement().getNit())) {
						agreementOutDTO.setStatusCode(CoreConstants.ERROR_STATUS_COD_AGREEMENTINCOCREDITO);
						agreementOutDTO.setStatusDesc(CoreConstants.ERROR_STATUS_DESC_AGREEMENTINCOCREDITO);
						agreementOutDTO.setTrnServerStatusCode(CoreConstants.ERROR_STATUS_COD_AGREEMENTINCOCREDITO.toString()); 
						trnServerStatusDesc = getMessage(BundleKeys.ERROR_INVALID_INCOCREDITO , new Object[]{codigoIncocredito},
								locale, CoreConstants.ERRORS_BUNDLE);
						agreementOutDTO.setTrnServerStatusDesc(trnServerStatusDesc);
						agreementOutDTO.setApprovalId(null);
						agreementOutDTO.setRqUID(header.getRqUID());
						return agreementOutDTO;
					}}}
					//Se Valida si el codigo terminal es valido
					for(RefInfo refInfoRqT :requestAgrmSynch.getRefInfo()) {
						if(refInfoRqT.getRefId().equals(CoreConstants.REFERENCE_TERMINAL)) {
							if(validarTerminal(codigoIncocredito,refInfoRqT.getRefType(), requestAgrmSynch.getAgreement().getNit())) {
								agreementOutDTO.setStatusCode(CoreConstants.ERROR_STATUS_COD_AGREEMENTTERMINAL);
								agreementOutDTO.setStatusDesc(CoreConstants.ERROR_STATUS_DESC_AGREEMENTTERMINAL);
								agreementOutDTO.setTrnServerStatusCode(CoreConstants.ERROR_STATUS_COD_AGREEMENTTERMINAL.toString()); 
								trnServerStatusDesc = getMessage(BundleKeys.ERROR_INVALID_TERMINAL, new Object[]{refInfoRqT.getRefId()},
										locale, CoreConstants.ERRORS_BUNDLE);
								agreementOutDTO.setTrnServerStatusDesc(trnServerStatusDesc);
								agreementOutDTO.setApprovalId(null);
								agreementOutDTO.setRqUID(header.getRqUID());
								return agreementOutDTO;
							}}}
				}}}
			creacionConvenio.setOperacion(CoreConstants.CREATE_OPERATION);
			creacionConvenio.setCodigoNura(requestAgrmSynch.getAgreement().getAgrmId());
			creacionConvenio.setNit(requestAgrmSynch.getAgreement().getNit());
			
			for(RefInfo refInfoRq :requestAgrmSynch.getRefInfo()) {
				if(refInfoRq.getRefId().equalsIgnoreCase(CoreConstants.REFERENCE_CODEAN)) { 
					creacionConvenio.setCodigoEan(refInfoRq.getRefType());			
				}else if(refInfoRq.getRefId().equalsIgnoreCase(CoreConstants.REFERENCE_CODACH)) {			
					creacionConvenio.setCodigoAch(refInfoRq.getRefType());
				}else if(refInfoRq.getRefId().equalsIgnoreCase(CoreConstants.REFERENCE_AGREGADOR)) {			
					creacionConvenio.setAgregador(refInfoRq.getRefType());
				}else if(refInfoRq.getRefId().equalsIgnoreCase(CoreConstants.REFERENCE_INCOCREDITO)) {			
					creacionConvenio.setCodigoIncocredito(refInfoRq.getRefType());
				}else if(refInfoRq.getRefId().equalsIgnoreCase(CoreConstants.REFERENCE_TERMINAL)) {			
					creacionConvenio.setCodigoTerminal(refInfoRq.getRefType());
				}else if(refInfoRq.getRefId().equalsIgnoreCase(CoreConstants.REFERENCE_TC)) {			
					creacionConvenio.setTarjetaCredito(refInfoRq.getRefType());
				}else if(refInfoRq.getRefId().equalsIgnoreCase(CoreConstants.REFERENCE_TEMA)) {			
					creacionConvenio.setTema(refInfoRq.getRefType());
				}else if(refInfoRq.getRefId().equalsIgnoreCase(CoreConstants.REFERENCE_PLANTILLA)) {			
					creacionConvenio.setPlantilla(refInfoRq.getRefType());
				}else if(refInfoRq.getRefId().equalsIgnoreCase(CoreConstants.REFERENCE_LOGO)) {			
					creacionConvenio.setLogo(refInfoRq.getRefType());
				}else if(refInfoRq.getRefId().equalsIgnoreCase(CoreConstants.REFERENCE_URLCONFIRMACION)) {			
					creacionConvenio.setUrlConfirmacion(refInfoRq.getRefType());
				}else if(refInfoRq.getRefId().equalsIgnoreCase(CoreConstants.REFERENCE_RUTACERTIFICADO)) {			
					creacionConvenio.setRutaCertificado(refInfoRq.getRefType());
				}else if(refInfoRq.getRefId().equalsIgnoreCase(CoreConstants.REFERENCE_ESTADO)) {			
					creacionConvenio.setEstado(refInfoRq.getRefType());
				}else if(refInfoRq.getRefId().equalsIgnoreCase(CoreConstants.REFERENCE_GENDER)) {			
					creacionConvenio.setGender(refInfoRq.getRefType());
				}else if(refInfoRq.getRefId().equalsIgnoreCase(CoreConstants.REFERENCE_TIPODESERVICIO)) {			
					creacionConvenio.setTipoServicio(refInfoRq.getRefType());
				}else if(refInfoRq.getRefId().equalsIgnoreCase(CoreConstants.REFERENCE_NOFACTMULTIREF)) {			
					creacionConvenio.setNoFactMultipleRef(refInfoRq.getRefType());
				}else if(refInfoRq.getRefId().equalsIgnoreCase(CoreConstants.REFERENCE_TIPOADMINISTRADOR)) {			
					creacionConvenio.setTipoAdministrador(refInfoRq.getRefType());
				} else if (refInfoRq.getRefId().equalsIgnoreCase("appCodeRBM")) {
					creacionConvenio.setCodigoGlobalPay(refInfoRq.getRefType());
				} else if (refInfoRq.getRefId().equalsIgnoreCase("appKeyRBM")) {
					creacionConvenio.setLlaveGlobalPay(refInfoRq.getRefType());
				}
				else {
				ReferenceType referenceType = new ReferenceType();
				referenceType.setRefId(refInfoRq.getRefId());
				referenceType.setRefType(refInfoRq.getRefType());
				}
			
			}
			creacionConvenio.setIdActEcnomica(requestAgrmSynch.getAgreement().getCategCode());
			creacionConvenio.setIdMunicipio(requestAgrmSynch.getAgreement().getContactInfo().getPostAddr().getCity());
			creacionConvenio.setIdBanco(requestAgrmSynch.getBankInfo().getBankId());
			creacionConvenio.setRazonSocial(requestAgrmSynch.getAgreement().getName());
			creacionConvenio.setDigitoVerificacion(requestAgrmSynch.getAgreement().getAgrmVfrCode());
			creacionConvenio.setDireccion(requestAgrmSynch.getAgreement().getContactInfo().getPostAddr().getAddr1());
			for(PhoneNum phoneNum :requestAgrmSynch.getAgreement().getContactInfo().getPhoneNum()) {
				if(phoneNum.getPhoneType().equalsIgnoreCase(CoreConstants.TYPE_FAX)) {
					creacionConvenio.setFax("");
					creacionConvenio.setTelefono(phoneNum.getPhone());
				}else
				creacionConvenio.setTelefono(phoneNum.getPhone());
			}
			creacionConvenio.setEmail(requestAgrmSynch.getAgreement().getContactInfo().getEmailAddr());
			creacionConvenio.setApeRepLegal(requestAgrmSynch.getLegalPerson().getPersonName().getLastName());
			creacionConvenio.setRepLegal(requestAgrmSynch.getLegalPerson().getPersonName().getFirstName());
			creacionConvenio.setNumDocRL(requestAgrmSynch.getLegalPerson().getGovIssueIdent().getIdentSerialNum());
			creacionConvenio.setTipoDocRL(requestAgrmSynch.getLegalPerson().getGovIssueIdent().getGovIssueIdentType());
			
			for(SecretList secretList :requestAgrmSynch.getSecretList()) {
				creacionConvenio.setUsuario(secretList.getSecretId());
				creacionConvenio.setContrasena(secretList.getSecret());
			}
			Boolean  esPSE=false;
			creacionConvenio.setUrlRespuesta(requestAgrmSynch.getAgreement().getImage().getUrl());
			String idMedioPago="";
			for(PmtInfo pmtInfo : requestAgrmSynch.getPmtInfo()) {
				idMedioPago = idMedioPago+pmtInfo.getPmtInfoType()+",";	
				if(pmtInfo.getPmtInfoType().equalsIgnoreCase(Long.toString(PaymentWayCodes.PSE))) {
					esPSE=true;
				}
			}
			
			creacionConvenio.setIdMedioPago(idMedioPago);
			creacionConvenio.setCuentaAsociada(requestAgrmSynch.getAgreement().getDepAcctId().getAcctKey());
			creacionConvenio.setTipoCuenta(requestAgrmSynch.getAgreement().getDepAcctId().getAcctType());
			creacionConvenio.setDescTipoCuenta(requestAgrmSynch.getAgreement().getDepAcctId().getDesc());
			String codigoAchCuentaRecaudo="";
			String idBancoCuentaRecaudo="";
			String cuentaRecaudoAsociada="";
			if(esPSE && creacionConvenio.getAgregador().equals("1"))  {
			for(AdditionalDepAcctId additionalDepAcctId : requestAgrmSynch.getAdditionalDepAcctId()) {
				codigoAchCuentaRecaudo = codigoAchCuentaRecaudo+additionalDepAcctId.getRefInfo().getRefType()+",";
				idBancoCuentaRecaudo = idBancoCuentaRecaudo+additionalDepAcctId.getBankInfo().getBankId()+",";	
				cuentaRecaudoAsociada = cuentaRecaudoAsociada+additionalDepAcctId.getDepAcctId().getAcctKey()+",";
			}
			}
			
			
			creacionConvenio.setCodigoAchCuentaRecaudo(codigoAchCuentaRecaudo);
			creacionConvenio.setIdBancoCuentaRecaudo(idBancoCuentaRecaudo);
			creacionConvenio.setCuentaRecaudoAsociada(cuentaRecaudoAsociada);
			
			String idRol="";

			for(PartnerInfo partnerInfo: requestAgrmSynch.getPartnerInfo()) {
				idRol = idRol+partnerInfo.getPartnerType()+",";
				if(partnerInfo.getPartnerType().equals(CoreConstants.ROL_COMERCIAL)) {
					creacionConvenio.setNombreComercial(partnerInfo.getPersonInfo().getPersonName().getFirstName());
					creacionConvenio.setApellidoComercial(partnerInfo.getPersonInfo().getPersonName().getLastName());
					creacionConvenio.setNumDocComercial(partnerInfo.getPersonInfo().getGovIssueIdent().getIdentSerialNum());
					creacionConvenio.setTipoDocContComercial(partnerInfo.getPersonInfo().getGovIssueIdent().getGovIssueIdentType());
					creacionConvenio.setEmailContComercial(partnerInfo.getContactInfo().getEmailAddr());
					for(PhoneNum phonetype : partnerInfo.getContactInfo().getPhoneNum()) {
						creacionConvenio.setTelContComercial(phonetype.getPhone());			
					}
				}else if(partnerInfo.getPartnerType().equals(CoreConstants.ROL_TECNICO)){
					creacionConvenio.setNombreTecnico(partnerInfo.getPersonInfo().getPersonName().getFirstName());
					creacionConvenio.setApellidoTecnico(partnerInfo.getPersonInfo().getPersonName().getLastName());
					creacionConvenio.setNumDocTecnico(partnerInfo.getPersonInfo().getGovIssueIdent().getIdentSerialNum());
					creacionConvenio.setTipoDocContTecnico(partnerInfo.getPersonInfo().getGovIssueIdent().getGovIssueIdentType());
					creacionConvenio.setEmailContTecnico(partnerInfo.getContactInfo().getEmailAddr());
					for(PhoneNum phonetype : partnerInfo.getContactInfo().getPhoneNum()) {
						creacionConvenio.setTelContTecnico(phonetype.getPhone());			
					}
				}else if(partnerInfo.getPartnerType().equals(CoreConstants.ROL_OPERATIVO)) {
					creacionConvenio.setNombreOperativo(partnerInfo.getPersonInfo().getPersonName().getFirstName());
					creacionConvenio.setApellidoOperativo(partnerInfo.getPersonInfo().getPersonName().getLastName());
					creacionConvenio.setNumDocOperativo(partnerInfo.getPersonInfo().getGovIssueIdent().getIdentSerialNum());
					creacionConvenio.setTipoDocContOperativo(partnerInfo.getPersonInfo().getGovIssueIdent().getGovIssueIdentType());
					creacionConvenio.setEmailContOperativo(partnerInfo.getContactInfo().getEmailAddr());
					for(PhoneNum phonetype : partnerInfo.getContactInfo().getPhoneNum()) {
						creacionConvenio.setTelContOperativo(phonetype.getPhone());			
					}
				}
				
				
			}
			
			creacionConvenio.setIdRol(idRol);

			creacionConvenio.setRegEliminado(CoreConstants.REGELIMINADO_CREATE);
			

			commerce=commerceDAO.agreementCreate(creacionConvenio);
		}catch(Exception e) {
			logger.error("Error en agreementCreate: ", e);
			return null;
			
		}
		if(commerce == null) {

			agreementOutDTO.setStatusCode(CoreConstants.ERROR_STATUS_COD_AGREEMENT);
			agreementOutDTO.setStatusDesc(getMessage(BundleKeys.ERROR_INVALID_AGREEMENT_ID, null, locale,CoreConstants.ERRORS_BUNDLE));
			agreementOutDTO.setTrnServerStatusCode(CoreConstants.ERROR_STATUS_COD_AGREEMENT.toString());
		} else {
			approvalId = commerce.getId().toString();
			trnServerStatusDesc = getMessage(BundleKeys.TRANSACTION_SUCCESS, null, locale,CoreConstants.MESSAGES_BUNDLE);
			agreementOutDTO.setStatusCode(CoreConstants.SUCCESS_STATUS_CODE);
			agreementOutDTO.setStatusDesc(getMessage(BundleKeys.TRANSACTION_SUCCESS, null, locale,CoreConstants.MESSAGES_BUNDLE));
			agreementOutDTO.setTrnServerStatusCode(CoreConstants.SUCCESS_STATUS_CODE.toString());
		}
		agreementOutDTO.setTrnServerStatusDesc(trnServerStatusDesc);
		agreementOutDTO.setRqUID(header.getRqUID());
		agreementOutDTO.setApprovalId(approvalId);
		
		return agreementOutDTO;
	}
	
	@Override
	public AgreementOutDTO agrmntModifyAdm(RequestAgrmSynch requestAgrmSynch, Header header, String operacion) {
		AgreementOutDTO agreementOutDTO = new AgreementOutDTO();
		Commerce	commerce =null;
		if (requestAgrmSynch.getAgreement().getAgrmId().toUpperCase().startsWith("C") && !requestAgrmSynch.getAgreement().getAgrmId().toUpperCase().startsWith("CPV")) {
			
			 commerce = commerceDAO.findByNura(requestAgrmSynch.getAgreement().getAgrmId());
			 if (commerce== null) {
				 requestAgrmSynch.getAgreement().setAgrmId(requestAgrmSynch.getAgreement().getAgrmId().replaceFirst("C","CPV"));
				 commerce = commerceDAO.findByNura(requestAgrmSynch.getAgreement().getAgrmId());
			 }			
	}
	else{
		 commerce = commerceDAO.findByNura(requestAgrmSynch.getAgreement().getAgrmId());
	}
		String approvalId=null, trnServerStatusDesc=null ,codigoIncocredito=null;
	
		logger.info("Info comercio: "+ commerce);
		
		if(commerce == null) {
			agreementOutDTO.setStatusCode(CoreConstants.ERROR_STATUS_CODE_600);
			agreementOutDTO.setStatusDesc(CoreConstants.ERROR_STATUS_CODE_DESC_600);
			agreementOutDTO.setTrnServerStatusCode(CoreConstants.ERROR_STATUS_CODE_600.toString()); 
			trnServerStatusDesc = getMessage(BundleKeys.ERROR_NOTFOUND, new Object[]{
					requestAgrmSynch.getAgreement().getAgrmId()}, locale, CoreConstants.ERRORS_BUNDLE);
			agreementOutDTO.setTrnServerStatusDesc(trnServerStatusDesc);
			agreementOutDTO.setApprovalId(null);
			agreementOutDTO.setRqUID(header.getRqUID());
			return agreementOutDTO;
		}
		
		
		
		try{
			if(requestAgrmSynch.getPmtInfo()!=null && !requestAgrmSynch.getPmtInfo().isEmpty()) {
				for(PmtInfo pmtInfo : requestAgrmSynch.getPmtInfo()) {
				if(pmtInfo.getPmtInfoType().equals("2")) {
					//Se Valida si el codigo incocredito es valido
					for(RefInfo refInfoRq :requestAgrmSynch.getRefInfo()) {
						if(refInfoRq.getRefId().equals(CoreConstants.REFERENCE_INCOCREDITO)) {
							codigoIncocredito = refInfoRq.getRefType();
					if(validarIncocredito(codigoIncocredito, requestAgrmSynch.getAgreement().getNit())) {
						agreementOutDTO.setStatusCode(CoreConstants.ERROR_STATUS_COD_AGREEMENTINCOCREDITO);
						agreementOutDTO.setStatusDesc(CoreConstants.ERROR_STATUS_DESC_AGREEMENTINCOCREDITO);
						agreementOutDTO.setTrnServerStatusCode(CoreConstants.ERROR_STATUS_COD_AGREEMENTINCOCREDITO.toString()); 
						trnServerStatusDesc = getMessage(BundleKeys.ERROR_INVALID_INCOCREDITO , new Object[]{codigoIncocredito},
								locale, CoreConstants.ERRORS_BUNDLE);
						agreementOutDTO.setTrnServerStatusDesc(trnServerStatusDesc);
						agreementOutDTO.setApprovalId(null);
						agreementOutDTO.setRqUID(header.getRqUID());
						return agreementOutDTO;
					}}}
					//Se Valida si el codigo terminal es valido
					for(RefInfo refInfoRqT :requestAgrmSynch.getRefInfo()) {
						if(refInfoRqT.getRefId().equals(CoreConstants.REFERENCE_TERMINAL)) {
							if(validarTerminal(codigoIncocredito,refInfoRqT.getRefType(), requestAgrmSynch.getAgreement().getNit())) {
								agreementOutDTO.setStatusCode(CoreConstants.ERROR_STATUS_COD_AGREEMENTTERMINAL);
								agreementOutDTO.setStatusDesc(CoreConstants.ERROR_STATUS_DESC_AGREEMENTTERMINAL);
								agreementOutDTO.setTrnServerStatusCode(CoreConstants.ERROR_STATUS_COD_AGREEMENTTERMINAL.toString()); 
								trnServerStatusDesc = getMessage(BundleKeys.ERROR_INVALID_TERMINAL, new Object[]{refInfoRqT.getRefId()},
										locale, CoreConstants.ERRORS_BUNDLE);
								agreementOutDTO.setTrnServerStatusDesc(trnServerStatusDesc);
								agreementOutDTO.setApprovalId(null);
								agreementOutDTO.setRqUID(header.getRqUID());
								return agreementOutDTO;
							}}}
				}}}
			creacionConvenio.setOperacion(operacion);
			creacionConvenio.setCodigoNura(requestAgrmSynch.getAgreement().getAgrmId());
			creacionConvenio.setNit(requestAgrmSynch.getAgreement().getNit());
			
			for(RefInfo refInfoRq :requestAgrmSynch.getRefInfo()) {
				if(refInfoRq.getRefId().equalsIgnoreCase(CoreConstants.REFERENCE_CODEAN)) { 
					creacionConvenio.setCodigoEan(refInfoRq.getRefType());			
				}else if(refInfoRq.getRefId().equalsIgnoreCase(CoreConstants.REFERENCE_CODACH)) {			
					creacionConvenio.setCodigoAch(refInfoRq.getRefType());
				}else if(refInfoRq.getRefId().equalsIgnoreCase(CoreConstants.REFERENCE_AGREGADOR)) {			
					creacionConvenio.setAgregador(refInfoRq.getRefType());
				}else if(refInfoRq.getRefId().equalsIgnoreCase(CoreConstants.REFERENCE_INCOCREDITO)) {			
					creacionConvenio.setCodigoIncocredito(refInfoRq.getRefType());
				}else if(refInfoRq.getRefId().equalsIgnoreCase(CoreConstants.REFERENCE_TERMINAL)) {			
					creacionConvenio.setCodigoTerminal(refInfoRq.getRefType());
				}else if(refInfoRq.getRefId().equalsIgnoreCase(CoreConstants.REFERENCE_TC)) {			
					creacionConvenio.setTarjetaCredito(refInfoRq.getRefType());
				}else if(refInfoRq.getRefId().equalsIgnoreCase(CoreConstants.REFERENCE_TEMA)) {			
					creacionConvenio.setTema(refInfoRq.getRefType());
				}else if(refInfoRq.getRefId().equalsIgnoreCase(CoreConstants.REFERENCE_PLANTILLA)) {			
					creacionConvenio.setPlantilla(refInfoRq.getRefType());
				}else if(refInfoRq.getRefId().equalsIgnoreCase(CoreConstants.REFERENCE_LOGO)) {			
					creacionConvenio.setLogo(refInfoRq.getRefType());
				}else if(refInfoRq.getRefId().equalsIgnoreCase(CoreConstants.REFERENCE_URLCONFIRMACION)) {			
					creacionConvenio.setUrlConfirmacion(refInfoRq.getRefType());
				}else if(refInfoRq.getRefId().equalsIgnoreCase(CoreConstants.REFERENCE_RUTACERTIFICADO)) {			
					creacionConvenio.setRutaCertificado(refInfoRq.getRefType());
				}else if(refInfoRq.getRefId().equalsIgnoreCase(CoreConstants.REFERENCE_ESTADO)) {			
					creacionConvenio.setEstado(refInfoRq.getRefType());
				}else if(refInfoRq.getRefId().equalsIgnoreCase(CoreConstants.REFERENCE_GENDER)) {			
					creacionConvenio.setGender(refInfoRq.getRefType());
				}else if(refInfoRq.getRefId().equalsIgnoreCase(CoreConstants.REFERENCE_TIPODESERVICIO)) {			
					creacionConvenio.setTipoServicio(refInfoRq.getRefType());
				}else if(refInfoRq.getRefId().equalsIgnoreCase(CoreConstants.REFERENCE_NOFACTMULTIREF)) {			
					creacionConvenio.setNoFactMultipleRef(refInfoRq.getRefType());
				}else if(refInfoRq.getRefId().equalsIgnoreCase(CoreConstants.REFERENCE_TIPOADMINISTRADOR)) {			
					creacionConvenio.setTipoAdministrador(refInfoRq.getRefType());
				}else if (refInfoRq.getRefId().equalsIgnoreCase("appCodeRBM")) {
					creacionConvenio.setCodigoGlobalPay(refInfoRq.getRefType());
				} else if (refInfoRq.getRefId().equalsIgnoreCase("appKeyRBM")) {
					creacionConvenio.setLlaveGlobalPay(refInfoRq.getRefType());
				}
				else {
				ReferenceType referenceType = new ReferenceType();
				referenceType.setRefId(refInfoRq.getRefId());
				referenceType.setRefType(refInfoRq.getRefType());
				}
			
			}
			
			creacionConvenio.setIdActEcnomica(requestAgrmSynch.getAgreement().getCategCode());
			creacionConvenio.setIdMunicipio(requestAgrmSynch.getAgreement().getContactInfo().getPostAddr().getCity());
			creacionConvenio.setIdBanco(requestAgrmSynch.getBankInfo().getBankId());
			creacionConvenio.setRazonSocial(requestAgrmSynch.getAgreement().getName());
			creacionConvenio.setDigitoVerificacion(requestAgrmSynch.getAgreement().getAgrmVfrCode());
			creacionConvenio.setDireccion(requestAgrmSynch.getAgreement().getContactInfo().getPostAddr().getAddr1());
			
			for(PhoneNum phoneType :requestAgrmSynch.getAgreement().getContactInfo().getPhoneNum()) {
				if(phoneType.getPhoneType().equalsIgnoreCase(CoreConstants.TYPE_FAX)) {
					creacionConvenio.setFax(phoneType.getPhone());
					creacionConvenio.setTelefono(phoneType.getPhone());
				}else
				creacionConvenio.setTelefono(phoneType.getPhone());
			}
			
			creacionConvenio.setEmail(requestAgrmSynch.getAgreement().getContactInfo().getEmailAddr());
			creacionConvenio.setApeRepLegal(requestAgrmSynch.getLegalPerson().getPersonName().getLastName());
			creacionConvenio.setRepLegal(requestAgrmSynch.getLegalPerson().getPersonName().getFirstName());
			creacionConvenio.setNumDocRL(requestAgrmSynch.getLegalPerson().getGovIssueIdent().getIdentSerialNum());
			creacionConvenio.setTipoDocRL(requestAgrmSynch.getLegalPerson().getGovIssueIdent().getGovIssueIdentType());
			
			for(SecretList secretList :requestAgrmSynch.getSecretList()) {
				creacionConvenio.setUsuario(secretList.getSecretId());
				creacionConvenio.setContrasena(secretList.getSecret());
				
			}
			creacionConvenio.setUrlRespuesta(requestAgrmSynch.getAgreement().getImage().getUrl());

			Boolean  esPSE=false;
			creacionConvenio.setUrlRespuesta(requestAgrmSynch.getAgreement().getImage().getUrl());
			String idMedioPago="";
			for(PmtInfo pmtInfo : requestAgrmSynch.getPmtInfo()) {
				idMedioPago = idMedioPago+pmtInfo.getPmtInfoType()+",";	
				if(pmtInfo.getPmtInfoType().equalsIgnoreCase(Long.toString(PaymentWayCodes.PSE))) {
					esPSE=true;
				}
			}
			
			creacionConvenio.setIdMedioPago(idMedioPago);
			creacionConvenio.setCuentaAsociada(requestAgrmSynch.getAgreement().getDepAcctId().getAcctKey());
			creacionConvenio.setTipoCuenta(requestAgrmSynch.getAgreement().getDepAcctId().getAcctType());
			creacionConvenio.setDescTipoCuenta(requestAgrmSynch.getAgreement().getDepAcctId().getDesc());
			String codigoAchCuentaRecaudo="";
			String idBancoCuentaRecaudo="";
			String cuentaRecaudoAsociada="";
			if(esPSE && creacionConvenio.getAgregador().equals("1"))  {
				for(AdditionalDepAcctId additionalDepAcctId : requestAgrmSynch.getAdditionalDepAcctId()) {
					codigoAchCuentaRecaudo = codigoAchCuentaRecaudo+additionalDepAcctId.getRefInfo().getRefType()+",";
					idBancoCuentaRecaudo = idBancoCuentaRecaudo+additionalDepAcctId.getBankInfo().getBankId()+",";	
					cuentaRecaudoAsociada = cuentaRecaudoAsociada+additionalDepAcctId.getDepAcctId().getAcctKey()+",";
				}
				}
				
				
				creacionConvenio.setCodigoAchCuentaRecaudo(codigoAchCuentaRecaudo);
				creacionConvenio.setIdBancoCuentaRecaudo(idBancoCuentaRecaudo);
				creacionConvenio.setCuentaRecaudoAsociada(cuentaRecaudoAsociada);
			String idRol="";

			for(PartnerInfo partnerInfo: requestAgrmSynch.getPartnerInfo()) {
				idRol = idRol+partnerInfo.getPartnerType()+",";
				if(partnerInfo.getPartnerType().equals(CoreConstants.ROL_COMERCIAL)) {
					creacionConvenio.setNombreComercial(partnerInfo.getPersonInfo().getPersonName().getFirstName());
					creacionConvenio.setApellidoComercial(partnerInfo.getPersonInfo().getPersonName().getLastName());
					creacionConvenio.setNumDocComercial(partnerInfo.getPersonInfo().getGovIssueIdent().getIdentSerialNum());
					creacionConvenio.setTipoDocContComercial(partnerInfo.getPersonInfo().getGovIssueIdent().getGovIssueIdentType());
					creacionConvenio.setEmailContComercial(partnerInfo.getContactInfo().getEmailAddr());
					for(PhoneNum phonetype : partnerInfo.getContactInfo().getPhoneNum()) {
						creacionConvenio.setTelContComercial(phonetype.getPhone());			
					}
				}else if(partnerInfo.getPartnerType().equals(CoreConstants.ROL_TECNICO)){
					creacionConvenio.setNombreTecnico(partnerInfo.getPersonInfo().getPersonName().getFirstName());
					creacionConvenio.setApellidoTecnico(partnerInfo.getPersonInfo().getPersonName().getLastName());
					creacionConvenio.setNumDocTecnico(partnerInfo.getPersonInfo().getGovIssueIdent().getIdentSerialNum());
					creacionConvenio.setTipoDocContTecnico(partnerInfo.getPersonInfo().getGovIssueIdent().getGovIssueIdentType());
					creacionConvenio.setEmailContTecnico(partnerInfo.getContactInfo().getEmailAddr());
					for(PhoneNum phonetype : partnerInfo.getContactInfo().getPhoneNum()) {
						creacionConvenio.setTelContTecnico(phonetype.getPhone());			
					}
				}else if(partnerInfo.getPartnerType().equals(CoreConstants.ROL_OPERATIVO)) {
					creacionConvenio.setNombreOperativo(partnerInfo.getPersonInfo().getPersonName().getFirstName());
					creacionConvenio.setApellidoOperativo(partnerInfo.getPersonInfo().getPersonName().getLastName());
					creacionConvenio.setNumDocOperativo(partnerInfo.getPersonInfo().getGovIssueIdent().getIdentSerialNum());
					creacionConvenio.setTipoDocContOperativo(partnerInfo.getPersonInfo().getGovIssueIdent().getGovIssueIdentType());
					creacionConvenio.setEmailContOperativo(partnerInfo.getContactInfo().getEmailAddr());
					for(PhoneNum phonetype : partnerInfo.getContactInfo().getPhoneNum()) {
						creacionConvenio.setTelContOperativo(phonetype.getPhone());			
					}
				}
				
				
			}
			
			creacionConvenio.setIdRol(idRol);
			
			creacionConvenio.setRegEliminado(CoreConstants.REGELIMINADO_CREATE);
			
			commerce = commerceDAO.agreementCreate(creacionConvenio);
		}catch(Exception e) {
			logger.error("Error en agreementModify: ", e);
			return null;
			
		}
		if(commerce == null) {

			agreementOutDTO.setStatusCode(CoreConstants.ERROR_STATUS_COD_AGREEMENT);
			agreementOutDTO.setStatusDesc(getMessage(BundleKeys.ERROR_INVALID_AGREEMENT_ID, null, locale, CoreConstants.ERRORS_BUNDLE));
			agreementOutDTO.setTrnServerStatusCode(CoreConstants.ERROR_STATUS_COD_AGREEMENT.toString());
		} else {
			approvalId = commerce.getId().toString();
			trnServerStatusDesc = getMessage(BundleKeys.TRANSACTION_SUCCESS, null, locale, CoreConstants.MESSAGES_BUNDLE);
			agreementOutDTO.setStatusCode(CoreConstants.SUCCESS_STATUS_CODE);
			agreementOutDTO.setStatusDesc(getMessage(BundleKeys.TRANSACTION_SUCCESS, null, locale,CoreConstants.MESSAGES_BUNDLE));
			agreementOutDTO.setTrnServerStatusCode(CoreConstants.SUCCESS_STATUS_CODE.toString());
		}
		agreementOutDTO.setTrnServerStatusDesc(trnServerStatusDesc);
		agreementOutDTO.setRqUID(header.getRqUID());
		agreementOutDTO.setApprovalId(approvalId);
		
		return agreementOutDTO;
	}

	@Override
	public AgreementOutDTO agrmntDeleteAdm(String agrmId, String type, Header header, String operacion) {
		AgreementOutDTO agreementOutDTO = new AgreementOutDTO();
		Commerce	commerce =null;
		if (agrmId.toUpperCase().startsWith("C") && !agrmId.toUpperCase().startsWith("CPV")) {
			
			 commerce = commerceDAO.findByNura(agrmId);
			 if (commerce== null) {
				 agrmId=agrmId.replaceFirst("C","CPV");
				 commerce = commerceDAO.findByNura(agrmId);
			 }			
	}
	else{
		 commerce = commerceDAO.findByNura(agrmId);
	}
		String approvalId=null, trnServerStatusDesc=null;
		logger.info("Info comercio: "+ commerce);
		if(commerce == null) {
			agreementOutDTO.setStatusCode(CoreConstants.ERROR_STATUS_CODE_600);
			agreementOutDTO.setStatusDesc(CoreConstants.ERROR_STATUS_CODE_DESC_600);
			agreementOutDTO.setTrnServerStatusCode(CoreConstants.ERROR_STATUS_CODE_600.toString()); 
			trnServerStatusDesc = getMessage(BundleKeys.ERROR_NOTFOUND, new Object[]{
					agrmId}, locale, CoreConstants.ERRORS_BUNDLE);
			agreementOutDTO.setTrnServerStatusDesc(trnServerStatusDesc);
			agreementOutDTO.setApprovalId(null);
			agreementOutDTO.setRqUID(header.getRqUID());
			return agreementOutDTO;
		}
		try{
			creacionConvenio.setOperacion(operacion);
			creacionConvenio.setCodigoNura(agrmId);
			if(type.equals(CoreConstants.DELETE_TYPE1) && commerce.getStatus().equals(CoreConstants.STATE_ON)) {
				creacionConvenio.setEstado(CoreConstants.STATE_OFF);
				creacionConvenio.setRegEliminado(CoreConstants.REGELIMINADO_DELETE_OFF);
			}else if(type.equals(CoreConstants.DELETE_TYPE1) && commerce.getStatus().equals(CoreConstants.STATE_OFF)) {
				creacionConvenio.setEstado(CoreConstants.STATE_ON);
				creacionConvenio.setRegEliminado(CoreConstants.REGELIMINADO_DELETE_OFF);
			}else if(type.equals(CoreConstants.DELETE_TYPE2)) {
				creacionConvenio.setEstado(CoreConstants.STATE_OFF);
				creacionConvenio.setRegEliminado(CoreConstants.REGELIMINADO_DELETE_ON);
			}else{
				agreementOutDTO.setStatusCode(CoreConstants.ERROR_STATUS_CODE_600);
				agreementOutDTO.setStatusDesc(CoreConstants.ERROR_STATUS_CODE_DESC_600);
				agreementOutDTO.setTrnServerStatusCode(CoreConstants.ERROR_STATUS_CODE_600.toString()); 
				trnServerStatusDesc = getMessage(BundleKeys.ERROR_TYPE_DELETE, null, locale, CoreConstants.ERRORS_BUNDLE);
				agreementOutDTO.setTrnServerStatusDesc(trnServerStatusDesc);
				agreementOutDTO.setApprovalId(null);
				agreementOutDTO.setRqUID(header.getRqUID());
			return agreementOutDTO;
		}
				
			creacionConvenio.setAgregador("");
			creacionConvenio.setApellidoComercial("");
			creacionConvenio.setApellidoTecnico("");
			creacionConvenio.setApellidoOperativo("");
			creacionConvenio.setApeRepLegal("");
			creacionConvenio.setCodigoAch("");
			creacionConvenio.setCodigoEan("");
			creacionConvenio.setCodigoIncocredito("");
			creacionConvenio.setCodigoTerminal("");
			creacionConvenio.setContrasena("");
			creacionConvenio.setCuentaAsociada("");
			creacionConvenio.setDescTipoCuenta("");
			creacionConvenio.setDigitoVerificacion("");
			creacionConvenio.setDireccion("");
			creacionConvenio.setEmail("");
			creacionConvenio.setEmailContComercial("");
			creacionConvenio.setEmailContTecnico("");
			creacionConvenio.setEmailContOperativo("");
			creacionConvenio.setFax("");
			creacionConvenio.setGender("");
			creacionConvenio.setIdActEcnomica("");
			creacionConvenio.setIdBanco("");
			creacionConvenio.setIdMedioPago("");
			creacionConvenio.setIdMunicipio("");
			creacionConvenio.setIdRol("");
			creacionConvenio.setLogo("");
			creacionConvenio.setNit("");
			creacionConvenio.setNoFactMultipleRef("");
			creacionConvenio.setNombreComercial("");
			creacionConvenio.setNombreTecnico("");
			creacionConvenio.setNombreOperativo("");
			creacionConvenio.setNumDocComercial("");
			creacionConvenio.setNumDocTecnico("");
			creacionConvenio.setNumDocOperativo("");
			creacionConvenio.setNumDocRL("");
			creacionConvenio.setPlantilla("");
			creacionConvenio.setRazonSocial("");
			creacionConvenio.setRepLegal("");
			creacionConvenio.setRutaCertificado("");
			creacionConvenio.setTarjetaCredito("");
			creacionConvenio.setTelContComercial("");
			creacionConvenio.setTelContTecnico("");
			creacionConvenio.setTelContOperativo("");
			creacionConvenio.setTelefono("");
			creacionConvenio.setTema("");
			creacionConvenio.setTipoCuenta("");
			creacionConvenio.setTipoDocContComercial("");
			creacionConvenio.setTipoDocContTecnico("");
			creacionConvenio.setTipoDocContOperativo("");
			creacionConvenio.setTipoDocRL("");
			creacionConvenio.setTipoServicio("");
			creacionConvenio.setUrlConfirmacion("");
			creacionConvenio.setUrlRespuesta("");
			creacionConvenio.setUsuario("");			
			
			
			commerce = commerceDAO.agreementCreate(creacionConvenio);
		}catch(Exception e) {
			logger.error("Error en agreementDelete: ", e);
			return null;
			
		}
		if(commerce == null) {
			agreementOutDTO.setStatusCode(CoreConstants.ERROR_STATUS_COD_AGREEMENT);
			agreementOutDTO.setStatusDesc(getMessage(BundleKeys.ERROR_INVALID_AGREEMENT_ID, null, locale,CoreConstants.ERRORS_BUNDLE));
			agreementOutDTO.setTrnServerStatusCode(CoreConstants.ERROR_STATUS_COD_AGREEMENT.toString());
		} else {
			approvalId = commerce.getId().toString();
			trnServerStatusDesc = getMessage(BundleKeys.TRANSACTION_SUCCESS, null, locale,CoreConstants.MESSAGES_BUNDLE);
			agreementOutDTO.setStatusCode(CoreConstants.SUCCESS_STATUS_CODE);
			agreementOutDTO.setStatusDesc(getMessage(BundleKeys.TRANSACTION_SUCCESS, null, locale,CoreConstants.MESSAGES_BUNDLE));
			agreementOutDTO.setTrnServerStatusCode(CoreConstants.SUCCESS_STATUS_CODE.toString());
		}
		agreementOutDTO.setTrnServerStatusDesc(trnServerStatusDesc);
		agreementOutDTO.setRqUID(header.getRqUID());
		agreementOutDTO.setApprovalId(approvalId);
		
		return agreementOutDTO;
	}

	public boolean validarIncocredito(String codigoIncocredito, String nit) {
		try {
			logger.info("Entro al método validarIncocredito del facade GestionConveniosFacadeBean");
			
			Long count= commerceDAO.getCommerceByIncoCredito(codigoIncocredito, nit);
			
			if(count>0)
				return true;
			
		} catch (Exception e) {
			logger.error("Error realizando la validacion del codigo incocredito. ", e);
		}
		return false;
	}

	public boolean validarTerminal(String codigoIncocredito, String codigoTerminal, String codigoNura) {
		try {
			logger.info("Entro al método validarIncocredito del facade GestionConveniosFacadeBean");
			
			Long count= commerceDAO.getCommerceByTerminal(codigoIncocredito, codigoTerminal, codigoNura);
			
			if(count>0)
				return true;
		
	} catch (Exception e) {
		logger.error("Error realizando la validacion del codigo terminal. ", e);
	}
	return false;
	}


}