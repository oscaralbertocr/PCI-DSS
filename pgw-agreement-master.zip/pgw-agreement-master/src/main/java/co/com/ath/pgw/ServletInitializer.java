package co.com.ath.pgw;

import org.springframework.boot.builder.SpringApplicationBuilder;
import org.springframework.boot.web.servlet.support.SpringBootServletInitializer;
/**
 * aplicacion del api agreement
 * @version 1.0 17/06/2019
 * @author sophosSolutions
 */
public class ServletInitializer extends SpringBootServletInitializer {
	/**
	 * inicializacion de la aplicacion.
	 * @param application
	 * @return SpringApplicationBuilder
	 */
	@Override
	protected SpringApplicationBuilder configure(SpringApplicationBuilder application) {
		return application.sources(PgwAgreementApplication.class);
	}

}
