/*
 * AgreementSynchronizationService
 *  
 * GSI - Recaudos
 * Creado el: 05/11/2015
 *
 * Copyright (c) A Toda Hora S.A. Todos los derechos reservados
 * 
 * Este software es confidencial y es propietario de ATH, queda prohibido
 * su uso, reproducción y copia de manera parcial o permanente salvo autorización
 * expresa de A Toda Hora S.A o de quién represente sus derechos.
 */
package co.com.ath.pgw.bsn.service;

import co.com.ath.pgw.bsn.dto.in.AgreementSynchronizationInDTO;
import co.com.ath.pgw.bsn.dto.out.AgreementOutDTO;
import co.com.ath.pgw.rest.request.dto.Header;
import co.com.ath.pgw.rest.request.dto.RequestAgrmSynch;
import co.com.ath.pgw.rest.response.dto.ResponseAgrmSynch;

/**
 * Servicio para realizar las operaciones disponibles para el comercio.
 * @version 0.0.0 05/11/2015
 * @author <proveedor_edrobles@ath.com.co>
 */
public interface AgreementSynchronizationService {
	
	/**
	 * Permite gestionar novedades en los convenios asociados.
	 * @param agreementSynchronizationInDTO
	 * @return AgreementOutDTO
	 */	
	public AgreementOutDTO agrmntSynchAdm(AgreementSynchronizationInDTO agreementSynchronizationInDTO);
	/**
	 * Permite la creacion de convenios desde el portal administrativo.
	 * @param requestAgrmSynch
	 * @param header
	 * @return AgreementOutDTO
	 */	
	public AgreementOutDTO agrmntCreateAdm(RequestAgrmSynch requestAgrmSynch, Header header);
	/**
	 * Permite la creacion de convenios desde el portal administrativo.
	 * @param agrmId
	 * @param headerDto
	 * @return RequestAgrmSynch
	 */	
	public ResponseAgrmSynch agrmntFindAdm(String  agrmId, Header headerDto);
	
	/**
	 * Permite la actualizacion de convenios desde el portal administrativo.
	 * @param requestAgrmSynch
	 * @param header
	 * @return AgreementOutDTO
	 */
	public AgreementOutDTO agrmntModifyAdm(RequestAgrmSynch requestAgrmSynch, Header headerDto, String operacion);
	/**
	 * Permite la actualizacion de convenios desde el portal administrativo.
	 * @param requestAgrmSynch
	 * @param header
	 * @return AgreementOutDTO
	 */	
	public AgreementOutDTO agrmntDeleteAdm(String agrmId, String type, Header headerDto, String operacion);
	
	
}
