package co.com.ath.pgw.bsn.controller;

import java.util.List;

import co.com.ath.pgw.bsn.model.bo.CommerceRoleContactBO;

/*
* Interface del servicio de obtener los roles
*
* @author Nelly Rocio Linares <nelly.linares@sophossolutions.com>
* @version 1.0 28/05/2019
* 
*/

public interface RoleCtrlService {

	List<CommerceRoleContactBO> findAll();

}
