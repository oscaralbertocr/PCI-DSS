package co.com.ath.pgw.rest.dto;

import java.io.Serializable;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonProperty;

public class ContactInfo implements Serializable
{

    @JsonProperty("EmailAddr")
    private String emailAddr;
    @JsonProperty("PhoneNum")
    private List<PhoneNum> phoneNum = null;
    @JsonProperty("PostAddr")
    private PostAddr postAddr;
    private final static long serialVersionUID = -4907486557723192652L;

   
    public String getEmailAddr() {
        return emailAddr;
    }

    
    public void setEmailAddr(String emailAddr) {
        this.emailAddr = emailAddr;
    }

       
    public PostAddr getPostAddr() {
        return postAddr;
    }

    
    public void setPostAddr(PostAddr postAddr) {
        this.postAddr = postAddr;
    }

	public List<PhoneNum> getPhoneNum() {
		return phoneNum;
	}


	public void setPhoneNum(List<PhoneNum> phoneNum) {
		this.phoneNum = phoneNum;
	}
    
    

}
