package co.com.ath.pgw.config;

import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;

/**
 * Configuracion persistencia para el api
 * @author SophosSolutions
 * @version 1.0
 */
@Configuration
@ComponentScan(basePackages = "co.com.ath.pgw.persistence.dao")
public class PersistenceConfig {


}
