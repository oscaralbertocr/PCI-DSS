package co.com.ath.pgw.bsn.controller.impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import co.com.ath.pgw.bsn.controller.BankCtrlService;
import co.com.ath.pgw.srv.mapper.MapperGetBankInfo;
import co.com.ath.pgw.persistence.dao.BankDAO;
import co.com.ath.pgw.rest.response.dto.BankListResponse;

/*
* Implementación del servicio de consulta de entidades bancarias 
*
* @author Nelly Rocio Linares <nelly.linares@sophossolutions.com>
* @version 1.0 28/05/2019
* 
*/

@Service
public class BankCtrlServiceImpl implements BankCtrlService {

	@Autowired
	private BankDAO bankDao;

	@Override
	public BankListResponse findByIsAval(Long valor) {
		return MapperGetBankInfo.mapperResponseSuccessCore(bankDao.findByIsAval(valor));

	}

}
