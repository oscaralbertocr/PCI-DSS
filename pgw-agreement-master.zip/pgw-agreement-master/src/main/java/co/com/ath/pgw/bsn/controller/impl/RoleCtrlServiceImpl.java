package co.com.ath.pgw.bsn.controller.impl;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import co.com.ath.pgw.bsn.controller.RoleCtrlService;
import co.com.ath.pgw.bsn.model.bo.CommerceRoleContactBO;
import co.com.ath.pgw.persistence.dao.CommerceRoleContactDAO;
import co.com.ath.pgw.persistence.model.CommerceRoleContact;

/*
* 
*
* @author Nelly Rocio Linares <nelly.linares@sophossolutions.com>
* @version 1.0 28/05/2019
* 
*/

@Service
public class RoleCtrlServiceImpl implements RoleCtrlService {

	@Autowired
	private CommerceRoleContactDAO commerceRoleContactDAO;

	@Override
	public List<CommerceRoleContactBO> findAll() {

		List<CommerceRoleContactBO> roles = new ArrayList<CommerceRoleContactBO>();
		List<CommerceRoleContact> lista = commerceRoleContactDAO.findAll();

		for (CommerceRoleContact result : lista) {
			CommerceRoleContactBO rol = new CommerceRoleContactBO();

			rol.setId(result.getId());
			rol.setName(result.getName());
			roles.add(rol);
		}

		return roles;
	}

}
