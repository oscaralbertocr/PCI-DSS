package co.com.ath.services.apirest.controller;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataAccessException;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import co.com.ath.services.apirest.model.dto.ParametroDTO;
import co.com.ath.services.apirest.model.services.IParametroService;
import co.com.ath.services.apirest.util.Constants;
import co.com.ath.services.apirest.util.Util;

/*
 * Clase : ParametroRestController
 * Date  : 18-Nov-2020
 * Author: Javier Capera
 *         SOPHOS SOLUTIONS
 */

@RestController
@RequestMapping("/rest")
public class ParametroRestController {
	static Logger logger = LoggerFactory.getLogger(ParametroRestController.class);

	@Autowired
	private IParametroService parametroService;

	private Map<String, Object> response = new HashMap<>();

	/**
	 * @param id
	 * @return
	 */
	@GetMapping("/parametro/{id}")
	public ResponseEntity<?> show(@PathVariable String id) {
		ParametroDTO parametroDTO = new ParametroDTO();
		response = new HashMap<>();

		try {
			parametroDTO = parametroService.find(id);
			if (parametroDTO == null) {
				response.put(Constants.MSG_PARAMETRO_TXT, Constants.INF_PARAMETRO_01);
				return new ResponseEntity<Map<String, Object>>(response, HttpStatus.ACCEPTED);
			}

		} catch (DataAccessException ex) {
			response.put(Constants.MSG_PARAMETRO_TXT, Constants.ERR_PARAMETRO_01);
			response.put(Constants.ERR_PARAMETRO_TXT, ex.getMessage().concat(": ").concat(ex.getCause().getMessage()));
			logger.error(Constants.ERR_PARAMETRO_TXT + " =>",
					ex.getMessage().concat(": ").concat(ex.getCause().getMessage()));
			return new ResponseEntity<Map<String, Object>>(response, HttpStatus.INTERNAL_SERVER_ERROR);
		}
		return new ResponseEntity<ParametroDTO>(parametroDTO, HttpStatus.OK);
	}

	/**
	 * @param parametroDTO
	 * @return
	 */
	@PostMapping("/parametro")
	public ResponseEntity<?> create(@RequestBody ParametroDTO parametroDTO) {
		ParametroDTO parametroNew = null;
		response = new HashMap<>();

		try {

			if (parametroDTO == null) {
				response.put(Constants.MSG_PARAMETRO_TXT, Constants.INF_PARAMETRO_07);
				return new ResponseEntity<Map<String, Object>>(response, HttpStatus.ACCEPTED);
			}

			if ((parametroDTO.getDescripcion() == null || parametroDTO.getDescripcion().isEmpty())
					|| (parametroDTO.getTipoValor() == null || parametroDTO.getTipoValor().isEmpty())
					|| (parametroDTO.getValor() == null || parametroDTO.getValor().isEmpty())) {
				response.put(Constants.MSG_PARAMETRO_TXT, Constants.INF_PARAMETRO_06);
				return new ResponseEntity<Map<String, Object>>(response, HttpStatus.ACCEPTED);
			}

			if (!Util.tipoDatoValido(parametroDTO.getTipoValor())) {
				response.put(Constants.MSG_PARAMETRO_TXT, Constants.INF_PARAMETRO_04);
				return new ResponseEntity<Map<String, Object>>(response, HttpStatus.ACCEPTED);
			}

			parametroNew = parametroService.save(parametroDTO);
			if (parametroNew == null) {
				response.put(Constants.MSG_PARAMETRO_TXT, Constants.INF_PARAMETRO_02);
				return new ResponseEntity<Map<String, Object>>(response, HttpStatus.ACCEPTED);
			}
		} catch (DataAccessException ex) {
			response.put(Constants.MSG_PARAMETRO_TXT, Constants.ERR_PARAMETRO_01);
			response.put(Constants.ERR_PARAMETRO_TXT, ex.getMessage().concat(": ").concat(ex.getCause().getMessage()));
			logger.error(Constants.ERR_PARAMETRO_TXT + " =>",
					ex.getMessage().concat(": ").concat(ex.getCause().getMessage()));
			return new ResponseEntity<Map<String, Object>>(response, HttpStatus.INTERNAL_SERVER_ERROR);
		}
		return new ResponseEntity<ParametroDTO>(parametroNew, HttpStatus.OK);
	}

	/**
	 * @param parametroDTO
	 * @param id
	 * @return
	 */
	@PutMapping("/parametro/{id}")
	public ResponseEntity<?> update(@RequestBody ParametroDTO parametroDTO, @PathVariable String id) {
		ParametroDTO parametroNew = null;
		response = new HashMap<>();

		try {
			if (parametroService.find(id) == null) {
				response.put(Constants.MSG_PARAMETRO_TXT, Constants.INF_PARAMETRO_03);
				return new ResponseEntity<Map<String, Object>>(response, HttpStatus.ACCEPTED);
			}

			if ((parametroDTO.getDescripcion() == null || parametroDTO.getDescripcion().isEmpty())
					|| (parametroDTO.getTipoValor() == null || parametroDTO.getTipoValor().isEmpty())
					|| (parametroDTO.getValor() == null || parametroDTO.getValor().isEmpty())) {
				response.put(Constants.MSG_PARAMETRO_TXT, Constants.INF_PARAMETRO_06);
				return new ResponseEntity<Map<String, Object>>(response, HttpStatus.ACCEPTED);
			}

			if (!Util.tipoDatoValido(parametroDTO.getTipoValor())) {
				response.put(Constants.MSG_PARAMETRO_TXT, Constants.INF_PARAMETRO_04);
				return new ResponseEntity<Map<String, Object>>(response, HttpStatus.ACCEPTED);
			}

			parametroNew = parametroService.save(parametroDTO);
			if (parametroNew == null) {
				response.put(Constants.MSG_PARAMETRO_TXT, Constants.INF_PARAMETRO_05);
				return new ResponseEntity<Map<String, Object>>(response, HttpStatus.ACCEPTED);
			}
		} catch (DataAccessException ex) {
			response.put(Constants.MSG_PARAMETRO_TXT, Constants.ERR_PARAMETRO_01);
			response.put(Constants.ERR_PARAMETRO_TXT, ex.getMessage().concat(": ").concat(ex.getCause().getMessage()));
			logger.error(Constants.ERR_PARAMETRO_TXT + " =>",
					ex.getMessage().concat(": ").concat(ex.getCause().getMessage()));
			return new ResponseEntity<Map<String, Object>>(response, HttpStatus.INTERNAL_SERVER_ERROR);
		}
		return new ResponseEntity<ParametroDTO>(parametroNew, HttpStatus.OK);
	}

	/**
	 * @param parametroDTO
	 * @return
	 */
	@PostMapping("/parametro/lista")
	public ResponseEntity<?> getLista(@RequestBody String[] lista) {
		List<ParametroDTO> lst = new ArrayList<>();
		response = new HashMap<>();

		try {

			if (lista == null || lista.length==0) {
				response.put(Constants.MSG_PARAMETRO_TXT, Constants.INF_PARAMETRO_08);
				return new ResponseEntity<Map<String, Object>>(response, HttpStatus.ACCEPTED);
			}

			lst = parametroService.lstParametros(lista);
			if (lst == null || lst.isEmpty()) {
				response.put(Constants.MSG_PARAMETRO_TXT, Constants.INF_PARAMETRO_09);
				return new ResponseEntity<Map<String, Object>>(response, HttpStatus.ACCEPTED);
			}
		} catch (DataAccessException ex) {
			response.put(Constants.MSG_PARAMETRO_TXT, Constants.ERR_PARAMETRO_01);
			response.put(Constants.ERR_PARAMETRO_TXT, ex.getMessage().concat(": ").concat(ex.getCause().getMessage()));
			logger.error(Constants.ERR_PARAMETRO_TXT + " =>",
					ex.getMessage().concat(": ").concat(ex.getCause().getMessage()));
			return new ResponseEntity<Map<String, Object>>(response, HttpStatus.INTERNAL_SERVER_ERROR);
		}
		return new ResponseEntity<List<ParametroDTO>>(lst, HttpStatus.OK);
	}

}
