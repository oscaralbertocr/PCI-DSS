package co.com.ath.services.apirest.config;

import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;

/**
 * Configuracion persistencia para el api
 * @author SophosSolutions
 * @version 1.0
 */
@Configuration
@ComponentScan(basePackages = {"co.com.ath.services.apirest.model.dao",
		"co.com.ath.services.apirest.model.entities"})
public class PersistenceConfig {


}
