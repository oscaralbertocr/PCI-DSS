package co.com.ath.services.apirest.model.dao;

import java.util.List;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;

import co.com.ath.services.apirest.model.entities.Parametro;


/*
 * Clase : IParametroDAO
 * Date  : 18-Nov-2020
 * Author: Javier Capera
 *         SOPHOS SOLUTIONS
 */
public interface IParametroDAO extends CrudRepository<Parametro, String> {
	
	@Query(value = "select * from parametros par where par.clave IN ?1", nativeQuery = true)
	public List<Parametro> getLstParametros(String[] arr);

}
