package co.com.ath.services.apirest.util;

public class Util {

	public static final boolean tipoDatoValido(String tipoDato) {
		boolean resp = false;

		switch (tipoDato) {
		case Constants.PARAM_TIPO_DATO_ALFANUMERICO:
			resp = true;
			break;
		case Constants.PARAM_TIPO_DATO_NUMERICO:
			resp = true;
			break;
		case Constants.PARAM_TIPO_DATO_FECHA:
			resp = true;
			break;
		case Constants.PARAM_TIPO_DATO_BOOLEAN:
			resp = true;
			break;
		case Constants.PARAM_TIPO_DATO_BLOQUE:
			resp = true;
			break;
		case Constants.PARAM_TIPO_DATO_MILIS:
			resp = true;
			break;
		}
		return resp;

	}

}
