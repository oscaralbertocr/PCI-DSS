package co.com.ath.services.apirest.model.entities;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import co.com.ath.services.apirest.model.dto.ParametroDTO;

/*
 * Clase : Parametro
 * Date  : 18-Nov-2020
 * Author: Javier Capera
 *         SOPHOS SOLUTIONS
 */

@Entity
@Table(name = "PARAMETROS")
public class Parametro implements Serializable {

	@Id
	@Column(name = "CLAVE", nullable = false)
	private String nombre;

	@Column(name = "DESCRIPCION", nullable = false)
	private String descripcion;

	@Column(name = "VALOR_ACTUAL", nullable = false)
	private String valorActual;

	@Column(name = "VALOR_ANTERIOR")
	private String valorAnterior;

	@Column(name = "VALOR_POSTERIOR")
	private String valorPosterior;

	@Column(name = "TIPO_VALOR", nullable = false)
	private String tipoValor;

	@Column(name = "FECHA_CREACION", nullable = false)
	private Date fechaCreacion;

	@Column(name = "FECHA_ULT_MODIF")
	private Date fechaModificacion;

	@Column(name = "ESTADO", nullable = false)
	private boolean estado;

	public Parametro() {

	}

	public String getNombre() {
		return nombre;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	public String getDescripcion() {
		return descripcion;
	}

	public void setDescripcion(String descripcion) {
		this.descripcion = descripcion;
	}

	public String getValorActual() {
		return valorActual;
	}

	public void setValorActual(String valorActual) {
		this.valorActual = valorActual;
	}

	public String getValorAnterior() {
		return valorAnterior;
	}

	public void setValorAnterior(String valorAnterior) {
		this.valorAnterior = valorAnterior;
	}

	public String getValorPosterior() {
		return valorPosterior;
	}

	public void setValorPosterior(String valorPosterior) {
		this.valorPosterior = valorPosterior;
	}

	public String getTipoValor() {
		return tipoValor;
	}

	public void setTipoValor(String tipoValor) {
		this.tipoValor = tipoValor;
	}

	public Date getFechaCreacion() {
		return fechaCreacion;
	}

	public void setFechaCreacion(Date fechaCreacion) {
		this.fechaCreacion = fechaCreacion;
	}

	public Date getFechaModificacion() {
		return fechaModificacion;
	}

	public void setFechaModificacion(Date fechaModificacion) {
		this.fechaModificacion = fechaModificacion;
	}

	public boolean isEstado() {
		return estado;
	}

	public void setEstado(boolean estado) {
		this.estado = estado;
	}

	@Override
	public String toString() {
		return "Parametro [id=" + nombre + ", descripcion=" + descripcion + ", valorActual=" + valorActual
				+ ", valorAnterior=" + valorAnterior + ", valorPosterior=" + valorPosterior + ", tipoValor=" + tipoValor
				+ ", fechaCreacion=" + fechaCreacion + ", fechaModificacion=" + fechaModificacion + ", estado=" + estado
				+ "]";
	}

	/**
	 * @return
	 */
	public ParametroDTO toParametroDTO() {
		ParametroDTO parametroDTO = new ParametroDTO();

		parametroDTO.setNombre(this.nombre);
		parametroDTO.setDescripcion(this.descripcion);
		parametroDTO.setValor(this.valorActual);
		parametroDTO.setTipoValor(this.tipoValor);
		parametroDTO.setActivo(this.estado);
		return parametroDTO;
	}

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

}
