package co.com.ath.services.apirest.model.services.impl;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import co.com.ath.services.apirest.model.dao.IParametroDAO;
import co.com.ath.services.apirest.model.dto.ParametroDTO;
import co.com.ath.services.apirest.model.entities.Parametro;
import co.com.ath.services.apirest.model.services.IParametroService;
import co.com.ath.services.apirest.util.Constants;

/*
 * Clase : ParametroServiceImpl
 * Date  : 18-Nov-2020
 * Author: Javier Capera
 *         SOPHOS SOLUTIONS
 */
@Service
public class ParametroServiceImpl implements IParametroService {

	@Autowired
	private IParametroDAO parametroDAO;

	@Override
	@Transactional
	public ParametroDTO save(ParametroDTO parametroDTO) {
		Parametro parametro = new Parametro();

		if (parametroDTO != null && !parametroDTO.getNombre().isEmpty()) {
			parametro = parametroDAO.findOne(parametroDTO.getNombre());

			if (parametro != null) {
				parametro.setEstado(parametroDTO.isActivo());
				parametro.setTipoValor(parametroDTO.getTipoValor());
				if (parametro.isEstado()) {
					parametro.setDescripcion(parametroDTO.getDescripcion());
					if (!parametro.getValorActual().equals(parametroDTO.getValor())) {
						parametro.setValorPosterior(parametro.getValorAnterior());
						parametro.setValorAnterior(parametro.getValorActual());
						parametro.setValorActual(parametroDTO.getValor());
						parametro.setFechaModificacion(new Date());
					}
				}
			} else {
				parametro = new Parametro();
				parametro.setNombre(parametroDTO.getNombre());
				parametro.setDescripcion(parametroDTO.getDescripcion());
				parametro.setValorActual(parametroDTO.getValor());
				parametro.setTipoValor(parametroDTO.getTipoValor());
				parametro.setFechaCreacion(new Date());
				parametro.setEstado(Constants.PARAM_ESTADO_HABILITADO);
			}
			return parametroDAO.save(parametro).toParametroDTO();
		}
		return null;
	}

	@Override
	@Transactional(readOnly = true)
	public ParametroDTO find(String nombre) {
		if (nombre != null) {
			Parametro parametro = parametroDAO.findOne(nombre);
			if (parametro != null) {
				return parametro.toParametroDTO();
			}
		}
		return null;
	}

	@Override
	@Transactional
	public List<ParametroDTO> lstParametros(String[] lst) {
		List<ParametroDTO> lstParametro = new ArrayList<>();
		if (lst != null ) {
			ParametroDTO parametroDTO;
		
			List<Parametro> lstConsulta = parametroDAO.getLstParametros(lst);
			for (Parametro p : lstConsulta) {
				parametroDTO = new ParametroDTO();
				parametroDTO.setActivo(p.isEstado());
				parametroDTO.setDescripcion(p.getDescripcion());
				parametroDTO.setNombre(p.getNombre());
				parametroDTO.setTipoValor(p.getTipoValor());
				parametroDTO.setValor(p.getValorActual());

				lstParametro.add(parametroDTO);
			}
		}
		return lstParametro;
	}

}
