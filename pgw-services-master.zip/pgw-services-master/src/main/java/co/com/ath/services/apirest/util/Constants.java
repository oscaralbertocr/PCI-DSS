package co.com.ath.services.apirest.util;

public class Constants {
	
	/* Parametro */
	public static final boolean PARAM_ESTADO_HABILITADO = true;
	public static final boolean PARAM_ESTADO_INHABILITADO = false;
	public static final String PARAM_TIPO_DATO_ALFANUMERICO ="Alfanumérico";
	public static final String PARAM_TIPO_DATO_NUMERICO ="Numérico";
	public static final String PARAM_TIPO_DATO_FECHA ="Fecha";
	public static final String PARAM_TIPO_DATO_BOOLEAN = "Booleano";
	public static final String PARAM_TIPO_DATO_BLOQUE = "Bloque";
	public static final String PARAM_TIPO_DATO_MILIS = "Milisegundos";
	
	/* Mensajes de error */
	
	public static final String ERR_PARAMETRO_TXT = "Error";
	public static final String ERR_PARAMETRO_01 = "PAR/Err001-Error al acceder la base de datos";
	
	/* Mensajes informativos */
	public static final String MSG_PARAMETRO_TXT = "Mensaje";
	public static final String INF_PARAMETRO_01 = "PAR/Inf001-No se encontró información de ese parámetro";
	public static final String INF_PARAMETRO_02 = "PAR/Inf002-El parámetro no pudo guardarse";
	public static final String INF_PARAMETRO_03 = "PAR/Inf003-El parámetro que se va actualizar no existe";
	public static final String INF_PARAMETRO_04 = "PAR/Inf004-Los tipo de datos reconocidos son: Alfanumérico, Numérico, Fecha, Booleano o Bloque";	
	public static final String INF_PARAMETRO_05 = "PAR/Inf005-El parámetro no pudo actualizarse";
	public static final String INF_PARAMETRO_06 = "PAR/Inf006-Hay campos vacíos en la solicitud que deben diligenciarse";
	public static final String INF_PARAMETRO_07 = "PAR/Inf007-No hay información para guardar";
	public static final String INF_PARAMETRO_08 = "PAR/Inf008-La lista de parámetros a consultar esta vacia";
	public static final String INF_PARAMETRO_09 = "PAR/Inf009-No se encontró información para la lista de parámetros";
}
