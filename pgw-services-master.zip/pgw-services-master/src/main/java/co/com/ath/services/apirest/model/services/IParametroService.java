package co.com.ath.services.apirest.model.services;

import java.util.List;

import co.com.ath.services.apirest.model.dto.ParametroDTO;

/*
 * Clase : IParametroService
 * Date  : 18-Nov-2020
 * Author: Javier Capera
 *         SOPHOS SOLUTIONS
 */
public interface IParametroService {

	public ParametroDTO save(ParametroDTO parametroDTO);

	public ParametroDTO find(String nombre);

	public List<ParametroDTO> lstParametros(String[] lst);

}
