# pgw-aval
# Ejecucion Release [RQ32458_Release_Aval] - prv_jmrodriguez:AV_1
# 2_Ejecucion Release [RQ32458_Release_Aval] - prv_jmrodriguez:AV_1
# 3_Ejecucion Release [RQ32458_Release_Aval] - prv_jmrodriguez:AV_1
# [30072019]4_Ejecucion Release [RQ32458_Release_Aval] - prv_jmrodriguez:AV_1
# [11092019]1_Ejecucion Release [RQ32458_Release_Aval] - prv_jmrodriguez:AV_1.1
# [18092019]2_Ejecucion Release [RQ32458_Release_Aval] - prv_jmrodriguez:AV_1.2
# [04102019]1_Ejecucion Release [RQ32458_Release_Aval] - prv_javendano:AV_1.3
# [25112019]1_Ejecucion Release [RQ32458_Reporte fortify] - prv_javendano:AV_1.5:PT
# [16102019]1_Ejecucion Release [RQ33328_Particion de Logs] - prv_javendano:AV_1.4
<<<<<<< HEAD



=======
# [14012020]1_Ejecucion Release [Escaneo Fortify] - jmendoza:AV_1.8
# [05032020] 1_Ejecucion Release [Escaneo Fortify] - jmendoza:AV_1.9:PT
>>>>>>> PT
