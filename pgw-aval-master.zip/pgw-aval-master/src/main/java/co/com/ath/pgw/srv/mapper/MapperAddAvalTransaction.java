package co.com.ath.pgw.srv.mapper;

import java.util.Calendar;

/*
 * author: Edwin Alexander Bohorquez
 * description: Clase para mapear objetos request 
 * 				a objetos del Core.
*/

import java.util.Date;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import co.com.ath.pgw.in.dto.AVALPaymentAddRqType;
import co.com.ath.pgw.in.dto.AVALPaymentAddRsType;
import co.com.ath.pgw.in.model.AgreementInfoType;
import co.com.ath.pgw.in.model.BankInfoType;
import co.com.ath.pgw.in.model.CustNameType;
import co.com.ath.pgw.in.model.FeeType;
import co.com.ath.pgw.in.model.OrderInfoType;
import co.com.ath.pgw.in.model.PersonalDataType;
import co.com.ath.pgw.in.model.ReferenceType;
import co.com.ath.pgw.in.model.TaxFeeType;
import co.com.ath.pgw.in.model.TransactionStatusType;
import co.com.ath.pgw.in.model.UserIdType;
import co.com.ath.pgw.rest.dto.AdditionalStatus;
import co.com.ath.pgw.rest.dto.MsgRsHdr;
import co.com.ath.pgw.rest.dto.PmtStatus;
import co.com.ath.pgw.rest.dto.RefInfo;
import co.com.ath.pgw.rest.dto.Status;
import co.com.ath.pgw.rest.request.dto.AVALTransactionRequest;
import co.com.ath.pgw.rest.request.dto.Header;
import co.com.ath.pgw.rest.response.dto.AVALTransactionResponse;
import co.com.ath.pgw.rest.response.dto.GenericErrorResponse;
import co.com.ath.pgw.util.constants.CoreConstants;
import co.com.ath.pgw.util.converter.DateUtil;
import co.com.ath.pgw.util.exception.CustomException;
/**
 * Servicio de Mapeo de objetos para los pagos AVAL
 * @author SophosSolutions
 * @version 1.0
 * @since 1.0
 */
public class MapperAddAvalTransaction {
	
	private static Logger LOGGER = LoggerFactory.getLogger(MapperAddAvalTransaction.class);
	
	/**
	 * mapeo request para los pagos AVAL.
	 * @param avalTransactionRequest
	 * @param header
	 * @return AVALPaymentAddRqType
	 */	
	public static AVALPaymentAddRqType mapperRequestToCoreRequest(AVALTransactionRequest avalTransactionRequest, Header header) throws CustomException {
		AVALPaymentAddRqType  avalPaymentAddRqType = new AVALPaymentAddRqType();
		try {
			//cabecera de request
			avalPaymentAddRqType.setRqUID(header.getRqUID());		
			avalPaymentAddRqType.setChannel(header.getChannel());		
			avalPaymentAddRqType.setIPAddr(header.getIpAddr());
			
			//fecha de la transaccion
			avalPaymentAddRqType.setClientDt(DateUtil.toXMLGregorianCalendar(new Date()));		
					
			//pmtid
			avalPaymentAddRqType.setPmtId(avalTransactionRequest.getInvoicePmtInfo().getPmtStatus().getPmtAuthId());
			
			//beneficiario - comprador
			PersonalDataType personalDataTypeBeneficiary = new PersonalDataType();
			CustNameType custNameTypePayee = new CustNameType();
			custNameTypePayee.setFirstName(avalTransactionRequest.getCustPayeeInfo().getPersonName().getFirstName());		
			custNameTypePayee.setMiddleName(avalTransactionRequest.getCustPayeeInfo().getPersonName().getMiddleName());		
			custNameTypePayee.setLastName(avalTransactionRequest.getCustPayeeInfo().getPersonName().getLastName());		
			custNameTypePayee.setSecondLastName(avalTransactionRequest.getCustPayeeInfo().getPersonName().getSecondLastName());
			personalDataTypeBeneficiary.setCustName(custNameTypePayee);
			personalDataTypeBeneficiary.setEmailAddr(avalTransactionRequest.getCustPayeeInfo().getContactInfo().getEmailAddr());
			personalDataTypeBeneficiary.setPhone(avalTransactionRequest.getCustPayeeInfo().getContactInfo().getPhoneNum().getPhone());			
			avalPaymentAddRqType.getPersonalData().add(personalDataTypeBeneficiary);
			
			UserIdType userIdType = new UserIdType();
			userIdType.setCustIdType(avalTransactionRequest.getCustPayeeInfo().getGovIssueIdent().getGovIssueIdentType());
			userIdType.setCustIdNum(avalTransactionRequest.getCustPayeeInfo().getGovIssueIdent().getIdentSerialNum());
			avalPaymentAddRqType.setUserId(userIdType);
			
			//pagador
			PersonalDataType personalDataTypePayer = new PersonalDataType();
			CustNameType custPayer = new CustNameType();
			custPayer.setLegalName(avalTransactionRequest.getCustInfo().getPersonInfo().getPersonName().getLegalName());
			custPayer.setFirstName(avalTransactionRequest.getCustInfo().getPersonInfo().getPersonName().getFirstName());
			custPayer.setMiddleName(avalTransactionRequest.getCustInfo().getPersonInfo().getPersonName().getMiddleName());
			custPayer.setLastName(avalTransactionRequest.getCustInfo().getPersonInfo().getPersonName().getLastName());
			custPayer.setSecondLastName(avalTransactionRequest.getCustInfo().getPersonInfo().getPersonName().getSecondLastName());
			custPayer.setNickName(avalTransactionRequest.getCustInfo().getPersonInfo().getPersonName().getNickname());
			personalDataTypePayer.setCustName(custPayer);
			personalDataTypePayer.setCustIdType(avalTransactionRequest.getCustInfo().getPersonInfo().getGovIssueIdent().getGovIssueIdentType());
			personalDataTypePayer.setCustIdNum(avalTransactionRequest.getCustInfo().getPersonInfo().getGovIssueIdent().getIdentSerialNum());
			personalDataTypePayer.setGender(avalTransactionRequest.getCustInfo().getPersonInfo().getGender());
			personalDataTypePayer.setBirthDt(avalTransactionRequest.getCustInfo().getPersonInfo().getBirthDt());
			personalDataTypePayer.setCityName(avalTransactionRequest.getCustInfo().getPersonInfo().getContactInfo().getPostAddr().getCity());
			personalDataTypePayer.setStateProvName(avalTransactionRequest.getCustInfo().getPersonInfo().getContactInfo().getPostAddr().getStateProv());
			personalDataTypePayer.setCountryName(avalTransactionRequest.getCustInfo().getPersonInfo().getContactInfo().getPostAddr().getCountry());
			personalDataTypePayer.setAddress(avalTransactionRequest.getCustInfo().getPersonInfo().getContactInfo().getPostAddr().getAddr1());
			personalDataTypePayer.setEmailAddr(avalTransactionRequest.getCustInfo().getPersonInfo().getContactInfo().getEmailAddr());
			personalDataTypePayer.setPhone(avalTransactionRequest.getCustInfo().getPersonInfo().getContactInfo().getPhoneNum().getPhone());				
			avalPaymentAddRqType.getPersonalData().add(personalDataTypePayer);		
	
			//convenio
			AgreementInfoType agreementInfoType = new AgreementInfoType();
			agreementInfoType.setAgreementId(avalTransactionRequest.getAgreement().getAgrmId());
			avalPaymentAddRqType.setAgreementInfo(agreementInfoType);
	
			//id de banco
			BankInfoType bankInfoType = new BankInfoType();
			bankInfoType.setBankId(avalTransactionRequest.getBankInfo().getBankId());
			avalPaymentAddRqType.setBankInfo(bankInfoType);			
			
			//id y descripcion de compra
			OrderInfoType orderInfoType = new OrderInfoType();		
			orderInfoType.setOrderId(avalTransactionRequest.getInvoicePmtInfo().getInvoiceInfo().getInvoiceNum());
			orderInfoType.setDesc(avalTransactionRequest.getInvoicePmtInfo().getInvoiceInfo().getDesc());				
			avalPaymentAddRqType.setOrderInfo(orderInfoType);			
			
			FeeType feeType = new FeeType();
			feeType.setAmt(avalTransactionRequest.getFee().getCurAmt().getAmt());
			feeType.setCurCode(avalTransactionRequest.getFee().getCurAmt().getCurCode());				
			avalPaymentAddRqType.setFee(feeType);
			
			//valor del impuesto
			TaxFeeType taxFeeType = new TaxFeeType();
			taxFeeType.setAmt(avalTransactionRequest.getTaxPmtInfo().getCurAmt().getAmt());
			taxFeeType.setCurCode(avalTransactionRequest.getTaxPmtInfo().getCurAmt().getCurCode());
			avalPaymentAddRqType.setTaxFee(taxFeeType);				
			
			//referencias
			if( avalTransactionRequest.getRefInfo() != null && !avalTransactionRequest.getRefInfo().isEmpty() ) {
				for (RefInfo refinfo : avalTransactionRequest.getRefInfo()) {
					ReferenceType referenceType = new ReferenceType();
					referenceType.setRefId(refinfo.getRefId());
					referenceType.setRefType(refinfo.getRefType());
					avalPaymentAddRqType.getReference().add(referenceType);
				}			
			}
		} catch (Exception e) {
			LOGGER.error("Error mapeando informacion ", e.getMessage());
			throw new CustomException(e.getMessage(), setCustomError(e));
		}
		return avalPaymentAddRqType;
	}	
	/**
	 * mapeo de respuesta para los pagos AVAL.
	 * @param avalPaymentAddRsType
	 * @return AVALTransactionResponse
	 */	
	public static AVALTransactionResponse mapperResponseSuccessCore(AVALPaymentAddRsType avalPaymentAddRsType) throws CustomException {
		AVALTransactionResponse avalTransactionResponse = new AVALTransactionResponse();
		try {
			PmtStatus pmtStatus = new PmtStatus();
			pmtStatus.setPmtAuthId(avalPaymentAddRsType.getPmtId());
			pmtStatus.setStatusCode(String.valueOf(avalPaymentAddRsType.getTransactionStatus().getTrnStatusCode()));
			pmtStatus.setStatusDesc(avalPaymentAddRsType.getTransactionStatus().getTrnStatusDesc());
			pmtStatus.setEffDt(DateUtil.toDate(avalPaymentAddRsType.getTransactionStatus().getEffDt()));
			pmtStatus.setNextDt(DateUtil.toDate(avalPaymentAddRsType.getTransactionStatus().getCompensationDt()));
			avalTransactionResponse.setPmtStatus(pmtStatus);
		} catch (Exception e) {
			LOGGER.error("Error mapeando informacion ", e.getMessage());
			throw new CustomException(e.getMessage(), setCustomError(e));
		}	
		return avalTransactionResponse;
	}
	/**
	 * mapeo de respuesta erronea generica para los pagos AVAL.
	 * @param avalPaymentAddRsType
	 * @return GenericErrorResponse
	 */	
	public static GenericErrorResponse mapperResponseErrorCore(AVALPaymentAddRsType avalPaymentAddRsType) {
		GenericErrorResponse genericErrorResponse = new GenericErrorResponse();
		
		Status status = new Status();
		status.setStatusCode(String.valueOf(avalPaymentAddRsType.getStatusCode()));
		status.setStatusDesc(avalPaymentAddRsType.getStatusDesc());
		status.setEndDt(Calendar.getInstance().getTime());
		
		AdditionalStatus additionalStatus = new AdditionalStatus();
		additionalStatus.setStatusCode(avalPaymentAddRsType.getTransactionStatus().getTrnServerStatusCode());
		additionalStatus.setStatusDesc(avalPaymentAddRsType.getTransactionStatus().getTrnServerStatusDesc());		
		status.setAdditionalStatus(additionalStatus);
		
		MsgRsHdr msgRsHdr = new MsgRsHdr();
		msgRsHdr.setStatus(status);
		msgRsHdr.setEndDt(Calendar.getInstance().getTime());
		genericErrorResponse.setMsgRsHdr(msgRsHdr);
		
		return genericErrorResponse;
	}
	/**
	 * mapeo de respuesta erronea para los pagos AVAL.
	 * @param exception
	 * @return AVALPaymentAddRsType
	 */	
	public static AVALPaymentAddRsType setCustomError(Exception e){
		AVALPaymentAddRsType avalPaymentAddRsType = new AVALPaymentAddRsType();
		avalPaymentAddRsType.setStatusCode(CoreConstants.ERROR_STATUS_CODE_300);
		avalPaymentAddRsType.setStatusDesc(CoreConstants.ERROR_STATUS_CODE_DESC);
		
		TransactionStatusType transactionStatusType = new TransactionStatusType();
		transactionStatusType.setTrnStatusCode(Long.valueOf(CoreConstants.ERROR_STATUS_CODE_300));
		transactionStatusType.setTrnStatusDesc(CoreConstants.ERROR_STATUS_CODE_DESC);
		transactionStatusType.setTrnServerStatusCode(CoreConstants.ERROR_STATUS_CODE_300.toString());
		transactionStatusType.setTrnServerStatusDesc(e.toString());
		avalPaymentAddRsType.setTransactionStatus(transactionStatusType);
		return avalPaymentAddRsType;
	}
	
}