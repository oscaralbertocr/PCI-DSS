package co.com.ath.pgw.bsn.service.impl;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

import javax.annotation.Resource;
import javax.persistence.NoResultException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;
/*
import co.com.ath.pgw.adaptive.auth.bsn.service.AdaptiveAuthenticationService;
import co.com.ath.pgw.adaptive.auth.rsa.csd.ws.ActionCode;
import co.com.ath.pgw.adaptive.auth.rsa.csd.ws.AnalyzeResponse;
import co.com.ath.pgw.adaptive.auth.rsa.csd.ws.CreateUserResponse;
import co.com.ath.pgw.adaptive.auth.rsa.csd.ws.RunRiskType;
import co.com.ath.pgw.adaptive.auth.rsa.csd.ws.TriggeredRule;
import co.com.ath.pgw.adaptive.auth.rsa.csd.ws.UserStatus;
*/
import co.com.ath.pgw.bsn.dto.in.AddAVALPaymentInDTO;
import co.com.ath.pgw.bsn.dto.out.AddAVALPaymentOutDTO;
import co.com.ath.pgw.bsn.service.PGWAvalPaymentService;
import co.com.ath.pgw.persistence.dao.BankDAO;
import co.com.ath.pgw.persistence.dao.BlackListDAO;
import co.com.ath.pgw.persistence.dao.BlackListIpDAO;
import co.com.ath.pgw.persistence.dao.CommerceDAO;
import co.com.ath.pgw.persistence.dao.PaymentWayDAO;
import co.com.ath.pgw.persistence.dao.ResponseCodeDAO;
import co.com.ath.pgw.persistence.dao.TopDAO;
import co.com.ath.pgw.persistence.dao.TransactionDAO;
import co.com.ath.pgw.persistence.dao.TransactionStatusDAO;
import co.com.ath.pgw.persistence.model.BlackList;
import co.com.ath.pgw.persistence.model.BlackListIp;
import co.com.ath.pgw.persistence.model.PaymentWay;
import co.com.ath.pgw.persistence.model.ResponseCode;
import co.com.ath.pgw.persistence.model.Top;
import co.com.ath.pgw.persistence.model.Transaction;
import co.com.ath.pgw.persistence.service.SendMailService;
import co.com.ath.pgw.util.constants.CoreConstants;
import co.com.ath.pgw.util.constants.PaymentWayCodes;
import co.com.ath.pgw.util.converter.Util;
import co.com.ath.pgw.util.enums.ResponseCodeEnum;
import co.com.ath.pgw.util.enums.TransactionStatusEnum;
import co.com.ath.pgw.util.i18n.BundleKeys;
import co.com.ath.pgw.util.i18n.BundleType;
import co.com.ath.pgw.util.i18n.ResourceBundleManager;
import co.com.ath.pgw.util.validation.ValidationException;
import co.com.ath.pgw.util.validation.model.AddAVALPaymentValidator;


/**
 * Implementación de servicio para pagar mediante Aval.
 * @version 0.0.0 22/07/2019
 * @author SophosSolutions
 */
/*
 * 
* @RQ28816
* <strong>Autor</strong> Silverio Bonilla Celis </br>
* <strong>Descripcion</strong> Modificación Baloto </br>
* <strong>Número de Cambios</strong> 1</br>
* <strong>Identificador corto</strong> C01</br>
* 
* @IM717218
*  <strong>Autor</strong>Camilo Bustamante</br>
*  <strong>Descripcion</strong>Validación Consumo Banco</br>
*  <strong>Numero de Cambios</strong>3</br>
*  <strong>Identificador corto</strong>C06</br>
* 
* @IM19113 
*  <strong>Autor</strong>Henry Hernandez</br>
*  <strong>Descripcion</strong>Validación Doble Pago TC y Aval</br>
*  <strong>Numero de Cambios</strong>2</br>
*  <strong>Identificador corto</strong>C09</br>
* 
* <strong>Autor</strong>Edwin Alexander Bohorquez</br>
* <strong>Descripcion</strong>Motor de riesgo</br>
* <strong>Número de Cambios</strong>3</br>
* <strong>Identificador corto</strong>C10</br>
* 
* <strong>Autor</strong>Edwin Alexander Bohorquez</br>
* <strong>Descripcion</strong>Desagregacion de Motor de riesgo</br>
* <strong>Número de Cambios</strong>1</br>
* <strong>Identificador corto</strong>C11</br>
* 
*/
@Service
public class PGWAvalPaymentServiceImpl implements PGWAvalPaymentService{

	static Logger LOGGER = LoggerFactory.getLogger(PGWAvalPaymentServiceImpl.class);	
	
	@Resource
	private ResourceBundleManager resourceBundleManager;
	
	@Resource
	public TransactionDAO transactionDAO;
	
	@Resource
	public PaymentWayDAO paymentWayDAO;
	
	@Resource
	public CommerceDAO commerceDAO;
	
	@Resource
	private BankDAO bankDAO;
	
	@Resource
	private AddAVALPaymentValidator addAVALPaymentValidator;
	
	@Resource
	public BlackListDAO blackListDAO;
	
	@Resource
	public BlackListIpDAO blackListIpDAO;
	
	@Resource
	public TransactionStatusDAO transactionStatusDAO;
	
	@Resource
	public ResponseCodeDAO responseCodeDAO;
	
	@Resource
	private TopDAO topesDAO;
	
	@Resource
	private SendMailService sendMailService; 
	
	/** información de localización */
    public Locale locale;
	
    /** INI-C10**/  
    /*
	@Resource
	private AdaptiveAuthenticationService adaptiveAuthenticationService;
	*/
    /** FIN-C10**/
    
    public PGWAvalPaymentServiceImpl(){
    	this.locale = Locale.getDefault();    	
    }
    
	@Override
	public AddAVALPaymentOutDTO addAVALPayment(AddAVALPaymentInDTO addAVALPaymentInDTO) throws Exception{
		AddAVALPaymentOutDTO addAVALPaymentOutDTO = new AddAVALPaymentOutDTO();
		addAVALPaymentOutDTO.setRqUID(addAVALPaymentInDTO.getRqUID());
		addAVALPaymentOutDTO.setStatusCode(CoreConstants.SUCCESS_STATUS_CODE);
		addAVALPaymentOutDTO.setStatusDesc(getMessage(BundleKeys.TRANSACTION_SUCCESS, null, locale));
		
		// Validar la información de entrada
		try {
			addAVALPaymentValidator.validate(addAVALPaymentInDTO);
		} catch (ValidationException ex) {
			addAVALPaymentOutDTO.setStatusCode(CoreConstants.ERROR_DATA_VALIDATION_CODE);
			addAVALPaymentOutDTO.setStatusDesc(ex.getMessage());
			addAVALPaymentOutDTO.setTrnServerStatusCode(String.valueOf(ex.getErrorCode()));
			if(ex.getCause() != null){
				addAVALPaymentOutDTO.setTrnServerStatusDesc(ex.getCause().getMessage());
			} else {
				addAVALPaymentOutDTO.setTrnServerStatusDesc(ex.getMessage());
			}
			addAVALPaymentOutDTO.setPmtId(addAVALPaymentInDTO.getTransactionBO().getPmtId());
			return addAVALPaymentOutDTO;
		}
		/** INI C01 **/

		Transaction transaction = transactionDAO.findByPmtId(Long.valueOf(addAVALPaymentInDTO.getTransactionBO().getPmtId()));
		
		try {
			
			 /*INICIO-C09**/				
			//VALIDACIÓN DOBLE CLICK PAGOS AVAL
			if(transaction.getPaymentWay().getId().equals(PaymentWayCodes.PAGOS_AVAL)){
				LOGGER.info("...ERROR DOBLE CLICK BOTON PAGAR AVAL");
				addAVALPaymentOutDTO.setStatusCode(CoreConstants.ERROR_STATUS_CODE_300);
				addAVALPaymentOutDTO.setStatusDesc(CoreConstants.ERROR_STATUS_PROCESING_AVAL);
				addAVALPaymentOutDTO.setTrnStatusCode(Long.valueOf(CoreConstants.ERROR_STATUS_CODE_300));
				addAVALPaymentOutDTO.setTrnStatusDesc(CoreConstants.ERROR_STATUS_PROCESING_AVAL);
				addAVALPaymentOutDTO.setTrnServerStatusCode(null); 
				addAVALPaymentOutDTO.setTrnServerStatusDesc(null); 
				addAVALPaymentOutDTO.setEffDt(transaction.getPayDate());
				addAVALPaymentOutDTO.setCompensationDate(transaction.getCompensationDate());
				addAVALPaymentOutDTO.setApprovalId(transaction.getApprovalNumber());
		        return addAVALPaymentOutDTO;
			}
			/*FIN-C09**/
			
			transaction.setPaymentWay(paymentWayDAO.read(PaymentWayCodes.PAGOS_AVAL));
			if (addAVALPaymentInDTO.getTransactionBO().getTermsNConditions() != null
					&& !addAVALPaymentInDTO.getTransactionBO().getTermsNConditions().isEmpty()) {
				transaction.setTermsAndConditions(Boolean.parseBoolean(addAVALPaymentInDTO.getTransactionBO().getTermsNConditions()));
			}
			
			/**INICIO-C06**/
			/* Si es convenio CPV o convenio Obligacion, el banco recaudador de la transaccion
			 * es  el banco que corresponde al convenio. */
			if( Util.esConvenioCPV(transaction.getCommerce().getNuraCode()) 
					|| Util.esConvenioObligacion(transaction.getCommerce().getNuraCode()) ) {
				transaction.setBankCollecter(transaction.getCommerce().getSubscription().getBank());
			} else
			/**FIN-C06**/
			/*INICIO C01*/
			if(addAVALPaymentInDTO.getTransactionBO().getCommerce() != null && addAVALPaymentInDTO.getTransactionBO().getBank() != null){
				String tc = commerceDAO.findByNura(addAVALPaymentInDTO.getTransactionBO().getCommerce().getNuraCode()).getCreditCardInd();
				if (tc.equals(CoreConstants.VALIDATOR_TC)){
					transaction.setBankCollecter(bankDAO.findByAVALCode(addAVALPaymentInDTO.getTransactionBO().getBank().getAvalCode()));
				}
			}
			/*FIN C01*/	
			
			//validacion de Topes
			if (!validateTopByCommerceAndPaymentWay(transaction, paymentWayDAO.read(PaymentWayCodes.PAGOS_AVAL))) {
				
				//Si no pasa la validacion de Topes
				setTopesError(addAVALPaymentOutDTO, transaction);
				
			} else { 
				
				transaction.setBank(bankDAO.findByAVALCode(addAVALPaymentInDTO.getTransactionBO().getBank().getAvalCode()));
				transaction.setCustomerDocType(addAVALPaymentInDTO.getTransactionBO().getCustomerDocType());
				transaction.setCustomerDocId(addAVALPaymentInDTO.getTransactionBO().getCustomerDocId());
				transaction.setIpAddress(addAVALPaymentInDTO.getTransactionBO().getIpAddress());
				transaction.setResponseCode(null);
		
				if (addAVALPaymentInDTO.getTransactionBO().getCustomerName() != null
						&& !addAVALPaymentInDTO.getTransactionBO().getCustomerName().isEmpty()) {
					transaction.setCustomerName(addAVALPaymentInDTO.getTransactionBO().getCustomerName());
				}
		
				//Cambio Nombre Duplicado INI
				
				if (addAVALPaymentInDTO.getTransactionBO().getCustomerName() != null && !addAVALPaymentInDTO.getTransactionBO().getCustomerName().isEmpty() && !addAVALPaymentInDTO.getTransactionBO().getCustomerName().equals("GUEST"))					
				{
					transaction.setPayerName(addAVALPaymentInDTO.getTransactionBO().getFirstNamePayer());
					transaction.setMiddleNamePayer("");
					transaction.setLastNamePayer("");
					transaction.setSecondLastNamePayer("");
				}
				//CCambio Nombre Duplicado FIN
		        if (addAVALPaymentInDTO.getTransactionBO().getMiddleNameBuyer() != null
						&& !addAVALPaymentInDTO.getTransactionBO().getMiddleNameBuyer().isEmpty()) {
		        	transaction.setMiddleNameBuyer(addAVALPaymentInDTO.getTransactionBO().getMiddleNameBuyer());
				}
				
				if (addAVALPaymentInDTO.getTransactionBO().getLastNameBuyer() != null
						&& !addAVALPaymentInDTO.getTransactionBO().getLastNameBuyer().isEmpty()) {
					transaction.setLastNameBuyer(addAVALPaymentInDTO.getTransactionBO().getLastNameBuyer());
				}
				
				if (addAVALPaymentInDTO.getTransactionBO().getSecondLastNameBuyer() != null
						&& !addAVALPaymentInDTO.getTransactionBO().getSecondLastNameBuyer().isEmpty()) {
					transaction.setSecondLastNameBuyer(addAVALPaymentInDTO.getTransactionBO().getSecondLastNameBuyer());
				}
				if (addAVALPaymentInDTO.getTransactionBO().getCustomerEmail() != null
						&& !addAVALPaymentInDTO.getTransactionBO().getCustomerEmail().isEmpty()) {
					transaction.setCustomerEmail(addAVALPaymentInDTO.getTransactionBO().getCustomerEmail());
				}
		
				if (addAVALPaymentInDTO.getTransactionBO().getCustomerMobileNumber() != null
						&& !addAVALPaymentInDTO.getTransactionBO().getCustomerMobileNumber().isEmpty()) {
					transaction.setCustomerMobileNumber(addAVALPaymentInDTO.getTransactionBO().getCustomerMobileNumber());
				}
				
				//información del pagador
				if(addAVALPaymentInDTO.getTransactionBO().getPayerCompany() != null 
						&& !addAVALPaymentInDTO.getTransactionBO().getPayerCompany().isEmpty()) {
					transaction.setPayerCompany(addAVALPaymentInDTO.getTransactionBO().getPayerCompany());
				}
				
				if(addAVALPaymentInDTO.getTransactionBO().getFirstNamePayer() != null
						&& !addAVALPaymentInDTO.getTransactionBO().getFirstNamePayer().isEmpty()) {
					transaction.setPayerName(addAVALPaymentInDTO.getTransactionBO().getFirstNamePayer());
		
				}
				
				if(addAVALPaymentInDTO.getTransactionBO().getMiddleNamePayer() != null
						&& !addAVALPaymentInDTO.getTransactionBO().getMiddleNamePayer().isEmpty()) {
					transaction.setMiddleNamePayer(addAVALPaymentInDTO.getTransactionBO().getMiddleNamePayer());
				}
				
				if(addAVALPaymentInDTO.getTransactionBO().getLastNamePayer() != null
						&& !addAVALPaymentInDTO.getTransactionBO().getLastNamePayer().isEmpty()) {
					transaction.setLastNamePayer(addAVALPaymentInDTO.getTransactionBO().getLastNamePayer());
				}
				
				if(addAVALPaymentInDTO.getTransactionBO().getSecondLastNamePayer() != null
						&& !addAVALPaymentInDTO.getTransactionBO().getSecondLastNamePayer().isEmpty()) {
					transaction.setSecondLastNamePayer(addAVALPaymentInDTO.getTransactionBO().getSecondLastNamePayer());
				}
				
				if(addAVALPaymentInDTO.getTransactionBO().getPayerNickName() != null 
						&& !addAVALPaymentInDTO.getTransactionBO().getPayerNickName().isEmpty()) {
					transaction.setPayerNickName(addAVALPaymentInDTO.getTransactionBO().getPayerNickName());
				}
				
				if(addAVALPaymentInDTO.getTransactionBO().getPayerDocType() != null 
						&& !addAVALPaymentInDTO.getTransactionBO().getPayerDocType().isEmpty()) {
					transaction.setPayerDocType(addAVALPaymentInDTO.getTransactionBO().getPayerDocType());
				}
		
				if(addAVALPaymentInDTO.getTransactionBO().getPayerDocId() != null 
						&& !addAVALPaymentInDTO.getTransactionBO().getPayerDocId().isEmpty()) {
					transaction.setPayerDocId(addAVALPaymentInDTO.getTransactionBO().getPayerDocId());
				}
				
				if(addAVALPaymentInDTO.getTransactionBO().getPayerGender() != null 
						&& !addAVALPaymentInDTO.getTransactionBO().getPayerGender().isEmpty()) {
					transaction.setPayerGender(addAVALPaymentInDTO.getTransactionBO().getPayerGender());
				}
				
				if(addAVALPaymentInDTO.getTransactionBO().getPayerBirthDate() != null 
						&& addAVALPaymentInDTO.getTransactionBO().getPayerBirthDate().toString() != "") {
					transaction.setPayerBirthDate(addAVALPaymentInDTO.getTransactionBO().getPayerBirthDate());
				}
				
				if(addAVALPaymentInDTO.getTransactionBO().getPayerCity() != null 
						&& !addAVALPaymentInDTO.getTransactionBO().getPayerCity().isEmpty()) {
					transaction.setPayerCity(addAVALPaymentInDTO.getTransactionBO().getPayerCity());
				}
				
				if(addAVALPaymentInDTO.getTransactionBO().getPayerDepartment() != null 
						&& !addAVALPaymentInDTO.getTransactionBO().getPayerDepartment().isEmpty()) {
					transaction.setPayerDepartment(addAVALPaymentInDTO.getTransactionBO().getPayerDepartment());
				}
				
				if(addAVALPaymentInDTO.getTransactionBO().getPayerCountry() != null 
						&& !addAVALPaymentInDTO.getTransactionBO().getPayerCountry().isEmpty()) {
					transaction.setPayerCounty(addAVALPaymentInDTO.getTransactionBO().getPayerCountry());
				}
				
				if(addAVALPaymentInDTO.getTransactionBO().getPayerAddress() != null
						&& !addAVALPaymentInDTO.getTransactionBO().getPayerAddress().isEmpty()) { 
					transaction.setPayerAddress(addAVALPaymentInDTO.getTransactionBO().getPayerAddress());
				}
				
				if(addAVALPaymentInDTO.getTransactionBO().getPayerMail() != null 
						&& !addAVALPaymentInDTO.getTransactionBO().getPayerMail().isEmpty()) {
					transaction.setPayerMail(addAVALPaymentInDTO.getTransactionBO().getPayerMail());
				}
				
				if(addAVALPaymentInDTO.getTransactionBO().getPayerPhone() != null 
						&& !addAVALPaymentInDTO.getTransactionBO().getPayerPhone().isEmpty()) {
					transaction.setPayerPhone(addAVALPaymentInDTO.getTransactionBO().getPayerPhone());
				}
		
				List<BlackList> blackListBuyer = new ArrayList<BlackList>();
				List<BlackList> blackListPayer = new ArrayList<BlackList>();
				List<BlackListIp> blackListIp = new ArrayList<BlackListIp>();		
		
				//Validacion de listas negras
				blackListBuyer = blackListDAO.findByDocument(addAVALPaymentInDTO.getTransactionBO().getCustomerDocType(),addAVALPaymentInDTO.getTransactionBO().getCustomerDocId());
				blackListPayer = blackListDAO.findByDocument(transaction.getPayerDocType(),transaction.getPayerDocId());
				blackListIp = blackListIpDAO.findByIp(addAVALPaymentInDTO.getTransactionBO().getIpAddress());
		
				//Si la transaccion se cataloga como Listas Negras
				if(blackListBuyer.size() > 0 || blackListPayer.size() > 0 || blackListIp.size() > 0){
					
					//Flujo de Listas Negras
					addAVALPaymentOutDTO = avalBlackListFlow(addAVALPaymentOutDTO, transaction, blackListIp.size());
					
				} 
				/** INICIO-C10 **/		
				/*
				else {
										
					 //RQ25510 Motor de Riesgo.
					 //Actualiza la informacion de la transaccion inicialmente
					  					 
					transactionDAO.update(tx);
					
					// Realiza consulta Analyze a RSA
					AnalyzeResponse analyzeRsaOutDTO = null;
					try {
						analyzeRsaOutDTO = adaptiveAuthenticationService.analyze(inDTO.getTransactionBO(), RunRiskType.RISK_ONLY);
					} catch (Exception ex) {
						LOGGER.error("@PGWPaymentServiceImpl addAVALPayment Ocurrio un error en Motor de Riesgo. {}", ex.getLocalizedMessage());
						
						//Garantiza que el servicio del core (transaccion) continua sin afectacion.
						analyzeRsaOutDTO = adaptiveAuthenticationService.getAnalyzeDummy(); 
					}
		
					UserStatus userStatus = analyzeRsaOutDTO.getIdentificationData().getUserStatus();
					TriggeredRule triggeredRule = analyzeRsaOutDTO.getRiskResult().getTriggeredRule();
					
					if ( triggeredRule.getActionCode().getValue().equals(ActionCode.DENY.getValue()) ) {
						
						LOGGER.info("@PGWPaymentServiceImpl addAVALPayment pmtid: {} "
								+ "Motor de Riesgo retorno ActionCode {}. Se rechaza como lista negra.", tx.getPmtId(), ActionCode.DENY);
		
						try {
							analyzeRsaOutDTO = adaptiveAuthenticationService.analyze(inDTO.getTransactionBO(),RunRiskType.ALL);
						} catch (Exception e) {
							LOGGER.error("@PGWPaymentServiceImpl addAVALPayment Ocurrio un error en Motor de Riesgo. {}", e.getLocalizedMessage());
						}
						
						//Flujo de Listas Negras
						outDTO = avalBlackListFlow(outDTO, tx, blackListIp.size());
							
					} else if (userStatus == UserStatus.NOTENROLLED || userStatus == UserStatus.VERIFIED) {
		
						if (userStatus == UserStatus.NOTENROLLED) {
								
							CreateUserResponse cur;
							try {
								cur = adaptiveAuthenticationService.createUser(inDTO.getTransactionBO());
							} catch (Exception e) {
								LOGGER.error("@PGWPaymentServiceImpl addAVALPayment Ocurrio un error en Motor de Riesgo. {}", e.getLocalizedMessage());
								//Garantiza que el servicio del core (transaccion) continua sin afectacion.
								cur = adaptiveAuthenticationService.getCreateUserDummy();
							}
								
							userStatus = cur.getIdentificationData().getUserStatus();
							triggeredRule = cur.getRiskResult().getTriggeredRule();
						}
		
						if ( triggeredRule.getActionCode().getValue().equals(ActionCode.DENY.getValue()) ) {
							
							LOGGER.info("@PGWPaymentServiceImpl addAVALPayment pmtid: {} "
									+ "Motor de Riesgo retorno ActionCode {}. Se rechaza como lista negra.", tx.getPmtId(), ActionCode.DENY);
		
							try {
								analyzeRsaOutDTO = adaptiveAuthenticationService.analyze(inDTO.getTransactionBO(),RunRiskType.ALL);
							} catch (Exception e) {
								LOGGER.error("@PGWPaymentServiceImpl addAVALPayment Ocurrio un error en Motor de Riesgo. {}", e.getLocalizedMessage());
							}
		
							//Flujo de Listas Negras
							outDTO = avalBlackListFlow(outDTO, tx, blackListIp.size());
						
						} else if (userStatus.equals(UserStatus.VERIFIED)) {
		
							tx.setStatus(transactionStatusDAO.findById(TransactionStatusEnum.PROCESSING.getCode()));
							transactionDAO.update(tx);
							outDTO.setPmtId(tx.getPmtId()+"");
							outDTO.setTrnStatusCode(tx.getStatus().getBusinessCode().getCode());
							outDTO.setTrnStatusDesc(getMessage(tx.getStatus().getBusinessCode().getDescription().getMessageCode(), null, locale));
							outDTO.setTrnServerStatusCode(null);
							outDTO.setTrnServerStatusDesc(null);
							outDTO.setEffDt(tx.getPayDate());
							outDTO.setCompensationDate(tx.getCompensationDate());
							outDTO.setApprovalId(tx.getApprovalNumber());
		
						} else {
							LOGGER.error("@PGWPaymentServiceImpl addAVALPayment {} \n", CoreConstants.RSA_USER_STATUS_ERROR);
							outDTO = rsaError(outDTO, tx, CoreConstants.RSA_USER_STATUS_ERROR);
						}
		
					} else {
							
						LOGGER.error("@PGWPaymentServiceImpl addAVALPayment {} \n", CoreConstants.RSA_USER_STATUS_ERROR);
							
						//Garantiza que el servicio del core (transaccion) continua sin afectacion.
						tx.setStatus(transactionStatusDAO.findById(TransactionStatusEnum.PROCESSING.getCode()));
						transactionDAO.update(tx);
						outDTO.setPmtId(tx.getPmtId()+"");
						outDTO.setTrnStatusCode(tx.getStatus().getBusinessCode().getCode());
						outDTO.setTrnStatusDesc(getMessage(tx.getStatus().getBusinessCode().getDescription().getMessageCode(), null, locale));
						outDTO.setTrnServerStatusCode(null);
						outDTO.setTrnServerStatusDesc(null);
						outDTO.setEffDt(tx.getPayDate());
						outDTO.setCompensationDate(tx.getCompensationDate());
						outDTO.setApprovalId(tx.getApprovalNumber());
						
					}
				}	
				*/	
				/** FIN-C10 **/
				
				/** INICIO-C11 **/
				//Garantiza que el servicio del core (transaccion) continua sin afectacion.
				transaction.setStatus(transactionStatusDAO.findById(TransactionStatusEnum.PROCESSING.getCode()));
				transactionDAO.update(transaction);
				addAVALPaymentOutDTO.setPmtId(transaction.getPmtId()+"");
				addAVALPaymentOutDTO.setTrnStatusCode(transaction.getStatus().getBusinessCode().getCode());
				addAVALPaymentOutDTO.setTrnStatusDesc(getMessage(transaction.getStatus().getBusinessCode().getDescription().getMessageCode(), null, locale));
				addAVALPaymentOutDTO.setTrnServerStatusCode(null);
				addAVALPaymentOutDTO.setTrnServerStatusDesc(null);
				addAVALPaymentOutDTO.setEffDt(transaction.getPayDate());
				addAVALPaymentOutDTO.setCompensationDate(transaction.getCompensationDate());
				addAVALPaymentOutDTO.setApprovalId(transaction.getApprovalNumber());
				/** FIN-C11 **/
			} 
			
		} catch (NoResultException e) {
			LOGGER.error("No se pudo realizar la transaccion con el RQ'" + (addAVALPaymentInDTO.getRqUID()) + "' "
					+ "Problemas con la conexion en BD del Core Pasarela. Exception:{}\nCause:{} ");
			System.err.println(e.getMessage());
			addAVALPaymentOutDTO.setStatusCode(CoreConstants.ERROR_STATUS_CODE_300);
			addAVALPaymentOutDTO.setStatusDesc(CoreConstants.ERROR_STATUS_CODE_DESC_300);
			addAVALPaymentOutDTO.setTrnStatusCode(Long.valueOf(CoreConstants.FAULT_STATUS_CODE));
			addAVALPaymentOutDTO.setTrnStatusDesc(CoreConstants.FAULT_STATUS_ERROR_DESC);
			addAVALPaymentOutDTO.setTrnServerStatusCode(String.valueOf(CoreConstants.FAULT_STATUS_CODE));
			addAVALPaymentOutDTO.setTrnServerStatusDesc(CoreConstants.FAULT_STATUS_DESC);
		}
		/** FIN C01 **/
		
		/** INICIO-C10 **/	
		/*
		outDTO.setToken(adaptiveAuthenticationService.getLastTokenCookie( inDTO.getTransactionBO().getPmtId() ));
		*/
		/** FIN-C10 **/
		
		return addAVALPaymentOutDTO;
	}

	
	private AddAVALPaymentOutDTO avalBlackListFlow(
			AddAVALPaymentOutDTO addAVALPaymentOutDTO, Transaction transaction, int blackListIpSize) {
				
		transaction.setStatus(transactionStatusDAO.findById(TransactionStatusEnum.CANCELLED.getCode()));
		transaction.setResponseCode(getFraudResponseCode(blackListIpSize));
		transactionDAO.update(transaction);

		// Leer Estado TX -- Envio de Correo Electrónico
		Transaction txdata = transactionDAO.read(transaction.getId());
		if(txdata.getEmailflag()==CoreConstants.FLAG_EMAIL_OFF){
			
			transaction.setEmailflag(CoreConstants.FLAG_EMAIL_ON);
			transactionDAO.update(transaction);
			
			sendMailService.sendMail(transaction); 
		}

		addAVALPaymentOutDTO.setPmtId(transaction.getPmtId()+"");
		addAVALPaymentOutDTO.setStatusCode(CoreConstants.ERROR_DATA_SECURITY_CODE);
		addAVALPaymentOutDTO.setStatusDesc(CoreConstants.ERROR_DATA_SECURITY_CODE_DESC);
		addAVALPaymentOutDTO.setTrnStatusCode(Long.valueOf(CoreConstants.ERROR_DATA_SECURITY_CODE));
		addAVALPaymentOutDTO.setTrnStatusDesc(CoreConstants.ERROR_DATA_SECURITY_CODE_DESC);
		addAVALPaymentOutDTO.setTrnServerStatusCode(null); 
		addAVALPaymentOutDTO.setTrnServerStatusDesc(null); 
		addAVALPaymentOutDTO.setEffDt(transaction.getPayDate());
		addAVALPaymentOutDTO.setCompensationDate(transaction.getCompensationDate());
		addAVALPaymentOutDTO.setApprovalId(transaction.getApprovalNumber());
		
		return addAVALPaymentOutDTO;
	}		
	
	public ResponseCode getFraudResponseCode(int blackListIpFound) {
		if(blackListIpFound == 1) {
			LOGGER.info("Validación Listas Negras Fallida: " + ResponseCodeEnum.NOT_AUTHORIZED_FRAUD_IP.toString());
			return responseCodeDAO.read(ResponseCodeEnum.NOT_AUTHORIZED_FRAUD_IP.toString());
		} else {
			LOGGER.info("Validación Listas Negras Fallida: " + ResponseCodeEnum.NOT_AUTHORIZED_FRAUD_DOC.toString());
			return responseCodeDAO.read(ResponseCodeEnum.NOT_AUTHORIZED_FRAUD_DOC.toString());
		}
	}
	
	private AddAVALPaymentOutDTO setTopesError(AddAVALPaymentOutDTO addAVALPaymentOutDTO, Transaction transaction) {
		
		ResponseCode responseCode = responseCodeDAO.read(CoreConstants.TOP_ERROR_CODE);
		
		/**INICIO-C04**/
		transaction.setStatus(transactionStatusDAO.findById(TransactionStatusEnum.REFUSED.getCode()));
		/**FIN-C04**/
		transaction.setResponseCode(responseCode);
		transactionDAO.update(transaction);
		
		LOGGER.error("@addAVALTransaction {} ", transaction.getResponseCode().getDescription());

		// Leer Envio de Correo Electrónico
		Transaction transactionData = transactionDAO.read(transaction.getId());
		if(transactionData.getEmailflag()==CoreConstants.FLAG_EMAIL_OFF){
			
			transaction.setEmailflag(CoreConstants.FLAG_EMAIL_ON);
			transactionDAO.update(transaction);
			
			sendMailService.sendMail(transaction); 
		}
				
		addAVALPaymentOutDTO.setStatusCode(Integer.parseInt(transaction.getResponseCode().getCode()));
		addAVALPaymentOutDTO.setStatusDesc(transaction.getResponseCode().getDescription());
		addAVALPaymentOutDTO.setTrnStatusCode(CoreConstants.SUCCESS_STATUS_CODE.longValue());
		addAVALPaymentOutDTO.setTrnStatusDesc(getMessage(BundleKeys.TRANSACTION_SUCCESS, null, locale));
		addAVALPaymentOutDTO.setTrnServerStatusCode(CoreConstants.SUCCESS_STATUS_CODE.toString());
		addAVALPaymentOutDTO.setTrnServerStatusDesc(getMessage(BundleKeys.TRANSACTION_SUCCESS, null, locale));
		addAVALPaymentOutDTO.setEffDt(transaction.getPayDate());
		addAVALPaymentOutDTO.setCompensationDate(transaction.getCompensationDate());
		addAVALPaymentOutDTO.setApprovalId(transaction.getApprovalNumber());
		
		return addAVALPaymentOutDTO;		
	}
	
	public boolean validateTopByCommerceAndPaymentWay(Transaction transaction, PaymentWay paymentWay) throws Exception {
		
		boolean isActive = true;
//		long txValue, tpMin, tpMax;
		
		try {
			
			Top topePermanente = topesDAO.findTopPermanentTran(transaction.getCommerce().getId(), paymentWay.getId(), transaction.getTotalValue());
			
			if(topePermanente != null)
				return false;
			
			Top topeFecha = topesDAO.findTopByDateTran(transaction.getCommerce().getId(), paymentWay.getId(), transaction.getTotalValue());
			
			if(topeFecha != null)
				return false;
			
//			if(topes != null && !topes.isEmpty()){
//				isActive = Boolean.TRUE;
//			}
//			List<Top> tp = topesDAO.findByCommerceAndPaymentWay(tx.getCommerce().getId(), paymentWay.getId());
//			if (tp != null) {
//				if (tp.getTopPermanent() != 0) {
//					txValue = tx.getTotalValue().longValue();
//					tpMin = tp.getTopMin().longValue();
//					tpMax = tp.getTopMax().longValue();
//					if (txValue > tpMin && txValue < tpMax) {
//						isActive = true;
//					}
//				} else {
//					if (tp.getBeginDate().before(tx.getTransactionDate())
//							&& tp.getEndDate().after(tx.getTransactionDate())) {
//						txValue = tx.getTotalValue().longValue();
//						tpMin = tp.getTopMin().longValue();
//						tpMax = tp.getTopMax().longValue();
//						if (txValue > tpMin && txValue < tpMax) {
//							isActive = true;
//						}
//					}
//				}
//			} else {
//				isActive = true;
//			}
		} catch (NoResultException e) {
			LOGGER.error("@validateTopByCommerceAndPaymentWay TopesError");		
			throw e;
		}
		return isActive;
	}
	
	public String getMessage(String messageKey, Object[] args, Locale locale) {
		if (resourceBundleManager == null) {
			return messageKey;
		}
		resourceBundleManager.setBundle(BundleType.MESSAGES);
		return resourceBundleManager.getMessage(messageKey, args, locale);
	}
	
	private AddAVALPaymentOutDTO rsaError(AddAVALPaymentOutDTO addAVALPaymentOutDTO,
			Transaction transaction, String exceptionCode) {
		
		String codigoError = getRsaResponseCode(CoreConstants.RSA_ERROR).getDescription();
		
		transaction.setStatus(transactionStatusDAO.findById(TransactionStatusEnum.FAILED.getCode()));
		transaction.setResponseCode(getRsaResponseCode(exceptionCode));
		transactionDAO.update(transaction);
		
		LOGGER.error("@AdaptiveAuthentication rsaError, Descripcion: {} ", transaction.getResponseCode().getDescription());

		// Envio de correo
		sendMailService.sendMail(transaction);
		
		addAVALPaymentOutDTO.setPmtId(transaction.getPmtId().toString());
		addAVALPaymentOutDTO.setStatusCode(Integer.parseInt(codigoError));
		addAVALPaymentOutDTO.setStatusDesc(transaction.getResponseCode().getDescription());
		addAVALPaymentOutDTO.setTrnStatusCode(null);
		addAVALPaymentOutDTO.setTrnStatusDesc(null);
		addAVALPaymentOutDTO.setTrnServerStatusCode(codigoError.toString());
		addAVALPaymentOutDTO.setTrnServerStatusDesc(CoreConstants.ERROR_STATUS_CODE_DESC);
		addAVALPaymentOutDTO.setEffDt(transaction.getPayDate());
		addAVALPaymentOutDTO.setCompensationDate(transaction.getCompensationDate());
		addAVALPaymentOutDTO.setApprovalId(transaction.getApprovalNumber());
		
		return addAVALPaymentOutDTO;
	}
	
	public ResponseCode getRsaResponseCode(String errorCode) {

		if (errorCode.equals(CoreConstants.RSA_DEVICE_PRINT_NOT_FOUND)) {
			LOGGER.info("No se encontro el DevicePrint en trama de entrada");
			return responseCodeDAO.read(CoreConstants.RSA_DEVICE_PRINT_NOT_FOUND);
		} else if (errorCode.equals(CoreConstants.RSA_SWITCH_ERROR)) {
			LOGGER.info("No se encuentra bien configurado el switch de motor de riesgo");
			return responseCodeDAO.read(CoreConstants.RSA_SWITCH_ERROR);
		} else if (errorCode.equals(CoreConstants.RSA_SERVICE_ERROR)) {
			LOGGER.info("Ocurrio un error en el servicio de motor de riesgo");
			return responseCodeDAO.read(CoreConstants.RSA_SERVICE_ERROR);
		}else if (errorCode.equals(CoreConstants.RSA_ERROR)) {
			return responseCodeDAO.read(CoreConstants.RSA_ERROR);
		} else {
			LOGGER.info("No se encontro el DeviceTokenCookie en trama de entrada");
			return responseCodeDAO.read(CoreConstants.ERROR_STATUS_CODE_300);
		}
	}
	
}
