package co.com.ath.pgw.srv;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import co.com.ath.pgw.bsn.controller.AvalPaymentCtrlService;
import co.com.ath.pgw.in.dto.AVALPaymentAddRsType;
import co.com.ath.pgw.rest.request.dto.AVALTransactionRequest;
import co.com.ath.pgw.rest.request.dto.Header;
import co.com.ath.pgw.rest.response.dto.AVALTransactionResponse;
import co.com.ath.pgw.rest.response.dto.GenericErrorResponse;
import co.com.ath.pgw.srv.mapper.MapperAddAvalTransaction;
import co.com.ath.pgw.util.constants.CoreConstants;
import co.com.ath.pgw.util.exception.CustomException;
/**
 * Facade del Servicio AVAL con las operaciones disponibles para los pagos por este medio.
 * @author SophosSolutions
 * @version 1.0 17/06/2019
 */
@CrossOrigin("*")
@RestController
@RequestMapping(path = "/avalManagement/v1")
public class AvalServiceFacade {

	static Logger LOGGER = LoggerFactory.getLogger(AvalServiceFacade.class);

	@Autowired
	private AvalPaymentCtrlService avalPaymentCtrlService;

	/**
	 * servicio Put para realizar pagos mediante AVAL.
	 * @param avalTransactionRequest
	 * @param header
	 * @return ResponseEntity
	 */	
	@PutMapping("/Payments_Aval/Aval")
	public ResponseEntity<?> addAVALPayment(
			@RequestHeader(name = "X-RqUID", required = true) long rqUID,
			@RequestHeader(name = "X-Channel", required = true) String channel,
			@RequestHeader(name = "X-CompanyId", required = true) String companyId,
			@RequestHeader(name = "X-IPAddr", required = false) String ipAddr,
			@RequestHeader(name = "X-IdentSerialNum", required = true) String identSerialNum,
			@RequestHeader(name = "X-GovIssueIdentType", required = false) String govIssueIdentType,
			@RequestBody(required = true) AVALTransactionRequest avalTransactionRequest) throws CustomException {
		Header header = new Header(rqUID, channel, companyId, identSerialNum, govIssueIdentType, ipAddr);
		LOGGER.info("@addAVALPayment input\n{}", header + "\n" + avalTransactionRequest);
		try {
			AVALPaymentAddRsType avalPaymentAddRsType = avalPaymentCtrlService.addAVALPayment(MapperAddAvalTransaction.mapperRequestToCoreRequest(avalTransactionRequest, header));
			if (avalPaymentAddRsType.getStatusCode() != CoreConstants.SUCCESS_STATUS_CODE) {
				throw new CustomException(String.valueOf(avalPaymentAddRsType.getStatusCode()), avalPaymentAddRsType);
			}
			AVALTransactionResponse avalTransactionResponse = MapperAddAvalTransaction.mapperResponseSuccessCore(avalPaymentAddRsType);
			LOGGER.info("@addAVALPayment output\n{}", header + "\n" + avalTransactionResponse);
			HttpHeaders httpHeaders = new HttpHeaders();
			httpHeaders.add("X-RqUID", String.valueOf(rqUID));
			httpHeaders.add("X-ApprovalId", avalPaymentAddRsType.getTransactionStatus().getApprovalId());
			return new ResponseEntity<>(avalTransactionResponse, httpHeaders, HttpStatus.CREATED);
		} catch (CustomException e) {
			GenericErrorResponse genericErrorResponse = MapperAddAvalTransaction.mapperResponseErrorCore((AVALPaymentAddRsType) e.getObjeto());
			LOGGER.info("@addAVALPayment error output\n{}", header + "\n" + genericErrorResponse);
			HttpHeaders httpHeaders = new HttpHeaders();
			httpHeaders.add("X-RqUID", String.valueOf(rqUID));
			httpHeaders.add("X-ApprovalId", CoreConstants.DEFAULT_APPROVAL);
			return new ResponseEntity<>(genericErrorResponse, httpHeaders, HttpStatus.PARTIAL_CONTENT);
		}
	}

}
