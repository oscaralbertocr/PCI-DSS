package co.com.ath.pgw.bsn.controller;

import co.com.ath.pgw.in.dto.AVALPaymentAddRqType;
import co.com.ath.pgw.in.dto.AVALPaymentAddRsType;
import co.com.ath.pgw.util.exception.CustomException;

/**
 * Servicio puente para las peticiones entre los servicios de AvalPayment y el Core
 * @author sophosSolutions
 * @version 1.0
 * @since 1.0
 */

public interface AvalPaymentCtrlService {
	/**
	 * Permite realizar los pagos por medio de pago Aval.
	 * @param avalPaymentAddRqType
	 * @return AVALPaymentAddRsType
	 */
	public AVALPaymentAddRsType addAVALPayment(AVALPaymentAddRqType avalPaymentAddRqType) throws CustomException;
	
}
