package co.com.ath.pgw.config;

import java.util.HashMap;

import javax.naming.NamingException;
import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.PropertySource;
import org.springframework.core.env.Environment;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;
import org.springframework.jndi.JndiTemplate;
import org.springframework.orm.jpa.JpaTransactionManager;
import org.springframework.orm.jpa.LocalContainerEntityManagerFactoryBean;
import org.springframework.orm.jpa.vendor.HibernateJpaVendorAdapter;
import org.springframework.transaction.PlatformTransactionManager;
/**
 * Configuracion dataSource para el api pgw AVAL.
 * @author SophosSolutions
 * @version 1.0 17/06/2019
 */

@Configuration
@PropertySource({ "file:D:/pgw-core-config/pgw-config.properties" })
@EnableJpaRepositories(basePackages = "co.com.ath.pgw.persistence", 
	entityManagerFactoryRef = "prvEntityManager", 
	transactionManagerRef = "prvTransactionManager")
public class DataSourceConfig {

	@Autowired
	private Environment env;
	/**
	 * obtencion de entityManager.
	 * @return LocalContainerEntityManagerFactoryBean
	 */	
	@Bean
	public LocalContainerEntityManagerFactoryBean prvEntityManager() {
		LocalContainerEntityManagerFactoryBean em = new LocalContainerEntityManagerFactoryBean();
		try {
			em.setDataSource(prvDataSource());
		} catch (NamingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		em.setPackagesToScan(new String[] { "co.com.ath.pgw.persistence.model" });

		HibernateJpaVendorAdapter vendorAdapter = new HibernateJpaVendorAdapter();
		em.setJpaVendorAdapter(vendorAdapter);
		HashMap<String, Object> properties = new HashMap<>();
		properties.put("hibernate.hbm2ddl.auto", env.getProperty("hibernate.hbm2ddl.auto"));
		properties.put("hibernate.dialect", env.getProperty("hibernate.dialect"));
		properties.put("hibernate.connection.release_mode", "after_transaction");
		em.setJpaPropertyMap(properties);

		return em;
	}
	/**
	 * obtencion de Datasource.
	 * @return DataSource
	 */	
	@Bean (destroyMethod = "")
	public DataSource prvDataSource() throws NamingException {
		System.out.println("Propertie"+env.getProperty("jdbc.url"));
		return (DataSource) new JndiTemplate().lookup(env.getProperty("jdbc.url"));

	}
	/**
	 * persistencia del datasource.
	 * @return PlatformTransactionManager
	 */	
	@Bean
	public PlatformTransactionManager prvTransactionManager() {

		JpaTransactionManager transactionManager = new JpaTransactionManager();
		transactionManager.setEntityManagerFactory(prvEntityManager().getObject());
		return transactionManager;
	}
}
