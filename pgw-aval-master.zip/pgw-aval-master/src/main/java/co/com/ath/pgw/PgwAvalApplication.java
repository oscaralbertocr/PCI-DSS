package co.com.ath.pgw;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

/**
 * aplicacion del api AVAL
 * @version 1.0 17/06/2019
 * @author sophosSolutions
 */

@SpringBootApplication
public class PgwAvalApplication {
	/**
	 * inicializacion de la aplicacion.
	 * @param args
	 * 
	 */	
	public static void main(String[] args) {
		SpringApplication.run(PgwAvalApplication.class, args);
	}

}
