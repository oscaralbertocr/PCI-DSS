package co.com.ath.pgw.config;

import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;


@Configuration
@ComponentScan(basePackages = {"co.com.ath.pgw.persistence","co.com.ath.pgw.persistence.dao"})
public class PersistenceConfig {


}
