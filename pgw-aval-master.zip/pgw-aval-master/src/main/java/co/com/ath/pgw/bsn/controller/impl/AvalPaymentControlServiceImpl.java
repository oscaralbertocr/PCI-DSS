package co.com.ath.pgw.bsn.controller.impl;

import javax.annotation.Resource;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import co.com.ath.pgw.bsn.controller.AvalPaymentCtrlService;
import co.com.ath.pgw.bsn.dto.in.AddAVALPaymentInDTO;
import co.com.ath.pgw.bsn.dto.out.AddAVALPaymentOutDTO;
import co.com.ath.pgw.bsn.service.PGWAvalPaymentService;
import co.com.ath.pgw.in.dto.AVALPaymentAddRqType;
import co.com.ath.pgw.in.dto.AVALPaymentAddRsType;
import co.com.ath.pgw.util.converter.PaymentsObjectsConverter;
import co.com.ath.pgw.util.exception.CustomException;

/**
 * Implementación de servicio puente para los pagos por medio de AVAL
 * 
 * @author sophosSolutions
 * @version 1.0
 * @since 1.0
 */

@Service
public class AvalPaymentControlServiceImpl implements AvalPaymentCtrlService{
	
static Logger LOGGER = LoggerFactory.getLogger(AvalPaymentControlServiceImpl.class);
	
	@Resource
	PGWAvalPaymentService pgwPaymentService;
	
	@Override
	public AVALPaymentAddRsType addAVALPayment(AVALPaymentAddRqType avalPaymentAddRqType) throws CustomException{
		AVALPaymentAddRsType avalPaymentAddRsType;
		try{
			AddAVALPaymentInDTO addAVALPaymentInDTO 	= PaymentsObjectsConverter.convertAVALPaymentAddRqTypeToAddAVALPaymentInDTO(avalPaymentAddRqType);
			AddAVALPaymentOutDTO addAVALPaymentOutDTO 	= pgwPaymentService.addAVALPayment(addAVALPaymentInDTO);
			avalPaymentAddRsType 						= PaymentsObjectsConverter.convertAddAVALPaymentOutDTOToAVALPaymentAddRsType(addAVALPaymentOutDTO);
		} catch(Exception ex){
			avalPaymentAddRsType = PaymentsObjectsConverter.convertAddAVALPaymentOutDTOToAVALPaymentAddRsTypeError(avalPaymentAddRqType, ex);
			throw new CustomException(ex.getMessage(),avalPaymentAddRsType);
		}
		return avalPaymentAddRsType;
	}
	
}
