package co.com.ath.pgw.bsn.service;

import co.com.ath.pgw.bsn.dto.in.AddAVALPaymentInDTO;
import co.com.ath.pgw.bsn.dto.out.AddAVALPaymentOutDTO;

/**
 * Servicio para realizar pagos mediante Aval.
 * @version 0.0.0 05/11/2015
 * @author SophosSolutions
 */
public interface PGWAvalPaymentService {
	/**
	 * Permite realizar transacciones por medio de pago Aval.
	 * @param addAVALPaymentInDTO
	 * @return AddAVALPaymentOutDTO
	 */	
	public AddAVALPaymentOutDTO addAVALPayment(AddAVALPaymentInDTO addAVALPaymentInDTO) throws Exception;
	
}
