# pgw-cards
# [09082019]3_Ejecucion Release [RQ32456_Release_Cards] - prv_jmrodriguez:CR_1
# [30082019]1_Ejecucion Release [RQ32456_Release_Cards_GlobalPay] - prv_jmrodriguez:CR_1.1   
# [10092019]1_Ejecucion Release [RQ32456_Release_Cards_GlobalPay] - prv_jmrodriguez:CR_1.2   
# [11092019]1_Ejecucion Release [RQ32456_Release_Cards_GlobalPay] - prv_jmrodriguez:CR_1.3   
# [13092019]1_Ejecucion Release [RQ32456_Release_Cards_GlobalPay] - prv_jmrodriguez:CR_1.4
# [18092019]1_Ejecucion Release [RQ32456_Release_Cards_GlobalPay] - prv_jmrodriguez:CR_1.5
# [04102019]1_Ejecucion Release [RQ32456_Integracion_K7] - prv_javendano:CR_1.6

# [16102019]1_Ejecucion Release [RQ33328_Particion de Logs] - prv_javendano:CR_1.7
# [22102019]1_Ejecucion Release [Envio de informacion a RBM] - prv_javendano:CR_1.8
# [14012020]1_Ejecucion Release [escaneo Fortify] - jmendoza:CR_1.9
# [05032020]1_Ejecucion Release [escaneo Fortify] - jmendoza:CR_2.1:PT
# [06032020]1_Ejecucion Release [escaneo Fortify] - jmendoza:CR_2.2:PT
