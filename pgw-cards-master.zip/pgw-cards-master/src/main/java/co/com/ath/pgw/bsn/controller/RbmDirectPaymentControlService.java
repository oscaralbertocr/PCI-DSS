package co.com.ath.pgw.bsn.controller;

import co.com.ath.pgw.in.dto.CreditCardPaymentAddRequest;
import co.com.ath.pgw.in.dto.CreditCardPaymentAddResponse;
import co.com.ath.pgw.util.exception.CustomException;
/**
* Servicio puente para las peticiones entre los servicios de rbm entre k7 y el core
* 
* @author sophosSolutions
* @version 1.0 22/07/2019
* 
*/
public interface RbmDirectPaymentControlService {
	/**
	 * servicio que inicializa pagos RBM por k7
	 * @param creditCardPaymentAddRequest
	 * @return CreditCardPaymentAddResponse
	 */
	public CreditCardPaymentAddResponse creditCardPaymentAdd(CreditCardPaymentAddRequest creditCardPaymentAddRequest) throws CustomException ;
	
}
