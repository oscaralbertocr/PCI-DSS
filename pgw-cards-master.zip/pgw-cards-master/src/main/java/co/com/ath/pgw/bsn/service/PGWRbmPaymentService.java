package co.com.ath.pgw.bsn.service;

import co.com.ath.pgw.bsn.dto.in.AddRBMPaymentInDTO;
import co.com.ath.pgw.bsn.dto.out.AddRBMPaymentOutDTO;
import co.com.ath.pgw.util.exception.CustomException;
/**
* Servicio para pagos con RBM
* 
* @author sophossolutions
* @version 1.0 22/07/2019
* 
*/
public interface PGWRbmPaymentService {
	/**
	 * Permite crear una transaccion de compra con rbm
	 * @param addRBMPaymentInDTO
	 * @return AddRBMPaymentOutDTO
	 * @throws Exception
	 */
	public AddRBMPaymentOutDTO addRBMPayment(AddRBMPaymentInDTO addRBMPaymentInDTO)  throws Exception;
	
}
