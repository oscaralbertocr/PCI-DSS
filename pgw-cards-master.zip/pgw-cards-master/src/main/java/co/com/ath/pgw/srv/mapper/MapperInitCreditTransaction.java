package co.com.ath.pgw.srv.mapper;

import java.math.BigDecimal;
import java.util.Calendar;
import java.util.HashMap;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import co.com.ath.pgw.bsn.globalPay.dto.IniciarTransaccionDeCompraRqType;
import co.com.ath.pgw.bsn.globalPay.dto.IniciarTransaccionDeCompraRsType;
import co.com.ath.pgw.client.rbm.model.TipoTipoDocumento;
import co.com.ath.pgw.in.model.IdPersonaType;
import co.com.ath.pgw.in.model.InfoPersonaType;
import co.com.ath.pgw.in.model.InfoRespuestaType;
import co.com.ath.pgw.in.model.ReferenceType;
import co.com.ath.pgw.in.model.UserIdType;
import co.com.ath.pgw.rest.dto.AdditionalStatus;
import co.com.ath.pgw.rest.dto.MsgRsHdr;
import co.com.ath.pgw.rest.dto.PmtStatus;
import co.com.ath.pgw.rest.dto.RefInfo;
import co.com.ath.pgw.rest.dto.Status;
import co.com.ath.pgw.rest.request.dto.CreditTransactionGlobalPayRequest;
import co.com.ath.pgw.rest.request.dto.Header;
import co.com.ath.pgw.rest.response.dto.CreditTransactionGlobalPayResponse;
import co.com.ath.pgw.rest.response.dto.GenericErrorResponse;
import co.com.ath.pgw.util.constants.CoreConstants;
import co.com.ath.pgw.util.converter.DateUtil;
import co.com.ath.pgw.util.exception.CustomException;
/**
 * Servicio de Mapeo de objetos para pagos con tarjeta de credito desde globalPay
 * @author SophosSolutions
 * @version 1.0
 * @since 1.0
 */
public class MapperInitCreditTransaction {
	
	private static Logger LOGGER = LoggerFactory.getLogger(MapperInitCreditTransaction.class);
	/**
	 * mapeo request para pagos con tarjeta de credito desde globalPay.
	 * @param creditTransactionGlobalPayRequest
	 * @param header
	 * @return AgreementSynchronizationRqType
	 * @throws CustomException
	 */	
	public static IniciarTransaccionDeCompraRqType mapperRequestToCoreRequest(CreditTransactionGlobalPayRequest creditTransactionGlobalPayRequest, Header header) throws CustomException {
		IniciarTransaccionDeCompraRqType iniciarTransaccionDeCompraRqType = new IniciarTransaccionDeCompraRqType();
		try {
			iniciarTransaccionDeCompraRqType.setRqUID(header.getRqUID());
			iniciarTransaccionDeCompraRqType.setChannel(header.getChannel());
			iniciarTransaccionDeCompraRqType.setIPAddr(header.getIpAddr());
			iniciarTransaccionDeCompraRqType.setClientDt(DateUtil.toXMLGregorianCalendar(Calendar.getInstance().getTime()));
			
			UserIdType userIdType = new UserIdType();
			userIdType.setCustIdNum(header.getIdentSerialNum());
			//userIdType.setCustIdType(header.getGovIssueIdentType());
			userIdType.setCustIdType(mapRBMIdentification(header.getGovIssueIdentType()));
			iniciarTransaccionDeCompraRqType.setUserId(userIdType);
			
			/*BENEFICIARIO*/
			InfoPersonaType infoPersonaTypePayee = new InfoPersonaType();
			infoPersonaTypePayee.setNombres(creditTransactionGlobalPayRequest.getCustPayeeInfo().getPersonName().getFirstName());
			infoPersonaTypePayee.setApellidos(creditTransactionGlobalPayRequest.getCustPayeeInfo().getPersonName().getLastName());
			infoPersonaTypePayee.setCorreo(creditTransactionGlobalPayRequest.getCustPayeeInfo().getContactInfo().getEmailAddr());
			infoPersonaTypePayee.setTelefono(creditTransactionGlobalPayRequest.getCustPayeeInfo().getContactInfo().getPhoneNum().getPhone());
			
			IdPersonaType idPersonaTypePayee = new IdPersonaType();
			idPersonaTypePayee.setNumDocumento(creditTransactionGlobalPayRequest.getCustPayeeInfo().getGovIssueIdent().getIdentSerialNum());
			//idPersonaTypePayee.setTipoDocumento(creditTransactionGlobalPayRequest.getCustPayeeInfo().getGovIssueIdent().getGovIssueIdentType());
			idPersonaTypePayee.setTipoDocumento(mapRBMIdentification(creditTransactionGlobalPayRequest.getCustPayeeInfo().getGovIssueIdent().getGovIssueIdentType()));
			infoPersonaTypePayee.setIdPersona(idPersonaTypePayee);
			iniciarTransaccionDeCompraRqType.setInfoPersonaBeneficiario(infoPersonaTypePayee);
			
			/*PAGADOR*/
			InfoPersonaType infoPersonaType = new InfoPersonaType();
			infoPersonaType.setNombres(creditTransactionGlobalPayRequest.getCustInfo().getPersonInfo().getPersonName().getFirstName());
			infoPersonaType.setApellidos(creditTransactionGlobalPayRequest.getCustInfo().getPersonInfo().getPersonName().getLastName());
			infoPersonaType.setCorreo(creditTransactionGlobalPayRequest.getCustInfo().getPersonInfo().getContactInfo().getEmailAddr());
			infoPersonaType.setTelefono(creditTransactionGlobalPayRequest.getCustInfo().getPersonInfo().getContactInfo().getPhoneNum().getPhone());
			infoPersonaType.setNumeroTelefonoCelular(creditTransactionGlobalPayRequest.getCustInfo().getPersonInfo().getContactInfo().getPhoneNum().getPhone());
			
			IdPersonaType idPersonaType = new IdPersonaType();
			idPersonaType.setNumDocumento(creditTransactionGlobalPayRequest.getCustInfo().getPersonInfo().getGovIssueIdent().getIdentSerialNum());
			//idPersonaType.setTipoDocumento(creditTransactionGlobalPayRequest.getCustInfo().getPersonInfo().getGovIssueIdent().getGovIssueIdentType());
			idPersonaType.setTipoDocumento(mapRBMIdentification(creditTransactionGlobalPayRequest.getCustInfo().getPersonInfo().getGovIssueIdent().getGovIssueIdentType()));
			infoPersonaType.setIdPersona(idPersonaType);
			iniciarTransaccionDeCompraRqType.setInfoPersona(infoPersonaType);
			
			for(RefInfo refInfo: creditTransactionGlobalPayRequest.getRefInfo()) {
				ReferenceType referenceType = new ReferenceType();
				referenceType.setRefId(refInfo.getRefId());
				referenceType.setRefType(refInfo.getRefType());
				iniciarTransaccionDeCompraRqType.getReference().add(referenceType);
			}
			
			iniciarTransaccionDeCompraRqType.setPmtid(creditTransactionGlobalPayRequest.getPmtStatus().getPmtAuthId());
		} catch (Exception e) {
			LOGGER.error("Error mapeando informacion ", e.getMessage());
			throw new CustomException(e.getMessage(), setCustomError(e));
		}
		return iniciarTransaccionDeCompraRqType;
	}
	
	/*
	 * Dario
	 * */
	private static String mapRBMIdentification(String customerDocType) {
		// Equivalencia de tipos de documento
		Map<String, String> rbmIdentificationMap = new HashMap<String, String>();
		rbmIdentificationMap.put("CC", "CC");
		rbmIdentificationMap.put("TI", "TI");
		rbmIdentificationMap.put("CE", "CE");
		rbmIdentificationMap.put("NIT", "NI");		
		rbmIdentificationMap.put("PA", "PP");
		rbmIdentificationMap.put("RC", "RC");
		return rbmIdentificationMap.get(customerDocType);
	}
	
	/*
	 * Dario
	 * */
	
	/**
	 * mapeo respuesta exitosa para pagos con tarjeta de credito desde globalPay.
	 * @param iniciarTransaccionDeCompraRsType
	 * @return CreditTransactionGlobalPayResponse
	 * @throws CustomException
	 */		
	public static CreditTransactionGlobalPayResponse mapperResponseSuccessCore(IniciarTransaccionDeCompraRsType iniciarTransaccionDeCompraRsType) throws CustomException {
		CreditTransactionGlobalPayResponse creditTransactionGlobalPayResponse = new CreditTransactionGlobalPayResponse();
		try {
			PmtStatus pmtStatus = new PmtStatus();
			pmtStatus.setPmtAuthId(iniciarTransaccionDeCompraRsType.getPmtid());
			pmtStatus.setStatusDesc(iniciarTransaccionDeCompraRsType.getInfoRespuesta().getEstado());
			pmtStatus.setEffDt(iniciarTransaccionDeCompraRsType.getEffDt());
			pmtStatus.setCompensationDt(iniciarTransaccionDeCompraRsType.getCompensationDate());
			creditTransactionGlobalPayResponse.setPmtStatus(pmtStatus);
			if(iniciarTransaccionDeCompraRsType.getReference()!= null) {
				for(ReferenceType referenceType: iniciarTransaccionDeCompraRsType.getReference()){
					RefInfo refInfo = new RefInfo();
					refInfo.setRefId(referenceType.getRefId());
					refInfo.setRefType(referenceType.getRefType());
					creditTransactionGlobalPayResponse.getRefInfo().add(refInfo);
				}
			}
			
			creditTransactionGlobalPayResponse.getRefInfo().add(new RefInfo(CoreConstants.PORTAL_URL, iniciarTransaccionDeCompraRsType.getInfoTransaccionResp().getUrlRBM()));
		} catch (Exception e) {
			LOGGER.error("Error mapeando informacion ", e.getMessage());
			throw new CustomException(e.getMessage(), setCustomError(e));
		}
		return creditTransactionGlobalPayResponse;
	}
	/**
	 * mapeo respuesta error generico para pagos con tarjeta de credito desde globalPay.
	 * @param iniciarTransaccionDeCompraRsType
	 * @return GenericErrorResponse
	 */			
	public static GenericErrorResponse mapperResponseErrorCore(IniciarTransaccionDeCompraRsType iniciarTransaccionDeCompraRsType) {
		GenericErrorResponse genericErrorResponse = new GenericErrorResponse();
		
		Status status = new Status();
		status.setStatusCode(String.valueOf(CoreConstants.ERROR_STATUS_CODE_300));
		status.setStatusDesc(CoreConstants.ERROR_STATUS_CODE_DESC);
		status.setEndDt(Calendar.getInstance().getTime());
		
		AdditionalStatus additionalStatus = new AdditionalStatus();
		additionalStatus.setStatusCode(iniciarTransaccionDeCompraRsType.getInfoRespuesta().getCodRespuesta());
		additionalStatus.setStatusDesc(iniciarTransaccionDeCompraRsType.getInfoRespuesta().getDescRespuesta());
		status.setAdditionalStatus(additionalStatus);
		
		MsgRsHdr msgRsHdr = new MsgRsHdr();
		msgRsHdr.setStatus(status);
		msgRsHdr.setEndDt(Calendar.getInstance().getTime());
		genericErrorResponse.setMsgRsHdr(msgRsHdr);
		
		return genericErrorResponse;
	}
	/**
	 * mapeo respuesta error para pagos con tarjeta de credito desde globalPay.
	 * @param Exception
	 * @return IniciarTransaccionDeCompraRsType
	 */		
	public static IniciarTransaccionDeCompraRsType setCustomError(Exception e){
		IniciarTransaccionDeCompraRsType iniciarTransaccionDeCompraRsType = new IniciarTransaccionDeCompraRsType();
		InfoRespuestaType infoRespuestaType = new InfoRespuestaType();
		infoRespuestaType.setCodRespuesta(CoreConstants.ERROR_STATUS_CODE_300.toString());
		infoRespuestaType.setDescRespuesta(e.toString());
		iniciarTransaccionDeCompraRsType.setInfoRespuesta(infoRespuestaType);
		return iniciarTransaccionDeCompraRsType;
	}
	
}
