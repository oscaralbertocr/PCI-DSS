/*
 * PGWCommerceService
 *  
 * GSI - Integración
 * Creado el: 20/09/2014
 *
 * Copyright (c) A Toda Hora S.A. Todos los derechos reservados
 * 
 * Este software es confidencial y es propietario de ATH, queda prohibido
 * su uso, reproducción y copia de manera parcial o permanente salvo autorización
 * expresa de A Toda Hora S.A o de quién represente sus derechos.
 */
package co.com.ath.pgw.bsn.service;

import co.com.ath.pgw.bsn.dto.in.IniciarTransaccionInDTO;
import co.com.ath.pgw.bsn.dto.out.IniciarTransaccionOutDTO;

/**
* Servicio checkout GlobalPay de RBM 
* 
*/
public interface PGWGlobalPayCheckoutService {

	/***
	 * Servicio para desde la Pasarela notificar al Core el estado de la
	 * transaccion de pago por tarjeta de credito en GlobalPay
	 * 
	 * @param iniciarTransaccionInDTO
	 * @return
	 */
	public IniciarTransaccionOutDTO checkout(IniciarTransaccionInDTO iniciarTransaccionInDTO);
	

	
}
