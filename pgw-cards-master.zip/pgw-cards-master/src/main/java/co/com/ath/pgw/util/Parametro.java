package co.com.ath.pgw.util;

import java.util.List;

import org.json.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.client.RestTemplate;

import co.com.ath.pgw.util.qr.Constants;
import co.com.ath.pgw.util.qr.ParametroDTO;

public class Parametro {
	private static final Logger LOGGER = LoggerFactory.getLogger(Parametro.class);
	
	private Parametro() {
	}

	/**
	 * @param clave
	 * @return
	 */
	public static String getParametro(String clave) {
		try {

			String path = ServiceContext.path;
			String uriPermiso = path + Constants.URL_AUTORIZACION_USER;
			String uriParametro = path + Constants.URL_PARAMETRO;

			HttpHeaders headers = new HttpHeaders();
			headers.setContentType(MediaType.APPLICATION_JSON);
			headers.set("Authorization", getToken(uriPermiso));

			HttpEntity request = new HttpEntity(headers);
			RestTemplate plantilla = new RestTemplate();
			ResponseEntity<ParametroDTO> response = plantilla.exchange(uriParametro, HttpMethod.GET, request,
					ParametroDTO.class, clave);

			if (response.getStatusCode() == HttpStatus.OK) {
				ParametroDTO parametro = response.getBody();
				return parametro.getValor();
			}

		} catch (Exception e) {
			LOGGER.error("Error en getParametro. {}", e);
		}
		return null;

	}

	/**
	 * @param clave
	 * @return
	 */
	public static List<ParametroDTO> getParametros(String[] parametrosArray) {
		try {
			LOGGER.info("Ingreso getParametros");

			String path = ServiceContext.path;
			String uriPermiso = path + Constants.URL_AUTORIZACION_USER;
			String uriParametro = path + Constants.URL_LISTA;

			HttpHeaders headers = new HttpHeaders();
			headers.setContentType(MediaType.APPLICATION_JSON);
			headers.set("Authorization", getToken(uriPermiso));

			HttpEntity<Object> request = new HttpEntity<Object>(parametrosArray, headers);

			RestTemplate plantilla = new RestTemplate();

			ResponseEntity<List<ParametroDTO>> response = plantilla.exchange(uriParametro, HttpMethod.POST, request,
					new ParameterizedTypeReference<List<ParametroDTO>>() {
					});
			if (response.getStatusCode() == HttpStatus.OK) {
				List<ParametroDTO> parametros = response.getBody();
				return parametros;
			}

		} catch (Exception e) {
			LOGGER.error("Error en getParametros. {}", e);
		}
		return null;
	}

	/**
	 * @return
	 */
	private static String getToken(String uri) {
		String token = "";

		try {
			LOGGER.info("Ingreso getToken");
			JSONObject usuario = new JSONObject();
			usuario.put("User", "AuthParametros");

			HttpHeaders headers = new HttpHeaders();
			headers.setContentType(MediaType.APPLICATION_JSON);

			HttpEntity<String> request = new HttpEntity<String>(usuario.toString(), headers);

			RestTemplate plantilla = new RestTemplate();
			token = plantilla.postForObject(uri, request, String.class);

		} catch (Exception e) {
			LOGGER.error("Error en getToken. {}", e);
		}

		return token;
	}
}
