package co.com.ath.pgw;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

/**
 * aplicacion del api cards
 * @version 1.0 22/07/2019
 * @author sophosSolutions
 */
@SpringBootApplication
public class PgwCardsApplication {
	/**
	 * inicializacion de la aplicacion.
	 * @param args
	 * 
	 */	
	public static void main(String[] args) {
		SpringApplication.run(PgwCardsApplication.class, args);
	}

}
