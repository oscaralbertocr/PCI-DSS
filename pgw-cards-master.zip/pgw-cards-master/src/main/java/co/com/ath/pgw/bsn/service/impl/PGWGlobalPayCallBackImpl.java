package co.com.ath.pgw.bsn.service.impl;

import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;

import javax.annotation.Resource;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import co.com.ath.pgw.bsn.dto.in.GlobalPayInDTO;
import co.com.ath.pgw.bsn.service.PGWGlobalPayCallBack;
import co.com.ath.pgw.bsn.service.rs.NotificationPayments;
import co.com.ath.pgw.persistence.dao.BrandDAO;
import co.com.ath.pgw.persistence.dao.PaymentWayDAO;
import co.com.ath.pgw.persistence.dao.TransactionDAO;
import co.com.ath.pgw.persistence.dao.TransactionStatusDAO;
import co.com.ath.pgw.persistence.model.Brand;
import co.com.ath.pgw.persistence.model.Transaction;
import co.com.ath.pgw.persistence.model.TransactionStatus;
import co.com.ath.pgw.persistence.service.ReconciledTransactionService;
import co.com.ath.pgw.persistence.service.SendMailService;
import co.com.ath.pgw.rest.response.dto.GlobalPayCheckOutResponse;
import co.com.ath.pgw.util.Parametro;
import co.com.ath.pgw.util.constants.CoreConstants;
import co.com.ath.pgw.util.constants.PaymentWayCodes;
import co.com.ath.pgw.util.enums.AVALBankEnum;
import co.com.ath.pgw.util.enums.TransactionStatusEnum;
import co.com.ath.pgw.util.exception.CustomException;
import co.com.ath.pgw.util.security.impl.TokenGeneratorMD5Service;
import co.com.ath.pgw.util.tripledes.AesCifer;
import co.com.ath.ws.rs.objects.BankInfo;
import co.com.ath.ws.rs.objects.TransactionNotification;

@Service
public class PGWGlobalPayCallBackImpl implements PGWGlobalPayCallBack {

	private static Logger LOGGER = LoggerFactory.getLogger(PGWGlobalPayCallBackImpl.class);

	@Resource
	private SendMailService sendMailService;

	@Resource
	private TokenGeneratorMD5Service tokenGeneratorService;

	@Resource
	private TransactionDAO transactionDAO;

	@Resource
	private TransactionStatusDAO transactionStatusDAO;

	@Resource
	private PaymentWayDAO paymentWayDAO;

	@Resource
	private ReconciledTransactionService reconciledTransactionService;

	@Autowired 
	private AesCifer tripleDes;
	
	
	@Value("${pasarela.pse.nitagregador}")
	private String nitAgregator;

	@Value("${pasarela.pse.nitagregador.avVillas}")
	private String nitAgregatorAvVillas;
	
	@Resource
	private NotificationPayments notificationPayments;
	
	@Resource
	private BrandDAO brandDAO;
	

	String SEPARADOR = "_";

	public GlobalPayCheckOutResponse callBack(GlobalPayInDTO inDto) throws CustomException {

		LOGGER.info("Procesando CallBack de GlobalPay Id:{}", inDto.getIdTransaccion());

		// Se obtiene el sToken
		String sToken = generarToken(inDto);

		// Validar el sToken
		if (null != inDto.getsToken() && !"".equals(inDto.getsToken()) && sToken.equals(inDto.getsToken())) {

			LOGGER.info("Buscando la transaccion pmtid:{}", inDto.getPmtid());

			// Se valida la Tx ya existe en el Core de la Pasarela
			Transaction tx = transactionDAO.findByPmtId(inDto.getPmtid());

			if (null == tx) {

				LOGGER.error("No se encontro la transaccion pmtid:{} GlobalPay Id:{}", inDto.getPmtid(),
						inDto.getIdTransaccion());
				return new GlobalPayCheckOutResponse(201L, "error con el product_id");

			} else {

				LOGGER.info("Validando el estado de la transaccion pmtid:{}", tx.getPmtId());

				TransactionStatus transactionStatus = null;
				TransactionStatusEnum status = null;
				
				// validar el estado de la Tx
				if ((TransactionStatusEnum.PROCESSING.getCode().equals(tx.getStatus().getCode())
						|| TransactionStatusEnum.REGISTERED.getCode().equals(tx.getStatus().getCode())
						|| TransactionStatusEnum.LOGGED_IN.getCode().equals(tx.getStatus().getCode()))) {


					// Se valida el estado de la transaccion recibido por GlobalPay
					if (inDto.getIdEstado().equals(CoreConstants.GLOBALPAY_ESTADO_APROBADA)) { // Aprobada

						transactionStatus = transactionStatusDAO.findByDescription(TransactionStatusEnum.CONFIRMED_OK);
						status = TransactionStatusEnum.CONFIRMED_OK;
						
					} else if (inDto.getIdEstado().equals(CoreConstants.GLOBALPAY_ESTADO_CANCELADA)
							|| inDto.getIdEstado().equals(CoreConstants.GLOBALPAY_ESTADO_RECHAZADA)
							|| inDto.getIdEstado().equals(CoreConstants.GLOBALPAY_ESTADO_EXPIRADA)) { // Rechazada

						// Cancelada, Rechazada, Expirada
						transactionStatus = transactionStatusDAO.findByDescription(TransactionStatusEnum.CONFIRMED_NA);
						status = TransactionStatusEnum.CONFIRMED_NA;
					} 


				} else {
					LOGGER.warn("pmtid:{} La transaccion ya se encuentra en un estado final, "
							+ "no se actualizara el estado.", tx.getPmtId());
				}
				
				// Se actualizan los datos y el estado de la transaccion.
				tx = actualizarTransaccion(tx, inDto, transactionStatus);
				notificacion(tx, status);

				return new GlobalPayCheckOutResponse(200L, "exito");

			}

		} else {
			LOGGER.error("GlobalPay Id:{} El sToken recibido no cumple con los criterios de aceptacion.",
					inDto.getIdTransaccion());
			return new GlobalPayCheckOutResponse(203L, "error con el token");
		}

	}

	/***
	 * Genera el sToken a partir de los datos de entrada.
	 * 
	 * @param inDto
	 * @return
	 * @throws CustomException
	 */
	private String generarToken(GlobalPayInDTO inDto) throws CustomException {

		String sToken = null;

		try {
			String appCode=tripleDes.decrypt(Parametro.getParametro("pasarelarbmglobalpaycheckoutappCode"));
			String applicationKey=tripleDes.decrypt(Parametro.getParametro("pasarelarbmglobalpaycheckoutapplicationKey"));
			Set<Object> args = new HashSet<Object>();
			args.add(inDto.getIdTransaccion());
			args.add(appCode);
			args.add(inDto.getIdUsuario());
			args.add(applicationKey);

			sToken = "";

			LOGGER.info("GlobalPay Id:{} se genera sToken:{}", inDto.getPmtid(), sToken);

		} catch (Exception e) {
			String msg = "GlobalPay Id:" + inDto.getIdTransaccion() + " Ocurrio un error al generar el sToken. Error: "
					+ e.getMessage();
			LOGGER.error(msg);
			throw new CustomException(msg);
		}

		return sToken;
	}

	private Transaction actualizarTransaccion(Transaction tx, GlobalPayInDTO inDto,
			TransactionStatus transactionStatus) {

		if (null == tx.getPayerDocId() || tx.getPayerDocId().isEmpty())
			tx.setPayerDocId(inDto.getIdUsuario());

		if (null == tx.getCustomerDocId() || tx.getCustomerDocId().isEmpty())
			tx.setCustomerDocId(inDto.getIdUsuario());

		if (null == tx.getPayerName() || tx.getPayerName().isEmpty())
			tx.setPayerName(inDto.getNombreTitular());

		if (null == tx.getPayerMail() || tx.getPayerMail().isEmpty())
			tx.setPayerMail(inDto.getCorreoUsuario());

		if (null == tx.getCustomerEmail() || tx.getCustomerEmail().isEmpty())
			tx.setCustomerEmail(inDto.getCorreoUsuario());

		if (null == tx.getTransactionDate())
			tx.setTransactionDate(inDto.getFechaTransaccion());

		if (null == tx.getCompensationDate())
			tx.setCompensationDate(inDto.getFechaPago());

		if (null == tx.getBankCollecter())
			tx.setBankCollecter(tx.getCommerce().getSubscription().getBank());

		if (null == tx.getApprovalNumber() || tx.getApprovalNumber().isEmpty())
			tx.setApprovalNumber(inDto.getCodigoAutorizacion());

		if (null == tx.getTrazabilityCode() || tx.getTrazabilityCode().isEmpty())
			tx.setTrazabilityCode(inDto.getIdTransaccion());

		tx.setPaymentWay(paymentWayDAO.read(PaymentWayCodes.TC));
		tx.setGlobalPay(Boolean.TRUE);
		
		if (null != transactionStatus) {
			tx.setStatus(transactionStatus);
			LOGGER.info("pmtid:{} Cambiando estado a {}", tx.getPmtId(), transactionStatus);
		}

		transactionDAO.update(tx);

		return tx;
	}

	private void notificacion(Transaction transaction, TransactionStatusEnum txStatus) {

		// Leer Envio de Correo Electrónico
		Transaction txdata = transactionDAO.read(transaction.getId());

		if (txdata.getEmailflag() == CoreConstants.FLAG_EMAIL_OFF) {
			try {
				Long txStatusCode;
				
				if (null == txStatus)
					txStatusCode = txdata.getStatus().getCode();
				else
					txStatusCode = txStatus.getCode();
				
	
				transaction.setEmailflag(CoreConstants.FLAG_EMAIL_ON);
				transactionDAO.update(transaction);
	
				// Conciliar la transacción
				reconciledTransactionService.createOrUpdate(transaction, null);
	
				// Enviar correo de confirmación
				sendMailService.sendMail(transaction);
				
				LOGGER.info("Enviando correo promocional pmtid:{}", transaction.getPmtId());
				sendMailService.sendPromoMail(transaction);
	
				if (!(transaction.getCustomerEmail().equals(transaction.getPayerMail()))
						&& (transaction.getStatus().getCode() == txStatusCode)) {
	
					String mail = transaction.getPayerMail();
					transaction.setPayerMail(transaction.getCustomerEmail());
	
					sendMailService.sendMail(transaction);
					
					sendMailService.sendPromoMail(transaction);
					
					transaction.setPayerMail(mail);
				}
			}catch(Exception e) {
				LOGGER.error("Error notificacion",e);
			}finally {
				if (transaction.getNotificacionPPagos() == null || transaction.getNotificacionPPagos()==0) {
					if (updateInformation(transaction)) {
						transaction.setNotificacionPPagos(1);
						transactionDAO.update(transaction);	
						LOGGER.info("Se actualizo el estado de notificacion a portal de pagos: {}",transaction.getPmtId());
					}
				}
			}			
		}
	}
	
	/**
	 * Se informa al Portal de Pagos el estado de la transaccion
	 */
	private boolean updateInformation(Transaction transaction) {

		boolean result=true;
		try {
			TransactionNotification transactionNotification =new TransactionNotification();

			transactionNotification.setBusinessCode(transaction.getStatus().getBusinessCode().getCode());
			transactionNotification.setBusinessCodeDesc(transaction.getStatus().getBusinessCode().getDescription().name());
			transactionNotification.setCommerceNuraCode(transaction.getCommerce().getNuraCode());
			transactionNotification.setPmtId(transaction.getPmtId());
			transactionNotification.setRquId(transaction.getRquId());
			transactionNotification.setTrnChannel(transaction.getTrnChannel());
			transactionNotification.setIpAddress(transaction.getIpAddress());
			transactionNotification.setCustomerDocId(transaction.getCustomerDocId());
			transactionNotification.setCustomerDocType(transaction.getCustomerDocType());
			transactionNotification.setAmt(transaction.getTotalValue());
			transactionNotification.setCurCode(transaction.getCurrency());				
			transactionNotification.setAgreementId(getAgrementId(transaction));
			transactionNotification.setName(transaction.getCommerce().getSubscription().getCompanyName());
			transactionNotification.setNit(transactionDAO.getAggregatorNit(transaction, nitAgregator, nitAgregatorAvVillas));
			transactionNotification.setPhone(transaction.getCommerce().getSubscription().getPhone());								
			transactionNotification.setFirstName(transaction.getCustomerName() != null ? transaction.getCustomerName() : "");
			transactionNotification.setMiddleName(transaction.getMiddleNameBuyer() != null ? transaction.getMiddleNameBuyer() : "");
			transactionNotification.setLastName(transaction.getLastNameBuyer() != null ? transaction.getLastNameBuyer() : "");
			transactionNotification.setSecondLastName(transaction.getSecondLastNameBuyer() != null ? transaction.getSecondLastNameBuyer() : "");				
			transactionNotification.setCustIdType(transaction.getPayerDocType() != null ? transaction.getPayerDocType() : "");
			transactionNotification.setCustIdNum(transaction.getPayerDocId() != null ? transaction.getPayerDocId() : "");
			transactionNotification.setAddress(transaction.getPayerAddress());
			transactionNotification.setEmailAddr(transaction.getPayerMail() != null ? transaction.getPayerMail() : "");
			transactionNotification.setPhone(transaction.getPayerPhone() != null ? transaction.getPayerPhone() : "");				
			transactionNotification.setRquId(transaction.getRquId());
			transactionNotification.setPmtId(transaction.getPmtId());
			transactionNotification.setTrnChannel(transaction.getTrnChannel());				
			transactionNotification.setStatusCode(transaction.getStatus().getCode());
			transactionNotification.setStatusDesc(transaction.getStatus().getDescription().toString());
			transactionNotification.setOrderId(transaction.getOrderNumber()); 
			transactionNotification.setOrderDesc(transaction.getDescription());				
			transactionNotification.setPmtWayId(String.valueOf(transaction.getPaymentWay().getId()));
			transactionNotification.setPmtWayType(transaction.getPaymentWay().getName());

			BankInfo bankInfo = new BankInfo();
			bankInfo.setBankId(transaction.getBank() == null ? null : transaction.getBank().getAvalCode());	
			transactionNotification.setBankInfo(bankInfo);
			transactionNotification.setEffDt(getDate(transaction));
			transactionNotification.setCompensationDate(transaction.getCompensationDate());
			transactionNotification.setApprovalId(PaymentWayCodes.PSE.equals(transaction.getPaymentWay().getId()) ? transaction.getTrazabilityCode()
					: transaction.getApprovalNumber());
			transactionNotification.setReferenceMap(getReferenceMap(transaction, true));
			String codNie = "";

			LOGGER.info("Validacion de tipo de pago PSE y pago de tarjeta de credito. tipo de pago: {}, token: {}", transaction.getPaymentWay().getId(), transaction.getTokenized());

			if(PaymentWayCodes.PSE.equals(transaction.getPaymentWay().getId()) && transaction.getTokenized()!=null ) {
				LOGGER.info("Validacion de tipo de pago PSE y pago de tarjeta de credito se encontro");
				codNie = transaction.getTokenized();
			}else {
				LOGGER.info("Validacion de tipo de pago PSE y pago de tarjeta de credito No se encontro");
			}
			transactionNotification.setCodNIE(codNie);			

			result=notificationPayments.notification(transactionNotification);	
		} catch (Exception e) {
			result=false;
			LOGGER.error("No fue posible consumir el servicio @NotificationPayments {}",
					e.getLocalizedMessage());
		}
		return result;
	}
	
	private String getAgrementId(Transaction transaction) {
		String nuraCode = transaction.getCommerce().getNuraCode();
		final boolean needHomologate = transaction.getBank() != null
				&& AVALBankEnum.AV_VILLAS.getAvalCode().equals(transaction.getBank().getAvalCode())
				&& transaction.getCommerce().getHomologationBAVVCode() != null;
		if (needHomologate) {
			return transaction.getCommerce().getHomologationBAVVCode();
		}

		if (nuraCode.startsWith("CPV")) {
			nuraCode = nuraCode.substring(3, nuraCode.length());
		}

		return nuraCode;
	}
	
	private Date getDate(Transaction transaction) {
		if (transaction.getPayDate() != null) {
			return transaction.getPayDate();
		}
		return transaction.getTransactionDate();
	}
	
	/**
	 * Obtiene las referencias de la transaccion y las retorna en una lista de
	 * string.
	 * 
	 * @param tx
	 *            Transaccion a procesar
	 * @return Lista con las referencias encontradas o lista vacia si no hay
	 *         ninguna.
	 */
	private Map<String, String> getReferenceMap(Transaction transaction, boolean fillPaymetWay) {
		Map<String, String> refMap = new HashMap<String, String>();
		if (transaction == null) {
			return refMap;
		}
		if (fillPaymetWay) {
			// Validar el medio de pago para incluir informacion adicional
			if (transaction.getPaymentWay() != null) {
				if ((PaymentWayCodes.PAGOS_AVAL.equals(transaction.getPaymentWay().getId())
						|| PaymentWayCodes.PSE.equals(transaction.getPaymentWay().getId())) && transaction.getBank() != null) {
					refMap.put("BankId", transaction.getBank().getAvalCode());
					refMap.put("BankName", transaction.getBank().getName());
				}

				if ( PaymentWayCodes.TC.equals(transaction.getPaymentWay().getId()) 
						&& transaction.getIdBrand() != null) {

					Brand brand = brandDAO.read(Long.valueOf(transaction.getIdBrand().toString()));
					refMap.put("Brand", brand.getName());

					if ( transaction.isGlobalPay() != null && transaction.isGlobalPay() ) {
						refMap.put("CardEmbossNum", transaction.getCreditCardNumber());
					}

				}		

				TransactionStatus transactionStatus = transactionStatusDAO.findById(TransactionStatusEnum.REFUSED.getCode());
				if (PaymentWayCodes.PSE.equals(transaction.getPaymentWay().getId()) && transaction.getStatus()!=transactionStatus) {
					refMap.put("TrnCycle", transaction.getTrnCycle());
					refMap.put("AchBankCode", transaction.getBank().getAchCode());
				}
			}
		}

		if (transaction.getReference1() != null && !transaction.getReference1().trim().isEmpty()) {
			refMap.put("Reference1", transaction.getReference1());
		}
		if (transaction.getReference2() != null && !transaction.getReference2().trim().isEmpty()) {
			refMap.put("Reference2", transaction.getReference2());
		}
		if (transaction.getReference3() != null && !transaction.getReference3().trim().isEmpty()) {
			refMap.put("Reference3", transaction.getReference3());
		}

		// Ventanilla de Pagos
		if (transaction.getPlantilla() == CoreConstants.TAQUILLA_ON) {
			refMap.put("Template", CoreConstants.TAQUILLA_ON.toString());
			refMap.put("Theme", transaction.getTaquilla().getIdTaquilla().toString());
			refMap.put("LogoURL", new String(transaction.getUrlLogo()));
		} else if (transaction.getPlantilla() == CoreConstants.TAQUILLA_OFF) {
			refMap.put("Template", CoreConstants.TAQUILLA_OFF.toString());
		}

		return refMap;
	}
	
}
