package co.com.ath.pgw.bsn.controller;

import co.com.ath.pgw.in.dto.RBMPaymentAddRqType;
import co.com.ath.pgw.in.dto.RBMPaymentAddRsType;
/**
* Servicio puente para las peticiones entre los servicios de PaymentRbm y el Core
* 
* @author sophosSolutions
* @version 1.0 22/07/2019
* 
*/
public interface RbmPaymentControlService {
	/**
	 * servicio que inicializa pagos RBM de la pasarela de pagos
	 * @param rbmPaymentAddRqType
	 * @return RBMPaymentAddRsType
	 */
	public RBMPaymentAddRsType addRBMPayment(RBMPaymentAddRqType rbmPaymentAddRqType);
	
}
