/*
 * PGWCommerceService
 *  
 * GSI - Integración
 * Creado el: 20/09/2014
 *
 * Copyright (c) A Toda Hora S.A. Todos los derechos reservados
 * 
 * Este software es confidencial y es propietario de ATH, queda prohibido
 * su uso, reproducción y copia de manera parcial o permanente salvo autorización
 * expresa de A Toda Hora S.A o de quién represente sus derechos.
 */
package co.com.ath.pgw.bsn.service;

import co.com.ath.pgw.bsn.dto.in.ConsultarEstadoDePagoInDTO;
import co.com.ath.pgw.bsn.dto.in.IniciarTransaccionInDTO;
import co.com.ath.pgw.bsn.dto.out.ConsultarEstadoDePagoOutDTO;
import co.com.ath.pgw.bsn.dto.out.IniciarTransaccionOutDTO;
import co.com.ath.pgw.persistence.model.Transaction;
import co.com.ath.pgw.util.enums.TransactionStatusEnum;

/**
* Servicio para de GlobalPay de RBM 
* 
* @author camilo.bustamante@sophossolutions.com
* @version 1.0 03 Enero 2019
* @RQ31686 RBM_Integracion_Boton_TC_GlobalPay
* 
*/
@Deprecated
public interface PGWGlobalPayService {

	/**
	 * Permite crear una transaccion de compra en RBM GlobalPay
	 * @param iniciarTransaccionInDTO
	 * @return IniciarTransaccionOutDTO
	 * @throws Exception 
	 * @throws NumberFormatException 
	 */
	public IniciarTransaccionOutDTO IniciarTransaccionDeCompra(IniciarTransaccionInDTO iniciarTransaccionInDTO);
	
	/**
	 * Permite consultar el estado de una transaccion de compra en RBM GlobalPay
	 * @param consultarEstadoDePagoInDTO
	 * @return ConsultarEstadoDePagoOutDTO
	 * @throws Exception 
	 */
	public ConsultarEstadoDePagoOutDTO consultarEstadoDePago(ConsultarEstadoDePagoInDTO consultarEstadoDePagoInDTO);
	/**
	 * Permite notificacion mediante correos al realziar una transaccion en RBM GlobalPay
	 * @param transaction
	 * @param transactionStatusEnum
	 */
	public void notificacion(Transaction transaction, TransactionStatusEnum transactionStatusEnum);

	
}
