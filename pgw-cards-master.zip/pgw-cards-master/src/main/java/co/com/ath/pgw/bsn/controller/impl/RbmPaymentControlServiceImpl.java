package co.com.ath.pgw.bsn.controller.impl;

import javax.annotation.Resource;

import org.springframework.stereotype.Service;
import co.com.ath.pgw.bsn.controller.RbmPaymentControlService;
import co.com.ath.pgw.bsn.dto.in.AddRBMPaymentInDTO;
import co.com.ath.pgw.bsn.dto.out.AddRBMPaymentOutDTO;
import co.com.ath.pgw.bsn.service.PGWRbmPaymentService;
import co.com.ath.pgw.in.dto.RBMPaymentAddRqType;
import co.com.ath.pgw.in.dto.RBMPaymentAddRsType;
import co.com.ath.pgw.util.converter.PaymentsObjectsConverter;

/**
* Implementación de servicio puente para las peticiones entre 
* los servicios de RBM y el core
* 
* @author sophosSolutions
* @version 1.0 22/07/2019
*/
@Service
public class RbmPaymentControlServiceImpl implements RbmPaymentControlService{

	@Resource
	PGWRbmPaymentService pgwPaymentService;
	
	@Override
	public RBMPaymentAddRsType addRBMPayment(RBMPaymentAddRqType rbmPaymentAddRqType) {
		RBMPaymentAddRsType rmbPaymentAddRsType;
		try {
			AddRBMPaymentInDTO addRBMPaymentInDTO 		= PaymentsObjectsConverter.convertRBMPaymentAddRqTypeToAddRBMPaymentInDTO(rbmPaymentAddRqType);
			AddRBMPaymentOutDTO addRBMPaymentOutDTO 	= pgwPaymentService.addRBMPayment(addRBMPaymentInDTO);
			rmbPaymentAddRsType 	= PaymentsObjectsConverter.convertAddRBMPaymentOutDTOToRBMPaymentAddRsType(addRBMPaymentOutDTO);
		} catch (Exception e) {
			rmbPaymentAddRsType = PaymentsObjectsConverter.toRBMPaymentAddRsTypeError(rbmPaymentAddRqType, e);
		}		
        return rmbPaymentAddRsType;
	}
	
	
	
	
}
