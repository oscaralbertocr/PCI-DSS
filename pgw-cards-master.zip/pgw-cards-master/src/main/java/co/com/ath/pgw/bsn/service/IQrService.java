package co.com.ath.pgw.bsn.service;

import co.com.ath.pgw.in.dto.RBMPaymentAddRqType;
import co.com.ath.pgw.util.exception.CustomException;
import co.com.ath.pgw.util.qr.EstadoTransaccion;
import co.com.ath.pgw.util.qr.InformacionQR;

public interface IQrService {

	public InformacionQR generacionQR(RBMPaymentAddRqType iniciarTransaccionDeCompraRqType) throws CustomException;
	
	public EstadoTransaccion getEstadoTransaccion(long pmtId);
}
