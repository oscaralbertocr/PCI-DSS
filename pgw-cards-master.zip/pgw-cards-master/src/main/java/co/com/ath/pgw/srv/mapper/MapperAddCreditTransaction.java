package co.com.ath.pgw.srv.mapper;

import java.math.BigDecimal;
import java.math.BigInteger;
import java.util.Calendar;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import co.com.ath.pgw.in.dto.RBMPaymentAddRqType;
import co.com.ath.pgw.in.dto.RBMPaymentAddRsType;
import co.com.ath.pgw.in.model.AgreementInfoType;
import co.com.ath.pgw.in.model.CardLogicalDataType;
import co.com.ath.pgw.in.model.CustNameType;
import co.com.ath.pgw.in.model.FeeType;
import co.com.ath.pgw.in.model.OrderInfoType;
import co.com.ath.pgw.in.model.PersonalDataType;
import co.com.ath.pgw.in.model.ReferenceType;
import co.com.ath.pgw.in.model.TaxFeeType;
import co.com.ath.pgw.in.model.TransactionStatusType;
import co.com.ath.pgw.in.model.UserIdType;
import co.com.ath.pgw.rest.dto.AdditionalStatus;
import co.com.ath.pgw.rest.dto.MsgRsHdr;
import co.com.ath.pgw.rest.dto.PmtStatus;
import co.com.ath.pgw.rest.dto.RefInfo;
import co.com.ath.pgw.rest.dto.Status;
import co.com.ath.pgw.rest.request.dto.CreditTransactionRequest;
import co.com.ath.pgw.rest.request.dto.Header;
import co.com.ath.pgw.rest.response.dto.CreditTransactionResponse;
import co.com.ath.pgw.rest.response.dto.GenericErrorResponse;
import co.com.ath.pgw.util.constants.CoreConstants;
import co.com.ath.pgw.util.converter.DateUtil;
import co.com.ath.pgw.util.exception.CustomException;
/**
 * Servicio de Mapeo de objetos para pagos con tarjeta de credito
 * @author SophosSolutions
 * @version 1.0
 * @since 1.0
 */
public class MapperAddCreditTransaction {
	
	private static Logger LOGGER = LoggerFactory.getLogger(MapperAddCreditTransaction.class);
	/**
	 * mapeo request para pagos con tarjeta de credito.
	 * @param creditTransactionRequest
	 * @param header
	 * @return RBMPaymentAddRqType
	 * @throws CustomException
	 */	
	public static RBMPaymentAddRqType mapperRequestToCoreRequest(CreditTransactionRequest creditTransactionRequest, Header header) throws CustomException {
		RBMPaymentAddRqType rbmPaymentAddRqType = new RBMPaymentAddRqType();
		try {
			rbmPaymentAddRqType.setRqUID(header.getRqUID());
			rbmPaymentAddRqType.setChannel(header.getChannel());
			rbmPaymentAddRqType.setIPAddr(header.getIpAddr());
			rbmPaymentAddRqType.setClientDt(DateUtil.toXMLGregorianCalendar(Calendar.getInstance().getTime()));
			
			UserIdType userIdType = new UserIdType();
			userIdType.setCustIdNum(header.getIdentSerialNum());
			userIdType.setCustIdType(header.getGovIssueIdentType());
			rbmPaymentAddRqType.setUserId(userIdType);
			
			/*BENEFICIARIO*/
			PersonalDataType personalDataTypePayee = new PersonalDataType();
			CustNameType custNameTypePayee = new CustNameType();
			custNameTypePayee.setFirstName(creditTransactionRequest.getCustPayeeInfo().getPersonName().getFirstName());
			custNameTypePayee.setLastName(creditTransactionRequest.getCustPayeeInfo().getPersonName().getLastName());
			custNameTypePayee.setMiddleName(creditTransactionRequest.getCustPayeeInfo().getPersonName().getMiddleName());
			custNameTypePayee.setLegalName(creditTransactionRequest.getCustPayeeInfo().getPersonName().getLegalName());
			custNameTypePayee.setSecondLastName(creditTransactionRequest.getCustPayeeInfo().getPersonName().getSecondLastName());
			custNameTypePayee.setNickName(creditTransactionRequest.getCustPayeeInfo().getPersonName().getNickname());
			personalDataTypePayee.setCustName(custNameTypePayee);
			
			personalDataTypePayee.setCustIdType(creditTransactionRequest.getCustPayeeInfo().getGovIssueIdent().getGovIssueIdentType());
			personalDataTypePayee.setCustIdNum(creditTransactionRequest.getCustPayeeInfo().getGovIssueIdent().getIdentSerialNum());
			personalDataTypePayee.setEmailAddr(creditTransactionRequest.getCustPayeeInfo().getContactInfo().getEmailAddr());
			personalDataTypePayee.setPhone(creditTransactionRequest.getCustPayeeInfo().getContactInfo().getPhoneNum().getPhone());
			rbmPaymentAddRqType.getPersonalData().add(personalDataTypePayee);
			
			/*PAGADOR*/
			PersonalDataType personalDataType = new PersonalDataType();
			CustNameType custNameType = new CustNameType();
			custNameType.setFirstName(creditTransactionRequest.getCustInfo().getPersonInfo().getPersonName().getFirstName());
			custNameType.setLastName(creditTransactionRequest.getCustInfo().getPersonInfo().getPersonName().getLastName());
			custNameType.setMiddleName(creditTransactionRequest.getCustInfo().getPersonInfo().getPersonName().getMiddleName());
			custNameType.setLegalName(creditTransactionRequest.getCustInfo().getPersonInfo().getPersonName().getLegalName());
			custNameType.setSecondLastName(creditTransactionRequest.getCustInfo().getPersonInfo().getPersonName().getSecondLastName());
			custNameType.setNickName(creditTransactionRequest.getCustInfo().getPersonInfo().getPersonName().getNickname());
			personalDataType.setCustName(custNameType);
			
			personalDataType.setCustIdType(creditTransactionRequest.getCustInfo().getPersonInfo().getGovIssueIdent().getGovIssueIdentType());
			personalDataType.setCustIdNum(creditTransactionRequest.getCustInfo().getPersonInfo().getGovIssueIdent().getIdentSerialNum());
			personalDataType.setEmailAddr(creditTransactionRequest.getCustInfo().getPersonInfo().getContactInfo().getEmailAddr());
			personalDataType.setPhone(creditTransactionRequest.getCustInfo().getPersonInfo().getContactInfo().getPhoneNum().getPhone());				
			rbmPaymentAddRqType.getPersonalData().add(personalDataType);
			
			AgreementInfoType agreementInfoType = new AgreementInfoType();
			agreementInfoType.setAgreementId(creditTransactionRequest.getAgreement().getAgrmId());
			agreementInfoType.setName(creditTransactionRequest.getAgreement().getName());
			agreementInfoType.setNIT(creditTransactionRequest.getAgreement().getNit());
			agreementInfoType.setPhone(creditTransactionRequest.getAgreement().getContactInfo().getPhoneNum().getPhone());
			rbmPaymentAddRqType.setAgreementInfo(agreementInfoType);
			
			if (creditTransactionRequest.getCcAcctStmtRec().getNumberOfInstalments() !=null) {
				rbmPaymentAddRqType.setInstalamentsNum(new BigInteger(creditTransactionRequest.getCcAcctStmtRec().getNumberOfInstalments()));
			}			
			
			CardLogicalDataType cardLogicalDataType = new CardLogicalDataType();
			cardLogicalDataType.setCardEmbossNum(creditTransactionRequest.getCardAcctId().getAcctId());
			cardLogicalDataType.setCardVrfyData(creditTransactionRequest.getCardAcctId().getCcMotoAcct().getCardVrfyData());
			cardLogicalDataType.setExpDt(creditTransactionRequest.getCardAcctId().getCcMotoAcct().getExpDt() != null && !creditTransactionRequest.getCardAcctId().getCcMotoAcct().getExpDt().isEmpty() ? DateUtil.toXMLGregorianCalendar(DateUtil.parseString(creditTransactionRequest.getCardAcctId().getCcMotoAcct().getExpDt(), "yyyy-MM-dd")) : null);
			cardLogicalDataType.setBrand(creditTransactionRequest.getCardAcctId().getCcMotoAcct().getBrand());
			rbmPaymentAddRqType.setCardLogicalData(cardLogicalDataType);
			
			OrderInfoType orderInfoType = new OrderInfoType();
			orderInfoType.setOrderId(creditTransactionRequest.getInvoicePmtInfo().getInvoiceInfo().getInvoiceNum());
			orderInfoType.setDesc(creditTransactionRequest.getInvoicePmtInfo().getInvoiceInfo().getDesc());
			rbmPaymentAddRqType.setOrderInfo(orderInfoType);
			
			rbmPaymentAddRqType.setPmtId(creditTransactionRequest.getInvoicePmtInfo().getPmtStatus().getPmtAuthId());
			
			for(RefInfo refInfo: creditTransactionRequest.getRefInfo()) {
				ReferenceType referenceType = new ReferenceType();
				referenceType.setRefId(refInfo.getRefId());
				referenceType.setRefType(refInfo.getRefType());
				rbmPaymentAddRqType.getReference().add(referenceType);
			}
			
			FeeType feeType = new FeeType();
			feeType.setAmt(creditTransactionRequest.getFee().getCurAmt().getAmt());
			feeType.setCurCode(creditTransactionRequest.getFee().getCurAmt().getCurCode());
			feeType.setCurRate(new BigDecimal(creditTransactionRequest.getFee().getRate()));
			rbmPaymentAddRqType.setFee(feeType);
			
			TaxFeeType taxFeeType = new TaxFeeType();
			taxFeeType.setAmt(creditTransactionRequest.getTaxPmtInfo().getCurAmt().getAmt());
			taxFeeType.setCurCode(creditTransactionRequest.getTaxPmtInfo().getCurAmt().getCurCode());
			rbmPaymentAddRqType.setTaxFee(taxFeeType);
		} catch (Exception e) {
			LOGGER.error("Error mapeando informacion ", e.getMessage());
			throw new CustomException(e.getMessage(), setCustomError(e));
		}
		return rbmPaymentAddRqType;
	}
	/**
	 * mapeo respuesta exitosa para pagos con tarjeta de credito.
	 * @param rbmPaymentAddRsType
	 * @return CreditTransactionResponse
	 * @throws CustomException
	 */		
	public static CreditTransactionResponse mapperResponseSuccessCore(RBMPaymentAddRsType rbmPaymentAddRsType) throws CustomException {
		CreditTransactionResponse creditTransactionResponse = new CreditTransactionResponse();
		try {
			PmtStatus pmtStatus = new PmtStatus();
			pmtStatus.setPmtAuthId(rbmPaymentAddRsType.getPmtId());
			pmtStatus.setStatusCode(String.valueOf(rbmPaymentAddRsType.getTransactionStatus().getTrnStatusCode()));
			pmtStatus.setStatusDesc(rbmPaymentAddRsType.getTransactionStatus().getTrnStatusDesc());
			pmtStatus.setEffDt(DateUtil.toDate(rbmPaymentAddRsType.getTransactionStatus().getEffDt()));
			pmtStatus.setNextDt(DateUtil.toDate(rbmPaymentAddRsType.getTransactionStatus().getCompensationDt()));
			creditTransactionResponse.setPmtStatus(pmtStatus);
		} catch (Exception e) {
			LOGGER.error("Error mapeando informacion ", e.getMessage());
			throw new CustomException(e.getMessage(), setCustomError(e));
		}
		return creditTransactionResponse;
	}
	/**
	 * mapeo respuesta error generico para pagos con tarjeta de credito.
	 * @param rbmPaymentAddRsType
	 * @return GenericErrorResponse
	 * @throws CustomException
	 */		
	public static GenericErrorResponse mapperResponseErrorCore(RBMPaymentAddRsType rbmPaymentAddRsType) throws CustomException {
		GenericErrorResponse genericErrorResponse = new GenericErrorResponse();
		
		Status status = new Status();
		status.setStatusCode(String.valueOf(rbmPaymentAddRsType.getStatusCode()));
		status.setStatusDesc(rbmPaymentAddRsType.getStatusDesc());
		status.setEndDt(Calendar.getInstance().getTime());
		
		AdditionalStatus additionalStatus = new AdditionalStatus();
		additionalStatus.setStatusCode(rbmPaymentAddRsType.getTransactionStatus().getTrnServerStatusCode());
		additionalStatus.setStatusDesc(rbmPaymentAddRsType.getTransactionStatus().getTrnServerStatusDesc());
		status.setAdditionalStatus(additionalStatus);
		
		MsgRsHdr msgRsHdr = new MsgRsHdr();
		msgRsHdr.setStatus(status);
		msgRsHdr.setEndDt(Calendar.getInstance().getTime());
		genericErrorResponse.setMsgRsHdr(msgRsHdr);
		
		return genericErrorResponse;
	}
	/**
	 * mapeo respuesta error para pagos con tarjeta de credito.
	 * @param Exception
	 * @return RBMPaymentAddRsType
	 */			
	public static RBMPaymentAddRsType setCustomError(Exception e){
		RBMPaymentAddRsType rbmPaymentAddRsType = new RBMPaymentAddRsType();
		rbmPaymentAddRsType.setStatusCode(CoreConstants.ERROR_STATUS_CODE_300);
		rbmPaymentAddRsType.setStatusDesc(CoreConstants.ERROR_STATUS_CODE_DESC);
		
		TransactionStatusType transactionStatusType = new TransactionStatusType();
		transactionStatusType.setTrnStatusCode(Long.valueOf(CoreConstants.ERROR_STATUS_CODE_300));
		transactionStatusType.setTrnStatusDesc(CoreConstants.ERROR_STATUS_CODE_DESC);
		transactionStatusType.setTrnServerStatusCode(CoreConstants.ERROR_STATUS_CODE_300.toString());
		transactionStatusType.setTrnServerStatusDesc(e.toString());
		rbmPaymentAddRsType.setTransactionStatus(transactionStatusType);
		return rbmPaymentAddRsType;
	}
	
}
