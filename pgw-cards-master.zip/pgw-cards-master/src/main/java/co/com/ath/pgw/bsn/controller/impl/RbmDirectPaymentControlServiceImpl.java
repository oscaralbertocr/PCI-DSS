package co.com.ath.pgw.bsn.controller.impl;

import javax.annotation.Resource;

import org.springframework.stereotype.Service;

import co.com.ath.pgw.bsn.controller.RbmDirectPaymentControlService;
import co.com.ath.pgw.bsn.service.PGWRbmDirectPaymentService;
import co.com.ath.pgw.in.dto.CreditCardPaymentAddRequest;
import co.com.ath.pgw.in.dto.CreditCardPaymentAddResponse;
import co.com.ath.pgw.util.exception.CustomException;
/**
* Implementación de servicio puente para las peticiones entre 
* los servicios de RBM que vienen de k7 al core
* 
* @author sophosSolutions
* @version 1.0 22/07/2019
*/
@Service
public class RbmDirectPaymentControlServiceImpl implements RbmDirectPaymentControlService {

	@Resource
	PGWRbmDirectPaymentService pgwRbmDirectPaymentService;

	@Override
	public CreditCardPaymentAddResponse creditCardPaymentAdd(CreditCardPaymentAddRequest creditCardPaymentAddRequest) throws CustomException {
		CreditCardPaymentAddResponse creditCardPaymentAddResponse = null;
		try {
			creditCardPaymentAddResponse = pgwRbmDirectPaymentService.creditCardPaymentAdd(creditCardPaymentAddRequest);
		} catch (CustomException e) {
			throw new CustomException(e.getMessage(), (CreditCardPaymentAddResponse)e.getObjeto());
		}
		return creditCardPaymentAddResponse;
	}

}