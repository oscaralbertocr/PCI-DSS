package co.com.ath.pgw.bsn.service.impl;

import java.math.BigDecimal;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

import javax.annotation.Resource;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import co.com.ath.pgw.bsn.dto.in.IniciarTransaccionInDTO;
import co.com.ath.pgw.bsn.dto.out.IniciarTransaccionOutDTO;
import co.com.ath.pgw.bsn.globalPay.model.ReferenceType;
import co.com.ath.pgw.bsn.service.PGWGlobalPayCheckoutService;
import co.com.ath.pgw.bsn.service.rs.NotificationPayments;
import co.com.ath.pgw.controller.out.rbm.globalPay.RBMGlobalPayCtrlService;
import co.com.ath.pgw.persistence.dao.BrandDAO;
import co.com.ath.pgw.persistence.dao.NonWorkingDayDAO;
import co.com.ath.pgw.persistence.dao.PaymentWayDAO;
import co.com.ath.pgw.persistence.dao.TransactionDAO;
import co.com.ath.pgw.persistence.dao.TransactionStatusDAO;
import co.com.ath.pgw.persistence.model.Brand;
import co.com.ath.pgw.persistence.model.NonWorkingDay;
import co.com.ath.pgw.persistence.model.Transaction;
import co.com.ath.pgw.persistence.model.TransactionStatus;
import co.com.ath.pgw.persistence.service.ReconciledTransactionService;
import co.com.ath.pgw.persistence.service.SendMailService;
import co.com.ath.pgw.util.constants.CoreConstants;
import co.com.ath.pgw.util.constants.PaymentWayCodes;
import co.com.ath.pgw.util.converter.DateUtil;
import co.com.ath.pgw.util.enums.AVALBankEnum;
import co.com.ath.pgw.util.enums.TransactionStatusEnum;
import co.com.ath.pgw.util.i18n.BundleKeys;
import co.com.ath.pgw.util.i18n.BundleType;
import co.com.ath.pgw.util.i18n.ResourceBundleManager;
import co.com.ath.pgw.util.mask.MaskData;
import co.com.ath.ws.rs.objects.BankInfo;
import co.com.ath.ws.rs.objects.TransactionNotification;

/**
 * Implementacion de checkout GlobalPay
 * 
 */
@Service
public class PGWGlobalPayCheckoutImpl implements PGWGlobalPayCheckoutService {

	static Logger LOGGER = LoggerFactory.getLogger(PGWGlobalPayCheckoutImpl.class);

	@Resource
	private RBMGlobalPayCtrlService rbmGlobalPayCtrlService;

	@Resource
	public TransactionDAO transactionDAO;
	
	@Resource
	public PaymentWayDAO paymentWayDAO;
	
	@Resource
	public TransactionStatusDAO transactionStatusDAO;

	@Resource
	private ReconciledTransactionService reconciledTransactionService;

	@Resource
	private SendMailService sendMailService;
	
    @Resource
	private ResourceBundleManager resourceBundleManager;
    
	@Resource
	private BrandDAO brandDAO;
	
	@Resource
	private NotificationPayments notificationPayments;
    
	@Value("${pasarela.pse.nitagregador}")
	private String nitAgregator;

	@Value("${pasarela.pse.nitagregador.avVillas}")
	private String nitAgregatorAvVillas;
    
    
	/** información de localización */
    public Locale locale;
    
	Calendar calendar = Calendar.getInstance(Locale.getDefault());
	
	@Resource
	private NonWorkingDayDAO nonWorkingDayDAO;
	
	@Value("${hour_compensation_date}")
	private int hourCompensation;
	
	@Value("${minutes_compensation_date}")
	private int minutesCompensation;
	
	public static final String FORMATO_FECHA = "yyyy-MM-dd'T'HH:mm:ss.SSS";
	
	@Resource
	public MaskData maskData;


	@Override
	public IniciarTransaccionOutDTO checkout(IniciarTransaccionInDTO iniciarTransaccionInDTO) {
		
		LOGGER.info("@PGWGlobalPayCheckoutImpl checkout pmtid: {}, RqUID: {}", 
				iniciarTransaccionInDTO.getTransactionBO().getPmtId(), iniciarTransaccionInDTO.getRqUID());

		TransactionStatus transactionStatus;

		IniciarTransaccionOutDTO iniciarTransaccionOutDTO = new IniciarTransaccionOutDTO();

		iniciarTransaccionOutDTO.setRqUID(iniciarTransaccionInDTO.getRqUID());

		// Obtener la transacción
		Transaction transaction = transactionDAO.findByPmtId(Long.valueOf(iniciarTransaccionInDTO.getTransactionBO().getPmtId()));

		Long pmtid = null;
		if (null != transaction && null != transaction.getPmtId())
			pmtid = transaction.getPmtId();

		try {

			transaction.setPaymentWay(paymentWayDAO.read(PaymentWayCodes.TC));
			if (iniciarTransaccionInDTO.getTransactionBO().getTermsNConditions() != null
					&& !iniciarTransaccionInDTO.getTransactionBO().getTermsNConditions().isEmpty()) {
				transaction.setTermsAndConditions(
						Boolean.parseBoolean(iniciarTransaccionInDTO.getTransactionBO().getTermsNConditions()));
			}

			transaction.setGlobalPay(true);
			transaction.setBankCollecter(transaction.getCommerce().getSubscription().getBank());
			transaction.setIpAddress(iniciarTransaccionInDTO.getTransactionBO().getIpAddress());
			transaction.setResponseCode(null);

			// Cambio Nombre Duplicado INI
			if (iniciarTransaccionInDTO.getTransactionBO().getCustomerName() != null
					&& !iniciarTransaccionInDTO.getTransactionBO().getCustomerName().isEmpty()
					&& !iniciarTransaccionInDTO.getTransactionBO().getCustomerName().equals("GUEST")) {
				transaction.setPayerName(iniciarTransaccionInDTO.getTransactionBO().getFirstNamePayer());
				transaction.setMiddleNamePayer("");
				transaction.setLastNamePayer("");
				transaction.setSecondLastNamePayer("");
			}
			// Cambio Nombre Duplicado FIN

			transaction.setBankCollecter(transaction.getCommerce().getSubscription().getBank());

			// información del comprador
			if (iniciarTransaccionInDTO.getTransactionBO().getCustomerName() != null
					&& !iniciarTransaccionInDTO.getTransactionBO().getCustomerName().isEmpty()) {
				transaction.setCustomerName(iniciarTransaccionInDTO.getTransactionBO().getCustomerName());
			}

			if (iniciarTransaccionInDTO.getTransactionBO().getMiddleNameBuyer() != null
					&& !iniciarTransaccionInDTO.getTransactionBO().getMiddleNameBuyer().isEmpty()) {
				transaction.setMiddleNameBuyer(iniciarTransaccionInDTO.getTransactionBO().getMiddleNameBuyer());
			}

			if (iniciarTransaccionInDTO.getTransactionBO().getLastNameBuyer() != null
					&& !iniciarTransaccionInDTO.getTransactionBO().getLastNameBuyer().isEmpty()) {
				transaction.setLastNameBuyer(iniciarTransaccionInDTO.getTransactionBO().getLastNameBuyer());
			}

			if (iniciarTransaccionInDTO.getTransactionBO().getSecondLastNameBuyer() != null
					&& !iniciarTransaccionInDTO.getTransactionBO().getSecondLastNameBuyer().isEmpty()) {
				transaction.setSecondLastNameBuyer(iniciarTransaccionInDTO.getTransactionBO().getSecondLastNameBuyer());
			}

			if (iniciarTransaccionInDTO.getTransactionBO().getCustomerEmail() != null
					&& !iniciarTransaccionInDTO.getTransactionBO().getCustomerEmail().isEmpty()) {
				transaction.setCustomerEmail(iniciarTransaccionInDTO.getTransactionBO().getCustomerEmail());
			}

			if (iniciarTransaccionInDTO.getTransactionBO().getCustomerMobileNumber() != null
					&& !iniciarTransaccionInDTO.getTransactionBO().getCustomerMobileNumber().isEmpty()) {
				transaction
						.setCustomerMobileNumber(iniciarTransaccionInDTO.getTransactionBO().getCustomerMobileNumber());
			}

			// información del pagador
			if (iniciarTransaccionInDTO.getTransactionBO().getPayerCompany() != null
					&& !iniciarTransaccionInDTO.getTransactionBO().getPayerCompany().isEmpty()) {
				transaction.setPayerCompany(iniciarTransaccionInDTO.getTransactionBO().getPayerCompany());
			}

			if (iniciarTransaccionInDTO.getTransactionBO().getFirstNamePayer() != null
					&& !iniciarTransaccionInDTO.getTransactionBO().getFirstNamePayer().isEmpty()) {
				transaction.setPayerName(iniciarTransaccionInDTO.getTransactionBO().getFirstNamePayer());
			}

			if (iniciarTransaccionInDTO.getTransactionBO().getMiddleNamePayer() != null
					&& !iniciarTransaccionInDTO.getTransactionBO().getMiddleNamePayer().isEmpty()) {
				transaction.setMiddleNamePayer(iniciarTransaccionInDTO.getTransactionBO().getMiddleNamePayer());
			}

			if (iniciarTransaccionInDTO.getTransactionBO().getLastNamePayer() != null
					&& !iniciarTransaccionInDTO.getTransactionBO().getLastNamePayer().isEmpty()) {
				transaction.setLastNamePayer(iniciarTransaccionInDTO.getTransactionBO().getLastNamePayer());
			}

			if (iniciarTransaccionInDTO.getTransactionBO().getSecondLastNamePayer() != null
					&& !iniciarTransaccionInDTO.getTransactionBO().getSecondLastNamePayer().isEmpty()) {
				transaction.setSecondLastNamePayer(iniciarTransaccionInDTO.getTransactionBO().getSecondLastNamePayer());
			}

			if (iniciarTransaccionInDTO.getTransactionBO().getPayerNickName() != null
					&& !iniciarTransaccionInDTO.getTransactionBO().getPayerNickName().isEmpty()) {
				transaction.setPayerNickName(iniciarTransaccionInDTO.getTransactionBO().getPayerNickName());
			}

			if (iniciarTransaccionInDTO.getTransactionBO().getPayerDocType() != null
					&& !iniciarTransaccionInDTO.getTransactionBO().getPayerDocType().isEmpty()) {
				transaction.setPayerDocType(iniciarTransaccionInDTO.getTransactionBO().getPayerDocType());
			}

			if (iniciarTransaccionInDTO.getTransactionBO().getPayerDocId() != null
					&& !iniciarTransaccionInDTO.getTransactionBO().getPayerDocId().isEmpty()) {
				transaction.setPayerDocId(iniciarTransaccionInDTO.getTransactionBO().getPayerDocId());
			}

			if (iniciarTransaccionInDTO.getTransactionBO().getPayerGender() != null
					&& !iniciarTransaccionInDTO.getTransactionBO().getPayerGender().isEmpty()) {
				transaction.setPayerGender(iniciarTransaccionInDTO.getTransactionBO().getPayerGender());
			}

			if (iniciarTransaccionInDTO.getTransactionBO().getPayerBirthDate() != null
					&& iniciarTransaccionInDTO.getTransactionBO().getPayerBirthDate().toString() != "") {
				transaction.setPayerBirthDate(iniciarTransaccionInDTO.getTransactionBO().getPayerBirthDate());
			}

			if (iniciarTransaccionInDTO.getTransactionBO().getPayerCity() != null
					&& !iniciarTransaccionInDTO.getTransactionBO().getPayerCity().isEmpty()) {
				transaction.setPayerCity(iniciarTransaccionInDTO.getTransactionBO().getPayerCity());
			}

			if (iniciarTransaccionInDTO.getTransactionBO().getPayerDepartment() != null
					&& !iniciarTransaccionInDTO.getTransactionBO().getPayerDepartment().isEmpty()) {
				transaction.setPayerDepartment(iniciarTransaccionInDTO.getTransactionBO().getPayerDepartment());
			}

			if (iniciarTransaccionInDTO.getTransactionBO().getPayerCountry() != null
					&& !iniciarTransaccionInDTO.getTransactionBO().getPayerCountry().isEmpty()) {
				transaction.setPayerCounty(iniciarTransaccionInDTO.getTransactionBO().getPayerCountry());
			}

			if (iniciarTransaccionInDTO.getTransactionBO().getPayerAddress() != null
					&& !iniciarTransaccionInDTO.getTransactionBO().getPayerAddress().isEmpty()) {
				transaction.setPayerAddress(iniciarTransaccionInDTO.getTransactionBO().getPayerAddress());
			}

			if (iniciarTransaccionInDTO.getTransactionBO().getPayerMail() != null
					&& !iniciarTransaccionInDTO.getTransactionBO().getPayerMail().isEmpty()) {
				transaction.setPayerMail(iniciarTransaccionInDTO.getTransactionBO().getPayerMail());
			}

			if (iniciarTransaccionInDTO.getTransactionBO().getPayerPhone() != null
					&& !iniciarTransaccionInDTO.getTransactionBO().getPayerPhone().isEmpty()) {
				transaction.setPayerPhone(iniciarTransaccionInDTO.getTransactionBO().getPayerPhone());
			}

			if (iniciarTransaccionInDTO.getTransactionBO().getCustomerName() != null
					&& !iniciarTransaccionInDTO.getTransactionBO().getCustomerName().isEmpty()) {
				transaction.setCustomerName(iniciarTransaccionInDTO.getTransactionBO().getCustomerName());
			}

			if (iniciarTransaccionInDTO.getTransactionBO().getCustomerEmail() != null
					&& !iniciarTransaccionInDTO.getTransactionBO().getCustomerEmail().isEmpty()) {
				transaction.setCustomerEmail(iniciarTransaccionInDTO.getTransactionBO().getCustomerEmail());
			}

			if (iniciarTransaccionInDTO.getTransactionBO().getCustomerMobileNumber() != null
					&& !iniciarTransaccionInDTO.getTransactionBO().getCustomerMobileNumber().isEmpty()) {
				transaction
						.setCustomerMobileNumber(iniciarTransaccionInDTO.getTransactionBO().getCustomerMobileNumber());
			}

			// Se recorta a los primeros 6 digitos
			iniciarTransaccionInDTO.setRqUID(convertRqId(iniciarTransaccionInDTO.getRqUID()));

			// Se almacena el rquId
			transaction.setRquId(iniciarTransaccionInDTO.getRqUID().toString());

			transaction.setCustomerDocType(iniciarTransaccionInDTO.getTransactionBO().getCustomerDocType());
			transaction.setCustomerDocId(iniciarTransaccionInDTO.getTransactionBO().getCustomerDocId());

			transaction.setPaymentWay(paymentWayDAO.read(PaymentWayCodes.TC));

			transactionStatus = transactionStatusDAO.findById(TransactionStatusEnum.PROCESSING.getCode());

			if ((TransactionStatusEnum.REGISTERED.getCode().equals(transaction.getStatus().getCode())
					|| TransactionStatusEnum.LOGGED_IN.getCode().equals(transaction.getStatus().getCode()))) {
				LOGGER.info("pmtid:{} Cambiando estado a {}, previo a procesar datos de RBM.",
						transaction.getPmtId(), transactionStatus);
				transaction.setStatus(transactionStatus);
			}

			// Actualiza la informacion de la transaccion inicialmente
			transactionDAO.update(transaction);

			
			// Comienza el procesamiento de la informacion de GlobalPay
			String globalPayId = null;
			String globalPayStatus = null;
			String globalPayStatusDetail = null;
			String globalPayAuthorizationCode = null;
			Date globalPayDate = null;
			String globalPayCardType = null;
			String globalPayCardBin = null;
			String globalPayCardNumber = null;

			// Se validan las referencias
			if (null != iniciarTransaccionInDTO.getReferences() && !iniciarTransaccionInDTO.getReferences().isEmpty()) {

				// Se obtienen las referencias
				List<ReferenceType> references = iniciarTransaccionInDTO.getReferences();
				for (ReferenceType referenceType : references) {

					if (referenceType.getRefId().equals(CoreConstants.GLOBALPAY_ID)) {
						globalPayId = referenceType.getRefType();
					} else if (referenceType.getRefId().equals(CoreConstants.GLOBALPAY_STATUS)) {
						globalPayStatus = referenceType.getRefType();
					} else if (referenceType.getRefId().equals(CoreConstants.GLOBALPAY_DETAIL)) {
						globalPayStatusDetail = referenceType.getRefType();
					} else if (referenceType.getRefId().equals(CoreConstants.GLOBALPAY_AUTHORIZATIONCODE)) {
						globalPayAuthorizationCode = referenceType.getRefType();
					} else if (referenceType.getRefId().equals(CoreConstants.GLOBALPAY_PAYMENTDATE)) {						
						globalPayDate=DateUtil.parseString(referenceType.getRefType(), FORMATO_FECHA);
					} else if (referenceType.getRefId().equals(CoreConstants.GLOBALPAY_CARDTYPE)) {						
						globalPayCardType = referenceType.getRefType().equals(CoreConstants.GLOBALPAY_VISA) ? "1": referenceType.getRefType().equals(CoreConstants.GLOBALPAY_MASTERCARD)?"2":"";
					} else if (referenceType.getRefId().equals(CoreConstants.GLOBALPAY_CARDBIN)) {						
						globalPayCardBin = referenceType.getRefType();
					} else if (referenceType.getRefId().equals(CoreConstants.GLOBALPAY_CARDNUMBER)) {						
						globalPayCardNumber = referenceType.getRefType();
					}				
					
				}

			} else {
				
				// ERROR: El DTO no trae las referencias de GlobalPay
				throw new Exception("No se obtuvieron las referencias globalPayId, globalPayStatus y globalPayStatusDetail de GlobalPay.");
			}
			
			// Se valida que las referencias necesarias con la informacion de la tx esten
			if (null == globalPayId || null == globalPayStatus || null == globalPayStatusDetail
					|| "".equals(globalPayId) || "".equals(globalPayStatus) || "".equals(globalPayStatusDetail)) {
				
				// ERROR: Referencias vacias
				throw new Exception("Las referencias globalPayId, globalPayStatus o globalPayStatusDetail no pueden estar vacias.");
				
			} else {
				
				LOGGER.info("pmtid:{}, globalPayId:{}, globalPayStatus:{}, globalPayStatusDetail:{}", 
						pmtid, globalPayId, globalPayStatus, globalPayStatusDetail);
				
				transaction.setTrazabilityCode(globalPayId);
				
				transaction.setApprovalNumber(globalPayAuthorizationCode != null ? globalPayAuthorizationCode : globalPayId);
				
				Date current = new Date();
				Date response =new Date();
				
				response = globalPayDate != null ? fechaUTCaCOT(globalPayDate):current;
				
				transaction.setPayDate(response);
				
				
				transaction.setIdBrand(new BigDecimal(globalPayCardType));				
				
				// Se procesan los diferentes estados de GlobaPay
				if (globalPayStatus.equals(CoreConstants.GLOBALPAY_STATUS_APROBADA)) {
					
					transaction.setCompensationDate(calcCompensationDate(response));

					transactionStatus = transactionStatusDAO.findById(TransactionStatusEnum.CONFIRMED_OK.getCode());
					transaction.setStatus(transactionStatus);

					LOGGER.info("pmtid:{} Cambiando estado a {} en procesamiento de estados.",
							transaction.getPmtId(), transactionStatus);

					transactionDAO.update(transaction);

					iniciarTransaccionOutDTO.setStatusCode(CoreConstants.SUCCESS_STATUS_CODE);
					iniciarTransaccionOutDTO.setStatusDesc(getMessage(BundleKeys.TRANSACTION_SUCCESS, null, locale));
					iniciarTransaccionOutDTO.setTrnStatusCode(transactionStatus.getBusinessCode().getCode());
					iniciarTransaccionOutDTO.setTrnStatusDesc(getMessage(transactionStatus.getBusinessCode().getDescription().getMessageCode(), null, locale));
					iniciarTransaccionOutDTO.setApprovalId(globalPayId);
					iniciarTransaccionOutDTO.setUrlRBM("");
					
					notificacion(transaction, TransactionStatusEnum.CONFIRMED_OK);

				} else if (globalPayStatus.equals(CoreConstants.GLOBALPAY_STATUS_PENDIENTE)) {

					transactionStatus = transactionStatusDAO.findById(TransactionStatusEnum.PROCESSING.getCode());

					if ((TransactionStatusEnum.REGISTERED.getCode().equals(transaction.getStatus().getCode())
							|| TransactionStatusEnum.LOGGED_IN.getCode().equals(transaction.getStatus().getCode()))) {
						
						LOGGER.info("pmtid:{} Cambiando estado a {} en procesamiento de estados.",
								transaction.getPmtId(), transactionStatus);
						
						transaction.setStatus(transactionStatus);

					} else if (TransactionStatusEnum.PROCESSING.getCode().equals(transaction.getStatus().getCode())) {
						LOGGER.info("pmtid:{}. La transaccion se ya encuentra en estado {} "
								+ "en la BD del Core de la Pasarela {}",
								transaction.getPmtId(), transactionStatus);
					} else {
						LOGGER.info("pmtid:{}. La transaccion se ya encuentra en un estado final ({})"
								+ "en la BD del Core de la Pasarela {}",
								transaction.getPmtId(), transaction.getStatus());
					}
					
					transactionDAO.update(transaction);

					
					iniciarTransaccionOutDTO.setStatusCode(CoreConstants.SUCCESS_STATUS_CODE);
					iniciarTransaccionOutDTO.setStatusDesc(getMessage(BundleKeys.TRANSACTION_SUCCESS, null, locale));
					iniciarTransaccionOutDTO.setTrnStatusCode(transactionStatus.getBusinessCode().getCode());
					iniciarTransaccionOutDTO.setTrnStatusDesc(getMessage(transactionStatus.getBusinessCode().getDescription().getMessageCode(), null, locale));
					iniciarTransaccionOutDTO.setApprovalId(globalPayId);
					iniciarTransaccionOutDTO.setUrlRBM("");

				} else if (globalPayStatus.equals(CoreConstants.GLOBALPAY_STATUS_FALLIDA) ) {

					LOGGER.info("transaccion pmtid: {} rechazada por RBM: {}",
							iniciarTransaccionInDTO.getTransactionBO().getPmtId(), globalPayStatusDetail);

					transactionStatus = transactionStatusDAO.findById(TransactionStatusEnum.CONFIRMED_NA.getCode());
					transaction.setStatus(transactionStatus);
					
					LOGGER.info("pmtid:{} Cambiando estado a {} en procesamiento de estados",
							transaction.getPmtId(), transactionStatus);

					transactionDAO.update(transaction);
					
					iniciarTransaccionOutDTO.setTrnStatusCode(null);
					iniciarTransaccionOutDTO.setTrnStatusDesc(null);

					notificacion(transaction, TransactionStatusEnum.CONFIRMED_NA);

				} else {
					
					transactionDAO.update(transaction);
					
					// ERROR: globalPayStatusDetail NO MAPEADA
					throw new Exception("El globalPayStatusDetail: "+globalPayStatusDetail+" no esta mapeado dentro del Core.");
				}


				// Objeto de salida
				iniciarTransaccionOutDTO.setPmtId(String.valueOf(transaction.getPmtId()));
				iniciarTransaccionOutDTO.setTrnServerStatusCode(globalPayStatus);
				iniciarTransaccionOutDTO.setTrnServerStatusDesc(globalPayStatusDetail);
				iniciarTransaccionOutDTO.setEffDt(transaction.getPayDate());
				iniciarTransaccionOutDTO.setApprovalId(transaction.getApprovalNumber());
				
			}


		} catch (Exception e) {
			
			LOGGER.error("pmtid: {}, Error: {}", 
					iniciarTransaccionInDTO.getTransactionBO().getPmtId(), e);

			LOGGER.error("ocurrio un error procesando la transaccion "
							+ "RqUID:{} \nException:{} \nCausa:{} ",
					iniciarTransaccionInDTO.getRqUID(), e.getLocalizedMessage(), e.getCause());

			iniciarTransaccionOutDTO.setStatusCode(CoreConstants.ERROR_STATUS_CODE_300);
			iniciarTransaccionOutDTO.setStatusDesc(CoreConstants.ERROR_STATUS_CODE_DESC_300);
			iniciarTransaccionOutDTO.setTrnStatusCode(Long.valueOf(CoreConstants.FAULT_STATUS_CODE));
			iniciarTransaccionOutDTO.setTrnStatusDesc(CoreConstants.FAULT_STATUS_ERROR_DESC);
			iniciarTransaccionOutDTO.setTrnServerStatusCode(String.valueOf(CoreConstants.FAULT_STATUS_CODE));
			iniciarTransaccionOutDTO.setTrnServerStatusDesc(e.toString());

		}

		return iniciarTransaccionOutDTO;

	}

	private void notificacion(Transaction transaction, TransactionStatusEnum txStatus) {

		// Leer Envio de Correo Electrónico
		Transaction txdata = transactionDAO.read(transaction.getId());

		if (txdata.getEmailflag() == CoreConstants.FLAG_EMAIL_OFF) {
			try {
				transaction.setEmailflag(CoreConstants.FLAG_EMAIL_ON);
				transactionDAO.update(transaction);
	
				// Conciliar la transacción
				reconciledTransactionService.createOrUpdate(transaction, null);
	
				// Enviar correo de confirmación
				sendMailService.sendMail(transaction);
	
				if (!(transaction.getCustomerEmail().equals(transaction.getPayerMail()))
						&& (transaction.getStatus().getCode() == txStatus.getCode())) {
	
					String mail = transaction.getPayerMail();
					transaction.setPayerMail(transaction.getCustomerEmail());
	
					sendMailService.sendMail(transaction);
					transaction.setPayerMail(mail);
				}
			}catch(Exception e) {
				LOGGER.error("pmtid: {}, Error: {}", transaction.getPmtId(), e.getMessage());
			}finally {
				if (transaction.getNotificacionPPagos() == null || transaction.getNotificacionPPagos()==0) {
					if (updateInformation(transaction)) {
						transaction.setNotificacionPPagos(1);
						transactionDAO.update(transaction);	
						LOGGER.info("Se actualizo el estado de notificacion a portal de pagos: {}",transaction.getPmtId());
					}
				}
			}			
		}
	}

	/**
	 * obtiene los mensajes de bundles
	 * 
	 * @param String messageKey
	 * @param Object args
	 * @param Locale
	 * @return String
	 */
	private String getMessage(String messageKey, Object[] args, Locale locale) {

		if (resourceBundleManager == null) {
			return messageKey;
		}

		resourceBundleManager.setBundle(BundleType.MESSAGES);
		return resourceBundleManager.getMessage(messageKey, args, locale);
	}

	/**
	 * reduce la dimension del rqId
	 * 
	 * @param Long
	 * @return Long
	 */
	private Long convertRqId(Long rqId) {
		StringBuilder num = new StringBuilder(rqId.toString());
		if (num.length() < 7) {
			return rqId;
		}
		return Long.valueOf(num.substring(0, 6));
	}
	
	/**
	 * Se informa al Portal de Pagos el estado de la transaccion
	 */
	private boolean updateInformation(Transaction transaction) {

		boolean result=true;
		try {
			TransactionNotification transactionNotification =new TransactionNotification();

			transactionNotification.setBusinessCode(transaction.getStatus().getBusinessCode().getCode());
			transactionNotification.setBusinessCodeDesc(transaction.getStatus().getBusinessCode().getDescription().name());
			transactionNotification.setCommerceNuraCode(transaction.getCommerce().getNuraCode());
			transactionNotification.setPmtId(transaction.getPmtId());
			transactionNotification.setRquId(transaction.getRquId());
			transactionNotification.setTrnChannel(transaction.getTrnChannel());
			transactionNotification.setIpAddress(transaction.getIpAddress());
			transactionNotification.setCustomerDocId(transaction.getCustomerDocId());
			transactionNotification.setCustomerDocType(transaction.getCustomerDocType());
			transactionNotification.setAmt(transaction.getTotalValue());
			transactionNotification.setCurCode(transaction.getCurrency());				
			transactionNotification.setAgreementId(getAgrementId(transaction));
			transactionNotification.setName(transaction.getCommerce().getSubscription().getCompanyName());
			transactionNotification.setNit(transactionDAO.getAggregatorNit(transaction, nitAgregator, nitAgregatorAvVillas));
			transactionNotification.setPhone(transaction.getCommerce().getSubscription().getPhone());								
			transactionNotification.setFirstName(transaction.getCustomerName() != null ? transaction.getCustomerName() : "");
			transactionNotification.setMiddleName(transaction.getMiddleNameBuyer() != null ? transaction.getMiddleNameBuyer() : "");
			transactionNotification.setLastName(transaction.getLastNameBuyer() != null ? transaction.getLastNameBuyer() : "");
			transactionNotification.setSecondLastName(transaction.getSecondLastNameBuyer() != null ? transaction.getSecondLastNameBuyer() : "");				
			transactionNotification.setCustIdType(transaction.getPayerDocType() != null ? transaction.getPayerDocType() : "");
			transactionNotification.setCustIdNum(transaction.getPayerDocId() != null ? transaction.getPayerDocId() : "");
			transactionNotification.setAddress(transaction.getPayerAddress());
			transactionNotification.setEmailAddr(transaction.getPayerMail() != null ? transaction.getPayerMail() : "");
			transactionNotification.setPhone(transaction.getPayerPhone() != null ? transaction.getPayerPhone() : "");				
			transactionNotification.setRquId(transaction.getRquId());
			transactionNotification.setPmtId(transaction.getPmtId());
			transactionNotification.setTrnChannel(transaction.getTrnChannel());				
			transactionNotification.setStatusCode(transaction.getStatus().getCode());
			transactionNotification.setStatusDesc(transaction.getStatus().getDescription().toString());
			transactionNotification.setOrderId(transaction.getOrderNumber()); 
			transactionNotification.setOrderDesc(transaction.getDescription());				
			transactionNotification.setPmtWayId(String.valueOf(transaction.getPaymentWay().getId()));
			transactionNotification.setPmtWayType(transaction.getPaymentWay().getName());

			BankInfo bankInfo = new BankInfo();
			bankInfo.setBankId(transaction.getBank() == null ? null : transaction.getBank().getAvalCode());	
			transactionNotification.setBankInfo(bankInfo);
			transactionNotification.setEffDt(getDate(transaction));
			transactionNotification.setCompensationDate(transaction.getCompensationDate());
			transactionNotification.setApprovalId(PaymentWayCodes.PSE.equals(transaction.getPaymentWay().getId()) ? transaction.getTrazabilityCode()
					: transaction.getApprovalNumber());
			transactionNotification.setReferenceMap(getReferenceMap(transaction, true));
			transactionNotification.setIdOrigenTransaccion(transaction.getSource().getId().toString());
			String codNie = "";

			LOGGER.info("Validacion de tipo de pago PSE y pago de tarjeta de credito. tipo de pago: {}, token: {}", transaction.getPaymentWay().getId(), transaction.getTokenized());

			if(PaymentWayCodes.PSE.equals(transaction.getPaymentWay().getId()) && transaction.getTokenized()!=null ) {
				LOGGER.info("Validacion de tipo de pago PSE y pago de tarjeta de credito se encontro");
				codNie = transaction.getTokenized();
			}else {
				LOGGER.info("Validacion de tipo de pago PSE y pago de tarjeta de credito No se encontro");
			}
			transactionNotification.setCodNIE(codNie);			

			result=notificationPayments.notification(transactionNotification);	
		} catch (Exception e) {
			result=false;
			LOGGER.error("No fue posible consumir el servicio @NotificationPayments {}",
					e.getLocalizedMessage());
		}
		return result;
	}
	
	private String getAgrementId(Transaction transaction) {
		String nuraCode = transaction.getCommerce().getNuraCode();
		final boolean needHomologate = transaction.getBank() != null
				&& AVALBankEnum.AV_VILLAS.getAvalCode().equals(transaction.getBank().getAvalCode())
				&& transaction.getCommerce().getHomologationBAVVCode() != null;
		if (needHomologate) {
			return transaction.getCommerce().getHomologationBAVVCode();
		}

		if (nuraCode.startsWith("CPV")) {
			nuraCode = nuraCode.substring(3, nuraCode.length());
		}

		return nuraCode;
	}
	
	private Date getDate(Transaction transaction) {
		if (transaction.getPayDate() != null) {
			return transaction.getPayDate();
		}
		return transaction.getTransactionDate();
	}
	
	/**
	 * Obtiene las referencias de la transaccion y las retorna en una lista de
	 * string.
	 * 
	 * @param tx
	 *            Transaccion a procesar
	 * @return Lista con las referencias encontradas o lista vacia si no hay
	 *         ninguna.
	 */
	private Map<String, String> getReferenceMap(Transaction transaction, boolean fillPaymetWay) {
		Map<String, String> refMap = new HashMap<String, String>();
		if (transaction == null) {
			return refMap;
		}
		if (fillPaymetWay) {
			// Validar el medio de pago para incluir informacion adicional
			if (transaction.getPaymentWay() != null) {
				if ((PaymentWayCodes.PAGOS_AVAL.equals(transaction.getPaymentWay().getId())
						|| PaymentWayCodes.PSE.equals(transaction.getPaymentWay().getId())) && transaction.getBank() != null) {
					refMap.put("BankId", transaction.getBank().getAvalCode());
					refMap.put("BankName", transaction.getBank().getName());
				}

				if ( PaymentWayCodes.TC.equals(transaction.getPaymentWay().getId()) 
						&& transaction.getIdBrand() != null) {

					Brand brand = brandDAO.read(Long.valueOf(transaction.getIdBrand().toString()));
					refMap.put("Brand", brand.getName());

					if ( transaction.isGlobalPay() != null && transaction.isGlobalPay() ) {
						refMap.put("CardEmbossNum", transaction.getCreditCardNumber());
					}

				}		

				TransactionStatus transactionStatus = transactionStatusDAO.findById(TransactionStatusEnum.REFUSED.getCode());
				if (PaymentWayCodes.PSE.equals(transaction.getPaymentWay().getId()) && transaction.getStatus()!=transactionStatus) {
					refMap.put("TrnCycle", transaction.getTrnCycle());
					refMap.put("AchBankCode", transaction.getBank().getAchCode());
				}
			}
		}

		if (transaction.getReference1() != null && !transaction.getReference1().trim().isEmpty()) {
			refMap.put("Reference1", transaction.getReference1());
		}
		if (transaction.getReference2() != null && !transaction.getReference2().trim().isEmpty()) {
			refMap.put("Reference2", transaction.getReference2());
		}
		if (transaction.getReference3() != null && !transaction.getReference3().trim().isEmpty()) {
			refMap.put("Reference3", transaction.getReference3());
		}

		// Ventanilla de Pagos
		if (transaction.getPlantilla() == CoreConstants.TAQUILLA_ON) {
			refMap.put("Template", CoreConstants.TAQUILLA_ON.toString());
			refMap.put("Theme", transaction.getTaquilla().getIdTaquilla().toString());
			refMap.put("LogoURL", new String(transaction.getUrlLogo()));
		} else if (transaction.getPlantilla() == CoreConstants.TAQUILLA_OFF) {
			refMap.put("Template", CoreConstants.TAQUILLA_OFF.toString());
		}

		return refMap;
	}
	
	private Date calcCompensationDate(Date current) {
		calendar.setTime(current);
		Date date = current;
		if ((!isBusinessDay(current)) || ((calendar.get(Calendar.HOUR_OF_DAY)>hourCompensation) ||
				((calendar.get(Calendar.HOUR_OF_DAY)==hourCompensation) && (calendar.get(Calendar.MINUTE)>minutesCompensation)))){
			//Verifica el proximo dia habil
			date = nextBusinessDay(current);
		}
		return date;
	}
	
	public boolean isBusinessDay(Date date) {
		calendar.setTime(date);
		int dayOfWeek = calendar.get(Calendar.DAY_OF_WEEK);
		
		//Valida que el día no sea sábado o Domingo
		if (dayOfWeek == 1 || dayOfWeek == 7) {
			return false;
		}
		
		List<NonWorkingDay> nonWorkingDays = nonWorkingDayDAO.findByDay(getIntDate(date));
		NonWorkingDay day = new NonWorkingDay();
		day.setId(getIntDate(date));
		if (nonWorkingDays.contains(day)) {
			return false;
		}
		return true;
	}
	
	/**
	 * Retorna la fecha de la fecha dada en tipo entero en el formato YYYYMMDD
	 * @param date Fecha deseada
	 * @return Fecha en tipo int
	 */
	protected int getIntDate(Date date){
		int intDate = calendar.get(Calendar.YEAR);
		intDate = intDate * 100 + calendar.get(Calendar.MONTH) + 1;
		intDate = intDate * 100 + calendar.get(Calendar.DAY_OF_MONTH);
		return intDate;
	}
	
	public Date nextBusinessDay(Date date) {
		Date nextDate = nextDay(date);
		if (isBusinessDay(nextDate)) {
			return nextDate;
		}
		return nextBusinessDay(nextDate);
	}
	
	public Date nextDay(Date date) {
		calendar.setTime(date);
		calendar.add(Calendar.DATE, 1);
		return calendar.getTime();
	}
	
	/**
	 * Combierte la fecha de zona horaria universal a zona horaria bogota
	 * @param fecha
	 * @return
	 */
	public Date fechaUTCaCOT(Date fecha) {
		
		Calendar calendar= Calendar.getInstance();
		calendar.setTime(fecha);
		calendar.add(Calendar.HOUR, -5);
		
		return calendar.getTime();
	}

}
