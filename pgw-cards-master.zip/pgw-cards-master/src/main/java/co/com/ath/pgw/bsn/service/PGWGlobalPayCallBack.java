package co.com.ath.pgw.bsn.service;

import co.com.ath.pgw.bsn.dto.in.GlobalPayInDTO;
import co.com.ath.pgw.rest.response.dto.GlobalPayCheckOutResponse;
import co.com.ath.pgw.util.exception.CustomException;

public interface PGWGlobalPayCallBack {
	
	public GlobalPayCheckOutResponse callBack(GlobalPayInDTO inDto) throws CustomException;

}
