package co.com.ath.pgw.srv;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import co.com.ath.pgw.bsn.controller.PaymentGlobalPayService;
import co.com.ath.pgw.bsn.controller.RbmDirectPaymentControlService;
import co.com.ath.pgw.bsn.controller.RbmPaymentControlService;
import co.com.ath.pgw.bsn.globalPay.dto.IniciarTransaccionDeCompraRsType;
import co.com.ath.pgw.bsn.service.IQrService;
import co.com.ath.pgw.bsn.service.PGWGlobalPayCallBack;
import co.com.ath.pgw.in.dto.CreditCardPaymentAddResponse;
import co.com.ath.pgw.in.dto.RBMPaymentAddRsType;
import co.com.ath.pgw.rest.dto.MsgRsHdr;
import co.com.ath.pgw.rest.request.dto.CreditTransactionGlobalPayRequest;
import co.com.ath.pgw.rest.request.dto.CreditTransactionRequest;
import co.com.ath.pgw.rest.request.dto.CreditTxvcPaymentRequest;
import co.com.ath.pgw.rest.request.dto.Header;
import co.com.ath.pgw.rest.response.dto.CreditTransactionGlobalPayResponse;
import co.com.ath.pgw.rest.response.dto.CreditTransactionResponse;
import co.com.ath.pgw.rest.response.dto.CreditTxvcPaymentResponse;
import co.com.ath.pgw.rest.response.dto.GenericErrorResponse;
import co.com.ath.pgw.srv.mapper.MapperAddCreditTransaction;
import co.com.ath.pgw.srv.mapper.MapperAddTxCreditPayment;
import co.com.ath.pgw.srv.mapper.MapperInitCreditTransaction;
import co.com.ath.pgw.util.constants.CoreConstants;
import co.com.ath.pgw.util.exception.CustomException;
import co.com.ath.pgw.util.qr.EstadoTransaccion;
import co.com.ath.pgw.util.qr.InformacionQR;
/**
 * Facade del Api cards con las operaciones disponibles para los pagos mediante RBM.
 * @author SophosSolutions
 * @version 1.0 17/06/2019
 */
@CrossOrigin("*")
@RestController
@RequestMapping(path = "/cardsManagement/v1")
public class CardsServiceFacade {

	static Logger LOGGER = LoggerFactory.getLogger(CardsServiceFacade.class);

	@Autowired
	private RbmPaymentControlService rbmPaymentCtrlService;

	@Autowired
	private PaymentGlobalPayService paymentGlobalPayService;
	
	@Autowired
	private RbmDirectPaymentControlService rbmDirectPaymentControlService;
	
//	@Autowired
//	private PGWGlobalPayService pgwGlobalPayService;
	
	@Autowired
	private PGWGlobalPayCallBack pgwGlobalPayCallBack;
	
	@Autowired
	private IQrService qrService;
	
	private HttpHeaders httpHeaders = new HttpHeaders();
	
	/**
	 * servicio post para Crear una transacción por medio de tarjeta de credito con globalPay.
	 * @param creditTransactionGlobalPayRequest
	 * @param header
	 * @return ResponseEntity
	 */	
	@PostMapping("/Card_Trn/Trn")
	public ResponseEntity<?> initCreditTransaction(
			@RequestHeader(name = "X-RqUID", required = true) Long rqUID,
    		@RequestHeader(name = "X-Channel", required = true) String channel,
    		@RequestHeader(name = "X-CompanyId", required = true) String companyId,
    		@RequestHeader(name = "X-IdentSerialNum", required = true) String identSerialNum,
    		@RequestHeader(name = "X-GovIssueIdentType", required = false) String govIssueIdentType,
    		@RequestHeader(name = "X-IPAddr", required = false) String iPAddr,
    		@RequestBody(required = true) CreditTransactionGlobalPayRequest creditTransactionGlobalPayRequest) throws CustomException {
		Header header = new Header(rqUID, channel, companyId, identSerialNum, govIssueIdentType, iPAddr);
		LOGGER.info("@initCreditTransaction input\n{}", header + "\n" + creditTransactionGlobalPayRequest);
		try {
			
			IniciarTransaccionDeCompraRsType iniciarTransaccionDeCompraRsType = paymentGlobalPayService.iniciarTransaccionDeCompra(
					MapperInitCreditTransaction.mapperRequestToCoreRequest(creditTransactionGlobalPayRequest, header));
			
			
			CreditTransactionGlobalPayResponse creditTransactionGlobalPayResponse = 
					MapperInitCreditTransaction.mapperResponseSuccessCore(iniciarTransaccionDeCompraRsType);
			
			LOGGER.info("@initCreditTransaction output\n{}", header + "\n" + creditTransactionGlobalPayResponse);
			
			HttpHeaders httpHeaders = new HttpHeaders();
			httpHeaders.add("X-RqUID", String.valueOf(rqUID));
			httpHeaders.add("X-ApprovalId", iniciarTransaccionDeCompraRsType.getIdTransaccion());
			
			return new ResponseEntity<>(creditTransactionGlobalPayResponse, httpHeaders, HttpStatus.CREATED);
			
		} catch(CustomException e) {
			GenericErrorResponse genericErrorResponse = MapperInitCreditTransaction.mapperResponseErrorCore(
					(IniciarTransaccionDeCompraRsType)e.getObjeto());
			
			LOGGER.info("@initCreditTransaction error output\n{}", header + "\n" + genericErrorResponse);
			
			HttpHeaders httpHeaders = new HttpHeaders();
			httpHeaders.add("X-RqUID", String.valueOf(rqUID));
			httpHeaders.add("X-ApprovalId", CoreConstants.DEFAULT_APPROVAL);
			
			return new ResponseEntity<>(genericErrorResponse, httpHeaders, HttpStatus.PARTIAL_CONTENT);
			
		}
	}
	
	/**
	 * servicio put para Crear una transacción por medio de tarjeta de credito.
	 * @param creditTransactionRequest
	 * @param header
	 * @return ResponseEntity
	 */		
	@PutMapping("/Card_Payments/Payments")
	public ResponseEntity<?> addCreditTransaction(
			@RequestHeader(name = "X-RqUID", required = true) Long rqUID,
    		@RequestHeader(name = "X-Channel", required = true) String channel,
    		@RequestHeader(name = "X-CompanyId", required = true) String companyId,
    		@RequestHeader(name = "X-IdentSerialNum", required = true) String identSerialNum,
    		@RequestHeader(name = "X-GovIssueIdentType", required = false) String govIssueIdentType,
    		@RequestHeader(name = "X-IPAddr", required = false) String iPAddr,
    		@RequestBody(required = true) CreditTransactionRequest creditTransactionRequest) throws CustomException {
		Header header = new Header(rqUID, channel, companyId, identSerialNum, govIssueIdentType, iPAddr);
		LOGGER.info("@addCreditTransaction input\n{}", header + "\n" + creditTransactionRequest);
		try {
			RBMPaymentAddRsType rbmPaymentAddRsType = rbmPaymentCtrlService.addRBMPayment(MapperAddCreditTransaction.mapperRequestToCoreRequest(creditTransactionRequest, header));
			if(rbmPaymentAddRsType.getStatusCode() != CoreConstants.SUCCESS_STATUS_CODE)
				throw new CustomException(String.valueOf(rbmPaymentAddRsType.getStatusCode()), rbmPaymentAddRsType);
			CreditTransactionResponse creditTransactionResponse = MapperAddCreditTransaction.mapperResponseSuccessCore(rbmPaymentAddRsType);
			LOGGER.info("@addCreditTransaction output\n{}", header + "\n" + creditTransactionResponse);
			HttpHeaders httpHeaders = new HttpHeaders();
			httpHeaders.add("X-RqUID", String.valueOf(rqUID));
			httpHeaders.add("X-ApprovalId", rbmPaymentAddRsType.getTransactionStatus().getApprovalId());
			return new ResponseEntity<>(creditTransactionResponse, httpHeaders, HttpStatus.CREATED);
		} catch(CustomException e) {
			GenericErrorResponse genericErrorResponse = MapperAddCreditTransaction.mapperResponseErrorCore((RBMPaymentAddRsType)e.getObjeto());
			LOGGER.info("@addCreditTransaction error output\n{}", header + "\n" + genericErrorResponse);
			HttpHeaders httpHeaders = new HttpHeaders();
			httpHeaders.add("X-RqUID", String.valueOf(rqUID));
			httpHeaders.add("X-ApprovalId", CoreConstants.DEFAULT_APPROVAL);
			return new ResponseEntity<>(genericErrorResponse, httpHeaders, HttpStatus.PARTIAL_CONTENT);
		}
	}
	
	/**
	 * servicio put para Crear una transacción por medio de tarjeta de credito desde K7.
	 * @param creditTransactionRequest
	 * @param header
	 * @return ResponseEntity
	 */		
	@PostMapping("/Card_Debit/Debit")
	public ResponseEntity<?> addTxCreditPayment(
			@RequestHeader(name = "X-RqUID", required = true) Long rqUID,
    		@RequestHeader(name = "X-Channel", required = true) String channel,
    		@RequestHeader(name = "X-CompanyId", required = true) String companyId,
    		@RequestHeader(name = "X-IdentSerialNum", required = true) String identSerialNum,
    		@RequestHeader(name = "X-GovIssueIdentType", required = true) String govIssueIdentType,
    		@RequestHeader(name = "X-IPAddr", required = false) String iPAddr,
    		@RequestBody(required = true) CreditTxvcPaymentRequest creditTxvcPaymentRequest) throws CustomException {
		Header header = new Header(rqUID, channel, companyId, identSerialNum, govIssueIdentType, iPAddr);
		LOGGER.info("@addTxCreditPayment input\n{}", header + "\n" + creditTxvcPaymentRequest);
		try {
			CreditCardPaymentAddResponse creditCardPaymentAddResponse = rbmDirectPaymentControlService.creditCardPaymentAdd(MapperAddTxCreditPayment.mapperRequestToCoreRequest(creditTxvcPaymentRequest, header));
			if(creditCardPaymentAddResponse.getCreditCardPaymentAddRs().getStatus().getStatusCode() != CoreConstants.SUCCESS_STATUS_CODE)
				throw new CustomException(String.valueOf(creditCardPaymentAddResponse.getCreditCardPaymentAddRs().getStatus().getStatusCode()), creditCardPaymentAddResponse);
			CreditTxvcPaymentResponse creditTxvcPaymentResponse = MapperAddTxCreditPayment.mapperResponseSuccessCore(creditCardPaymentAddResponse);
			HttpHeaders httpHeaders = new HttpHeaders();
			httpHeaders.add("X-RqUID", String.valueOf(rqUID));
			httpHeaders.add("X-ApprovalId", creditCardPaymentAddResponse.getCreditCardPaymentAddRs().getApprovalId());
			LOGGER.info("@addTxCreditPayment output\n{}", httpHeaders + "\n" + creditTxvcPaymentResponse);
			return new ResponseEntity<>(creditTxvcPaymentResponse, httpHeaders, HttpStatus.CREATED);
		} catch(CustomException e) {
			GenericErrorResponse genericErrorResponse = MapperAddTxCreditPayment.mapperResponseErrorCore((CreditCardPaymentAddResponse)e.getObjeto());
			LOGGER.info("@addTxCreditPayment error output\n{}", header + "\n" + genericErrorResponse);
			HttpHeaders httpHeaders = new HttpHeaders();
			httpHeaders.add("X-RqUID", String.valueOf(rqUID));
			httpHeaders.add("X-ApprovalId", CoreConstants.DEFAULT_APPROVAL);
			return new ResponseEntity<>(genericErrorResponse, httpHeaders, HttpStatus.PARTIAL_CONTENT);
		}
	}
	
//	/**
//	 * servicio post valida el estado de una transaccion en rbm.
//	 * @param creditTransactionRequest
//	 * @param header
//	 * @return ResponseEntity
//	 */	
//	@PostMapping("/Card_Trn/In_Trn")
//	public ResponseEntity<?> inGetCreditTransactionStatus(@RequestBody ConsultarEstadoDePagoInDTO consultarEstadoDePagoInDTO) throws CustomException {
//		LOGGER.info("@inGetCreditTransactionStatus input \n {}", consultarEstadoDePagoInDTO);
//		ConsultarEstadoDePagoOutDTO consultarEstadoDePagoOutDTO = pgwGlobalPayService.consultarEstadoDePago(consultarEstadoDePagoInDTO);
//		LOGGER.info("@inGetCreditTransactionStatus output\n {}", consultarEstadoDePagoOutDTO);
//		return new ResponseEntity<>(consultarEstadoDePagoOutDTO, HttpStatus.OK);
//	}
	
	/**
	 * @param rqUID
	 * @param channel
	 * @param companyId
	 * @param identSerialNum
	 * @param govIssueIdentType
	 * @param iPAddr
	 * @param idTx
	 * @return
	 * @throws CustomException
	 */
	@PostMapping("/initGenerationQR")
	public ResponseEntity<?> initGenerationQR(
			@RequestHeader(name = "X-RqUID", required = true) Long rqUID,
			@RequestHeader(name = "X-Channel", required = true) String channel,
			@RequestHeader(name = "X-CompanyId", required = true) String companyId,
			@RequestHeader(name = "X-IdentSerialNum", required = true) String identSerialNum,
			@RequestHeader(name = "X-GovIssueIdentType", required = false) String govIssueIdentType,
			@RequestHeader(name = "X-IPAddr", required = false) String iPAddr, 
			@RequestBody(required = true) CreditTransactionRequest creditTransactionGlobalPayRequest) 
			throws CustomException {
		Header header = new Header(rqUID, channel, companyId, identSerialNum, govIssueIdentType, iPAddr);
		LOGGER.info("@initGenerationQR input\n{}", header+ "\n" + creditTransactionGlobalPayRequest);

		InformacionQR informacionQR = new InformacionQR();
		try {
			informacionQR = qrService.generacionQR(MapperAddCreditTransaction.mapperRequestToCoreRequest(creditTransactionGlobalPayRequest, header));
			LOGGER.info("@initGenerationQR output\n{}", header + "\n" + informacionQR);
		
			httpHeaders.add("X-RqUID", String.valueOf(rqUID));
			return new ResponseEntity<>(informacionQR, httpHeaders, HttpStatus.OK);
		} catch(CustomException e) {
			GenericErrorResponse genericErrorResponse = new GenericErrorResponse();
			genericErrorResponse.setMsgRsHdr((MsgRsHdr)e.getObjeto());
			LOGGER.error("Error initGenerationQR {} \n {}", header, genericErrorResponse);
			httpHeaders.add("X-RqUID", String.valueOf(rqUID));
			httpHeaders.add("X-ApprovalId", CoreConstants.DEFAULT_APPROVAL);
			return new ResponseEntity<>(genericErrorResponse, httpHeaders, HttpStatus.PARTIAL_CONTENT);
		}
	}

	/**
	 * @param rqUID
	 * @param channel
	 * @param companyId
	 * @param identSerialNum
	 * @param govIssueIdentType
	 * @param iPAddr
	 * @param idTx
	 * @return
	 * @throws CustomException
	 */
	@GetMapping("/getStatusFinallyTX/{idTx}")
	public ResponseEntity<?> getEstadoQR(@RequestHeader(name = "X-RqUID", required = true) Long rqUID,
			@RequestHeader(name = "X-Channel", required = true) String channel,
			@RequestHeader(name = "X-CompanyId", required = true) String companyId,
			@RequestHeader(name = "X-IdentSerialNum", required = true) String identSerialNum,
			@RequestHeader(name = "X-GovIssueIdentType", required = false) String govIssueIdentType,
			@RequestHeader(name = "X-IPAddr", required = false) String iPAddr, @PathVariable(required = true) Long idTx) 
			throws CustomException {
		Header header = new Header(rqUID, channel, companyId, identSerialNum, govIssueIdentType, iPAddr);
		LOGGER.info("@getStatusFinallyTX input\n{}", header + "\n tansacción:" + idTx);
		EstadoTransaccion estadoTransaccion = new EstadoTransaccion();
        try {
			estadoTransaccion = qrService.getEstadoTransaccion(idTx);		
			LOGGER.info("@getStatusFinallyTX output\n{}", header + "\n" + estadoTransaccion);
	
			httpHeaders.add("X-RqUID", String.valueOf(rqUID));
			return new ResponseEntity<>(estadoTransaccion, httpHeaders, HttpStatus.OK);
			
        } catch (Exception e) {
			LOGGER.error("Error getStatusFinallyTX {} {}", idTx, header + "\n");
			httpHeaders.add("X-RqUID", String.valueOf(rqUID));
			httpHeaders.add("X-ApprovalId", CoreConstants.DEFAULT_APPROVAL);

			return new ResponseEntity<>(e.getCause(), httpHeaders, HttpStatus.PARTIAL_CONTENT);
		}		
	}

}
