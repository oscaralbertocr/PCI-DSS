package co.com.ath.pgw.bsn.service.impl;

import static org.quartz.JobBuilder.newJob;
import static org.quartz.SimpleScheduleBuilder.simpleSchedule;
import static org.quartz.TriggerBuilder.newTrigger;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.UUID;

import javax.annotation.Resource;

import org.quartz.JobDetail;
import org.quartz.Scheduler;
import org.quartz.SchedulerException;
import org.quartz.Trigger;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Service;
import org.springframework.web.client.HttpStatusCodeException;
import org.springframework.web.client.RestClientException;
import org.springframework.web.client.RestTemplate;

import com.google.gson.Gson;

import co.com.ath.pgw.bsn.dto.in.AddRBMPaymentInDTO;
import co.com.ath.pgw.bsn.service.IQrService;
import co.com.ath.pgw.config.QuartzConfig;
import co.com.ath.pgw.in.dto.RBMPaymentAddRqType;
import co.com.ath.pgw.persistence.dao.ITransaccionQRDAO;
import co.com.ath.pgw.persistence.dao.PaymentWayDAO;
import co.com.ath.pgw.persistence.dao.TransactionDAO;
import co.com.ath.pgw.persistence.dao.TransactionStatusDAO;
import co.com.ath.pgw.persistence.model.Transaction;
import co.com.ath.pgw.persistence.model.TransactionStatus;
import co.com.ath.pgw.rest.dto.AdditionalStatus;
import co.com.ath.pgw.rest.dto.MsgRsHdr;
import co.com.ath.pgw.rest.dto.Status;
import co.com.ath.pgw.util.Parametro;
import co.com.ath.pgw.util.constants.CoreConstants;
import co.com.ath.pgw.util.constants.PaymentWayCodes;
import co.com.ath.pgw.util.converter.PaymentsObjectsConverter;
import co.com.ath.pgw.util.enums.TransactionStatusEnum;
import co.com.ath.pgw.util.exception.CustomException;
import co.com.ath.pgw.util.qr.CodigoQR;
import co.com.ath.pgw.util.qr.ErrorQR;
import co.com.ath.pgw.util.qr.EstadoTransaccion;
import co.com.ath.pgw.util.qr.InformacionQR;
import co.com.ath.pgw.util.qr.ParametroDTO;
import co.com.ath.pgw.util.qr.SolicitudQR;

@Service
public class QrServiceImpl implements IQrService {
	private static final Logger LOGGER = LoggerFactory.getLogger(QrServiceImpl.class);
	private static final int REPETICION_CONFIRMACION_TXT = 1;

	private List<ParametroDTO> parametrosQR = new ArrayList<>();
	private Transaction transaccion;
	private Long idTx;

	@Autowired
	private QuartzConfig quartzConfig;

	@Autowired
	private ITransaccionQRDAO transaccionQR;
	
	@Resource
	public TransactionDAO transactionDAO;
	
	@Resource
	public PaymentWayDAO paymentWayDAO;
	
    @Resource
	public TransactionStatusDAO transactionStatusDAO;

	@Override
	public InformacionQR generacionQR(RBMPaymentAddRqType iniciarTransaccionDeCompraRqType) throws CustomException {

		AddRBMPaymentInDTO addRBMPaymentInDTO = PaymentsObjectsConverter.convertRBMPaymentAddRqTypeToAddRBMPaymentInDTO(iniciarTransaccionDeCompraRqType);
		
		LOGGER.info("Inicio Ejecucion");
		InformacionQR informacionQR = new InformacionQR();
		idTx = Long.parseLong(addRBMPaymentInDTO.getTransactionBO().getPmtId());
		
		// Buscar la transacción
		transaccion = transaccionQR.findById(idTx);	
		
		if (transaccion == null) {
			LOGGER.info("No se encuentra la transacción " + idTx + " el " + new Date());
			throw new CustomException("Error", message(CoreConstants.QR_ERROR_TX_NO_EXISTE_CODE,CoreConstants.QR_ERROR_TX_NO_EXISTE));
		}
		
		//Actualiza la informacion
		
		transaccion.setPaymentWay(paymentWayDAO.read(PaymentWayCodes.TC));
		if (addRBMPaymentInDTO.getTransactionBO().getTermsNConditions() != null
				&& !addRBMPaymentInDTO.getTransactionBO().getTermsNConditions().isEmpty()) {
			transaccion.setTermsAndConditions(
					Boolean.parseBoolean(addRBMPaymentInDTO.getTransactionBO().getTermsNConditions()));
		}

		transaccion.setGlobalPay(true);
		transaccion.setBankCollecter(transaccion.getCommerce().getSubscription().getBank());
		transaccion.setIpAddress(addRBMPaymentInDTO.getTransactionBO().getIpAddress());
		transaccion.setResponseCode(null);

		// Cambio Nombre Duplicado INI
		if (addRBMPaymentInDTO.getTransactionBO().getCustomerName() != null
				&& !addRBMPaymentInDTO.getTransactionBO().getCustomerName().isEmpty()
				&& !addRBMPaymentInDTO.getTransactionBO().getCustomerName().equals("GUEST")) {
			transaccion.setPayerName(addRBMPaymentInDTO.getTransactionBO().getFirstNamePayer());
			transaccion.setMiddleNamePayer("");
			transaccion.setLastNamePayer("");
			transaccion.setSecondLastNamePayer("");
		}
		// Cambio Nombre Duplicado FIN

		transaccion.setBankCollecter(transaccion.getCommerce().getSubscription().getBank());

		// información del comprador
		if (addRBMPaymentInDTO.getTransactionBO().getCustomerName() != null
				&& !addRBMPaymentInDTO.getTransactionBO().getCustomerName().isEmpty()) {
			transaccion.setCustomerName(addRBMPaymentInDTO.getTransactionBO().getCustomerName());
		}

		if (addRBMPaymentInDTO.getTransactionBO().getMiddleNameBuyer() != null
				&& !addRBMPaymentInDTO.getTransactionBO().getMiddleNameBuyer().isEmpty()) {
			transaccion.setMiddleNameBuyer(addRBMPaymentInDTO.getTransactionBO().getMiddleNameBuyer());
		}

		if (addRBMPaymentInDTO.getTransactionBO().getLastNameBuyer() != null
				&& !addRBMPaymentInDTO.getTransactionBO().getLastNameBuyer().isEmpty()) {
			transaccion.setLastNameBuyer(addRBMPaymentInDTO.getTransactionBO().getLastNameBuyer());
		}

		if (addRBMPaymentInDTO.getTransactionBO().getSecondLastNameBuyer() != null
				&& !addRBMPaymentInDTO.getTransactionBO().getSecondLastNameBuyer().isEmpty()) {
			transaccion.setSecondLastNameBuyer(addRBMPaymentInDTO.getTransactionBO().getSecondLastNameBuyer());
		}

		if (addRBMPaymentInDTO.getTransactionBO().getCustomerEmail() != null
				&& !addRBMPaymentInDTO.getTransactionBO().getCustomerEmail().isEmpty()) {
			transaccion.setCustomerEmail(addRBMPaymentInDTO.getTransactionBO().getCustomerEmail());
		}

		if (addRBMPaymentInDTO.getTransactionBO().getCustomerMobileNumber() != null
				&& !addRBMPaymentInDTO.getTransactionBO().getCustomerMobileNumber().isEmpty()) {
			transaccion
					.setCustomerMobileNumber(addRBMPaymentInDTO.getTransactionBO().getCustomerMobileNumber());
		}

		// información del pagador
		if (addRBMPaymentInDTO.getTransactionBO().getPayerCompany() != null
				&& !addRBMPaymentInDTO.getTransactionBO().getPayerCompany().isEmpty()) {
			transaccion.setPayerCompany(addRBMPaymentInDTO.getTransactionBO().getPayerCompany());
		}

		if (addRBMPaymentInDTO.getTransactionBO().getFirstNamePayer() != null
				&& !addRBMPaymentInDTO.getTransactionBO().getFirstNamePayer().isEmpty()) {
			transaccion.setPayerName(addRBMPaymentInDTO.getTransactionBO().getFirstNamePayer());
		}

		if (addRBMPaymentInDTO.getTransactionBO().getMiddleNamePayer() != null
				&& !addRBMPaymentInDTO.getTransactionBO().getMiddleNamePayer().isEmpty()) {
			transaccion.setMiddleNamePayer(addRBMPaymentInDTO.getTransactionBO().getMiddleNamePayer());
		}

		if (addRBMPaymentInDTO.getTransactionBO().getLastNamePayer() != null
				&& !addRBMPaymentInDTO.getTransactionBO().getLastNamePayer().isEmpty()) {
			transaccion.setLastNamePayer(addRBMPaymentInDTO.getTransactionBO().getLastNamePayer());
		}

		if (addRBMPaymentInDTO.getTransactionBO().getSecondLastNamePayer() != null
				&& !addRBMPaymentInDTO.getTransactionBO().getSecondLastNamePayer().isEmpty()) {
			transaccion.setSecondLastNamePayer(addRBMPaymentInDTO.getTransactionBO().getSecondLastNamePayer());
		}

		if (addRBMPaymentInDTO.getTransactionBO().getPayerNickName() != null
				&& !addRBMPaymentInDTO.getTransactionBO().getPayerNickName().isEmpty()) {
			transaccion.setPayerNickName(addRBMPaymentInDTO.getTransactionBO().getPayerNickName());
		}

		if (addRBMPaymentInDTO.getTransactionBO().getPayerDocType() != null
				&& !addRBMPaymentInDTO.getTransactionBO().getPayerDocType().isEmpty()) {
			transaccion.setPayerDocType(addRBMPaymentInDTO.getTransactionBO().getPayerDocType());
		}

		if (addRBMPaymentInDTO.getTransactionBO().getPayerDocId() != null
				&& !addRBMPaymentInDTO.getTransactionBO().getPayerDocId().isEmpty()) {
			transaccion.setPayerDocId(addRBMPaymentInDTO.getTransactionBO().getPayerDocId());
		}

		if (addRBMPaymentInDTO.getTransactionBO().getPayerGender() != null
				&& !addRBMPaymentInDTO.getTransactionBO().getPayerGender().isEmpty()) {
			transaccion.setPayerGender(addRBMPaymentInDTO.getTransactionBO().getPayerGender());
		}

		if (addRBMPaymentInDTO.getTransactionBO().getPayerBirthDate() != null
				&& addRBMPaymentInDTO.getTransactionBO().getPayerBirthDate().toString() != "") {
			transaccion.setPayerBirthDate(addRBMPaymentInDTO.getTransactionBO().getPayerBirthDate());
		}

		if (addRBMPaymentInDTO.getTransactionBO().getPayerCity() != null
				&& !addRBMPaymentInDTO.getTransactionBO().getPayerCity().isEmpty()) {
			transaccion.setPayerCity(addRBMPaymentInDTO.getTransactionBO().getPayerCity());
		}

		if (addRBMPaymentInDTO.getTransactionBO().getPayerDepartment() != null
				&& !addRBMPaymentInDTO.getTransactionBO().getPayerDepartment().isEmpty()) {
			transaccion.setPayerDepartment(addRBMPaymentInDTO.getTransactionBO().getPayerDepartment());
		}

		if (addRBMPaymentInDTO.getTransactionBO().getPayerCountry() != null
				&& !addRBMPaymentInDTO.getTransactionBO().getPayerCountry().isEmpty()) {
			transaccion.setPayerCounty(addRBMPaymentInDTO.getTransactionBO().getPayerCountry());
		}

		if (addRBMPaymentInDTO.getTransactionBO().getPayerAddress() != null
				&& !addRBMPaymentInDTO.getTransactionBO().getPayerAddress().isEmpty()) {
			transaccion.setPayerAddress(addRBMPaymentInDTO.getTransactionBO().getPayerAddress());
		}

		if (addRBMPaymentInDTO.getTransactionBO().getPayerMail() != null
				&& !addRBMPaymentInDTO.getTransactionBO().getPayerMail().isEmpty()) {
			transaccion.setPayerMail(addRBMPaymentInDTO.getTransactionBO().getPayerMail());
		}

		if (addRBMPaymentInDTO.getTransactionBO().getPayerPhone() != null
				&& !addRBMPaymentInDTO.getTransactionBO().getPayerPhone().isEmpty()) {
			transaccion.setPayerPhone(addRBMPaymentInDTO.getTransactionBO().getPayerPhone());
		}

		if (addRBMPaymentInDTO.getTransactionBO().getCustomerName() != null
				&& !addRBMPaymentInDTO.getTransactionBO().getCustomerName().isEmpty()) {
			transaccion.setCustomerName(addRBMPaymentInDTO.getTransactionBO().getCustomerName());
		}

		if (addRBMPaymentInDTO.getTransactionBO().getCustomerEmail() != null
				&& !addRBMPaymentInDTO.getTransactionBO().getCustomerEmail().isEmpty()) {
			transaccion.setCustomerEmail(addRBMPaymentInDTO.getTransactionBO().getCustomerEmail());
		}

		if (addRBMPaymentInDTO.getTransactionBO().getCustomerMobileNumber() != null
				&& !addRBMPaymentInDTO.getTransactionBO().getCustomerMobileNumber().isEmpty()) {
			transaccion
					.setCustomerMobileNumber(addRBMPaymentInDTO.getTransactionBO().getCustomerMobileNumber());
		}

		// Se recorta a los primeros 6 digitos
		addRBMPaymentInDTO.setRqUID(convertRqId(addRBMPaymentInDTO.getRqUID()));

		// Se almacena el rquId
		transaccion.setRquId(addRBMPaymentInDTO.getRqUID().toString());

		transaccion.setCustomerDocType(addRBMPaymentInDTO.getTransactionBO().getCustomerDocType());
		transaccion.setCustomerDocId(addRBMPaymentInDTO.getTransactionBO().getCustomerDocId());
		
		////
		
		transactionDAO.update(transaccion);

		// informacion de QR

		if (!cargarListaParametrosQR()) {
			LOGGER.info("Fallo la carga de parámetros para solicitar el QR de la" + idTx + "a las " + new Date());
			transaccionQR.estadoFallido(idTx);
			throw new CustomException("Error", message(CoreConstants.QR_ERROR_CARGA_PARAMETROS_CODE,CoreConstants.QR_ERROR_CARGA_PARAMETROS));
		}
		LOGGER.info("carga de parametros");
		informacionQR.setIdTransaccion(idTx);

		LOGGER.info("se inicia marcacion de QR en la transaccion");
		// Marca la transacción como QR => Quien marca como TC al nuevo campo
		try {
			transaccionQR.identTransaccionQR(idTx);
		} catch (Exception e) {
			LOGGER.info("Error marcando la transacción " + idTx + " como QR, el " + new Date());
			transaccionQR.estadoFallido(idTx);
			throw new CustomException("Error", message(CoreConstants.QR_ERROR_MARCA_TX_CODE,CoreConstants.QR_ERROR_MARCA_TX));	
		}
		LOGGER.info("Fin marcacion de QR en la transaccion");

		/* Se cargan los parametros */

		informacionQR.setLstParametro(traerParametros("QRTimer", "QRMensaje", "QRInicio", "QRDelay"));
		if (informacionQR.getLstParametro() == null || informacionQR.getLstParametro().isEmpty()) {
			LOGGER.info("No estan disponibles los parámetros de la transacción " + idTx + "a las " + new Date());
			transaccionQR.estadoFallido(idTx);
			throw new CustomException("Error", message(CoreConstants.QR_ERROR_CARGA_PARAMETROS_CODE, CoreConstants.QR_ERROR_CARGA_PARAMETROS));
		}
		LOGGER.info("Se obtiene la consulta de parámetros " + idTx + "a las " + new Date());

		// hace la solicitud a RBM del codigo RQ
		informacionQR.setCodigoQR(solicitudQR());

		try {
			activarConsultaDetallada();
		} catch (SchedulerException e) {
			LOGGER.error("Error llamando la consulta detallada. {}", e);
			transaccionQR.estadoFallido(idTx);
			throw new CustomException("Error", message(CoreConstants.QR_ERROR_CONSULTA_DETALLADA_CODE,CoreConstants.QR_ERROR_CONSULTA_DETALLADA));
		}
		informacionQR.setFechaRespuesta(new Date());

		return informacionQR;
	}

	@Override
	public EstadoTransaccion getEstadoTransaccion(long idTransaccion) {
		EstadoTransaccion estadoTransaccion = new EstadoTransaccion();

		transaccion = transaccionQR.findById(idTransaccion);
		if (transaccion != null) {
			estadoTransaccion.setIdTx(idTransaccion);
			estadoTransaccion.setIdEstado(transaccion.getStatus().getCode());
			estadoTransaccion.setDescripcion(transaccion.getStatus().getDescription().name());
			estadoTransaccion.setPmtId(transaccion.getPmtId());
			return estadoTransaccion;
		}
		return null;
	}

	/**
	 * @param param
	 * @return
	 */
	private List<ParametroDTO> traerParametros(String... parametros) {

		return Parametro.getParametros(parametros);
	}

	/**
	 * Metodo que realiza el llamada para que se ejecute
	 * 
	 * @throws SchedulerException
	 */
	private void activarConsultaDetallada() throws SchedulerException {
		try {
			// Creacion de una instacia de Scheduler
			Scheduler scheduler = quartzConfig.schedulerFactoryBean().getScheduler();
			int repeticiones = Integer.valueOf(getParametroQR("QRRepeticiones"))
					+ REPETICION_CONFIRMACION_TXT;
			
			LOGGER.info("Se lanza la consulta detallada para la transacción {} a las{} ", idTx, new Date());

			scheduler.start();

			// Creacion una instacia de JobDetail
			JobDetail jobDetail = newJob(PGWGlobalPayQRImpl.class).usingJobData("pmtId", idTx)
					.usingJobData("repeticion", Integer.valueOf(getParametroQR("QRRepeticiones")))
					.usingJobData("QRUriConsultaDetallada", getParametroQR("QRUriConsultaDetallada"))
					.usingJobData("QRUriActualizarEstado", getParametroQR("QRUriActualizarEstado"))
					.usingJobData("contador", 0).withIdentity(String.valueOf(idTx), Scheduler.DEFAULT_GROUP).build();

			// Creacion de un Trigger donde indicamos que el Job se ejecutara
			Trigger trigger = newTrigger().withIdentity("T" + String.valueOf(idTx), Scheduler.DEFAULT_GROUP)
					.startAt(fechaLimite(Integer.valueOf(getParametroQR("QRInicio"))))
					.withSchedule(simpleSchedule().withRepeatCount(repeticiones)
							.withIntervalInMilliseconds(Integer.valueOf(getParametroQR("QRDelay"))))
					.build();

			// Registro dentro del Scheduler
			scheduler.scheduleJob(jobDetail, trigger);

			LOGGER.info("Termina la consulta detallada para la transacción {} a las {} ", idTx, new Date());
		} catch (Exception e) {
			transaccionQR.estadoFallido(idTx);
			LOGGER.info("Se presentan fallas al lanzar la consulta detallada RBM de la TX  {} a las {} {}", idTx,
					new Date(), e);
			throw new SchedulerException(e);
		}
	}

	/**
	 * @param milisegundos
	 * @return
	 */
	private Date fechaLimite(int milisegundos) {
		Calendar calendar = Calendar.getInstance();
		calendar.add(Calendar.MILLISECOND, milisegundos);
		return calendar.getTime();
	}

	/**
	 * @return
	 * @throws CustomException
	 */
	private CodigoQR solicitudQR() throws CustomException {
		LOGGER.info("Se inicia la solicitud del QR a RBM de la TX {} a las {} ", idTx, new Date());

		RestTemplate plantilla = new RestTemplate();

		SolicitudQR solicitudQR = new SolicitudQR();
		solicitudQR.setCodigoUnico(transaccion.getCommerce().getIncocreditoCode());
		solicitudQR.setCanal(getParametroQR("QRGenerarCanal"));
		solicitudQR.setTerminalId(transaccion.getCommerce().getTerminalCode());
		String idTransaccion =String.valueOf(idTx);
		solicitudQR.setIdTransaccion(idTransaccion.substring(idTransaccion.length()-6,idTransaccion.length()));
		solicitudQR.setValorCompra(transaccion.getTotalValue().toString());
		solicitudQR.setTipoOperacion(getParametroQR("QRTipoOperacion"));
		solicitudQR.setTipoQR(getParametroQR("QRTipoCodigo"));
		solicitudQR.setCondicionIva(getParametroQR("QRCondicionIva"));
		solicitudQR.setIva(Integer.valueOf(getParametroQR("QRIva")));
		solicitudQR.setBaseIva(Integer.valueOf(getParametroQR("QRBaseIva")));
		solicitudQR.setCondicionInc(getParametroQR("QRCondicionInc"));
		solicitudQR.setInc(Integer.valueOf(getParametroQR("QRInc")));
		solicitudQR.setCondicionPropina(getParametroQR("QRCondicionPropina"));
		solicitudQR.setBaseIva(Integer.valueOf(getParametroQR("QRPropina")));

		HttpHeaders headers = new HttpHeaders();
		headers.setContentType(MediaType.APPLICATION_JSON);
		headers.set(CoreConstants.HEADER_CHANNEL, CoreConstants.HEADER_VALUE_CHANNEL);
		headers.set(CoreConstants.HEADER_COMPANY, CoreConstants.HEADER_VALUE_COMPANY);
		headers.set(CoreConstants.HEADER_RQUID, String.valueOf(UUID.randomUUID()));
		headers.set(CoreConstants.HEADER_SERVICE_NAME, CoreConstants.HEADER_VALUE_SERVICE_NAME_GENERACION);
		
		LOGGER.info("Solicitud QR input\n{}", headers + "\n" + solicitudQR);
		
		HttpEntity<SolicitudQR> request = new HttpEntity<SolicitudQR>(solicitudQR, headers);
		
		String json = "";
		try {
			json = plantilla.postForObject(getParametroQR("QRUriGenerarCodigo"), request,String.class);
		}catch (HttpStatusCodeException  ec) {
			
			LOGGER.error("Error RestClientException {}, {}",  ec.getRawStatusCode(), ec.getResponseBodyAsString() );
			
			TransactionStatus transactionStatus = transactionStatusDAO.findById(TransactionStatusEnum.FAILED.getCode());
        	transaccion.setStatus(transactionStatus);
			
			transactionDAO.update(transaccion);
			
			throw new CustomException("Error", message(String.valueOf(ec.getRawStatusCode()),CoreConstants.GENERAR_QR_ERROR_PETICION));			
			
		} catch (Exception e) {
			LOGGER.error("Error general solicitudQR {}", e);
			
			TransactionStatus transactionStatus = transactionStatusDAO.findById(TransactionStatusEnum.FAILED.getCode());
        	transaccion.setStatus(transactionStatus);
			
			transactionDAO.update(transaccion);
			
			throw new CustomException("Error", message(e.getMessage(),CoreConstants.GENERAR_QR_ERROR_GENERAL));	
		}
		
		
		LOGGER.info("Respuesta generacion QR: \n{}", json);
		
		CodigoQR codigoQR = new Gson().fromJson(json, CodigoQR.class);
		if (codigoQR.getCodigoQR() == null) {
						
			ErrorQR errorQR = new Gson().fromJson(json, ErrorQR.class);
			
			if(errorQR.getCodigoError() == null) {
				LOGGER.info("No fue posible leer el error QR desde RBM para la TX " + idTx + "a las " + new Date());
				throw new CustomException("Error", new Gson().fromJson(json, MsgRsHdr.class));	
			} else {			
				if (errorQR.getCodigoError().equals(CoreConstants.GENERAR_QR_ERROR_INVOCACION) || errorQR.getCodigoError().equals(CoreConstants.GENERAR_QR_ERROR_CONEXION) ||
					errorQR.getCodigoError().equals(CoreConstants.GENERAR_QR_ERROR_INTERNO) || errorQR.getCodigoError().equals(CoreConstants.GENERAR_QR_ERROR_TIMEOUT))
					 {
						LOGGER.info("No fue posible leer el QR desde RBM para la TX " + idTx + "a las " + new Date());
		
						TransactionStatus transactionStatus = transactionStatusDAO.findById(TransactionStatusEnum.FAILED.getCode());
			        	transaccion.setStatus(transactionStatus);
						
						transactionDAO.update(transaccion);
						throw new CustomException("Error", message(errorQR.getCodigoError(),errorQR.getDescripcionError()));
				}else if(errorQR.getCodigoError().equals(CoreConstants.GENERAR_QR_ERROR_ESTRUCTURA) || errorQR.getCodigoError().equals(CoreConstants.GENERAR_QR_ERROR_INTERNO_PROVEEDOR)) {
					throw new CustomException("Error", message(errorQR.getCodigoError(),errorQR.getDescripcionError()));
				}
			}
		}
		return codigoQR;
	}

	/**
	 * @return
	 */
	private boolean cargarListaParametrosQR() {

		parametrosQR = traerParametros("QRTimer", "QRInicio", "QRDelay", "QRUriGenerarCodigo", "QRTipoOperacion",
				"QRTipoCodigo", "QRCondicionIva", "QRIva", "QRBaseIva", "QRCondicionInc", "QRInc", "QRCondicionPropina",
				"QRPropina", "QRRepeticiones", "QRUriConsultaDetallada", "QRUriActualizarEstado","QRGenerarCanal");
		return (parametrosQR != null && !parametrosQR.isEmpty());
	}

	/**
	 * @param nombre
	 * @return
	 */
	private String getParametroQR(String nombre) {
		for (ParametroDTO p : parametrosQR) {
			if (p.getNombre().equals(nombre)) {
				return p.getValor();
			}
		}
		return null;
	}
	
	/**
	 * @param rqUID
	 * @param channel
	 * @param companyId
	 * @param serverName
	 * @return
	 */
	private MsgRsHdr message(String code, String message ) {

		MsgRsHdr msgRsHdr = new MsgRsHdr();

		AdditionalStatus adicionalStatus = new AdditionalStatus();
		adicionalStatus.setStatusCode(code);
		adicionalStatus.setStatusDesc(message);
		adicionalStatus.setSeverity("null");

		Status status = new Status();
		status.setStatusCode(code);
		status.setStatusDesc(message);
		status.setSeverity("null");
		status.setEndDt(new Date());
		status.setAdditionalStatus(adicionalStatus);
		
		msgRsHdr.setStatus(status);
		msgRsHdr.getStatus().setAdditionalStatus(adicionalStatus);
		
		return msgRsHdr;
	}
	
	/**
	 * reduce la dimension del rqId
	 * 
	 * @param Long
	 * @return Long
	 */
	private Long convertRqId(Long rqId) {
		StringBuilder num = new StringBuilder(rqId.toString());
		if (num.length() < 7) {
			return rqId;
		}
		return Long.valueOf(num.substring(0, 6));
	}
}
