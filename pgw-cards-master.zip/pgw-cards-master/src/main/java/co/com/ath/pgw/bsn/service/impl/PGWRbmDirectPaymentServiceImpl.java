package co.com.ath.pgw.bsn.service.impl;

import javax.annotation.Resource;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpMethod;
import org.springframework.stereotype.Service;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;

import co.com.ath.pgw.bsn.controller.impl.RbmPaymentControlServiceImpl;
import co.com.ath.pgw.bsn.service.PGWRbmDirectPaymentService;
import co.com.ath.pgw.in.dto.CreditCardPaymentAddRequest;
import co.com.ath.pgw.in.dto.CreditCardPaymentAddResponse;
import co.com.ath.pgw.in.dto.RBMPaymentAddRqType;
import co.com.ath.pgw.in.dto.RBMPaymentAddRsType;
import co.com.ath.pgw.in.dto.TransactionAddRqType;
import co.com.ath.pgw.in.dto.TransactionAddRsType;
import co.com.ath.pgw.in.model.ReferenceType;
import co.com.ath.pgw.in.model.SecretListType;
import co.com.ath.pgw.persistence.dao.CommerceDAO;
import co.com.ath.pgw.persistence.model.Commerce;
import co.com.ath.pgw.srv.mapper.MapperAddTxCreditPayment;
import co.com.ath.pgw.util.constants.CoreConstants;
import co.com.ath.pgw.util.converter.TransactionObjectConverter;
import co.com.ath.pgw.util.exception.CustomException;
import co.com.ath.pgw.util.rest.AbstractRestClient;
/**
* Implementación por defecto del Servicio de pagos por RBM desde k7 
* 
* @author sophosSolutions
* @version 1.0 22/07/2019
**/
@Service
public class PGWRbmDirectPaymentServiceImpl implements PGWRbmDirectPaymentService{
	
	private static Logger LOGGER = LoggerFactory.getLogger(PGWRbmDirectPaymentServiceImpl.class);
	
	@Autowired
	private CommerceDAO commerceDAO;
	
	@Resource
	private RbmPaymentControlServiceImpl rbmPaymentCtrlServiceImpl;
	
	@Autowired
	private TransactionObjectConverter transactionObjectConverter;
	
	@Value("${core.services.in.host}")
	private String restHost;
	
	@Value("${core.services.in.post.payments_trn.in_trn}")
	private String restPostPaymentsTrnInTrn;
	
	@Resource
	private AbstractRestClient abstractRestClient;
	
	public CreditCardPaymentAddResponse creditCardPaymentAdd(CreditCardPaymentAddRequest creditCardPaymentAddRequest) throws CustomException {
    	CreditCardPaymentAddResponse creditCardPaymentAddResponse = new CreditCardPaymentAddResponse();
    	TransactionAddRqType transactionAddRqType = null;
    	TransactionAddRsType transactionAddRsType = null;
    	RBMPaymentAddRsType rbmPaymentAddRsType = null;
    	Commerce commerce = null;

    	try {
    		transactionAddRqType = transactionObjectConverter.convertToTransactionAddRq(creditCardPaymentAddRequest);
        	commerce = commerceDAO.findByNura(creditCardPaymentAddRequest.getCreditCardPaymentAddRq().getAgreementInfo().getAgreementId());
        	
        	if(commerce != null) {
	        	SecretListType secretListType = new SecretListType();
	        	secretListType.setSecretId(SecretListType.USER_KEY);
	        	secretListType.setSecret(commerce.getConfiguration().getUser());
	        	SecretListType SecretListType2 = new SecretListType();
	        	SecretListType2.setSecretId(SecretListType.WORD_KEY);
	        	SecretListType2.setSecret(commerce.getConfiguration().getPhrase());
	        	transactionAddRqType.getSecretList().add(secretListType);
	        	transactionAddRqType.getSecretList().add(SecretListType2);
	        	transactionAddRqType.setPortalURL(commerce.getConfiguration().getResponseURL());
        	}
        	
        	/**
        	 * INICIO C01        	
        	 */
        	ReferenceType ReferenceType = new ReferenceType();//REFPMTID
        	
        	ReferenceType.setRefId(CoreConstants.PMTID_K7);
        	ReferenceType.setRefType(creditCardPaymentAddRequest.getCreditCardPaymentAddRq().getPmtId());
        	
        	transactionAddRqType.getReference().add(ReferenceType);
        	/**
        	 * FIN C01        	
        	 */
        	
        	//LOGGER.info("@addTransaction input \n {}", addTxRq);
        	
        	//FIXME CONSUMO DEL SERVICIO REST CREACION DE TRANSACCION
    		String uri = restHost+restPostPaymentsTrnInTrn;
            String restClient = abstractRestClient.consumeRest(uri, transactionAddRqType, HttpMethod.POST, null);
            TypeReference<TransactionAddRsType> typeReference = new TypeReference<TransactionAddRsType>() {};
            ObjectMapper objectMapper = new ObjectMapper();
            try {
            	transactionAddRsType = objectMapper.readValue(restClient, typeReference);
            } catch (Exception e) {
            	//e.printStackTrace();
            	LOGGER.error("Error al convertir objeto \n{}", e.getMessage());
            	throw new CustomException(e.getMessage(), MapperAddTxCreditPayment.setCustomError(e));
            }
        	
            //LOGGER.info("@addTransaction output \n {}", addTxRs);
    	} catch(Exception e) {
    		LOGGER.error("Creando la transaccion {} Excepcion: {} ", creditCardPaymentAddRequest.getCreditCardPaymentAddRq().getRqUID(), e.getMessage());
    		LOGGER.error("Creando la transaccion {} Causa: {}", creditCardPaymentAddRequest.getCreditCardPaymentAddRq().getRqUID(), e.getCause());
    		throw new CustomException(e.getMessage(), MapperAddTxCreditPayment.setCustomError(e));
    	}
    	
    	if(transactionAddRsType != null && transactionAddRsType.getStatusCode() == CoreConstants.SUCCESS_STATUS_CODE) {
    		try {
    			RBMPaymentAddRqType rbmPaymentAddRqType = transactionObjectConverter.convertToRBMPaymentAddRq(creditCardPaymentAddRequest);
            	
    			rbmPaymentAddRqType.setPmtId(transactionAddRsType.getPmtId());
            	ReferenceType refIncoCredito = new ReferenceType();
            	ReferenceType refTerminal = new ReferenceType();
            	refIncoCredito.setRefId(CoreConstants.REFERENCE_INCOCREDITO);
            	refIncoCredito.setRefType(commerce.getIncocreditoCode());
            	refTerminal.setRefId(CoreConstants.REFERENCE_TERMINAL);    	
            	refTerminal.setRefType(commerce.getTerminalCode());
            	rbmPaymentAddRqType.getReference().add(refIncoCredito);
            	rbmPaymentAddRqType.getReference().add(refTerminal);
            	
            	//LOGGER.info("@addRBMTransaction input \n {}", addRBMRq);
            	rbmPaymentAddRsType = rbmPaymentCtrlServiceImpl.addRBMPayment(rbmPaymentAddRqType);
            	//LOGGER.info("@addRBMTransaction output \n {}", addRBMRs);
            	
        	} catch(Exception e) {
        		LOGGER.error("Consumo de servicio de RBM Excepcion: {}", e.getMessage());
        		LOGGER.error("Consumo de servicio de RBM Causa: {}", e.getCause());
        		throw new CustomException(e.getMessage(), MapperAddTxCreditPayment.setCustomError(e));
        	}
    		
    		try {
    			creditCardPaymentAddResponse = transactionObjectConverter.convertToRBMPaymentRs(transactionAddRsType, rbmPaymentAddRsType);
        		//LOGGER.info("@addCreditCardPayment output \n {}", addTCPaymentRs);
        	} catch(Exception e) {
        		LOGGER.error("Error al convertir el Objeto de Respuesta Excepcion: {}", e.getMessage());
        		LOGGER.error("Error al convertir el Objeto de Respuesta Causa: {}", e.getCause());
        		throw new CustomException(e.getMessage(), MapperAddTxCreditPayment.setCustomError(e));
        	}
    		
    	} else {
    		creditCardPaymentAddResponse = transactionObjectConverter.convertToRBMPaymentRs(transactionAddRsType);
    	}
		return creditCardPaymentAddResponse;
    }
	
}
