package co.com.ath.pgw.srv.mapper;

import java.math.BigDecimal;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import co.com.ath.pgw.bsn.dto.in.GlobalPayInDTO;
import co.com.ath.pgw.rest.request.dto.GlobalPayCheckOutRequest;
import co.com.ath.pgw.util.converter.DateUtil;
import co.com.ath.pgw.util.exception.CustomException;

/**
 * Servicio de Mapeo de objetos para pagos con tarjeta de credito GlobalPay (checkout)
 * @author SophosSolutions
 * @version 1.0
 * @since 1.0
 */
public class MapperGlobalPayCallBack {
	
	private static Logger LOGGER = LoggerFactory.getLogger(MapperGlobalPayCallBack.class);
	
	final String FORMATO_FECHA = "dd/MM/yyyy HH:mm:ss" ;
	
	public GlobalPayInDTO mapRequestToInDTO (GlobalPayCheckOutRequest request) throws CustomException {
		
		GlobalPayInDTO dto = new GlobalPayInDTO();

		try {
			
			dto.setIdEstado(new Long(request.getTransaction().getStatus()));
			dto.setDescripcion(request.getTransaction().getOrderDescription());
			dto.setCodigoAutorizacion(request.getTransaction().getAuthorizationCode());
			dto.setDetalleEstado(new Long(request.getTransaction().getStatusDetail()));
			dto.setMensaje(request.getTransaction().getMessage());
			dto.setIdTransaccion(request.getTransaction().getId());
			dto.setPmtid(new Long(request.getTransaction().getDevReference()));
			dto.setCodigoDelProcesador(request.getTransaction().getCarrieCode());
			dto.setMonto(new BigDecimal(request.getTransaction().getAmount()));
			dto.setCuotas(new Long(request.getTransaction().getInstallments()));
			dto.setsToken(request.getTransaction().getStoken());
			dto.setCodigoAplicacion(request.getTransaction().getApplicationCode());
			
			dto.setFechaTransaccion(DateUtil.parseString(request.getTransaction().getDate(), FORMATO_FECHA));
			dto.setFechaPago(DateUtil.parseString(request.getTransaction().getDate(), FORMATO_FECHA));
			
			dto.setIdUsuario(request.getUser().getId());
			dto.setCorreoUsuario(request.getUser().getEmail());
			
			dto.setBin(request.getCard().getBin());
			dto.setNombreTitular(request.getCard().getHolderName());
			dto.setTipoTarjeta(request.getCard().getType());
			dto.setNumeroTarjeta(request.getCard().getNumber());
			dto.setOrigen(request.getCard().getOrigin());
			
			
		} catch (Exception e) {
			LOGGER.error("Error mapeando informacion de entrada del @globalPayCallBack", e.getMessage());
			throw new CustomException(e.getMessage());
		}
		
		return dto;
	}

		
}
