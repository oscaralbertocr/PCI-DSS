package co.com.ath.pgw.bsn.service;

import co.com.ath.pgw.in.dto.CreditCardPaymentAddRequest;
import co.com.ath.pgw.in.dto.CreditCardPaymentAddResponse;
import co.com.ath.pgw.util.exception.CustomException;
/**
* Servicio para pagos con RBM desde k7
* 
* @author sophossolutions
* @version 1.0 22/07/2019
* 
*/
public interface PGWRbmDirectPaymentService {
	/**
	 * Permite crear una transaccion de compra con rbm desde k7
	 * @param creditCardPaymentAddRequest
	 * @return CreditCardPaymentAddResponse
	 * @throws CustomException
	 */
    public CreditCardPaymentAddResponse creditCardPaymentAdd(CreditCardPaymentAddRequest creditCardPaymentAddRequest) throws CustomException ;
	
}
