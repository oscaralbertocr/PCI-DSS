package co.com.ath.pgw.config;

import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;

/**
 * persistencia para el api cards.
 * @author SophosSolutions
 * @version 1.0 17/06/2019
 */
@Configuration
@ComponentScan(basePackages = "co.com.ath.pgw.persistence.dao")
public class PersistenceConfig {


}
