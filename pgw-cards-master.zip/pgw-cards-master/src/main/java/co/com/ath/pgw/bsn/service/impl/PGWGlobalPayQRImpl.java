package co.com.ath.pgw.bsn.service.impl;

import java.math.BigDecimal;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

import javax.annotation.Resource;

import org.quartz.DisallowConcurrentExecution;
import org.quartz.Job;
import org.quartz.JobDataMap;
import org.quartz.JobExecutionContext;
import org.quartz.JobExecutionException;
import org.quartz.JobKey;
import org.quartz.PersistJobDataAfterExecution;
import org.quartz.TriggerKey;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;

import com.google.gson.Gson;

import co.com.ath.pgw.bsn.service.rs.NotificationPayments;
import co.com.ath.pgw.controller.out.rbm.qr.RBMActualizarQR;
import co.com.ath.pgw.controller.out.rbm.qr.RBMConsultaDetalladaQR;
import co.com.ath.pgw.persistence.dao.BrandDAO;
import co.com.ath.pgw.persistence.dao.NonWorkingDayDAO;
import co.com.ath.pgw.persistence.dao.PaymentWayDAO;
import co.com.ath.pgw.persistence.dao.TransactionDAO;
import co.com.ath.pgw.persistence.dao.TransactionStatusDAO;
import co.com.ath.pgw.persistence.model.Brand;
import co.com.ath.pgw.persistence.model.NonWorkingDay;
import co.com.ath.pgw.persistence.model.Transaction;
import co.com.ath.pgw.persistence.model.TransactionStatus;
import co.com.ath.pgw.persistence.service.ReconciledTransactionService;
import co.com.ath.pgw.persistence.service.SendMailService;
import co.com.ath.pgw.rest.dto.MsgRsHdr;
import co.com.ath.pgw.rest.globalPay.qr.CoreGetStateQrRBMRq;
import co.com.ath.pgw.rest.globalPay.qr.CoreGetStateQrRBMRs;
import co.com.ath.pgw.rest.globalPay.qr.CoreUpdateQrRBMRq;
import co.com.ath.pgw.rest.globalPay.qr.CoreUpdateQrRBMRs;
import co.com.ath.pgw.util.constants.CoreConstants;
import co.com.ath.pgw.util.constants.PaymentWayCodes;
import co.com.ath.pgw.util.enums.AVALBankEnum;
import co.com.ath.pgw.util.enums.TransactionStatusEnum;
import co.com.ath.ws.rs.objects.BankInfo;
import co.com.ath.ws.rs.objects.TransactionNotification;

@PersistJobDataAfterExecution
@DisallowConcurrentExecution
public class PGWGlobalPayQRImpl implements Job {

	private static final Logger LOGGER = LoggerFactory.getLogger(PGWGlobalPayQRImpl.class);
	private static final int REPETICION_CONFIRMACION_TXT = 1;
	
	Calendar calendar = Calendar.getInstance(Locale.getDefault());
	
	@Resource
	public TransactionDAO transactionDAO;

	@Resource
	private RBMConsultaDetalladaQR rbmConsultaDetalladaQR;
	
	@Resource
	private RBMActualizarQR rbmActualizarQR;
	
	@Resource
	public TransactionStatusDAO transactionStatusDAO;
	
	@Resource
	public PaymentWayDAO paymentWayDAO;
	
	@Resource
	private NonWorkingDayDAO nonWorkingDayDAO;
	
	@Resource
	private ReconciledTransactionService reconciledTransactionService;

	@Resource
	private SendMailService sendMailService;
	
	@Resource
	private BrandDAO brandDAO;
	
	@Resource
	private NotificationPayments notificationPayments;
    
	@Value("${pasarela.pse.nitagregador}")
	private String nitAgregator;

	@Value("${pasarela.pse.nitagregador.avVillas}")
	private String nitAgregatorAvVillas;
		
	@Value("${hour_compensation_date}")
	private int hourCompensation;
	
	@Value("${minutes_compensation_date}")
	private int minutesCompensation;
		
	@Override
	public void execute(JobExecutionContext context) throws JobExecutionException {
				
		JobDataMap dataMap = context.getJobDetail().getJobDataMap();
		long pmtId = dataMap.getLong("pmtId");
		int maxRepeticiones = dataMap.getInt("repeticion");
		String urlConsultaQr =dataMap.getString("QRUriConsultaDetallada");
		String urlActualizarQr = dataMap.getString("QRUriActualizarEstado");
		Transaction transaction = null ;
		Date curDate = null;
		SimpleDateFormat format = null;
		String codigoAux = null;
		
		
		Integer contador = dataMap.getInt("contador") ;
		dataMap.put("contador", ++contador);
		LOGGER.info("PmtId: "+ pmtId + " contador " + contador + " de "+ maxRepeticiones + " " + new Date());		
		try {
			Calendar fecha = Calendar.getInstance();
			curDate = fecha.getTime();
			format = new SimpleDateFormat("yyyy-MM-dd");
			
			TransactionStatus transactionStatus;
			transaction = transactionDAO.findByPmtId(pmtId);
			
			if (null == transaction) {

				LOGGER.error("No se encontro la transaccion pmtid:{}", pmtId);
				closeJob(context, String.valueOf(pmtId));

			} else {
				
				if (contador == maxRepeticiones) {
					LOGGER.info("Maximo de peticiones hacia RBM para el pmtId: {}",pmtId );
					//updateFailed(context, transaction, urlActualizarQr, curDate,format, false, true);
				}
				
				CoreGetStateQrRBMRq coreGetStateQrRBMInDTO = new CoreGetStateQrRBMRq();
				coreGetStateQrRBMInDTO.setFechaTransaccion(format.format(curDate));
				coreGetStateQrRBMInDTO.setIdTerminal(transaction.getCommerce().getTerminalCode());
				coreGetStateQrRBMInDTO.setIdAdquiriente(transaction.getCommerce().getIncocreditoCode());
				String idTransaccion =String.valueOf(transaction.getPmtId());
				coreGetStateQrRBMInDTO.setIdTransaccionTerminal(idTransaccion.substring(idTransaccion.length()-6,idTransaccion.length()));
				
				String responseConsulta = rbmConsultaDetalladaQR.getStateRBM(coreGetStateQrRBMInDTO, urlConsultaQr);
				
				CoreGetStateQrRBMRs coreGetStateQrRBMOutDTO  = new Gson().fromJson(responseConsulta, CoreGetStateQrRBMRs.class);
												
				if (coreGetStateQrRBMOutDTO == null || coreGetStateQrRBMOutDTO.getInformacionEstado() == null) {	
					LOGGER.error("Ocurrio un error consultando RBM para el pmtId:{} \n {}", pmtId, new Gson().fromJson(responseConsulta, MsgRsHdr.class));					
				} else {

					LOGGER.info("@Respuesta Consulta detallada QR pmtid:{} input \n {}", transaction.getPmtId(), coreGetStateQrRBMOutDTO);
									
					//actualiza info en bd
					transactionStatus = transactionStatusDAO.findById(TransactionStatusEnum.PROCESSING.getCode());
					
					transaction.setTrazabilityCode(coreGetStateQrRBMOutDTO.getInformacionGeneral().getNumeroAprobacion());
					
					transaction.setApprovalNumber(coreGetStateQrRBMOutDTO.getInformacionGeneral().getNumeroAprobacion());
					
					if (coreGetStateQrRBMOutDTO.getInformacionPago().getFranquicia() != null) {
						String globalPayCardType= coreGetStateQrRBMOutDTO.getInformacionPago().getFranquicia().equals(CoreConstants.QR_VISA) ? 
								"1": coreGetStateQrRBMOutDTO.getInformacionPago().getFranquicia().equals(CoreConstants.QR_MASTERCARD)?"2":"";					
						transaction.setIdBrand(new BigDecimal(globalPayCardType));	
					}
					
					String codigo = coreGetStateQrRBMOutDTO.getInformacionEstado().getCodigoRespuesta();
					String estado = coreGetStateQrRBMOutDTO.getInformacionEstado().getEstado();
					codigoAux = codigo;
									
					//se procesa el estado de la transaccion
					if (codigo.equals(CoreConstants.QR_CODIGO)) {
						
						Date currentDate = calcDate(coreGetStateQrRBMOutDTO.getInformacionGeneral().getHora());
						Date responseDate =new Date();
						
						responseDate = currentDate == null ? null : currentDate;	
						
						transaction.setPayDate(responseDate);
						
						transaction.setCompensationDate(calcCompensationDate(responseDate));
	
						transactionStatus = transactionStatusDAO.findById(TransactionStatusEnum.CONFIRMED_OK.getCode());
						transaction.setStatus(transactionStatus);
	
						LOGGER.info("pmtid:{} Cambiando estado a {} en procesamiento de estados.",
								transaction.getPmtId(), transactionStatus);
	
						transactionDAO.update(transaction);
						notificacion(transaction, TransactionStatusEnum.CONFIRMED_OK);
						
						//inactivar QR					
						updateStateQr(transaction,format.format(curDate), urlActualizarQr, false);
						closeJob(context, String.valueOf(pmtId));
						
					} else if (codigo.equals(CoreConstants.QR_CODIGO) && estado.trim().toUpperCase().equals(CoreConstants.QR_STATUS_PENDIENTE)) {
	
						transactionStatus = transactionStatusDAO.findById(TransactionStatusEnum.PROCESSING.getCode());
	
						if ((TransactionStatusEnum.REGISTERED.getCode().equals(transaction.getStatus().getCode())
								|| TransactionStatusEnum.LOGGED_IN.getCode().equals(transaction.getStatus().getCode()))) {
							
							LOGGER.info("pmtid:{} Cambiando estado a {} en procesamiento de estados.",
									transaction.getPmtId(), transactionStatus);
							
							transaction.setStatus(transactionStatus);
	
						} else if (TransactionStatusEnum.PROCESSING.getCode().equals(transaction.getStatus().getCode())) {
							LOGGER.info("pmtid:{}. La transaccion se ya encuentra en estado {} "
									+ "en la BD del Core de la Pasarela {}",
									transaction.getPmtId(), transactionStatus);
						} else {
							LOGGER.info("pmtid:{}. La transaccion se ya encuentra en un estado final ({})"
									+ "en la BD del Core de la Pasarela {}",
									transaction.getPmtId(), transaction.getStatus());
						}
						
						transactionDAO.update(transaction);
	
					} else if (codigo.equals(CoreConstants.QR_CODIGO) && estado.trim().toUpperCase().equals(CoreConstants.QR_STATUS_FALLIDA)) {
	
						LOGGER.info("transaccion pmtid: {} rechazada por RBM: {} {} {}",transaction.getPmtId(), 
								coreGetStateQrRBMOutDTO.getInformacionEstado().getCodigoRespuesta(),
								coreGetStateQrRBMOutDTO.getInformacionEstado().getEstado(),
								coreGetStateQrRBMOutDTO.getInformacionEstado().getEstadoDetallado());	
						updateFailed(context, transaction, urlActualizarQr, curDate,format);	
					}else if(codigo.equals(CoreConstants.QR_PARAMETRO_NO_COMPLETADO)) {
						LOGGER.info("Respuesta QR: {} {} Parámetro de entrada obligatorio no completado. pmtid:{}",codigo, estado, transaction.getPmtId());
					}else if(codigo.equals(CoreConstants.QR_ERROR_TRANSFORMACION)) {
						LOGGER.info("Respuesta QR: {} {} Error en transformaciones. pmtid:{}",codigo, estado, transaction.getPmtId());					
					}else if(codigo.equals(CoreConstants.QR_ERROR_CONEXION)) {
						LOGGER.info("Respuesta QR: {} {} Error de conexión. pmtid:{}",codigo, estado, transaction.getPmtId());	
					}else if(codigo.equals(CoreConstants.QR_ERROR_INTERNO)) {
						LOGGER.info("Respuesta QR: {} {} Error interno del servicio. pmtid:{}",codigo, estado, transaction.getPmtId());						
					}else if(codigo.equals(CoreConstants.QR_TIMEOUT)) {
						LOGGER.info("Respuesta QR: {} {} Error de Timeout. pmtid:{}",codigo, estado, transaction.getPmtId());						
					}else if(codigo.equals(CoreConstants.QR_EMPTY)) {
						LOGGER.info("Respuesta QR: {} {} Consulta sin resultados. pmtid:{}",codigo, estado, transaction.getPmtId());						
					} else {
						LOGGER.info("Respuesta QR: {} {} no esta mapeado dentro del Core. pmtid:{}",codigo, estado, transaction.getPmtId());	
					}
					
					/*
					 * if(contador == maxRepeticiones) {
					 * LOGGER.info("contador es igual a maximo de repeticiones"); codigoAux =
					 * codigo; }
					 */
				}	
			}			
				
			LOGGER.info("Valor del contador: : "+contador+"; Valor del maxRepeticiones: "+maxRepeticiones+"; Valor codigoAux"+codigoAux+"; PMTID:"+pmtId);
			if (contador == (maxRepeticiones + REPETICION_CONFIRMACION_TXT) && !codigoAux.equals(CoreConstants.QR_CODIGO)) {
				LOGGER.info("Confirmación estado final para el pmtId: {}",pmtId);
				updateFailed(context, transaction, urlActualizarQr, curDate,format, true, false);
			}

		}catch (Exception e) {
			updateFailed(context, transaction, urlActualizarQr, curDate,format);
			LOGGER.error("Catch PmtId Id:{} Error enviando parametros de consulta detallada. {}",pmtId,e);
		}
	}
	
	private void notificacion(Transaction transaction, TransactionStatusEnum txStatus) {

		// Leer Envio de Correo Electrónico
		Transaction txdata = transactionDAO.read(transaction.getId());

		if (txdata.getEmailflag() == CoreConstants.FLAG_EMAIL_OFF) {
			try {
				transaction.setEmailflag(CoreConstants.FLAG_EMAIL_ON);
				transactionDAO.update(transaction);
	
				// Conciliar la transacción
				reconciledTransactionService.createOrUpdate(transaction, null);
	
				// Enviar correo de confirmación
				sendMailService.sendMail(transaction);
	
				if (!(transaction.getCustomerEmail().equals(transaction.getPayerMail()))
						&& (transaction.getStatus().getCode() == txStatus.getCode())) {
	
					String mail = transaction.getPayerMail();
					transaction.setPayerMail(transaction.getCustomerEmail());
	
					sendMailService.sendMail(transaction);
					transaction.setPayerMail(mail);
				}
			}catch(Exception e) {
				LOGGER.error("pmtid: {}, Error: {}", transaction.getPmtId(), e.getMessage());
			}finally {
				if (transaction.getNotificacionPPagos() == null || transaction.getNotificacionPPagos()==0) {
					if (updateInformation(transaction)) {
						transaction.setNotificacionPPagos(1);
						transactionDAO.update(transaction);	
						LOGGER.info("Se actualizo el estado de notificacion a portal de pagos: {}",transaction.getPmtId());
					}
				}
			}			
		}
	}
	
	/**
	 * Se informa al Portal de Pagos el estado de la transaccion
	 */
	private boolean updateInformation(Transaction transaction) {

		boolean result=true;
		try {
			TransactionNotification transactionNotification =new TransactionNotification();

			transactionNotification.setBusinessCode(transaction.getStatus().getBusinessCode().getCode());
			transactionNotification.setBusinessCodeDesc(transaction.getStatus().getBusinessCode().getDescription().name());
			transactionNotification.setCommerceNuraCode(transaction.getCommerce().getNuraCode());
			transactionNotification.setPmtId(transaction.getPmtId());
			transactionNotification.setRquId(transaction.getRquId());
			transactionNotification.setTrnChannel(transaction.getTrnChannel());
			transactionNotification.setIpAddress(transaction.getIpAddress());
			transactionNotification.setCustomerDocId(transaction.getCustomerDocId());
			transactionNotification.setCustomerDocType(transaction.getCustomerDocType());
			transactionNotification.setAmt(transaction.getTotalValue());
			transactionNotification.setCurCode(transaction.getCurrency());				
			transactionNotification.setAgreementId(getAgrementId(transaction));
			transactionNotification.setName(transaction.getCommerce().getSubscription().getCompanyName());
			transactionNotification.setNit(transactionDAO.getAggregatorNit(transaction, nitAgregator, nitAgregatorAvVillas));
			transactionNotification.setPhone(transaction.getCommerce().getSubscription().getPhone());								
			transactionNotification.setFirstName(transaction.getCustomerName() != null ? transaction.getCustomerName() : "");
			transactionNotification.setMiddleName(transaction.getMiddleNameBuyer() != null ? transaction.getMiddleNameBuyer() : "");
			transactionNotification.setLastName(transaction.getLastNameBuyer() != null ? transaction.getLastNameBuyer() : "");
			transactionNotification.setSecondLastName(transaction.getSecondLastNameBuyer() != null ? transaction.getSecondLastNameBuyer() : "");				
			transactionNotification.setCustIdType(transaction.getPayerDocType() != null ? transaction.getPayerDocType() : "");
			transactionNotification.setCustIdNum(transaction.getPayerDocId() != null ? transaction.getPayerDocId() : "");
			transactionNotification.setAddress(transaction.getPayerAddress());
			transactionNotification.setEmailAddr(transaction.getPayerMail() != null ? transaction.getPayerMail() : "");
			transactionNotification.setPhone(transaction.getPayerPhone() != null ? transaction.getPayerPhone() : "");				
			transactionNotification.setRquId(transaction.getRquId());
			transactionNotification.setPmtId(transaction.getPmtId());
			transactionNotification.setTrnChannel(transaction.getTrnChannel());				
			transactionNotification.setStatusCode(transaction.getStatus().getCode());
			transactionNotification.setStatusDesc(transaction.getStatus().getDescription().toString());
			transactionNotification.setOrderId(transaction.getOrderNumber()); 
			transactionNotification.setOrderDesc(transaction.getDescription());				
			transactionNotification.setPmtWayId(String.valueOf(transaction.getPaymentWay().getId()));
			transactionNotification.setPmtWayType(transaction.getPaymentWay().getName());

			BankInfo bankInfo = new BankInfo();
			bankInfo.setBankId(transaction.getBank() == null ? null : transaction.getBank().getAvalCode());	
			transactionNotification.setBankInfo(bankInfo);
			transactionNotification.setEffDt(getDate(transaction));
			transactionNotification.setCompensationDate(transaction.getCompensationDate());
			transactionNotification.setApprovalId(PaymentWayCodes.PSE.equals(transaction.getPaymentWay().getId()) ? transaction.getTrazabilityCode()
					: transaction.getApprovalNumber());
			transactionNotification.setReferenceMap(getReferenceMap(transaction, true));
			
			transactionNotification.setIdOrigenTransaccion(transaction.getSource().getId().toString());
			
			String codNie = "";

			LOGGER.info("Validacion de tipo de pago PSE y pago de tarjeta de credito. tipo de pago: {}, token: {}", transaction.getPaymentWay().getId(), transaction.getTokenized());

			if(PaymentWayCodes.PSE.equals(transaction.getPaymentWay().getId()) && transaction.getTokenized()!=null ) {
				LOGGER.info("Validacion de tipo de pago PSE y pago de tarjeta de credito se encontro");
				codNie = transaction.getTokenized();
			}else {
				LOGGER.info("Validacion de tipo de pago PSE y pago de tarjeta de credito No se encontro");
			}
			transactionNotification.setCodNIE(codNie);			

			result=notificationPayments.notification(transactionNotification);	
		} catch (Exception e) {
			result=false;
			LOGGER.error("No fue posible consumir el servicio @NotificationPayments {}",
					e.getLocalizedMessage());
		}
		return result;
	}
	
	private String getAgrementId(Transaction transaction) {
		String nuraCode = transaction.getCommerce().getNuraCode();
		final boolean needHomologate = transaction.getBank() != null
				&& AVALBankEnum.AV_VILLAS.getAvalCode().equals(transaction.getBank().getAvalCode())
				&& transaction.getCommerce().getHomologationBAVVCode() != null;
		if (needHomologate) {
			return transaction.getCommerce().getHomologationBAVVCode();
		}

		if (nuraCode.startsWith("CPV")) {
			nuraCode = nuraCode.substring(3, nuraCode.length());
		}

		return nuraCode;
	}
	
	private Date getDate(Transaction transaction) {
		if (transaction.getPayDate() != null) {
			return transaction.getPayDate();
		}
		return transaction.getTransactionDate();
	}
	
	/**
	 * Obtiene las referencias de la transaccion y las retorna en una lista de
	 * string.
	 * 
	 * @param tx
	 *            Transaccion a procesar
	 * @return Lista con las referencias encontradas o lista vacia si no hay
	 *         ninguna.
	 */
	private Map<String, String> getReferenceMap(Transaction transaction, boolean fillPaymetWay) {
		Map<String, String> refMap = new HashMap<String, String>();
		if (transaction == null) {
			return refMap;
		}
		if (fillPaymetWay) {
			// Validar el medio de pago para incluir informacion adicional
			if (transaction.getPaymentWay() != null) {
				if ((PaymentWayCodes.PAGOS_AVAL.equals(transaction.getPaymentWay().getId())
						|| PaymentWayCodes.PSE.equals(transaction.getPaymentWay().getId())) && transaction.getBank() != null) {
					refMap.put("BankId", transaction.getBank().getAvalCode());
					refMap.put("BankName", transaction.getBank().getName());
				}

				if ( PaymentWayCodes.TC.equals(transaction.getPaymentWay().getId()) 
						&& transaction.getIdBrand() != null) {

					Brand brand = brandDAO.read(Long.valueOf(transaction.getIdBrand().toString()));
					refMap.put("Brand", brand.getName());

					if ( transaction.isGlobalPay() != null && transaction.isGlobalPay() ) {
						refMap.put("CardEmbossNum", transaction.getCreditCardNumber());
					}

				}		

				TransactionStatus transactionStatus = transactionStatusDAO.findById(TransactionStatusEnum.REFUSED.getCode());
				if (PaymentWayCodes.PSE.equals(transaction.getPaymentWay().getId()) && transaction.getStatus()!=transactionStatus) {
					refMap.put("TrnCycle", transaction.getTrnCycle());
					refMap.put("AchBankCode", transaction.getBank().getAchCode());
				}
			}
		}

		if (transaction.getReference1() != null && !transaction.getReference1().trim().isEmpty()) {
			refMap.put("Reference1", transaction.getReference1());
		}
		if (transaction.getReference2() != null && !transaction.getReference2().trim().isEmpty()) {
			refMap.put("Reference2", transaction.getReference2());
		}
		if (transaction.getReference3() != null && !transaction.getReference3().trim().isEmpty()) {
			refMap.put("Reference3", transaction.getReference3());
		}

		// Ventanilla de Pagos
		if (transaction.getPlantilla() == CoreConstants.TAQUILLA_ON) {
			refMap.put("Template", CoreConstants.TAQUILLA_ON.toString());
			refMap.put("Theme", transaction.getTaquilla().getIdTaquilla().toString());
			refMap.put("LogoURL", new String(transaction.getUrlLogo()));
		} else if (transaction.getPlantilla() == CoreConstants.TAQUILLA_OFF) {
			refMap.put("Template", CoreConstants.TAQUILLA_OFF.toString());
		}

		return refMap;
	}	
	/**
	 * 
	 * @param hour
	 * @return
	 */
	public Date calcDate(String hour) {
		
		Date current = null;
		try {
			String[] horaRbm = hour.split(":");
			
			Calendar cal = Calendar.getInstance();   
			cal.set(Calendar.HOUR, Integer.parseInt(horaRbm[0]));         
			cal.set(Calendar.MINUTE, Integer.parseInt(horaRbm[1]));       
			cal.set(Calendar.SECOND, Integer.parseInt(horaRbm[2]));  
			current = cal.getTime();
			
		} catch (Exception e) {
			LOGGER.error("Error calculando fecha de respuesta: {}",e);
		}		
		return current;		
	}
	
	/**
	 * Combierte la fecha de zona horaria universal a zona horaria bogota
	 * @param fecha
	 * @return
	 */
	public Date fechaUTCaCOT(Date fecha) {
		Calendar calCalendar = null;
		Date result = null;
		
		try {
			calCalendar = Calendar.getInstance();
			calCalendar.setTime(fecha);
			calCalendar.add(Calendar.HOUR, -5);			
			result = calCalendar.getTime();
		} catch (Exception e) {
			LOGGER.error("Error calculando zona horaria: {}",e);
		}		
		return result;
	}
	/**
	 * 
	 * @param current
	 * @return
	 */
	private Date calcCompensationDate(Date current) {
		Date resultDate = null;
		try {
			calendar.setTime(current);
			resultDate = current;
			if ((!isBusinessDay(current)) || ((calendar.get(Calendar.HOUR_OF_DAY)>hourCompensation) ||
					((calendar.get(Calendar.HOUR_OF_DAY)==hourCompensation) && (calendar.get(Calendar.MINUTE)>minutesCompensation)))){
				//Verifica el proximo dia habil
				resultDate = nextBusinessDay(current);
			}
			
		} catch (Exception e) {
			LOGGER.error("Error calculando fecha de compensacion: {}",e);
		}
		return resultDate;
	}
	/**
	 * 
	 * @param date
	 * @return
	 */
	public boolean isBusinessDay(Date date) {
		calendar.setTime(date);
		int dayOfWeek = calendar.get(Calendar.DAY_OF_WEEK);
		
		//Valida que el día no sea sábado o Domingo
		if (dayOfWeek == 1 || dayOfWeek == 7) {
			return false;
		}
		
		List<NonWorkingDay> nonWorkingDays = nonWorkingDayDAO.findByDay(getIntDate(date));
		NonWorkingDay day = new NonWorkingDay();
		day.setId(getIntDate(date));
		if (nonWorkingDays.contains(day)) {
			return false;
		}
		return true;
	}
	
	/**
	 * Retorna la fecha de la fecha dada en tipo entero en el formato YYYYMMDD
	 * @param date Fecha deseada
	 * @return Fecha en tipo int
	 */
	protected int getIntDate(Date date){
		int intDate = calendar.get(Calendar.YEAR);
		intDate = intDate * 100 + calendar.get(Calendar.MONTH) + 1;
		intDate = intDate * 100 + calendar.get(Calendar.DAY_OF_MONTH);
		return intDate;
	}
	/**
	 * 
	 * @param date
	 * @return
	 */
	public Date nextBusinessDay(Date date) {
		Date nextDate = nextDay(date);
		if (isBusinessDay(nextDate)) {
			return nextDate;
		}
		return nextBusinessDay(nextDate);
	}	
	/**
	 * 
	 * @param date
	 * @return
	 */
	public Date nextDay(Date date) {
		calendar.setTime(date);
		calendar.add(Calendar.DATE, 1);
		return calendar.getTime();
	}	
	/**
	 * Metodo que actualiza el estado del QR
	 * @param TX
	 */
	public void updateStateQr(Transaction tx , String fecha, String url, boolean ultimoConsumo ){

		CoreUpdateQrRBMRs updateQr = new CoreUpdateQrRBMRs();
		try {
			CoreUpdateQrRBMRq coreUpdateQrRBMRq = new CoreUpdateQrRBMRq();
			coreUpdateQrRBMRq.setCodigoUnico(tx.getCommerce().getIncocreditoCode());
			coreUpdateQrRBMRq.setTerminalId(tx.getCommerce().getTerminalCode());
			String idTransaccion = String.valueOf(tx.getPmtId());
			coreUpdateQrRBMRq.setIdTransaccion(idTransaccion.substring(idTransaccion.length()-6,idTransaccion.length()));
			coreUpdateQrRBMRq.setFechaQR(fecha);
			coreUpdateQrRBMRq.setEstado("INACTIVO");
			
			LOGGER.info("Request actualizar estado QR pmtid: {}.\n {}",tx.getPmtId(), coreUpdateQrRBMRq);
			LOGGER.info("Se inactiva QR para el pmtId: {}", tx.getPmtId());
			
			String responseUpdateQr = rbmActualizarQR.updateQr(coreUpdateQrRBMRq, url);
			
			updateQr  = new Gson().fromJson(responseUpdateQr, CoreUpdateQrRBMRs.class);
			
			if (updateQr == null || updateQr.getCodigoRespuesta() == null) {					
				LOGGER.error("Ocurrio un error al tratar de actualizarel estado en RBM para el pmtId:{} \n {}", tx.getPmtId(), new Gson().fromJson(responseUpdateQr, MsgRsHdr.class));
			} else {
				LOGGER.info("Respuesta actualizar estado QR pmtid: {}. \n {}",tx.getPmtId(), updateQr);
			}	
			
			if((updateQr == null || (updateQr.getCodigoRespuesta().equals(CoreConstants.ACTUALIZAR_QR_ERROR_ESTRUCTURA)
				|| updateQr.getCodigoRespuesta().equals(CoreConstants.ACTUALIZAR_QR_ERROR_INVOCACION)
				|| updateQr.getCodigoRespuesta().equals(CoreConstants.ACTUALIZAR_QR_ERROR_INTERNO)))
				&& ultimoConsumo) {
				
				LOGGER.info("Reintento actualizar estado QR pmtid: {}.",tx.getPmtId());
				
				responseUpdateQr = rbmActualizarQR.updateQr(coreUpdateQrRBMRq, url);
				
				updateQr  = new Gson().fromJson(responseUpdateQr, CoreUpdateQrRBMRs.class);
				
				if (updateQr == null || updateQr.getCodigoRespuesta() == null) {					
					LOGGER.error("Ocurrio un error al tratar de actualizarel estado en RBM para el pmtId:{} \n {}", tx.getPmtId(), new Gson().fromJson(responseUpdateQr, MsgRsHdr.class));
				} else {
					LOGGER.info("Respuesta actualizar estado QR pmtid: {}. \n {}",tx.getPmtId(), updateQr);
				}				
			}			
			
		} catch (Exception e) {
			LOGGER.error("Error actualizando el estado del QR para el pmtid: {}. {}",tx.getPmtId(), e);
		}
		
	}
	
	/**
	 * Metodo que detiene el ciclo de ejecucion  
	 * @param context
	 * @param pmtId
	 */
	public void closeJob(JobExecutionContext context, String pmtId) {
		try {
			context.getScheduler().deleteJob(new JobKey(pmtId));
			TriggerKey triggerKey = new TriggerKey("T"+pmtId);
			context.getScheduler().unscheduleJob(triggerKey);
			LOGGER.info("Se inactiva la consulta detallada hacia RBM para el pmtId: {}", pmtId);
		} catch (Exception e) {
			LOGGER.error("Error cerrando el Job de consulta detallada: {}",e);
		}
	}
	
	
	
	/**
	 * @param context
	 * @param tx
	 * @param url
	 * @param curDate
	 * @param format
	 */
	public void  updateFailed(JobExecutionContext context, Transaction tx, String url, Date curDate,SimpleDateFormat format) {
		updateFailed(context, tx, url, curDate, format, true, true);
	}
	
	
	/**
	 *  Metodo que actualiza el estado de las transacciones a fallido
	 * @param context
	 * @param tx
	 * @param url
	 * @param curDate
	 * @param format
	 */
	public void  updateFailed(JobExecutionContext context, Transaction tx, String url, Date curDate,SimpleDateFormat format, boolean closeJob, boolean closeTransaccion) {
		TransactionStatus transactionStatus;
		try {
			if(closeTransaccion) {
				//inactivar QR	
				updateStateQr(tx,format.format(curDate),url,true);
			}
			
			if( closeJob ) {
				transactionStatus = transactionStatusDAO.findById(TransactionStatusEnum.FAILED.getCode());
				tx.setStatus(transactionStatus);
				transactionDAO.update(tx);	

				notificacion(tx, TransactionStatusEnum.FAILED);
				//terminar Job
				closeJob(context, String.valueOf(tx.getPmtId()));
			}
		} catch (Exception e) {
			LOGGER.error("Error actualizando el cierre de la transaccion, {}",e);
		}
	}
	
}
