package co.com.ath.pgw.srv.mapper;

import java.math.BigDecimal;
import java.util.Calendar;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import co.com.ath.pgw.client.bank.info.MsgRqHdrType;
import co.com.ath.pgw.in.dto.CreditCardPaymentAddRequest;
import co.com.ath.pgw.in.dto.CreditCardPaymentAddResponse;
import co.com.ath.pgw.in.dto.CreditCardPaymentAddRqType;
import co.com.ath.pgw.in.dto.CreditCardPaymentAddRsType;
import co.com.ath.pgw.in.model.AgreementInfoType;
import co.com.ath.pgw.in.model.CardInfoUserTypeXsd;
import co.com.ath.pgw.in.model.CardLogicalDataType;
import co.com.ath.pgw.in.model.CustIdType;
import co.com.ath.pgw.in.model.CustNameType;
import co.com.ath.pgw.in.model.FeeType;
import co.com.ath.pgw.in.model.OrderInfoType;
import co.com.ath.pgw.in.model.PayingCustomerType;
import co.com.ath.pgw.in.model.ReferenceType;
import co.com.ath.pgw.in.model.StatusType;
import co.com.ath.pgw.in.model.TaxFeeType;
import co.com.ath.pgw.in.model.TransactionStatusType;
import co.com.ath.pgw.in.model.UserIdType;
import co.com.ath.pgw.rest.dto.AdditionalStatus;
import co.com.ath.pgw.rest.dto.MsgRsHdr;
import co.com.ath.pgw.rest.dto.PmtStatus;
import co.com.ath.pgw.rest.dto.RefInfo;
import co.com.ath.pgw.rest.dto.Status;
import co.com.ath.pgw.rest.request.dto.CreditTxvcPaymentRequest;
import co.com.ath.pgw.rest.request.dto.Header;
import co.com.ath.pgw.rest.response.dto.CreditTxvcPaymentResponse;
import co.com.ath.pgw.rest.response.dto.GenericErrorResponse;
import co.com.ath.pgw.util.constants.CoreConstants;
import co.com.ath.pgw.util.converter.DateUtil;
import co.com.ath.pgw.util.exception.CustomException;
/**
 * Servicio de Mapeo de objetos para pagos con tarjeta de credito desde k7
 * @author SophosSolutions
 * @version 1.0
 * @since 1.0
 */
public class MapperAddTxCreditPayment {
	
	private static Logger LOGGER = LoggerFactory.getLogger(MapperAddTxCreditPayment.class);
	/**
	 * mapeo request para pagos con tarjeta de credito desde k7
	 * @param creditTxvcPaymentRequest
	 * @param header
	 * @return CreditCardPaymentAddRequest
	 * @throws CustomException
	 */	
	public static CreditCardPaymentAddRequest mapperRequestToCoreRequest(CreditTxvcPaymentRequest creditTxvcPaymentRequest, Header header) throws CustomException {
		CreditCardPaymentAddRequest creditCardPaymentAddRequest = new CreditCardPaymentAddRequest();
		try {
			CreditCardPaymentAddRqType creditCardPaymentAddRqType = new CreditCardPaymentAddRqType();
			creditCardPaymentAddRqType.setRqUID(header.getRqUID());
			creditCardPaymentAddRqType.setChannel(header.getChannel());
			creditCardPaymentAddRqType.setIPAddr(header.getIpAddr());
			creditCardPaymentAddRqType.setClientDt(DateUtil.toXMLGregorianCalendar(Calendar.getInstance().getTime()));
			
			UserIdType userIdType = new UserIdType();
			userIdType.setCustIdNum(header.getIdentSerialNum());
			userIdType.setCustIdType(header.getGovIssueIdentType());
			creditCardPaymentAddRqType.setUserId(userIdType);
			
			MsgRqHdrType msgRqHdrType = new MsgRqHdrType();
			msgRqHdrType.setChannel(header.getChannel());
			msgRqHdrType.setIPAddr(header.getIpAddr());
			msgRqHdrType.setClientDt(DateUtil.toXMLGregorianCalendar(Calendar.getInstance().getTime()));
			msgRqHdrType.setUserId(userIdType);
			creditCardPaymentAddRqType.setMsgRqHdr(msgRqHdrType);
			
			/*PAGADOR*/
			PayingCustomerType payingCustomerType = new PayingCustomerType();
			CustNameType custNameType = new CustNameType();
			custNameType.setFirstName(creditTxvcPaymentRequest.getCustInfo().getPersonInfo().getPersonName().getFirstName());
			custNameType.setLastName(creditTxvcPaymentRequest.getCustInfo().getPersonInfo().getPersonName().getLastName());
			custNameType.setMiddleName(creditTxvcPaymentRequest.getCustInfo().getPersonInfo().getPersonName().getMiddleName());
			custNameType.setLegalName(creditTxvcPaymentRequest.getCustInfo().getPersonInfo().getPersonName().getLegalName());
			custNameType.setSecondLastName(creditTxvcPaymentRequest.getCustInfo().getPersonInfo().getPersonName().getSecondLastName());
			custNameType.setNickName(creditTxvcPaymentRequest.getCustInfo().getPersonInfo().getPersonName().getNickname());
			payingCustomerType.setCustName(custNameType);
			
			CustIdType custIdType = new CustIdType();
			custIdType.setCustIdType(creditTxvcPaymentRequest.getCustInfo().getPersonInfo().getGovIssueIdent().getGovIssueIdentType());
			custIdType.setCustIdNum(creditTxvcPaymentRequest.getCustInfo().getPersonInfo().getGovIssueIdent().getIdentSerialNum());
			payingCustomerType.setCustId(custIdType);
			
			payingCustomerType.setEmailAddr(creditTxvcPaymentRequest.getCustInfo().getPersonInfo().getContactInfo().getEmailAddr());
			payingCustomerType.setPhone(creditTxvcPaymentRequest.getCustInfo().getPersonInfo().getContactInfo().getPhoneNum().getPhone());				
			creditCardPaymentAddRqType.setPayingCustomer(payingCustomerType);
			
			AgreementInfoType agreementInfoType = new AgreementInfoType();
			agreementInfoType.setAgreementId(creditTxvcPaymentRequest.getAgreement().getAgrmId());
			agreementInfoType.setName(creditTxvcPaymentRequest.getAgreement().getName());
			agreementInfoType.setNIT(creditTxvcPaymentRequest.getAgreement().getNit());
			agreementInfoType.setPhone(creditTxvcPaymentRequest.getAgreement().getContactInfo().getPhoneNum().getPhone());
			creditCardPaymentAddRqType.setAgreementInfo(agreementInfoType);
			
			creditCardPaymentAddRqType.setTrnType(creditTxvcPaymentRequest.getInvoicePmtInfo().getInvoiceInfo().getInvoiceType());
			
			OrderInfoType orderInfoType = new OrderInfoType();
			orderInfoType.setOrderId(creditTxvcPaymentRequest.getInvoicePmtInfo().getInvoiceInfo().getInvoiceNum());
			orderInfoType.setDesc(creditTxvcPaymentRequest.getInvoicePmtInfo().getInvoiceInfo().getDesc());
			creditCardPaymentAddRqType.setOrderInfo(orderInfoType);
			
			creditCardPaymentAddRqType.setPmtId(creditTxvcPaymentRequest.getInvoicePmtInfo().getPmtStatus().getPmtAuthId());
			creditCardPaymentAddRqType.setPmtType(creditTxvcPaymentRequest.getInvoicePmtInfo().getPmtStatus().getPmtType());
			
			CardInfoUserTypeXsd cardInfoUserTypeXsd = new CardInfoUserTypeXsd();
			cardInfoUserTypeXsd.setInstalamentsNum(creditTxvcPaymentRequest.getInvoicePmtInfo().getCcAcctStmtRec().getNumberOfInstalments());
			
			CardLogicalDataType cardLogicalDataType = new CardLogicalDataType();
			cardLogicalDataType.setCardEmbossNum(creditTxvcPaymentRequest.getCardAcctId().getAcctId());
			cardLogicalDataType.setCardVrfyData(creditTxvcPaymentRequest.getCardAcctId().getCcMotoAcct().getCardVrfyData());
			cardLogicalDataType.setExpDt(creditTxvcPaymentRequest.getCardAcctId().getCcMotoAcct().getExpDt() != null && !creditTxvcPaymentRequest.getCardAcctId().getCcMotoAcct().getExpDt().isEmpty() ? DateUtil.toXMLGregorianCalendar(DateUtil.parseString(creditTxvcPaymentRequest.getCardAcctId().getCcMotoAcct().getExpDt(), "yyyy-MM-dd")) : null);
			cardLogicalDataType.setBrand(creditTxvcPaymentRequest.getCardAcctId().getCcMotoAcct().getBrand());
			cardInfoUserTypeXsd.setCardLogicalData(cardLogicalDataType);
			creditCardPaymentAddRqType.setCardInfoUser(cardInfoUserTypeXsd);
			
			FeeType feeType = new FeeType();
			feeType.setAmt(creditTxvcPaymentRequest.getFee().getCurAmt().getAmt());
			feeType.setCurCode(creditTxvcPaymentRequest.getFee().getCurAmt().getCurCode());
			feeType.setCurRate(new BigDecimal(creditTxvcPaymentRequest.getFee().getRate()));
			creditCardPaymentAddRqType.setFee(feeType);
			
			TaxFeeType taxFeeType = new TaxFeeType();
			taxFeeType.setAmt(creditTxvcPaymentRequest.getTaxPmtInfo().getCurAmt().getAmt());
			taxFeeType.setCurCode(creditTxvcPaymentRequest.getTaxPmtInfo().getCurAmt().getCurCode());
			creditCardPaymentAddRqType.setTaxFee(taxFeeType);
			
			for(RefInfo refInfo: creditTxvcPaymentRequest.getRefInfo()) {
				ReferenceType referenceType = new ReferenceType();
				referenceType.setRefId(refInfo.getRefId());
				referenceType.setRefType(refInfo.getRefType());
				creditCardPaymentAddRqType.getReference().add(referenceType);
			}
			
			creditCardPaymentAddRqType.setTrnChannel(creditTxvcPaymentRequest.getTrnSrcInfo().getTrnSrc());
			creditCardPaymentAddRequest.setCreditCardPaymentAddRq(creditCardPaymentAddRqType);
		} catch (Exception e) {
			LOGGER.error("Error mapeando informacion ", e.getMessage());
			throw new CustomException(e.getMessage(), setCustomError(e));
		}
		return creditCardPaymentAddRequest;
	}
	/**
	 * mapeo respuesta exitosa para pagos con tarjeta de credito desde k7
	 * @param creditCardPaymentAddResponse
	 * @return CreditTxvcPaymentResponse
	 * @throws CustomException
	 */		
	public static CreditTxvcPaymentResponse mapperResponseSuccessCore(CreditCardPaymentAddResponse creditCardPaymentAddResponse) throws CustomException {
		CreditTxvcPaymentResponse creditTxvcPaymentResponse = new CreditTxvcPaymentResponse();
		try {
			PmtStatus pmtStatus = new PmtStatus();
			pmtStatus.setPmtAuthId(creditCardPaymentAddResponse.getCreditCardPaymentAddRs().getPmtId());
			pmtStatus.setStatusCode(String.valueOf(creditCardPaymentAddResponse.getCreditCardPaymentAddRs().getTransactionStatus().getTrnStatusCode()));
			pmtStatus.setStatusDesc(creditCardPaymentAddResponse.getCreditCardPaymentAddRs().getTransactionStatus().getTrnStatusDesc());
			pmtStatus.setEffDt(DateUtil.toDate(creditCardPaymentAddResponse.getCreditCardPaymentAddRs().getTransactionStatus().getEffDt()));
			pmtStatus.setApprovalId((creditCardPaymentAddResponse.getCreditCardPaymentAddRs().getApprovalId())!=null?(creditCardPaymentAddResponse.getCreditCardPaymentAddRs().getApprovalId()):"");
			pmtStatus.setNextDt(DateUtil.toDate(creditCardPaymentAddResponse.getCreditCardPaymentAddRs().getTransactionStatus().getCompensationDt()));
			creditTxvcPaymentResponse.setPmtStatus(pmtStatus);
		} catch (Exception e) {
			LOGGER.error("Error mapeando informacion ", e.getMessage());
			throw new CustomException(e.getMessage(), setCustomError(e));
		}
		return creditTxvcPaymentResponse;
	}
	/**
	 * mapeo respuesta error generico para pagos con tarjeta de credito desde k7
	 * @param creditCardPaymentAddResponse
	 * @return GenericErrorResponse
	 * @throws CustomException
	 */		
	public static GenericErrorResponse mapperResponseErrorCore(CreditCardPaymentAddResponse creditCardPaymentAddResponse) throws CustomException {
		GenericErrorResponse genericErrorResponse = new GenericErrorResponse();
		
		Status status = new Status();
		status.setStatusCode(String.valueOf(creditCardPaymentAddResponse.getCreditCardPaymentAddRs().getStatus().getStatusCode()));
		status.setStatusDesc(creditCardPaymentAddResponse.getCreditCardPaymentAddRs().getStatus().getStatusDesc());
		status.setEndDt(Calendar.getInstance().getTime());
		
		AdditionalStatus additionalStatus = new AdditionalStatus();
		if(creditCardPaymentAddResponse.getCreditCardPaymentAddRs().getTransactionStatus().getTrnServerStatusCode() != null) {
			additionalStatus.setStatusCode(creditCardPaymentAddResponse.getCreditCardPaymentAddRs().getTransactionStatus().getTrnServerStatusCode());
			additionalStatus.setStatusDesc(creditCardPaymentAddResponse.getCreditCardPaymentAddRs().getTransactionStatus().getTrnServerStatusDesc());
		}else {
			additionalStatus.setStatusCode(String.valueOf(creditCardPaymentAddResponse.getCreditCardPaymentAddRs().getTransactionStatus().getTrnStatusCode()));
			additionalStatus.setStatusDesc(creditCardPaymentAddResponse.getCreditCardPaymentAddRs().getTransactionStatus().getTrnStatusDesc());
		}
		status.setAdditionalStatus(additionalStatus);
		
		MsgRsHdr msgRsHdr = new MsgRsHdr();
		msgRsHdr.setStatus(status);
		msgRsHdr.setEndDt(Calendar.getInstance().getTime());
		genericErrorResponse.setMsgRsHdr(msgRsHdr);
		
		return genericErrorResponse;
	}
	/**
	 * mapeo respuesta error custom para pagos con tarjeta de credito desde k7
	 * @param Exception
	 * @return CreditCardPaymentAddResponse
	 * @throws CustomException
	 */			
	public static CreditCardPaymentAddResponse setCustomError(Exception e){
		CreditCardPaymentAddResponse creditCardPaymentAddResponse = new CreditCardPaymentAddResponse();
		CreditCardPaymentAddRsType creditCardPaymentAddRsType = new CreditCardPaymentAddRsType();
		
		StatusType statusType = new StatusType();
		statusType.setStatusCode(CoreConstants.ERROR_STATUS_CODE_300);
		statusType.setStatusDesc(CoreConstants.ERROR_STATUS_CODE_DESC);
		creditCardPaymentAddRsType.setStatus(statusType);
		
		TransactionStatusType transactionStatusType = new TransactionStatusType();
		transactionStatusType.setTrnStatusCode(Long.valueOf(CoreConstants.ERROR_STATUS_CODE_300));
		transactionStatusType.setTrnStatusDesc(CoreConstants.ERROR_STATUS_CODE_DESC);
		transactionStatusType.setTrnServerStatusCode(CoreConstants.ERROR_STATUS_CODE_300.toString());
		transactionStatusType.setTrnServerStatusDesc(e.toString());
		creditCardPaymentAddRsType.setTransactionStatus(transactionStatusType);
		
		creditCardPaymentAddResponse.setCreditCardPaymentAddRs(creditCardPaymentAddRsType);
		return creditCardPaymentAddResponse;
	}
	
}
