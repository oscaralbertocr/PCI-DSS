package co.com.ath.pgw.bsn.controller.impl;

import javax.annotation.Resource;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import co.com.ath.pgw.bsn.controller.PaymentGlobalPayService;
import co.com.ath.pgw.bsn.dto.in.IniciarTransaccionInDTO;
import co.com.ath.pgw.bsn.dto.out.IniciarTransaccionOutDTO;
import co.com.ath.pgw.bsn.globalPay.dto.IniciarTransaccionDeCompraRqType;
import co.com.ath.pgw.bsn.globalPay.dto.IniciarTransaccionDeCompraRsType;
import co.com.ath.pgw.bsn.service.PGWGlobalPayCheckoutService;
import co.com.ath.pgw.util.converter.GlobalPayObjectConverter;

/**
* Implementación de servicio puente para las peticiones entre 
* los servicios de PaymentGlobalPay y el Core
* 
* @author camilo.bustamante@sophossolutions.com
* @version 1.0 03 Enero 2019
* @RQ31686 RBM_Integracion_Boton_TC_GlobalPay
* 
*/
@Service
public class PaymentGlobalPayControlServiceImpl implements PaymentGlobalPayService{

	static Logger LOGGER = LoggerFactory.getLogger(PaymentGlobalPayControlServiceImpl.class);
	
//	@Resource
//	PGWGlobalPayService pgwGlobalPayService;
	
	@Resource
	PGWGlobalPayCheckoutService pgwGlobalPayCheckoutService;

	@Override
	public IniciarTransaccionDeCompraRsType iniciarTransaccionDeCompra(IniciarTransaccionDeCompraRqType iniciarTransaccionDeCompraRqType) {
		IniciarTransaccionDeCompraRsType iniciarTransaccionDeCompraRsType;
		/*try {*/
			IniciarTransaccionInDTO iniciarTransaccionInDTO = GlobalPayObjectConverter.convertIniciarTransaccionDeCompraRsTypeToIniciarTransaccionInDTO(iniciarTransaccionDeCompraRqType);
			
//			IniciarTransaccionOutDTO iniciarTransaccionOutDTO = pgwGlobalPayService.IniciarTransaccionDeCompra(iniciarTransaccionInDTO);
			IniciarTransaccionOutDTO iniciarTransaccionOutDTO = pgwGlobalPayCheckoutService.checkout(iniciarTransaccionInDTO); 
			
			iniciarTransaccionDeCompraRsType = GlobalPayObjectConverter.convertIniciarTransaccionOutDTOtoIniciarTransaccionDeCompraRsType(iniciarTransaccionOutDTO);
		/*} catch (Exception ex) {
			LOGGER.error(ex.getMessage());
			ex.printStackTrace();
			transactionAddRs = GlobalPayObjectConverter.convertIniciarTransaccionOutDTOtoIniciarTransaccionDeCompraRsTypeError(transactionAddRq, ex); 
		}*/
		return iniciarTransaccionDeCompraRsType;
	}

//	@Override
//	public ConsultarEstadoDePagoRsType consultarEstadoDePago(ConsultarEstadoDePagoRqType consultarEstadoDePagoRqType) {
//		
//		ConsultarEstadoDePagoRsType consultarEstadoDePagoRsType;
//		
//		try {
//			ConsultarEstadoDePagoInDTO consultarEstadoDePagoInDTO = GlobalPayObjectConverter.convertConsultarEstadoDePagoRqTypeToConsultarEstadoDePagoInDTO(consultarEstadoDePagoRqType);
//			ConsultarEstadoDePagoOutDTO consultarEstadoDePagoOutDTO = pgwGlobalPayService.consultarEstadoDePago(consultarEstadoDePagoInDTO); 
//			consultarEstadoDePagoRsType = GlobalPayObjectConverter.convertConsultarEstadoDePagoOutDTOtoConsultarEstadoDePagoRsType(consultarEstadoDePagoOutDTO);
//		} catch (Exception ex) {
//			consultarEstadoDePagoRsType = GlobalPayObjectConverter.convertConsultarEstadoDePagoOutDTOtoConsultarEstadoDePagoRsTypeError(consultarEstadoDePagoRqType, ex); 
//		}
//		
//		return consultarEstadoDePagoRsType;
//	}

}
