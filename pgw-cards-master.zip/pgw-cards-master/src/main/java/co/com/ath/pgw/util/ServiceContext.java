package co.com.ath.pgw.util;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

@Component
public class ServiceContext {

	static String path;

	@Value("${pasarela.app.parametros}")
	public void setPathContext(String pathContext) {
		ServiceContext.path = pathContext;
	}
}
