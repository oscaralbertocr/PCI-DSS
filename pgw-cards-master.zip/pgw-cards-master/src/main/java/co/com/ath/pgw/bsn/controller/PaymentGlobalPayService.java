package co.com.ath.pgw.bsn.controller;

import co.com.ath.pgw.bsn.globalPay.dto.IniciarTransaccionDeCompraRqType;
import co.com.ath.pgw.bsn.globalPay.dto.IniciarTransaccionDeCompraRsType;

/**
* Servicio puente para las peticiones entre los servicios de PaymentGlobalPay y el Core
* 
* @author camilo.bustamante@sophossolutions.com
* @version 1.0 03 Enero 2019
* @RQ31686 RBM_Integracion_Boton_TC_GlobalPay
* 
*/
public interface PaymentGlobalPayService {

	/**
	 * servicio que permiote crear una transaccion para los pagos rbm GlobalPay
	 * @param iniciarTransaccionDeCompraRqType
	 * @return IniciarTransaccionDeCompraRsType
	 */
    public IniciarTransaccionDeCompraRsType iniciarTransaccionDeCompra(IniciarTransaccionDeCompraRqType iniciarTransaccionDeCompraRqType);
    
//    /**
//     * servicio que permite consultar el estado de una transaccion rbm GlobalPay
//     * @param consultarEstadoDePagoRqType
//     * @return ConsultarEstadoDePagoRsType
//     */
//    public ConsultarEstadoDePagoRsType consultarEstadoDePago(ConsultarEstadoDePagoRqType consultarEstadoDePagoRqType);
    
}
