package co.com.ath.pgw.bsn.service.impl;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

import javax.annotation.Resource;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import co.com.ath.pgw.bsn.dto.in.ConsultarEstadoDePagoInDTO;
import co.com.ath.pgw.bsn.dto.in.CoreGetStateRBMPaymentInDTO;
import co.com.ath.pgw.bsn.dto.in.IniciarTransaccionInDTO;
import co.com.ath.pgw.bsn.dto.out.ConsultarEstadoDePagoOutDTO;
import co.com.ath.pgw.bsn.dto.out.CoreGetStateRBMPaymentOutDTO;
import co.com.ath.pgw.bsn.dto.out.CoreInitTransactionRbmOutDTO;
import co.com.ath.pgw.bsn.dto.out.IniciarTransaccionOutDTO;
import co.com.ath.pgw.bsn.model.bo.CommerceBO;
import co.com.ath.pgw.bsn.model.bo.SubscriptionBO;
import co.com.ath.pgw.bsn.model.bo.TransactionBO;
import co.com.ath.pgw.bsn.service.PGWGlobalPayService;
import co.com.ath.pgw.bsn.service.rs.NotificationPayments;
import co.com.ath.pgw.controller.out.rbm.globalPay.RBMGlobalPayCtrlService;
import co.com.ath.pgw.persistence.dao.BrandDAO;
import co.com.ath.pgw.persistence.dao.NonWorkingDayDAO;
import co.com.ath.pgw.persistence.dao.TransactionDAO;
import co.com.ath.pgw.persistence.dao.TransactionStatusDAO;
import co.com.ath.pgw.persistence.model.BlackList;
import co.com.ath.pgw.persistence.model.BlackListIp;
import co.com.ath.pgw.persistence.model.Brand;
import co.com.ath.pgw.persistence.model.NonWorkingDay;
import co.com.ath.pgw.persistence.model.ResponseCode;
import co.com.ath.pgw.persistence.model.Transaction;
import co.com.ath.pgw.persistence.model.TransactionStatus;
import co.com.ath.pgw.persistence.service.ReconciledTransactionService;
import co.com.ath.pgw.persistence.service.SendMailService;
import co.com.ath.pgw.util.constants.CoreConstants;
import co.com.ath.pgw.util.constants.PaymentWayCodes;
import co.com.ath.pgw.util.enums.AVALBankEnum;
import co.com.ath.pgw.util.enums.BusinessStatusEnum;
import co.com.ath.pgw.util.enums.TransactionStatusEnum;
import co.com.ath.pgw.util.i18n.BundleKeys;
import co.com.ath.ws.rs.objects.BankInfo;
import co.com.ath.ws.rs.objects.TransactionNotification;


/**
* Implementación por defecto del Servicio para de GlobalPay de RBM 
* 
* @author camilo.bustamante@sophossolutions.com
* @version 1.0 03 Enero 2019
* @RQ31686 RBM_Integracion_Boton_TC_GlobalPay
* 
* 
* <strong>Autor</strong>Edwin Alexander Bohorquez</br>
* <strong>Descripcion</strong>Motor de riesgo</br>
* <strong>Número de Cambios</strong>3</br>
* <strong>Identificador corto</strong>C10</br>
* 
* <strong>Autor</strong>Edwin Alexander Bohorquez</br>
* <strong>Descripcion</strong>Desagregacion de Motor de riesgo</br>
* <strong>Número de Cambios</strong>1</br>
* <strong>Identificador corto</strong>C11</br>
* 
* @PDP-374
* <strong>Autor</strong>Camilo Bustamante</br>
* <strong>Descripcion</strong>Envio de correo promocional</br>
* <strong>Numero de Cambios</strong>1</br>
* <strong>Identificador corto</strong>C12</br>
* 
*/

@Service
public class PGWGlobalPayServiceImpl implements PGWGlobalPayService{
	
	static Logger LOGGER = LoggerFactory.getLogger(PGWGlobalPayServiceImpl.class);
	
	private String EXITOSO_1 = "00";
	private String EXITOSO_2 = "08";
	private String ERROR_9002 = "9002";
	private String ERROR_9003 = "9003";
	private String ERROR_9004 = "9004";
	private String ERROR_9006 = "9006";
	private String ERROR_9008 = "9008";
	
	private String STATUS_DESC_INICIADA = "Iniciada";
	private String STATUS_DESC_APROBADA = "Aprobada";
	private String STATUS_DESC_APROBADO = "Aprobado";
	private String STATUS_DESC_RECHAZADA = "Rechazada";
	private String STATUS_DESC_RECHAZADO = "Rechazado";
	private String STATUS_DESC_PROCESANDO = "Procesando";
	private String STATUS_DESC_ERROR = "Error";
	
	
	@Resource
	private RBMGlobalPayCtrlService rbmGlobalPayCtrlService;
	
	
	@Resource
	private PGWRbmPaymentServiceImpl pgwRbmPaymentServiceImpl;
	
	@Resource
	private ReconciledTransactionService reconciledTransactionService;
	
	@Value("${hour_compensation_date}")
	private int hourCompensation;
	
	@Value("${minutes_compensation_date}")
	private int minutesCompensation;
	
	@Value("${pasarela.pse.nitagregador}")
	private String nitAgregator;

	@Value("${pasarela.pse.nitagregador.avVillas}")
	private String nitAgregatorAvVillas;
	
	@Value("${pasarela.rbm.globalpay.url}")
    private String globalPayUrl;

	
	@Resource
	private SendMailService sendMailService; 	

	@Resource
	private TransactionDAO transactionDAO;
	
	@Resource
	private BrandDAO brandDAO;
	
	@Resource
	private TransactionStatusDAO transactionStatusDAO;
	
	@Resource
	private NotificationPayments notificationPayments;
	
	@Resource
	private NonWorkingDayDAO nonWorkingDayDAO;
	
	Calendar calendar = Calendar.getInstance(Locale.getDefault());
	
	@Override
	public IniciarTransaccionOutDTO IniciarTransaccionDeCompra(IniciarTransaccionInDTO iniciarTransaccionInDTO) {
		
		
		TransactionStatus transactionStatus = pgwRbmPaymentServiceImpl.transactionStatusDAO.findById(TransactionStatusEnum.CONFIRMED_NA.getCode());
		
        String approvalId = null;
        
        IniciarTransaccionOutDTO iniciarTransaccionOutDTO = new IniciarTransaccionOutDTO();        
        
        iniciarTransaccionOutDTO.setRqUID(iniciarTransaccionInDTO.getRqUID());
        				
		// Obtener la transacción
		Transaction transaction = pgwRbmPaymentServiceImpl.transactionDAO.findByPmtId(Long.valueOf(iniciarTransaccionInDTO.getTransactionBO().getPmtId()));
		
		Long pmtid = null;
		if( null != transaction &&  null != transaction.getPmtId() )
			pmtid = transaction.getPmtId();
			
		
		try{
							
			//VALIDACIÓN DOBLE CLICK PAGOS TC
			if(transaction.getPaymentWay().getId().equals(PaymentWayCodes.TC)){
				LOGGER.info("...ERROR DOBLE CLICK BOTON PAGAR TC");
				iniciarTransaccionOutDTO.setStatusCode(CoreConstants.ERROR_STATUS_CODE_300);
				iniciarTransaccionOutDTO.setStatusDesc(CoreConstants.ERROR_STATUS_PROCESING_TC);
	            iniciarTransaccionOutDTO.setTrnStatusCode(Long.valueOf(CoreConstants.ERROR_STATUS_CODE_300));
	            iniciarTransaccionOutDTO.setTrnStatusDesc(CoreConstants.ERROR_STATUS_PROCESING_TC);
	            iniciarTransaccionOutDTO.setTrnServerStatusCode(String.valueOf(CoreConstants.ERROR_STATUS_CODE_300)); 
	            iniciarTransaccionOutDTO.setTrnServerStatusDesc(CoreConstants.ERROR_STATUS_PROCESING_TC); 
	            iniciarTransaccionOutDTO.setEffDt(transaction.getPayDate());
	            iniciarTransaccionOutDTO.setCompensationDate(transaction.getCompensationDate());
	            iniciarTransaccionOutDTO.setApprovalId(transaction.getApprovalNumber());
		        return iniciarTransaccionOutDTO;
			}
			
			transaction.setPaymentWay(pgwRbmPaymentServiceImpl.paymentWayDAO.read(PaymentWayCodes.TC));
			if (iniciarTransaccionInDTO.getTransactionBO().getTermsNConditions() != null
					&& !iniciarTransaccionInDTO.getTransactionBO().getTermsNConditions().isEmpty()) {
				transaction.setTermsAndConditions(Boolean.parseBoolean(iniciarTransaccionInDTO.getTransactionBO().getTermsNConditions()));
			}
			
			transaction.setGlobalPay(true);
			transaction.setBankCollecter(transaction.getCommerce().getSubscription().getBank());
			
			//validacion de Topes
			if(!pgwRbmPaymentServiceImpl.validateTopByCommerceAndPaymentWay(transaction, pgwRbmPaymentServiceImpl.paymentWayDAO.read(PaymentWayCodes.TC))){
				
				//Si no pasa la validacion de Topes
				setTopesError(iniciarTransaccionOutDTO, transaction);
				
			} else {
				transaction.setIpAddress(iniciarTransaccionInDTO.getTransactionBO().getIpAddress());
				transaction.setResponseCode(null);
				
				//Cambio Nombre Duplicado INI
				
				if (iniciarTransaccionInDTO.getTransactionBO().getCustomerName() != null 
						&& !iniciarTransaccionInDTO.getTransactionBO().getCustomerName().isEmpty() 
						&& !iniciarTransaccionInDTO.getTransactionBO().getCustomerName().equals("GUEST")) {
					transaction.setPayerName(iniciarTransaccionInDTO.getTransactionBO().getFirstNamePayer());
					transaction.setMiddleNamePayer("");
					transaction.setLastNamePayer("");
					transaction.setSecondLastNamePayer("");
				}
				//Cambio Nombre Duplicado FIN
							
				transaction.setBankCollecter(transaction.getCommerce().getSubscription().getBank());  
						
		        //información del comprador
				if (iniciarTransaccionInDTO.getTransactionBO().getCustomerName() != null
						&& !iniciarTransaccionInDTO.getTransactionBO().getCustomerName().isEmpty()) {
					transaction.setCustomerName(iniciarTransaccionInDTO.getTransactionBO().getCustomerName());
				}
		
				if (iniciarTransaccionInDTO.getTransactionBO().getMiddleNameBuyer() != null
						&& !iniciarTransaccionInDTO.getTransactionBO().getMiddleNameBuyer().isEmpty()) {
					transaction.setMiddleNameBuyer(iniciarTransaccionInDTO.getTransactionBO().getMiddleNameBuyer());
				}
				
				if (iniciarTransaccionInDTO.getTransactionBO().getLastNameBuyer() != null
						&& !iniciarTransaccionInDTO.getTransactionBO().getLastNameBuyer().isEmpty()) {
					transaction.setLastNameBuyer(iniciarTransaccionInDTO.getTransactionBO().getLastNameBuyer());
				}
				
				if (iniciarTransaccionInDTO.getTransactionBO().getSecondLastNameBuyer() != null
						&& !iniciarTransaccionInDTO.getTransactionBO().getSecondLastNameBuyer().isEmpty()) {
					transaction.setSecondLastNameBuyer(iniciarTransaccionInDTO.getTransactionBO().getSecondLastNameBuyer());
				}
		
				if (iniciarTransaccionInDTO.getTransactionBO().getCustomerEmail() != null
						&& !iniciarTransaccionInDTO.getTransactionBO().getCustomerEmail().isEmpty()) {
					transaction.setCustomerEmail(iniciarTransaccionInDTO.getTransactionBO().getCustomerEmail());
				}
		
				if (iniciarTransaccionInDTO.getTransactionBO().getCustomerMobileNumber() != null
						&& !iniciarTransaccionInDTO.getTransactionBO().getCustomerMobileNumber().isEmpty()) {
					transaction.setCustomerMobileNumber(iniciarTransaccionInDTO.getTransactionBO().getCustomerMobileNumber());
				}
		
				//información del pagador
				if(iniciarTransaccionInDTO.getTransactionBO().getPayerCompany() != null
						&& !iniciarTransaccionInDTO.getTransactionBO().getPayerCompany().isEmpty()){
					transaction.setPayerCompany(iniciarTransaccionInDTO.getTransactionBO().getPayerCompany());
				}
		
				if(iniciarTransaccionInDTO.getTransactionBO().getFirstNamePayer() != null
						&& !iniciarTransaccionInDTO.getTransactionBO().getFirstNamePayer().isEmpty()){
					transaction.setPayerName(iniciarTransaccionInDTO.getTransactionBO().getFirstNamePayer());
				}
		
				if(iniciarTransaccionInDTO.getTransactionBO().getMiddleNamePayer() != null
						&& !iniciarTransaccionInDTO.getTransactionBO().getMiddleNamePayer().isEmpty()){
					transaction.setMiddleNamePayer(iniciarTransaccionInDTO.getTransactionBO().getMiddleNamePayer());
				}
		
				if(iniciarTransaccionInDTO.getTransactionBO().getLastNamePayer() != null
						&& !iniciarTransaccionInDTO.getTransactionBO().getLastNamePayer().isEmpty()) {
					transaction.setLastNamePayer(iniciarTransaccionInDTO.getTransactionBO().getLastNamePayer());
				}
		
				if(iniciarTransaccionInDTO.getTransactionBO().getSecondLastNamePayer() != null
						&& !iniciarTransaccionInDTO.getTransactionBO().getSecondLastNamePayer().isEmpty()) {
					transaction.setSecondLastNamePayer(iniciarTransaccionInDTO.getTransactionBO().getSecondLastNamePayer());
				}
				

				if(iniciarTransaccionInDTO.getTransactionBO().getPayerNickName() != null 
						&& !iniciarTransaccionInDTO.getTransactionBO().getPayerNickName().isEmpty()) {
					transaction.setPayerNickName(iniciarTransaccionInDTO.getTransactionBO().getPayerNickName());
				}
		
				if(iniciarTransaccionInDTO.getTransactionBO().getPayerDocType() != null 
						&& !iniciarTransaccionInDTO.getTransactionBO().getPayerDocType().isEmpty()) {
					transaction.setPayerDocType(iniciarTransaccionInDTO.getTransactionBO().getPayerDocType());
				}
				
				if(iniciarTransaccionInDTO.getTransactionBO().getPayerDocId() != null 
						&& !iniciarTransaccionInDTO.getTransactionBO().getPayerDocId().isEmpty()) {
					transaction.setPayerDocId(iniciarTransaccionInDTO.getTransactionBO().getPayerDocId());
				}
				
				if(iniciarTransaccionInDTO.getTransactionBO().getPayerGender() != null 
						&& !iniciarTransaccionInDTO.getTransactionBO().getPayerGender().isEmpty()) {
					transaction.setPayerGender(iniciarTransaccionInDTO.getTransactionBO().getPayerGender());
				}
				
				if(iniciarTransaccionInDTO.getTransactionBO().getPayerBirthDate() != null 
						&& iniciarTransaccionInDTO.getTransactionBO().getPayerBirthDate().toString() != "") {
					transaction.setPayerBirthDate(iniciarTransaccionInDTO.getTransactionBO().getPayerBirthDate());
				}
				
				if(iniciarTransaccionInDTO.getTransactionBO().getPayerCity() != null 
						&& !iniciarTransaccionInDTO.getTransactionBO().getPayerCity().isEmpty()) {
					transaction.setPayerCity(iniciarTransaccionInDTO.getTransactionBO().getPayerCity());
				}
				
				if(iniciarTransaccionInDTO.getTransactionBO().getPayerDepartment() != null 
						&& !iniciarTransaccionInDTO.getTransactionBO().getPayerDepartment().isEmpty()) {
					transaction.setPayerDepartment(iniciarTransaccionInDTO.getTransactionBO().getPayerDepartment());
				}
				
				if(iniciarTransaccionInDTO.getTransactionBO().getPayerCountry() != null 
						&& !iniciarTransaccionInDTO.getTransactionBO().getPayerCountry().isEmpty()) {
					transaction.setPayerCounty(iniciarTransaccionInDTO.getTransactionBO().getPayerCountry());
				}
				
				if(iniciarTransaccionInDTO.getTransactionBO().getPayerAddress() != null
						&& !iniciarTransaccionInDTO.getTransactionBO().getPayerAddress().isEmpty()) { 
					transaction.setPayerAddress(iniciarTransaccionInDTO.getTransactionBO().getPayerAddress());
				}
				
				if(iniciarTransaccionInDTO.getTransactionBO().getPayerMail() != null 
						&& !iniciarTransaccionInDTO.getTransactionBO().getPayerMail().isEmpty()) {
					transaction.setPayerMail(iniciarTransaccionInDTO.getTransactionBO().getPayerMail());
				}
				
				if(iniciarTransaccionInDTO.getTransactionBO().getPayerPhone() != null 
						&& !iniciarTransaccionInDTO.getTransactionBO().getPayerPhone().isEmpty()) {
					transaction.setPayerPhone(iniciarTransaccionInDTO.getTransactionBO().getPayerPhone());
				}
		
				transaction.setPaymentWay(pgwRbmPaymentServiceImpl.paymentWayDAO.read(PaymentWayCodes.TC));
				transaction.setStatus(transactionStatus);
				transaction.setCustomerDocType(iniciarTransaccionInDTO.getTransactionBO().getCustomerDocType());
				transaction.setCustomerDocId(iniciarTransaccionInDTO.getTransactionBO().getCustomerDocId());

		        if (iniciarTransaccionInDTO.getTransactionBO().getCustomerName() != null
						&& !iniciarTransaccionInDTO.getTransactionBO().getCustomerName().isEmpty()) {
		        	transaction.setCustomerName(iniciarTransaccionInDTO.getTransactionBO().getCustomerName());
				}
		
				if (iniciarTransaccionInDTO.getTransactionBO().getCustomerEmail() != null
						&& !iniciarTransaccionInDTO.getTransactionBO().getCustomerEmail().isEmpty()) {
					transaction.setCustomerEmail(iniciarTransaccionInDTO.getTransactionBO().getCustomerEmail());
				}
		
				if (iniciarTransaccionInDTO.getTransactionBO().getCustomerMobileNumber() != null
						&& !iniciarTransaccionInDTO.getTransactionBO().getCustomerMobileNumber()
								.isEmpty()) {
					transaction.setCustomerMobileNumber(iniciarTransaccionInDTO.getTransactionBO()
							.getCustomerMobileNumber());
				}


				List<BlackList> blackListBuyer = new ArrayList<BlackList>();
				List<BlackList> blackListPayer = new ArrayList<BlackList>();
				List<BlackListIp> blackListIp = new ArrayList<BlackListIp>();
		
				// Se recorta a los primeros 6 digitos 
				iniciarTransaccionInDTO.setRqUID(pgwRbmPaymentServiceImpl.convertRqId(iniciarTransaccionInDTO.getRqUID()));
		
				// Se almacena el rquId
				transaction.setRquId(iniciarTransaccionInDTO.getRqUID().toString());
		
				//Actualiza la informacion de la transaccion inicialmente  
				pgwRbmPaymentServiceImpl.transactionDAO.update(transaction);
				
				iniciarTransaccionInDTO = fillTransactionBO(transaction, iniciarTransaccionInDTO);
		
				//Validacion de listas negras
				blackListBuyer = pgwRbmPaymentServiceImpl.blackListDAO.findByDocument(iniciarTransaccionInDTO.getTransactionBO().getCustomerDocType(), iniciarTransaccionInDTO.getTransactionBO().getCustomerDocId());
				blackListPayer = pgwRbmPaymentServiceImpl.blackListDAO.findByDocument(transaction.getPayerDocType(), transaction.getPayerDocId());
				blackListIp = pgwRbmPaymentServiceImpl.blackListIpDAO.findByIp(iniciarTransaccionInDTO.getTransactionBO().getIpAddress());
		
				//Si la Transaccion aplica como Listas Negras
				if(blackListBuyer.size() > 0 || blackListPayer.size() > 0 || blackListIp.size() > 0) {
					
					//Flujo de Listas Negras para RBM
					iniciarTransaccionOutDTO = rbmBlackListFlow(iniciarTransaccionOutDTO, transaction, blackListIp.size());
					
				} 
				/** INI - C10 **/
				/* 
				else {
			
					// Realiza consulta Analyze a RSA
					AnalyzeResponse analyzeRsaOutDTO = null;
					try {
						analyzeRsaOutDTO = pgwService.adaptiveAuthenticationService.analyze(
								inDTO.getTransactionBO(), RunRiskType.RISK_ONLY);
					} catch (Exception ex) {
						LOGGER.error("@PGWGlobalPayServiceImpl IniciarTransaccionDeCompra Ocurrio un error en Motor de Riesgo. {}",
								ex.getLocalizedMessage());
		
						// Garantiza que la transaccion continue
						analyzeRsaOutDTO = pgwService.adaptiveAuthenticationService.getAnalyzeDummy();
					}
		
					UserStatus userStatus = analyzeRsaOutDTO.getIdentificationData().getUserStatus();
					TriggeredRule triggeredRule = analyzeRsaOutDTO.getRiskResult().getTriggeredRule();

					if ( triggeredRule.getActionCode().getValue().equals(ActionCode.DENY.getValue()) ) {
		
						LOGGER.info("@PGWGlobalPayServiceImpl IniciarTransaccionDeCompra pmtid: {} "
								+ "Motor de Riesgo retorno ActionCode {}. Se rechaza como lista negra.", tx.getPmtId(), ActionCode.DENY);
						
						try {
							analyzeRsaOutDTO = pgwService.adaptiveAuthenticationService.analyze(inDTO.getTransactionBO(), RunRiskType.ALL);
						} catch (Exception e) {
							LOGGER.error("@PGWGlobalPayServiceImpl IniciarTransaccionDeCompra Ocurrio un error en Motor de Riesgo. {}", 
									e.getLocalizedMessage());
						}
		
						//Flujo de Listas Negras para RBM
						outDTO = rbmBlackListFlow(outDTO, tx, blackListIp.size());
		
					} else if (userStatus == UserStatus.NOTENROLLED || userStatus == UserStatus.VERIFIED) {

						if (userStatus == UserStatus.NOTENROLLED) {
		
							CreateUserResponse cur;
							try {
								cur = pgwService.adaptiveAuthenticationService.createUser(inDTO.getTransactionBO());
							} catch (Exception e) {
								LOGGER.error("@PGWGlobalPayServiceImpl IniciarTransaccionDeCompra Ocurrio un error en Motor de Riesgo. {}", 
										e.getLocalizedMessage());
		
								// Garantiza que la transaccion continue
								cur = pgwService.adaptiveAuthenticationService.getCreateUserDummy();
							}
		
							userStatus = cur.getIdentificationData().getUserStatus();
							triggeredRule = cur.getRiskResult().getTriggeredRule();
						}

				
						if ( triggeredRule.getActionCode().getValue().equals(ActionCode.DENY.getValue()) ) {
		
							LOGGER.info("@PGWGlobalPayServiceImpl IniciarTransaccionDeCompra pmtid: {} "
									+ "Motor de Riesgo retorno ActionCode {}. Se rechaza como lista negra.", 
									tx.getPmtId(), ActionCode.DENY);
							
							try {
								analyzeRsaOutDTO = pgwService.adaptiveAuthenticationService.analyze(inDTO.getTransactionBO(),RunRiskType.ALL);
							} catch (Exception e) {
								LOGGER.error("@PGWGlobalPayServiceImpl IniciarTransaccionDeCompra Ocurrio un error en Motor de Riesgo. {}",
										e.getLocalizedMessage());
							}
		
							//Flujo de Listas Negras para RBM
							outDTO = rbmBlackListFlow(outDTO, tx, blackListIp.size());
		
						} else if (userStatus.equals(UserStatus.VERIFIED)) {
						
							//Se consume el servicio de GlobalPay para crear transaccion.
							CoreInitTransactionRbmOutDTO outRBM = 
									rbmService.coreInitTransactionRbm(inDTO, CoreConstants.TIMEOUT_CREATETXINFORMATION);

							if ( outRBM.getServerStatusCode() != null &&
									( outRBM.getServerStatusCode().equals(EXITOSO_1) || outRBM.getServerStatusCode().equals(EXITOSO_2) )
								 ) {
								
								String terminal = inDTO.getTransactionBO().getCommerce().getTerminalCode();
								approvalId = outRBM.getIdTransaccion();
								String urlRBM = globalPayUrl+"?idTerminal="+terminal+"*idTransaccion="+approvalId;
								
								transactionStatus = pgwService.transactionStatusDAO.findById(TransactionStatusEnum.PROCESSING.getCode());
								tx.setStatus(transactionStatus);
								tx.setApprovalNumber(approvalId);
								tx.setTrazabilityCode(approvalId);
								
								outDTO.setStatusCode(CoreConstants.SUCCESS_STATUS_CODE);
								outDTO.setStatusDesc(pgwService.getMessage(BundleKeys.TRANSACTION_SUCCESS, null, pgwService.locale));
								
								outDTO.setTrnStatusCode(transactionStatus.getBusinessCode().getCode());
								outDTO.setTrnStatusDesc(pgwService.getMessage(
										transactionStatus.getBusinessCode().getDescription().getMessageCode(), null, pgwService.locale));
								
								outDTO.setApprovalId(approvalId);
								outDTO.setUrlRBM(urlRBM);
								
							} else if (  outRBM.getServerStatusCode() != null && (
									outRBM.getServerStatusCode().equals(ERROR_9002) ||
									outRBM.getServerStatusCode().equals(ERROR_9003) ||
									outRBM.getServerStatusCode().equals(ERROR_9004) ||
									outRBM.getServerStatusCode().equals(ERROR_9006) ||
									outRBM.getServerStatusCode().equals(ERROR_9008) ) ) {
								
								LOGGER.info("@PGWGlobalPayServiceImpl IniciarTransaccionDeCompra, transaccion rechazada. "
										+ "pmtid:{}, Error GlobalPay:{}, StatusCode:{}, StatusDesc:{}, "
										+ "TrnServerStatusCode:{}, ServerStatusDesc:{}, ", 
										inDTO.getTransactionBO().getPmtId(), outRBM.getServerStatusCode(), 
										outRBM.getStatusCode(), outRBM.getStatusDesc(), 
										outRBM.getTrnServerStatusCode(), outRBM.getServerStatusDesc());
								
								transactionStatus = pgwService.transactionStatusDAO.findById(TransactionStatusEnum.CONFIRMED_NA.getCode());
								tx.setStatus(transactionStatus);
								
								outDTO.setStatusCode(outRBM.getStatusCode());
								outDTO.setStatusDesc(outRBM.getStatusDesc());
								outDTO.setTrnStatusCode(Long.parseLong(outRBM.getServerStatusCode()));
								outDTO.setTrnStatusDesc(outRBM.getServerStatusDesc());
							
							} else {
								
								LOGGER.error("@PGWGlobalPayServiceImpl IniciarTransaccionDeCompra pmtid:{}, "
										+ "Error de RBM no mapeado.", tx.getPmtId() );
								
								transactionStatus = pgwService.transactionStatusDAO.findById(TransactionStatusEnum.FAILED.getCode());
								
								tx.setStatus(transactionStatus);
								pgwService.transactionDAO.update(tx);
								
								notificacion(tx, TransactionStatusEnum.FAILED);
								
								throw new Exception("@PGWGlobalPayServiceImpl IniciarTransaccionDeCompra pmtid:" 
										+ tx.getPmtId() + ", Error de RBM no mapeado." );
								
							}

							// Actualizar la transacción
							tx.setApprovalNumber(approvalId);
							pgwService.transactionDAO.update(tx);
		
						
						// Objeto de salida
						outDTO.setPmtId(String.valueOf(tx.getPmtId()));
						outDTO.setTrnServerStatusCode(null);
						outDTO.setTrnServerStatusDesc(null);
						outDTO.setEffDt(tx.getPayDate());
						outDTO.setApprovalId(tx.getApprovalNumber());
	
					} else {
						LOGGER.error("PGWGlobalPayServiceImpl IniciarTransaccionDeCompra {} \n", CoreConstants.RSA_USER_STATUS_ERROR);
						outDTO = rsaError(outDTO, tx, CoreConstants.RSA_USER_STATUS_ERROR);
					}
	
						} else {
							LOGGER.error("@PGWGlobalPayServiceImpl IniciarTransaccionDeCompra {} \n", CoreConstants.RSA_USER_STATUS_ERROR);
							outDTO = rsaError(outDTO, tx, CoreConstants.RSA_USER_STATUS_ERROR);
						}
	
					}
				*/
				/** FIN - C10 **/
				
				/** INICIO-C11 **/
				//Se consume el servicio de GlobalPay para crear transaccion.
				CoreInitTransactionRbmOutDTO coreInitTransactionRbmOutDTO = rbmGlobalPayCtrlService.coreInitTransactionRbm(iniciarTransaccionInDTO, CoreConstants.TIMEOUT_CREATETXINFORMATION);

				if ( coreInitTransactionRbmOutDTO.getServerStatusCode() != null &&
						( coreInitTransactionRbmOutDTO.getServerStatusCode().equals(EXITOSO_1) || coreInitTransactionRbmOutDTO.getServerStatusCode().equals(EXITOSO_2) )
					 ) {
					
					String terminal = iniciarTransaccionInDTO.getTransactionBO().getCommerce().getTerminalCode();
					approvalId = coreInitTransactionRbmOutDTO.getIdTransaccion();
					String urlRBM = globalPayUrl+"?idTerminal="+terminal+"&idTransaccion="+approvalId;
					
					transactionStatus = pgwRbmPaymentServiceImpl.transactionStatusDAO.findById(TransactionStatusEnum.PROCESSING.getCode());
					transaction.setStatus(transactionStatus);
					transaction.setApprovalNumber(approvalId);
					transaction.setTrazabilityCode(approvalId);
					Date current = new Date();
					transaction.setPayDate(current);
										
					iniciarTransaccionOutDTO.setStatusCode(CoreConstants.SUCCESS_STATUS_CODE);
					iniciarTransaccionOutDTO.setStatusDesc(pgwRbmPaymentServiceImpl.getMessage(BundleKeys.TRANSACTION_SUCCESS, null, pgwRbmPaymentServiceImpl.locale));
					
					iniciarTransaccionOutDTO.setTrnStatusCode(transactionStatus.getBusinessCode().getCode());
					iniciarTransaccionOutDTO.setTrnStatusDesc(pgwRbmPaymentServiceImpl.getMessage(
							transactionStatus.getBusinessCode().getDescription().getMessageCode(), null, pgwRbmPaymentServiceImpl.locale));
					
					iniciarTransaccionOutDTO.setApprovalId(approvalId);
					iniciarTransaccionOutDTO.setUrlRBM(urlRBM);
					
				} else if (  coreInitTransactionRbmOutDTO.getServerStatusCode() != null && (
						coreInitTransactionRbmOutDTO.getServerStatusCode().equals(ERROR_9002) ||
						coreInitTransactionRbmOutDTO.getServerStatusCode().equals(ERROR_9003) ||
						coreInitTransactionRbmOutDTO.getServerStatusCode().equals(ERROR_9004) ||
						coreInitTransactionRbmOutDTO.getServerStatusCode().equals(ERROR_9006) ||
						coreInitTransactionRbmOutDTO.getServerStatusCode().equals(ERROR_9008) ) ) {
					
					LOGGER.info("@PGWGlobalPayServiceImpl IniciarTransaccionDeCompra, transaccion rechazada. "
							+ "pmtid:{}, Error GlobalPay:{}, StatusCode:{}, StatusDesc:{}, "
							+ "TrnServerStatusCode:{}, ServerStatusDesc:{}, ", 
							iniciarTransaccionInDTO.getTransactionBO().getPmtId(), coreInitTransactionRbmOutDTO.getServerStatusCode(), 
							coreInitTransactionRbmOutDTO.getStatusCode(), coreInitTransactionRbmOutDTO.getStatusDesc(), 
							coreInitTransactionRbmOutDTO.getTrnServerStatusCode(), coreInitTransactionRbmOutDTO.getServerStatusDesc());
					
					transactionStatus = pgwRbmPaymentServiceImpl.transactionStatusDAO.findById(TransactionStatusEnum.CONFIRMED_NA.getCode());
					transaction.setStatus(transactionStatus);
					
					iniciarTransaccionOutDTO.setStatusCode(coreInitTransactionRbmOutDTO.getStatusCode());
					iniciarTransaccionOutDTO.setStatusDesc(coreInitTransactionRbmOutDTO.getStatusDesc());
					iniciarTransaccionOutDTO.setTrnStatusCode(null);
					iniciarTransaccionOutDTO.setTrnStatusDesc(null);

				} else {
					
					LOGGER.error("@PGWGlobalPayServiceImpl IniciarTransaccionDeCompra pmtid:{}, "
							+ "Error de RBM no mapeado.", transaction.getPmtId() );
					
					transactionStatus = pgwRbmPaymentServiceImpl.transactionStatusDAO.findById(TransactionStatusEnum.FAILED.getCode());
					
					transaction.setStatus(transactionStatus);
					pgwRbmPaymentServiceImpl.transactionDAO.update(transaction);
					
					notificacion(transaction, TransactionStatusEnum.FAILED);
					
					throw new Exception("@PGWGlobalPayServiceImpl IniciarTransaccionDeCompra pmtid:" 
							+ transaction.getPmtId() + ", Error de RBM no mapeado." );
					
				}

				// Actualizar la transacción
				transaction.setApprovalNumber(approvalId);
				pgwRbmPaymentServiceImpl.transactionDAO.update(transaction);


				// Objeto de salida
				iniciarTransaccionOutDTO.setPmtId(String.valueOf(transaction.getPmtId()));
				iniciarTransaccionOutDTO.setTrnServerStatusCode(coreInitTransactionRbmOutDTO.getServerStatusCode());
				iniciarTransaccionOutDTO.setTrnServerStatusDesc(coreInitTransactionRbmOutDTO.getServerStatusDesc());
				iniciarTransaccionOutDTO.setEffDt(transaction.getPayDate());
				iniciarTransaccionOutDTO.setApprovalId(transaction.getApprovalNumber());
	            iniciarTransaccionOutDTO.setCompensationDate(null);			
				/** FIN-C11 **/
				
			}
			
		} catch (Exception e) {
			LOGGER.error( "@PGWGlobalPayServiceImpl IniciarTransaccionDeCompra, "
					+ "No se pudo realizar la transaccion con el RqUID:{}\nException:{}\nCause:{} ", 
					iniciarTransaccionInDTO.getRqUID(), e.getLocalizedMessage(), e.getCause() );
			
			LOGGER.error("@PGWGlobalPayServiceImpl IniciarTransaccionDeCompra, pmtid:{}", pmtid);
			
			System.err.println(e.getMessage());
			iniciarTransaccionOutDTO.setStatusCode(CoreConstants.ERROR_STATUS_CODE_300);
			iniciarTransaccionOutDTO.setStatusDesc(CoreConstants.ERROR_STATUS_CODE_DESC_300);
			iniciarTransaccionOutDTO.setTrnStatusCode(Long.valueOf(CoreConstants.FAULT_STATUS_CODE));
			iniciarTransaccionOutDTO.setTrnStatusDesc(CoreConstants.FAULT_STATUS_ERROR_DESC);
			iniciarTransaccionOutDTO.setTrnServerStatusCode(String.valueOf(CoreConstants.FAULT_STATUS_CODE));
			iniciarTransaccionOutDTO.setTrnServerStatusDesc(e.toString());
			
			/// ************** Transaccion Fallida *************
			if(transaction != null) {
				transactionStatus = pgwRbmPaymentServiceImpl.transactionStatusDAO.findById(TransactionStatusEnum.FAILED.getCode());
				
				transaction.setStatus(transactionStatus);
				pgwRbmPaymentServiceImpl.transactionDAO.update(transaction);
				
				notificacion(transaction, TransactionStatusEnum.FAILED);
			}
			
		} 
		
		/** INI - C10 **/		
		//outDTO.setToken(pgwService.adaptiveAuthenticationService.getLastTokenCookie(inDTO.getTransactionBO().getPmtId()));
		/** FIN - C10 **/
		
		return iniciarTransaccionOutDTO;
		
	}
	/**
	 * Se encarga de completar los valores de la transaccion para rbm 
	 * @param transaction
	 * @param iniciarTransaccionInDTO
	 * @return IniciarTransaccionInDTO
	 */
	private IniciarTransaccionInDTO fillTransactionBO(Transaction transaction, IniciarTransaccionInDTO iniciarTransaccionInDTO) {

		TransactionBO transactionBO = iniciarTransaccionInDTO.getTransactionBO();
		
		SubscriptionBO subscriptionBO = new SubscriptionBO();
		subscriptionBO.setCompanyName(transaction.getCommerce().getSubscription().getCompanyName());
		
		CommerceBO commerceBO = new CommerceBO();
		commerceBO.setNuraCode(transaction.getCommerce().getNuraCode());
		commerceBO.setSubscription(subscriptionBO);
		commerceBO.setNit(transaction.getCommerce().getNit().toString());
		commerceBO.setIncocreditoCode(transaction.getCommerce().getIncocreditoCode());
		commerceBO.setTerminalCode(transaction.getCommerce().getTerminalCode());
		
		transactionBO.setCommerce(commerceBO );
		transactionBO.setOrderNumber(transaction.getOrderNumber());
		transactionBO.setDescription(transaction.getDescription());
		
		transactionBO.setCurrency(transaction.getCurrency());
		transactionBO.setTotalValue(transaction.getTotalValue());
		transactionBO.setTaxValue(transaction.getTaxValue());
		

		iniciarTransaccionInDTO.setTransactionBO(transactionBO);
		return iniciarTransaccionInDTO;
	}
	
	/**
	 * Se encarga de marcar la transaccion fallida, enviar el mensaje
	 * de error y configura el DTO de salida 
	 * @param outDTO
	 * @param tx
	 * @param exceptionCode
	 * @return
	 */
	@SuppressWarnings("unused")
	@Deprecated
	private IniciarTransaccionOutDTO rsaError(IniciarTransaccionOutDTO iniciarTransaccionOutDTO,
			Transaction transaction, String exceptionCode) {
		
		/** INI - C10 **/
		String codigoError = ""; //-->temporal (se debe quitar)		
		//String codigoError = pgwService.getRsaResponseCode(CoreConstants.RSA_ERROR).getDescription();
		/** FIN - C10 **/
		
		transaction.setStatus(pgwRbmPaymentServiceImpl.transactionStatusDAO.findById(TransactionStatusEnum.FAILED.getCode()));
		
		/** INI - C10 **/		
		//tx.setResponseCode(pgwService.getRsaResponseCode(exceptionCode));
		/** FIN - C10 **/
		
		pgwRbmPaymentServiceImpl.transactionDAO.update(transaction);
		
		LOGGER.error("@AdaptiveAuthentication rsaError, Descripcion: {} ", transaction.getResponseCode().getDescription());

		// Envio de correo
		sendMailService.sendMail(transaction);
		
		iniciarTransaccionOutDTO.setPmtId(transaction.getPmtId().toString());
		iniciarTransaccionOutDTO.setStatusCode(Integer.parseInt(codigoError));
		iniciarTransaccionOutDTO.setStatusDesc(transaction.getResponseCode().getDescription());
		iniciarTransaccionOutDTO.setTrnStatusCode(null);
		iniciarTransaccionOutDTO.setTrnStatusDesc(null);
		iniciarTransaccionOutDTO.setTrnServerStatusCode(codigoError.toString());
		iniciarTransaccionOutDTO.setTrnServerStatusDesc(CoreConstants.ERROR_STATUS_CODE_DESC);
		iniciarTransaccionOutDTO.setEffDt(transaction.getPayDate());
		iniciarTransaccionOutDTO.setCompensationDate(transaction.getCompensationDate());
		iniciarTransaccionOutDTO.setApprovalId(transaction.getApprovalNumber());
		
		return iniciarTransaccionOutDTO;
	}
	
	/**
	 * Flujo de listas Negras para medio de pago RBM
	 * 
	 * @param outDTO
	 * @param tx
	 * @param blackListIpSize
	 * @return
	 */
	private IniciarTransaccionOutDTO rbmBlackListFlow(IniciarTransaccionOutDTO iniciarTransaccionOutDTO,
			Transaction transaction, int blackListIpSize) {
		
		TransactionStatus transactionStatus = pgwRbmPaymentServiceImpl.transactionStatusDAO.findById(TransactionStatusEnum.CANCELLED.getCode());
		transaction.setStatus(transactionStatus);
		transaction.setResponseCode(pgwRbmPaymentServiceImpl.getFraudResponseCode(blackListIpSize));
		pgwRbmPaymentServiceImpl.transactionDAO.update(transaction);
		LOGGER.error("@IniciarTransaccionDeCompra {} ", transaction.getResponseCode().getDescription());
		// Leer Envio de Correo Electrónico
		Transaction transactionData = pgwRbmPaymentServiceImpl.transactionDAO.read(transaction.getId());
		if(transactionData.getEmailflag()==CoreConstants.FLAG_EMAIL_OFF){
			
			transaction.setEmailflag(CoreConstants.FLAG_EMAIL_ON);
			pgwRbmPaymentServiceImpl.transactionDAO.update(transaction);
			
			// Enviar correo de confirmación			
			sendMailService.sendMail(transaction);
		}
        
		// Objeto de salida
		iniciarTransaccionOutDTO.setPmtId(String.valueOf(transaction.getPmtId()));
		iniciarTransaccionOutDTO.setStatusCode(CoreConstants.ERROR_DATA_SECURITY_CODE);
		iniciarTransaccionOutDTO.setStatusDesc(CoreConstants.ERROR_DATA_SECURITY_CODE_DESC);
		iniciarTransaccionOutDTO.setTrnStatusCode(Long.valueOf(CoreConstants.ERROR_DATA_SECURITY_CODE));
		iniciarTransaccionOutDTO.setTrnStatusDesc(CoreConstants.ERROR_DATA_SECURITY_CODE_DESC);
		iniciarTransaccionOutDTO.setTrnServerStatusCode(null); 
		iniciarTransaccionOutDTO.setTrnServerStatusDesc(null);
		iniciarTransaccionOutDTO.setEffDt(transaction.getPayDate());
		iniciarTransaccionOutDTO.setCompensationDate(transaction.getCompensationDate());
		iniciarTransaccionOutDTO.setApprovalId(transaction.getApprovalNumber());
        
		return iniciarTransaccionOutDTO;
	}
	
	private IniciarTransaccionOutDTO setTopesError(IniciarTransaccionOutDTO iniciarTransaccionOutDTO, Transaction transaction) {
		
		ResponseCode responseCode = pgwRbmPaymentServiceImpl.responseCodeDAO.read(CoreConstants.TOP_ERROR_CODE);
		
		transaction.setStatus(pgwRbmPaymentServiceImpl.transactionStatusDAO.findById(TransactionStatusEnum.REFUSED.getCode()));
		transaction.setResponseCode(responseCode);
		pgwRbmPaymentServiceImpl.transactionDAO.update(transaction);
		
		LOGGER.error("@IniciarTransaccionDeCompra {} ", transaction.getResponseCode().getDescription());

		// Leer  Envio de Correo Electrónico
		Transaction txdata = pgwRbmPaymentServiceImpl.transactionDAO.read(transaction.getId());
		if(txdata.getEmailflag()==CoreConstants.FLAG_EMAIL_OFF){
			
			transaction.setEmailflag(CoreConstants.FLAG_EMAIL_ON);
			pgwRbmPaymentServiceImpl.transactionDAO.update(transaction);
			
			// Enviar correo de confirmación			
			sendMailService.sendMail(transaction);
		}
				
		iniciarTransaccionOutDTO.setStatusCode(Integer.parseInt(transaction.getResponseCode().getCode()));
		iniciarTransaccionOutDTO.setStatusDesc(transaction.getResponseCode().getDescription());
		iniciarTransaccionOutDTO.setTrnStatusCode(CoreConstants.SUCCESS_STATUS_CODE.longValue());
		iniciarTransaccionOutDTO.setTrnStatusDesc(pgwRbmPaymentServiceImpl.getMessage(BundleKeys.TRANSACTION_SUCCESS, null, pgwRbmPaymentServiceImpl.locale));
		iniciarTransaccionOutDTO.setTrnServerStatusCode(CoreConstants.SUCCESS_STATUS_CODE.toString());
		iniciarTransaccionOutDTO.setTrnServerStatusDesc(pgwRbmPaymentServiceImpl.getMessage(BundleKeys.TRANSACTION_SUCCESS, null, pgwRbmPaymentServiceImpl.locale));
		iniciarTransaccionOutDTO.setEffDt(transaction.getPayDate());
		iniciarTransaccionOutDTO.setCompensationDate(transaction.getCompensationDate());
		iniciarTransaccionOutDTO.setApprovalId(transaction.getApprovalNumber());
		
		return iniciarTransaccionOutDTO;
		
	}
	

	@Override
	public ConsultarEstadoDePagoOutDTO consultarEstadoDePago(ConsultarEstadoDePagoInDTO consultarEstadoDePagoInDTO) {
		
		ConsultarEstadoDePagoOutDTO consultarEstadoDePagoOutDTO = new ConsultarEstadoDePagoOutDTO();
		
		TransactionStatus transactionStatus;
		
		// Obtener la transacción
		Transaction transaction = pgwRbmPaymentServiceImpl.transactionDAO.findByPmtId(Long.valueOf(consultarEstadoDePagoInDTO.getTransactionBO().getPmtId()));
		
		transactionStatus = pgwRbmPaymentServiceImpl.transactionStatusDAO.findById(TransactionStatusEnum.CONFIRMED_OK.getCode());
		
		CoreGetStateRBMPaymentInDTO coreGetStateRBMPaymentInDTO = new CoreGetStateRBMPaymentInDTO();
		coreGetStateRBMPaymentInDTO.setChannel(consultarEstadoDePagoInDTO.getTransactionBO().getTrnChannel());
		coreGetStateRBMPaymentInDTO.setClientDt(consultarEstadoDePagoInDTO.getClientDt());
		coreGetStateRBMPaymentInDTO.setIpAddr(consultarEstadoDePagoInDTO.getIpAddr());
		coreGetStateRBMPaymentInDTO.setRqUID(consultarEstadoDePagoInDTO.getRqUID());
		coreGetStateRBMPaymentInDTO.setTransactionBO(consultarEstadoDePagoInDTO.getTransactionBO());
		coreGetStateRBMPaymentInDTO.setIdTxRbm(consultarEstadoDePagoInDTO.getIdTxRbm());
		
		
		//Se consume el servicio de GlobalPay para Consultar la transaccion.
				
		CoreGetStateRBMPaymentOutDTO coreGetStateRBMPaymentOutDTO = rbmGlobalPayCtrlService.coreGetStateRBMPayment(coreGetStateRBMPaymentInDTO, CoreConstants.TIMEOUT_CREATETXINFORMATION);
		
		if ( coreGetStateRBMPaymentOutDTO.getServerStatusCode() != null &&
				(coreGetStateRBMPaymentOutDTO.getServerStatusCode().equals(EXITOSO_1) || coreGetStateRBMPaymentOutDTO.getServerStatusCode().equals(EXITOSO_2)) 
				) {
			
			Date date = null;
	        Date compensationDate = null;
	        
	        consultarEstadoDePagoOutDTO.setRqUID(coreGetStateRBMPaymentOutDTO.getRqUID());
	        consultarEstadoDePagoOutDTO.setReturnCode(coreGetStateRBMPaymentOutDTO.getEstadoTxConsultada());
	        consultarEstadoDePagoOutDTO.setStatusCode(coreGetStateRBMPaymentOutDTO.getStatusCode());
	        consultarEstadoDePagoOutDTO.setStatusDesc(coreGetStateRBMPaymentOutDTO.getStatusDesc());
	        
	        date = coreGetStateRBMPaymentOutDTO.getFechaTxRbm();
			
			//Transaccion aprobada en RBM
			if( coreGetStateRBMPaymentOutDTO.getTrnServerStatusDesc().equals(STATUS_DESC_APROBADA) 
				||	coreGetStateRBMPaymentOutDTO.getTrnServerStatusDesc().equals(STATUS_DESC_APROBADO)) {
				
				Brand brand = null;//franquicia
				try {					
					brand = pgwRbmPaymentServiceImpl.brandDAO.findByName(coreGetStateRBMPaymentOutDTO.getFranquicia());
				} catch (Exception e) {
					LOGGER.info("@PGWGlobalPayServiceImpl GetStateRBMPayment, no fue posible obtener la franquisia de la transacion. {}", e.getMessage());
				}
				
				transactionStatus = pgwRbmPaymentServiceImpl.transactionStatusDAO.findById(TransactionStatusEnum.CONFIRMED_OK.getCode());
				consultarEstadoDePagoOutDTO.setTrnStatus(TransactionStatusEnum.CONFIRMED_OK.getCode());
				compensationDate = calcCompensationDate(date);
				String approvalId = coreGetStateRBMPaymentOutDTO.getNumeroAprobacion();
				
				transaction.setStatus(transactionStatus);
				transaction.setApprovalNumber(approvalId);
				consultarEstadoDePagoOutDTO.setAprovalId(approvalId);
				
				if (null != brand ) {
					transaction.setIdBrand(new BigDecimal(brand.getId()));
					consultarEstadoDePagoOutDTO.setBrand(new BigDecimal(brand.getId()));
				}
				transaction.setPayDate(date);
				transaction.setCompensationDate(compensationDate);
				consultarEstadoDePagoOutDTO.setPayDate(date);
				consultarEstadoDePagoOutDTO.setCompensationDate(compensationDate);
				
				
				pgwRbmPaymentServiceImpl.transactionDAO.update(transaction);
				
				LOGGER.info("Se cierra la transaccion TARJETA DE CREDITO en flujo normal byTokenFinal con estado {} pmtId{}",
						transaction.getStatus().getDescription(), transaction.getPmtId());
				notificacion(transaction, TransactionStatusEnum.CONFIRMED_OK);
				
				
			} else if( coreGetStateRBMPaymentOutDTO.getTrnServerStatusDesc().equals(STATUS_DESC_INICIADA) || 
					coreGetStateRBMPaymentOutDTO.getTrnServerStatusDesc().equals(STATUS_DESC_PROCESANDO) ) {
				
				consultarEstadoDePagoOutDTO.setTxRBMState(coreGetStateRBMPaymentOutDTO.getTrnServerStatusDesc());
				consultarEstadoDePagoOutDTO.setTxState(TransactionStatusEnum.PROCESSING.getCode());
				consultarEstadoDePagoOutDTO.setTxState(BusinessStatusEnum.PENDIENTE.getCode());

			}

			return consultarEstadoDePagoOutDTO;

		} else if ( null != coreGetStateRBMPaymentOutDTO.getTrnServerStatusDesc() &&
				( coreGetStateRBMPaymentOutDTO.getTrnServerStatusDesc().equals(STATUS_DESC_RECHAZADA) ||
						coreGetStateRBMPaymentOutDTO.getTrnServerStatusDesc().equals(STATUS_DESC_RECHAZADO)	
					|| coreGetStateRBMPaymentOutDTO.getTrnServerStatusDesc().equals(STATUS_DESC_ERROR) )
			) {
			
			LOGGER.info("@PGWGlobalPayServiceImpl GetStateRBMPayment, transaccion rechazada. "
					+ "pmtid:{}, Error GlobalPay:{}, StatusCode:{}, StatusDesc:{}, ", 
					consultarEstadoDePagoInDTO.getTransactionBO().getPmtId(), coreGetStateRBMPaymentOutDTO.getServerStatusCode(), 
					coreGetStateRBMPaymentOutDTO.getStatusCode(), coreGetStateRBMPaymentOutDTO.getStatusDesc() );
			
			/// ************** RECHAZADA *************
			
			consultarEstadoDePagoOutDTO.setRqUID(coreGetStateRBMPaymentOutDTO.getRqUID());
			consultarEstadoDePagoOutDTO.setReturnCode(coreGetStateRBMPaymentOutDTO.getEstadoTxConsultada());
			consultarEstadoDePagoOutDTO.setStatusCode(coreGetStateRBMPaymentOutDTO.getStatusCode());
			consultarEstadoDePagoOutDTO.setStatusDesc(coreGetStateRBMPaymentOutDTO.getStatusDesc());
			
			transactionStatus = pgwRbmPaymentServiceImpl.transactionStatusDAO.findById(TransactionStatusEnum.CONFIRMED_NA.getCode());
			consultarEstadoDePagoOutDTO.setTrnStatus(TransactionStatusEnum.CONFIRMED_NA.getCode());
			transaction.setStatus(transactionStatus);
			
			pgwRbmPaymentServiceImpl.transactionDAO.update(transaction);
			
			LOGGER.info("Se cierra la transaccion TARJETA DE CREDITO en flujo normal byTokenFinal con estado {} pmtId{}",
					transaction.getStatus().getDescription(), transaction.getPmtId());
			
			notificacion(transaction, TransactionStatusEnum.CONFIRMED_NA);
			
			return consultarEstadoDePagoOutDTO;
			
		} else if ( coreGetStateRBMPaymentOutDTO.getServerStatusCode() != null && (
				coreGetStateRBMPaymentOutDTO.getServerStatusCode().equals(ERROR_9002) ||
				coreGetStateRBMPaymentOutDTO.getServerStatusCode().equals(ERROR_9003) ||
				coreGetStateRBMPaymentOutDTO.getServerStatusCode().equals(ERROR_9004) ||
				coreGetStateRBMPaymentOutDTO.getServerStatusCode().equals(ERROR_9006) ||
				coreGetStateRBMPaymentOutDTO.getServerStatusCode().equals(ERROR_9008) )
				) {
			
			LOGGER.info("@PGWGlobalPayServiceImpl GetStateRBMPayment. "
					+ "pmtid:{}, Error GlobalPay:{}, StatusCode:{}, StatusDesc:{}, ", 
					consultarEstadoDePagoInDTO.getTransactionBO().getPmtId(), coreGetStateRBMPaymentOutDTO.getServerStatusCode(), 
					coreGetStateRBMPaymentOutDTO.getStatusCode(), coreGetStateRBMPaymentOutDTO.getStatusDesc() );
			
			consultarEstadoDePagoOutDTO.setTxRBMState(coreGetStateRBMPaymentOutDTO.getTrnServerStatusDesc());
			consultarEstadoDePagoOutDTO.setTxState(TransactionStatusEnum.PROCESSING.getCode());
			consultarEstadoDePagoOutDTO.setTxState(BusinessStatusEnum.PENDIENTE.getCode());
						
			return consultarEstadoDePagoOutDTO;
			
		} else {
			LOGGER.error("@PGWGlobalPayServiceImpl GetStateRBMPayment pmtid:{}, Error de RBM no mapeado.",
					transaction.getPmtId());
			
			consultarEstadoDePagoOutDTO.setTxState(TransactionStatusEnum.PROCESSING.getCode());
			consultarEstadoDePagoOutDTO.setTxState(BusinessStatusEnum.PENDIENTE.getCode());

			return consultarEstadoDePagoOutDTO;
		}
 
	}
	
	@Override
	public void notificacion(Transaction transaction, TransactionStatusEnum txStatus) {
		
		// Leer Envio de Correo Electrónico
		Transaction txdata = pgwRbmPaymentServiceImpl.transactionDAO.read(transaction.getId());
		
		if (txdata.getEmailflag() == CoreConstants.FLAG_EMAIL_OFF) {
			try {
				transaction.setEmailflag(CoreConstants.FLAG_EMAIL_ON);
				pgwRbmPaymentServiceImpl.transactionDAO.update(transaction);
				
				// Conciliar la transacción
				reconciledTransactionService.createOrUpdate(transaction, null);
				
				// Enviar correo de confirmación			
				sendMailService.sendMail(transaction);
				
				/** INICIO-C12 */
				LOGGER.info("Enviando correo promocional pmtid:{}", transaction.getPmtId());
				sendMailService.sendPromoMail(transaction);
				/** FIN-C12 */
				
				if(!(transaction.getCustomerEmail().equals(transaction.getPayerMail())) 
						&& (transaction.getStatus().getCode() == txStatus.getCode())){
					
					String mail = transaction.getPayerMail();
					transaction.setPayerMail(transaction.getCustomerEmail());
					
					sendMailService.sendMail(transaction);
					/** INICIO-C12 */
					sendMailService.sendPromoMail(transaction);
					/** FIN-C12 */
					transaction.setPayerMail(mail);
				}
			}catch(Exception e) {
				e.printStackTrace();
			}finally {
				if (transaction.getNotificacionPPagos() == null || transaction.getNotificacionPPagos()==0) {
					if (updateInformation(transaction)) {
						transaction.setNotificacionPPagos(1);
						transactionDAO.update(transaction);	
						LOGGER.info("Se actualizo el estado de notificacion a portal de pagos: {}",transaction.getPmtId());
					}
				}
			}
		}
	}
	
	/**
	 * Se informa al Portal de Pagos el estado de la transaccion
	 */
	private boolean updateInformation(Transaction transaction) {

		boolean result=true;
		try {
			TransactionNotification transactionNotification =new TransactionNotification();

			transactionNotification.setBusinessCode(transaction.getStatus().getBusinessCode().getCode());
			transactionNotification.setBusinessCodeDesc(transaction.getStatus().getBusinessCode().getDescription().name());
			transactionNotification.setCommerceNuraCode(transaction.getCommerce().getNuraCode());
			transactionNotification.setPmtId(transaction.getPmtId());
			transactionNotification.setRquId(transaction.getRquId());
			transactionNotification.setTrnChannel(transaction.getTrnChannel());
			transactionNotification.setIpAddress(transaction.getIpAddress());
			transactionNotification.setCustomerDocId(transaction.getCustomerDocId());
			transactionNotification.setCustomerDocType(transaction.getCustomerDocType());
			transactionNotification.setAmt(transaction.getTotalValue());
			transactionNotification.setCurCode(transaction.getCurrency());				
			transactionNotification.setAgreementId(getAgrementId(transaction));
			transactionNotification.setName(transaction.getCommerce().getSubscription().getCompanyName());
			transactionNotification.setNit(transactionDAO.getAggregatorNit(transaction, nitAgregator, nitAgregatorAvVillas));
			transactionNotification.setPhone(transaction.getCommerce().getSubscription().getPhone());								
			transactionNotification.setFirstName(transaction.getCustomerName() != null ? transaction.getCustomerName() : "");
			transactionNotification.setMiddleName(transaction.getMiddleNameBuyer() != null ? transaction.getMiddleNameBuyer() : "");
			transactionNotification.setLastName(transaction.getLastNameBuyer() != null ? transaction.getLastNameBuyer() : "");
			transactionNotification.setSecondLastName(transaction.getSecondLastNameBuyer() != null ? transaction.getSecondLastNameBuyer() : "");				
			transactionNotification.setCustIdType(transaction.getPayerDocType() != null ? transaction.getPayerDocType() : "");
			transactionNotification.setCustIdNum(transaction.getPayerDocId() != null ? transaction.getPayerDocId() : "");
			transactionNotification.setAddress(transaction.getPayerAddress());
			transactionNotification.setEmailAddr(transaction.getPayerMail() != null ? transaction.getPayerMail() : "");
			transactionNotification.setPhone(transaction.getPayerPhone() != null ? transaction.getPayerPhone() : "");				
			transactionNotification.setRquId(transaction.getRquId());
			transactionNotification.setPmtId(transaction.getPmtId());
			transactionNotification.setTrnChannel(transaction.getTrnChannel());				
			transactionNotification.setStatusCode(transaction.getStatus().getCode());
			transactionNotification.setStatusDesc(transaction.getStatus().getDescription().toString());
			transactionNotification.setOrderId(transaction.getOrderNumber()); 
			transactionNotification.setOrderDesc(transaction.getDescription());				
			transactionNotification.setPmtWayId(String.valueOf(transaction.getPaymentWay().getId()));
			transactionNotification.setPmtWayType(transaction.getPaymentWay().getName());

			BankInfo bankInfo = new BankInfo();
			bankInfo.setBankId(transaction.getBank() == null ? null : transaction.getBank().getAvalCode());	
			transactionNotification.setBankInfo(bankInfo);
			transactionNotification.setEffDt(getDate(transaction));
			transactionNotification.setCompensationDate(transaction.getCompensationDate());
			transactionNotification.setApprovalId(PaymentWayCodes.PSE.equals(transaction.getPaymentWay().getId()) ? transaction.getTrazabilityCode()
					: transaction.getApprovalNumber());
			transactionNotification.setReferenceMap(getReferenceMap(transaction, true));
			transactionNotification.setIdOrigenTransaccion(transaction.getSource().getId().toString());
			String codNie = "";

			LOGGER.info("Validacion de tipo de pago PSE y pago de tarjeta de credito. tipo de pago: {}, token: {}", transaction.getPaymentWay().getId(), transaction.getTokenized());

			if(PaymentWayCodes.PSE.equals(transaction.getPaymentWay().getId()) && transaction.getTokenized()!=null ) {
				LOGGER.info("Validacion de tipo de pago PSE y pago de tarjeta de credito se encontro");
				codNie = transaction.getTokenized();
			}else {
				LOGGER.info("Validacion de tipo de pago PSE y pago de tarjeta de credito No se encontro");
			}
			transactionNotification.setCodNIE(codNie);			

			result=notificationPayments.notification(transactionNotification);	
		} catch (Exception e) {
			result=false;
			LOGGER.error("No fue posible consumir el servicio @NotificationPayments {}",
					e.getLocalizedMessage());
		}
		return result;
	}
	
	private String getAgrementId(Transaction transaction) {
		String nuraCode = transaction.getCommerce().getNuraCode();
		final boolean needHomologate = transaction.getBank() != null
				&& AVALBankEnum.AV_VILLAS.getAvalCode().equals(transaction.getBank().getAvalCode())
				&& transaction.getCommerce().getHomologationBAVVCode() != null;
		if (needHomologate) {
			return transaction.getCommerce().getHomologationBAVVCode();
		}

		if (nuraCode.startsWith("CPV")) {
			nuraCode = nuraCode.substring(3, nuraCode.length());
		}

		return nuraCode;
	}
	
	private Date getDate(Transaction transaction) {
		if (transaction.getPayDate() != null) {
			return transaction.getPayDate();
		}
		return transaction.getTransactionDate();
	}
	
	/**
	 * Obtiene las referencias de la transaccion y las retorna en una lista de
	 * string.
	 * 
	 * @param tx
	 *            Transaccion a procesar
	 * @return Lista con las referencias encontradas o lista vacia si no hay
	 *         ninguna.
	 */
	private Map<String, String> getReferenceMap(Transaction transaction, boolean fillPaymetWay) {
		Map<String, String> refMap = new HashMap<String, String>();
		if (transaction == null) {
			return refMap;
		}
		if (fillPaymetWay) {
			// Validar el medio de pago para incluir informacion adicional
			if (transaction.getPaymentWay() != null) {
				if ((PaymentWayCodes.PAGOS_AVAL.equals(transaction.getPaymentWay().getId())
						|| PaymentWayCodes.PSE.equals(transaction.getPaymentWay().getId())) && transaction.getBank() != null) {
					refMap.put("BankId", transaction.getBank().getAvalCode());
					refMap.put("BankName", transaction.getBank().getName());
				}

				if ( PaymentWayCodes.TC.equals(transaction.getPaymentWay().getId()) 
						&& transaction.getIdBrand() != null) {

					Brand brand = brandDAO.read(Long.valueOf(transaction.getIdBrand().toString()));
					refMap.put("Brand", brand.getName());

					if ( transaction.isGlobalPay() != null && transaction.isGlobalPay() ) {
						refMap.put("CardEmbossNum", transaction.getCreditCardNumber());
					}

				}		

				TransactionStatus transactionStatus = transactionStatusDAO.findById(TransactionStatusEnum.REFUSED.getCode());
				if (PaymentWayCodes.PSE.equals(transaction.getPaymentWay().getId()) && transaction.getStatus()!=transactionStatus) {
					refMap.put("TrnCycle", transaction.getTrnCycle());
					refMap.put("AchBankCode", transaction.getBank().getAchCode());
				}
			}
		}

		if (transaction.getReference1() != null && !transaction.getReference1().trim().isEmpty()) {
			refMap.put("Reference1", transaction.getReference1());
		}
		if (transaction.getReference2() != null && !transaction.getReference2().trim().isEmpty()) {
			refMap.put("Reference2", transaction.getReference2());
		}
		if (transaction.getReference3() != null && !transaction.getReference3().trim().isEmpty()) {
			refMap.put("Reference3", transaction.getReference3());
		}

		// Ventanilla de Pagos
		if (transaction.getPlantilla() == CoreConstants.TAQUILLA_ON) {
			refMap.put("Template", CoreConstants.TAQUILLA_ON.toString());
			refMap.put("Theme", transaction.getTaquilla().getIdTaquilla().toString());
			refMap.put("LogoURL", new String(transaction.getUrlLogo()));
		} else if (transaction.getPlantilla() == CoreConstants.TAQUILLA_OFF) {
			refMap.put("Template", CoreConstants.TAQUILLA_OFF.toString());
		}

		return refMap;
	}
	
	

	private Date calcCompensationDate(Date current) {
		calendar.setTime(current);
		Date date = current;
		if ((!isBusinessDay(current)) || ((calendar.get(Calendar.HOUR_OF_DAY)>hourCompensation) ||
				((calendar.get(Calendar.HOUR_OF_DAY)==hourCompensation) && (calendar.get(Calendar.MINUTE)>minutesCompensation)))){
			//Verifica el proximo dia habil
			date = nextBusinessDay(current);
		}
		return date;
	}
	
	public boolean isBusinessDay(Date date) {
		calendar.setTime(date);
		int dayOfWeek = calendar.get(Calendar.DAY_OF_WEEK);
		
		//Valida que el día no sea sábado o Domingo
		if (dayOfWeek == 1 || dayOfWeek == 7) {
			return false;
		}
		
		List<NonWorkingDay> nonWorkingDays = nonWorkingDayDAO.findByDay(getIntDate(date));
		NonWorkingDay day = new NonWorkingDay();
		day.setId(getIntDate(date));
		if (nonWorkingDays.contains(day)) {
			return false;
		}
		return true;
	}
	
	/**
	 * Retorna la fecha de la fecha dada en tipo entero en el formato YYYYMMDD
	 * @param date Fecha deseada
	 * @return Fecha en tipo int
	 */
	protected int getIntDate(Date date){
		int intDate = calendar.get(Calendar.YEAR);
		intDate = intDate * 100 + calendar.get(Calendar.MONTH) + 1;
		intDate = intDate * 100 + calendar.get(Calendar.DAY_OF_MONTH);
		return intDate;
	}
	
	public Date lastBusinessDay(Date date) {
		Date previousDate = previousDay(date);
		if (isBusinessDay(previousDate)) {
			return previousDate;
		}
		return lastBusinessDay(previousDate);
	}
	
	public Date nextBusinessDay(Date date) {
		Date nextDate = nextDay(date);
		if (isBusinessDay(nextDate)) {
			return nextDate;
		}
		return nextBusinessDay(nextDate);
	}
	
	public Date previousDay(Date date) {
		calendar.setTime(date);
		calendar.add(Calendar.DATE, -1);
		return calendar.getTime();
	}

	public Date nextDay(Date date) {
		calendar.setTime(date);
		calendar.add(Calendar.DATE, 1);
		return calendar.getTime();
	}
}
