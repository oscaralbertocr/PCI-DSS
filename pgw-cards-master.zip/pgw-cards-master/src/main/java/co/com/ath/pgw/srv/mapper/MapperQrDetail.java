package co.com.ath.pgw.srv.mapper;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import co.com.ath.pgw.bsn.dto.in.QrDetailInDTO;
import co.com.ath.pgw.rest.request.dto.StatusFinallyQRRequest;
import co.com.ath.pgw.util.exception.CustomException;

public class MapperQrDetail {
	
	private static final Logger LOGGER = LoggerFactory.getLogger(MapperQrDetail.class);
	
	public QrDetailInDTO mapRequestToInDTO(StatusFinallyQRRequest request) throws CustomException {
	
		QrDetailInDTO dto = new QrDetailInDTO();
		
		try {
			dto.setPmtid(new Long(request.getPmtStatus().getPmtAuthId()));
			
		}catch (Exception e) {
			LOGGER.error("Error mapeando informacion de entrada del @getStatusFinallyTX {}", e);
		}
		return dto;	
	 }
	
	}
