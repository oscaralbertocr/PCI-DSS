package co.com.ath.pgw.bsn.service.impl;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;

import javax.annotation.Resource;
import javax.persistence.NoResultException;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;


import co.com.ath.pgw.bsn.dto.in.AddRBMPaymentInDTO;
import co.com.ath.pgw.bsn.dto.in.ModRevRBMPaymentInDTO;
import co.com.ath.pgw.bsn.dto.out.AddRBMPaymentOutDTO;
import co.com.ath.pgw.bsn.dto.out.ModRevRBMPaymentOutDTO;
import co.com.ath.pgw.bsn.model.bo.TransactionBO;
import co.com.ath.pgw.bsn.service.PGWRbmPaymentService;
import co.com.ath.pgw.persistence.dao.BlackListDAO;
import co.com.ath.pgw.persistence.dao.BlackListIpDAO;
import co.com.ath.pgw.persistence.dao.BrandDAO;
import co.com.ath.pgw.persistence.dao.CommerceDAO;
import co.com.ath.pgw.persistence.dao.PaymentWayDAO;
import co.com.ath.pgw.persistence.dao.ResponseCodeDAO;
import co.com.ath.pgw.persistence.dao.TopDAO;
import co.com.ath.pgw.persistence.dao.TransactionDAO;
import co.com.ath.pgw.persistence.dao.TransactionStatusDAO;
import co.com.ath.pgw.persistence.model.BlackList;
import co.com.ath.pgw.persistence.model.BlackListIp;
import co.com.ath.pgw.persistence.model.Brand;
import co.com.ath.pgw.persistence.model.Commerce;
import co.com.ath.pgw.persistence.model.PaymentWay;
import co.com.ath.pgw.persistence.model.ResponseCode;
import co.com.ath.pgw.persistence.model.Top;
import co.com.ath.pgw.persistence.model.Transaction;
import co.com.ath.pgw.persistence.model.TransactionStatus;
import co.com.ath.pgw.persistence.service.ReconciledTransactionService;
import co.com.ath.pgw.persistence.service.SendMailService;
import co.com.ath.pgw.util.Parametro;
import co.com.ath.pgw.util.constants.CoreConstants;
import co.com.ath.pgw.util.constants.PaymentWayCodes;
import co.com.ath.pgw.util.enums.BusinessStatusEnum;
import co.com.ath.pgw.util.enums.ResponseCodeEnum;
import co.com.ath.pgw.util.enums.TransactionStatusEnum;
import co.com.ath.pgw.util.i18n.BundleKeys;
import co.com.ath.pgw.util.i18n.BundleType;
import co.com.ath.pgw.util.i18n.ResourceBundleManager;
import co.com.ath.pgw.util.mask.MaskData;
import co.com.ath.pgw.util.tripledes.AesCifer;
import co.com.ath.pgw.util.validation.ValidationException;
import co.com.ath.pgw.util.validation.model.AddRBMPaymentValidator;
import co.com.ath.pgw.ws.client.payments.GatewayPaymentAdmCtrlService;
import co.com.ath.pgw.ws.client.payments.GatewayPaymentClientCtrlService;

/**
* Implementación por defecto del Servicio de pagos por RBM
* 
* @author sophosSolutions
* @version 1.0 22/07/2019
**/

/*
* <strong>Autor</strong>Edwin Alexander Bohorquez</br>
* <strong>Descripcion</strong>Motor de riesgo</br>
* <strong>Número de Cambios</strong>3</br>
* <strong>Identificador corto</strong>C10</br>
* 
* <strong>Autor</strong>Edwin Alexander Bohorquez</br>
* <strong>Descripcion</strong>Desagregacion de Motor de riesgo</br>
* <strong>Número de Cambios</strong>1</br>
* <strong>Identificador corto</strong>C11</br>
* 
*/

@Service
public class PGWRbmPaymentServiceImpl implements PGWRbmPaymentService{

	static Logger LOGGER = LoggerFactory.getLogger(PGWRbmPaymentServiceImpl.class);
	
	@Resource
	public TransactionStatusDAO transactionStatusDAO;
	
	@Resource
    private AddRBMPaymentValidator addRBMPaymentValidator;
	
	@Resource
	public BrandDAO brandDAO;
	
	@Resource
	public TransactionDAO transactionDAO;
	
	@Resource
	public MaskData maskData;
	
	@Resource
	public PaymentWayDAO paymentWayDAO;
	
	@Resource
	private TopDAO topesDAO;
	
	@Resource
	public ResponseCodeDAO responseCodeDAO; 
	
	@Resource
	public BlackListDAO blackListDAO;  
    
    @Resource
	public BlackListIpDAO blackListIpDAO;
	
    @Resource
	public CommerceDAO commerceDAO;
    
    /** información de localización */
    public Locale locale;
    
    @Resource
	private ResourceBundleManager resourceBundleManager;
    
    @Resource
	private SendMailService sendMailService; 
    
    @Resource
	public ReconciledTransactionService reconciledTransactionService;
    
    /** INI - C10 **/
    /*	
	@Resource
	private AdaptiveAuthenticationService adaptiveAuthenticationService;
	*/
    /** FIN - C10 **/
    
    @Resource
    private GatewayPaymentAdmCtrlService gatewayPaymentAdmCtrlService;
    
    @Resource
    private GatewayPaymentClientCtrlService gatewayPaymentClientCtrlService;
   
    @Autowired 
	private AesCifer tripleDes;
    
    public PGWRbmPaymentServiceImpl(){
    	this.locale = Locale.getDefault();    	
    }
    
	@Override
	public AddRBMPaymentOutDTO addRBMPayment(AddRBMPaymentInDTO addRBMPaymentInDTO) throws Exception {
		TransactionStatus transactionStatus = transactionStatusDAO.findById(TransactionStatusEnum.CONFIRMED_NA.getCode());
        Date date = null;
        Date compensationDate = null;
        String approvalId = null;
        AddRBMPaymentOutDTO addRBMPaymentOutDTO = new AddRBMPaymentOutDTO();
        addRBMPaymentOutDTO.setRqUID(addRBMPaymentInDTO.getRqUID());
        
        // Validar la información de entrada
		try {
			addRBMPaymentValidator.validate(addRBMPaymentInDTO);
		} catch (ValidationException ex) {
			addRBMPaymentOutDTO.setStatusCode(CoreConstants.ERROR_DATA_VALIDATION_CODE);
			addRBMPaymentOutDTO.setStatusDesc(ex.getMessage());
			addRBMPaymentOutDTO.setTrnServerStatusCode(String.valueOf(ex.getErrorCode()));
			if (ex.getCause() != null) {
				addRBMPaymentOutDTO.setTrnServerStatusDesc(ex.getCause().getMessage());
			} else {
				addRBMPaymentOutDTO.setTrnServerStatusDesc(ex.getMessage());
			}
			return addRBMPaymentOutDTO;
		}
		
		Brand brand = brandDAO.read(Long.valueOf(addRBMPaymentInDTO.getTransactionBO().getCreditCard().getBrand().getId()));
		addRBMPaymentInDTO.getTransactionBO().getCreditCard().getBrand().setName(brand.getName());
		
		// Obtener la transacción
		Transaction transaction = transactionDAO.findByPmtId(Long.valueOf(addRBMPaymentInDTO.getTransactionBO().getPmtId()));
		
		try{
			
			if(addRBMPaymentInDTO.getTransactionBO().getCreditCard().getBrand().getId() != null 
					&& !addRBMPaymentInDTO.getTransactionBO().getCreditCard().getBrand().getId().isEmpty()) {
				transaction.setIdBrand(BigDecimal.valueOf(Long.parseLong(addRBMPaymentInDTO.getTransactionBO().getCreditCard().getBrand().getId())));
			}
			
			if(addRBMPaymentInDTO.getTransactionBO().getCreditCard().getNumber() != null 
					&& !addRBMPaymentInDTO.getTransactionBO().getCreditCard().getNumber().isEmpty()) {
				transaction.setCreditCardNumber(maskData.getMaskData(addRBMPaymentInDTO.getTransactionBO().getCreditCard().getNumber()));
			}
			
			 /*INICIO-C09**/				
			//VALIDACIÓN DOBLE CLICK PAGOS TC
			if(transaction.getPaymentWay().getId().equals(PaymentWayCodes.TC)){
				LOGGER.info("...ERROR DOBLE CLICK BOTON PAGAR TC");
				addRBMPaymentOutDTO.setStatusCode(CoreConstants.ERROR_STATUS_CODE_300);
				addRBMPaymentOutDTO.setStatusDesc(CoreConstants.ERROR_STATUS_PROCESING_TC);
				addRBMPaymentOutDTO.setTrnStatusCode(Long.valueOf(CoreConstants.ERROR_STATUS_CODE_300));
				addRBMPaymentOutDTO.setTrnStatusDesc(CoreConstants.ERROR_STATUS_PROCESING_TC);
				addRBMPaymentOutDTO.setTrnServerStatusCode(null); 
				addRBMPaymentOutDTO.setTrnServerStatusDesc(null); 
				addRBMPaymentOutDTO.setEffDt(transaction.getPayDate());
				addRBMPaymentOutDTO.setCompensationDate(transaction.getCompensationDate());
				addRBMPaymentOutDTO.setApprovalId(transaction.getApprovalNumber());
		        return addRBMPaymentOutDTO;
			}
			/*FIN-C09**/
			
			transaction.setPaymentWay(paymentWayDAO.read(PaymentWayCodes.TC));
			transaction.setBankCollecter(transaction.getCommerce().getSubscription().getBank());
			if (addRBMPaymentInDTO.getTransactionBO().getTermsNConditions() != null
					&& !addRBMPaymentInDTO.getTransactionBO().getTermsNConditions().isEmpty()) {
				transaction.setTermsAndConditions(Boolean.parseBoolean(addRBMPaymentInDTO.getTransactionBO().getTermsNConditions()));
			}
			
			//validacion de Topes
			if(!validateTopByCommerceAndPaymentWay(transaction, paymentWayDAO.read(PaymentWayCodes.TC))){
				
				//Si no pasa la validacion de Topes
				setTopesError(addRBMPaymentOutDTO, transaction);
				
			} else {
				transaction.setIpAddress(addRBMPaymentInDTO.getTransactionBO().getIpAddress());
				transaction.setResponseCode(null);
				//Cambio Nombre Duplicado INI
				
				if (addRBMPaymentInDTO.getTransactionBO().getCustomerName() != null && !addRBMPaymentInDTO.getTransactionBO().getCustomerName().isEmpty() && !addRBMPaymentInDTO.getTransactionBO().getCustomerName().equals("GUEST"))					
				{
					transaction.setPayerName(addRBMPaymentInDTO.getTransactionBO().getFirstNamePayer());
					transaction.setMiddleNamePayer("");
					transaction.setLastNamePayer("");
					transaction.setSecondLastNamePayer("");
				}
				//Cambio Nombre Duplicado FIN
							
				/**INICIO-C01**/
				transaction.setBankCollecter(transaction.getCommerce().getSubscription().getBank());  
				/**FIN-C01**/
						
		        //información del comprador
				if (addRBMPaymentInDTO.getTransactionBO().getCustomerName() != null
						&& !addRBMPaymentInDTO.getTransactionBO().getCustomerName().isEmpty()) {
					transaction.setCustomerName(addRBMPaymentInDTO.getTransactionBO().getCustomerName());
				}
		
				if (addRBMPaymentInDTO.getTransactionBO().getMiddleNameBuyer() != null
						&& !addRBMPaymentInDTO.getTransactionBO().getMiddleNameBuyer().isEmpty()) {
					transaction.setMiddleNameBuyer(addRBMPaymentInDTO.getTransactionBO().getMiddleNameBuyer());
				}
				
				if (addRBMPaymentInDTO.getTransactionBO().getLastNameBuyer() != null
						&& !addRBMPaymentInDTO.getTransactionBO().getLastNameBuyer().isEmpty()) {
					transaction.setLastNameBuyer(addRBMPaymentInDTO.getTransactionBO().getLastNameBuyer());
				}
				
				if (addRBMPaymentInDTO.getTransactionBO().getSecondLastNameBuyer() != null
						&& !addRBMPaymentInDTO.getTransactionBO().getSecondLastNameBuyer().isEmpty()) {
					transaction.setSecondLastNameBuyer(addRBMPaymentInDTO.getTransactionBO().getSecondLastNameBuyer());
				}
		
				if (addRBMPaymentInDTO.getTransactionBO().getCustomerEmail() != null
						&& !addRBMPaymentInDTO.getTransactionBO().getCustomerEmail().isEmpty()) {
					transaction.setCustomerEmail(addRBMPaymentInDTO.getTransactionBO().getCustomerEmail());
				}
		
				if (addRBMPaymentInDTO.getTransactionBO().getCustomerMobileNumber() != null
						&& !addRBMPaymentInDTO.getTransactionBO().getCustomerMobileNumber().isEmpty()) {
					transaction.setCustomerMobileNumber(addRBMPaymentInDTO.getTransactionBO().getCustomerMobileNumber());
				}
		
				//información del pagador
				if(addRBMPaymentInDTO.getTransactionBO().getPayerCompany() != null
						&& !addRBMPaymentInDTO.getTransactionBO().getPayerCompany().isEmpty()){
					transaction.setPayerCompany(addRBMPaymentInDTO.getTransactionBO().getPayerCompany());
				}
		
				if(addRBMPaymentInDTO.getTransactionBO().getFirstNamePayer() != null
						&& !addRBMPaymentInDTO.getTransactionBO().getFirstNamePayer().isEmpty()){
					transaction.setPayerName(addRBMPaymentInDTO.getTransactionBO().getFirstNamePayer());
				}
		
				if(addRBMPaymentInDTO.getTransactionBO().getMiddleNamePayer() != null
						&& !addRBMPaymentInDTO.getTransactionBO().getMiddleNamePayer().isEmpty()){
					transaction.setMiddleNamePayer(addRBMPaymentInDTO.getTransactionBO().getMiddleNamePayer());
				}
		
				if(addRBMPaymentInDTO.getTransactionBO().getLastNamePayer() != null
						&& !addRBMPaymentInDTO.getTransactionBO().getLastNamePayer().isEmpty()) {
					transaction.setLastNamePayer(addRBMPaymentInDTO.getTransactionBO().getLastNamePayer());
				}
		
				if(addRBMPaymentInDTO.getTransactionBO().getSecondLastNamePayer() != null
						&& !addRBMPaymentInDTO.getTransactionBO().getSecondLastNamePayer().isEmpty()) {
					transaction.setSecondLastNamePayer(addRBMPaymentInDTO.getTransactionBO().getSecondLastNamePayer());
				}
		
				if(addRBMPaymentInDTO.getTransactionBO().getPayerNickName() != null 
						&& !addRBMPaymentInDTO.getTransactionBO().getPayerNickName().isEmpty()) {
					transaction.setPayerNickName(addRBMPaymentInDTO.getTransactionBO().getPayerNickName());
				}
		
				if(addRBMPaymentInDTO.getTransactionBO().getPayerDocType() != null 
						&& !addRBMPaymentInDTO.getTransactionBO().getPayerDocType().isEmpty()) {
					transaction.setPayerDocType(addRBMPaymentInDTO.getTransactionBO().getPayerDocType());
				}
				
				if(addRBMPaymentInDTO.getTransactionBO().getPayerDocId() != null 
						&& !addRBMPaymentInDTO.getTransactionBO().getPayerDocId().isEmpty()) {
					transaction.setPayerDocId(addRBMPaymentInDTO.getTransactionBO().getPayerDocId());
				}
				
				if(addRBMPaymentInDTO.getTransactionBO().getPayerGender() != null 
						&& !addRBMPaymentInDTO.getTransactionBO().getPayerGender().isEmpty()) {
					transaction.setPayerGender(addRBMPaymentInDTO.getTransactionBO().getPayerGender());
				}
				
				if(addRBMPaymentInDTO.getTransactionBO().getPayerBirthDate() != null 
						&& addRBMPaymentInDTO.getTransactionBO().getPayerBirthDate().toString() != "") {
					transaction.setPayerBirthDate(addRBMPaymentInDTO.getTransactionBO().getPayerBirthDate());
				}
				
				if(addRBMPaymentInDTO.getTransactionBO().getPayerCity() != null 
						&& !addRBMPaymentInDTO.getTransactionBO().getPayerCity().isEmpty()) {
					transaction.setPayerCity(addRBMPaymentInDTO.getTransactionBO().getPayerCity());
				}
				
				if(addRBMPaymentInDTO.getTransactionBO().getPayerDepartment() != null 
						&& !addRBMPaymentInDTO.getTransactionBO().getPayerDepartment().isEmpty()) {
					transaction.setPayerDepartment(addRBMPaymentInDTO.getTransactionBO().getPayerDepartment());
				}
				
				if(addRBMPaymentInDTO.getTransactionBO().getPayerCountry() != null 
						&& !addRBMPaymentInDTO.getTransactionBO().getPayerCountry().isEmpty()) {
					transaction.setPayerCounty(addRBMPaymentInDTO.getTransactionBO().getPayerCountry());
				}
				
				if(addRBMPaymentInDTO.getTransactionBO().getPayerAddress() != null
						&& !addRBMPaymentInDTO.getTransactionBO().getPayerAddress().isEmpty()) { 
					transaction.setPayerAddress(addRBMPaymentInDTO.getTransactionBO().getPayerAddress());
				}
				
				if(addRBMPaymentInDTO.getTransactionBO().getPayerMail() != null 
						&& !addRBMPaymentInDTO.getTransactionBO().getPayerMail().isEmpty()) {
					transaction.setPayerMail(addRBMPaymentInDTO.getTransactionBO().getPayerMail());
				}
				
				if(addRBMPaymentInDTO.getTransactionBO().getPayerPhone() != null 
						&& !addRBMPaymentInDTO.getTransactionBO().getPayerPhone().isEmpty()) {
					transaction.setPayerPhone(addRBMPaymentInDTO.getTransactionBO().getPayerPhone());
				}
				
				if(addRBMPaymentInDTO.getTransactionBO().getCreditCard().getBrand().getId() != null 
						&& !addRBMPaymentInDTO.getTransactionBO().getCreditCard().getBrand().getId().isEmpty()) {
					transaction.setIdBrand(BigDecimal.valueOf(Long.parseLong(addRBMPaymentInDTO.getTransactionBO().getCreditCard().getBrand().getId())));
				}
				
				if(addRBMPaymentInDTO.getTransactionBO().getCreditCard().getNumber() != null 
						&& !addRBMPaymentInDTO.getTransactionBO().getCreditCard().getNumber().isEmpty()) {
					//tx.setCreditCardNumber("************" + inDTO.getTransactionBO().getCreditCard().getNumber().substring(inDTO.getTransactionBO().getCreditCard().getNumber().length()-4, inDTO.getTransactionBO().getCreditCard().getNumber().length()));
					transaction.setCreditCardNumber(maskData.getMaskData(addRBMPaymentInDTO.getTransactionBO().getCreditCard().getNumber()));
					
				}
		
				transaction.setPaymentWay(paymentWayDAO.read(PaymentWayCodes.TC));
				transaction.setStatus(transactionStatus);
				transaction.setCustomerDocType(addRBMPaymentInDTO.getTransactionBO().getCustomerDocType());
		        transaction.setCustomerDocId(addRBMPaymentInDTO.getTransactionBO().getCustomerDocId());

		        if (addRBMPaymentInDTO.getTransactionBO().getCustomerName() != null
						&& !addRBMPaymentInDTO.getTransactionBO().getCustomerName().isEmpty()) {
		        	transaction.setCustomerName(addRBMPaymentInDTO.getTransactionBO().getCustomerName());
				}
		
				if (addRBMPaymentInDTO.getTransactionBO().getCustomerEmail() != null
						&& !addRBMPaymentInDTO.getTransactionBO().getCustomerEmail().isEmpty()) {
					transaction.setCustomerEmail(addRBMPaymentInDTO.getTransactionBO().getCustomerEmail());
				}
		
				if (addRBMPaymentInDTO.getTransactionBO().getCustomerMobileNumber() != null
						&& !addRBMPaymentInDTO.getTransactionBO().getCustomerMobileNumber()
								.isEmpty()) {
					transaction.setCustomerMobileNumber(addRBMPaymentInDTO.getTransactionBO()
							.getCustomerMobileNumber());
				}

				List<BlackList> blackListBuyer = new ArrayList<BlackList>();
				List<BlackList> blackListPayer = new ArrayList<BlackList>();
				List<BlackListIp> blackListIp = new ArrayList<BlackListIp>();
		
				// Se recorta a los primeros 6 digitos 
				addRBMPaymentInDTO.setRqUID(convertRqId(addRBMPaymentInDTO.getRqUID()));
		
				// Se almacena el rquId
				transaction.setRquId(addRBMPaymentInDTO.getRqUID().toString());
		
				//Actualiza la informacion de la transaccion inicialmente  
				transactionDAO.update(transaction);
		
				//Validacion de listas negras
				blackListBuyer = blackListDAO.findByDocument(addRBMPaymentInDTO.getTransactionBO().getCustomerDocType(), addRBMPaymentInDTO.getTransactionBO().getCustomerDocId());
				blackListPayer = blackListDAO.findByDocument(transaction.getPayerDocType(), transaction.getPayerDocId());
				blackListIp = blackListIpDAO.findByIp(addRBMPaymentInDTO.getTransactionBO().getIpAddress());
		
				//Si la Transaccion aplica como Listas Negras
				if(blackListBuyer.size() > 0 || blackListPayer.size() > 0 || blackListIp.size() > 0) {
					
					//Flujo de Listas Negras para RBM
					addRBMPaymentOutDTO = rbmBlackListFlow(addRBMPaymentOutDTO, transaction, blackListIp.size());
					
				}
				
				/** INI - C10 **/
				/* 				  				 
				else {
			
					// Realiza consulta Analyze a RSA
					//AnalyzeResponse analyzeRsaOutDTO = null;
					try {
						analyzeRsaOutDTO = adaptiveAuthenticationService.analyze(inDTO.getTransactionBO(), RunRiskType.RISK_ONLY);
					} catch (Exception ex) {
						LOGGER.error("@PGWPaymentServiceImpl addRBMPayment Ocurrio un error en Motor de Riesgo. {}",ex.getLocalizedMessage());
		
						// Garantiza que la transaccion continue
						analyzeRsaOutDTO = adaptiveAuthenticationService.getAnalyzeDummy();
					}
		
					UserStatus userStatus = analyzeRsaOutDTO.getIdentificationData().getUserStatus();
					TriggeredRule triggeredRule = analyzeRsaOutDTO.getRiskResult().getTriggeredRule();

					if ( triggeredRule.getActionCode().getValue().equals(ActionCode.DENY.getValue()) ) {
		
						LOGGER.info("@PGWPaymentServiceImpl addRBMPayment pmtid: {} "
								+ "Motor de Riesgo retorno ActionCode {}. Se rechaza como lista negra.", tx.getPmtId(), ActionCode.DENY);
						
						try {
							analyzeRsaOutDTO = adaptiveAuthenticationService.analyze(inDTO.getTransactionBO(), RunRiskType.ALL);
						} catch (Exception e) {
							LOGGER.error("@PGWPaymentServiceImpl addRBMPayment Ocurrio un error en Motor de Riesgo. {}", e.getLocalizedMessage());
						}
		
						//Flujo de Listas Negras para RBM
						outDTO = rbmBlackListFlow(outDTO, tx, blackListIp.size());
		
					} else if (userStatus == UserStatus.NOTENROLLED || userStatus == UserStatus.VERIFIED) {

						if (userStatus == UserStatus.NOTENROLLED) {
		
							CreateUserResponse cur;
							try {
								cur = adaptiveAuthenticationService.createUser(inDTO.getTransactionBO());
							} catch (Exception e) {
								LOGGER.error("@PGWPaymentServiceImpl addRBMPayment Ocurrio un error en Motor de Riesgo. {}", e.getLocalizedMessage());
		
								// Garantiza que la transaccion continue
								cur = adaptiveAuthenticationService.getCreateUserDummy();
							}
		
							userStatus = cur.getIdentificationData().getUserStatus();
							triggeredRule = cur.getRiskResult().getTriggeredRule();
						}

				
						if ( triggeredRule.getActionCode().getValue().equals(ActionCode.DENY.getValue()) ) {
		
							LOGGER.info("@PGWPaymentServiceImpl addRBMPayment pmtid: {} "
									+ "Motor de Riesgo retorno ActionCode {}. Se rechaza como lista negra.", tx.getPmtId(), ActionCode.DENY);
							
							try {
								analyzeRsaOutDTO = adaptiveAuthenticationService.analyze(inDTO.getTransactionBO(),RunRiskType.ALL);
							} catch (Exception e) {
								LOGGER.error("@PGWPaymentServiceImpl addRBMPayment Ocurrio un error en Motor de Riesgo. {}",e.getLocalizedMessage());
							}
		
							//Flujo de Listas Negras para RBM
							outDTO = rbmBlackListFlow(outDTO, tx, blackListIp.size());
		
						} else if (userStatus.equals(UserStatus.VERIFIED)) {

							// Consumir el servicio de pago RBM
							AddRBMPaymentOutDTO outRBM = initRBMTransaction(inDTO);
							// outRBM.setStatusCode(300);
		
							//retorna error de longitud de numero de documento de identidad
							if (outRBM.getStatusCode() == Long.parseLong(Integer.toString(CoreConstants.INVALID_LENGTH_INFORMATION))) {
								transactionStatus = transactionStatusDAO.findById(TransactionStatusEnum.CANCELLED.getCode());
								tx.setStatus(transactionStatus);
								outDTO.setStatusCode(CoreConstants.INVALID_LENGTH_INFORMATION);
								outDTO.setStatusDesc(getMessage(BundleKeys.TRANSACTION_SUCCESS, null, locale));
								outDTO.setTrnStatusCode(Long.valueOf(CoreConstants.INVALID_LENGTH_INFORMATION));
								outDTO.setTrnStatusDesc(CoreConstants.INVALID_LENGTH_INFORMATION_DES);
							}
		
							// retorna error de cálculo del impuesto
							if (outRBM.getStatusCode() == Long.parseLong(Integer.toString(CoreConstants.INVALID_TAX_AMOUNT))) {
								transactionStatus = transactionStatusDAO.findById(TransactionStatusEnum.CANCELLED.getCode());
								tx.setStatus(transactionStatus);
								outDTO.setStatusCode(CoreConstants.INVALID_TAX_AMOUNT);
								outDTO.setStatusDesc(getMessage(BundleKeys.TRANSACTION_SUCCESS, null, locale));
								outDTO.setTrnStatusCode(Long.valueOf(CoreConstants.INVALID_TAX_AMOUNT));
								outDTO.setTrnStatusDesc(CoreConstants.INVALID_TAX_AMOUNT_DESC);
							}
		
						
							// retorna errores
							// INI C07 
							if (outRBM.getStatusCode() == Long.parseLong(Integer.toString(CoreConstants.ERROR_STATUS_CODE_1260)) 
									|| outRBM.getStatusCode().equals((CoreConstants.ERROR_STATUS_CODE_100))
									|| outRBM.getStatusCode().equals((CoreConstants.ERROR_STATUS_CODE_400))) {
								
								transactionStatus = transactionStatusDAO.findById(TransactionStatusEnum.CONFIRMED_NA.getCode());
								tx.setStatus(transactionStatus);
								outDTO.setStatusCode(outRBM.getStatusCode());
								outDTO.setStatusDesc(outRBM.getStatusDesc());
								outDTO.setTrnStatusCode(Long.parseLong(outRBM.getTrnServerStatusCode()));
								outDTO.setTrnStatusDesc(outRBM.getTrnServerStatusDesc());
							}
							// FIN C07 
							if (outRBM.getStatusCode().equals(CoreConstants.SUCCESS_STATUS_CODE)) {
								// EL bus hace homologación retornando estados de negocio.
		
								if (outRBM.getTrnStatusCode().equals(BusinessStatusEnum.APROBADA.getCode())) {
		
									transactionStatus = transactionStatusDAO.findById(TransactionStatusEnum.CONFIRMED_OK.getCode());
									tx.setStatus(transactionStatus);
									outDTO.setStatusCode(CoreConstants.SUCCESS_STATUS_CODE);
									outDTO.setStatusDesc(getMessage(BundleKeys.TRANSACTION_SUCCESS, null,locale));
									outDTO.setTrnStatusCode(transactionStatus.getBusinessCode().getCode());
									outDTO.setTrnStatusDesc(getMessage(transactionStatus.getBusinessCode().getDescription().getMessageCode(),null, locale));
								} else {
									transactionStatus = transactionStatusDAO.findById(TransactionStatusEnum.CONFIRMED_NA.getCode());
									tx.setStatus(transactionStatus);
									outDTO.setStatusCode(CoreConstants.SUCCESS_STATUS_CODE);
									outDTO.setStatusDesc(getMessage(BundleKeys.TRANSACTION_SUCCESS, null,locale));
									outDTO.setTrnStatusCode(transactionStatus.getBusinessCode().getCode());
									outDTO.setTrnStatusDesc(getMessage(transactionStatus.getBusinessCode().getDescription().getMessageCode(),null, locale));
								}
		
								effDate = outRBM.getEffDt();
								compensationDate = outRBM.getCompensationDate();
								approvalId = outRBM.getApprovalId();
							}

							if (outRBM.getStatusCode().equals( CoreConstants.ERROR_STATUS_CODE_300)
									|| outRBM.getStatusCode().equals(CoreConstants.ERROR_STATUS_CODE_700)) {
								
								ModRevRBMPaymentOutDTO outClient = revRBMTransaction(inDTO);
								transactionStatus = transactionStatusDAO.findById(TransactionStatusEnum.CONFIRMED_NA.getCode());
								tx.setStatus(transactionStatus);
								outDTO.setStatusCode(CoreConstants.ERROR_STATUS_CODE_300);
								outDTO.setStatusDesc(CoreConstants.ERROR_STATUS_CODE_DESC_300);
								outDTO.setTrnStatusCode(Long.valueOf(CoreConstants.ERROR_STATUS_CODE_300.toString()));
								outDTO.setTrnStatusDesc(CoreConstants.ERROR_STATUS_CODE_DESC_300);
								effDate = outClient.getEffDt();
								compensationDate = outClient.getCompensationDt();
								approvalId = outClient.getApprovalId();
							}
							
							//Mapeo de error Status CODE 100 Redeban
							if(outRBM.getStatusCode().equals(CoreConstants.ERROR_STATUS_CODE_100)) {
								
							}

							// Actualizar la transacción
							tx.setPayDate(effDate);
							tx.setCompensationDate(compensationDate);
							tx.setApprovalNumber(approvalId);
							transactionDAO.update(tx);
		
							// Leer Envio de Correo Electrónico
							Transaction txdata = transactionDAO.read(tx.getId());
							if (txdata.getEmailflag() == 0) {
								tx.setEmailflag(1);
								transactionDAO.update(tx);
								// Enviar correo de confirmación
								sendMailService.sendMail(tx);
								if(!(tx.getCustomerEmail().equals(tx.getPayerMail())) && (tx.getStatus().getCode() == TransactionStatusEnum.CONFIRMED_OK.getCode())){
									String mail = tx.getPayerMail();
									tx.setPayerMail(tx.getCustomerEmail());
									sendMailService.sendMail(tx);
									tx.setPayerMail(mail);
								}
							}
		
							// Conciliar en linea la transacción
							String statusRed;
							if (outRBM.getTrnServerStatusCode() != null) {
								statusRed = outRBM.getTrnServerStatusCode();
							} else {
								statusRed = outRBM.getStatusCode().toString();
							}
							reconciledTransactionService.createOrUpdate(tx, statusRed);

						// Objeto de salida
						outDTO.setPmtId(String.valueOf(tx.getPmtId()));
						outDTO.setTrnServerStatusCode(null);
						outDTO.setTrnServerStatusDesc(null);
						outDTO.setEffDt(tx.getPayDate());
						outDTO.setCompensationDate(tx.getCompensationDate());
						outDTO.setApprovalId(tx.getApprovalNumber());
	
					} else {
						LOGGER.error("@PGWPaymentServiceImpl addRBMPayment {} \n", CoreConstants.RSA_USER_STATUS_ERROR);
						outDTO = rsaError(outDTO, tx, CoreConstants.RSA_USER_STATUS_ERROR);
					}
	
						} else {
							LOGGER.error("@PGWPaymentServiceImpl addRBMPayment {} \n", CoreConstants.RSA_USER_STATUS_ERROR);
							outDTO = rsaError(outDTO, tx, CoreConstants.RSA_USER_STATUS_ERROR);
						}
	
					}
				*/
				/** FIN - C10 **/
				
				/** INICIO-C11 **/
				// Consumir el servicio de pago RBM
				AddRBMPaymentOutDTO addRBMPaymentOutDTO1 = initRBMTransaction(addRBMPaymentInDTO);
				// outRBM.setStatusCode(300);

				//retorna error de longitud de numero de documento de identidad
				if (addRBMPaymentOutDTO1.getStatusCode() == Long.parseLong(Integer.toString(CoreConstants.INVALID_LENGTH_INFORMATION))) {
					transactionStatus = transactionStatusDAO.findById(TransactionStatusEnum.CANCELLED.getCode());
					transaction.setStatus(transactionStatus);
					addRBMPaymentOutDTO.setStatusCode(CoreConstants.INVALID_LENGTH_INFORMATION);
					addRBMPaymentOutDTO.setStatusDesc(getMessage(BundleKeys.TRANSACTION_SUCCESS, null, locale));
					addRBMPaymentOutDTO.setTrnStatusCode(Long.valueOf(CoreConstants.INVALID_LENGTH_INFORMATION));
					addRBMPaymentOutDTO.setTrnStatusDesc(CoreConstants.INVALID_LENGTH_INFORMATION_DES);
				}

				// retorna error de cálculo del impuesto
				if (addRBMPaymentOutDTO1.getStatusCode() == Long.parseLong(Integer.toString(CoreConstants.INVALID_TAX_AMOUNT))) {
					transactionStatus = transactionStatusDAO.findById(TransactionStatusEnum.CANCELLED.getCode());
					transaction.setStatus(transactionStatus);
					addRBMPaymentOutDTO.setStatusCode(CoreConstants.INVALID_TAX_AMOUNT);
					addRBMPaymentOutDTO.setStatusDesc(getMessage(BundleKeys.TRANSACTION_SUCCESS, null, locale));
					addRBMPaymentOutDTO.setTrnStatusCode(Long.valueOf(CoreConstants.INVALID_TAX_AMOUNT));
					addRBMPaymentOutDTO.setTrnStatusDesc(CoreConstants.INVALID_TAX_AMOUNT_DESC);
				}


				// retorna errores
				// INI C07 
				if (addRBMPaymentOutDTO1.getStatusCode() == Long.parseLong(Integer.toString(CoreConstants.ERROR_STATUS_CODE_1260)) 
						|| addRBMPaymentOutDTO1.getStatusCode().equals((CoreConstants.ERROR_STATUS_CODE_100))
						|| addRBMPaymentOutDTO1.getStatusCode().equals((CoreConstants.ERROR_STATUS_CODE_400))) {
					
					transactionStatus = transactionStatusDAO.findById(TransactionStatusEnum.CONFIRMED_NA.getCode());
					transaction.setStatus(transactionStatus);
					addRBMPaymentOutDTO.setStatusCode(addRBMPaymentOutDTO1.getStatusCode());
					addRBMPaymentOutDTO.setStatusDesc(addRBMPaymentOutDTO1.getStatusDesc());
					addRBMPaymentOutDTO.setTrnStatusCode(transactionStatus.getBusinessCode().getCode());
					addRBMPaymentOutDTO.setTrnStatusDesc(getMessage(transactionStatus.getBusinessCode().getDescription().getMessageCode(),null, locale));
				}
				// FIN C07 
				if (addRBMPaymentOutDTO1.getStatusCode().equals(CoreConstants.SUCCESS_STATUS_CODE)) {
					// EL bus hace homologación retornando estados de negocio.

					if (addRBMPaymentOutDTO1.getTrnStatusCode().equals(BusinessStatusEnum.APROBADA.getCode())) {

						transactionStatus = transactionStatusDAO.findById(TransactionStatusEnum.CONFIRMED_OK.getCode());
						transaction.setStatus(transactionStatus);
						addRBMPaymentOutDTO.setStatusCode(CoreConstants.SUCCESS_STATUS_CODE);
						addRBMPaymentOutDTO.setStatusDesc(getMessage(BundleKeys.TRANSACTION_SUCCESS, null,locale));
						addRBMPaymentOutDTO.setTrnStatusCode(transactionStatus.getBusinessCode().getCode());
						addRBMPaymentOutDTO.setTrnStatusDesc(getMessage(transactionStatus.getBusinessCode().getDescription().getMessageCode(),null, locale));
					} else {
						transactionStatus = transactionStatusDAO.findById(TransactionStatusEnum.CONFIRMED_NA.getCode());
						transaction.setStatus(transactionStatus);
						addRBMPaymentOutDTO.setStatusCode(CoreConstants.SUCCESS_STATUS_CODE);
						addRBMPaymentOutDTO.setStatusDesc(getMessage(BundleKeys.TRANSACTION_SUCCESS, null,locale));
						addRBMPaymentOutDTO.setTrnStatusCode(transactionStatus.getBusinessCode().getCode());
						addRBMPaymentOutDTO.setTrnStatusDesc(getMessage(transactionStatus.getBusinessCode().getDescription().getMessageCode(),null, locale));
					}

					date = addRBMPaymentOutDTO1.getEffDt();
					compensationDate = addRBMPaymentOutDTO1.getCompensationDate();
					approvalId = addRBMPaymentOutDTO1.getApprovalId();
				}

				if (addRBMPaymentOutDTO1.getStatusCode().equals( CoreConstants.ERROR_STATUS_CODE_300)
						|| addRBMPaymentOutDTO1.getStatusCode().equals(CoreConstants.ERROR_STATUS_CODE_700)) {
					
					ModRevRBMPaymentOutDTO modRevRBMPaymentOutDTO = revRBMTransaction(addRBMPaymentInDTO);
					transactionStatus = transactionStatusDAO.findById(TransactionStatusEnum.CONFIRMED_NA.getCode());
					transaction.setStatus(transactionStatus);
					addRBMPaymentOutDTO.setStatusCode(CoreConstants.ERROR_STATUS_CODE_300);
					addRBMPaymentOutDTO.setStatusDesc(CoreConstants.ERROR_STATUS_CODE_DESC_300);
					addRBMPaymentOutDTO.setTrnStatusCode(Long.valueOf(CoreConstants.ERROR_STATUS_CODE_300.toString()));
					addRBMPaymentOutDTO.setTrnStatusDesc(CoreConstants.ERROR_STATUS_CODE_DESC_300);
					date = modRevRBMPaymentOutDTO.getEffDt();
					compensationDate = modRevRBMPaymentOutDTO.getCompensationDt();
					approvalId = modRevRBMPaymentOutDTO.getApprovalId();
				}

				//Mapeo de error Status CODE 100 Redeban
				if(addRBMPaymentOutDTO1.getStatusCode().equals(CoreConstants.ERROR_STATUS_CODE_100)) {
					
				}

				// Actualizar la transacción
				transaction.setPayDate(date);
				transaction.setCompensationDate(compensationDate);
				transaction.setApprovalNumber(approvalId);
				transactionDAO.update(transaction);

				// Leer Envio de Correo Electrónico
				Transaction transactiondata = transactionDAO.read(transaction.getId());
				if (transactiondata.getEmailflag() == CoreConstants.FLAG_EMAIL_OFF) {
					transaction.setEmailflag(CoreConstants.FLAG_EMAIL_ON);
					transactionDAO.update(transaction);
					// Enviar correo de confirmación
					sendMailService.sendMail(transaction);
					if(!(transaction.getCustomerEmail().equals(transaction.getPayerMail())) && (transaction.getStatus().getCode() == TransactionStatusEnum.CONFIRMED_OK.getCode())){
						String mail = transaction.getPayerMail();
						transaction.setPayerMail(transaction.getCustomerEmail());
						sendMailService.sendMail(transaction);
						transaction.setPayerMail(mail);
					}
				}

				// Conciliar en linea la transacción
				String statusRed;
				if (addRBMPaymentOutDTO1.getTrnServerStatusCode() != null) {
					statusRed = addRBMPaymentOutDTO1.getTrnServerStatusCode();
				} else {
					statusRed = addRBMPaymentOutDTO1.getStatusCode().toString();
				}
				reconciledTransactionService.createOrUpdate(transaction, statusRed);

				// Objeto de salida
				addRBMPaymentOutDTO.setPmtId(String.valueOf(transaction.getPmtId()));
				addRBMPaymentOutDTO.setTrnServerStatusCode(null);
				addRBMPaymentOutDTO.setTrnServerStatusDesc(null);
				addRBMPaymentOutDTO.setEffDt(transaction.getPayDate());
				addRBMPaymentOutDTO.setCompensationDate(transaction.getCompensationDate());
				addRBMPaymentOutDTO.setApprovalId(transaction.getApprovalNumber());								
				/** FIN-C11 **/
				
			}
			
		}catch (NoResultException e) {
			LOGGER.error("No se pudo realizar la transaccion con el RQ'" +(addRBMPaymentInDTO.getRqUID())+ "' "
					+ "Problemas con la conexion en BD del Core Pasarela. Exception:{}\nCause:{} ");
			System.err.println(e.getMessage());
			addRBMPaymentOutDTO.setStatusCode(CoreConstants.ERROR_STATUS_CODE_300);
			addRBMPaymentOutDTO.setStatusDesc(CoreConstants.ERROR_STATUS_CODE_DESC_300);
			addRBMPaymentOutDTO.setTrnStatusCode(Long.valueOf(CoreConstants.FAULT_STATUS_CODE));
			addRBMPaymentOutDTO.setTrnStatusDesc(CoreConstants.FAULT_STATUS_ERROR_DESC);
			addRBMPaymentOutDTO.setTrnServerStatusCode(String.valueOf(CoreConstants.FAULT_STATUS_CODE));
			addRBMPaymentOutDTO.setTrnServerStatusDesc(CoreConstants.FAULT_STATUS_DESC);
		}
		/**FIN C01 **/
		
		/** INI - C10 **/				
		//outDTO.setToken(adaptiveAuthenticationService.getLastTokenCookie( inDTO.getTransactionBO().getPmtId() ));
		/** FIN - C10 **/
		
		return addRBMPaymentOutDTO;
	}
	/**
	 * validacion de listas negras en pagos RBM
	 * 
	 * @param transaction
	 * @param paymentWay
	 * @return boolean
	 */
	public boolean validateTopByCommerceAndPaymentWay(Transaction transaction, PaymentWay paymentWay) throws Exception {
		
		boolean isActive = true;
//		long txValue, tpMin, tpMax;
		
		try {
			
			//Tope permanente
			Top top = topesDAO.findTopPermanentTran(transaction.getCommerce().getId(), paymentWay.getId(), transaction.getTotalValue());
			
			if(top != null)
				return false;
			
			Top topDate = topesDAO.findTopByDateTran(transaction.getCommerce().getId(), paymentWay.getId(), transaction.getTotalValue());
			
			if(topDate != null)
				return false;
			
//			if(topes != null && !topes.isEmpty()){
//				isActive = Boolean.TRUE;
//			}
//			List<Top> tp = topesDAO.findByCommerceAndPaymentWay(tx.getCommerce().getId(), paymentWay.getId());
//			if (tp != null) {
//				if (tp.getTopPermanent() != 0) {
//					txValue = tx.getTotalValue().longValue();
//					tpMin = tp.getTopMin().longValue();
//					tpMax = tp.getTopMax().longValue();
//					if (txValue > tpMin && txValue < tpMax) {
//						isActive = true;
//					}
//				} else {
//					if (tp.getBeginDate().before(tx.getTransactionDate())
//							&& tp.getEndDate().after(tx.getTransactionDate())) {
//						txValue = tx.getTotalValue().longValue();
//						tpMin = tp.getTopMin().longValue();
//						tpMax = tp.getTopMax().longValue();
//						if (txValue > tpMin && txValue < tpMax) {
//							isActive = true;
//						}
//					}
//				}
//			} else {
//				isActive = true;
//			}
		} catch (NoResultException e) {
			LOGGER.error("@validateTopByCommerceAndPaymentWay error: {}: ", e.getMessage() );
			throw e;
		}
		return isActive;
	}
	/**
	 * Permite validar los topes de errores para transacciones rbm
	 * @param addRBMPaymentOutDTO
	 * @param transaction
	 * @return AddRBMPaymentOutDTO
	 */
	private AddRBMPaymentOutDTO setTopesError(AddRBMPaymentOutDTO addRBMPaymentOutDTO, Transaction transaction) {
		
		ResponseCode responseCode = responseCodeDAO.read(CoreConstants.TOP_ERROR_CODE);
		
		/**INICIO-C04**/
		transaction.setStatus(transactionStatusDAO.findById(TransactionStatusEnum.REFUSED.getCode()));
		/**FIN-C04**/
		transaction.setResponseCode(responseCode);
		transactionDAO.update(transaction);
		
		LOGGER.error("@addRBMTransaction {} ", transaction.getResponseCode().getDescription());

		// Leer  Envio de Correo Electrónico
		Transaction txdata = transactionDAO.read(transaction.getId());
		if(txdata.getEmailflag()==CoreConstants.FLAG_EMAIL_OFF){
			
			transaction.setEmailflag(CoreConstants.FLAG_EMAIL_ON);
			transactionDAO.update(transaction);
			
			// Enviar correo de confirmación			
			sendMailService.sendMail(transaction);
		}
				
		addRBMPaymentOutDTO.setStatusCode(Integer.parseInt(transaction.getResponseCode().getCode()));
		addRBMPaymentOutDTO.setStatusDesc(transaction.getResponseCode().getDescription());
		addRBMPaymentOutDTO.setTrnStatusCode(CoreConstants.SUCCESS_STATUS_CODE.longValue());
		addRBMPaymentOutDTO.setTrnStatusDesc(getMessage(BundleKeys.TRANSACTION_SUCCESS, null, locale));
		addRBMPaymentOutDTO.setTrnServerStatusCode(CoreConstants.SUCCESS_STATUS_CODE.toString());
		addRBMPaymentOutDTO.setTrnServerStatusDesc(getMessage(BundleKeys.TRANSACTION_SUCCESS, null, locale));
		addRBMPaymentOutDTO.setEffDt(transaction.getPayDate());
		addRBMPaymentOutDTO.setCompensationDate(transaction.getCompensationDate());
		addRBMPaymentOutDTO.setApprovalId(transaction.getApprovalNumber());
		
		return addRBMPaymentOutDTO;		
	}
	/**
	 * reduce la dimension del rqId
	 * @param Long
	 * @return Long
	 */
	public Long convertRqId(Long rqId){
		StringBuilder num = new StringBuilder(rqId.toString());
		if(num.length() < 7){
			return rqId;
		}
		return Long.valueOf(num.substring(0,6));
	}
	/**
	 * validacion de listas negras en rbm
	 * @param addRBMPaymentOutDTO
	 * @param transaction
	 * @param int
	 * @return AddRBMPaymentOutDTO
	 */
	private AddRBMPaymentOutDTO rbmBlackListFlow(AddRBMPaymentOutDTO addRBMPaymentOutDTO,
			Transaction transaction, int blackListIpSize) {
		
		TransactionStatus transactionStatus = transactionStatusDAO.findById(TransactionStatusEnum.CANCELLED.getCode());
		transaction.setStatus(transactionStatus);
		transaction.setResponseCode(getFraudResponseCode(blackListIpSize));
		transactionDAO.update(transaction);
		
		// Leer Envio de Correo Electrónico
		Transaction txdata = transactionDAO.read(transaction.getId());
		if(txdata.getEmailflag()==CoreConstants.FLAG_EMAIL_OFF){
			
			transaction.setEmailflag(CoreConstants.FLAG_EMAIL_ON);
			transactionDAO.update(transaction);
			
			// Enviar correo de confirmación
			sendMailService.sendMail(transaction);
		}
        
		// Objeto de salida
		addRBMPaymentOutDTO.setPmtId(String.valueOf(transaction.getPmtId()));
		addRBMPaymentOutDTO.setStatusCode(CoreConstants.ERROR_DATA_SECURITY_CODE);
		addRBMPaymentOutDTO.setStatusDesc(CoreConstants.ERROR_DATA_SECURITY_CODE_DESC);
		addRBMPaymentOutDTO.setTrnStatusCode(Long.valueOf(CoreConstants.ERROR_DATA_SECURITY_CODE));
		addRBMPaymentOutDTO.setTrnStatusDesc(CoreConstants.ERROR_DATA_SECURITY_CODE_DESC);
		addRBMPaymentOutDTO.setTrnServerStatusCode(null); 
		addRBMPaymentOutDTO.setTrnServerStatusDesc(null);
		addRBMPaymentOutDTO.setEffDt(transaction.getPayDate());
		addRBMPaymentOutDTO.setCompensationDate(transaction.getCompensationDate());
		addRBMPaymentOutDTO.setApprovalId(transaction.getApprovalNumber());
        
		return addRBMPaymentOutDTO;
	}
	/**
	 * validacion de listas negras en rbm
	 * @param addRBMPaymentInDTO
	 * @return AddRBMPaymentOutDTO
	 */
	private AddRBMPaymentOutDTO initRBMTransaction(AddRBMPaymentInDTO addRBMPaymentInDTO){
		AddRBMPaymentOutDTO addRBMPaymentOutDTO;
		if(addRBMPaymentInDTO.getTransactionBO().getSource() != null 
				&& addRBMPaymentInDTO.getTransactionBO().getSource().getId() != null
				&& !addRBMPaymentInDTO.getTransactionBO().getSource().getId().isEmpty())
			addRBMPaymentInDTO.getTransactionBO().getSource().setId(addRBMPaymentInDTO.getTransactionBO().getSource().getId());
		else
			addRBMPaymentInDTO.getTransactionBO().getSource().setId("4");
		Commerce commerce = commerceDAO.findByNura(addRBMPaymentInDTO.getTransactionBO().getCommerce().getNuraCode());
		addRBMPaymentInDTO.getTransactionBO().setReference1(commerce.getIncocreditoCode() != null ? commerce.getIncocreditoCode() : "");
		addRBMPaymentInDTO.getTransactionBO().setReference2(commerce.getTerminalCode() != null ? commerce.getTerminalCode() : "");
		addRBMPaymentInDTO.getTransactionBO().setReference3(addRBMPaymentInDTO.getTransactionBO().getReference3() != null ? addRBMPaymentInDTO.getTransactionBO().getReference3() : "");
		
		
		addRBMPaymentOutDTO = gatewayPaymentClientCtrlService.addRBMPayment(addRBMPaymentInDTO);
				
		return addRBMPaymentOutDTO;
	}
	/**
	 * obtiene los mensajes de bundles
	 * @param String messageKey
	 * @param Object args
	 * @param Locale
	 * @return String
	 */
	public String getMessage(String messageKey, Object[] args, Locale locale) {
		if (resourceBundleManager == null) {
			return messageKey;
		}
		resourceBundleManager.setBundle(BundleType.MESSAGES);
		return resourceBundleManager.getMessage(messageKey, args, locale);
	}
	/**
	 * valida la transaccion en rbm
	 * @param addRBMPaymentInDTO
	 * @return ModRevRBMPaymentOutDTO
	 */
	private ModRevRBMPaymentOutDTO revRBMTransaction(AddRBMPaymentInDTO addRBMPaymentInDTO) {
		ModRevRBMPaymentInDTO modRevRBMPaymentInDTO;
		String username;
		String pass;
		try {
			modRevRBMPaymentInDTO = new ModRevRBMPaymentInDTO();
			modRevRBMPaymentInDTO.setRqUID(addRBMPaymentInDTO.getRqUID());
			modRevRBMPaymentInDTO.setChannel(String.valueOf(addRBMPaymentInDTO.getTransactionBO().getSource().getId()));
			modRevRBMPaymentInDTO.setClientDt(addRBMPaymentInDTO.getClientDt());
			modRevRBMPaymentInDTO.setIpAddr(addRBMPaymentInDTO.getIpAddr());
			modRevRBMPaymentInDTO.setCustIdType(addRBMPaymentInDTO.getTransactionBO().getCustomerDocType());
			modRevRBMPaymentInDTO.setCustIdNum(addRBMPaymentInDTO.getTransactionBO().getCustomerDocId());
			modRevRBMPaymentInDTO.setCustLoginId(null);
			modRevRBMPaymentInDTO.setPmtId(addRBMPaymentInDTO.getTransactionBO().getPmtId());
			modRevRBMPaymentInDTO.setInstalamentsNum(addRBMPaymentInDTO.getInstalamentsNum());
			modRevRBMPaymentInDTO.setOrderId(addRBMPaymentInDTO.getTransactionBO().getOrderNumber());
			modRevRBMPaymentInDTO.setOrderDesc(addRBMPaymentInDTO.getTransactionBO().getDescription());
			modRevRBMPaymentInDTO.setOrderExpDt(null); 
			modRevRBMPaymentInDTO.setOrderEndDt(null);
			modRevRBMPaymentInDTO.setCardEmbossNum(addRBMPaymentInDTO.getTransactionBO().getCreditCard().getNumber());
			modRevRBMPaymentInDTO.setBrand(addRBMPaymentInDTO.getTransactionBO().getCreditCard().getBrand().getName());
			modRevRBMPaymentInDTO.setCardExpDt(addRBMPaymentInDTO.getExpDate()); 
			modRevRBMPaymentInDTO.setCardVrfyData(String.valueOf(addRBMPaymentInDTO.getTransactionBO().getCreditCard().getSecurityCode())); 
			modRevRBMPaymentInDTO.setAmt(addRBMPaymentInDTO.getTransactionBO().getTotalValue()); 
			modRevRBMPaymentInDTO.setCurCode(addRBMPaymentInDTO.getTransactionBO().getCurrency()); 
			modRevRBMPaymentInDTO.setTaxAmt(addRBMPaymentInDTO.getTransactionBO().getTaxValue()); 
			modRevRBMPaymentInDTO.setReferenceList(getReferenceList(addRBMPaymentInDTO.getTransactionBO())); 
			username = tripleDes.decrypt(Parametro.getParametro("pasarelawsrbmwsseusername"));
			pass = tripleDes.decrypt(Parametro.getParametro("pasarela.ws.rbm.wsse.password"));
			return gatewayPaymentAdmCtrlService.modRevRBMPayment(modRevRBMPaymentInDTO, username, pass);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return null;
		
	}
	/**
	 * obtiene las referencias de la transaccion
	 * @param transactionBO
	 * @return List<String>
	 */
	private List<String> getReferenceList(TransactionBO transactionBO) {
		List<String> referenceList = new ArrayList<String>();
		if(transactionBO != null) {
			referenceList.add(transactionBO.getReference1()); //INCOCREDITO
			referenceList.add(transactionBO.getReference2()); //TERMINAL
			referenceList.add(transactionBO.getReference3());
		}
		return referenceList;
	}
	/**
	 * obtiene codigo de respuesta fraud
	 * @param int blackListIpFound
	 * @return ResponseCode
	 */
	public ResponseCode getFraudResponseCode(int blackListIpFound) {
		if(blackListIpFound == 1) {
			LOGGER.info("Validación Listas Negras Fallida: " + ResponseCodeEnum.NOT_AUTHORIZED_FRAUD_IP.toString());
			return responseCodeDAO.read(ResponseCodeEnum.NOT_AUTHORIZED_FRAUD_IP.toString());
		} else {
			LOGGER.info("Validación Listas Negras Fallida: " + ResponseCodeEnum.NOT_AUTHORIZED_FRAUD_DOC.toString());
			return responseCodeDAO.read(ResponseCodeEnum.NOT_AUTHORIZED_FRAUD_DOC.toString());
		}
	}
	
}
