# pgw-inquiries
PCI-DSS/pgw-inquiries - repositorio de consultas
