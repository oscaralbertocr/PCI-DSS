# pgw-core-logging
# [02092019] Release de Logs prv_jmrodriguez:CL_1.0 
# [15102019] Particion de Logs prv_javendano:CL_1.1
